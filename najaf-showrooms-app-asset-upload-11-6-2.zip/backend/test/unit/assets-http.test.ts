// Phase 11.6.2: the HTTP contract of the upload routes through the real routes, the real authentication service (fake auth store),
// the real asset service, the real in-memory storage provider and the in-memory asset store. Plus source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { ASSET_RATE_LIMITS, registerAssetRoutes, toAssetHttp } from '../../src/assets/routes.ts';
import { ASSET_UPLOAD_MAX_BYTES, AssetError, createAssetService } from '../../src/assets/service.ts';
import { COUNT_RECENT_PENDING_SQL, LOCK_ACTING_USER_SQL, LOCK_UPLOAD_SLOT_SQL, buildDeletePendingOwn, buildFindOwn, buildInsertPending } from '../../src/assets/repository.ts';
import { createMemoryStorage } from '../../src/storage/index.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeAssetStore } from '../helpers/fake-assets.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };
type AssetBody = { asset: Record<string, unknown> & { id: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JPG = new Uint8Array(readFileSync(join(ROOT, 'test', 'fixtures', 'images', 'baseline-3x2.jpg')));
const UPLOAD = '/v1/me/assets';
const ONE = '/v1/me/assets/:id';

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  let authCalls = 0;
  const countingAuth = { authenticate: async (t: string | undefined) => (authCalls++, auth.authenticate(t)) };
  const fa = makeFakeAssetStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
  });
  const storage = createMemoryStorage();
  const assets = createAssetService({ store: fa.store, storage });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler; scoped: boolean }> = [];
  const parsers: Array<{ types: unknown; opts: unknown; scoped: boolean }> = [];
  const makeApp = (scoped: boolean): Record<string, unknown> => {
    const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
      routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler, scoped });
    };
    return {
      get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE'),
      addContentTypeParser: (types: unknown, opts: unknown) => void parsers.push({ types, opts, scoped }),
      register: (plugin: (child: unknown) => Promise<void>) => void plugin(makeApp(true)),
    };
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerAssetRoutes(makeApp(false) as never, { auth: countingAuth, assets, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  const infoLogs: unknown[] = [];
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent & { handlerRan: boolean }> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {}, info: (o: unknown) => void infoLogs.push(o) }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return { ...sent, handlerRan: false };
    }
    await route.handler(req, reply);
    return { ...sent, handlerRan: true };
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    return { id: r.user.id, headers: bearer(r.session.accessToken) };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    return { id: r.user.id, headers: bearer(r.session.accessToken) };
  }
  const upload = (who: { headers: Record<string, string> }, body: unknown = JPG, type = 'image/jpeg', query: unknown = { kind: 'car_image' }) =>
    call('POST', UPLOAD, { headers: { ...who.headers, 'content-type': type }, body: body instanceof Uint8Array ? Buffer.from(body) : body, query });
  return { routes, parsers, call, member, pendingDealer, upload, fa, storage, infoLogs, authCalls: () => authCalls };
}

describe('asset routes: registration', () => {
  it('registers exactly the upload and read routes, inside an encapsulated plugin that alone parses image bodies', () => {
    const { routes, parsers } = setup(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`GET ${ONE}`, `POST ${UPLOAD}`]);
    assert.ok(routes.every((r) => r.scoped), 'both routes live in the encapsulated plugin');
    assert.deepEqual(parsers.map((p) => ({ ...p, opts: { ...(p.opts as object) } })), [{ types: ['image/jpeg', 'image/png', 'image/webp'], opts: { parseAs: 'buffer', bodyLimit: ASSET_UPLOAD_MAX_BYTES }, scoped: true }]);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts?.bodyLimit, ASSET_UPLOAD_MAX_BYTES);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
  });
});

describe('asset routes: refused before the body is read', () => {
  it('no token or a bad token is 401 (WWW-Authenticate) in the onRequest hook, before any handler or parsing', async () => {
    const s = setup();
    for (const headers of [{ 'content-type': 'image/jpeg' }, { 'content-type': 'image/jpeg', authorization: 'Bearer forged.token.value' }]) {
      const r = await s.call('POST', UPLOAD, { headers, query: { kind: 'car_image' } });
      assert.equal(r.status, 401);
      assert.equal(r.handlerRan, false);
      assert.equal(r.headers['www-authenticate'], 'Bearer');
    }
    const g = await s.call('GET', ONE, { params: { id: '0f8fad5b-d9cb-469f-a165-70867728950e' } });
    assert.equal(g.status, 401);
  });

  it('a declared type that is not an accepted image is 415 in the hook (SVG, HTML, JSON, multipart, none)', async () => {
    const s = setup();
    const m = await s.member();
    for (const type of ['image/svg+xml', 'text/html', 'application/json', 'multipart/form-data; boundary=x', 'image/png; x=y']) {
      const r = await s.upload(m, JPG, type);
      assert.equal(r.status, 415, type);
      assert.equal(r.handlerRan, false);
    }
    const none = await s.call('POST', UPLOAD, { headers: m.headers, query: { kind: 'car_image' } });
    assert.equal(none.status, 415);
    assert.equal(s.storage.size(), 0);
  });
});

describe('asset routes: behavior', () => {
  it('201 {asset} pending with a whitelist; GET returns it to the owner; nothing internal in answers or logs', async () => {
    const s = setup();
    const m = await s.member();
    const r = await s.upload(m);
    assert.equal(r.status, 201);
    const asset = (r.body as AssetBody).asset;
    assert.deepEqual(Object.keys(asset).sort(), ['bytes', 'createdAt', 'height', 'id', 'kind', 'status', 'width']);
    assert.equal(asset['status'], 'pending');
    const g = await s.call('GET', ONE, { headers: m.headers, params: { id: asset.id } });
    assert.equal(g.status, 200);
    assert.deepEqual((g.body as AssetBody).asset, asset);
    const key = s.fa.rows()[0]!.storageKey!;
    const sha = s.fa.rows()[0]!.sha256!;
    for (const text of [JSON.stringify(r), JSON.stringify(g), JSON.stringify(s.infoLogs)]) {
      assert.ok(!text.includes(key) && !text.includes('incoming') && !text.includes(sha), 'no storage key or checksum leaves the server');
    }
    assert.deepEqual(s.infoLogs, [{ event: 'assets.uploaded', assetId: asset.id, kind: 'car_image', bytes: JPG.length }]);
  });

  it('another user gets 404 identical to an unknown id; a malformed id is 404', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const id = ((await s.upload(a)).body as AssetBody).asset.id;
    const unknown = await s.call('GET', ONE, { headers: b.headers, params: { id: '0f8fad5b-d9cb-469f-a165-70867728950e' } });
    const theirs = await s.call('GET', ONE, { headers: b.headers, params: { id } });
    assert.equal(theirs.status, 404);
    assert.deepEqual(theirs.body, unknown.body);
    assert.equal((await s.call('GET', ONE, { headers: a.headers, params: { id: '../x' } })).status, 404);
  });

  it('a pending dealer is 403; a wrong kind or a filename in the query is 400; bytes that are not the declared image are 400', async () => {
    const s = setup();
    const d = await s.pendingDealer();
    assert.equal((await s.upload(d)).status, 403);
    const m = await s.member();
    const q = await s.upload(m, JPG, 'image/jpeg', { kind: 'car_image', filename: '../../evil.php' });
    assert.equal(q.status, 400);
    assert.deepEqual((q.body as ErrBody).error.fields, [{ field: 'filename', code: 'unknown_field' }]);
    const mismatch = await s.upload(m, JPG, 'image/png');
    assert.equal(mismatch.status, 400);
    assert.deepEqual((mismatch.body as ErrBody).error.fields, [{ field: 'body', code: 'invalid_format' }]);
    assert.equal(s.storage.size(), 0);
  });

  it('uploads have their own per-address budget; reads are not blocked by it', async () => {
    const s = setup(true);
    const m = await s.member();
    for (let i = 0; i < ASSET_RATE_LIMITS.upload.limit; i++) assert.equal((await s.upload(m, JPG, 'image/gif')).status, 415);
    const denied = await s.upload(m);
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal(denied.handlerRan, false);
    assert.equal((await s.call('GET', ONE, { headers: m.headers, params: { id: '0f8fad5b-d9cb-469f-a165-70867728950e' } })).status, 404);
  });

  it('maps every error to its status; leaves unknown ones to the global handler', () => {
    const m = (e: unknown) => toAssetHttp(e)?.status;
    assert.equal(m(new AssetError('validation_failed', [{ field: 'body', code: 'required' }])), 400);
    assert.equal(m(new AssetError('unsupported_media_type')), 415);
    assert.equal(m(new AssetError('too_large')), 413);
    assert.equal(m(new AssetError('upload_limit')), 409);
    assert.equal(m(new AssetError('storage_unavailable')), 503);
    assert.equal(m(new AuthzError('forbidden')), 403);
    assert.equal(toAssetHttp(new Error('boom')), undefined);
  });
});

describe('assets: SQL and source guards', () => {
  it('the row is created pending for the given owner, without mime/thumb/ready; reads and deletes are scoped by owner', () => {
    const ins = buildInsertPending({ ownerId: '5', kind: 'car_image', storageKey: 'incoming/car_image/x', bytes: 3, width: 1, height: 1, sha256: 'a'.repeat(64) });
    assert.match(ins.text, /INSERT INTO assets AS a \(owner_id, kind, status, storage_key, bytes, width, height, sha256\)\s+VALUES \(\$1::bigint, \$2, 'pending', \$3, \$4, \$5, \$6, \$7\)/);
    assert.ok(!/\b(mime|thumb_key|ready_at)\b/.test(ins.text));
    assert.deepEqual(ins.values, ['5', 'car_image', 'incoming/car_image/x', 3, 1, 1, 'a'.repeat(64)]);
    assert.match(buildFindOwn('u', '5').text, /WHERE a\.id = \$1::uuid AND a\.owner_id = \$2::bigint$/);
    const del = buildDeletePendingOwn('u', '5').text.replace(/\s+/g, ' ');
    assert.match(del, /WHERE a\.id = \$1::uuid AND a\.owner_id = \$2::bigint AND a\.status = 'pending' AND NOT EXISTS \(SELECT 1 FROM car_images ci WHERE ci\.asset_id = a\.id\) AND NOT EXISTS \(SELECT 1 FROM showrooms s WHERE s\.cover_asset_id = a\.id\)/);
    assert.match(COUNT_RECENT_PENDING_SQL, /owner_id = \$1::bigint AND status = 'pending' AND created_at > now\(\) - interval '24 hours'/);
    assert.match(LOCK_UPLOAD_SLOT_SQL, /pg_advisory_xact_lock\(hashtextextended\('najaf\.asset-upload:' \|\| \$1::bigint::text, 0\)\)/);
    assert.match(LOCK_ACTING_USER_SQL, /status = 'active' AND deleted_at IS NULL FOR SHARE/);
  });

  it('nothing reads back a storage key, thumbnail key or checksum, and no statement writes another table', () => {
    const repo = code('src/assets/repository.ts');
    const selects = [...repo.matchAll(/SELECT[\s\S]*?FROM/g)].map((m) => m[0]).join(' ') + [...repo.matchAll(/RETURNING [^`]*/g)].map((m) => m[0]).join(' ');
    assert.ok(!/storage_key|thumb_key|sha256|mime/.test(selects.replace(/\$\{COLUMNS\}/g, '')), selects);
    assert.ok(!/storage_key|thumb_key|sha256|mime/.test(/const COLUMNS = '([^']*)'/.exec(repo)![1]!));
    assert.ok(!/SELECT\s+\*/i.test(repo));
    assert.ok(!/\b(INSERT INTO|UPDATE|DELETE FROM)\s+(?!assets\b)\w+/i.test(repo), 'only assets is written');
  });

  it('no client filename is ever read; the key is generated server-side; routes never name a key', () => {
    const svc = code('src/assets/service.ts');
    const routes = code('src/assets/routes.ts');
    assert.ok(!/filename|content-disposition|originalname/i.test(svc + routes + code('src/assets/validation.ts')));
    assert.match(svc, /const storageKey = assertSafeKey\(`incoming\/\$\{kind\}\/\$\{newKeyId\(\)\}`\);/);
    assert.ok(!/storageKey|storage_key/.test(routes));
    assert.ok(!/console\./.test(svc + routes));
    assert.match(routes, /return toActor\(found\.user\);/);
  });

  it('storage is wired only through index.ts (when configured) into the asset service', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.assets\) registerAssetRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /if \(\(process\.env\['STORAGE_PROVIDER'\] \?\? ''\) !== ''\) \{/);
    assert.match(index, /createAssetService\(\{ store: createPgAssetStore\(db\), storage: createStorage\(storageConfig\), maxObjectBytes: storageConfig\.maxObjectBytes, logger: boot \}\)/);
    assert.match(index, /boot\.info\(\{ storage: redactStorageConfig\(storageConfig\) \}/);
    assert.ok(!/storageConfig\.s3|secretAccessKey/.test(index), 'startup never touches the credentials directly');
  });
});

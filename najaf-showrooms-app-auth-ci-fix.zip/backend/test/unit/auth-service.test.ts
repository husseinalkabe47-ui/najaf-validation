import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAuthService } from '../../src/auth/service.ts';
import { LOGIN_MAX_FAILURES, SESSION_TTL_SECONDS } from '../../src/auth/policy.ts';
import { hashSessionToken, isWellFormedToken } from '../../src/auth/tokens.ts';
import { AuthError } from '../../src/auth/types.ts';
import { makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const PASSWORD = 'Corr3ct-Horse-Battery';
const reg = { name: 'علي حسين', phone: '07701234567', password: PASSWORD };
const E164 = '+9647701234567';

function setup() {
  const db = makeFakeAuthStore();
  const { hasher, calls } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, logger: log.logger });
  return { db, calls, log, auth };
}
const authError = (code: string) => (e: unknown) => e instanceof AuthError && e.code === code;
async function failureOf(p: Promise<unknown>): Promise<AuthError> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
    return e;
  }
  throw new Error('expected a failure');
}
const shape = (e: AuthError) => JSON.stringify({ name: e.name, code: e.code, message: e.message, fields: e.fields });

describe('registration', () => {
  it('creates an active regular user and a session; the result has exactly the public shape', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg, { userAgent: 'TestAgent/1.0' });
    assert.deepEqual(Object.keys(r.user).sort(), ['createdAt', 'id', 'name', 'phone', 'role', 'status']);
    assert.equal(r.user.name, 'علي حسين');
    assert.equal(r.user.phone, E164);
    assert.equal(r.user.role, 'user');
    assert.equal(r.user.status, 'active');
    assert.ok(isWellFormedToken(r.session.token));
    const ttl = new Date(r.session.expiresAt).getTime() - Date.now();
    assert.ok(Math.abs(ttl - SESSION_TTL_SECONDS * 1000) < 60_000, `ttl ${ttl}`);
    assert.equal(db.users().length, 1);
    assert.equal(db.sessions().length, 1);
    assert.equal(db.sessions()[0]?.userAgent, 'TestAgent/1.0');
  });

  it('stores only an argon2id hash of the password and only the SHA-256 of the token', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    const stored = db.users()[0]!;
    assert.ok(stored.passwordHash.startsWith('$argon2id$'));
    assert.ok(!stored.passwordHash.includes(PASSWORD));
    assert.ok(!db.dump().includes(PASSWORD), 'the password must not be stored anywhere');
    assert.ok(!db.dump().includes(r.session.token), 'the raw token must not be stored anywhere');
    assert.ok(db.sessions()[0]!.tokenHash.equals(hashSessionToken(r.session.token)));
    assert.equal(db.sessions()[0]!.tokenHash.length, 32);
  });

  it('never returns the password or the hash (shape and text)', async () => {
    const { auth } = setup();
    const r = await auth.register(reg);
    const text = JSON.stringify(r);
    assert.ok(!text.includes(PASSWORD) && !text.includes('$argon2') && !/password|hash/i.test(text));
  });

  it('accepts any supported phone format and stores the canonical E.164', async () => {
    for (const phone of ['07701234567', '+964 770 123 4567', '009647701234567', '٠٧٧٠١٢٣٤٥٦٧']) {
      const { db, auth } = setup();
      await auth.register({ ...reg, phone });
      assert.equal(db.users()[0]?.phoneE164, E164, phone);
    }
  });

  it('role, status and id are not inputs: attempts are validation failures and create nothing', async () => {
    const { db, auth } = setup();
    for (const extra of [{ role: 'admin' }, { status: 'active' }, { id: '1' }, { accountType: 'dealer' }]) {
      const e = await failureOf(auth.register({ ...reg, ...extra }));
      assert.equal(e.code, 'validation_failed');
    }
    assert.equal(db.users().length, 0);
  });

  it('malformed input is a validation failure, with no database work and no hashing', async () => {
    const { db, calls, auth } = setup();
    for (const body of [null, 'x', [], {}, { ...reg, name: 'ab' }, { ...reg, phone: '123' }, { ...reg, password: '123' }, { ...reg, password: 'x'.repeat(129) }]) {
      await assert.rejects(auth.register(body), authError('validation_failed'));
    }
    assert.equal(db.users().length, 0);
    assert.equal(calls.hash, 0);
  });

  it('validation errors do not echo the submitted values', async () => {
    const { auth } = setup();
    const e = await failureOf(auth.register({ name: 'ab', phone: 'not-a-phone-zzz', password: 'sh' }));
    const text = JSON.stringify({ message: e.message, fields: e.fields });
    assert.ok(!text.includes('not-a-phone-zzz') && !text.includes('"sh"'));
  });

  it('a duplicate phone is a generic conflict, creates no second user and no session, whatever the format', async () => {
    const { db, auth } = setup();
    await auth.register(reg);
    for (const phone of ['07701234567', '+9647701234567', '٠٧٧٠١٢٣٤٥٦٧']) {
      const e = await failureOf(auth.register({ ...reg, name: 'شخص آخر', phone }));
      assert.equal(e.code, 'conflict');
      assert.ok(!JSON.stringify(e).includes('9647701234567') && !e.message.includes('علي'));
    }
    assert.equal(db.users().length, 1);
    assert.equal(db.sessions().length, 1);
  });

  it('concurrent registrations of the same phone: exactly one wins (the unique index decides)', async () => {
    const { db, auth } = setup();
    const results = await Promise.allSettled([auth.register(reg), auth.register(reg), auth.register(reg)]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(results.filter((r) => r.status === 'rejected' && (r.reason as AuthError).code === 'conflict').length, 2);
    assert.equal(db.users().length, 1);
  });

  it('is atomic: if the session cannot be created, no user remains', async () => {
    const { db, auth } = setup();
    db.faults.failNextSessionCreate = true;
    await assert.rejects(auth.register(reg), /simulated session insert failure/);
    assert.equal(db.users().length, 0);
    assert.equal(db.sessions().length, 0);
    await auth.register(reg); // and the phone is still free
    assert.equal(db.users().length, 1);
  });

  it('cleans the user agent (control characters, length) and tolerates its absence', async () => {
    const { db, auth } = setup();
    await auth.register(reg, { userAgent: 'Agent\u0000\n/1.0 ' + 'x'.repeat(400) });
    const ua = db.sessions()[0]?.userAgent ?? '';
    assert.ok(ua.length <= 300 && !/[\u0000-\u001f]/.test(ua));
    const other = setup();
    await other.auth.register({ ...reg, phone: '07709999999' });
    assert.equal(other.db.sessions()[0]?.userAgent, null);
  });
});

describe('login (credential verification)', () => {
  it('logs in with the right password, in any phone format, and issues a NEW session token', async () => {
    const { db, auth } = setup();
    const r1 = await auth.register(reg);
    const r2 = await auth.login({ phone: '+964 770 123 4567', password: PASSWORD }, { userAgent: 'Second/2.0' });
    assert.equal(r2.user.id, r1.user.id);
    assert.equal(r2.user.phone, E164);
    assert.notEqual(r2.session.token, r1.session.token);
    assert.ok(isWellFormedToken(r2.session.token));
    assert.equal(db.sessions().length, 2);
    assert.ok(db.users()[0]?.lastLoginAt instanceof Date);
    assert.equal(db.users()[0]?.failedLogins, 0);
  });

  it('a wrong password is invalid_credentials and is counted', async () => {
    const { db, auth } = setup();
    await auth.register(reg);
    await assert.rejects(auth.login({ phone: reg.phone, password: 'wrong-password' }), authError('invalid_credentials'));
    assert.equal(db.users()[0]?.failedLogins, 1);
    assert.equal(db.sessions().length, 1, 'no session for a failed login');
  });

  it('an unknown account fails EXACTLY like a wrong password (same error, same shape)', async () => {
    const { auth } = setup();
    await auth.register(reg);
    const wrongPassword = await failureOf(auth.login({ phone: reg.phone, password: 'wrong-password' }));
    const unknownAccount = await failureOf(auth.login({ phone: '07700000000', password: 'wrong-password' }));
    assert.equal(shape(wrongPassword), shape(unknownAccount));
    assert.equal(wrongPassword.code, 'invalid_credentials');
  });

  it('every failure path performs exactly one argon2 verification, so timing does not reveal the account', async () => {
    const { db, calls, auth } = setup();
    const r = await auth.register(reg);
    const verifications = async (p: Promise<unknown>) => {
      const before = calls.verify;
      await p.catch(() => undefined);
      return calls.verify - before;
    };
    assert.equal(await verifications(auth.login({ phone: '07700000000', password: 'x-unknown' })), 1, 'unknown account');
    assert.equal(await verifications(auth.login({ phone: reg.phone, password: 'x-wrong' })), 1, 'wrong password');
    db.setStatus(r.user.id, 'pending');
    assert.equal(await verifications(auth.login({ phone: reg.phone, password: PASSWORD })), 1, 'correct password, inactive account');
    db.setStatus(r.user.id, 'active');
    for (let i = 0; i < LOGIN_MAX_FAILURES; i++) await auth.login({ phone: reg.phone, password: 'x-bad' }).catch(() => undefined);
    assert.equal(await verifications(auth.login({ phone: reg.phone, password: PASSWORD })), 1, 'locked account');
  });

  it('the dummy hash used for unknown/locked accounts is computed once, not per request', async () => {
    const { calls, auth } = setup();
    const hashesAfterSetup = calls.hash;
    for (let i = 0; i < 5; i++) await auth.login({ phone: `0770000000${i}`, password: 'whatever' }).catch(() => undefined);
    assert.equal(calls.hash - hashesAfterSetup, 1);
  });

  it('locks the account after the configured consecutive failures; while locked even the right password fails, generically', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    for (let i = 0; i < LOGIN_MAX_FAILURES; i++) await assert.rejects(auth.login({ phone: reg.phone, password: 'bad-' + i }), authError('invalid_credentials'));
    assert.equal(db.users()[0]?.locked, true);
    const lockedFailure = await failureOf(auth.login({ phone: reg.phone, password: PASSWORD }));
    const wrongFailure = await failureOf(auth.login({ phone: reg.phone, password: 'wrong' }));
    assert.equal(shape(lockedFailure), shape(wrongFailure), 'a locked account is indistinguishable from a wrong password');
    assert.equal(db.users()[0]?.failedLogins, LOGIN_MAX_FAILURES, 'attempts during the lock are not counted');
    db.unlock(r.user.id);
    const ok = await auth.login({ phone: reg.phone, password: PASSWORD });
    assert.equal(ok.user.id, r.user.id);
    assert.equal(db.users()[0]?.failedLogins, 0, 'a successful login resets the counter');
  });

  it('failures below the threshold never lock, and a success in between resets the count', async () => {
    const { db, auth } = setup();
    await auth.register(reg);
    for (let i = 0; i < LOGIN_MAX_FAILURES - 1; i++) await auth.login({ phone: reg.phone, password: 'bad' }).catch(() => undefined);
    assert.equal(db.users()[0]?.locked, false);
    await auth.login({ phone: reg.phone, password: PASSWORD });
    for (let i = 0; i < LOGIN_MAX_FAILURES - 1; i++) await auth.login({ phone: reg.phone, password: 'bad' }).catch(() => undefined);
    assert.equal(db.users()[0]?.locked, false);
  });

  it('an account that may not sign in (pending/suspended) gets the same generic failure, and no session', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    for (const status of ['pending', 'suspended']) {
      db.setStatus(r.user.id, status);
      const e = await failureOf(auth.login({ phone: reg.phone, password: PASSWORD }));
      assert.equal(e.code, 'invalid_credentials');
    }
    assert.equal(db.sessions().filter((s) => s.revokedAt === null).length, 0);
  });

  it('malformed login input is a validation failure with no lookup and no hashing', async () => {
    const { db, calls, auth } = setup();
    const before = calls.verify;
    for (const body of [null, {}, { phone: 'abc', password: 'x' }, { phone: reg.phone }, { password: 'x' }, { phone: reg.phone, password: 'x'.repeat(129) }, { phone: reg.phone, password: 'x', role: 'admin' }]) {
      await assert.rejects(auth.login(body), authError('validation_failed'));
    }
    assert.equal(db.counters.findCredentials, 0);
    assert.equal(calls.verify, before);
  });

  it('the login result never contains the password, the hash or counters', async () => {
    const { auth } = setup();
    await auth.register(reg);
    const text = JSON.stringify(await auth.login({ phone: reg.phone, password: PASSWORD }));
    assert.ok(!text.includes(PASSWORD) && !text.includes('$argon2') && !/password|hash|failed|locked/i.test(text));
  });
});

describe('sessions: validation and logout', () => {
  it('authenticates a valid token and returns the public user', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    const me = await auth.authenticate(r.session.token);
    assert.deepEqual(me?.user, r.user);
    assert.equal(me?.sessionId, db.sessions()[0]?.id);
    assert.ok(!JSON.stringify(me).includes('$argon2'));
  });

  it('rejects malformed tokens without touching the database', async () => {
    const { db, auth } = setup();
    for (const token of [undefined, '', 'abc', 'nsj_short', 'nsj_' + 'x'.repeat(44), 'Bearer nsj_' + 'a'.repeat(43), 'xxx_' + 'a'.repeat(43), 'nsj_' + 'a'.repeat(42) + '!']) {
      assert.equal(await auth.authenticate(token), null, String(token));
    }
    assert.equal(db.counters.findActive, 0);
  });

  it('rejects a well-formed but unknown token', async () => {
    const { auth } = setup();
    await auth.register(reg);
    assert.equal(await auth.authenticate('nsj_' + 'A'.repeat(43)), null);
  });

  it('rejects an expired session', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    db.expireAllSessions();
    assert.equal(await auth.authenticate(r.session.token), null);
  });

  it('rejects the session of a suspended user, whose sessions are revoked', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    db.setStatus(r.user.id, 'suspended');
    assert.equal(await auth.authenticate(r.session.token), null);
  });

  it('logout revokes only that session: the token stops working, other sessions of the same user keep working', async () => {
    const { db, auth } = setup();
    const a = await auth.register(reg);
    const b = await auth.login({ phone: reg.phone, password: PASSWORD });
    await auth.logout(a.session.token);
    assert.equal(await auth.authenticate(a.session.token), null);
    assert.ok(await auth.authenticate(b.session.token));
    const revoked = db.sessions().find((s) => s.revokedAt !== null);
    assert.equal(revoked?.revokedReason, 'logout');
  });

  it('logout is idempotent and silent for unknown or malformed tokens', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    await auth.logout(r.session.token);
    await auth.logout(r.session.token);
    await auth.logout('nsj_' + 'B'.repeat(43));
    await auth.logout('garbage');
    await auth.logout(undefined);
    assert.equal(db.counters.revoke, 3, 'malformed tokens never reach the database');
  });

  it('a failed last_used_at update does not fail an otherwise valid request', async () => {
    const { db, auth } = setup();
    const r = await auth.register(reg);
    db.store.sessions.touch = async () => {
      throw new Error('bookkeeping failure');
    };
    assert.ok(await auth.authenticate(r.session.token));
  });
});

describe('confidentiality of logs and non-enumeration across the whole flow', () => {
  it('logs contain only event names and user ids: no password, hash, token or phone', async () => {
    const { log, auth } = setup();
    const r = await auth.register(reg);
    await auth.login({ phone: reg.phone, password: 'wrong-password-123' }).catch(() => undefined);
    await auth.login({ phone: '07700000000', password: 'unknown-account-pw' }).catch(() => undefined);
    const ok = await auth.login({ phone: reg.phone, password: PASSWORD });
    await auth.authenticate(ok.session.token);
    await auth.logout(ok.session.token);
    await auth.register(reg).catch(() => undefined);
    const text = log.text();
    for (const secret of [PASSWORD, 'wrong-password-123', 'unknown-account-pw', r.session.token, ok.session.token, '$argon2', '9647701234567', '07701234567', '07700000000', 'علي']) {
      assert.ok(!text.includes(secret), `the log must not contain ${secret}`);
    }
    assert.ok(text.includes('auth.registered') && text.includes('auth.login.failed') && text.includes('auth.login.success'));
  });

  it('no AuthError ever carries the password, a phone number or a hash', async () => {
    const { auth } = setup();
    await auth.register(reg);
    const errors = await Promise.all([
      failureOf(auth.login({ phone: reg.phone, password: 'wrong-password-123' })),
      failureOf(auth.login({ phone: '07700000000', password: 'unknown-account-pw' })),
      failureOf(auth.register(reg)),
      failureOf(auth.register({ name: 'x', phone: 'y', password: 'z' })),
    ]);
    for (const e of errors) {
      const text = JSON.stringify({ message: e.message, fields: e.fields, stack: undefined });
      for (const secret of ['wrong-password-123', 'unknown-account-pw', '9647701234567', '$argon2']) assert.ok(!text.includes(secret));
    }
  });
});

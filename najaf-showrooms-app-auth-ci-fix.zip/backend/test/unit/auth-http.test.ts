// HTTP contract of the authentication routes. The pure helpers always run; the Fastify tests need `fastify`
// (installed in CI) and are SKIPPED visibly when it is missing, never silently passed.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { bearerToken, isJsonContentType, registerAuthRoutes, toAuthHttp } from '../../src/auth/routes.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AuthApi, AuthResult } from '../../src/auth/types.ts';

const TOKEN = 'nsj_' + 'A'.repeat(43);
const user = { id: '7', name: 'علي حسين', phone: '+9647701234567', role: 'user', status: 'active', createdAt: '2026-01-02T03:04:05.000Z' };
const grant: AuthResult = { user, session: { token: TOKEN, expiresAt: '2026-02-01T00:00:00.000Z' } };

describe('bearerToken', () => {
  it('extracts exactly one token from a well-formed header', () => {
    assert.equal(bearerToken(`Bearer ${TOKEN}`), TOKEN);
    assert.equal(bearerToken(`bearer ${TOKEN}`), TOKEN);
    assert.equal(bearerToken(`BEARER ${TOKEN}`), TOKEN);
  });
  it('returns undefined for everything else', () => {
    for (const h of [undefined, null, 5, '', 'Bearer', 'Bearer ', `Bearer  ${TOKEN}`, `Bearer ${TOKEN} extra`, `Basic ${TOKEN}`, TOKEN, ` Bearer ${TOKEN}`, [`Bearer ${TOKEN}`], `Bearer ${TOKEN}\n`]) {
      assert.equal(bearerToken(h), undefined, String(h));
    }
  });
});

describe('toAuthHttp: fixed status and generic message per error code', () => {
  it('maps every AuthError', () => {
    assert.deepEqual(toAuthHttp(new AuthError('conflict')), { status: 409, code: 'conflict', message: 'This account cannot be registered' });
    assert.deepEqual(toAuthHttp(new AuthError('invalid_credentials')), { status: 401, code: 'invalid_credentials', message: 'Invalid phone number or password' });
    assert.deepEqual(toAuthHttp(new AuthError('unauthorized')), { status: 401, code: 'unauthorized', message: 'Authentication required' });
    assert.deepEqual(toAuthHttp(new AuthError('validation_failed', [{ field: 'name', code: 'too_short' }])), { status: 400, code: 'validation_failed', message: 'The submitted data is not valid', fields: [{ field: 'name', code: 'too_short' }] });
  });
  it('ignores errors that are not AuthErrors (the global handler deals with them)', () => {
    for (const e of [new Error('boom'), 'x', null, { code: 'conflict' }]) assert.equal(toAuthHttp(e), undefined);
  });
});

describe('isJsonContentType', () => {
  it('accepts application/json with or without parameters, any case', () => {
    for (const ct of ['application/json', 'application/json; charset=utf-8', 'application/json;charset=UTF-8', 'APPLICATION/JSON', ' application/json ', 'application/json ; charset=utf-8']) assert.equal(isJsonContentType(ct), true, ct);
  });
  it('rejects everything else, including the types Fastify would otherwise parse (text/plain)', () => {
    for (const ct of ['text/plain', 'text/plain; charset=utf-8', 'text/json', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x', 'application/vnd.api+json', 'application/jsonx', 'application/json/x', 'application/xml', '', undefined, null, 5, ['application/json']]) {
      assert.equal(isJsonContentType(ct), false, String(ct));
    }
  });
});

// A minimal stand-in for the Fastify instance: it records the routes and hooks the plugin registers, so the wiring is
// verified here without Fastify. (The same behavior is verified end to end through real Fastify in the tests below, in CI.)
type RouteOpts = { bodyLimit?: number; onRequest?: (request: unknown, reply: unknown) => Promise<unknown> };
function recordRoutes() {
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined });
  };
  const app = { get: add('GET'), post: add('POST') };
  registerAuthRoutes(app as never, { auth: fakeAuthApi() });
  return routes;
}
function fakeAuthApi(): AuthApi {
  return { register: async () => grant, login: async () => grant, authenticate: async () => null, logout: async () => {} };
}
function fakeReply() {
  const sent: { status?: number; body?: unknown } = {};
  const reply = { code: (n: number) => ((sent.status = n), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

describe('authentication routes: registration of routes and the JSON-only hook (no Fastify needed)', () => {
  it('registers exactly the four routes', () => {
    assert.deepEqual(recordRoutes().map((r) => `${r.method} ${r.path}`).sort(), ['GET /v1/auth/me', 'POST /v1/auth/login', 'POST /v1/auth/logout', 'POST /v1/auth/register']);
  });

  it('the two routes that take a body carry a 4 KiB limit and the JSON-only hook; the bodiless routes do not need it', () => {
    const byPath = Object.fromEntries(recordRoutes().map((r) => [r.path, r.opts]));
    for (const path of ['/v1/auth/register', '/v1/auth/login']) {
      assert.equal(byPath[path]?.bodyLimit, 4096, path);
      assert.equal(typeof byPath[path]?.onRequest, 'function', path);
    }
    assert.equal(byPath['/v1/auth/me'], undefined);
    assert.equal(byPath['/v1/auth/logout'], undefined);
  });

  it('the hook answers 415 with a generic body for every non-JSON content type, without touching anything else', async () => {
    const hook = recordRoutes().find((r) => r.path === '/v1/auth/register')?.opts?.onRequest as NonNullable<RouteOpts['onRequest']>;
    for (const ct of ['text/plain', 'text/plain; charset=utf-8', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x', 'application/vnd.api+json', 'text/json']) {
      const { reply, sent } = fakeReply();
      const out = await hook({ headers: { 'content-type': ct }, id: 'req-1' }, reply);
      assert.equal(out, reply, `the hook must return the reply to end the request (${ct})`);
      assert.equal(sent.status, 415, ct);
      assert.deepEqual(sent.body, { error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: 'req-1' } });
    }
  });

  it('the hook lets application/json (with or without charset) and a request with no content type continue', async () => {
    for (const path of ['/v1/auth/register', '/v1/auth/login']) {
      const hook = recordRoutes().find((r) => r.path === path)?.opts?.onRequest as NonNullable<RouteOpts['onRequest']>;
      for (const headers of [{ 'content-type': 'application/json' }, { 'content-type': 'application/json; charset=utf-8' }, {}]) {
        const { reply, sent } = fakeReply();
        assert.equal(await hook({ headers, id: 'r' }, reply), undefined, JSON.stringify(headers));
        assert.equal(sent.status, undefined, 'a request that may continue must not be answered by the hook');
      }
    }
  });
});

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let reason: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'silent', NODE_ENV: 'test' });
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };

function fakeAuth(over: Partial<AuthApi> = {}): AuthApi {
  return {
    register: async () => grant,
    login: async () => grant,
    authenticate: async (t) => (t === TOKEN ? { user, sessionId: 's1' } : null),
    logout: async () => {},
    ...over,
  };
}
const json = { 'content-type': 'application/json' };

describe('authentication routes over HTTP', { skip: reason }, () => {
  it('are absent when no AuthApi is supplied (existing behavior is untouched)', async () => {
    const app = await buildServer!({ config, db: okDb });
    assert.equal((await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: '{}' })).statusCode, 404);
    assert.equal((await app.inject({ method: 'GET', url: '/healthz' })).statusCode, 200);
    await app.close();
  });

  it('POST /v1/auth/register: 201 with the user and the session grant', async () => {
    const seen: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async (i, c) => (seen.push(i, c), grant) }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: { ...json, 'user-agent': 'UA/1' }, payload: JSON.stringify({ name: 'علي حسين', phone: '07701234567', password: 'secret1' }) });
    assert.equal(r.statusCode, 201);
    assert.deepEqual(r.json(), grant);
    assert.deepEqual(seen, [{ name: 'علي حسين', phone: '07701234567', password: 'secret1' }, { userAgent: 'UA/1' }]);
    assert.equal(r.headers['cache-control'], 'no-store');
    await app.close();
  });

  it('POST /v1/auth/login: 200, and 401 with the generic body for a failure', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ login: async (i) => { if ((i as { password?: string }).password === 'bad') throw new AuthError('invalid_credentials'); return grant; } }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: '07701234567', password: 'good' }) });
    assert.equal(ok.statusCode, 200);
    const bad = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: '07701234567', password: 'bad' }) });
    assert.equal(bad.statusCode, 401);
    const body = bad.json() as { error: { code: string; message: string; requestId: string } };
    assert.deepEqual(Object.keys(body.error).sort(), ['code', 'message', 'requestId']);
    assert.equal(body.error.code, 'invalid_credentials');
    assert.equal(body.error.requestId, bad.headers['x-request-id']);
    await app.close();
  });

  it('validation errors are 400 with field names and codes only', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => { throw new AuthError('validation_failed', [{ field: 'name', code: 'too_short' }]); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'x', phone: '1', password: 'TopSecretValue!' }) });
    assert.equal(r.statusCode, 400);
    assert.deepEqual((r.json() as { error: { fields: unknown } }).error.fields, [{ field: 'name', code: 'too_short' }]);
    assert.ok(!r.body.includes('TopSecretValue!'));
    await app.close();
  });

  it('a duplicate account is a generic 409', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => { throw new AuthError('conflict'); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: '{}' });
    assert.equal(r.statusCode, 409);
    assert.equal((r.json() as { error: { code: string } }).error.code, 'conflict');
    await app.close();
  });

  it('GET /v1/auth/me: 200 with the public user for a valid Bearer token; 401 + WWW-Authenticate otherwise', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth() });
    const ok = await app.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${TOKEN}` } });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { user });
    const rejected: Array<Record<string, string>> = [{}, { authorization: 'Bearer nsj_' + 'B'.repeat(43) }, { authorization: 'Bearer garbage' }, { authorization: `Basic ${TOKEN}` }, { authorization: TOKEN }];
    for (const headers of rejected) {
      const r = await app.inject({ method: 'GET', url: '/v1/auth/me', headers });
      assert.equal(r.statusCode, 401, JSON.stringify(headers));
      assert.equal(r.headers['www-authenticate'], 'Bearer');
      assert.equal((r.json() as { error: { code: string } }).error.code, 'unauthorized');
    }
    await app.close();
  });

  it('POST /v1/auth/logout: 204 for a Bearer token, 401 without one', async () => {
    const revoked: Array<string | undefined> = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ logout: async (t) => void revoked.push(t) }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/logout', headers: { authorization: `Bearer ${TOKEN}` } });
    assert.equal(ok.statusCode, 204);
    assert.equal(ok.body, '');
    assert.deepEqual(revoked, [TOKEN]);
    assert.equal((await app.inject({ method: 'POST', url: '/v1/auth/logout' })).statusCode, 401);
    assert.deepEqual(revoked, [TOKEN], 'no token, no revocation attempt');
    await app.close();
  });

  it('malformed JSON, a non-JSON content type and an oversized body are rejected generically before the service runs', async () => {
    let called = 0;
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => (called++, grant) }) });
    const badJson = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: '{"name":' });
    assert.equal(badJson.statusCode, 400);
    assert.equal((badJson.json() as { error: { message: string } }).error.message, 'Bad request');
    // Fastify parses text/plain by default; these endpoints must refuse it (415) before the body is read or the service runs
    for (const url of ['/v1/auth/register', '/v1/auth/login']) {
      for (const contentType of ['text/plain', 'text/plain; charset=utf-8', 'application/x-www-form-urlencoded']) {
        const wrong = await app.inject({ method: 'POST', url, headers: { 'content-type': contentType }, payload: 'name=x&password=y' });
        assert.equal(wrong.statusCode, 415, `${url} ${contentType}`);
        const body = wrong.json() as { error: { code: string; message: string; requestId: string } };
        assert.equal(body.error.code, 'unsupported_media_type');
        assert.equal(body.error.requestId, wrong.headers['x-request-id']);
        assert.ok(!wrong.body.includes('password'), 'the refusal must not echo the body');
      }
    }
    const jsonOk = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: { 'content-type': 'application/json; charset=utf-8' }, payload: '{}' });
    assert.equal(jsonOk.statusCode, 201, 'application/json with a charset is still accepted');
    assert.equal(called, 1);
    called = 0;
    const big = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'x'.repeat(10_000) }) });
    assert.equal(big.statusCode, 413);
    assert.equal(called, 0);
    await app.close();
  });

  it('an unexpected service failure is an opaque 500: no message, no stack', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ login: async () => { throw new Error('secret failure at /srv/app/auth.ts password=hunter2'); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: '{}' });
    assert.equal(r.statusCode, 500);
    assert.ok(!r.body.includes('hunter2') && !r.body.includes('/srv/app'));
    assert.equal((r.json() as { error: { code: string } }).error.code, 'internal_error');
    await app.close();
  });
});

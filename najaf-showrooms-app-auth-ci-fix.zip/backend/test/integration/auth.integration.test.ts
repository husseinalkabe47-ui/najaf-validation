// Authentication against a real PostgreSQL 16 (migrations 0001-0013 applied) with REAL argon2id, through the application
// role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY).
// The suite is skipped visibly when they are missing, or when the `argon2` package is not installed.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { hashSessionToken } from '../../src/auth/tokens.ts';
import { AuthError } from '../../src/auth/types.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { recordingLogger } from '../helpers/fake-auth.ts';
import { assertArgon2idPolicy } from '../helpers/phc.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Integration-Passw0rd!';
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);

describe('authentication on PostgreSQL 16 with real argon2id', { skip: skip || argon2Missing }, () => {
  let app: Db;
  let admin: Db;
  const log = recordingLogger();
  let auth: ReturnType<typeof createAuthService>;

  const one = async (sql: string, params: unknown[] = []): Promise<Record<string, unknown>> => {
    const r = await admin.query(sql, params);
    assert.equal(r.rows.length, 1, `expected exactly one row for: ${sql.slice(0, 70)}`);
    return r.rows[0] as Record<string, unknown>;
  };
  const userRow = (phone: string) => one('SELECT id, role, status, password_hash, phone_verified_at, failed_logins, locked_until, last_login_at FROM users WHERE phone_e164 = $1', [phone]);
  const failure = async (p: Promise<unknown>): Promise<AuthError> => {
    try {
      await p;
    } catch (e) {
      assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
      return e;
    }
    throw new Error('expected a failure');
  };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    auth = createAuthService({ store: createPgAuthStore(app), hasher, logger: log.logger });
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  it('registers a regular active user with an argon2id hash (m=19456, t=2, p=1) and an unverified phone', async () => {
    const phone = newPhone();
    const r = await auth.register({ name: 'اختبار تكامل', phone: local(phone), password: PW }, { userAgent: 'it-suite/1.0' });
    assert.equal(r.user.phone, phone);
    assert.equal(r.user.role, 'user');
    assert.equal(r.user.status, 'active');
    const row = await userRow(phone);
    assert.equal(row['role'], 'user');
    assert.equal(row['status'], 'active');
    assertArgon2idPolicy(String(row['password_hash'])); // argon2id, v=19, m=19456, t=2, p=1 in ANY serialization order
    assert.ok(!String(row['password_hash']).includes(PW));
    assert.equal(row['phone_verified_at'], null);
    assert.equal(row['failed_logins'], 0);
  });

  it('never returns the password or the hash, and the session row holds only the SHA-256 of the token', async () => {
    const phone = newPhone();
    const r = await auth.register({ name: 'اختبار السرية', phone, password: PW });
    const text = JSON.stringify(r);
    assert.ok(!text.includes(PW) && !text.includes('$argon2') && !/password|hash/i.test(text));
    const uid = (await userRow(phone))['id'];
    const s = await one(`SELECT encode(token_hash, 'hex') AS hex, octet_length(token_hash) AS len, family_id IS NOT NULL AS has_family,
                                expires_at > now() + interval '29 days' AS long_enough, expires_at < now() + interval '31 days' AS bounded,
                                revoked_at, s::text AS whole_row FROM sessions s WHERE user_id = $1`, [uid]);
    assert.equal(s['len'], 32);
    assert.equal(s['hex'], hashSessionToken(r.session.token).toString('hex'));
    assert.equal(s['has_family'], true);
    assert.equal(s['long_enough'], true);
    assert.equal(s['bounded'], true);
    assert.equal(s['revoked_at'], null);
    assert.ok(!String(s['whole_row']).includes(r.session.token), 'the raw token must not be stored');
  });

  it('a duplicate account is a generic conflict and creates nothing, in any phone format', async () => {
    const phone = newPhone();
    await auth.register({ name: 'مستخدم أول', phone, password: PW });
    for (const input of [phone, local(phone), phone.replace('+964', '00964')]) {
      const e = await failure(auth.register({ name: 'مستخدم ثانٍ', phone: input, password: PW }));
      assert.equal(e.code, 'conflict');
      assert.ok(!e.message.includes(phone.slice(4)));
    }
    assert.equal((await one('SELECT count(*)::int AS n FROM users WHERE phone_e164 = $1', [phone]))['n'], 1);
    assert.equal((await one('SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1', [phone]))['n'], 1);
  });

  it('concurrent registrations of one phone: exactly one succeeds, the rest are conflicts', async () => {
    const phone = newPhone();
    const results = await Promise.allSettled(Array.from({ length: 5 }, () => auth.register({ name: 'سباق التسجيل', phone, password: PW })));
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.equal(results.filter((x) => x.status === 'rejected' && (x.reason as AuthError).code === 'conflict').length, 4);
    assert.equal((await one('SELECT count(*)::int AS n FROM users WHERE phone_e164 = $1', [phone]))['n'], 1);
  });

  it('malformed input and role/status injection are rejected and create nothing', async () => {
    const phone = newPhone();
    for (const body of [{ name: 'ab', phone, password: PW }, { name: 'اسم صحيح', phone: 'bad', password: PW }, { name: 'اسم صحيح', phone, password: '123' }, { name: 'اسم صحيح', phone, password: PW, role: 'admin' }, { name: 'اسم صحيح', phone, password: PW, status: 'active' }, null, 'x']) {
      assert.equal((await failure(auth.register(body))).code, 'validation_failed');
    }
    assert.equal((await admin.query('SELECT 1 FROM users WHERE phone_e164 = $1', [phone])).rows.length, 0);
  });

  it('logs in with the right password: a new session, last_login_at set, failures reset', async () => {
    const phone = newPhone();
    const reg = await auth.register({ name: 'مستخدم الدخول', phone, password: PW });
    const login = await auth.login({ phone: local(phone), password: PW });
    assert.equal(login.user.id, reg.user.id);
    assert.notEqual(login.session.token, reg.session.token);
    const row = await userRow(phone);
    assert.notEqual(row['last_login_at'], null);
    assert.equal(row['failed_logins'], 0);
    assert.equal((await one('SELECT count(*)::int AS n FROM sessions WHERE user_id = $1', [row['id']]))['n'], 2);
  });

  it('a wrong password is invalid_credentials and is counted; an unknown account fails identically', async () => {
    const phone = newPhone();
    await auth.register({ name: 'مستخدم الفشل', phone, password: PW });
    const wrong = await failure(auth.login({ phone, password: 'wrong-password-1' }));
    const unknown = await failure(auth.login({ phone: newPhone(), password: 'wrong-password-1' }));
    assert.equal(JSON.stringify({ c: wrong.code, m: wrong.message, f: wrong.fields }), JSON.stringify({ c: unknown.code, m: unknown.message, f: unknown.fields }));
    assert.equal(wrong.code, 'invalid_credentials');
    assert.equal((await userRow(phone))['failed_logins'], 1);
  });

  it('locks after 5 consecutive failures; while locked the right password also fails generically; unlocking restores access', async () => {
    const phone = newPhone();
    await auth.register({ name: 'مستخدم القفل', phone, password: PW });
    for (let i = 0; i < 5; i++) assert.equal((await failure(auth.login({ phone, password: `bad-${i}-password` }))).code, 'invalid_credentials');
    let row = await userRow(phone);
    assert.equal(row['failed_logins'], 5);
    assert.ok(row['locked_until'] instanceof Date && row['locked_until'].getTime() > Date.now());
    const lockedFailure = await failure(auth.login({ phone, password: PW }));
    const wrongFailure = await failure(auth.login({ phone, password: 'wrong-again-1' }));
    assert.equal(lockedFailure.message, wrongFailure.message);
    assert.equal((await userRow(phone))['failed_logins'], 5, 'attempts during the lock are not counted');
    await admin.query(`UPDATE users SET locked_until = now() - interval '1 second' WHERE phone_e164 = $1`, [phone]);
    const ok = await auth.login({ phone, password: PW });
    assert.ok(ok.session.token);
    row = await userRow(phone);
    assert.equal(row['failed_logins'], 0);
    assert.equal(row['locked_until'], null);
  });

  it('authenticates a valid token, refreshes last_used_at only when stale, and rejects unknown or malformed tokens', async () => {
    const phone = newPhone();
    const r = await auth.register({ name: 'مستخدم الجلسة', phone, password: PW });
    const me = await auth.authenticate(r.session.token);
    assert.equal(me?.user.phone, phone);
    assert.ok(!JSON.stringify(me).includes('$argon2'));
    await admin.query(`UPDATE sessions SET last_used_at = now() - interval '5 minutes' WHERE id = $1`, [me?.sessionId]);
    await auth.authenticate(r.session.token);
    assert.equal((await one(`SELECT last_used_at > now() - interval '1 minute' AS fresh FROM sessions WHERE id = $1`, [me?.sessionId]))['fresh'], true);
    assert.equal(await auth.authenticate('nsj_' + 'Z'.repeat(43)), null);
    assert.equal(await auth.authenticate('garbage'), null);
    assert.equal(await auth.authenticate(undefined), null);
  });

  it('logout revokes exactly that session (reason logout) and is idempotent', async () => {
    const phone = newPhone();
    const a = await auth.register({ name: 'مستخدم الخروج', phone, password: PW });
    const b = await auth.login({ phone, password: PW });
    await auth.logout(a.session.token);
    await auth.logout(a.session.token);
    assert.equal(await auth.authenticate(a.session.token), null);
    assert.ok(await auth.authenticate(b.session.token));
    const revoked = await one(`SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 AND s.revoked_reason = 'logout'`, [phone]);
    assert.equal(revoked['n'], 1);
  });

  it('rejects an expired session', async () => {
    const phone = newPhone();
    const r = await auth.register({ name: 'مستخدم المنتهي', phone, password: PW });
    await admin.query(`UPDATE sessions SET created_at = now() - interval '3 days', expires_at = now() - interval '1 day' WHERE user_id = (SELECT id FROM users WHERE phone_e164 = $1)`, [phone]);
    assert.equal(await auth.authenticate(r.session.token), null);
  });

  it('suspension revokes sessions (database trigger) and blocks login, with the same generic failure', async () => {
    const phone = newPhone();
    const r = await auth.register({ name: 'مستخدم الإيقاف', phone, password: PW });
    await admin.query(`UPDATE users SET status = 'suspended' WHERE phone_e164 = $1`, [phone]);
    assert.equal(await auth.authenticate(r.session.token), null);
    assert.equal((await one(`SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 AND s.revoked_reason = 'user_suspended'`, [phone]))['n'], 1);
    assert.equal((await failure(auth.login({ phone, password: PW }))).code, 'invalid_credentials');
  });

  it('the application role cannot create an administrator through any path, including a hand-written insert', async () => {
    const hash = '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA';
    await assert.rejects(app.query(`INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير مزوّر', $1, 'admin', $2)`, [newPhone(), hash]), (e: unknown) => (e as { kind?: string }).kind === 'forbidden');
  });

  it('logs hold event names and ids only: no password, hash, token or phone', async () => {
    const text = log.text();
    assert.ok(text.includes('auth.registered') && text.includes('auth.login.failed') && text.includes('auth.login.success'));
    for (const secret of [PW, '$argon2', 'nsj_', ...created, ...created.map(local)]) assert.ok(!text.includes(secret), `the log must not contain ${secret}`);
  });
});

describe('authentication over HTTP on PostgreSQL 16', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });
  const json = { 'content-type': 'application/json' };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  it('register, me, login, logout, me again: the full cycle with no secret in any response', async () => {
    const server = await buildServer!({ config: config(), db: app, auth: createAuthService({ store: createPgAuthStore(app), hasher }) });
    const phone = newPhone();
    const reg = await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'مستخدم HTTP', phone: local(phone), password: PW }) });
    assert.equal(reg.statusCode, 201);
    const { user, session } = reg.json() as { user: { phone: string; role: string }; session: { token: string } };
    assert.equal(user.phone, phone);
    assert.equal(user.role, 'user');
    const me = await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${session.token}` } });
    assert.equal(me.statusCode, 200);
    const login = await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone, password: PW }) });
    assert.equal(login.statusCode, 200);
    const token2 = (login.json() as { session: { token: string } }).session.token;
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/logout', headers: { authorization: `Bearer ${token2}` } })).statusCode, 204);
    const after401 = await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${token2}` } });
    assert.equal(after401.statusCode, 401);
    assert.equal(after401.headers['www-authenticate'], 'Bearer');
    for (const r of [me, login, after401]) assert.ok(!r.body.includes(PW) && !r.body.includes('$argon2') && !/"password|"hash/i.test(r.body));
    await server.close();
  });

  it('failures are generic: a wrong password and an unknown account are the same 401 body', async () => {
    const server = await buildServer!({ config: config(), db: app, auth: createAuthService({ store: createPgAuthStore(app), hasher }) });
    const phone = newPhone();
    await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'مستخدم عام', phone, password: PW }) });
    const wrong = await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone, password: 'not-the-password' }) });
    const unknown = await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: newPhone(), password: 'not-the-password' }) });
    assert.equal(wrong.statusCode, 401);
    assert.equal(unknown.statusCode, 401);
    const strip = (b: string) => JSON.stringify({ ...(JSON.parse(b) as { error: object }).error, requestId: undefined });
    assert.equal(strip(wrong.body), strip(unknown.body));
    const dup = await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'مستخدم عام', phone, password: PW }) });
    assert.equal(dup.statusCode, 409);
    const bad = await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'x', phone: '1', password: '1', role: 'admin' }) });
    assert.equal(bad.statusCode, 400);
    await server.close();
  });
});

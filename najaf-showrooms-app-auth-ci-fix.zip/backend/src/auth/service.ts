// Authentication service: registration, credential verification (login), authentication of a session token, logout.
//
// Security properties (each one is covered by tests):
//  - Passwords exist only as an argon2id hash; they are never logged, returned, or placed in an error.
//  - Every login failure is the SAME error (AuthError 'invalid_credentials'): unknown phone, wrong password, locked account
//    and non-active account are indistinguishable, and each performs exactly one argon2 verification (a dummy hash when the
//    account is unknown or locked), so neither the response nor the timing reveals whether an account exists.
//  - role/status are never inputs: registration always creates an active regular user.
//  - Session tokens are random, shown once, and stored only as SHA-256.
import { randomBytes } from 'node:crypto';
import { DbError } from '../errors.ts';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import { USER_AGENT_MAX } from './policy.ts';
import type { PasswordHasher } from './password.ts';
import type { AuthStore, UserRow } from './repository.ts';
import { generateSessionToken, hashSessionToken, isWellFormedToken } from './tokens.ts';
import { AuthError } from './types.ts';
import type { AuthApi, AuthContext, AuthResult, AuthenticatedUser, PublicUser } from './types.ts';
import { parseLoginInput, parseRegisterInput } from './validation.ts';

export function toPublicUser(u: UserRow): PublicUser {
  // Built field by field on purpose: a spread of the row could leak a column added later.
  return { id: u.id, name: u.name, phone: u.phoneE164, role: u.role, status: u.status, createdAt: u.createdAt.toISOString() };
}

// eslint-disable-next-line no-control-regex
const NON_PRINTABLE = /[\u0000-\u001f\u007f-\u009f]/g;
function cleanUserAgent(ua: string | undefined): string | null {
  if (typeof ua !== 'string') return null;
  const cleaned = ua.replace(NON_PRINTABLE, '').trim().slice(0, USER_AGENT_MAX);
  return cleaned === '' ? null : cleaned;
}

export function createAuthService(deps: {
  store: AuthStore;
  hasher: PasswordHasher;
  logger?: Logger;
  randomBytes?: (bytes: number) => Buffer;
}): AuthApi {
  const { store, hasher } = deps;
  const logger = deps.logger ?? nullLogger;
  const rand = deps.randomBytes ?? randomBytes;

  // A real argon2 hash of a random value, computed once. Verifying against it costs the same as a real verification.
  let dummy: Promise<string> | undefined;
  const dummyHash = (): Promise<string> => (dummy ??= hasher.hash(rand(16).toString('hex')));

  async function register(input: unknown, ctx: AuthContext = {}): Promise<AuthResult> {
    const parsed = parseRegisterInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const { name, phone, password } = parsed.value;

    const passwordHash = await hasher.hash(password);
    const token = generateSessionToken(rand);
    try {
      const result = await store.transaction(async ({ users, sessions }) => {
        const user = await users.insert({ name, phoneE164: phone, passwordHash });
        const session = await sessions.create({ userId: user.id, tokenHash: hashSessionToken(token), userAgent: cleanUserAgent(ctx.userAgent) });
        return { user, session };
      });
      logger.info({ event: 'auth.registered', userId: result.user.id });
      return { user: toPublicUser(result.user), session: { token, expiresAt: result.session.expiresAt.toISOString() } };
    } catch (e) {
      // Race-safe: the unique index decides, never a prior SELECT. Nothing identifies which account collided.
      if (e instanceof DbError && e.kind === 'unique' && e.constraint === 'users_phone_active_uq') {
        logger.info({ event: 'auth.register.conflict' });
        throw new AuthError('conflict');
      }
      throw e;
    }
  }

  async function login(input: unknown, ctx: AuthContext = {}): Promise<AuthResult> {
    const parsed = parseLoginInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const { phone, password } = parsed.value;

    const cred = await store.users.findCredentialsByPhone(phone);

    if (!cred || cred.locked) {
      await hasher.verify(await dummyHash(), password); // same cost as a real verification; the result is discarded
      logger.info({ event: 'auth.login.failed', reason: cred ? 'locked' : 'unknown_account', ...(cred ? { userId: cred.id } : {}) });
      throw new AuthError('invalid_credentials');
    }

    const matches = await hasher.verify(cred.passwordHash, password);
    if (!matches) {
      await store.users.recordFailedLogin(cred.id);
      logger.info({ event: 'auth.login.failed', reason: 'bad_password', userId: cred.id });
      throw new AuthError('invalid_credentials');
    }
    if (cred.status !== 'active') {
      // Correct password but the account may not sign in (pending/suspended). Deliberately the same generic failure.
      logger.info({ event: 'auth.login.failed', reason: 'inactive', userId: cred.id });
      throw new AuthError('invalid_credentials');
    }

    const token = generateSessionToken(rand);
    const session = await store.transaction(async ({ users, sessions }) => {
      await users.recordSuccessfulLogin(cred.id);
      return sessions.create({ userId: cred.id, tokenHash: hashSessionToken(token), userAgent: cleanUserAgent(ctx.userAgent) });
    });
    logger.info({ event: 'auth.login.success', userId: cred.id });
    return { user: toPublicUser(cred), session: { token, expiresAt: session.expiresAt.toISOString() } };
  }

  async function authenticate(token: string | undefined): Promise<AuthenticatedUser | null> {
    if (!isWellFormedToken(token)) return null; // malformed: no database work at all
    const found = await store.sessions.findActive(hashSessionToken(token));
    if (!found) return null;
    try {
      await store.sessions.touch(found.sessionId);
    } catch {
      // last_used_at is bookkeeping; a failed touch must not fail an otherwise valid request
    }
    return { user: toPublicUser(found.user), sessionId: found.sessionId };
  }

  async function logout(token: string | undefined): Promise<void> {
    if (!isWellFormedToken(token)) return;
    const revoked = await store.sessions.revokeByTokenHash(hashSessionToken(token));
    if (revoked) logger.info({ event: 'auth.logout' });
  }

  return { register, login, authenticate, logout };
}

// HTTP contract for authentication (Phase 11.4, Step 1). Thin by design: the decisions live in service.ts and in the pure
// helpers below. This file imports Fastify TYPES only, so the helpers are unit-testable without Fastify installed.
//
//   POST /v1/auth/register   {name, phone, password}  -> 201 {user, session}
//   POST /v1/auth/login      {phone, password}        -> 200 {user, session}
//   GET  /v1/auth/me         Authorization: Bearer    -> 200 {user}
//   POST /v1/auth/logout     Authorization: Bearer    -> 204
//
// Errors use the project's body shape { error: { code, message, requestId, fields? } }. Messages are fixed and generic.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { FieldError } from './validation.ts';
import { AuthError } from './types.ts';
import type { AuthApi, AuthContext } from './types.ts';

export interface AuthHttpError {
  status: number;
  code: string;
  message: string;
  fields?: FieldError[];
}

export function toAuthHttp(e: unknown): AuthHttpError | undefined {
  if (!(e instanceof AuthError)) return undefined;
  switch (e.code) {
    case 'validation_failed':
      return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    case 'conflict':
      return { status: 409, code: e.code, message: e.message };
    case 'invalid_credentials':
    case 'unauthorized':
      return { status: 401, code: e.code, message: e.message };
  }
}

/** application/json, with optional parameters (e.g. charset), case-insensitive. Nothing else qualifies. */
export function isJsonContentType(value: unknown): boolean {
  return typeof value === 'string' && /^\s*application\/json\s*(;.*)?$/i.test(value);
}

// Fastify natively accepts BOTH application/json and text/plain. text/plain is a CORS "simple" content type (a cross-site
// page can send it without a preflight), and these endpoints take JSON only, so anything else is answered 415 here, in
// onRequest: before the body is read or parsed and before the service runs. (No content type at all: Fastify itself answers
// 415 when a body is present, and an empty body is a validation error.)
async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** "Bearer <token>" (scheme case-insensitive, exactly one token, no extra spaces); anything else is undefined. */
export function bearerToken(header: unknown): string | undefined {
  if (typeof header !== 'string') return undefined;
  const m = /^Bearer ([^\s]+)$/i.exec(header);
  return m ? (m[1] as string) : undefined;
}

const contextOf = (request: FastifyRequest): AuthContext => {
  const ua = request.headers['user-agent'];
  return { userAgent: typeof ua === 'string' ? ua : undefined };
};

export function registerAuthRoutes(app: FastifyInstance, deps: { auth: AuthApi }): void {
  const { auth } = deps;

  type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };
  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toAuthHttp(e);
    if (!mapped) throw e; // not an authentication error: the global error handler maps it (generic 4xx/5xx body)
    if (mapped.status === 401 && mapped.code === 'unauthorized') reply.header('www-authenticate', 'Bearer');
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  app.post('/v1/auth/register', { bodyLimit: 4096, onRequest: requireJsonBody }, async (request, reply) => {
    try {
      const result = await auth.register(request.body, contextOf(request));
      return reply.code(201).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/login', { bodyLimit: 4096, onRequest: requireJsonBody }, async (request, reply) => {
    try {
      const result = await auth.login(request.body, contextOf(request));
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/auth/me', async (request, reply) => {
    try {
      const found = await auth.authenticate(bearerToken(request.headers['authorization']));
      if (!found) throw new AuthError('unauthorized');
      return reply.code(200).send({ user: found.user });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/logout', async (request, reply) => {
    try {
      const token = bearerToken(request.headers['authorization']);
      if (!token) throw new AuthError('unauthorized');
      await auth.logout(token);
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

// Authentication policy constants (Phase 11.4, Step 1).
// Sources: the approved architecture (refresh token: 30 days absolute, 256-bit random; argon2id), the existing database
// limits (users.name >= 3 chars, app_settings limits.text: name 100, password 128) and the prototype rules (password >= 6).
// NOT in the approved plan, therefore PROPOSED and pending approval: the login lockout numbers and the password minimum.

/** argon2id parameters: OWASP minimum profile; identical to the PHC strings used throughout the database tests (m=19456,t=2,p=1). */
export const ARGON2 = { memoryCost: 19456, timeCost: 2, parallelism: 1 } as const;
export const ARGON2_PHC_PREFIX = '$argon2id$';

/** Opaque session token, stored only as SHA-256 in sessions.token_hash. */
export const SESSION_TOKEN_BYTES = 32;
/** Absolute lifetime (the approved refresh-token lifetime). In this step it is also what authenticates requests; see README. */
export const SESSION_TTL_SECONDS = 30 * 24 * 60 * 60;
/** sessions.last_used_at is refreshed at most this often (avoids a write per request). */
export const SESSION_TOUCH_INTERVAL_SECONDS = 60;

/** PROPOSED: consecutive failed logins before the account is locked, and for how long. */
export const LOGIN_MAX_FAILURES = 5;
export const LOGIN_LOCK_SECONDS = 15 * 60;

export const NAME_MIN = 3;
export const NAME_MAX = 100;
/** PROPOSED: matches the prototype (6); a production minimum of 8 is recommended. */
export const PASSWORD_MIN = 6;
export const PASSWORD_MAX = 128;
export const USER_AGENT_MAX = 300;
export const PHONE_INPUT_MAX = 32;

// PostgreSQL access for authentication. Every statement is parameterized (values are never interpolated into SQL), uses
// only columns/privileges the application role has (migrations 0012/0013), and never selects password_hash except in the
// single credentials lookup used by login. Time is the database clock (now()), so there is no clock skew.
import type { Db, Tx } from '../db.ts';
import { LOGIN_LOCK_SECONDS, LOGIN_MAX_FAILURES, SESSION_TOUCH_INTERVAL_SECONDS, SESSION_TTL_SECONDS } from './policy.ts';

export interface UserRow {
  id: string;
  name: string;
  phoneE164: string;
  role: string;
  status: string;
  createdAt: Date;
}
export interface CredentialRow extends UserRow {
  passwordHash: string;
  /** true while users.locked_until is in the future (decided by the database clock). */
  locked: boolean;
}
export interface ActiveSession {
  sessionId: string;
  lastUsedAt: Date;
  user: UserRow;
}

export interface UsersRepository {
  /** Inserts an ACTIVE regular user. role and status are NOT parameters: the database defaults ('user', 'active') apply. */
  insert(input: { name: string; phoneE164: string; passwordHash: string }): Promise<UserRow>;
  findCredentialsByPhone(phoneE164: string): Promise<CredentialRow | null>;
  recordFailedLogin(userId: string): Promise<void>;
  recordSuccessfulLogin(userId: string): Promise<void>;
}
export interface SessionsRepository {
  create(input: { userId: string; tokenHash: Buffer; userAgent: string | null }): Promise<{ sessionId: string; expiresAt: Date }>;
  findActive(tokenHash: Buffer): Promise<ActiveSession | null>;
  revokeByTokenHash(tokenHash: Buffer): Promise<boolean>;
  touch(sessionId: string): Promise<void>;
}
export interface AuthStore {
  users: UsersRepository;
  sessions: SessionsRepository;
  /** Runs fn in one database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { users: UsersRepository; sessions: SessionsRepository }) => Promise<T>): Promise<T>;
}

interface UserSqlRow {
  id: string;
  name: string;
  phone_e164: string;
  role: string;
  status: string;
  created_at: Date;
}
const toUserRow = (r: UserSqlRow): UserRow => ({ id: r.id, name: r.name, phoneE164: r.phone_e164, role: r.role, status: r.status, createdAt: r.created_at });

export function createPgUsersRepository(q: Tx): UsersRepository {
  return {
    async insert({ name, phoneE164, passwordHash }) {
      const r = await q.query<UserSqlRow>(
        `INSERT INTO users (name, phone_e164, password_hash)
         VALUES ($1, $2, $3)
         RETURNING id, name, phone_e164, role, status, created_at`,
        [name, phoneE164, passwordHash],
      );
      return toUserRow(r.rows[0] as UserSqlRow);
    },

    async findCredentialsByPhone(phoneE164) {
      const r = await q.query<UserSqlRow & { password_hash: string; locked: boolean }>(
        `SELECT id, name, phone_e164, role, status, created_at, password_hash,
                (locked_until IS NOT NULL AND locked_until > now()) AS locked
           FROM users
          WHERE phone_e164 = $1 AND deleted_at IS NULL`,
        [phoneE164],
      );
      const row = r.rows[0];
      return row ? { ...toUserRow(row), passwordHash: row.password_hash, locked: row.locked === true } : null;
    },

    async recordFailedLogin(userId) {
      // Atomic: concurrent failures cannot lose a count; the lock starts exactly when the threshold is reached.
      await q.query(
        `UPDATE users
            SET failed_logins = LEAST(failed_logins + 1, 100),
                locked_until = CASE WHEN failed_logins + 1 >= $2 THEN now() + make_interval(secs => $3) ELSE locked_until END
          WHERE id = $1`,
        [userId, LOGIN_MAX_FAILURES, LOGIN_LOCK_SECONDS],
      );
    },

    async recordSuccessfulLogin(userId) {
      await q.query(`UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now() WHERE id = $1`, [userId]);
    },
  };
}

export function createPgSessionsRepository(q: Tx): SessionsRepository {
  return {
    async create({ userId, tokenHash, userAgent }) {
      // family_id starts a new rotation family (used by the refresh step); expires_at is absolute.
      const r = await q.query<{ id: string; expires_at: Date }>(
        `INSERT INTO sessions (user_id, family_id, token_hash, expires_at, user_agent)
         VALUES ($1, gen_random_uuid(), $2, now() + make_interval(secs => $3), $4)
         RETURNING id, expires_at`,
        [userId, tokenHash, SESSION_TTL_SECONDS, userAgent],
      );
      const row = r.rows[0] as { id: string; expires_at: Date };
      return { sessionId: row.id, expiresAt: row.expires_at };
    },

    async findActive(tokenHash) {
      const r = await q.query<UserSqlRow & { session_id: string; last_used_at: Date }>(
        `SELECT s.id AS session_id, s.last_used_at,
                u.id, u.name, u.phone_e164, u.role, u.status, u.created_at
           FROM sessions s
           JOIN users u ON u.id = s.user_id
          WHERE s.token_hash = $1
            AND s.revoked_at IS NULL
            AND s.expires_at > now()
            AND u.deleted_at IS NULL
            AND u.status = 'active'`,
        [tokenHash],
      );
      const row = r.rows[0];
      return row ? { sessionId: row.session_id, lastUsedAt: row.last_used_at, user: toUserRow(row) } : null;
    },

    async revokeByTokenHash(tokenHash) {
      const r = await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'logout' WHERE token_hash = $1 AND revoked_at IS NULL`, [tokenHash]);
      return (r.rowCount ?? 0) > 0;
    },

    async touch(sessionId) {
      await q.query(`UPDATE sessions SET last_used_at = now() WHERE id = $1 AND last_used_at < now() - make_interval(secs => $2)`, [sessionId, SESSION_TOUCH_INTERVAL_SECONDS]);
    },
  };
}

export function createPgAuthStore(db: Db): AuthStore {
  return {
    users: createPgUsersRepository(db),
    sessions: createPgSessionsRepository(db),
    transaction: (fn) => db.tx((t) => fn({ users: createPgUsersRepository(t), sessions: createPgSessionsRepository(t) })),
  };
}

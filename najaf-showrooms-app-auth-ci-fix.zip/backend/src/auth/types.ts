import type { FieldError } from './validation.ts';

/** The ONLY user shape that ever leaves the service. It is built field by field: no password, no hash, no counters. */
export interface PublicUser {
  /** bigint identity, as a decimal string (safe for any JSON client). */
  id: string;
  name: string;
  /** Canonical E.164 (+9647XXXXXXXXX). */
  phone: string;
  role: string;
  status: string;
  /** ISO-8601 UTC. */
  createdAt: string;
}

export interface SessionGrant {
  /** Shown once. Only its SHA-256 is stored. */
  token: string;
  expiresAt: string;
}

export interface AuthResult {
  user: PublicUser;
  session: SessionGrant;
}

export interface AuthenticatedUser {
  user: PublicUser;
  sessionId: string;
}

export interface AuthContext {
  userAgent?: string | undefined;
}

export type AuthErrorCode = 'validation_failed' | 'conflict' | 'invalid_credentials' | 'unauthorized';

// Fixed, generic messages: nothing here can reveal whether an account exists, why a login failed, or what was submitted.
const MESSAGES: Record<AuthErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  conflict: 'This account cannot be registered',
  invalid_credentials: 'Invalid phone number or password',
  unauthorized: 'Authentication required',
};

export class AuthError extends Error {
  readonly code: AuthErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: AuthErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'AuthError';
    this.code = code;
    this.fields = fields;
  }
}

/** What the HTTP layer needs from the authentication service. */
export interface AuthApi {
  register(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  login(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  authenticate(token: string | undefined): Promise<AuthenticatedUser | null>;
  logout(token: string | undefined): Promise<void>;
}

// Thin HTTP layer (Fastify). All decisions live in dependency-free modules (health.ts, http-errors.ts);
// this file only wires them. Phase 11.4.1 exposes health endpoints only: no business routes, no auth yet.
import { randomUUID } from 'node:crypto';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import type { AppConfig } from './config.ts';
import type { Db } from './db.ts';
import { livenessReport, readinessReport } from './health.ts';
import { toHttpError } from './http-errors.ts';
import { registerAuthRoutes } from './auth/routes.ts';
import type { AuthApi } from './auth/types.ts';

const REQUEST_ID = /^[A-Za-z0-9._-]{8,64}$/;

export async function buildServer(deps: { config: AppConfig; db: Pick<Db, 'ping' | 'checkSchema'>; auth?: AuthApi }): Promise<FastifyInstance> {
  const { config, db } = deps;
  const app = Fastify({
    logger: {
      level: config.server.logLevel,
      redact: { paths: ['req.headers.authorization', 'req.headers.cookie', 'res.headers["set-cookie"]'], censor: '[redacted]' },
    },
    // Accept a well-formed incoming id for tracing, otherwise generate one (never trust arbitrary header content).
    genReqId: (req) => {
      const h = req.headers['x-request-id'];
      return typeof h === 'string' && REQUEST_ID.test(h) ? h : randomUUID();
    },
  });

  app.addHook('onSend', async (request, reply, payload) => {
    reply.header('x-request-id', request.id);
    reply.header('cache-control', 'no-store');
    reply.header('x-content-type-options', 'nosniff');
    return payload;
  });

  app.get('/healthz', async () => livenessReport());

  app.get('/readyz', async (request, reply) => {
    const r = await readinessReport({ db, logger: request.log });
    return reply.code(r.ready ? 200 : 503).send({ status: r.ready ? 'ready' : 'not_ready', checks: r.checks });
  });

  // Authentication routes exist only when an AuthApi is supplied (existing callers and tests are unaffected).
  if (deps.auth) registerAuthRoutes(app, { auth: deps.auth });

  app.setNotFoundHandler((request, reply) => {
    const e = toHttpError({ statusCode: 404 });
    return reply.code(e.status).send({ error: { code: e.code, message: e.message, requestId: request.id } });
  });

  app.setErrorHandler((error, request, reply) => {
    const e = toHttpError(error);
    // Full detail (including the stack) stays in the server log; the client gets the generic mapped body only.
    if (e.status >= 500) request.log.error({ err: error }, 'request failed');
    else request.log.warn({ code: e.code }, 'request rejected');
    return reply.code(e.status).send({ error: { code: e.code, message: e.message, requestId: request.id } });
  });

  return app;
}

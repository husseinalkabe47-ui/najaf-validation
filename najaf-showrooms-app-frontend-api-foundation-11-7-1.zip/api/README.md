# عميل الخلفية (المرحلة 11.7.1)

`api/apiClient.js` هو الطبقة الوحيدة المخصّصة للاتصال بالخلفية. **لم تُربط به أي شاشة بعد، ولم يُضف إلى `index.html`**
(الربط وتحميل السكربت في 11.7.2)، فسلوك التطبيق الحالي (بيانات تجريبية محلية في `localStorage`) لم يتغيّر.
الفصل: لا يستورد العميل ولا يلمس `AppStorage` أو أي Repository أو Service محلي، ولا يخزّن شيئًا في المتصفح.

## الإعداد
| الإعداد | الطريقة | ملاحظات |
|---|---|---|
| عنوان الخلفية | `<meta name="najaf-api-base-url" content="https://api.example.com">` في `index.html` (يُضاف عند الربط)، أو `window.NAJAF_API_BASE_URL`، أو الخيار `baseUrl` في `ApiClient.create` | يقبل `http(s)://host[/prefix]` أو مسارًا نسبيًا يبدأ بـ `/` (خلف وكيل عكسي). يُرفض: بيانات اعتماد في الرابط، استعلام، `#`، `//host`، أي بروتوكول آخر. **فارغ = الخلفية غير مفعّلة** (`fromEnvironment()` تعيد `null`، وضع التجربة المحلي). |
| المهلة | الخيار `timeoutMs` (افتراضي 15000، الحد الأعلى 120000) أو `timeoutMs` لكل طلب | تشمل قراءة الجسم. |
| `fetch` / `now` / `setTimeout` / `AbortController` | خيارات حقن (للاختبار) | الافتراضي الدوال العامة للمتصفح. |
| مخزن الرموز | الخيار `tokenStore {get,set,clear}` | الافتراضي: **ذاكرة فقط** (تُفقد عند إعادة تحميل الصفحة، لا `localStorage`). |
| `onAuthLost(reason)` | خيار | يُستدعى عند فقدان الجلسة نهائيًا: `expired` أو `refresh_rejected`. |

لا يوجد في الخلفية الحالية CORS (`backend/src`)؛ لذا يلزم نشر الواجهة والخلفية على الأصل نفسه (أو وكيل عكسي) وإلا منع المتصفح الطلبات. لم يُغيَّر شيء في الخلفية.

## الاستعمال
```js
const api = ApiClient.fromEnvironment();          // null إن لم تُهيَّأ الخلفية
await api.get('/v1/public/cars', { auth: 'none', query: { page: 1 } });
await api.post('/v1/me/favorites', { carId }, {});   // auth:'required' افتراضيًا
api.setSession(sessionFromServer);                 // 11.7.2 بعد تسجيل الدخول
```
`auth`: `'required'` (افتراضي: بلا جلسة → خطأ دون اتصال) | `'optional'` | `'none'` (لا يُرسل رمزًا أبدًا).
المسار يجب أن يبدأ بـ `/` (الروابط المطلقة مرفوضة كي لا يصل الرمز إلى مضيف آخر).

## الأخطاء
كل فشل هو `ApiError`: `kind` (`network` | `timeout` | `aborted` | `http` | `invalid_response` | `config` | `auth`)، `status`، `code` (من `error.code` في الخادم)،
`fields`، `requestId`، `retryAfterSeconds` (من `Retry-After` بالثواني فقط)، `messageAr` (رسالة عربية عامة للواجهة)، و`serverMessage` للتشخيص.
لا يحوي أي رمز أو رابط أو جسم طلب.

## المصادقة (بعقد الخلفية الموجود، بلا اختراع)
- الترويسة `Authorization: Bearer <accessToken>`؛ الجلسة `{accessToken, accessExpiresAt, refreshToken, refreshExpiresAt}`.
- قبل الإرسال: إن اقترب رمز الوصول من الانتهاء (30 ثانية) يُستدعى `POST /v1/auth/refresh {refreshToken}` ثم يُخزَّن الزوج الجديد (الرمز يُدوَّر).
- عند 401: تجديد ثم **إعادة واحدة** للطلب. إن جدّد طلب آخر الرمز فعلًا يُعاد الطلب بالرمز الجديد دون تجديد ثانٍ.
- **تجديد واحد في آنٍ واحد** (single-flight) مهما تعدّدت الطلبات.
- رفض التجديد (400/401) أو انتهاء رمز التجديد أو 401 بعد الإعادة: تُمسح الجلسة ويُستدعى `onAuthLost`. أخطاء عابرة (شبكة/مهلة/429/5xx) لا تُنهي الجلسة.
- لا يُسجَّل شيء في `console`، ولا تُخزَّن كلمات مرور (العميل لا يتعامل معها أصلًا).

## تشغيل الاختبارات
```
node --test --test-reporter=spec tests/api_client.test.js     # اختبارات العميل فقط (36)
node --test --test-reporter=spec "tests/**/*.test.js"          # كل اختبارات الواجهة
```
تتطلب Node 22 ولا تحتاج شبكة ولا تبعيات. الاختبارات تحاكي `fetch`؛ **لم يُجرَّب تكامل فعلي مع خادم حقيقي**.

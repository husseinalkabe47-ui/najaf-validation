/* Phase 11.7.1 — اختبارات عميل الـ API (api/apiClient.js). بلا شبكة حقيقية: fetch والمؤقّتات والساعة كلها مُحقَنة.
   تثبت السلوك مقابل عقد الخلفية كما هو موثّق، لا مقابل خادم حقيقي (لم يُجرَّب أي تكامل فعلي مع خادم). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const ApiClient = require('../api/apiClient.js');
const { ApiError } = ApiClient;

const T0 = Date.parse('2030-01-01T00:00:00Z');
const iso = ms => new Date(ms).toISOString();
const SECRET_A = 'ACCESS-SECRET-aaaaaaaaaaaaaaaa';
const SECRET_R = 'REFRESH-SECRET-rrrrrrrrrrrrrrr';
const session = (n, o) => Object.assign({ accessToken: 'ACCESS-' + n, accessExpiresAt: iso(T0 + 15 * 60e3), refreshToken: 'REFRESH-' + n, refreshExpiresAt: iso(T0 + 30 * 864e5) }, o);
const json = (status, body, headers) => new Response(JSON.stringify(body), { status, headers: Object.assign({ 'content-type': 'application/json' }, headers) });

/** عميل بمؤقّتات يدوية وساعة قابلة للتحريك. handler(call) يعيد Response أو وعدًا أو يرمي. */
function setup(handler, opts) {
  const calls = [];
  const timers = new Map();
  let seq = 1;
  const clock = { t: T0 };
  const lost = [];
  const fetchFn = async (url, init) => {
    const call = { url, init, headers: init.headers, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    calls.push(call);
    return handler(call, calls.length);
  };
  const api = ApiClient.create(Object.assign({
    baseUrl: 'https://api.example.test', fetch: fetchFn, now: () => clock.t,
    setTimeout: (fn, ms) => { const id = seq++; timers.set(id, { fn, ms }); return id; },
    clearTimeout: id => { timers.delete(id); },
    onAuthLost: r => lost.push(r),
  }, opts));
  return { api, calls, timers, clock, lost, fireTimers: () => [...timers.values()].forEach(t => t.fn()) };
}
const rejects = async (p, kind, extra) => {
  let err;
  try { await p; } catch (e) { err = e; }
  assert.ok(err instanceof ApiError, 'expected ApiError, got ' + err);
  assert.equal(err.kind, kind);
  if (extra) for (const k of Object.keys(extra)) assert.deepEqual(err[k], extra[k], k);
  return err;
};

/* ---------------- الإعداد ---------------- */

test('baseUrl: يُنظَّف ويُرفض غير الصالح', () => {
  assert.equal(ApiClient.normalizeBaseUrl('https://api.example.test/'), 'https://api.example.test');
  assert.equal(ApiClient.normalizeBaseUrl(' http://localhost:3000/v1/ '), 'http://localhost:3000/v1');
  assert.equal(ApiClient.normalizeBaseUrl('/api/'), '/api');
  for (const bad of ['', '   ', null, undefined, 42, 'ftp://x.test', 'javascript:alert(1)', 'https://u:p@x.test', 'https://x.test?a=1', 'https://x.test#h', '//evil.test', '/a?b', 'api.example.test', 'https://x .test', 'https://x.test\\a'])
    assert.throws(() => ApiClient.normalizeBaseUrl(bad), e => e instanceof ApiError && e.kind === 'config', String(bad));
  assert.throws(() => ApiClient.create({}), ApiError);
});

test('الإعداد من البيئة: وسم meta ثم المتغير العام؛ فارغ = غير مفعّل ولا عميل', () => {
  const doc = c => ({ querySelector: sel => (sel === 'meta[name="najaf-api-base-url"]' ? { content: c } : null) });
  assert.equal(ApiClient.fromEnvironment({ document: doc(''), window: {} }), null);
  assert.equal(ApiClient.isConfigured({ document: doc(''), window: {} }), false);
  assert.equal(ApiClient.fromEnvironment({ document: { querySelector: () => null }, window: {} }), null);
  assert.equal(ApiClient.fromEnvironment({ document: doc('https://api.example.test/'), window: { NAJAF_API_BASE_URL: 'https://other.test' } }).baseUrl, 'https://api.example.test');
  assert.equal(ApiClient.fromEnvironment({ document: doc(''), window: { NAJAF_API_BASE_URL: '/api' } }).baseUrl, '/api');
  assert.throws(() => ApiClient.fromEnvironment({ document: doc('not a url'), window: {} }), ApiError);
});

test('المهلة: قيمة غير صالحة تُرفض، والسقف الأعلى مطبَّق', async () => {
  assert.throws(() => ApiClient.create({ baseUrl: '/api', timeoutMs: 0 }), ApiError);
  assert.throws(() => ApiClient.create({ baseUrl: '/api', timeoutMs: NaN }), ApiError);
  const s = setup(() => json(200, {}), { timeoutMs: 9e9 });
  await s.api.get('/v1/public/x', { auth: 'none' });
  assert.equal(s.calls.length, 1);
});

/* ---------------- طلبات ناجحة ---------------- */

test('GET ناجح: URL والاستعلام والترويسات، بلا Authorization عند auth:none', async () => {
  const s = setup(() => json(200, { items: [1, 2] }));
  const data = await s.api.get('/v1/public/cars', { auth: 'none', query: { page: 2, q: 'كيا ريو', skip: undefined, none: null, flag: false } });
  assert.deepEqual(data, { items: [1, 2] });
  const c = s.calls[0];
  assert.equal(c.url, 'https://api.example.test/v1/public/cars?page=2&q=%D9%83%D9%8A%D8%A7%20%D8%B1%D9%8A%D9%88&flag=false');
  assert.equal(c.init.method, 'GET');
  assert.equal(c.headers.Accept, 'application/json');
  assert.equal(c.headers.Authorization, undefined);
  assert.equal(c.headers['Content-Type'], undefined, 'لا Content-Type بلا جسم');
  assert.equal(c.init.body, undefined);
  assert.equal(c.init.credentials, 'omit');
  assert.equal(c.init.redirect, 'error');
  assert.ok(c.init.signal);
});

test('POST: يُرسل JSON مع Content-Type، و204 يعيد null، والمؤقّت يُلغى بعد النجاح', async () => {
  const s = setup(call => (call.url.endsWith('/gone') ? new Response(null, { status: 204 }) : json(201, { ok: true })));
  assert.deepEqual(await s.api.post('/v1/x', { a: 1, ar: 'نص' }, { auth: 'none' }), { ok: true });
  assert.equal(s.calls[0].headers['Content-Type'], 'application/json');
  assert.deepEqual(s.calls[0].body, { a: 1, ar: 'نص' });
  assert.equal(await s.api.delete('/v1/gone', { auth: 'none' }), null);
  assert.equal(s.timers.size, 0, 'لا مؤقّتات متروكة');
});

test('المسار: روابط مطلقة وملتوية تُرفض قبل أي اتصال (لا تسرّب الرمز لمضيف آخر)', async () => {
  const s = setup(() => json(200, {}));
  s.api.setSession(session(1));
  for (const bad of ['https://evil.test/x', '//evil.test/x', 'v1/x', '/v1/../x', '/v1/x y', '/v1/x#h', '', null, '/v1\\x'])
    await rejects(s.api.get(bad), 'config', { code: 'invalid_path' });
  assert.equal(s.calls.length, 0);
});

test('جسم غير قابل للتحويل إلى JSON يُرفض قبل الاتصال', async () => {
  const s = setup(() => json(200, {}));
  const cyc = {}; cyc.self = cyc;
  await rejects(s.api.post('/v1/x', cyc, { auth: 'none' }), 'config', { code: 'invalid_body' });
  assert.equal(s.calls.length, 0);
});

/* ---------------- أخطاء الشبكة والمهلة والإلغاء ---------------- */

test('خطأ شبكة: ApiError(network) بلا تسريب للرابط أو الرسالة الأصلية', async () => {
  const s = setup(() => { throw new TypeError('fetch failed https://api.example.test/secret?token=' + SECRET_A); });
  const e = await rejects(s.api.get('/v1/public/x', { auth: 'none' }), 'network', { status: null, code: 'network' });
  assert.equal(e.isNetworkError, true);
  assert.ok(!JSON.stringify(e).includes(SECRET_A) && !e.message.includes(SECRET_A) && !String(e.stack).includes(SECRET_A));
  assert.match(e.messageAr, /الاتصال/);
});

test('المهلة: تنتهي حتى لو تجاهل fetch الإشارة، وتُلغي الطلب الفعلي', async () => {
  let sig;
  const s = setup(call => { sig = call.init.signal; return new Promise(() => {}); }, { timeoutMs: 5000 });
  const p = s.api.get('/v1/public/x', { auth: 'none' });
  await new Promise(r => setImmediate(r));
  assert.equal([...s.timers.values()][0].ms, 5000);
  s.fireTimers();
  const e = await rejects(p, 'timeout');
  assert.equal(e.isNetworkError, true);
  assert.equal(sig.aborted, true);
  assert.equal(s.timers.size, 0);
});

test('مهلة لكل طلب تتجاوز الافتراضية، وتُقيَّد بالسقف', async () => {
  const s = setup(() => json(200, {}));
  await s.api.get('/v1/x', { auth: 'none', timeoutMs: 1234 });
  await s.api.get('/v1/x', { auth: 'none' });
  await rejects(s.api.get('/v1/x', { auth: 'none', timeoutMs: -1 }), 'config');
  assert.equal(s.calls.length, 2);
});

test('إلغاء المستدعي: aborted ≠ timeout، وإشارة ملغاة مسبقًا لا تتصل', async () => {
  const s = setup(() => new Promise(() => {}));
  const ac = new AbortController();
  const p = s.api.get('/v1/x', { auth: 'none', signal: ac.signal });
  await new Promise(r => setImmediate(r));
  ac.abort();
  await rejects(p, 'aborted');
  const ac2 = new AbortController(); ac2.abort();
  const before = s.calls.length;
  await rejects(s.api.get('/v1/x', { auth: 'none', signal: ac2.signal }), 'aborted');
  assert.equal(s.calls.length, before);
});

/* ---------------- أخطاء HTTP ---------------- */

test('خطأ HTTP بصيغة الخلفية: code/fields/requestId، وعربي عام للواجهة', async () => {
  const body = { error: { code: 'validation_failed', message: 'The submitted data is not valid', fields: [{ field: 'phone', code: 'invalid_format' }], requestId: 'req-1' } };
  const s = setup(() => json(400, body));
  const e = await rejects(s.api.post('/v1/x', {}, { auth: 'none' }), 'http', { status: 400, code: 'validation_failed', requestId: 'req-1', fields: [{ field: 'phone', code: 'invalid_format' }] });
  assert.equal(e.serverMessage, 'The submitted data is not valid');
  assert.equal(e.messageAr, 'البيانات المرسلة غير صحيحة.');
});

test('429 مع Retry-After، و404، و5xx بجسم غير JSON', async () => {
  const s = setup((c, n) => {
    if (n === 1) return json(429, { error: { code: 'rate_limited', message: 'm', requestId: 'r' } }, { 'retry-after': '120' });
    if (n === 2) return json(404, { error: { code: 'not_found', message: 'm', requestId: 'r' } });
    if (n === 3) return new Response('<html>Bad gateway</html>', { status: 502, headers: { 'content-type': 'text/html' } });
    return json(429, { error: { code: 'rate_limited' } }, { 'retry-after': 'Wed, 21 Oct 2030 07:28:00 GMT' });
  });
  const o = { auth: 'none' };
  await rejects(s.api.get('/v1/x', o), 'http', { status: 429, code: 'rate_limited', retryAfterSeconds: 120 });
  await rejects(s.api.get('/v1/x', o), 'http', { status: 404, code: 'not_found', retryAfterSeconds: undefined });
  const e = await rejects(s.api.get('/v1/x', o), 'http', { status: 502, code: 'http_error', requestId: undefined, serverMessage: undefined });
  assert.match(e.messageAr, /الخادم/);
  await rejects(s.api.get('/v1/x', o), 'http', { status: 429, retryAfterSeconds: undefined });
});

test('جسم خطأ بحقول خبيثة/غير متوقعة لا يمرّ كما هو', async () => {
  const s = setup(() => json(409, { error: { code: '<script>', message: 5, fields: 'x', requestId: { a: 1 } } }));
  const e = await rejects(s.api.post('/v1/x', {}, { auth: 'none' }), 'http', { status: 409, code: 'http_error', fields: undefined, requestId: undefined, serverMessage: undefined });
  assert.ok(e);
});

/* ---------------- JSON غير صالح ---------------- */

test('JSON تالف أو نوع محتوى خاطئ في نجاح 2xx → invalid_response', async () => {
  const s = setup((c, n) => (n === 1
    ? new Response('{"a":', { status: 200, headers: { 'content-type': 'application/json' } })
    : new Response('<html></html>', { status: 200, headers: { 'content-type': 'text/html' } })));
  const e = await rejects(s.api.get('/v1/x', { auth: 'none' }), 'invalid_response', { status: 200 });
  assert.match(e.messageAr, /غير صالح/);
  await rejects(s.api.get('/v1/x', { auth: 'none' }), 'invalid_response');
});

test('JSON تالف في ردّ خطأ لا يكسر المعالجة (يبقى خطأ HTTP عامًّا)', async () => {
  const s = setup(() => new Response('{oops', { status: 500, headers: { 'content-type': 'application/json' } }));
  await rejects(s.api.get('/v1/x', { auth: 'none' }), 'http', { status: 500, code: 'http_error' });
});

/* ---------------- ترويسة المصادقة ---------------- */

test('ترويسة Bearer: تُرسل مع required/optional فقط، ولا جلسة = لا اتصال في required', async () => {
  const s = setup(() => json(200, { ok: 1 }));
  await rejects(s.api.get('/v1/me/x'), 'auth', { code: 'not_authenticated', status: 401 });
  assert.equal(s.calls.length, 0);
  await s.api.get('/v1/public/x', { auth: 'optional' });
  assert.equal(s.calls[0].headers.Authorization, undefined);
  s.api.setSession(session(1));
  await s.api.get('/v1/me/x');
  await s.api.get('/v1/public/x', { auth: 'optional' });
  await s.api.get('/v1/public/x', { auth: 'none' });
  assert.equal(s.calls[1].headers.Authorization, 'Bearer ACCESS-1');
  assert.equal(s.calls[2].headers.Authorization, 'Bearer ACCESS-1');
  assert.equal(s.calls[3].headers.Authorization, undefined);
  await rejects(s.api.get('/v1/x', { auth: 'bogus' }), 'config');
});

test('setSession يرفض شكلًا غير صالح، وclearSession/hasSession', () => {
  const s = setup(() => json(200, {}));
  for (const bad of [null, {}, session(1, { accessToken: '' }), session(1, { refreshToken: 5 }), session(1, { accessExpiresAt: 'x' }), session(1, { refreshExpiresAt: undefined })])
    assert.throws(() => s.api.setSession(bad), ApiError);
  assert.equal(s.api.hasSession(), false);
  s.api.setSession(session(1));
  assert.equal(s.api.hasSession(), true);
  s.api.clearSession();
  assert.equal(s.api.hasSession(), false);
});

test('الواجهة العامة لا تعيد الرموز أبدًا', () => {
  const s = setup(() => json(200, {}));
  s.api.setSession(session(1));
  assert.ok(!JSON.stringify(Object.keys(s.api)).match(/token|session$/i) || Object.keys(s.api).every(k => !/^(getSession|getToken|accessToken|refreshToken)$/.test(k)));
  assert.ok(!JSON.stringify(s.api).includes('ACCESS-1'));
});

/* ---------------- انتهاء الصلاحية والتجديد ---------------- */

const refreshOk = n => json(200, { user: { id: '1' }, session: session(n) });

test('انتهاء رمز الوصول مسبقًا: تجديد قبل الإرسال بعقد الخلفية، ثم الطلب بالرمز الجديد', async () => {
  const s = setup(call => (call.url.endsWith('/v1/auth/refresh') ? refreshOk(2) : json(200, { ok: 1 })));
  s.api.setSession(session(1, { accessExpiresAt: iso(T0 + 10e3) }));   // أقل من هامش 30 ثانية
  await s.api.get('/v1/me/x');
  assert.equal(s.calls.length, 2);
  assert.equal(s.calls[0].url, 'https://api.example.test/v1/auth/refresh');
  assert.equal(s.calls[0].init.method, 'POST');
  assert.deepEqual(s.calls[0].body, { refreshToken: 'REFRESH-1' });
  assert.equal(s.calls[0].headers.Authorization, undefined, 'التجديد بلا Authorization');
  assert.equal(s.calls[1].headers.Authorization, 'Bearer ACCESS-2');
  await s.api.get('/v1/me/x');            // الرمز الجديد صالح: لا تجديد آخر
  assert.equal(s.calls.length, 3);
  assert.equal(s.calls[2].headers.Authorization, 'Bearer ACCESS-2');
});

test('الرمز قريب الانتهاء لكنه صالح خارج الهامش: لا تجديد', async () => {
  const s = setup(() => json(200, {}));
  s.api.setSession(session(1, { accessExpiresAt: iso(T0 + 60e3) }));
  await s.api.get('/v1/me/x');
  assert.equal(s.calls.length, 1);
});

test('رد 401 من الخادم: تجديد ثم إعادة الطلب مرة واحدة بنجاح', async () => {
  let n = 0;
  const s = setup(call => {
    if (call.url.endsWith('/v1/auth/refresh')) return refreshOk(2);
    return ++n === 1 ? json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } }, { 'www-authenticate': 'Bearer' }) : json(200, { done: true });
  });
  s.api.setSession(session(1));
  assert.deepEqual(await s.api.post('/v1/me/things', { a: 1 }), { done: true });
  assert.deepEqual(s.calls.map(c => c.url.replace('https://api.example.test', '')), ['/v1/me/things', '/v1/auth/refresh', '/v1/me/things']);
  assert.equal(s.calls[2].headers.Authorization, 'Bearer ACCESS-2');
  assert.deepEqual(s.calls[2].body, { a: 1 });
  assert.deepEqual(s.lost, []);
});

test('تزامن: عدة طلبات والرمز منتهٍ → استدعاء تجديد واحد فقط، وكلها تستعمل الرمز الجديد', async () => {
  let release;
  const gate = new Promise(r => { release = r; });
  const s = setup(async call => {
    if (call.url.endsWith('/v1/auth/refresh')) { await gate; return refreshOk(2); }
    return json(200, { ok: 1 });
  });
  s.api.setSession(session(1, { accessExpiresAt: iso(T0 - 1000) }));
  const ps = Array.from({ length: 6 }, (_, i) => s.api.get('/v1/me/x' + i));
  await new Promise(r => setImmediate(r));
  release();
  await Promise.all(ps);
  const refreshes = s.calls.filter(c => c.url.endsWith('/v1/auth/refresh'));
  assert.equal(refreshes.length, 1);
  const others = s.calls.filter(c => !c.url.endsWith('/v1/auth/refresh'));
  assert.equal(others.length, 6);
  others.forEach(c => assert.equal(c.headers.Authorization, 'Bearer ACCESS-2'));
});

test('تزامن: عدة 401 بالرمز القديم نفسه → تجديد واحد، وكل طلب يُعاد مرة واحدة', async () => {
  const s = setup(async call => {
    if (call.url.endsWith('/v1/auth/refresh')) return refreshOk(2);
    return call.headers.Authorization === 'Bearer ACCESS-1' ? json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } }) : json(200, { ok: 1 });
  });
  s.api.setSession(session(1));
  await Promise.all([1, 2, 3, 4].map(i => s.api.get('/v1/me/x' + i)));
  assert.equal(s.calls.filter(c => c.url.endsWith('/v1/auth/refresh')).length, 1);
  assert.equal(s.calls.filter(c => c.headers.Authorization === 'Bearer ACCESS-2').length, 4);
});

test('طلب 401 جاء بعد أن جدّد غيره: يُعاد بالرمز الحالي دون تجديد ثانٍ', async () => {
  let release;
  const gate = new Promise(r => { release = r; });
  let first = true;
  const s = setup(async call => {
    if (call.url.endsWith('/v1/auth/refresh')) return refreshOk(2);
    if (call.headers.Authorization === 'Bearer ACCESS-1') {
      if (first) { first = false; await gate; }          // الطلب الأول ينتظر ثم يعود 401 بعد أن جُدِّد الرمز
      return json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } });
    }
    return json(200, { ok: 1 });
  });
  s.api.setSession(session(1));
  const slow = s.api.get('/v1/me/slow');
  await new Promise(r => setImmediate(r));
  await s.api.get('/v1/me/fast');                        // 401 → تجديد → نجاح
  release();
  await slow;
  assert.equal(s.calls.filter(c => c.url.endsWith('/v1/auth/refresh')).length, 1, 'تجديد واحد فقط');
});

test('رفض التجديد (401): تُمسح الجلسة، يُبلَّغ onAuthLost مرة، والطلبات التالية بلا اتصال', async () => {
  const s = setup(call => (call.url.endsWith('/v1/auth/refresh') ? json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } }) : json(200, {})));
  s.api.setSession(session(1, { accessExpiresAt: iso(T0 - 1) }));
  const e = await rejects(s.api.get('/v1/me/x'), 'auth', { code: 'session_expired', status: 401 });
  assert.equal(e.isUnauthorized, true);
  assert.equal(s.api.hasSession(), false);
  assert.deepEqual(s.lost, ['refresh_rejected']);
  const n = s.calls.length;
  await rejects(s.api.get('/v1/me/x'), 'auth', { code: 'not_authenticated' });
  assert.equal(s.calls.length, n);
});

test('فشل تجديد عابر (شبكة/429/5xx/مهلة): الجلسة تبقى ولا يُبلَّغ فقدانها', async () => {
  for (const mode of ['network', '429', '503']) {
    const s = setup(call => {
      if (!call.url.endsWith('/v1/auth/refresh')) return json(200, {});
      if (mode === 'network') throw new TypeError('down');
      return json(Number(mode), { error: { code: 'x', message: 'm', requestId: 'r' } });
    });
    s.api.setSession(session(1, { accessExpiresAt: iso(T0 - 1) }));
    const e = await rejects(s.api.get('/v1/me/x'), mode === 'network' ? 'network' : 'http');
    if (mode !== 'network') assert.equal(e.status, Number(mode));
    assert.equal(s.api.hasSession(), true, mode);
    assert.deepEqual(s.lost, [], mode);
  }
});

test('رمز التجديد منتهٍ محليًا: لا اتصال، تُمسح الجلسة، onAuthLost("expired")', async () => {
  const s = setup(() => json(200, {}));
  s.api.setSession(session(1, { accessExpiresAt: iso(T0 - 1), refreshExpiresAt: iso(T0 - 1) }));
  await rejects(s.api.get('/v1/me/x'), 'auth', { code: 'session_expired' });
  assert.equal(s.calls.length, 0);
  assert.equal(s.api.hasSession(), false);
  assert.deepEqual(s.lost, ['expired']);
});

test('بعد التجديد ما زال 401: لا حلقة (إعادة واحدة فقط)، وتُمسح الجلسة', async () => {
  const s = setup(call => (call.url.endsWith('/v1/auth/refresh') ? refreshOk(2) : json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } })));
  s.api.setSession(session(1));
  await rejects(s.api.get('/v1/me/x'), 'http', { status: 401 });
  assert.equal(s.calls.length, 3, 'طلب + تجديد + إعادة واحدة');
  assert.equal(s.api.hasSession(), false);
  assert.deepEqual(s.lost, ['expired']);
});

test('رد تجديد بشكل جلسة غير صالح: invalid_response والجلسة القديمة محفوظة', async () => {
  const s = setup(call => (call.url.endsWith('/v1/auth/refresh') ? json(200, { user: {}, session: { accessToken: 'x' } }) : json(200, {})));
  s.api.setSession(session(1, { accessExpiresAt: iso(T0 - 1) }));
  await rejects(s.api.get('/v1/me/x'), 'invalid_response');
  assert.equal(s.api.hasSession(), true);
});

test('401 بلا رمز مُرسَل (auth:optional بلا جلسة) لا يُطلق تجديدًا', async () => {
  const s = setup(() => json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } }));
  await rejects(s.api.get('/v1/x', { auth: 'optional' }), 'http', { status: 401 });
  assert.equal(s.calls.length, 1);
});

test('401 على auth:none لا يُطلق تجديدًا ولا يمسّ الجلسة', async () => {
  const s = setup(() => json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } }));
  s.api.setSession(session(1));
  await rejects(s.api.get('/v1/x', { auth: 'none' }), 'http', { status: 401 });
  assert.equal(s.calls.length, 1);
  assert.equal(s.api.hasSession(), true);
});

/* ---------------- عدم تسريب الأسرار ---------------- */

test('لا console ولا تسريب للرموز في الأخطاء أو أي مخرجات', async () => {
  const logged = [];
  const orig = {};
  ['log', 'info', 'warn', 'error', 'debug'].forEach(k => { orig[k] = console[k]; console[k] = (...a) => logged.push(a.map(String).join(' ')); });
  try {
    const s = setup(call => {
      if (call.url.endsWith('/v1/auth/refresh')) return json(401, { error: { code: 'unauthorized', message: 'm', requestId: 'r' } });
      throw new TypeError('boom ' + call.headers.Authorization);
    });
    s.api.setSession({ accessToken: SECRET_A, accessExpiresAt: iso(T0 + 15 * 60e3), refreshToken: SECRET_R, refreshExpiresAt: iso(T0 + 864e5) });
    const e1 = await rejects(s.api.get('/v1/me/x'), 'network');
    s.api.setSession({ accessToken: SECRET_A, accessExpiresAt: iso(T0 - 1), refreshToken: SECRET_R, refreshExpiresAt: iso(T0 + 864e5) });
    const e2 = await rejects(s.api.get('/v1/me/x'), 'auth');
    for (const e of [e1, e2]) {
      const dump = JSON.stringify(e) + e.message + e.messageAr + String(e.stack) + Object.getOwnPropertyNames(e).map(k => String(e[k])).join('|');
      assert.ok(!dump.includes(SECRET_A) && !dump.includes(SECRET_R));
    }
  } finally { Object.assign(console, orig); }
  assert.deepEqual(logged, []);
});

test('الملف نفسه: لا console ولا localStorage ولا AppStorage ولا اعتماد على الطبقات المحلية', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'api', 'apiClient.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  for (const bad of [/\bconsole\./, /localStorage|sessionStorage|indexedDB|document\.cookie/, /AppStorage|Repository|SessionService|UserService|AuthService/, /\beval\(|new Function/])
    assert.ok(!bad.test(src), String(bad));
});

/* ---------------- الحفاظ على سلوك التطبيق الحالي ---------------- */

test('التحميل كسكربت عادي داخل بيئة التطبيق الحالية: لا أخطاء، لا شبكة، غير مفعّل، والبيانات المحلية دون تغيير', () => {
  const vm = require('vm');
  const { makeEnv } = require('./harness.js');
  const env = makeEnv();
  assert.deepEqual(env.errors, []);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'api', 'apiClient.js'), 'utf8'), env.ctx, { filename: 'api/apiClient.js' });
  assert.equal(env.run('typeof ApiClient'), 'object');
  assert.equal(env.run('ApiClient.isConfigured()'), false);
  assert.equal(env.run('ApiClient.fromEnvironment()'), null);
  assert.equal(env.run('typeof fetch'), 'undefined', 'لا شيء في التطبيق الحالي يستدعي الشبكة');
  assert.equal(JSON.stringify(env.run('SessionService.getCurrentUser()')), 'null');
});

test('index.html لم يتغيّر في هذه المرحلة: العميل غير محمَّل في التطبيق (الربط في 11.7.2)', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert.ok(!/apiClient/.test(html));
  assert.equal((html.match(/<script src=/g) || []).length, 85);
});

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  can, authorize, authorizeRead, requireActor, isPublic, toAuthzHttp, AuthzError, notFound,
  userResource, showroomResource, showroomCarResource, memberCarResource, favoriteResource,
  type Actor, type Action, type Resource,
} from '../../src/authz/index.ts';

const member = (id: string): Actor => ({ id, role: 'member' });
const dealer = (id: string): Actor => ({ id, role: 'dealer' });
const admin = (id = '1'): Actor => ({ id, role: 'admin' });
const M1 = member('10'), M2 = member('11'), D1 = dealer('20'), D2 = dealer('21'), A = admin('1');

const showroom = (ownerId: string, status = 'active', ownerActive = true) => showroomResource({ ownerId, status, ownerActive });
const showroomCar = (showroomOwnerId: string, showroomStatus = 'active', ownerActive = true, deleted = false) => showroomCarResource({ showroomOwnerId, showroomStatus, ownerActive, deleted });
const memberCar = (ownerId: string, status = 'active', ownerActive = true, deleted = false) => memberCarResource({ ownerId, status, ownerActive, deleted });

const ACTIONS: Action[] = ['read', 'update', 'delete', 'moderate'];
const code = (f: () => void) => { try { f(); return 'ok'; } catch (e) { assert.ok(e instanceof AuthzError); return e.code; } };

describe('deny by default', () => {
  it('a guest (null actor) can do nothing to anything', () => {
    for (const r of [userResource({ id: '10' }), showroom('20'), showroomCar('20'), memberCar('10'), favoriteResource({ userId: '10' })])
      for (const a of ACTIONS) assert.equal(can(null, a, r), false);
  });
  it('unknown actions, malformed actors and malformed resources are denied', () => {
    assert.equal(can(A, 'drop' as never, showroom('20')), false);
    assert.equal(can(A, 'read', { kind: 'secret' } as never), false);
    assert.equal(can(A, 'read', null as never), false);
    assert.equal(can('admin' as never, 'read', showroom('20')), false);
  });
  it('requireActor: guest is 401, an actor passes through', () => {
    assert.equal(code(() => requireActor(null)), 'unauthorized');
    assert.equal(requireActor(M1), M1);
  });
});

describe('role escalation is impossible through the policy', () => {
  it('a member can never act as a dealer or admin, whatever ids they hold', () => {
    const s = showroom('10'); // even if the showroom row says owner 10 (== the member's id), a member is not a dealer owner
    assert.equal(can(M1, 'read', s), false);
    assert.equal(can(M1, 'update', s), false);
    assert.equal(can(M1, 'update', showroomCar('10')), false);
    for (const a of ['moderate', 'delete'] as const) assert.equal(can(M1, a, s), false);
  });
  it('a dealer is not an admin: no moderation, no deleting showrooms, no foreign data', () => {
    for (const r of [showroom('20'), showroomCar('20')]) assert.equal(can(D1, 'moderate', r), false);
    assert.equal(can(D1, 'delete', showroom('20')), false);
    assert.equal(can(D1, 'moderate', memberCar('10')), false);
    assert.equal(can(D1, 'read', userResource({ id: '10' })), false);
    assert.equal(can(D1, 'moderate', userResource({ id: '10' })), false);
  });
  it('client-supplied role/permission fields on an actor-like object cannot matter: only id and role are read, role must be exact', () => {
    const forged = { id: '10', role: 'member', isAdmin: true, permissions: ['*'] } as unknown as Actor;
    assert.equal(can(forged, 'moderate', memberCar('99')), false);
    assert.equal(can({ id: '10', role: 'ADMIN' } as never, 'moderate', memberCar('99')), false);
  });
});

describe('ownership bypass / IDOR / BOLA', () => {
  it('member cars: only the owner (and admin for read/delete/moderate) — never another member', () => {
    const car = memberCar('10');
    assert.deepEqual(ACTIONS.map((a) => can(M1, a, car)), [true, true, true, false]);
    assert.deepEqual(ACTIONS.map((a) => can(M2, a, car)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(D1, a, car)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(A, a, car)), [true, false, true, true]);
  });
  it('ownership is by id, never by role: a dealer who owns a MEMBER ad manages it as its owner, and only that one', () => {
    assert.equal(can(D1, 'update', memberCar('20')), true);
    assert.equal(can(D1, 'update', memberCar('21')), false);
  });
  it('showrooms: only the owning dealer manages; another dealer and every member are denied', () => {
    const s = showroom('20');
    assert.deepEqual(ACTIONS.map((a) => can(D1, a, s)), [true, true, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(D2, a, s)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(M1, a, s)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(A, a, s)), [true, true, true, true]);
  });
  it("showroom cars follow the showroom's owner", () => {
    const c = showroomCar('20');
    assert.deepEqual(ACTIONS.map((a) => can(D1, a, c)), [true, true, true, false]);
    assert.deepEqual(ACTIONS.map((a) => can(D2, a, c)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(M1, a, c)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(A, a, c)), [true, true, true, true]);
  });
  it('ids are compared as exact strings: "20" does not match "020", "20 " or 20', () => {
    for (const bad of ['020', '20 ', '2', '200']) assert.equal(can({ id: bad, role: 'dealer' }, 'update', showroom('20')), false);
    assert.equal(can({ id: 20 as never, role: 'dealer' }, 'update', showroom('20')), false);
  });
  it('resource factories refuse a malformed owner id (a client string cannot become an owner)', () => {
    for (const bad of ['', '0', '1 OR 1=1', '-1', 'null', '01', '1.0'])
      assert.throws(() => memberCarResource({ ownerId: bad, status: 'active', ownerActive: true, deleted: false }), TypeError, bad);
    assert.throws(() => showroomResource({ ownerId: undefined as never, status: 'active', ownerActive: true }), TypeError);
    assert.throws(() => favoriteResource({ userId: {} as never }), TypeError);
  });
});

describe('cross-user access', () => {
  it('user records: self reads and updates; admin reads and moderates; nobody else', () => {
    const u = userResource({ id: '10' });
    assert.deepEqual(ACTIONS.map((a) => can(M1, a, u)), [true, true, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(M2, a, u)), [false, false, false, false]);
    assert.deepEqual(ACTIONS.map((a) => can(A, a, u)), [true, false, false, true]);
  });
  it('favorites are strictly personal — not even an admin', () => {
    const f = favoriteResource({ userId: '10' });
    assert.deepEqual(ACTIONS.map((a) => can(M1, a, f)), [true, true, true, false]);
    for (const other of [M2, D1, A]) for (const a of ACTIONS) assert.equal(can(other, a, f), false);
  });
});

describe('admin access', () => {
  it('admin reaches every resource kind (except favorites) in every state, including hidden ones', () => {
    for (const st of ['pending', 'suspended', 'active']) {
      assert.equal(can(A, 'read', showroom('20', st, st === 'active')), true);
      assert.equal(can(A, 'moderate', showroom('20', st, false)), true);
      assert.equal(can(A, 'read', showroomCar('20', st, false, true)), true);
    }
    for (const st of ['pending', 'active', 'sold', 'rejected', 'suspended']) assert.equal(can(A, 'moderate', memberCar('10', st, false, true)), true);
  });
  it('admin is still limited: cannot rewrite a member ad or read favorites', () => {
    assert.equal(can(A, 'update', memberCar('10')), false);
    assert.equal(can(A, 'read', favoriteResource({ userId: '10' })), false);
  });
});

describe('dealer / member separation', () => {
  it('a dealer owner keeps access to their own NON-public showroom and its cars', () => {
    const s = showroom('20', 'pending'); const c = showroomCar('20', 'suspended');
    assert.equal(isPublic(s), false);
    assert.equal(can(D1, 'read', s), true);
    assert.equal(can(D1, 'update', c), true);
  });
  it('members and dealers get no access to each other\'s private resources', () => {
    assert.equal(can(M1, 'read', showroom('20', 'pending')), false);
    assert.equal(can(D1, 'read', memberCar('10', 'pending')), false);
    assert.equal(can(D1, 'read', favoriteResource({ userId: '10' })), false);
  });
});

describe('public visibility is separate from private authorization', () => {
  it('mirrors the public_showrooms / public_cars views', () => {
    assert.equal(isPublic(showroom('20')), true);
    for (const st of ['pending', 'suspended', 'rejected', '', 'ACTIVE']) assert.equal(isPublic(showroom('20', st)), false, st);
    assert.equal(isPublic(showroom('20', 'active', false)), false, 'owner suspended/deleted hides the showroom');
    assert.equal(isPublic(showroomCar('20')), true);
    assert.equal(isPublic(showroomCar('20', 'suspended')), false);
    assert.equal(isPublic(showroomCar('20', 'active', false)), false);
    assert.equal(isPublic(showroomCar('20', 'active', true, true)), false);
    assert.equal(isPublic(memberCar('10')), true);
    for (const st of ['pending', 'sold', 'rejected', 'suspended']) assert.equal(isPublic(memberCar('10', st)), false, st);
    assert.equal(isPublic(memberCar('10', 'active', false)), false);
    assert.equal(isPublic(memberCar('10', 'active', true, true)), false);
    assert.equal(isPublic(userResource({ id: '10' })), false);
    assert.equal(isPublic(favoriteResource({ userId: '10' })), false);
  });
  it('being public grants a guest/stranger NO private capability', () => {
    const s = showroom('20');
    assert.equal(isPublic(s), true);
    for (const a of ACTIONS) { assert.equal(can(null, a, s), false); assert.equal(can(M1, a, s), false); }
  });
  it('authorizeRead: public → anyone; private → owner/admin only; otherwise 404', () => {
    const pub = showroom('20'); const hidden = showroom('20', 'pending');
    assert.doesNotThrow(() => authorizeRead(null, pub));
    assert.doesNotThrow(() => authorizeRead(M1, pub));
    assert.equal(code(() => authorizeRead(null, hidden)), 'not_found');
    assert.equal(code(() => authorizeRead(M1, hidden)), 'not_found');
    assert.equal(code(() => authorizeRead(D2, hidden)), 'not_found');
    assert.doesNotThrow(() => authorizeRead(D1, hidden));
    assert.doesNotThrow(() => authorizeRead(A, hidden));
    assert.equal(code(() => authorizeRead(M1, null)), 'not_found');
  });
});

describe('404 non-disclosure', () => {
  it('a private resource the caller may not read is indistinguishable from a missing one (same code, status, message, shape)', () => {
    const missing = (() => { try { authorize(M1, 'read', undefined); } catch (e) { return e as AuthzError; } throw new Error('no throw'); })();
    const cases: Array<[Actor | null, Resource]> = [
      [M2, memberCar('10')], [D1, memberCar('10')], [null, memberCar('10')],
      [M1, showroom('20', 'pending')], [D2, showroom('20', 'suspended')], [null, showroom('20')],
      [M2, favoriteResource({ userId: '10' })], [A, favoriteResource({ userId: '10' })],
      [M2, userResource({ id: '10' })],
    ];
    for (const [actor, r] of cases) {
      for (const a of ACTIONS) {
        let err: AuthzError | undefined;
        try { authorize(actor, a, r); } catch (e) { err = e as AuthzError; }
        assert.ok(err, `${r.kind}/${a} must be denied`);
        assert.equal(err.code, 'not_found');
        assert.deepEqual(toAuthzHttp(err), toAuthzHttp(missing));
        assert.equal(err.message, missing.message);
      }
    }
    assert.deepEqual(toAuthzHttp(missing), { status: 404, code: 'not_found', message: 'Not found' });
  });
  it('403 only when the caller can already read the resource but may not do the action', () => {
    assert.equal(code(() => authorize(D1, 'delete', showroom('20'))), 'forbidden'); // owner may read, not delete
    assert.equal(code(() => authorize(D1, 'moderate', showroomCar('20'))), 'forbidden');
    assert.equal(code(() => authorize(A, 'update', memberCar('10'))), 'forbidden');
    assert.equal(code(() => authorize(M1, 'moderate', memberCar('10'))), 'forbidden');
    assert.equal(code(() => authorize(M1, 'update', userResource({ id: '10' }))), 'ok');
    assert.deepEqual(toAuthzHttp(new AuthzError('forbidden')), { status: 403, code: 'forbidden', message: 'Not allowed' });
  });
  it('an allowed action returns normally; a missing resource is always 404 even for an admin', () => {
    assert.doesNotThrow(() => authorize(M1, 'update', memberCar('10')));
    assert.equal(code(() => authorize(A, 'read', null)), 'not_found');
    assert.equal(code(() => { throw notFound(); }), 'not_found');
  });
  it('the error carries no resource detail and toAuthzHttp ignores foreign errors', () => {
    const e = new AuthzError('not_found');
    assert.equal(JSON.stringify(toAuthzHttp(e)).includes('10'), false);
    assert.equal(toAuthzHttp(new Error('x')), undefined);
    assert.equal(toAuthzHttp(undefined), undefined);
  });
});

describe('suspended / deleted users never reach the policy as actors', () => {
  it('their actor is null, so every action on every resource is denied/404', async () => {
    const { toActor } = await import('../../src/authz/index.ts');
    for (const bad of [{ id: '10', role: 'user', status: 'suspended' }, { id: '10', role: 'user', status: 'active', deletedAt: new Date() }]) {
      const actor = toActor(bad);
      assert.equal(actor, null);
      assert.equal(code(() => authorize(actor, 'update', memberCar('10'))), 'not_found', 'even their own former ad');
      assert.equal(can(actor, 'read', userResource({ id: '10' })), false);
    }
  });
});

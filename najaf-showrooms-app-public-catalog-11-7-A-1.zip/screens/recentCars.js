/* RecentCarsScreen — «السيارات المضافة حديثاً» (ميزة جديدة ج1): القائمة الكاملة للسيارات العامة (معارض + أعضاء) بالأحدث أولًا.
   المصدر الوحيد: getRecentCars (searchService) ← searchCars('all') ← getPublicCars ← visibilityService؛ والعرض بـCarCard وEmptyState القائمين.
   بحث بسيط يعيد استخدام searchCars نفسه (الترتيب الزمني محفوظ بعد البحث)؛ لا منطق ظهور ولا ترتيب ولا فلترة هنا، ولا محرك ثانٍ ولا تخزين. */
let recentCarsQuery = '';

/* (11.7-A) وضع الخادم: GET /v1/public/cars (كل المصادر، الأحدث أولًا: ترتيب الخادم id DESC) */
function _recentQuery() { const t = BackendCatalog.searchTerm(recentCarsQuery); return t ? { q: t } : {}; }
function _recentRemoteDone() { if (currentRoute === 'recentCars') { const l = document.getElementById('recentCarsList'); if (l) l.innerHTML = renderRecentCarsList(); } }
function _recentReload() { BackendCatalog.reload('/v1/public/cars', _recentQuery(), _recentRemoteDone); _recentRemoteDone(); }
function _recentMore() { BackendCatalog.more('/v1/public/cars', _recentQuery(), _recentRemoteDone); _recentRemoteDone(); }

function renderRecentCarsList() {
  const hasQ = !!String(recentCarsQuery || '').trim();
  let results, st = null;
  if (BackendCatalog.isEnabled()) {
    st = BackendCatalog.list('/v1/public/cars', _recentQuery(), _recentRemoteDone);
    if (st.status !== 'ready' && st.status !== 'empty') return RemoteState(st, { loading: 'جارٍ تحميل السيارات…', retry: '_recentReload()' });
    results = st.items;
  } else results = getRecentCars({ query: recentCarsQuery });
  if (!results.length) {
    return hasQ
      ? EmptyState({ icon: '🔍', title: 'لم نعثر على سيارات مطابقة لبحثك', hint: 'تأكد من كتابة الماركة أو الموديل أو السنة، أو جرّب كلمة أخرى.',
          actions: [{ label: 'مسح البحث', onclick: 'clearRecentCarsSearch()' }] })
      : EmptyState({ icon: '🆕', title: 'لا توجد سيارات مضافة حديثًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.',
          actions: [{ label: 'العودة للرئيسية', onclick: "go('home')" }] });
  }
  return `<p class="results-count" aria-live="polite">النتائج: ${st ? remoteCountText(results.length, st) : carCountLabel(results.length)}</p><div class="list-grid">${results.map(st ? RemoteCarCard : CarCard).join('')}</div>${st ? RemoteMoreFooter(st, '_recentMore') : ''}`;
}
function onRecentCarsSearch(value) { recentCarsQuery = value; if (BackendCatalog.isEnabled()) { BackendCatalog.debounce(_recentRemoteDone); return; } const l = document.getElementById('recentCarsList'); if (l) l.innerHTML = renderRecentCarsList(); }
function clearRecentCarsSearch() { recentCarsQuery = ''; render(); }

function RecentCarsScreen() {
  return `
  ${DetailBackButton('home', true)}
  <div class="topbar">
    <h1>🆕 السيارات المضافة حديثاً</h1>
    <p class="sub">أحدث السيارات التي أضيفت إلى المنصة</p>
    ${SearchBox('ابحث عن سيارة', 'onRecentCarsSearch', recentCarsQuery)}
  </div>
  <div class="section">
    <div id="recentCarsList">${renderRecentCarsList()}</div>
  </div>`;
}

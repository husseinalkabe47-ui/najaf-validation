/* الرئيسية (المرحلة 10 / الجزء 4) — تحسين العرض فقط على الشاشة القائمة، بلا منطق أعمال هنا:
   • البيانات كلها من getHomeFeed (searchService) فوق المسار العام للظهور؛ والعرض بـCarCard وShowroomCard وEmptyState وAdSlot.
   • البطل: «اعثر على سيارتك بين معارض النجف» + مربع البحث القائم (handleHomeSearch → شاشة البحث الموحّدة).
   • إجراءا اكتشاف بارزان: «وين ألكه هاي السيارة؟» ← السيارات (البحث والفلاتر القائمة)، و«استكشف المعارض على الخريطة» ← الخريطة القائمة.
   • الوصول السريع القائم محفوظ كما هو، ومساحة الإعلان home_banner في موضعها (بين الوصول السريع والسيارات) بلا تغيير.
   • سيارات الأعضاء كما كانت؛ ومعلومات المنصة قسم موجز بلا ادعاءات (لا توثيق ولا ضمان ولا دفع). */

/** البحث من الرئيسية: نص ← شاشة البحث الموحّدة القائمة بنفس النص؛ فارغ/غير نصي ← شاشة السيارات (تصفح + بحث + فلاتر) */
function handleHomeSearch(value) {
  const q = (typeof value === 'string' || typeof value === 'number') ? String(value).trim() : '';
  if (q) go('search', q); else go('cars');
}

/** رأس قسم: عنوان (h2 بمعرّف يشير إليه aria-labelledby) وزر «عرض الكل» اختياري بوجهة القسم القائمة */
function _homeHead(id, title, route, allLabel, showAll) {
  return `<div class="home-head"><h2 id="${id}">${title}</h2>${showAll
    ? `<button type="button" class="link-btn" onclick="go('${route}')" aria-label="${allLabel}">عرض الكل</button>` : ''}</div>`;
}

/* (11.7-A) وضع الخادم: كل قسم يُحمَّل مستقلًا من GET /v1/public/cars|showrooms (أحدث 10) بحالات تحميل/خطأ/فراغ خاصة به؛ لا بيانات محلية. */
const _HOME_SECTIONS = {
  recent: { path: '/v1/public/cars', query: { limit: '10' } },
  cars: { path: '/v1/public/cars', query: { source: 'showroom', limit: '10' } },
  showrooms: { path: '/v1/public/showrooms', query: { limit: '10' } },
  members: { path: '/v1/public/cars', query: { source: 'member', limit: '10' } },
};
function _homeRemoteDone() { if (currentRoute === 'home') render(); }
function _homeRetry() { Object.keys(_HOME_SECTIONS).forEach(k => { const s = _HOME_SECTIONS[k]; if (BackendCatalog.list(s.path, s.query).status === 'error') BackendCatalog.reload(s.path, s.query, _homeRemoteDone); }); render(); }
/** { n, body }: n = عدد العناصر المحمّلة (يحدّد ظهور «عرض الكل») */
function _homeRemoteSection(key, card, empty) {
  const s = _HOME_SECTIONS[key], st = BackendCatalog.list(s.path, s.query, _homeRemoteDone);
  if (st.status === 'ready') return { n: st.items.length, body: `<div class="hscroll">${st.items.map(card).join('')}</div>` };
  if (st.status === 'empty') return { n: 0, body: empty };
  return { n: 0, body: RemoteState(st, { loading: 'جارٍ التحميل…', retry: '_homeRetry()' }) };
}

function HomeScreen() {
  let recentBody, carsBody, showroomsBody, membersBody, recentN, carsN, showroomsN;
  if (BackendCatalog.isEnabled()) {
    const r = _homeRemoteSection('recent', RemoteCarCard, EmptyState({ icon: '🆕', title: 'لا توجد سيارات مضافة حديثًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.' }));
    const c = _homeRemoteSection('cars', RemoteCarCard, EmptyState({ icon: '🚘', title: 'لا توجد سيارات حاليًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.' }));
    const sh = _homeRemoteSection('showrooms', RemoteShowroomCard, EmptyState({ icon: '🏢', title: 'لا توجد معارض', hint: 'ستظهر هنا المعارض فور إضافتها.' }));
    const m = _homeRemoteSection('members', RemoteCarCard, `<p class="sub">لا توجد سيارات أعضاء نشطة بعد.</p>`);
    recentBody = r.body; carsBody = c.body; showroomsBody = sh.body; membersBody = m.body; recentN = r.n; carsN = c.n; showroomsN = sh.n;
  } else {
    const feed = getHomeFeed();
    const recent = getRecentCars({ limit: RECENT_CARS_HOME_LIMIT });   // (ميزة جديدة ج1) موحّد: معارض + أعضاء، الأحدث أولًا، من المسار العام نفسه
    recentBody = recent.length ? `<div class="hscroll">${recent.map(CarCard).join('')}</div>`
      : EmptyState({ icon: '🆕', title: 'لا توجد سيارات مضافة حديثًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.' });
    carsBody = feed.cars.length ? `<div class="hscroll">${feed.cars.map(CarCard).join('')}</div>`
      : EmptyState({ icon: '🚘', title: 'لا توجد سيارات حاليًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.' });
    showroomsBody = feed.showrooms.length ? `<div class="hscroll">${feed.showrooms.map(ShowroomCard).join('')}</div>`
      : EmptyState({ icon: '🏢', title: 'لا توجد معارض', hint: 'ستظهر هنا المعارض فور إضافتها.' });
    membersBody = feed.memberCars.length ? `<div class="hscroll">${feed.memberCars.map(CarCard).join('')}</div>`
      : `<p class="sub">لا توجد سيارات أعضاء نشطة بعد.</p>`;
    recentN = recent.length; carsN = feed.cars.length; showroomsN = feed.showrooms.length;
  }
  const account = AuthorizationService.getAccountEntryPoint();
  return `
  <div class="topbar home-hero">
    <div class="topbar-row home-top"><span class="home-brand">🚗 معارض النجف</span>${AccountButton()}</div>
    <h1 class="home-title">اعثر على سيارتك بين معارض النجف</h1>
    <p class="home-lead">سيارات ومعارض النجف الأشرف في مكان واحد</p>
    ${SearchBox('ابحث عن سيارة أو معرض', '', '', 'handleHomeSearch')}
  </div>
  <div class="section home-actions" role="group" aria-label="طرق الاكتشاف">
    <button type="button" class="home-action primary" onclick="go('cars')">
      <span class="ha-ic" aria-hidden="true">🔎</span>
      <span class="ha-txt"><b>وين ألكه هاي السيارة؟</b><small>ابحث بالماركة أو الموديل واعرف المعرض</small></span>
    </button>
    <button type="button" class="home-action" onclick="go('map')">
      <span class="ha-ic" aria-hidden="true">📍</span>
      <span class="ha-txt"><b>استكشف المعارض على الخريطة</b><small>افتح مواقع المعارض في تطبيق الخرائط</small></span>
    </button>
  </div>
  <section class="section home-section" aria-labelledby="homeQuickTitle">
    <h2 id="homeQuickTitle">وصول سريع</h2>
    <div class="explore-grid">
      <button class="explore-btn" onclick="go('cars')"><span class="ic">🚘</span>السيارات</button>
      <button class="explore-btn" onclick="go('showrooms')"><span class="ic">🏢</span>المعارض</button>
      <button class="explore-btn" onclick="go('map')"><span class="ic">📍</span>الخريطة</button>
      <button class="explore-btn" onclick="go('favorites')"><span class="ic">❤️</span>المفضلة</button>
      <button class="explore-btn" onclick="go('memberCars')"><span class="ic">🧑‍🤝‍🧑</span>سيارات الأعضاء</button>
      <button class="explore-btn" onclick="go('${account.route}')"><span class="ic">${account.icon}</span>${account.label}</button>
    </div>
  </section>
  ${AdSlot('home_banner')}
  <section id="homeRecent" class="section home-section" aria-labelledby="homeRecentTitle">
    ${_homeHead('homeRecentTitle', '🆕 السيارات المضافة حديثاً', 'recentCars', 'عرض كل السيارات المضافة حديثاً', recentN > 0)}
    <p class="sub">أحدث السيارات التي أضيفت إلى معارض النجف</p>
    ${recentBody}
  </section>
  <section id="homeCars" class="section home-section" aria-labelledby="homeCarsTitle">
    ${_homeHead('homeCarsTitle', '🔥 أحدث السيارات', 'cars', 'عرض كل السيارات', carsN > 0)}
    ${carsBody}
  </section>
  <section id="homeShowrooms" class="section home-section" aria-labelledby="homeShowroomsTitle">
    ${_homeHead('homeShowroomsTitle', '🏢 معارض النجف', 'showrooms', 'عرض كل المعارض', showroomsN > 0)}
    ${showroomsBody}
  </section>
  <section id="homeValue" class="section home-section home-value" aria-labelledby="homeValueTitle">
    <h2 id="homeValueTitle">لماذا معارض النجف؟</h2>
    <div class="info-block">
      <ul class="value-list">
        <li><span class="vi" aria-hidden="true">🚘</span>تصفح سيارات المعارض في النجف</li>
        <li><span class="vi" aria-hidden="true">⚖️</span>قارن السيارات والأسعار والمواصفات</li>
        <li><span class="vi" aria-hidden="true">🏢</span>اعرف بأي معرض موجودة السيارة</li>
        <li><span class="vi" aria-hidden="true">📞</span>تواصل مباشرة مع المعرض</li>
      </ul>
    </div>
  </section>
  <section id="homeMembers" class="section home-section" aria-labelledby="homeMembersTitle">
    ${_homeHead('homeMembersTitle', '🧑‍🤝‍🧑 سيارات الأعضاء', 'memberCars', 'عرض كل سيارات الأعضاء', true)}
    ${membersBody}
  </section>`;
}

/* ShowroomsScreen — دليل المعارض العام. (UX ج6) بحث بارز + سطر مساعد + عدّاد نتائج ثم البطاقات مباشرة تحته.
   المصدر الوحيد: searchShowrooms (خدمة البحث القائمة: الاسم والعنوان، توحيد NFKC/الأرقام) ← getVisibleShowrooms (visibilityService) ← ShowroomCard.
   لا فلترة محلية ولا قاعدة ظهور هنا، ولا فلاتر متقدمة (لا يوجد نظام فلاتر للمعارض أصلًا فلا زر «تصفية»). */
let showroomsSearchQuery = '';
/** صيغة عدد المعارض بالعربية (نظير carCountLabel): معرض واحد / معرضان / 3–10 معارض / 11+ معرضًا */
function showroomCountLabel(n) {
  if (typeof n !== 'number' || !Number.isInteger(n) || n < 1) return '';
  if (n === 1) return 'معرض واحد';
  if (n === 2) return 'معرضان';
  return n <= 10 ? `${n} معارض` : `${n} معرضًا`;
}

/* (11.7-A) وضع الخادم: GET /v1/public/showrooms?q (انظر cars.js للقيود). لا عدّاد سيارات في البطاقة (غير موجود في العقد). */
const _SHOWROOMS_PATH = '/v1/public/showrooms';
function _showroomsRemote() { return BackendCatalog.isEnabled(); }
function _showroomsQuery() { const t = BackendCatalog.searchTerm(showroomsSearchQuery); return t ? { q: t } : {}; }
function _showroomsRemoteDone() { if (currentRoute === 'showrooms') { const l = document.getElementById('showroomsList'); if (l) l.innerHTML = renderShowroomsList(); } }
function _showroomsReload() { BackendCatalog.reload(_SHOWROOMS_PATH, _showroomsQuery(), _showroomsRemoteDone); _showroomsRemoteDone(); }
function _showroomsMore() { BackendCatalog.more(_SHOWROOMS_PATH, _showroomsQuery(), _showroomsRemoteDone); _showroomsRemoteDone(); }

function renderShowroomsList() {
  let results, st = null;
  if (_showroomsRemote()) {
    st = BackendCatalog.list(_SHOWROOMS_PATH, _showroomsQuery(), _showroomsRemoteDone);
    if (st.status !== 'ready' && st.status !== 'empty') return RemoteState(st, { loading: 'جارٍ تحميل المعارض…', retry: '_showroomsReload()' });
    results = st.items;
  } else results = searchShowrooms(showroomsSearchQuery);
  if (results.length === 0) {
    if (!showroomsSearchQuery.trim()) return EmptyState({ icon: '🏢', title: 'لا توجد معارض', hint: 'ستظهر هنا المعارض فور إضافتها.' });
    return EmptyState({ icon: '🔍', title: 'لم نعثر على معارض مطابقة لبحثك', hint: 'جرّب اسم المعرض أو جزءًا من العنوان.',
      actions: [{ label: 'مسح البحث', onclick: 'clearShowroomsSearch()' }] });
  }
  return `<p class="results-count" aria-live="polite">النتائج: ${showroomCountLabel(results.length)}${st && st.nextBefore ? ' (والمزيد)' : ''}</p><div class="list-grid">${results.map(st ? RemoteShowroomCard : ShowroomCard).join('')}</div>${st ? RemoteMoreFooter(st, '_showroomsMore') : ''}`;
}

function onShowroomsSearch(value) {
  showroomsSearchQuery = value;
  if (_showroomsRemote()) { BackendCatalog.debounce(_showroomsRemoteDone); return; }
  const list = document.getElementById('showroomsList');
  if (list) list.innerHTML = renderShowroomsList();
}
function clearShowroomsSearch() { showroomsSearchQuery = ''; render(); }

function ShowroomsScreen() {
  return `
  <div class="topbar">
    <h1>🏢 معارض السيارات</h1>
    <p class="sub">اسم المعرض، العنوان أو المنطقة</p>
    ${SearchBox('ابحث عن معرض', 'onShowroomsSearch', showroomsSearchQuery)}
  </div>
  <div class="section">
    <div id="showroomsList">${renderShowroomsList()}</div>
  </div>`;
}

// HTTP contract of the authentication routes. The pure helpers and the route wiring always run; the Fastify tests need
// `fastify` (installed in CI) and are SKIPPED visibly when it is missing, never silently passed.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { RATE_LIMITS } from '../../src/auth/policy.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { bearerToken, isJsonContentType, registerAuthRoutes, toAuthHttp } from '../../src/auth/routes.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AccountApi, AuthApi, AuthResult, OtpApi } from '../../src/auth/types.ts';

const ACCESS = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.' + 'A'.repeat(60) + '.' + 'B'.repeat(43);
const REFRESH = 'nsj_' + 'A'.repeat(43);
const user = { id: '7', name: 'علي حسين', phone: '+9647701234567', role: 'user', status: 'active', phoneVerified: false, createdAt: '2026-01-02T03:04:05.000Z' };
const grant: AuthResult = { user, session: { accessToken: ACCESS, accessExpiresAt: '2026-01-02T03:19:05.000Z', refreshToken: REFRESH, refreshExpiresAt: '2026-02-01T00:00:00.000Z' } };

describe('bearerToken', () => {
  it('extracts exactly one token from a well-formed header', () => {
    assert.equal(bearerToken(`Bearer ${ACCESS}`), ACCESS);
    assert.equal(bearerToken(`bearer ${ACCESS}`), ACCESS);
    assert.equal(bearerToken(`BEARER ${ACCESS}`), ACCESS);
  });
  it('returns undefined for everything else', () => {
    for (const h of [undefined, null, 5, '', 'Bearer', 'Bearer ', `Bearer  ${ACCESS}`, `Bearer ${ACCESS} extra`, `Basic ${ACCESS}`, ACCESS, ` Bearer ${ACCESS}`, [`Bearer ${ACCESS}`], `Bearer ${ACCESS}\n`]) {
      assert.equal(bearerToken(h), undefined, String(h));
    }
  });
});

describe('toAuthHttp: fixed status and generic message per error code', () => {
  it('maps every AuthError', () => {
    assert.deepEqual(toAuthHttp(new AuthError('conflict')), { status: 409, code: 'conflict', message: 'This account cannot be registered' });
    assert.deepEqual(toAuthHttp(new AuthError('invalid_credentials')), { status: 401, code: 'invalid_credentials', message: 'Invalid phone number or password' });
    assert.deepEqual(toAuthHttp(new AuthError('unauthorized')), { status: 401, code: 'unauthorized', message: 'Authentication required' });
    assert.deepEqual(toAuthHttp(new AuthError('validation_failed', [{ field: 'name', code: 'too_short' }])), { status: 400, code: 'validation_failed', message: 'The submitted data is not valid', fields: [{ field: 'name', code: 'too_short' }] });
  });
  it('maps the one-time-code errors: one generic 400 for every code failure, and 429 with its Retry-After hint', () => {
    assert.deepEqual(toAuthHttp(new AuthError('invalid_code')), { status: 400, code: 'invalid_code', message: 'The code is invalid or has expired' });
    assert.deepEqual(toAuthHttp(new AuthError('rate_limited')), { status: 429, code: 'rate_limited', message: 'Too many requests' });
    assert.deepEqual(toAuthHttp(new AuthError('rate_limited', undefined, 42)), { status: 429, code: 'rate_limited', message: 'Too many requests', retryAfterSeconds: 42 });
  });
  it('maps the wrong-current-password refusal to a generic 400 (not 401: the session itself is fine)', () => {
    assert.deepEqual(toAuthHttp(new AuthError('invalid_current_password')), { status: 400, code: 'invalid_current_password', message: 'The current password is incorrect' });
  });
  it('ignores errors that are not AuthErrors (the global handler deals with them)', () => {
    for (const e of [new Error('boom'), 'x', null, { code: 'conflict' }]) assert.equal(toAuthHttp(e), undefined);
  });
});

describe('isJsonContentType', () => {
  it('accepts application/json with or without parameters, any case', () => {
    for (const ct of ['application/json', 'application/json; charset=utf-8', 'application/json;charset=UTF-8', 'APPLICATION/JSON', ' application/json ', 'application/json ; charset=utf-8']) assert.equal(isJsonContentType(ct), true, ct);
  });
  it('rejects everything else, including the types Fastify would otherwise parse (text/plain)', () => {
    for (const ct of ['text/plain', 'text/plain; charset=utf-8', 'text/json', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x', 'application/vnd.api+json', 'application/jsonx', 'application/json/x', 'application/xml', '', undefined, null, 5, ['application/json']]) {
      assert.equal(isJsonContentType(ct), false, String(ct));
    }
  });
});

// A minimal stand-in for the Fastify instance: it records the routes and hooks the plugin registers, so the wiring is
// verified here without Fastify. (The same behavior is verified end to end through real Fastify in the tests below, in CI.)
type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
function recordRoutes(withLimiter: boolean, withOtp: boolean | OtpApi = false, auth: AuthApi = fakeAuthApi(), account?: AccountApi) {
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const app = { get: add('GET'), post: add('POST') };
  const limiter = createMemoryRateLimiter();
  registerAuthRoutes(app as never, { auth, ...(withOtp ? { otp: typeof withOtp === 'object' ? withOtp : fakeOtp() } : {}), ...(account ? { account } : {}), ...(withLimiter ? { rateLimiter: limiter } : {}) });
  return routes;
}
function fakeAccount(over: Partial<AccountApi> = {}): AccountApi {
  return {
    changePassword: async () => ({ status: 'password_changed' }),
    logoutAll: async () => ({ status: 'signed_out_everywhere' }),
    ...over,
  };
}
function fakeOtp(over: Partial<OtpApi> = {}): OtpApi {
  return {
    requestPhoneVerification: async () => ({ status: 'sent' }),
    confirmPhoneVerification: async () => ({ ...user, phoneVerified: true }),
    requestPasswordReset: async () => ({ status: 'accepted' }),
    resetPassword: async () => ({ status: 'password_reset' }),
    ...over,
  };
}
function fakeAuthApi(): AuthApi {
  return { register: async () => grant, login: async () => grant, refresh: async () => grant, authenticate: async () => null, logout: async () => {} };
}
function fakeReply() {
  const sent: { status?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}
const BODY_ROUTES = ['/v1/auth/register', '/v1/auth/login', '/v1/auth/refresh', '/v1/auth/logout'];

describe('authentication routes: wiring (no Fastify needed)', () => {
  it('registers exactly the five routes', () => {
    assert.deepEqual(recordRoutes(true).map((r) => `${r.method} ${r.path}`).sort(), ['GET /v1/auth/me', 'POST /v1/auth/login', 'POST /v1/auth/logout', 'POST /v1/auth/refresh', 'POST /v1/auth/register']);
  });

  it('every route that takes a body has a 4 KiB limit, a rate-limit hook FIRST and the JSON-only hook second; /me has neither', () => {
    const byPath = Object.fromEntries(recordRoutes(true).map((r) => [r.path, r.opts]));
    for (const path of BODY_ROUTES) {
      assert.equal(byPath[path]?.bodyLimit, 4096, path);
      assert.equal(byPath[path]?.onRequest?.length, 2, path);
    }
    assert.equal(byPath['/v1/auth/me'], undefined);
  });

  it('without a rate limiter only the JSON-only hook is attached (the behavior before rate limiting existed)', () => {
    for (const r of recordRoutes(false).filter((x) => BODY_ROUTES.includes(x.path))) assert.equal(r.opts?.onRequest?.length, 1, r.path);
  });

  it('the JSON-only hook answers 415 with a generic body for every non-JSON content type', async () => {
    for (const path of BODY_ROUTES) {
      const hooks = recordRoutes(true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      for (const ct of ['text/plain', 'text/plain; charset=utf-8', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x', 'application/vnd.api+json']) {
        const { reply, sent } = fakeReply();
        const out = await hooks[1]!({ headers: { 'content-type': ct }, id: 'req-1', ip: '1.1.1.1', log: { warn() {} } }, reply);
        assert.equal(out, reply);
        assert.equal(sent.status, 415, `${path} ${ct}`);
        assert.deepEqual(sent.body, { error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: 'req-1' } });
      }
    }
  });

  it('the JSON-only hook lets application/json (with or without charset) and a request with no content type continue', async () => {
    for (const path of BODY_ROUTES) {
      const hooks = recordRoutes(true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      for (const headers of [{ 'content-type': 'application/json' }, { 'content-type': 'application/json; charset=utf-8' }, {}]) {
        const { reply, sent } = fakeReply();
        assert.equal(await hooks[1]!({ headers, id: 'r' }, reply), undefined, `${path} ${JSON.stringify(headers)}`);
        assert.equal(sent.status, undefined);
      }
    }
  });

  it('the rate-limit hook of each route enforces that route\'s own limit, per client address, and answers 429 with Retry-After', async () => {
    for (const [path, route] of [['/v1/auth/register', 'register'], ['/v1/auth/login', 'login'], ['/v1/auth/refresh', 'refresh'], ['/v1/auth/logout', 'logout']] as const) {
      const hooks = recordRoutes(true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      const req = { ip: '203.0.113.9', id: 'r1', headers: {}, log: { warn() {} } };
      const limit = RATE_LIMITS[route].limit;
      for (let i = 0; i < limit; i++) assert.equal(await hooks[0]!(req, fakeReply().reply), undefined, `${route} #${i + 1}`);
      const { reply, sent } = fakeReply();
      assert.equal(await hooks[0]!(req, reply), reply, `${route} is limited after ${limit}`);
      assert.equal(sent.status, 429);
      assert.equal(sent.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
      assert.equal(await hooks[0]!({ ...req, ip: '203.0.113.10' }, fakeReply().reply), undefined, 'another address is unaffected');
    }
  });
});

const OTP_BODY_ROUTES = ['/v1/auth/phone/verify/confirm', '/v1/auth/password/forgot', '/v1/auth/password/reset'];
const OTP_ROUTES = ['/v1/auth/phone/verify/request', ...OTP_BODY_ROUTES];
const OTP_LIMITS = { '/v1/auth/phone/verify/request': 'phoneVerifyRequest', '/v1/auth/phone/verify/confirm': 'phoneVerifyConfirm', '/v1/auth/password/forgot': 'passwordForgot', '/v1/auth/password/reset': 'passwordReset' } as const;

describe('one-time code routes: wiring (no Fastify needed)', () => {
  it('exist only when an OtpApi is supplied; with it there are nine routes', () => {
    assert.equal(recordRoutes(true).length, 5);
    assert.deepEqual(recordRoutes(true, true).map((r) => `${r.method} ${r.path}`).sort(), [
      'GET /v1/auth/me', 'POST /v1/auth/login', 'POST /v1/auth/logout', 'POST /v1/auth/password/forgot', 'POST /v1/auth/password/reset',
      'POST /v1/auth/phone/verify/confirm', 'POST /v1/auth/phone/verify/request', 'POST /v1/auth/refresh', 'POST /v1/auth/register',
    ]);
  });

  it('the three body routes have the 4 KiB limit, the rate limit first and the JSON-only hook second', () => {
    const byPath = Object.fromEntries(recordRoutes(true, true).map((r) => [r.path, r.opts]));
    for (const path of OTP_BODY_ROUTES) {
      assert.equal(byPath[path]?.bodyLimit, 4096, path);
      assert.equal(byPath[path]?.onRequest?.length, 2, path);
    }
  });

  it('the authenticated request route takes no body: only a rate limit, and nothing at all without a limiter', () => {
    const withLimiter = recordRoutes(true, true).find((r) => r.path === '/v1/auth/phone/verify/request');
    assert.equal(withLimiter?.opts?.onRequest?.length, 1);
    assert.equal(withLimiter?.opts?.bodyLimit, undefined);
    const without = recordRoutes(false, true).find((r) => r.path === '/v1/auth/phone/verify/request');
    assert.equal(without?.opts?.onRequest, undefined);
  });

  it('each new route enforces its OWN rate limit per client address, with 429 and Retry-After', async () => {
    for (const path of OTP_ROUTES) {
      const route = OTP_LIMITS[path as keyof typeof OTP_LIMITS];
      const hooks = recordRoutes(true, true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      const req = { ip: '203.0.113.9', id: 'r1', headers: {}, log: { warn() {} } };
      for (let i = 0; i < RATE_LIMITS[route].limit; i++) assert.equal(await hooks[0]!(req, fakeReply().reply), undefined, `${route} #${i + 1}`);
      const { reply, sent } = fakeReply();
      assert.equal(await hooks[0]!(req, reply), reply, `${route} is limited`);
      assert.equal(sent.status, 429);
      assert.equal(sent.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
    }
  });

  it('the three body routes refuse every non-JSON content type with a generic 415', async () => {
    for (const path of OTP_BODY_ROUTES) {
      const hooks = recordRoutes(true, true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      for (const ct of ['text/plain', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x']) {
        const { reply, sent } = fakeReply();
        assert.equal(await hooks[1]!({ headers: { 'content-type': ct }, id: 'req-1', ip: '1.1.1.1', log: { warn() {} } }, reply), reply);
        assert.equal(sent.status, 415, `${path} ${ct}`);
      }
    }
  });

  it('the limits are strict enough for what they protect: forgotten-password requests are no looser than registration per window', () => {
    assert.ok(RATE_LIMITS.passwordForgot.limit <= RATE_LIMITS.phoneVerifyConfirm.limit);
    for (const r of ['phoneVerifyRequest', 'phoneVerifyConfirm', 'passwordForgot', 'passwordReset'] as const) assert.ok(RATE_LIMITS[r].limit <= 10 && RATE_LIMITS[r].windowSeconds >= 600, r);
  });
});

describe('one-time code route handlers (run directly, no Fastify needed)', () => {
  const authed = { ...fakeAuthApi(), authenticate: async (t: string | undefined) => (t === ACCESS ? { user, sessionId: 'fam-1' } : null) };
  const run = async (otp: OtpApi, path: string, request: Record<string, unknown>) => {
    const route = recordRoutes(false, otp, authed).find((r) => r.path === path)!;
    const { reply, sent } = fakeReply();
    await route.handler({ id: 'req-1', ip: '1.1.1.1', headers: {}, body: undefined, ...request }, reply);
    return sent;
  };
  const spy = () => {
    const calls: unknown[][] = [];
    const otp = fakeOtp({
      requestPhoneVerification: async (...a) => (calls.push(['request', ...a]), { status: 'sent' }),
      confirmPhoneVerification: async (...a) => (calls.push(['confirm', ...a]), { ...user, phoneVerified: true }),
      requestPasswordReset: async (...a) => (calls.push(['forgot', ...a]), { status: 'accepted' }),
      resetPassword: async (...a) => (calls.push(['reset', ...a]), { status: 'password_reset' }),
    });
    return { otp, calls };
  };
  const bearer = { authorization: `Bearer ${ACCESS}` };

  it('the two phone-verification routes REFUSE a request without a valid access token (401 + WWW-Authenticate), and the service is never called', async () => {
    for (const path of ['/v1/auth/phone/verify/request', '/v1/auth/phone/verify/confirm']) {
      for (const headers of [{}, { authorization: 'Bearer garbage' }, { authorization: `Bearer ${REFRESH}` }, { authorization: ACCESS }] as Array<Record<string, string>>) {
        const { otp, calls } = spy();
        const sent = await run(otp, path, { headers, body: { code: '123456' } });
        assert.equal(sent.status, 401, `${path} ${JSON.stringify(headers)}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
        assert.equal((sent.body as { error: { code: string } }).error.code, 'unauthorized');
        assert.equal(calls.length, 0);
      }
    }
  });

  it('the user id given to the service is the one in the verified token: a user id in the request is never used', async () => {
    const { otp, calls } = spy();
    const sent = await run(otp, '/v1/auth/phone/verify/request', { headers: bearer, body: { userId: '999' }, params: { id: '999' } });
    assert.equal(sent.status, 202);
    assert.deepEqual(sent.body, { status: 'sent' });
    const confirmed = await run(otp, '/v1/auth/phone/verify/confirm', { headers: bearer, body: { code: '123456', userId: '999' } });
    assert.equal(confirmed.status, 200);
    assert.deepEqual(calls, [['request', '7'], ['confirm', '7', { code: '123456', userId: '999' }]], 'the body is the service\'s to validate (it rejects the stray field)');
  });

  it('request: 200 for an already-verified user, 429 + Retry-After when throttled', async () => {
    const done = await run(fakeOtp({ requestPhoneVerification: async () => ({ status: 'already_verified' }) }), '/v1/auth/phone/verify/request', { headers: bearer });
    assert.equal(done.status, 200);
    assert.deepEqual(done.body, { status: 'already_verified' });
    const slow = await run(fakeOtp({ requestPhoneVerification: async () => { throw new AuthError('rate_limited', undefined, 37); } }), '/v1/auth/phone/verify/request', { headers: bearer });
    assert.equal(slow.status, 429);
    assert.equal(slow.headers['retry-after'], '37');
    assert.deepEqual(slow.body, { error: { code: 'rate_limited', message: 'Too many requests', requestId: 'req-1' } });
  });

  it('confirm: invalid_code is a generic 400 that never echoes the code', async () => {
    const sent = await run(fakeOtp({ confirmPhoneVerification: async () => { throw new AuthError('invalid_code'); } }), '/v1/auth/phone/verify/confirm', { headers: bearer, body: { code: '654321' } });
    assert.equal(sent.status, 400);
    assert.deepEqual(sent.body, { error: { code: 'invalid_code', message: 'The code is invalid or has expired', requestId: 'req-1' } });
    assert.ok(!JSON.stringify(sent.body).includes('654321'));
  });

  it('forgot and reset need NO authentication (the caller is locked out), and pass the body straight to the service', async () => {
    const { otp, calls } = spy();
    const forgot = await run(otp, '/v1/auth/password/forgot', { body: { phone: '07701234567' } });
    assert.equal(forgot.status, 202);
    assert.deepEqual(forgot.body, { status: 'accepted' });
    const reset = await run(otp, '/v1/auth/password/reset', { body: { phone: '07701234567', code: '123456', newPassword: 'N3w-Passw0rd' } });
    assert.equal(reset.status, 200);
    assert.deepEqual(reset.body, { status: 'password_reset' });
    assert.deepEqual(calls, [['forgot', { phone: '07701234567' }], ['reset', { phone: '07701234567', code: '123456', newPassword: 'N3w-Passw0rd' }]]);
  });

  it('forgot: the answer is identical whatever the service did (the HTTP layer adds nothing that could tell accounts apart)', async () => {
    const sents = [] as unknown[];
    for (const body of [{ phone: '07701234567' }, { phone: '07700000000' }]) sents.push(await run(fakeOtp(), '/v1/auth/password/forgot', { body }));
    assert.equal(JSON.stringify(sents[0]), JSON.stringify(sents[1]));
  });

  it('reset: every code failure is one generic 400, validation failures name only the field, and secrets are never echoed', async () => {
    const wrong = await run(fakeOtp({ resetPassword: async () => { throw new AuthError('invalid_code'); } }), '/v1/auth/password/reset', { body: { phone: '07701234567', code: '000000', newPassword: 'Sup3r-Secret-Pass' } });
    assert.equal(wrong.status, 400);
    assert.equal((wrong.body as { error: { code: string } }).error.code, 'invalid_code');
    const weak = await run(fakeOtp({ resetPassword: async () => { throw new AuthError('validation_failed', [{ field: 'newPassword', code: 'too_short' }]); } }), '/v1/auth/password/reset', { body: { newPassword: 'x' } });
    assert.equal(weak.status, 400);
    assert.deepEqual((weak.body as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'too_short' }]);
    for (const sent of [wrong, weak]) assert.ok(!JSON.stringify(sent.body).includes('Sup3r-Secret-Pass') && !JSON.stringify(sent.body).includes('000000'));
  });

  it('an unexpected service failure is NOT turned into a friendly answer: it propagates to the global handler (opaque 500)', async () => {
    const route = recordRoutes(false, fakeOtp({ requestPasswordReset: async () => { throw new Error('database exploded: password=hunter2'); } }), authed).find((r) => r.path === '/v1/auth/password/forgot')!;
    await assert.rejects(route.handler({ id: 'r', ip: '1.1.1.1', headers: {}, body: { phone: '07701234567' } }, fakeReply().reply), /database exploded/);
  });
});

const ACCOUNT_ROUTES = ['/v1/auth/password/change', '/v1/auth/logout/all'];

describe('account security routes: wiring and handlers (no Fastify needed)', () => {
  const authed = { ...fakeAuthApi(), authenticate: async (t: string | undefined) => (t === ACCESS ? { user, sessionId: 'fam-1' } : null) };
  const bearer = { authorization: `Bearer ${ACCESS}` };
  const run = async (account: AccountApi, path: string, request: Record<string, unknown>) => {
    const route = recordRoutes(false, false, authed, account).find((r) => r.path === path)!;
    const { reply, sent } = fakeReply();
    await route.handler({ id: 'req-1', ip: '1.1.1.1', headers: {}, body: undefined, ...request }, reply);
    return sent;
  };
  const spy = () => {
    const calls: unknown[][] = [];
    const account = fakeAccount({
      changePassword: async (...a) => (calls.push(['change', ...a]), { status: 'password_changed' }),
      logoutAll: async (...a) => (calls.push(['logoutAll', ...a]), { status: 'signed_out_everywhere' }),
    });
    return { account, calls };
  };

  it('exist only when an AccountApi is supplied', () => {
    assert.equal(recordRoutes(true).length, 5);
    assert.equal(recordRoutes(true, true).length, 9);
    assert.deepEqual(recordRoutes(true, false, fakeAuthApi(), fakeAccount()).map((r) => r.path).filter((p) => ACCOUNT_ROUTES.includes(p)).sort(), ACCOUNT_ROUTES.slice().sort());
    assert.equal(recordRoutes(true, true, fakeAuthApi(), fakeAccount()).length, 11);
  });

  it('change password: 4 KiB body, the rate limit first, then the JSON-only hook; sign-out-all takes no body: only the rate limit', () => {
    const byPath = Object.fromEntries(recordRoutes(true, false, fakeAuthApi(), fakeAccount()).map((r) => [r.path, r.opts]));
    assert.equal(byPath['/v1/auth/password/change']?.bodyLimit, 4096);
    assert.equal(byPath['/v1/auth/password/change']?.onRequest?.length, 2);
    assert.equal(byPath['/v1/auth/logout/all']?.onRequest?.length, 1);
    assert.equal(byPath['/v1/auth/logout/all']?.bodyLimit, undefined);
  });

  it('each route enforces its OWN rate limit per client address (429 + Retry-After); change password refuses non-JSON bodies (415)', async () => {
    for (const [path, route] of [['/v1/auth/password/change', 'passwordChange'], ['/v1/auth/logout/all', 'logoutAll']] as const) {
      const hooks = recordRoutes(true, false, fakeAuthApi(), fakeAccount()).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      const req = { ip: '203.0.113.9', id: 'r1', headers: {}, log: { warn() {} } };
      for (let i = 0; i < RATE_LIMITS[route].limit; i++) assert.equal(await hooks[0]!(req, fakeReply().reply), undefined, `${route} #${i + 1}`);
      const { reply, sent } = fakeReply();
      assert.equal(await hooks[0]!(req, reply), reply);
      assert.equal(sent.status, 429);
      assert.equal(sent.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
    }
    const jsonHook = (recordRoutes(true, false, fakeAuthApi(), fakeAccount()).find((r) => r.path === '/v1/auth/password/change')?.opts?.onRequest as Hook[])[1]!;
    for (const ct of ['text/plain', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x']) {
      const { reply, sent } = fakeReply();
      assert.equal(await jsonHook({ headers: { 'content-type': ct }, id: 'r', ip: '1.1.1.1', log: { warn() {} } }, reply), reply);
      assert.equal(sent.status, 415, ct);
    }
  });

  it('both routes REFUSE a request without a valid ACCESS token (401 + WWW-Authenticate); the service is never reached', async () => {
    for (const path of ACCOUNT_ROUTES) {
      for (const headers of [{}, { authorization: 'Bearer garbage' }, { authorization: `Bearer ${REFRESH}` }, { authorization: ACCESS }, { authorization: `Basic ${ACCESS}` }] as Array<Record<string, string>>) {
        const { account, calls } = spy();
        const sent = await run(account, path, { headers, body: { currentPassword: 'a', newPassword: 'bbbbbb' } });
        assert.equal(sent.status, 401, `${path} ${JSON.stringify(headers)}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
        assert.equal((sent.body as { error: { code: string } }).error.code, 'unauthorized');
        assert.equal(calls.length, 0);
      }
    }
  });

  it('OWNERSHIP: the service receives the user id from the verified token, never one named in the body, params or query', async () => {
    const { account, calls } = spy();
    const hostile = { userId: '999', user_id: '999', id: '999' };
    const changed = await run(account, '/v1/auth/password/change', { headers: bearer, body: { currentPassword: 'Old-Passw0rd', newPassword: 'N3w-Passw0rd', ...hostile }, params: hostile, query: hostile });
    assert.equal(changed.status, 200);
    assert.deepEqual(changed.body, { status: 'password_changed' });
    const out = await run(account, '/v1/auth/logout/all', { headers: bearer, body: hostile, params: hostile, query: hostile });
    assert.equal(out.status, 204);
    assert.deepEqual(calls.map((c) => [c[0], c[1]]), [['change', '7'], ['logoutAll', '7']], 'always the token\'s user');
    assert.deepEqual(calls[0]![3], { requestId: 'req-1' }, 'the request id is passed along for the audit event');
    assert.deepEqual(calls[1]![2], { requestId: 'req-1' });
  });

  it('change password: the body goes to the service untouched (it validates and REJECTS a stray user id); wrong password is a generic 400', async () => {
    const { calls, account } = spy();
    await run(account, '/v1/auth/password/change', { headers: bearer, body: { currentPassword: 'a', newPassword: 'b', userId: '999' } });
    assert.deepEqual(calls[0]![2], { currentPassword: 'a', newPassword: 'b', userId: '999' });
    const wrong = await run(fakeAccount({ changePassword: async () => { throw new AuthError('invalid_current_password'); } }), '/v1/auth/password/change', { headers: bearer, body: { currentPassword: 'Sup3r-Secret-Old', newPassword: 'Sup3r-Secret-New' } });
    assert.equal(wrong.status, 400);
    assert.deepEqual(wrong.body, { error: { code: 'invalid_current_password', message: 'The current password is incorrect', requestId: 'req-1' } });
    assert.ok(!JSON.stringify(wrong.body).includes('Sup3r-Secret'));
  });

  it('validation failures (weak or same password) name only the field and never echo a password', async () => {
    const weak = await run(fakeAccount({ changePassword: async () => { throw new AuthError('validation_failed', [{ field: 'newPassword', code: 'same_as_current' }]); } }), '/v1/auth/password/change', { headers: bearer, body: { currentPassword: 'Same-Passw0rd', newPassword: 'Same-Passw0rd' } });
    assert.equal(weak.status, 400);
    assert.deepEqual((weak.body as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'same_as_current' }]);
    assert.ok(!JSON.stringify(weak.body).includes('Same-Passw0rd'));
  });

  it('a suspended or deleted account is refused like any invalid token (the service answers unauthorized)', async () => {
    const sent = await run(fakeAccount({ logoutAll: async () => { throw new AuthError('unauthorized'); } }), '/v1/auth/logout/all', { headers: bearer });
    assert.equal(sent.status, 401);
    assert.equal(sent.headers['www-authenticate'], 'Bearer');
  });

  it('sign-out-all answers 204 with NO body', async () => {
    const sent = await run(fakeAccount(), '/v1/auth/logout/all', { headers: bearer });
    assert.equal(sent.status, 204);
    assert.equal(sent.body, undefined);
  });

  it('an unexpected service failure propagates to the global handler (an opaque 500), never a friendly answer', async () => {
    const route = recordRoutes(false, false, authed, fakeAccount({ logoutAll: async () => { throw new Error('database exploded: password=hunter2'); } })).find((r) => r.path === '/v1/auth/logout/all')!;
    await assert.rejects(route.handler({ id: 'r', ip: '1.1.1.1', headers: bearer, body: undefined }, fakeReply().reply), /database exploded/);
  });
});

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let reason: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'silent', NODE_ENV: 'test' });
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };

function fakeAuth(over: Partial<AuthApi> = {}): AuthApi {
  return {
    register: async () => grant,
    login: async () => grant,
    refresh: async () => grant,
    authenticate: async (t) => (t === ACCESS ? { user, sessionId: 'fam-1' } : null),
    logout: async () => {},
    ...over,
  };
}
const json = { 'content-type': 'application/json' };

describe('authentication routes over HTTP', { skip: reason }, () => {
  it('are absent when no AuthApi is supplied (existing behavior is untouched)', async () => {
    const app = await buildServer!({ config, db: okDb });
    assert.equal((await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: '{}' })).statusCode, 404);
    assert.equal((await app.inject({ method: 'GET', url: '/healthz' })).statusCode, 200);
    await app.close();
  });

  it('POST /v1/auth/register: 201 with the user and BOTH tokens', async () => {
    const seen: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async (i, c) => (seen.push(i, c), grant) }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: { ...json, 'user-agent': 'UA/1' }, payload: JSON.stringify({ name: 'علي حسين', phone: '07701234567', password: 'secret1' }) });
    assert.equal(r.statusCode, 201);
    assert.deepEqual(r.json(), grant);
    assert.deepEqual(seen, [{ name: 'علي حسين', phone: '07701234567', password: 'secret1' }, { userAgent: 'UA/1' }]);
    assert.equal(r.headers['cache-control'], 'no-store');
    await app.close();
  });

  it('POST /v1/auth/login: 200, and 401 with the generic body for a failure', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ login: async (i) => { if ((i as { password?: string }).password === 'bad') throw new AuthError('invalid_credentials'); return grant; } }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: '07701234567', password: 'good' }) });
    assert.equal(ok.statusCode, 200);
    const bad = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: '07701234567', password: 'bad' }) });
    assert.equal(bad.statusCode, 401);
    const body = bad.json() as { error: { code: string; message: string; requestId: string } };
    assert.deepEqual(Object.keys(body.error).sort(), ['code', 'message', 'requestId']);
    assert.equal(body.error.code, 'invalid_credentials');
    assert.equal(body.error.requestId, bad.headers['x-request-id']);
    await app.close();
  });

  it('POST /v1/auth/refresh: 200 with a new pair; every failure is the same generic 401', async () => {
    const calls: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ refresh: async (i) => { calls.push(i); if ((i as { refreshToken?: string }).refreshToken !== REFRESH) throw new AuthError('unauthorized'); return grant; } }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: REFRESH }) });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), grant);
    const bad = await app.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: 'nsj_' + 'B'.repeat(43) }) });
    assert.equal(bad.statusCode, 401);
    assert.equal(bad.headers['www-authenticate'], 'Bearer');
    assert.equal((bad.json() as { error: { code: string } }).error.code, 'unauthorized');
    assert.equal(calls.length, 2);
    await app.close();
  });

  it('validation errors are 400 with field names and codes only, for register, login, refresh and logout', async () => {
    const fail = () => { throw new AuthError('validation_failed', [{ field: 'refreshToken', code: 'invalid_format' }]); };
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: fail, login: fail, refresh: fail, logout: fail }) });
    for (const url of BODY_ROUTES) {
      const r = await app.inject({ method: 'POST', url, headers: json, payload: JSON.stringify({ password: 'TopSecretValue!', refreshToken: 'nsj_secret-looking-value' }) });
      assert.equal(r.statusCode, 400, url);
      assert.deepEqual((r.json() as { error: { fields: unknown } }).error.fields, [{ field: 'refreshToken', code: 'invalid_format' }]);
      assert.ok(!r.body.includes('TopSecretValue!') && !r.body.includes('secret-looking'));
    }
    await app.close();
  });

  it('a duplicate account is a generic 409', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => { throw new AuthError('conflict'); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: '{}' });
    assert.equal(r.statusCode, 409);
    assert.equal((r.json() as { error: { code: string } }).error.code, 'conflict');
    await app.close();
  });

  it('GET /v1/auth/me: 200 with the public user for a valid ACCESS token; 401 + WWW-Authenticate otherwise (a refresh token is not accepted)', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth() });
    const ok = await app.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${ACCESS}` } });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { user });
    const rejected: Array<Record<string, string>> = [{}, { authorization: 'Bearer ' + ACCESS.slice(0, -2) + 'zz' }, { authorization: 'Bearer garbage' }, { authorization: `Basic ${ACCESS}` }, { authorization: ACCESS }, { authorization: `Bearer ${REFRESH}` }];
    for (const headers of rejected) {
      const r = await app.inject({ method: 'GET', url: '/v1/auth/me', headers });
      assert.equal(r.statusCode, 401, JSON.stringify(headers));
      assert.equal(r.headers['www-authenticate'], 'Bearer');
      assert.equal((r.json() as { error: { code: string } }).error.code, 'unauthorized');
    }
    await app.close();
  });

  it('POST /v1/auth/logout: 204 for a refresh token in the body; the service receives exactly that body', async () => {
    const seen: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ logout: async (i) => void seen.push(i) }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/logout', headers: json, payload: JSON.stringify({ refreshToken: REFRESH }) });
    assert.equal(ok.statusCode, 204);
    assert.equal(ok.body, '');
    assert.deepEqual(seen, [{ refreshToken: REFRESH }]);
    await app.close();
  });

  it('malformed JSON, a non-JSON content type and an oversized body are rejected generically before the service runs', async () => {
    let called = 0;
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => (called++, grant), refresh: async () => (called++, grant) }) });
    const badJson = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: '{"name":' });
    assert.equal(badJson.statusCode, 400);
    assert.equal((badJson.json() as { error: { message: string } }).error.message, 'Bad request');
    // Fastify parses text/plain by default; these endpoints must refuse it (415) before the body is read or the service runs
    for (const url of BODY_ROUTES) {
      for (const contentType of ['text/plain', 'text/plain; charset=utf-8', 'application/x-www-form-urlencoded']) {
        const wrong = await app.inject({ method: 'POST', url, headers: { 'content-type': contentType }, payload: 'name=x&password=y' });
        assert.equal(wrong.statusCode, 415, `${url} ${contentType}`);
        const body = wrong.json() as { error: { code: string; message: string; requestId: string } };
        assert.equal(body.error.code, 'unsupported_media_type');
        assert.equal(body.error.requestId, wrong.headers['x-request-id']);
        assert.ok(!wrong.body.includes('password'), 'the refusal must not echo the body');
      }
    }
    const jsonOk = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: { 'content-type': 'application/json; charset=utf-8' }, payload: '{}' });
    assert.equal(jsonOk.statusCode, 201, 'application/json with a charset is still accepted');
    assert.equal(called, 1);
    called = 0;
    const big = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'x'.repeat(10_000) }) });
    assert.equal(big.statusCode, 413);
    assert.equal(called, 0);
    await app.close();
  });

  it('an unexpected service failure is an opaque 500: no message, no stack', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ login: async () => { throw new Error('secret failure at /srv/app/auth.ts password=hunter2'); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: '{}' });
    assert.equal(r.statusCode, 500);
    assert.ok(!r.body.includes('hunter2') && !r.body.includes('/srv/app'));
    assert.equal((r.json() as { error: { code: string } }).error.code, 'internal_error');
    await app.close();
  });
});

describe('rate limiting over HTTP', { skip: reason }, () => {
  const post = (app: Awaited<ReturnType<BuildServer>>, url: string, remoteAddress: string, extra: Record<string, string> = {}, payload = '{}') =>
    app.inject({ method: 'POST', url, headers: { ...json, ...extra }, payload, remoteAddress });

  it('each sensitive route answers 429 with Retry-After once its limit is spent; the service is not called for the blocked requests', async () => {
    for (const [url, route] of [['/v1/auth/register', 'register'], ['/v1/auth/login', 'login'], ['/v1/auth/refresh', 'refresh'], ['/v1/auth/logout', 'logout']] as const) {
      let called = 0;
      const count = async () => { called++; return grant; };
      const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth({ register: count, login: count, refresh: count, logout: async () => void called++ }) });
      const limit = RATE_LIMITS[route].limit;
      for (let i = 0; i < limit; i++) assert.ok((await post(app, url, '198.51.100.20')).statusCode < 300, `${route} #${i + 1}`);
      const blocked = await post(app, url, '198.51.100.20');
      assert.equal(blocked.statusCode, 429, route);
      assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
      assert.deepEqual(Object.keys((blocked.json() as { error: object }).error).sort(), ['code', 'message', 'requestId']);
      assert.equal((blocked.json() as { error: { code: string } }).error.code, 'rate_limited');
      assert.equal(called, limit, `${route}: blocked requests never reach the service`);
      assert.equal((await post(app, url, '198.51.100.21')).statusCode < 300, true, 'another client is unaffected');
      await app.close();
    }
  });

  it('the limit applies before the body is read: garbage and wrong content types are 429 too once blocked', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth() });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '198.51.100.30');
    assert.equal((await post(app, '/v1/auth/login', '198.51.100.30', {}, '{"broken')).statusCode, 429);
    const text = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: { 'content-type': 'text/plain' }, payload: 'x', remoteAddress: '198.51.100.30' });
    assert.equal(text.statusCode, 429);
    await app.close();
  });

  it('GET /v1/auth/me and the health endpoints are not rate limited', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth() });
    for (let i = 0; i < 200; i++) assert.equal((await app.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${ACCESS}` }, remoteAddress: '198.51.100.40' })).statusCode, 200);
    for (let i = 0; i < 50; i++) assert.equal((await app.inject({ method: 'GET', url: '/healthz', remoteAddress: '198.51.100.40' })).statusCode, 200);
    await app.close();
  });

  it('there is no limiting when no limiter is supplied', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth() });
    for (let i = 0; i < RATE_LIMITS.login.limit + 5; i++) assert.equal((await post(app, '/v1/auth/login', '198.51.100.50')).statusCode, 200);
    await app.close();
  });

  it('by default the client address is the socket address: a spoofed X-Forwarded-For cannot dodge the limit', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth() });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '198.51.100.60', { 'x-forwarded-for': `203.0.113.${i + 1}` });
    assert.equal((await post(app, '/v1/auth/login', '198.51.100.60', { 'x-forwarded-for': '203.0.113.200' })).statusCode, 429);
    await app.close();
  });

  it('behind a TRUSTED proxy the real client address (X-Forwarded-For) is used, so clients are limited separately', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth(), trustProxy: ['10.0.0.0/8'] });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '10.0.0.5', { 'x-forwarded-for': '203.0.113.1' });
    assert.equal((await post(app, '/v1/auth/login', '10.0.0.5', { 'x-forwarded-for': '203.0.113.1' })).statusCode, 429, 'that client is limited');
    assert.equal((await post(app, '/v1/auth/login', '10.0.0.5', { 'x-forwarded-for': '203.0.113.2' })).statusCode, 200, 'another client behind the same proxy is not');
    await app.close();
  });

  it('X-Forwarded-For is IGNORED when the connection is not from a trusted proxy, even if a proxy list is configured', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth(), trustProxy: ['10.0.0.0/8'] });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '198.51.100.70', { 'x-forwarded-for': `203.0.113.${i + 1}` });
    assert.equal((await post(app, '/v1/auth/login', '198.51.100.70', { 'x-forwarded-for': '203.0.113.99' })).statusCode, 429);
    await app.close();
  });
});

describe('one-time code routes over HTTP', { skip: reason }, () => {
  const rateLimiter = () => createMemoryRateLimiter();

  it('POST /v1/auth/phone/verify/request: 202 sent, 200 already verified, 401 without a valid access token, 429 with Retry-After', async () => {
    let mode: 'sent' | 'already_verified' | 'throttled' = 'sent';
    const asked: string[] = [];
    const otp = fakeOtp({ requestPhoneVerification: async (id) => { asked.push(id); if (mode === 'throttled') throw new AuthError('rate_limited', undefined, 42); return { status: mode }; } });
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth(), otp });
    const bearer = { authorization: `Bearer ${ACCESS}` };
    const sent = await app.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers: bearer });
    assert.equal(sent.statusCode, 202);
    assert.deepEqual(sent.json(), { status: 'sent' });
    mode = 'already_verified';
    const done = await app.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers: bearer });
    assert.equal(done.statusCode, 200);
    assert.deepEqual(done.json(), { status: 'already_verified' });
    mode = 'throttled';
    const slow = await app.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers: bearer });
    assert.equal(slow.statusCode, 429);
    assert.equal(slow.headers['retry-after'], '42');
    assert.equal((slow.json() as { error: { code: string } }).error.code, 'rate_limited');
    assert.deepEqual(asked, ['7', '7', '7'], 'the user id comes from the verified token, never from the request');
    for (const headers of [{}, { authorization: 'Bearer garbage' }, { authorization: `Bearer ${REFRESH}` }] as Array<Record<string, string>>) {
      const r = await app.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers });
      assert.equal(r.statusCode, 401, JSON.stringify(headers));
      assert.equal(r.headers['www-authenticate'], 'Bearer');
    }
    assert.equal(asked.length, 3, 'unauthenticated requests never reach the service');
    await app.close();
  });

  it('POST /v1/auth/phone/verify/confirm: 200 with the updated user; 400 invalid_code is generic; 401 unauthenticated; 400 validation', async () => {
    const seen: unknown[] = [];
    const otp = fakeOtp({ confirmPhoneVerification: async (id, input) => {
      seen.push(id, input);
      if ((input as { code?: string }).code === '000000') throw new AuthError('invalid_code');
      if ((input as { code?: string }).code === 'bad') throw new AuthError('validation_failed', [{ field: 'code', code: 'invalid_format' }]);
      return { ...user, phoneVerified: true };
    } });
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth(), otp });
    const post = (payload: unknown, headers: Record<string, string> = { authorization: `Bearer ${ACCESS}` }) => app.inject({ method: 'POST', url: '/v1/auth/phone/verify/confirm', headers: { ...json, ...headers }, payload: JSON.stringify(payload) });
    const ok = await post({ code: '123456' });
    assert.equal(ok.statusCode, 200);
    assert.equal((ok.json() as { user: { phoneVerified: boolean } }).user.phoneVerified, true);
    const wrong = await post({ code: '000000' });
    assert.equal(wrong.statusCode, 400);
    assert.deepEqual(Object.keys((wrong.json() as { error: object }).error).sort(), ['code', 'message', 'requestId']);
    assert.equal((wrong.json() as { error: { code: string } }).error.code, 'invalid_code');
    assert.ok(!wrong.body.includes('000000'));
    assert.equal((await post({ code: 'bad' })).statusCode, 400);
    assert.equal((await post({ code: '123456' }, {})).statusCode, 401);
    assert.deepEqual(seen.slice(0, 2), ['7', { code: '123456' }]);
    await app.close();
  });

  it('POST /v1/auth/password/forgot answers 202 {status:"accepted"}; the service decides nothing the client can see', async () => {
    const seen: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth(), otp: fakeOtp({ requestPasswordReset: async (i) => (seen.push(i), { status: 'accepted' }) }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/password/forgot', headers: json, payload: JSON.stringify({ phone: '07701234567' }) });
    assert.equal(r.statusCode, 202);
    assert.deepEqual(r.json(), { status: 'accepted' });
    assert.deepEqual(seen, [{ phone: '07701234567' }]);
    assert.ok(!r.body.includes('7701234567'), 'the phone is not echoed');
    await app.close();
  });

  it('POST /v1/auth/password/reset: 200 on success; one generic 400 for every code failure; validation errors name the field only', async () => {
    const otp = fakeOtp({ resetPassword: async (i) => {
      const b = i as { code?: string; newPassword?: string };
      if (b.newPassword === 'weak') throw new AuthError('validation_failed', [{ field: 'newPassword', code: 'too_short' }]);
      if (b.code !== '123456') throw new AuthError('invalid_code');
      return { status: 'password_reset' };
    } });
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth(), otp });
    const post = (payload: unknown) => app.inject({ method: 'POST', url: '/v1/auth/password/reset', headers: json, payload: JSON.stringify(payload) });
    const ok = await post({ phone: '07701234567', code: '123456', newPassword: 'N3w-Passw0rd' });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { status: 'password_reset' });
    assert.ok(!ok.body.includes('N3w-Passw0rd'));
    const bad = await post({ phone: '07701234567', code: '000000', newPassword: 'N3w-Passw0rd-secret' });
    assert.equal(bad.statusCode, 400);
    assert.equal((bad.json() as { error: { code: string } }).error.code, 'invalid_code');
    assert.ok(!bad.body.includes('N3w-Passw0rd-secret') && !bad.body.includes('000000'));
    const weak = await post({ phone: '07701234567', code: '123456', newPassword: 'weak' });
    assert.equal(weak.statusCode, 400);
    assert.deepEqual((weak.json() as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'too_short' }]);
    await app.close();
  });

  it('the three body routes refuse text/plain and oversized bodies before the service runs', async () => {
    let called = 0;
    const count = async () => (called++, { status: 'accepted' as const });
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth(), otp: fakeOtp({ requestPasswordReset: count, resetPassword: async () => (called++, { status: 'password_reset' as const }), confirmPhoneVerification: async () => (called++, { ...user, phoneVerified: true }) }) });
    for (const url of OTP_BODY_ROUTES) {
      const text = await app.inject({ method: 'POST', url, headers: { 'content-type': 'text/plain', authorization: `Bearer ${ACCESS}` }, payload: 'code=123456&password=hunter2' });
      assert.equal(text.statusCode, 415, url);
      assert.ok(!text.body.includes('hunter2'));
      const big = await app.inject({ method: 'POST', url, headers: { ...json, authorization: `Bearer ${ACCESS}` }, payload: JSON.stringify({ phone: 'x'.repeat(10_000) }) });
      assert.equal(big.statusCode, 413, url);
    }
    assert.equal(called, 0);
    await app.close();
  });

  it('every new route is rate limited per client address, and the service is not called for blocked requests', async () => {
    for (const url of OTP_ROUTES) {
      const route = OTP_LIMITS[url as keyof typeof OTP_LIMITS];
      let called = 0;
      const otp = fakeOtp({ requestPhoneVerification: async () => (called++, { status: 'sent' as const }), confirmPhoneVerification: async () => (called++, { ...user, phoneVerified: true }), requestPasswordReset: async () => (called++, { status: 'accepted' as const }), resetPassword: async () => (called++, { status: 'password_reset' as const }) });
      const app = await buildServer!({ config, db: okDb, auth: fakeAuth(), otp, rateLimiter: rateLimiter() });
      const hit = () => app.inject({ method: 'POST', url, headers: { ...json, authorization: `Bearer ${ACCESS}` }, payload: '{}', remoteAddress: '198.51.100.55' });
      for (let i = 0; i < RATE_LIMITS[route].limit; i++) assert.notEqual((await hit()).statusCode, 429, `${route} #${i + 1}`);
      const blocked = await hit();
      assert.equal(blocked.statusCode, 429, route);
      assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
      assert.ok(called <= RATE_LIMITS[route].limit, `${route}: blocked requests never reach the service`);
      await app.close();
    }
  });

  it('are absent without an OtpApi', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth() });
    for (const url of OTP_ROUTES) assert.equal((await app.inject({ method: 'POST', url, headers: json, payload: '{}' })).statusCode, 404, url);
    await app.close();
  });
});

describe('account security routes over HTTP', { skip: reason }, () => {
  const bearer = { authorization: `Bearer ${ACCESS}` };
  const authedAuth = () => fakeAuth({ authenticate: async (t) => (t === ACCESS ? { user, sessionId: 'fam-1' } : null) });

  it('POST /v1/auth/password/change: 200 {status}; wrong current and weak/same new passwords are generic 400s; no secret in any body', async () => {
    const seen: unknown[] = [];
    const account = fakeAccount({ changePassword: async (id, input, ctx) => {
      seen.push([id, input, ctx]);
      const b = input as { currentPassword?: string; newPassword?: string };
      if (b.currentPassword === 'wrong') throw new AuthError('invalid_current_password');
      if (b.newPassword === 'weak') throw new AuthError('validation_failed', [{ field: 'newPassword', code: 'too_short' }]);
      return { status: 'password_changed' };
    } });
    const app = await buildServer!({ config, db: okDb, auth: authedAuth(), account });
    const post = (payload: unknown, headers: Record<string, string> = bearer) => app.inject({ method: 'POST', url: '/v1/auth/password/change', headers: { ...json, ...headers }, payload: JSON.stringify(payload) });
    const ok = await post({ currentPassword: 'Old-Passw0rd', newPassword: 'N3w-Passw0rd' });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { status: 'password_changed' });
    const wrong = await post({ currentPassword: 'wrong', newPassword: 'N3w-Passw0rd-secret' });
    assert.equal(wrong.statusCode, 400);
    assert.equal((wrong.json() as { error: { code: string } }).error.code, 'invalid_current_password');
    const weak = await post({ currentPassword: 'Old-Passw0rd', newPassword: 'weak' });
    assert.deepEqual((weak.json() as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'too_short' }]);
    for (const r of [ok, wrong, weak]) assert.ok(!r.body.includes('N3w-Passw0rd') && !r.body.includes('Old-Passw0rd') && !r.body.includes('wrong"'));
    assert.equal((await post({ currentPassword: 'a', newPassword: 'b' }, {})).statusCode, 401);
    assert.equal(seen.length, 3, 'the unauthenticated call never reached the service');
    assert.equal((seen[0] as unknown[])[0], '7');
    assert.equal(typeof ((seen[0] as unknown[])[2] as { requestId: string }).requestId, 'string');
    await app.close();
  });

  it('POST /v1/auth/logout/all: 204 and an empty body; 401 without a valid access token; the user is the token\'s', async () => {
    const asked: string[] = [];
    const app = await buildServer!({ config, db: okDb, auth: authedAuth(), account: fakeAccount({ logoutAll: async (id) => (asked.push(id), { status: 'signed_out_everywhere' }) }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/logout/all', headers: bearer });
    assert.equal(ok.statusCode, 204);
    assert.equal(ok.body, '');
    for (const headers of [{}, { authorization: 'Bearer garbage' }, { authorization: `Bearer ${REFRESH}` }] as Array<Record<string, string>>) {
      const r = await app.inject({ method: 'POST', url: '/v1/auth/logout/all', headers });
      assert.equal(r.statusCode, 401);
      assert.equal(r.headers['www-authenticate'], 'Bearer');
    }
    const spoof = await app.inject({ method: 'POST', url: '/v1/auth/logout/all?userId=999', headers: { ...json, ...bearer }, payload: JSON.stringify({ userId: '999' }) });
    assert.equal(spoof.statusCode, 204);
    assert.deepEqual(asked, ['7', '7'], 'a user id in the body or the query is ignored');
    await app.close();
  });

  it('change password refuses text/plain (415) and oversized bodies (413) before the service runs', async () => {
    let called = 0;
    const app = await buildServer!({ config, db: okDb, auth: authedAuth(), account: fakeAccount({ changePassword: async () => (called++, { status: 'password_changed' as const }) }) });
    const text = await app.inject({ method: 'POST', url: '/v1/auth/password/change', headers: { 'content-type': 'text/plain', ...bearer }, payload: 'currentPassword=a&newPassword=hunter2hunter2' });
    assert.equal(text.statusCode, 415);
    assert.ok(!text.body.includes('hunter2'));
    const big = await app.inject({ method: 'POST', url: '/v1/auth/password/change', headers: { ...json, ...bearer }, payload: JSON.stringify({ currentPassword: 'x'.repeat(10_000) }) });
    assert.equal(big.statusCode, 413);
    assert.equal(called, 0);
    await app.close();
  });

  it('both routes are rate limited per client address, and the service is not called for blocked requests', async () => {
    for (const [url, route] of [['/v1/auth/password/change', 'passwordChange'], ['/v1/auth/logout/all', 'logoutAll']] as const) {
      let called = 0;
      const account = fakeAccount({ changePassword: async () => (called++, { status: 'password_changed' as const }), logoutAll: async () => (called++, { status: 'signed_out_everywhere' as const }) });
      const app = await buildServer!({ config, db: okDb, auth: authedAuth(), account, rateLimiter: createMemoryRateLimiter() });
      const hit = () => app.inject({ method: 'POST', url, headers: { ...json, ...bearer }, payload: '{}', remoteAddress: '198.51.100.88' });
      for (let i = 0; i < RATE_LIMITS[route].limit; i++) assert.notEqual((await hit()).statusCode, 429, `${route} #${i + 1}`);
      const blocked = await hit();
      assert.equal(blocked.statusCode, 429, route);
      assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
      assert.ok(called <= RATE_LIMITS[route].limit);
      await app.close();
    }
  });

  it('are absent without an AccountApi', async () => {
    const app = await buildServer!({ config, db: okDb, auth: authedAuth() });
    for (const url of ACCOUNT_ROUTES) assert.equal((await app.inject({ method: 'POST', url, headers: { ...json, ...bearer }, payload: '{}' })).statusCode, 404, url);
    await app.close();
  });
});

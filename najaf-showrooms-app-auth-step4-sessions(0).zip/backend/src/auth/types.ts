import type { FieldError } from './validation.ts';

/** The ONLY user shape that ever leaves the service. It is built field by field: no password, no hash, no counters. */
export interface PublicUser {
  /** bigint identity, as a decimal string (safe for any JSON client). */
  id: string;
  name: string;
  /** Canonical E.164 (+9647XXXXXXXXX). */
  phone: string;
  role: string;
  status: string;
  /** true once the phone number has been proven with a one-time code. Registration never sets it. */
  phoneVerified: boolean;
  /** ISO-8601 UTC. */
  createdAt: string;
}

/** Both tokens are shown ONCE. Only the SHA-256 of the refresh token is stored; the access token is not stored at all. */
export interface SessionGrant {
  /** 15-minute signed token for API calls (Authorization: Bearer). Carries only sub + sid. */
  accessToken: string;
  accessExpiresAt: string;
  /** Opaque 256-bit token, used ONLY to obtain new tokens (POST /v1/auth/refresh) or to log out. Rotated on every use. */
  refreshToken: string;
  /** Absolute (30 days from login); rotation does not extend it. */
  refreshExpiresAt: string;
}

export interface AuthResult {
  user: PublicUser;
  session: SessionGrant;
}

export interface AuthenticatedUser {
  user: PublicUser;
  /** The login session (sessions.family_id): stable across refresh-token rotations. */
  sessionId: string;
}

export interface AuthContext {
  userAgent?: string | undefined;
}

export type AuthErrorCode = 'validation_failed' | 'conflict' | 'invalid_credentials' | 'unauthorized' | 'invalid_code' | 'rate_limited' | 'invalid_current_password';

// Fixed, generic messages: nothing here can reveal whether an account exists, why a login failed, or what was submitted.
const MESSAGES: Record<AuthErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  conflict: 'This account cannot be registered',
  invalid_credentials: 'Invalid phone number or password',
  unauthorized: 'Authentication required',
  // ONE message for every one-time-code failure (wrong, expired, used, exhausted, wrong purpose, unknown account).
  invalid_code: 'The code is invalid or has expired',
  rate_limited: 'Too many requests',
  // Only an AUTHENTICATED user ever sees this (change password): it cannot be used to probe accounts.
  invalid_current_password: 'The current password is incorrect',
};

export class AuthError extends Error {
  readonly code: AuthErrorCode;
  readonly fields: FieldError[] | undefined;
  /** Only for 'rate_limited': a hint, in seconds, for the Retry-After header. */
  readonly retryAfterSeconds: number | undefined;
  constructor(code: AuthErrorCode, fields?: FieldError[], retryAfterSeconds?: number) {
    super(MESSAGES[code]);
    this.name = 'AuthError';
    this.code = code;
    this.fields = fields;
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

/** What the HTTP layer needs from the authentication service. */
export interface AuthApi {
  register(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  login(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  /** Rotates the refresh token: the presented token stops working, a new pair is issued. Reuse revokes the whole session. */
  refresh(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  /** Verifies an ACCESS token and re-reads the session and the user from the database. */
  authenticate(accessToken: string | undefined): Promise<AuthenticatedUser | null>;
  /** Ends the login session identified by the refresh token (works even when the access token has expired). */
  logout(input: unknown): Promise<void>;
}

/** One-time codes: phone verification (authenticated) and password recovery (not authenticated). */
export interface OtpApi {
  /** Sends a code to the user's OWN phone. 'already_verified' sends nothing. Throws rate_limited when throttled. */
  requestPhoneVerification(userId: string): Promise<{ status: 'sent' | 'already_verified' }>;
  /** Verifies the code and sets phone_verified_at atomically. Idempotent for an already-verified user. */
  confirmPhoneVerification(userId: string, input: unknown): Promise<PublicUser>;
  /** ALWAYS the same answer, whether or not the phone belongs to an account. */
  requestPasswordReset(input: unknown): Promise<{ status: 'accepted' }>;
  /** Verifies the code, sets the new password, revokes every session: one transaction, one use of the code. */
  resetPassword(input: unknown): Promise<{ status: 'password_reset' }>;
}

export interface AccountContext {
  /** The HTTP request id, recorded in the audit event so it can be correlated with the logs. Not a secret. */
  requestId?: string | undefined;
}

/** Account and session security for the AUTHENTICATED user. The user id always comes from the verified access token. */
export interface AccountApi {
  /**
   * Requires the current password, applies the password policy, refuses the same password, and ends EVERY session of the
   * user (including the current one: the user signs in again with the new password). Audited.
   */
  changePassword(userId: string, input: unknown, ctx?: AccountContext): Promise<{ status: 'password_changed' }>;
  /** Ends EVERY live login session of the user, atomically, even against refreshes that are in flight. Audited. */
  logoutAll(userId: string, ctx?: AccountContext): Promise<{ status: 'signed_out_everywhere' }>;
}

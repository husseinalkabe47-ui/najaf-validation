# Backend — أساس المرحلة 11.4.1

**الحالة بصراحة:** هذا الأساس **غير متصل بالواجهة** ولا يضيف أي ميزة للمستخدم. يحوي فقط: إعدادات البيئة، طبقة اتصال آمنة بـPostgreSQL 16، فحص الدور والمخطط عند الإقلاع، ونقطتَي صحة (`/healthz` و`/readyz`). الواجهة (التطبيق الحالي) ما زالت تعمل على `localStorage` كما كانت، ولم يُعدَّل فيها ملف.

## البنية
```
backend/
├── src/
│   ├── config.ts          إعدادات البيئة: تحقق كامل، لا كلمة مرور في الأخطاء أو السجلات
│   ├── errors.ts          تصنيف أخطاء المشغّل (SQLSTATE/شبكة) إلى DbError آمن (بلا SQL ولا قيم)
│   ├── http-errors.ts     تحويل الأخطاء إلى ردود HTTP عامة (409/422/403/503/500)
│   ├── role.ts            فحص أن الاتصال بدور أدنى امتيازًا (ليس superuser، عضو في najaf_app)
│   ├── schema-contract.ts العقد مع المخطط المُختبَر: 16 جدولًا + viewان (يُقارَن آليًا بالترحيلات)
│   ├── db.ts              Pool + query + tx (BEGIN/COMMIT/ROLLBACK مضمونة) + ping/verifyRole/checkSchema
│   ├── health.ts          liveness بلا قاعدة، readiness (اتصال + عقد المخطط) بلا تفاصيل للعميل
│   ├── server.ts          Fastify رفيع: /healthz و/readyz و404/خطأ عامّان، request-id، no-store
│   ├── index.ts           نقطة الدخول: config → db → سياسة الدور → خادم → إيقاف نظيف
│   └── types.ts           واجهة Logger (متوافقة مع pino)
├── scripts/db-check.ts    أداة تشغيل: تفحص الاتصال والدور والمخطط وتطبع JSON بلا أسرار
├── ops/create_app_login.sql  ينشئ دور الدخول الأدنى امتيازًا (كلمة المرور تُمرَّر -v ولا تُكتب في الملف)
├── test/unit/             اختبارات بلا قاعدة بيانات (تعمل في أي بيئة)
├── test/integration/      اختبارات على PostgreSQL حقيقي (تُتخطّى بوضوح بلا DATABASE_URL)
└── .env.example           كل متغيرات البيئة موثَّقة (اختبار آلي يمنع اختلافها عن الكود)
```
**القاعدة الحاكمة:** كل المنطق في وحدات **بلا اعتماديات** (تُختبر محليًا بالكامل)؛ و`pg` وFastify لا يظهران إلا في `db.ts` (استيراد كسول عبر factory) و`server.ts`.

## نموذج الأمان (ما اعتُمد)
- **لا اتصال بمشرف.** يتصل الـBackend بدور دخول (`najaf_app_login`) **عضو** في `najaf_app` (من الترحيل 0012) فيرث الامتيازات المُختبَرة فقط: بلا DDL ولا TRUNCATE، بلا DELETE على `users` و`showrooms` و`audit_logs` و`exchange_rates`، بلا تعديل `users.role`، وبعد 0013 بلا تعديل أعمدة الملكية والأوقات و`version`.
- **سياسة تُفرض عند الإقلاع** (`DB_REQUIRE_APP_ROLE=true`، ولا يُسمح بتعطيلها في الإنتاج): ترفض العملية الدور إن كان superuser أو يستطيع إنشاء أدوار/قواعد أو له replication/bypassrls أو ليس عضوًا في `najaf_app`، وترفض كذلك اسم المستخدم `postgres` في الإعداد. رمز الخروج 78.
- **TLS:** الافتراضي `verify-full` في الإنتاج، و`disable` مرفوض فيه؛ أنماط libpq التي تُضعف الأمان بصمت (`prefer`/`allow`/`verify-ca`) مرفوضة.
- **استعلامات مُعلَّمة فقط** (القيم لا تُدمج في SQL أبدًا)، و`checkSchema` يمرّر أسماء الكائنات معلَّمة كذلك.
- **مهلات من أول جملة:** `statement_timeout` و`lock_timeout` و`idle_in_transaction_session_timeout` كمعاملات بدء الاتصال (يتحقق منها اختبار التكامل بقراءة `current_setting`).
- **أخطاء بلا تسريب:** `DbError` يحمل النوع والـSQLSTATE واسم القيد فقط؛ رسالة المشغّل الأصلية للسجل الداخلي وحده؛ ردود HTTP عامة (لا SQL ولا أسماء قيود ولا تتبّع مكدّس).
- **المعاملات:** الاتصال يُحرَّر مرة واحدة دائمًا؛ فشل `ROLLBACK` يُتلف الاتصال بدل إعادة استعماله؛ استعلام المعاملة بعد انتهائها مرفوض.
- **readiness** لا يكشف شيئًا للعميل سوى حالات خشنة (`ok/fail/skipped`)؛ التفاصيل في السجل.

## البيئة (`.env.example`)
`DATABASE_URL` (أو `PGHOST`/`PGPORT`/`PGDATABASE`/`PGUSER`/`PGPASSWORD`)، `DB_SSL` و`DB_SSL_CA`، `DB_POOL_MAX` (10)، `DB_STATEMENT_TIMEOUT_MS` (15000)، `DB_LOCK_TIMEOUT_MS` (5000)، `DB_IDLE_IN_TX_TIMEOUT_MS` (15000)، `DB_CONNECT_TIMEOUT_MS` (5000)، `DB_IDLE_TIMEOUT_MS` (30000)، `DB_APPLICATION_NAME`، `DB_REQUIRE_APP_ROLE`، و`NODE_ENV` و`HOST` و`PORT` و`LOG_LEVEL`. القيم الخاطئة تُجمَع في خطأ واحد واضح، ولا يظهر فيه كلمة المرور أبدًا. لا ملف `.env` في المستودع (`.gitignore`).

## التشغيل
```bash
# 1) قاعدة PostgreSQL 16 بالترحيلات المُختبَرة
for f in ../database/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -1 -d najaf -f "$f"; done
# 2) دور الاتصال (مرة واحدة)
psql -v ON_ERROR_STOP=1 -d najaf -v login=najaf_app_login -v pw="$NAJAF_APP_PASSWORD" -f ops/create_app_login.sql
# 3) الاعتماديات والإعداد
npm install && cp .env.example .env     # عدّل DATABASE_URL
npm run db:check                         # يفحص الاتصال والدور والمخطط
npm run dev                              # خادم Node ≥ 22.18 يشغّل TypeScript مباشرة (بلا خطوة بناء)
```
`GET /healthz` ← `{"status":"ok"}`؛ `GET /readyz` ← 200 `{"status":"ready",...}` أو 503 `not_ready`.

## الاختبارات
| الأمر | ماذا يشغّل | يحتاج |
| --- | --- | --- |
| `npm test` | **117 اختبار وحدة** تعمل بلا أي اعتمادية: الإعدادات (27)، تصنيف الأخطاء وردود HTTP (44)، طبقة الاتصال بـpool مزيّف: خيارات `pg`، معاملات، تنظيف الاتصال، أخطاء (22)، سياسة الدور (8)، الصحة (7)، العقد مع الترحيلات (5)، توافق `.env.example` (4). ثم **7 اختبارات خادم HTTP** (Fastify `inject`) | Node ≥ 22.18. اختبارات الخادم تحتاج `npm install` وإلا تُتخطّى بوضوح كمجموعة |
| `npm run test:integration` | **58 اختبار تكامل** على PostgreSQL حقيقي: اتصال ودور ومهلات فعلية وكلمة مرور خاطئة وخادم غير متاح وحدّ الـpool وcommit/rollback وعدم تسريب الاتصالات (17)، **امتيازات الدور** (23 عملية ممنوعة و12 مسموحة + إضافة التدقيق + منع إنشاء مدير + 3 معارض/115 سيارة) (38)، وردود الصحة عبر HTTP (3) | `DATABASE_URL` (دور التطبيق) و`ADMIN_DATABASE_URL` (superuser للتجهيز فقط) |
| `npm run typecheck` | `tsc --noEmit` صارم (`erasableSyntaxOnly`) | `npm install` |

CI: `.github/workflows/backend.yml` (تشغيل يدوي) يطبّق الترحيلات المُختبَرة ويشغّل الثلاثة معًا + انحدار الواجهة (33 ملفًا) على PostgreSQL 16.

## التراجع (المرحلة قابلة للإزالة بالكامل)
هذه المرحلة **إضافية بحتة**: احذف `backend/` و`.github/workflows/backend.yml` وفقرة 11.4.1 من `README.md` الجذر، فيعود المشروع كما كان في 11p3 بلا أي أثر. لا ملف في الواجهة أو الخدمات أو المستودعات أو `database/` تغيّر.

## قرارات معمارية معلَّقة (لم تُنفَّذ عمدًا؛ تحتاج موافقتك قبل 11.4.2)
1. **TypeScript بلا بناء:** يُنفَّذ مباشرة بـNode ≥ 22.18 (type stripping) وتُفحَص أنواعه بـ`tsc` في CI. بديله: خطوة بناء (esbuild/tsc) — أُبقي المشروع بلا بناء اتساقًا مع قاعدته.
2. **Drizzle ORM** (المذكور في وثيقة 11.1) **مؤجَّل**: المخطط يعتمد مشغّلات وviews وصلاحيات أعمدة ومهاجرات SQL مكتوبة يدويًا واجتازت التحقق؛ فالمقترح SQL مُعلَّم مباشرة بـ`pg`، مع إعادة النظر عند نقل أول مستودع.
3. **Zod** مؤجَّل لحين وجود أول مسار يستقبل مدخلات.
4. **لا مشغّل ترحيلات في الباكند:** الترحيلات SQL تُطبَّق بـ`psql`؛ جدول تتبّع داخل المخطط سيغيّر ما اجتاز التحقق. خيارات 11.4.2: أداة خارجية (dbmate/graphile-migrate) أو مشغّل بمخطط `ops` منفصل.
5. **ملف قفل الحزم غير موجود:** بيئتي لا تثبّت حزم npm؛ يُنشأ `package-lock.json` من أول تشغيل ناجح في CI ويُلتزم به.

## خريطة الخدمات الحالية → وحدات الباكند القادمة (تصميم، غير منفَّذ)
| الواجهة الآن | وحدة الباكند | الجداول |
| --- | --- | --- |
| AuthService/SessionService/UserService | auth | users, sessions, verification_codes, message_deliveries |
| SearchService/VisibilityService/CarFilterService | catalog (قراءة عامة) | views: public_cars, public_showrooms |
| MemberCarsService/ShowroomCarsService/ShowroomService/FavoritesService | owners | cars, showrooms, favorites |
| CarImagesService/ImageService/ImageStore (IndexedDB) | uploads | assets, car_images + تخزين كائنات |
| AdminService | moderation | users, showrooms, cars, audit_logs |
| RewardService | rewards | reward_grants |
| FormatService (TEXT_LIMITS) وسعر الصرف | settings | app_settings, exchange_rates |
| AuthorizationService | سياسة `can(actor, action, resource)` واحدة | — |
| MigrationService (مخطط localStorage) | لا مقابل (تحلّ محلّه ترحيلات SQL) | — |

ربط الواجهة بالباكند (علم `DATA_SOURCE=local|api` ومستودعات بعيدة بالواجهة نفسها) في مرحلة لاحقة؛ الواجهة هنا لم تُلمَس.

## Migration Runner (دمج أداة الترحيلات)

أُدمجت **node-pg-migrate 9.0.0** (نسخة مثبَّتة بلا `^`) بعد أن نجح تقييمها المنفصل على PostgreSQL 16 (29 نجاحًا، 0 فشل، 3 معلومات). **لم يُعدَّل أي ملف في `database/migrations` (0001–0013)، ولم يتغير مخطط PostgreSQL.**

- **المصدر الوحيد للـSQL:** `database/migrations` (مجمَّد وبصماته في `database/CHECKSUMS.sha256`). الأداة لا تكتب فيه.
- **التغليف:** `db/migrations/NNNN_name.js` (13 ملف CommonJS) يقرأ ملف SQL الأصلي حرفيًا. و**`db/down/NNNN_name.down.sql`** (13) هي ملفات التراجع. التفاصيل في `db/README.md`.
- **التتبع:** `ops.pgmigrations` (لا شيء في `public`).
- **حساب منفصل:** `MIGRATION_DATABASE_URL` يشير إلى `najaf_migrator` (مالك قاعدة البيانات، `CREATEROLE`، ليس superuser، ولا يرث صلاحيات `najaf_app` ولا يستطيع `SET ROLE` إليه). يُنشأ بـ`ops/create_migration_role.sql`. الإعداد يرفض `najaf_app` و`najaf_app_login` و`najaf_report`، ويرفض الحساب نفسه المستعمل في `DATABASE_URL`، وفحص الدور قبل أي تشغيل يرفض أي حساب **يرث صلاحيات `najaf_app` أو يستطيع `SET ROLE` إليه** (هوية تطبيق). أما العضوية الإدارية `ADMIN OPTION` التي يمنحها PostgreSQL 16 تلقائيًا لمنشئ الدور فمقبولة لأنها لا تمنح صلاحياته ولا التحويل إليه.
- **المتغيرات:** `.env.migrations.example` (اختبار آلي يمنع اختلافها عن الكود).

```bash
npm run db:migrate                       # تطبيق كل الترحيلات المعلّقة
npm run db:migrate:status                # applied / pending / unknown
npm run db:rollback -- --steps 1         # تراجع آخر ترحيلة (لا عدد افتراضيًا)
npm run db:rollback -- --all             # تراجع كل شيء (تُحذف الجداول؛ الأدوار تبقى)
```
قواعد أمان: `down` بلا `--steps`/`--all` مرفوض؛ وفي الإنتاج مرفوض ما لم يُضبط `MIGRATION_ALLOW_ROLLBACK=true`؛ ولا تظهر كلمة المرور في أي مخرج.

**الاختبارات:** 60 اختبار وحدة (إعدادات الـRunner، الـRunner بـ`runner` مزيّف، فحص الدور، الحالة، وأصول الترحيل) + 9 اختبارات تكامل على PostgreSQL حقيقي (`test/integration/migrate.integration.test.ts`، تحتاج قاعدة **فارغة** واسمها فيه test أو mig أو ci لأنها تتراجع عن كل شيء) + `.github/workflows/migrations.yml` (تشغيل يدوي): يطبّق ويتراجع ويقارن `pg_dump` بمرجع `psql -1`.

**التراجع عن هذه الخطوة بالكامل** (إضافية بحتة، لا شيء قديم حُذف أو استُبدل): احذف `backend/src/migrate/` و`backend/scripts/migrate.ts` و`backend/db/` و`backend/ops/create_migration_role.sql` و`backend/.env.migrations.example` و`backend/test/**/migrate*` و`.github/workflows/migrations.yml` وهذا القسم، وأزل من `backend/package.json` ثلاثة أوامر `db:migrate*`/`db:rollback` وسطر `"node-pg-migrate": "9.0.0"`.

## المصادقة والحسابات (Phase 11.4): الخطوتان 1 و2

تسجيل مستخدم، والتحقق من بيانات الدخول، **رمز وصول 15 دقيقة**، **رمز تحديث دوّار مع كشف إعادة الاستعمال**، وحدّ معدّل. **لا ربط بالواجهة بعد**، ولا OTP، ولا تفويض (11.5). **لم يتغير مخطط PostgreSQL ولا أي ترحيلة** (يكفي `sessions`: `family_id` و`replaced_by` وأسباب الإلغاء `rotated` و`reuse_detected` و`logout`).

| المسار | الطلب | النجاح | الفشل |
| --- | --- | --- | --- |
| `POST /v1/auth/register` | `{name, phone, password}` | 201 `{user, session}` | 400 تحقق، 409 تعذّر التسجيل، 429 |
| `POST /v1/auth/login` | `{phone, password}` | 200 `{user, session}` | 400، 401 `invalid_credentials`، 429 |
| `POST /v1/auth/refresh` | `{refreshToken}` | 200 `{user, session}` (جديدان كلاهما) | 400، 401 `unauthorized`، 429 |
| `GET /v1/auth/me` | `Authorization: Bearer <accessToken>` | 200 `{user}` | 401 `unauthorized` |
| `POST /v1/auth/logout` | `{refreshToken}` | 204 | 400، 429 |

`session = {accessToken, accessExpiresAt, refreshToken, refreshExpiresAt}`، ويُعرض كل رمز **مرة واحدة**. المستخدم العام `{id, name, phone, role, status, createdAt}` يُبنى حقلًا حقلًا (لا كلمة مرور ولا تجزئة)، و`phone` بصيغة E.164.

**الرمزان**
- **رمز الوصول:** HS256 (على `node:crypto`، بلا تبعية)، 15 دقيقة، يحمل `sub` و`sid` فقط. **الدور والحالة لا تُقرأ منه أبدًا**: تُعاد قراءة الجلسة والمستخدم من القاعدة عند كل طلب، فيموت الرمز **فورًا** عند الخروج أو الإيقاف أو كشف إعادة الاستعمال أو تغيير كلمة المرور (مشغّلات القاعدة)، لا بعد 15 دقيقة. التحقق صارم: ترويسة ثابتة، توقيع بزمن ثابت، مطالبات محددة بالضبط، عمر لا يتجاوز السياسة.
- **رمز التحديث:** عشوائي 256 بت (`nsj_…`)، **SHA-256 فقط** في `sessions.token_hash`، **30 يومًا مطلقة** من الدخول (التدوير لا يمدّها). لا يُقبل رمز تحديث كرمز وصول، ولا العكس.
- **التدوير:** كل `/refresh` يُصدر زوجًا جديدًا في المعاملة نفسها (قفل الصف `FOR UPDATE`): يُلغى الصف القديم بسبب `rotated` مع `replaced_by`، ويُدرج جديد بنفس `family_id` ونفس الانتهاء.
- **كشف إعادة الاستعمال:** عرض رمز دُوِّر سابقًا يُلغي **كل** جلسة الدخول (`reuse_detected`) ويُثبَّت الإلغاء، ولا يُصدر شيئًا. وهو **صارم عمدًا**: طلبان متزامنان بالرمز نفسه يُنهيان الجلسة (فعلى العميل ألا يجدّد بالتوازي). الجلسات الأخرى للمستخدم لا تتأثر.
- **الخروج:** بـ`refreshToken` (يعمل ولو انتهى رمز الوصول)، ويُنهي جلسة الدخول كلها. وهو متساوي الأثر بأي رمز من السلسلة، ولا يُعدّ إعادة استعمال.
- **كل إخفاق تجديد** (مجهول، منتهٍ، مُلغى، مُعاد استعماله، حساب موقوف أو محذوف) هو **الخطأ نفسه** `unauthorized`.

**الإعداد** (وحدة منفصلة `src/auth/config.ts`، ومثال `.env.auth.example`)
- `AUTH_ACCESS_TOKEN_SECRET` **مطلوب** (32 حرفًا فأكثر، عشوائي: `openssl rand -base64 48`)، ويُرفض الفارغ والقصير وقليل التنوع والنماذج (`change-me`…). لا يُسجَّل ولا يُكرَّر في أي خطأ. **بدونه لا يبدأ الخادم** (`npm start` يخرج برمز 78).
- `AUTH_TRUSTED_PROXIES` اختياري: عناوين/CIDR للوكلاء الذين يُوثَق بـ`X-Forwarded-For` منهم (Cloudflare/موازن الحمل). الافتراضي **لا أحد**، و«الثقة بالجميع» (`/0` و`*` و`true`) **مرفوضة**. بدونه خلف وكيل تظهر كل الطلبات من عنوان الوكيل.
- تدوير السر يُبطل رموز الوصول فقط (رموز التحديث تعمل وتُصدر رموز وصول جديدة).

**حدّ المعدّل** (`src/auth/rate-limit.ts`): لكل عنوان عميل ولكل مسار، نوافذ ثابتة **في ذاكرة العملية** (بلا جدول ولا ترحيلة): `register` 5/ساعة، `login` 10/5 دقائق، `refresh` 60/10 دقائق، `logout` 30/5 دقائق. يُجاب 429 مع `Retry-After` **قبل قراءة الجسم**. الذاكرة محدودة (50 ألف مفتاح). **القيود:** الحدّ لكل نسخة تشغيل (عند عدة نسخ يتضاعف السقف)، ويضاف إلى قفل الحساب (5 إخفاقات/15 دقيقة) لا يحلّ محله.

**سائر الضمانات (الخطوة 1):**
- argon2id (`m=19456,t=2,p=1`)، ولا كلمة مرور تُسجَّل أو تُرجَع.
- فشل الدخول بكل أسبابه خطأ واحد، وتحقق argon2 واحد في كل مسار (لا فرق توقيت).
- الدور والحالة ليسا مدخلين (حقل `role` يُرفض).
- `register` و`login` و`refresh` و`logout` تقبل `application/json` فقط (415 قبل قراءة الجسم)، وحدّ الجسم 4 KiB.
- استعلامات SQL مُعلَّمة فقط، والوقت من ساعة القاعدة (انتهاء الجلسة) وساعة التطبيق (انتهاء رمز الوصول).

**ما لم يُنفَّذ بعد:** OTP وتحقق الهاتف واسترداد كلمة المرور، والمدير الأول، وتغيير كلمة المرور، والخروج من كل الأجهزة، وتسجيل التجار والبريد، وأحداث التدقيق، وCORS وكوكي رمز التحديث (يُحسمان مع 11.7)، و`ip_hash` (يحتاج سرًّا)، وذاكرة مؤقتة ≤ 30 ثانية لقراءة المستخدم (حاليًا قراءة عند كل طلب: أدق وأبطأ).

**قرارات تنتظر موافقتك (غير واردة في الخطة):** أرقام القفل وحدّ المعدّل، والحد الأدنى لكلمة المرور 6 (يُنصح بـ8)، وكشف إعادة الاستعمال الصارم بلا مهلة سماح.
**التبعيات:** لا جديدة في هذه الخطوة (`argon2` من الخطوة 1 فقط).
**الاختبارات:** وحدات `test/unit/auth-*.test.ts` (رمز الوصول، الخدمة، التجديد، المستودعات، حدّ المعدّل، الإعداد، التحقق، HTTP)، وتكامل `test/integration/auth*.integration.test.ts` على PostgreSQL حقيقي مع argon2id حقيقي.

import type { FieldError } from './validation.ts';

/** The ONLY user shape that ever leaves the service. It is built field by field: no password, no hash, no counters. */
export interface PublicUser {
  /** bigint identity, as a decimal string (safe for any JSON client). */
  id: string;
  name: string;
  /** Canonical E.164 (+9647XXXXXXXXX). */
  phone: string;
  role: string;
  status: string;
  /** ISO-8601 UTC. */
  createdAt: string;
}

/** Both tokens are shown ONCE. Only the SHA-256 of the refresh token is stored; the access token is not stored at all. */
export interface SessionGrant {
  /** 15-minute signed token for API calls (Authorization: Bearer). Carries only sub + sid. */
  accessToken: string;
  accessExpiresAt: string;
  /** Opaque 256-bit token, used ONLY to obtain new tokens (POST /v1/auth/refresh) or to log out. Rotated on every use. */
  refreshToken: string;
  /** Absolute (30 days from login); rotation does not extend it. */
  refreshExpiresAt: string;
}

export interface AuthResult {
  user: PublicUser;
  session: SessionGrant;
}

export interface AuthenticatedUser {
  user: PublicUser;
  /** The login session (sessions.family_id): stable across refresh-token rotations. */
  sessionId: string;
}

export interface AuthContext {
  userAgent?: string | undefined;
}

export type AuthErrorCode = 'validation_failed' | 'conflict' | 'invalid_credentials' | 'unauthorized';

// Fixed, generic messages: nothing here can reveal whether an account exists, why a login failed, or what was submitted.
const MESSAGES: Record<AuthErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  conflict: 'This account cannot be registered',
  invalid_credentials: 'Invalid phone number or password',
  unauthorized: 'Authentication required',
};

export class AuthError extends Error {
  readonly code: AuthErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: AuthErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'AuthError';
    this.code = code;
    this.fields = fields;
  }
}

/** What the HTTP layer needs from the authentication service. */
export interface AuthApi {
  register(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  login(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  /** Rotates the refresh token: the presented token stops working, a new pair is issued. Reuse revokes the whole session. */
  refresh(input: unknown, ctx?: AuthContext): Promise<AuthResult>;
  /** Verifies an ACCESS token and re-reads the session and the user from the database. */
  authenticate(accessToken: string | undefined): Promise<AuthenticatedUser | null>;
  /** Ends the login session identified by the refresh token (works even when the access token has expired). */
  logout(input: unknown): Promise<void>;
}

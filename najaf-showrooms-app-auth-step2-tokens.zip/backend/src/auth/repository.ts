// PostgreSQL access for authentication. Every statement is parameterized (values are never interpolated into SQL), uses
// only columns/privileges the application role has (migrations 0012/0013), and never selects password_hash except in the
// single credentials lookup used by login. Time is the database clock (now()), so there is no clock skew.
import type { Db, Tx } from '../db.ts';
import { LOGIN_LOCK_SECONDS, LOGIN_MAX_FAILURES, SESSION_TOUCH_INTERVAL_SECONDS, SESSION_TTL_SECONDS } from './policy.ts';

export interface UserRow {
  id: string;
  name: string;
  phoneE164: string;
  role: string;
  status: string;
  createdAt: Date;
}
export interface CredentialRow extends UserRow {
  passwordHash: string;
  /** true while users.locked_until is in the future (decided by the database clock). */
  locked: boolean;
}
export interface NewSession {
  /** sessions.id of the NEW row (this refresh token). */
  sessionId: string;
  /** sessions.family_id: the login session; stable across rotations. */
  familyId: string;
  expiresAt: Date;
}
export interface ActiveSession {
  /** sessions.id of the live row (the current refresh token's row). */
  sessionId: string;
  familyId: string;
  lastUsedAt: Date;
  user: UserRow;
}
export type RotateOutcome =
  | { kind: 'rotated'; user: UserRow; session: NewSession }
  /** The presented refresh token was already rotated: the whole family has been revoked ('reuse_detected'). */
  | { kind: 'reuse'; userId: string }
  /** Unknown, revoked (other reasons), expired, or the account is not active. Nothing changed. */
  | { kind: 'rejected' };

export interface UsersRepository {
  /** Inserts an ACTIVE regular user. role and status are NOT parameters: the database defaults ('user', 'active') apply. */
  insert(input: { name: string; phoneE164: string; passwordHash: string }): Promise<UserRow>;
  findCredentialsByPhone(phoneE164: string): Promise<CredentialRow | null>;
  recordFailedLogin(userId: string): Promise<void>;
  recordSuccessfulLogin(userId: string): Promise<void>;
}
export interface SessionsRepository {
  /** Starts a NEW login session (new family) for a user. */
  create(input: { userId: string; tokenHash: Buffer; userAgent: string | null }): Promise<NewSession>;
  /** The live session of a family belonging to this user, with the user (active, not deleted); otherwise null. */
  findActiveByFamily(familyId: string, userId: string): Promise<ActiveSession | null>;
  /**
   * Rotates a refresh token. MUST run inside AuthStore.transaction: it locks the presented row, so two concurrent
   * refreshes of the same token cannot both succeed (the loser sees it as already rotated, i.e. reuse).
   */
  rotate(input: { presentedHash: Buffer; newHash: Buffer; userAgent: string | null }): Promise<RotateOutcome>;
  /** Revokes the live session of the family that this refresh token belongs to, whether or not the token is current. */
  revokeFamilyByTokenHash(tokenHash: Buffer): Promise<boolean>;
  touch(sessionId: string): Promise<void>;
}
export interface AuthStore {
  users: UsersRepository;
  sessions: SessionsRepository;
  /** Runs fn in one database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { users: UsersRepository; sessions: SessionsRepository }) => Promise<T>): Promise<T>;
}

interface UserSqlRow {
  id: string;
  name: string;
  phone_e164: string;
  role: string;
  status: string;
  created_at: Date;
}
const toUserRow = (r: UserSqlRow): UserRow => ({ id: r.id, name: r.name, phoneE164: r.phone_e164, role: r.role, status: r.status, createdAt: r.created_at });

export function createPgUsersRepository(q: Tx): UsersRepository {
  return {
    async insert({ name, phoneE164, passwordHash }) {
      const r = await q.query<UserSqlRow>(
        `INSERT INTO users (name, phone_e164, password_hash)
         VALUES ($1, $2, $3)
         RETURNING id, name, phone_e164, role, status, created_at`,
        [name, phoneE164, passwordHash],
      );
      return toUserRow(r.rows[0] as UserSqlRow);
    },

    async findCredentialsByPhone(phoneE164) {
      const r = await q.query<UserSqlRow & { password_hash: string; locked: boolean }>(
        `SELECT id, name, phone_e164, role, status, created_at, password_hash,
                (locked_until IS NOT NULL AND locked_until > now()) AS locked
           FROM users
          WHERE phone_e164 = $1 AND deleted_at IS NULL`,
        [phoneE164],
      );
      const row = r.rows[0];
      return row ? { ...toUserRow(row), passwordHash: row.password_hash, locked: row.locked === true } : null;
    },

    async recordFailedLogin(userId) {
      // Atomic: concurrent failures cannot lose a count; the lock starts exactly when the threshold is reached.
      await q.query(
        `UPDATE users
            SET failed_logins = LEAST(failed_logins + 1, 100),
                locked_until = CASE WHEN failed_logins + 1 >= $2 THEN now() + make_interval(secs => $3) ELSE locked_until END
          WHERE id = $1`,
        [userId, LOGIN_MAX_FAILURES, LOGIN_LOCK_SECONDS],
      );
    },

    async recordSuccessfulLogin(userId) {
      await q.query(`UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now() WHERE id = $1`, [userId]);
    },
  };
}

interface RotateSqlRow {
  id: string;
  family_id: string;
  user_id: string;
  revoked: boolean;
  revoked_reason: string | null;
  expired: boolean;
  status: string;
  deleted: boolean;
  name: string;
  phone_e164: string;
  role: string;
  created_at: Date;
}

export function createPgSessionsRepository(q: Tx): SessionsRepository {
  return {
    async create({ userId, tokenHash, userAgent }) {
      // A new family per login; expires_at is absolute and comes from the database clock.
      const r = await q.query<{ id: string; family_id: string; expires_at: Date }>(
        `INSERT INTO sessions (user_id, family_id, token_hash, expires_at, user_agent)
         VALUES ($1, gen_random_uuid(), $2, now() + make_interval(secs => $3), $4)
         RETURNING id, family_id, expires_at`,
        [userId, tokenHash, SESSION_TTL_SECONDS, userAgent],
      );
      const row = r.rows[0] as { id: string; family_id: string; expires_at: Date };
      return { sessionId: row.id, familyId: row.family_id, expiresAt: row.expires_at };
    },

    async findActiveByFamily(familyId, userId) {
      const r = await q.query<UserSqlRow & { session_id: string; family_id: string; last_used_at: Date }>(
        `SELECT s.id AS session_id, s.family_id, s.last_used_at,
                u.id, u.name, u.phone_e164, u.role, u.status, u.created_at
           FROM sessions s
           JOIN users u ON u.id = s.user_id
          WHERE s.family_id = $1
            AND s.user_id = $2
            AND s.revoked_at IS NULL
            AND s.expires_at > now()
            AND u.deleted_at IS NULL
            AND u.status = 'active'`,
        [familyId, userId],
      );
      const row = r.rows[0];
      return row ? { sessionId: row.session_id, familyId: row.family_id, lastUsedAt: row.last_used_at, user: toUserRow(row) } : null;
    },

    async rotate({ presentedHash, newHash, userAgent }) {
      const found = await q.query<RotateSqlRow>(
        `SELECT s.id, s.family_id, s.user_id,
                s.revoked_at IS NOT NULL AS revoked, s.revoked_reason, s.expires_at <= now() AS expired,
                u.status, u.deleted_at IS NOT NULL AS deleted, u.name, u.phone_e164, u.role, u.created_at
           FROM sessions s
           JOIN users u ON u.id = s.user_id
          WHERE s.token_hash = $1
            FOR UPDATE OF s`,
        [presentedHash],
      );
      const row = found.rows[0];
      if (!row) return { kind: 'rejected' };

      if (row.revoked) {
        if (row.revoked_reason !== 'rotated') return { kind: 'rejected' };
        // A token that was already exchanged is being presented again: it was copied. End the whole login session.
        await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'reuse_detected' WHERE family_id = $1 AND revoked_at IS NULL`, [row.family_id]);
        return { kind: 'reuse', userId: row.user_id };
      }
      if (row.expired || row.deleted || row.status !== 'active') return { kind: 'rejected' };

      // Same family and the SAME absolute expiry (copied inside SQL, so microseconds are preserved).
      const inserted = await q.query<{ id: string; expires_at: Date }>(
        `INSERT INTO sessions (user_id, family_id, token_hash, expires_at, user_agent)
         SELECT user_id, family_id, $2::bytea, expires_at, $3::text FROM sessions WHERE id = $1
         RETURNING id, expires_at`,
        [row.id, newHash, userAgent],
      );
      const created = inserted.rows[0] as { id: string; expires_at: Date };
      await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'rotated', replaced_by = $2 WHERE id = $1`, [row.id, created.id]);
      return {
        kind: 'rotated',
        user: toUserRow({ id: row.user_id, name: row.name, phone_e164: row.phone_e164, role: row.role, status: row.status, created_at: row.created_at }),
        session: { sessionId: created.id, familyId: row.family_id, expiresAt: created.expires_at },
      };
    },

    async revokeFamilyByTokenHash(tokenHash) {
      const r = await q.query(
        `UPDATE sessions SET revoked_at = now(), revoked_reason = 'logout'
          WHERE revoked_at IS NULL AND family_id = (SELECT family_id FROM sessions WHERE token_hash = $1)`,
        [tokenHash],
      );
      return (r.rowCount ?? 0) > 0;
    },

    async touch(sessionId) {
      await q.query(`UPDATE sessions SET last_used_at = now() WHERE id = $1 AND last_used_at < now() - make_interval(secs => $2)`, [sessionId, SESSION_TOUCH_INTERVAL_SECONDS]);
    },
  };
}

export function createPgAuthStore(db: Db): AuthStore {
  return {
    users: createPgUsersRepository(db),
    sessions: createPgSessionsRepository(db),
    transaction: (fn) => db.tx((t) => fn({ users: createPgUsersRepository(t), sessions: createPgSessionsRepository(t) })),
  };
}

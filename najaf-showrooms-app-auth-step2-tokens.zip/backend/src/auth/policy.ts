// Authentication policy constants (Phase 11.4, Step 1).
// Sources: the approved architecture (refresh token: 30 days absolute, 256-bit random; argon2id), the existing database
// limits (users.name >= 3 chars, app_settings limits.text: name 100, password 128) and the prototype rules (password >= 6).
// NOT in the approved plan, therefore PROPOSED and pending approval: the login lockout numbers and the password minimum.

/** argon2id parameters: OWASP minimum profile; identical to the PHC strings used throughout the database tests (m=19456,t=2,p=1). */
export const ARGON2 = { memoryCost: 19456, timeCost: 2, parallelism: 1 } as const;
export const ARGON2_PHC_PREFIX = '$argon2id$';

/** Opaque session token, stored only as SHA-256 in sessions.token_hash. */
export const SESSION_TOKEN_BYTES = 32;
/** Absolute lifetime (the approved refresh-token lifetime). In this step it is also what authenticates requests; see README. */
export const SESSION_TTL_SECONDS = 30 * 24 * 60 * 60;
/** sessions.last_used_at is refreshed at most this often (avoids a write per request). */
export const SESSION_TOUCH_INTERVAL_SECONDS = 60;

/** PROPOSED: consecutive failed logins before the account is locked, and for how long. */
export const LOGIN_MAX_FAILURES = 5;
export const LOGIN_LOCK_SECONDS = 15 * 60;

export const NAME_MIN = 3;
export const NAME_MAX = 100;
/** PROPOSED: matches the prototype (6); a production minimum of 8 is recommended. */
export const PASSWORD_MIN = 6;
export const PASSWORD_MAX = 128;
export const USER_AGENT_MAX = 300;
export const PHONE_INPUT_MAX = 32;

// ---- Step 2: access tokens, refresh rotation, rate limiting ----
/** Access token (HS256, claims: sub + sid only): short-lived; role and status are never read from it. */
export const ACCESS_TOKEN_TTL_SECONDS = 15 * 60;
export const ACCESS_TOKEN_CLOCK_SKEW_SECONDS = 30;
export const ACCESS_TOKEN_MAX_LENGTH = 400;
/** The refresh token is the stored session token. 30 days, absolute from login: rotation never extends it. */
export const REFRESH_TOKEN_TTL_SECONDS = SESSION_TTL_SECONDS;

/** PROPOSED (not in the approved plan): per client IP, in-process (per instance), fixed windows. */
export const RATE_LIMITS = {
  register: { limit: 5, windowSeconds: 60 * 60 },
  login: { limit: 10, windowSeconds: 5 * 60 },
  refresh: { limit: 60, windowSeconds: 10 * 60 },
  logout: { limit: 30, windowSeconds: 5 * 60 },
} as const;
export type RateLimitedRoute = keyof typeof RATE_LIMITS;
/** Upper bound on tracked keys, so memory cannot grow without limit under a spray of addresses. */
export const RATE_LIMIT_MAX_KEYS = 50_000;

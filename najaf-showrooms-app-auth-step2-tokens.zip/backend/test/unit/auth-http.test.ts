// HTTP contract of the authentication routes. The pure helpers and the route wiring always run; the Fastify tests need
// `fastify` (installed in CI) and are SKIPPED visibly when it is missing, never silently passed.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { RATE_LIMITS } from '../../src/auth/policy.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { bearerToken, isJsonContentType, registerAuthRoutes, toAuthHttp } from '../../src/auth/routes.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AuthApi, AuthResult } from '../../src/auth/types.ts';

const ACCESS = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.' + 'A'.repeat(60) + '.' + 'B'.repeat(43);
const REFRESH = 'nsj_' + 'A'.repeat(43);
const user = { id: '7', name: 'علي حسين', phone: '+9647701234567', role: 'user', status: 'active', createdAt: '2026-01-02T03:04:05.000Z' };
const grant: AuthResult = { user, session: { accessToken: ACCESS, accessExpiresAt: '2026-01-02T03:19:05.000Z', refreshToken: REFRESH, refreshExpiresAt: '2026-02-01T00:00:00.000Z' } };

describe('bearerToken', () => {
  it('extracts exactly one token from a well-formed header', () => {
    assert.equal(bearerToken(`Bearer ${ACCESS}`), ACCESS);
    assert.equal(bearerToken(`bearer ${ACCESS}`), ACCESS);
    assert.equal(bearerToken(`BEARER ${ACCESS}`), ACCESS);
  });
  it('returns undefined for everything else', () => {
    for (const h of [undefined, null, 5, '', 'Bearer', 'Bearer ', `Bearer  ${ACCESS}`, `Bearer ${ACCESS} extra`, `Basic ${ACCESS}`, ACCESS, ` Bearer ${ACCESS}`, [`Bearer ${ACCESS}`], `Bearer ${ACCESS}\n`]) {
      assert.equal(bearerToken(h), undefined, String(h));
    }
  });
});

describe('toAuthHttp: fixed status and generic message per error code', () => {
  it('maps every AuthError', () => {
    assert.deepEqual(toAuthHttp(new AuthError('conflict')), { status: 409, code: 'conflict', message: 'This account cannot be registered' });
    assert.deepEqual(toAuthHttp(new AuthError('invalid_credentials')), { status: 401, code: 'invalid_credentials', message: 'Invalid phone number or password' });
    assert.deepEqual(toAuthHttp(new AuthError('unauthorized')), { status: 401, code: 'unauthorized', message: 'Authentication required' });
    assert.deepEqual(toAuthHttp(new AuthError('validation_failed', [{ field: 'name', code: 'too_short' }])), { status: 400, code: 'validation_failed', message: 'The submitted data is not valid', fields: [{ field: 'name', code: 'too_short' }] });
  });
  it('ignores errors that are not AuthErrors (the global handler deals with them)', () => {
    for (const e of [new Error('boom'), 'x', null, { code: 'conflict' }]) assert.equal(toAuthHttp(e), undefined);
  });
});

describe('isJsonContentType', () => {
  it('accepts application/json with or without parameters, any case', () => {
    for (const ct of ['application/json', 'application/json; charset=utf-8', 'application/json;charset=UTF-8', 'APPLICATION/JSON', ' application/json ', 'application/json ; charset=utf-8']) assert.equal(isJsonContentType(ct), true, ct);
  });
  it('rejects everything else, including the types Fastify would otherwise parse (text/plain)', () => {
    for (const ct of ['text/plain', 'text/plain; charset=utf-8', 'text/json', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x', 'application/vnd.api+json', 'application/jsonx', 'application/json/x', 'application/xml', '', undefined, null, 5, ['application/json']]) {
      assert.equal(isJsonContentType(ct), false, String(ct));
    }
  });
});

// A minimal stand-in for the Fastify instance: it records the routes and hooks the plugin registers, so the wiring is
// verified here without Fastify. (The same behavior is verified end to end through real Fastify in the tests below, in CI.)
type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
function recordRoutes(withLimiter: boolean) {
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined });
  };
  const app = { get: add('GET'), post: add('POST') };
  const limiter = createMemoryRateLimiter();
  registerAuthRoutes(app as never, { auth: fakeAuthApi(), ...(withLimiter ? { rateLimiter: limiter } : {}) });
  return routes;
}
function fakeAuthApi(): AuthApi {
  return { register: async () => grant, login: async () => grant, refresh: async () => grant, authenticate: async () => null, logout: async () => {} };
}
function fakeReply() {
  const sent: { status?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}
const BODY_ROUTES = ['/v1/auth/register', '/v1/auth/login', '/v1/auth/refresh', '/v1/auth/logout'];

describe('authentication routes: wiring (no Fastify needed)', () => {
  it('registers exactly the five routes', () => {
    assert.deepEqual(recordRoutes(true).map((r) => `${r.method} ${r.path}`).sort(), ['GET /v1/auth/me', 'POST /v1/auth/login', 'POST /v1/auth/logout', 'POST /v1/auth/refresh', 'POST /v1/auth/register']);
  });

  it('every route that takes a body has a 4 KiB limit, a rate-limit hook FIRST and the JSON-only hook second; /me has neither', () => {
    const byPath = Object.fromEntries(recordRoutes(true).map((r) => [r.path, r.opts]));
    for (const path of BODY_ROUTES) {
      assert.equal(byPath[path]?.bodyLimit, 4096, path);
      assert.equal(byPath[path]?.onRequest?.length, 2, path);
    }
    assert.equal(byPath['/v1/auth/me'], undefined);
  });

  it('without a rate limiter only the JSON-only hook is attached (the behavior before rate limiting existed)', () => {
    for (const r of recordRoutes(false).filter((x) => BODY_ROUTES.includes(x.path))) assert.equal(r.opts?.onRequest?.length, 1, r.path);
  });

  it('the JSON-only hook answers 415 with a generic body for every non-JSON content type', async () => {
    for (const path of BODY_ROUTES) {
      const hooks = recordRoutes(true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      for (const ct of ['text/plain', 'text/plain; charset=utf-8', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x', 'application/vnd.api+json']) {
        const { reply, sent } = fakeReply();
        const out = await hooks[1]!({ headers: { 'content-type': ct }, id: 'req-1', ip: '1.1.1.1', log: { warn() {} } }, reply);
        assert.equal(out, reply);
        assert.equal(sent.status, 415, `${path} ${ct}`);
        assert.deepEqual(sent.body, { error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: 'req-1' } });
      }
    }
  });

  it('the JSON-only hook lets application/json (with or without charset) and a request with no content type continue', async () => {
    for (const path of BODY_ROUTES) {
      const hooks = recordRoutes(true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      for (const headers of [{ 'content-type': 'application/json' }, { 'content-type': 'application/json; charset=utf-8' }, {}]) {
        const { reply, sent } = fakeReply();
        assert.equal(await hooks[1]!({ headers, id: 'r' }, reply), undefined, `${path} ${JSON.stringify(headers)}`);
        assert.equal(sent.status, undefined);
      }
    }
  });

  it('the rate-limit hook of each route enforces that route\'s own limit, per client address, and answers 429 with Retry-After', async () => {
    for (const [path, route] of [['/v1/auth/register', 'register'], ['/v1/auth/login', 'login'], ['/v1/auth/refresh', 'refresh'], ['/v1/auth/logout', 'logout']] as const) {
      const hooks = recordRoutes(true).find((r) => r.path === path)?.opts?.onRequest as Hook[];
      const req = { ip: '203.0.113.9', id: 'r1', headers: {}, log: { warn() {} } };
      const limit = RATE_LIMITS[route].limit;
      for (let i = 0; i < limit; i++) assert.equal(await hooks[0]!(req, fakeReply().reply), undefined, `${route} #${i + 1}`);
      const { reply, sent } = fakeReply();
      assert.equal(await hooks[0]!(req, reply), reply, `${route} is limited after ${limit}`);
      assert.equal(sent.status, 429);
      assert.equal(sent.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
      assert.equal(await hooks[0]!({ ...req, ip: '203.0.113.10' }, fakeReply().reply), undefined, 'another address is unaffected');
    }
  });
});

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let reason: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'silent', NODE_ENV: 'test' });
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };

function fakeAuth(over: Partial<AuthApi> = {}): AuthApi {
  return {
    register: async () => grant,
    login: async () => grant,
    refresh: async () => grant,
    authenticate: async (t) => (t === ACCESS ? { user, sessionId: 'fam-1' } : null),
    logout: async () => {},
    ...over,
  };
}
const json = { 'content-type': 'application/json' };

describe('authentication routes over HTTP', { skip: reason }, () => {
  it('are absent when no AuthApi is supplied (existing behavior is untouched)', async () => {
    const app = await buildServer!({ config, db: okDb });
    assert.equal((await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: '{}' })).statusCode, 404);
    assert.equal((await app.inject({ method: 'GET', url: '/healthz' })).statusCode, 200);
    await app.close();
  });

  it('POST /v1/auth/register: 201 with the user and BOTH tokens', async () => {
    const seen: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async (i, c) => (seen.push(i, c), grant) }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: { ...json, 'user-agent': 'UA/1' }, payload: JSON.stringify({ name: 'علي حسين', phone: '07701234567', password: 'secret1' }) });
    assert.equal(r.statusCode, 201);
    assert.deepEqual(r.json(), grant);
    assert.deepEqual(seen, [{ name: 'علي حسين', phone: '07701234567', password: 'secret1' }, { userAgent: 'UA/1' }]);
    assert.equal(r.headers['cache-control'], 'no-store');
    await app.close();
  });

  it('POST /v1/auth/login: 200, and 401 with the generic body for a failure', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ login: async (i) => { if ((i as { password?: string }).password === 'bad') throw new AuthError('invalid_credentials'); return grant; } }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: '07701234567', password: 'good' }) });
    assert.equal(ok.statusCode, 200);
    const bad = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: '07701234567', password: 'bad' }) });
    assert.equal(bad.statusCode, 401);
    const body = bad.json() as { error: { code: string; message: string; requestId: string } };
    assert.deepEqual(Object.keys(body.error).sort(), ['code', 'message', 'requestId']);
    assert.equal(body.error.code, 'invalid_credentials');
    assert.equal(body.error.requestId, bad.headers['x-request-id']);
    await app.close();
  });

  it('POST /v1/auth/refresh: 200 with a new pair; every failure is the same generic 401', async () => {
    const calls: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ refresh: async (i) => { calls.push(i); if ((i as { refreshToken?: string }).refreshToken !== REFRESH) throw new AuthError('unauthorized'); return grant; } }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: REFRESH }) });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), grant);
    const bad = await app.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: 'nsj_' + 'B'.repeat(43) }) });
    assert.equal(bad.statusCode, 401);
    assert.equal(bad.headers['www-authenticate'], 'Bearer');
    assert.equal((bad.json() as { error: { code: string } }).error.code, 'unauthorized');
    assert.equal(calls.length, 2);
    await app.close();
  });

  it('validation errors are 400 with field names and codes only, for register, login, refresh and logout', async () => {
    const fail = () => { throw new AuthError('validation_failed', [{ field: 'refreshToken', code: 'invalid_format' }]); };
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: fail, login: fail, refresh: fail, logout: fail }) });
    for (const url of BODY_ROUTES) {
      const r = await app.inject({ method: 'POST', url, headers: json, payload: JSON.stringify({ password: 'TopSecretValue!', refreshToken: 'nsj_secret-looking-value' }) });
      assert.equal(r.statusCode, 400, url);
      assert.deepEqual((r.json() as { error: { fields: unknown } }).error.fields, [{ field: 'refreshToken', code: 'invalid_format' }]);
      assert.ok(!r.body.includes('TopSecretValue!') && !r.body.includes('secret-looking'));
    }
    await app.close();
  });

  it('a duplicate account is a generic 409', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => { throw new AuthError('conflict'); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: '{}' });
    assert.equal(r.statusCode, 409);
    assert.equal((r.json() as { error: { code: string } }).error.code, 'conflict');
    await app.close();
  });

  it('GET /v1/auth/me: 200 with the public user for a valid ACCESS token; 401 + WWW-Authenticate otherwise (a refresh token is not accepted)', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth() });
    const ok = await app.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${ACCESS}` } });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { user });
    const rejected: Array<Record<string, string>> = [{}, { authorization: 'Bearer ' + ACCESS.slice(0, -2) + 'zz' }, { authorization: 'Bearer garbage' }, { authorization: `Basic ${ACCESS}` }, { authorization: ACCESS }, { authorization: `Bearer ${REFRESH}` }];
    for (const headers of rejected) {
      const r = await app.inject({ method: 'GET', url: '/v1/auth/me', headers });
      assert.equal(r.statusCode, 401, JSON.stringify(headers));
      assert.equal(r.headers['www-authenticate'], 'Bearer');
      assert.equal((r.json() as { error: { code: string } }).error.code, 'unauthorized');
    }
    await app.close();
  });

  it('POST /v1/auth/logout: 204 for a refresh token in the body; the service receives exactly that body', async () => {
    const seen: unknown[] = [];
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ logout: async (i) => void seen.push(i) }) });
    const ok = await app.inject({ method: 'POST', url: '/v1/auth/logout', headers: json, payload: JSON.stringify({ refreshToken: REFRESH }) });
    assert.equal(ok.statusCode, 204);
    assert.equal(ok.body, '');
    assert.deepEqual(seen, [{ refreshToken: REFRESH }]);
    await app.close();
  });

  it('malformed JSON, a non-JSON content type and an oversized body are rejected generically before the service runs', async () => {
    let called = 0;
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ register: async () => (called++, grant), refresh: async () => (called++, grant) }) });
    const badJson = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: '{"name":' });
    assert.equal(badJson.statusCode, 400);
    assert.equal((badJson.json() as { error: { message: string } }).error.message, 'Bad request');
    // Fastify parses text/plain by default; these endpoints must refuse it (415) before the body is read or the service runs
    for (const url of BODY_ROUTES) {
      for (const contentType of ['text/plain', 'text/plain; charset=utf-8', 'application/x-www-form-urlencoded']) {
        const wrong = await app.inject({ method: 'POST', url, headers: { 'content-type': contentType }, payload: 'name=x&password=y' });
        assert.equal(wrong.statusCode, 415, `${url} ${contentType}`);
        const body = wrong.json() as { error: { code: string; message: string; requestId: string } };
        assert.equal(body.error.code, 'unsupported_media_type');
        assert.equal(body.error.requestId, wrong.headers['x-request-id']);
        assert.ok(!wrong.body.includes('password'), 'the refusal must not echo the body');
      }
    }
    const jsonOk = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: { 'content-type': 'application/json; charset=utf-8' }, payload: '{}' });
    assert.equal(jsonOk.statusCode, 201, 'application/json with a charset is still accepted');
    assert.equal(called, 1);
    called = 0;
    const big = await app.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'x'.repeat(10_000) }) });
    assert.equal(big.statusCode, 413);
    assert.equal(called, 0);
    await app.close();
  });

  it('an unexpected service failure is an opaque 500: no message, no stack', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth({ login: async () => { throw new Error('secret failure at /srv/app/auth.ts password=hunter2'); } }) });
    const r = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: '{}' });
    assert.equal(r.statusCode, 500);
    assert.ok(!r.body.includes('hunter2') && !r.body.includes('/srv/app'));
    assert.equal((r.json() as { error: { code: string } }).error.code, 'internal_error');
    await app.close();
  });
});

describe('rate limiting over HTTP', { skip: reason }, () => {
  const post = (app: Awaited<ReturnType<BuildServer>>, url: string, remoteAddress: string, extra: Record<string, string> = {}, payload = '{}') =>
    app.inject({ method: 'POST', url, headers: { ...json, ...extra }, payload, remoteAddress });

  it('each sensitive route answers 429 with Retry-After once its limit is spent; the service is not called for the blocked requests', async () => {
    for (const [url, route] of [['/v1/auth/register', 'register'], ['/v1/auth/login', 'login'], ['/v1/auth/refresh', 'refresh'], ['/v1/auth/logout', 'logout']] as const) {
      let called = 0;
      const count = async () => { called++; return grant; };
      const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth({ register: count, login: count, refresh: count, logout: async () => void called++ }) });
      const limit = RATE_LIMITS[route].limit;
      for (let i = 0; i < limit; i++) assert.ok((await post(app, url, '198.51.100.20')).statusCode < 300, `${route} #${i + 1}`);
      const blocked = await post(app, url, '198.51.100.20');
      assert.equal(blocked.statusCode, 429, route);
      assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS[route].windowSeconds));
      assert.deepEqual(Object.keys((blocked.json() as { error: object }).error).sort(), ['code', 'message', 'requestId']);
      assert.equal((blocked.json() as { error: { code: string } }).error.code, 'rate_limited');
      assert.equal(called, limit, `${route}: blocked requests never reach the service`);
      assert.equal((await post(app, url, '198.51.100.21')).statusCode < 300, true, 'another client is unaffected');
      await app.close();
    }
  });

  it('the limit applies before the body is read: garbage and wrong content types are 429 too once blocked', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth() });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '198.51.100.30');
    assert.equal((await post(app, '/v1/auth/login', '198.51.100.30', {}, '{"broken')).statusCode, 429);
    const text = await app.inject({ method: 'POST', url: '/v1/auth/login', headers: { 'content-type': 'text/plain' }, payload: 'x', remoteAddress: '198.51.100.30' });
    assert.equal(text.statusCode, 429);
    await app.close();
  });

  it('GET /v1/auth/me and the health endpoints are not rate limited', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth() });
    for (let i = 0; i < 200; i++) assert.equal((await app.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${ACCESS}` }, remoteAddress: '198.51.100.40' })).statusCode, 200);
    for (let i = 0; i < 50; i++) assert.equal((await app.inject({ method: 'GET', url: '/healthz', remoteAddress: '198.51.100.40' })).statusCode, 200);
    await app.close();
  });

  it('there is no limiting when no limiter is supplied', async () => {
    const app = await buildServer!({ config, db: okDb, auth: fakeAuth() });
    for (let i = 0; i < RATE_LIMITS.login.limit + 5; i++) assert.equal((await post(app, '/v1/auth/login', '198.51.100.50')).statusCode, 200);
    await app.close();
  });

  it('by default the client address is the socket address: a spoofed X-Forwarded-For cannot dodge the limit', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth() });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '198.51.100.60', { 'x-forwarded-for': `203.0.113.${i + 1}` });
    assert.equal((await post(app, '/v1/auth/login', '198.51.100.60', { 'x-forwarded-for': '203.0.113.200' })).statusCode, 429);
    await app.close();
  });

  it('behind a TRUSTED proxy the real client address (X-Forwarded-For) is used, so clients are limited separately', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth(), trustProxy: ['10.0.0.0/8'] });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '10.0.0.5', { 'x-forwarded-for': '203.0.113.1' });
    assert.equal((await post(app, '/v1/auth/login', '10.0.0.5', { 'x-forwarded-for': '203.0.113.1' })).statusCode, 429, 'that client is limited');
    assert.equal((await post(app, '/v1/auth/login', '10.0.0.5', { 'x-forwarded-for': '203.0.113.2' })).statusCode, 200, 'another client behind the same proxy is not');
    await app.close();
  });

  it('X-Forwarded-For is IGNORED when the connection is not from a trusted proxy, even if a proxy list is configured', async () => {
    const app = await buildServer!({ config, db: okDb, rateLimiter: createMemoryRateLimiter(), auth: fakeAuth(), trustProxy: ['10.0.0.0/8'] });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await post(app, '/v1/auth/login', '198.51.100.70', { 'x-forwarded-for': `203.0.113.${i + 1}` });
    assert.equal((await post(app, '/v1/auth/login', '198.51.100.70', { 'x-forwarded-for': '203.0.113.99' })).statusCode, 429);
    await app.close();
  });
});

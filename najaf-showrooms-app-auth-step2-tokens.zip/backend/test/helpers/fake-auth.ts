// Test doubles for the authentication layer. The fake hasher produces argon2id-SHAPED strings so the PHC checks are
// exercised, but it is a test double only: real argon2 runs in the CI integration tests.
import { createHash, randomUUID } from 'node:crypto';
import { DbError } from '../../src/errors.ts';
import type { PasswordHasher } from '../../src/auth/password.ts';
import { LOGIN_MAX_FAILURES, SESSION_TTL_SECONDS } from '../../src/auth/policy.ts';
import type { ActiveSession, AuthStore, CredentialRow, NewSession, RotateOutcome, SessionsRepository, UserRow, UsersRepository } from '../../src/auth/repository.ts';
import type { Logger } from '../../src/types.ts';

export function makeFakeHasher() {
  let n = 0;
  const calls = { hash: 0, verify: 0 };
  const digest = (salt: string, plain: string) => createHash('sha256').update(`${salt}\u0000${plain}`).digest('base64').replace(/=+$/, '');
  const hasher: PasswordHasher = {
    async ready() {},
    async hash(plain) {
      calls.hash += 1;
      const salt = `salt${++n}`;
      return `$argon2id$v=19$m=19456,t=2,p=1$${salt}$${digest(salt, plain)}`;
    },
    async verify(hash, plain) {
      calls.verify += 1;
      const parts = hash.split('$');
      if (parts.length !== 6) return false;
      return parts[5] === digest(parts[4] as string, plain);
    },
  };
  return { hasher, calls };
}

interface FakeUser extends UserRow {
  passwordHash: string;
  failedLogins: number;
  locked: boolean;
  lastLoginAt: Date | null;
  deletedAt: Date | null;
}
interface FakeSession {
  id: string;
  userId: string;
  tokenHash: Buffer;
  familyId: string;
  createdAt: Date;
  expiresAt: Date;
  lastUsedAt: Date;
  revokedAt: Date | null;
  revokedReason: string | null;
  replacedBy: string | null;
  userAgent: string | null;
}

/** A controllable clock shared by the fake database and the service, so expiry can be tested without waiting. */
export function makeClock(start = Date.UTC(2026, 0, 1)) {
  let t = start;
  return {
    now: () => t,
    advanceSeconds(s: number) {
      t += s * 1000;
    },
  };
}

export function makeFakeAuthStore(clock: { now(): number } = { now: () => Date.now() }) {
  let users: FakeUser[] = [];
  let sessions: FakeSession[] = [];
  let nextId = 1;
  const counters = { findCredentials: 0, findActive: 0, touch: 0, revoke: 0, sessionCreate: 0, rotate: 0 };
  const faults = { failNextSessionCreate: false };
  const live = (s: FakeSession) => s.revokedAt === null && s.expiresAt.getTime() > clock.now();
  const publicRow = (u: FakeUser): UserRow => ({ id: u.id, name: u.name, phoneE164: u.phoneE164, role: u.role, status: u.status, createdAt: u.createdAt });

  const usersRepo: UsersRepository = {
    async insert({ name, phoneE164, passwordHash }) {
      if (users.some((u) => u.phoneE164 === phoneE164 && u.deletedAt === null)) {
        throw new DbError('unique', { sqlstate: '23505', constraint: 'users_phone_active_uq', driverMessage: 'duplicate key value violates unique constraint "users_phone_active_uq"' });
      }
      // database defaults: role 'user', status 'active' (the repository interface has no way to pass them)
      const u: FakeUser = { id: String(nextId++), name, phoneE164, role: 'user', status: 'active', createdAt: new Date(clock.now()), passwordHash, failedLogins: 0, locked: false, lastLoginAt: null, deletedAt: null };
      users.push(u);
      return publicRow(u);
    },
    async findCredentialsByPhone(phoneE164): Promise<CredentialRow | null> {
      counters.findCredentials += 1;
      const u = users.find((x) => x.phoneE164 === phoneE164 && x.deletedAt === null);
      return u ? { ...publicRow(u), passwordHash: u.passwordHash, locked: u.locked } : null;
    },
    async recordFailedLogin(userId) {
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.failedLogins += 1;
      if (u.failedLogins >= LOGIN_MAX_FAILURES) u.locked = true;
    },
    async recordSuccessfulLogin(userId) {
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.failedLogins = 0;
      u.locked = false;
      u.lastLoginAt = new Date(clock.now());
    },
  };

  const sessionsRepo: SessionsRepository = {
    async create({ userId, tokenHash, userAgent }): Promise<NewSession> {
      counters.sessionCreate += 1;
      if (faults.failNextSessionCreate) {
        faults.failNextSessionCreate = false;
        throw new Error('simulated session insert failure');
      }
      const now = clock.now();
      const s: FakeSession = { id: randomUUID(), userId, tokenHash, familyId: randomUUID(), createdAt: new Date(now), expiresAt: new Date(now + SESSION_TTL_SECONDS * 1000), lastUsedAt: new Date(now), revokedAt: null, revokedReason: null, replacedBy: null, userAgent };
      sessions.push(s);
      return { sessionId: s.id, familyId: s.familyId, expiresAt: s.expiresAt };
    },
    async findActiveByFamily(familyId, userId): Promise<ActiveSession | null> {
      counters.findActive += 1;
      const s = sessions.find((x) => x.familyId === familyId && x.userId === userId && live(x));
      if (!s) return null;
      const u = users.find((x) => x.id === s.userId);
      if (!u || u.deletedAt !== null || u.status !== 'active') return null;
      return { sessionId: s.id, familyId: s.familyId, lastUsedAt: s.lastUsedAt, user: publicRow(u) };
    },
    async rotate({ presentedHash, newHash, userAgent }): Promise<RotateOutcome> {
      counters.rotate += 1;
      const old = sessions.find((x) => x.tokenHash.equals(presentedHash));
      if (!old) return { kind: 'rejected' };
      if (old.revokedAt !== null) {
        if (old.revokedReason !== 'rotated') return { kind: 'rejected' };
        for (const s of sessions) if (s.familyId === old.familyId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'reuse_detected'; }
        return { kind: 'reuse', userId: old.userId };
      }
      const u = users.find((x) => x.id === old.userId);
      if (old.expiresAt.getTime() <= clock.now() || !u || u.deletedAt !== null || u.status !== 'active') return { kind: 'rejected' };
      const fresh: FakeSession = { id: randomUUID(), userId: old.userId, tokenHash: newHash, familyId: old.familyId, createdAt: new Date(clock.now()), expiresAt: old.expiresAt, lastUsedAt: new Date(clock.now()), revokedAt: null, revokedReason: null, replacedBy: null, userAgent };
      sessions.push(fresh);
      old.revokedAt = new Date(clock.now());
      old.revokedReason = 'rotated';
      old.replacedBy = fresh.id;
      return { kind: 'rotated', user: publicRow(u), session: { sessionId: fresh.id, familyId: fresh.familyId, expiresAt: fresh.expiresAt } };
    },
    async revokeFamilyByTokenHash(tokenHash) {
      counters.revoke += 1;
      const any = sessions.find((x) => x.tokenHash.equals(tokenHash));
      if (!any) return false;
      let changed = false;
      for (const s of sessions) if (s.familyId === any.familyId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'logout'; changed = true; }
      return changed;
    },
    async touch(sessionId) {
      counters.touch += 1;
      const s = sessions.find((x) => x.id === sessionId);
      if (s) s.lastUsedAt = new Date(clock.now());
    },
  };

  const store: AuthStore = {
    users: usersRepo,
    sessions: sessionsRepo,
    async transaction(fn) {
      const snapshot = { users: users.map((u) => ({ ...u })), sessions: sessions.map((s) => ({ ...s })), nextId };
      try {
        return await fn({ users: usersRepo, sessions: sessionsRepo });
      } catch (e) {
        users = snapshot.users;
        sessions = snapshot.sessions;
        nextId = snapshot.nextId;
        throw e;
      }
    },
  };

  return {
    store,
    counters,
    faults,
    users: () => users,
    sessions: () => sessions,
    /** everything the "database" holds, as text: used to prove secrets are not stored */
    dump: () => JSON.stringify({ users, sessions: sessions.map((s) => ({ ...s, tokenHash: s.tokenHash.toString('hex') })) }),
    unlock(userId: string) {
      const u = users.find((x) => x.id === userId);
      if (u) u.locked = false;
    },
    setStatus(userId: string, status: string) {
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.status = status;
      if (status === 'suspended') for (const s of sessions) if (s.userId === userId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'user_suspended'; }
    },
    expireAllSessions() {
      for (const s of sessions) s.expiresAt = new Date(clock.now() - 1000);
    },
  };
}

export function recordingLogger() {
  const entries: unknown[] = [];
  const logger: Logger = {
    debug: (o) => entries.push(o),
    info: (o) => entries.push(o),
    warn: (o) => entries.push(o),
    error: (o) => entries.push(o),
  };
  return { logger, entries, text: () => JSON.stringify(entries) };
}

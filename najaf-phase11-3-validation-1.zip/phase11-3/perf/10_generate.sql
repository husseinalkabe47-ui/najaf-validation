-- توليد بيانات اصطناعية للأداء (قاعدة منفصلة، بمشرف). المتغيرات من runner: ncars, ndealers, nmembers, nfav, nsess
\set ON_ERROR_STOP 1
CREATE SCHEMA perf;
CREATE TABLE perf.marks (id serial PRIMARY KEY, step text NOT NULL, at timestamptz NOT NULL DEFAULT clock_timestamp());
INSERT INTO perf.marks (step) VALUES ('start');
SELECT (:ncars * 7 / 10) AS nshow, (:ncars - :ncars * 7 / 10) AS nmem \gset

-- التحميل الكمّي يتخطى المشغّلات (المفاتيح الأجنبية وحراس الصور) للسرعة؛ قيود CHECK والفهارس الفريدة تبقى فعّالة.
-- سلامة المفاتيح والثوابت تُتحقَّق بعد التحميل باستعلامات صريحة (perf.checks).
SET session_replication_role = replica;

INSERT INTO users (name, phone_e164, role, status, password_hash)
VALUES ('مدير الأداء', '+9647000000001', 'admin', 'active', '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA');
INSERT INTO users (name, phone_e164, role, status, password_hash, created_at)
SELECT 'تاجر ' || g, '+9647' || lpad((100000000 + g)::text, 9, '0'), 'dealer',
       CASE WHEN g % 20 = 0 THEN 'pending' WHEN g % 33 = 0 THEN 'suspended' ELSE 'active' END,
       '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA', now() - (random() * interval '700 days')
  FROM generate_series(1, :ndealers) g;
INSERT INTO users (name, phone_e164, role, status, password_hash, created_at)
SELECT 'عضو ' || g, '+9647' || lpad((200000000 + g)::text, 9, '0'), 'user',
       CASE WHEN g % 50 = 0 THEN 'suspended' ELSE 'active' END,
       '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA', now() - (random() * interval '700 days')
  FROM generate_series(1, :nmembers) g;
INSERT INTO perf.marks (step) VALUES ('users');

INSERT INTO showrooms (owner_id, name, description, phone, address, latitude, longitude, status, search_text, created_at)
SELECT u.id, 'معرض ' || u.id, 'وصف المعرض', u.phone_e164, 'النجف الأشرف',
       round((31.95 + random() * 0.1)::numeric, 6), round((44.28 + random() * 0.1)::numeric, 6),
       CASE WHEN u.id % 25 = 0 THEN 'pending' WHEN u.id % 17 = 0 THEN 'suspended' ELSE 'active' END,
       lower('معرض ' || u.id), u.created_at
  FROM users u WHERE u.role = 'dealer';
INSERT INTO perf.marks (step) VALUES ('showrooms');

CREATE TEMP TABLE sr AS SELECT row_number() OVER (ORDER BY id) AS rn, id, owner_id FROM showrooms;
CREATE TEMP TABLE mb AS SELECT row_number() OVER (ORDER BY id) AS rn, id, phone_e164 FROM users WHERE role = 'user';
CREATE TEMP TABLE br (rn integer, brand text, models text[]);
INSERT INTO br VALUES
 (1, 'Toyota', ARRAY['Camry','Corolla','Land Cruiser','Hilux','Prado','Yaris']), (2, 'Kia', ARRAY['Rio','Cerato','Sportage','Sorento','Optima','Picanto']),
 (3, 'Hyundai', ARRAY['Elantra','Sonata','Tucson','Accent','Santa Fe','Azera']), (4, 'Nissan', ARRAY['Altima','Sunny','Patrol','Maxima','Sentra','X-Trail']),
 (5, 'Chevrolet', ARRAY['Malibu','Cruze','Tahoe','Impala','Captiva','Optra']), (6, 'Ford', ARRAY['Explorer','Edge','Fusion','Mustang','F-150','Taurus']),
 (7, 'Honda', ARRAY['Accord','Civic','CR-V','Pilot','City','Jazz']), (8, 'Mercedes-Benz', ARRAY['C200','E300','S500','GLE','GLC','A200']),
 (9, 'BMW', ARRAY['320i','520i','X5','X3','730Li','116i']), (10, 'Mitsubishi', ARRAY['Lancer','Pajero','Outlander','L200','ASX','Montero']),
 (11, 'GMC', ARRAY['Yukon','Sierra','Acadia','Terrain','Envoy','Canyon']), (12, 'Lexus', ARRAY['ES350','LX570','RX350','GX460','IS250','LS460']);
CREATE TEMP TABLE colors AS SELECT t.color, t.rn FROM unnest(ARRAY['أبيض','أسود','فضي','رمادي','أحمر','أزرق','ذهبي','بني']) WITH ORDINALITY AS t(color, rn);

INSERT INTO cars (source_type, showroom_id, brand, model, year, price, currency, mileage, transmission, fuel_type, color, description, status, search_text, created_at, updated_at)
SELECT 'showroom', s.id, b.brand, b.models[1 + (g % 6)], 2005 + (g % 21),
       CASE WHEN g % 5 = 0 THEN 3000 + (g * 131) % 60000 ELSE 5000000 + (g::bigint * 7919) % 70000000 END,
       CASE WHEN g % 5 = 0 THEN 'USD' ELSE 'IQD' END,
       (g * 37) % 250000, CASE WHEN g % 3 = 0 THEN 'يدوي' ELSE 'أوتوماتيك' END,
       (ARRAY['بنزين','ديزل','هايبرد','كهرباء'])[1 + (g % 4)], c.color, 'سيارة بحالة جيدة رقم ' || g,
       CASE WHEN g % 10 = 0 THEN 'sold' ELSE 'available' END,
       lower(b.brand || ' ' || b.models[1 + (g % 6)] || ' ' || (2005 + (g % 21)) || ' ' || c.color),
       now() - (g * interval '10 minutes'), now() - (g * interval '10 minutes')
  FROM generate_series(1, :nshow) g
  JOIN sr s ON s.rn = 1 + ((g::bigint * 7919) % (SELECT count(*) FROM sr))
  JOIN br b ON b.rn = 1 + (g % 12)
  JOIN colors c ON c.rn = 1 + (g % 8);

INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, mileage, transmission, fuel_type, color, description, status,
                  phone, whatsapp, location, latitude, longitude, search_text, created_at, updated_at)
SELECT 'member', m.id, b.brand, b.models[1 + (g % 6)], 2005 + (g % 21),
       CASE WHEN g % 7 = 0 THEN 3000 + (g * 131) % 60000 ELSE 5000000 + (g::bigint * 7919) % 70000000 END,
       CASE WHEN g % 7 = 0 THEN 'USD' ELSE 'IQD' END,
       (g * 53) % 250000, 'أوتوماتيك', (ARRAY['بنزين','ديزل','هايبرد','كهرباء'])[1 + (g % 4)], c.color, 'إعلان عضو ' || g,
       CASE WHEN g % 20 < 15 THEN 'active' WHEN g % 20 < 17 THEN 'sold' WHEN g % 20 = 17 THEN 'pending' WHEN g % 20 = 18 THEN 'rejected' ELSE 'suspended' END,
       m.phone_e164, m.phone_e164, 'النجف', round((31.95 + random() * 0.1)::numeric, 6), round((44.28 + random() * 0.1)::numeric, 6),
       lower(b.brand || ' ' || b.models[1 + (g % 6)] || ' ' || (2005 + (g % 21)) || ' ' || c.color),
       now() - (g * interval '20 minutes'), now() - (g * interval '20 minutes')
  FROM generate_series(1, :nmem) g
  JOIN mb m ON m.rn = 1 + ((g::bigint * 104729) % (SELECT count(*) FROM mb))
  JOIN br b ON b.rn = 1 + ((g + 5) % 12)
  JOIN colors c ON c.rn = 1 + ((g + 3) % 8);
INSERT INTO perf.marks (step) VALUES ('cars');

CREATE TEMP TABLE n AS
SELECT c.id AS car_id, k AS k, gen_random_uuid() AS aid, CASE WHEN c.source_type = 'member' THEN c.owner_id ELSE s.owner_id END AS own
  FROM cars c LEFT JOIN showrooms s ON s.id = c.showroom_id
  CROSS JOIN LATERAL generate_series(1, 1 + (c.id % 3)) AS k;
INSERT INTO assets (id, owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at)
SELECT aid, own, 'car_image', 'ready', 'perf/' || aid || '/full.webp', 'perf/' || aid || '/thumb.webp', 'image/webp', 120000, 1600, 1066,
       encode(sha256(convert_to(aid::text, 'UTF8')), 'hex'), now() FROM n;
INSERT INTO car_images (car_id, asset_id, sort_order, is_main) SELECT car_id, aid, k - 1, k = 1 FROM n;
INSERT INTO perf.marks (step) VALUES ('images');

INSERT INTO favorites (user_id, car_id)
SELECT DISTINCT m.id, c.id
  FROM (SELECT 1 + ((g::bigint * 15485863) % (SELECT count(*) FROM mb)) AS rn1, 1 + ((g::bigint * 32452843) % :ncars) AS cn FROM generate_series(1, :nfav) g) x
  JOIN mb m ON m.rn = x.rn1
  JOIN (SELECT id, row_number() OVER (ORDER BY id) AS rn FROM cars) c ON c.rn = x.cn;
INSERT INTO sessions (user_id, family_id, token_hash, created_at, last_used_at, expires_at)
SELECT m.id, gen_random_uuid(), sha256(convert_to('s' || g, 'UTF8')), now() - interval '1 day', now(), now() + interval '29 days'
  FROM generate_series(1, :nsess) g JOIN mb m ON m.rn = 1 + (g % (SELECT count(*) FROM mb));
INSERT INTO audit_logs (actor_id, actor_role, action, entity_type, entity_id, after_data)
SELECT 1, 'admin', 'perf.seed', 'cars', (g % 1000)::text, '{"k":1}'::jsonb FROM generate_series(1, 100000) g;
INSERT INTO message_deliveries (channel, provider, to_phone, status, cost_micros, provider_message_id)
SELECT CASE WHEN g % 10 = 0 THEN 'sms' ELSE 'whatsapp' END, 'twilio', '+9647' || lpad((200000000 + (g % 40000))::text, 9, '0'), 'delivered',
       CASE WHEN g % 10 = 0 THEN 350000 ELSE 9100 END, 'perf-' || g FROM generate_series(1, 50000) g;
INSERT INTO exchange_rates (usd_to_iqd, kind, note) VALUES (1300.00, 'manual', 'perf');
INSERT INTO perf.marks (step) VALUES ('other');

RESET session_replication_role;
ANALYZE;
INSERT INTO perf.marks (step) VALUES ('analyze');

-- ===== سلامة البيانات المولَّدة (لأن المفاتيح الأجنبية والمشغّلات تُخطّيت أثناء التحميل) =====
CREATE TABLE perf.checks (name text, bad bigint);
INSERT INTO perf.checks VALUES
 ('cars بلا معرض صالح', (SELECT count(*) FROM cars c WHERE c.source_type = 'showroom' AND NOT EXISTS (SELECT 1 FROM showrooms s WHERE s.id = c.showroom_id))),
 ('cars بلا مالك صالح', (SELECT count(*) FROM cars c WHERE c.source_type = 'member' AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = c.owner_id))),
 ('car_images بلا سيارة', (SELECT count(*) FROM car_images i WHERE NOT EXISTS (SELECT 1 FROM cars c WHERE c.id = i.car_id))),
 ('car_images بلا أصل', (SELECT count(*) FROM car_images i WHERE NOT EXISTS (SELECT 1 FROM assets a WHERE a.id = i.asset_id))),
 ('سيارات لها صور بلا رئيسية واحدة بالضبط', (SELECT count(*) FROM (SELECT car_id FROM car_images GROUP BY car_id HAVING count(*) FILTER (WHERE is_main) <> 1) s)),
 ('سيارات تتجاوز سقف الصور', (SELECT count(*) FROM (SELECT i.car_id FROM car_images i JOIN cars c ON c.id = i.car_id GROUP BY i.car_id, c.source_type HAVING count(*) > CASE c.source_type WHEN 'member' THEN 4 ELSE 5 END) s)),
 ('favorites بلا مستخدم/سيارة', (SELECT count(*) FROM favorites f WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = f.user_id) OR NOT EXISTS (SELECT 1 FROM cars c WHERE c.id = f.car_id))),
 ('showrooms مالكها ليس تاجرًا', (SELECT count(*) FROM showrooms s JOIN users u ON u.id = s.owner_id WHERE u.role <> 'dealer'));
INSERT INTO perf.marks (step) VALUES ('checks');

-- ===== كلفة حارس الصور مع تفعيل المشغّلات: 1000 إعلان × 3 صور =====
DO $$
DECLARE t0 timestamptz; u bigint; c bigint; a uuid;
BEGIN
  SELECT id INTO u FROM users WHERE role = 'user' AND status = 'active' ORDER BY id LIMIT 1;
  t0 := clock_timestamp();
  FOR i IN 1..1000 LOOP
    INSERT INTO cars (source_type, owner_id, brand, model, year, price, status, phone) VALUES ('member', u, 'Kia', 'Rio', 2020, 1000000, 'active', '+9647700000001') RETURNING id INTO c;
    FOR k IN 1..3 LOOP
      INSERT INTO assets (owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at)
      VALUES (u, 'car_image', 'ready', 'g/' || gen_random_uuid(), 'g/' || gen_random_uuid(), 'image/webp', 10, 1, 1, encode(sha256(convert_to(gen_random_uuid()::text, 'UTF8')), 'hex'), now()) RETURNING id INTO a;
      INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (c, a, k - 1, k = 1);
    END LOOP;
  END LOOP;
  INSERT INTO perf.marks (step) VALUES ('guard_triggers_on: 1000 cars + 3000 images ms=' || round(extract(epoch FROM clock_timestamp() - t0) * 1000));
END $$;

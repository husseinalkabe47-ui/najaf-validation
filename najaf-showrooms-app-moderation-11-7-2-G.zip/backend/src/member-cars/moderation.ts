// Administrator moderation of member car ads (Phase 11.7.2-G): list and read the ads under review, approve, reject, suspend, restore.
//
// The rules (each is covered by tests):
//  - Only an administrator (the verified token's account, re-read from the database) may use this module. Anyone else, and an
//    unknown or malformed id, gets the SAME 404 before anything is read. The administrator never edits an ad's content and never
//    marks it sold (the policy gives them read, delete and `moderate` only): only OWNERS mark an ad sold or edit it.
//  - Transitions are fixed by the server (TRANSITIONS below); nothing in a request names a status:
//        approve  pending   -> active      (publishes the ad: see the reward gate)
//        reject   pending   -> rejected    (reason optional)
//        suspend  active    -> suspended   (reason REQUIRED)
//        restore  suspended -> active
//    A rejected ad can NOT be restored or approved by an administrator: its owner must edit it (which resubmits it as 'pending',
//    member-cars/service.ts), and only then can it be reviewed again. Any other combination is 409 invalid_state.
//  - REWARD GATE: an ad is published (approved) only if the database holds a rewarded-ad grant that was verified server-side
//    (reward_grants: status 'consumed' with an ssv_transaction_id and verified_at) and is bound to THIS ad and THIS owner. Nothing
//    a client sends can satisfy it. This repository only READS reward_grants: the verification itself (the AdMob server-side
//    verification callback that creates verified grants) does not exist yet, so today no ad has such a grant and approving is
//    refused with 409 reward_required. Reject, suspend and restore do not depend on it (a restored ad was published before).
//  - Optimistic concurrency: every action names the `version` the administrator last saw. Inside ONE transaction the acting account
//    is re-checked and share-locked, the ad is locked FOR UPDATE, the version is compared (409 version_conflict), the transition is
//    a compare-and-swap on version AND on the source status, and the audit row is written. All or nothing.
//  - Public visibility is not decided here: the public_cars view shows a member ad only while its status is 'active' and its owner
//    is active, so approve/restore make it public and reject/suspend hide it, by the status alone.
//  - The review stamp (reviewed_by/at) is written by the server; the administrator's id never appears in a response.
import { authorize, memberCarResource, notFound } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';
import type { FieldError, Parsed } from '../auth/validation.ts';
import type { Db, Tx } from '../db.ts';
import { toOwnMemberCar } from './service.ts';
import type { OwnMemberCar } from './service.ts';
import type { MemberCarRow } from './repository.ts';
import { MEMBER_CAR_STATUSES, parseCarId } from './validation.ts';
import type { MemberCarStatus } from './validation.ts';

export type ModerationAction = 'approve' | 'reject' | 'suspend' | 'restore';
export const MODERATION_ACTIONS: readonly ModerationAction[] = ['approve', 'reject', 'suspend', 'restore'];
export const TRANSITIONS: Readonly<Record<ModerationAction, { from: MemberCarStatus; to: MemberCarStatus }>> = Object.freeze({
  approve: { from: 'pending', to: 'active' },
  reject: { from: 'pending', to: 'rejected' },
  suspend: { from: 'active', to: 'suspended' },
  restore: { from: 'suspended', to: 'active' },
});
export const REASON_MAX = 500; // varchar(500)
export const LIST_LIMIT_DEFAULT = 50;
export const LIST_LIMIT_MAX = 100;

export type ModerationErrorCode = 'validation_failed' | 'version_conflict' | 'invalid_state' | 'reward_required';
const MESSAGES: Record<ModerationErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  version_conflict: 'The ad was changed by another request; reload it and try again',
  invalid_state: 'The ad is not in a state that allows this action',
  reward_required: 'The ad has no verified rewarded-ad grant, so it cannot be published',
};
export class ModerationError extends Error {
  readonly code: ModerationErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: ModerationErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'ModerationError';
    this.code = code;
    this.fields = fields;
  }
}

/** What an ad row looks like to the administrator: the owner's view plus WHO owns it and when it was reviewed. */
export interface ModeratedRow extends MemberCarRow {
  ownerName: string;
  reviewedAt: Date | null;
}
export interface AdminMemberCar extends OwnMemberCar {
  ownerId: string;
  ownerName: string;
  reviewedAt: string | null;
}
export interface AdminPage {
  items: AdminMemberCar[];
  nextAfter: string | null;
}
export interface ModerationContext {
  requestId?: string | undefined;
}

export interface ModerationApi {
  list(actor: Actor | null, query: unknown): Promise<AdminPage>;
  get(actor: Actor | null, rawId: unknown): Promise<AdminMemberCar>;
  act(actor: Actor | null, action: ModerationAction, rawId: unknown, body: unknown, ctx?: ModerationContext): Promise<AdminMemberCar>;
}

// ---------------------------------------------------------------- validation

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;
const LIMIT_PATTERN = /^[1-9][0-9]{0,2}$/;

export interface ListQuery {
  status: MemberCarStatus;
  afterId: string | null;
  limit: number;
}

/** ?status=pending|active|sold|rejected|suspended (default pending) &after=<id> &limit=1..100 (default 50). Unknown keys are rejected. */
export function parseAdminListQuery(query: unknown): Parsed<ListQuery> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  for (const key of Object.keys(q)) if (!['status', 'after', 'limit'].includes(key)) errors.push({ field: SAFE_FIELD.test(key) ? key : 'unknown', code: 'unknown_field' });
  let status: MemberCarStatus = 'pending';
  const s = q['status'];
  if (s !== undefined) {
    if (typeof s !== 'string') errors.push({ field: 'status', code: 'invalid_type' });
    else if (!(MEMBER_CAR_STATUSES as readonly string[]).includes(s)) errors.push({ field: 'status', code: 'invalid_format' });
    else status = s as MemberCarStatus;
  }
  let afterId: string | null = null;
  const a = q['after'];
  if (a !== undefined) {
    if (typeof a !== 'string') errors.push({ field: 'after', code: 'invalid_type' });
    else if (parseCarId(a) === null) errors.push({ field: 'after', code: 'invalid_format' });
    else afterId = a;
  }
  let limit = LIST_LIMIT_DEFAULT;
  const l = q['limit'];
  if (l !== undefined) {
    if (typeof l !== 'string') errors.push({ field: 'limit', code: 'invalid_type' });
    else if (!LIMIT_PATTERN.test(l) || Number(l) > LIST_LIMIT_MAX) errors.push({ field: 'limit', code: 'invalid_format' });
    else limit = Number(l);
  }
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { status, afterId, limit } };
}

export interface ActionInput {
  version: number;
  /** The administrator's note. Optional for reject (null when absent or blank), required for suspend, not accepted otherwise. */
  reason: string | null;
}

/** Body of a moderation action: {version} (+ {reason} for reject and suspend). Strict whitelist; the value is never echoed. */
export function parseActionInput(action: ModerationAction, body: unknown): Parsed<ActionInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  const allowed = action === 'reject' || action === 'suspend' ? ['version', 'reason'] : ['version'];
  for (const key of Object.keys(body)) if (!allowed.includes(key)) errors.push({ field: SAFE_FIELD.test(key) ? key : 'unknown', code: 'unknown_field' });
  const v = body['version'];
  let version = 0;
  if (v === undefined) errors.push({ field: 'version', code: 'required' });
  else if (typeof v !== 'number' || !Number.isSafeInteger(v) || v < 1) errors.push({ field: 'version', code: 'invalid_format' });
  else version = v;
  let reason: string | null = null;
  if (action === 'reject' || action === 'suspend') {
    const r = body['reason'];
    if (r === undefined || r === null) {
      if (action === 'suspend') errors.push({ field: 'reason', code: 'required' });
    } else if (typeof r !== 'string') errors.push({ field: 'reason', code: 'invalid_type' });
    else {
      const t = r.normalize('NFC').trim();
      if (CONTROL.test(t)) errors.push({ field: 'reason', code: 'invalid_format' });
      else if (Array.from(t).length > REASON_MAX) errors.push({ field: 'reason', code: 'too_long' });
      else if (t === '') {
        if (action === 'suspend') errors.push({ field: 'reason', code: 'required' });
      } else reason = t;
    }
  }
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { version, reason } };
}

function parsed<T>(r: Parsed<T>): T {
  if (!r.ok) throw new ModerationError('validation_failed', r.errors);
  return r.value;
}

// ---------------------------------------------------------------- repository

export interface ModerationRepository {
  /** Re-checks INSIDE the transaction that the acting administrator is still active and not deleted, and SHARE-locks it. */
  lockActingUser(userId: string): Promise<boolean>;
  /** Member ads that are not deleted with this status, oldest id first (keyset on id). */
  list(q: ListQuery): Promise<ModeratedRow[]>;
  /** One member ad that is not deleted; null for anything else (a showroom car, deleted, unknown). */
  find(id: string): Promise<ModeratedRow | null>;
  /** find, locked FOR UPDATE until the end of the transaction. */
  lock(id: string): Promise<ModeratedRow | null>;
  /** A server-verified, consumed rewarded-ad grant bound to this ad and this owner exists. READ ONLY. */
  hasVerifiedReward(carId: string, ownerId: string): Promise<boolean>;
  /** Compare-and-swap of the status (and reasons and review stamp). null = not at expectedVersion or not in `from`. */
  transition(input: { id: string; expectedVersion: number; action: ModerationAction; reason: string | null; reviewerId: string }): Promise<ModeratedRow | null>;
}
export interface ModerationStore {
  /** Autocommit reads. */
  cars: ModerationRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { cars: ModerationRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

const COLUMNS = `c.id, c.owner_id, c.brand, c.model, c.year, c.price, c.currency, c.mileage, c.transmission, c.fuel_type, c.color,
       c.description, c.phone, c.whatsapp, c.location, c.latitude, c.longitude, c.status, c.rejection_reason, c.suspension_reason,
       c.reviewed_at, c.version, c.created_at, c.updated_at`;
const RETURNING = COLUMNS.replace(/c\./g, '');
const MEMBER_LIVE = `c.source_type = 'member' AND c.deleted_at IS NULL`;

interface SqlRow {
  id: string;
  owner_id: string;
  owner_name?: string;
  owner_active?: boolean;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuel_type: string;
  color: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  location: string | null;
  latitude: string | null;
  longitude: string | null;
  status: string;
  rejection_reason: string | null;
  suspension_reason: string | null;
  reviewed_at: Date | null;
  version: number;
  created_at: Date;
  updated_at: Date;
}
const toRow = (r: SqlRow): ModeratedRow => ({
  id: String(r.id),
  ownerId: String(r.owner_id),
  ownerName: r.owner_name ?? '',
  ownerActive: r.owner_active === true,
  brand: r.brand,
  model: r.model,
  year: Number(r.year),
  price: String(r.price),
  currency: r.currency,
  mileage: r.mileage === null ? null : Number(r.mileage),
  transmission: r.transmission,
  fuelType: r.fuel_type,
  color: r.color,
  description: r.description,
  phone: r.phone,
  whatsapp: r.whatsapp,
  location: r.location,
  latitude: r.latitude === null ? null : String(r.latitude),
  longitude: r.longitude === null ? null : String(r.longitude),
  status: r.status,
  rejectionReason: r.rejection_reason,
  suspensionReason: r.suspension_reason,
  reviewedAt: r.reviewed_at,
  version: Number(r.version),
  createdAt: r.created_at,
  updatedAt: r.updated_at,
});

/** SQL builders, exported so tests can pin their text. Every status is a SQL literal taken from TRANSITIONS (never from a request). */
export function buildList(q: ListQuery): { text: string; values: unknown[] } {
  const values: unknown[] = [q.status];
  const where = [MEMBER_LIVE, `c.status = $1`];
  if (q.afterId !== null) {
    values.push(q.afterId);
    where.push(`c.id > $${values.length}::bigint`);
  }
  values.push(q.limit);
  return {
    text: `SELECT ${COLUMNS}, u.name AS owner_name, (u.status = 'active' AND u.deleted_at IS NULL) AS owner_active
             FROM cars c JOIN users u ON u.id = c.owner_id
            WHERE ${where.join(' AND ')} ORDER BY c.id ASC LIMIT $${values.length}`,
    values,
  };
}
export function buildFind(id: string, lock: boolean): { text: string; values: unknown[] } {
  return {
    text: `SELECT ${COLUMNS}, u.name AS owner_name, (u.status = 'active' AND u.deleted_at IS NULL) AS owner_active
             FROM cars c JOIN users u ON u.id = c.owner_id
            WHERE c.id = $1::bigint AND ${MEMBER_LIVE}${lock ? '\n              FOR UPDATE OF c' : ''}`,
    values: [id],
  };
}
export function buildHasVerifiedReward(carId: string, ownerId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT 1 FROM reward_grants
            WHERE car_id = $1::bigint AND user_id = $2::bigint AND status = 'consumed'
              AND ssv_transaction_id IS NOT NULL AND verified_at IS NOT NULL AND consumed_at IS NOT NULL
            LIMIT 1`,
    values: [carId, ownerId],
  };
}
export function buildTransition(input: { id: string; expectedVersion: number; action: ModerationAction; reason: string | null; reviewerId: string }): { text: string; values: unknown[] } {
  const t = Object.hasOwn(TRANSITIONS, input.action) ? TRANSITIONS[input.action] : undefined;
  if (!t) throw new Error('unknown moderation action');
  // Reasons by action: reject keeps its (optional) reason, suspend keeps its required one; approve and restore clear them.
  const rejection = input.action === 'reject' ? '$3' : 'NULL';
  const suspension = input.action === 'suspend' ? '$3' : 'NULL';
  return {
    text: `UPDATE cars c SET status = '${t.to}', rejection_reason = ${rejection}, suspension_reason = ${suspension}, reviewed_at = now(), reviewed_by = $4::bigint
            WHERE c.id = $1::bigint AND ${MEMBER_LIVE} AND c.version = $2 AND c.status = '${t.from}'
        RETURNING ${RETURNING}`,
    values: [input.id, input.expectedVersion, input.reason, input.reviewerId],
  };
}

export function createPgModerationRepository(q: Tx): ModerationRepository {
  const run = async (s: { text: string; values: unknown[] }) => q.query<SqlRow>(s.text, s.values);
  return {
    async lockActingUser(userId) {
      const r = await q.query(`SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`, [userId]);
      return r.rows.length === 1;
    },
    async list(query) {
      return (await run(buildList(query))).rows.map(toRow);
    },
    async find(id) {
      const r = (await run(buildFind(id, false))).rows[0];
      return r ? toRow(r) : null;
    },
    async lock(id) {
      const r = (await run(buildFind(id, true))).rows[0];
      return r ? toRow(r) : null;
    },
    async hasVerifiedReward(carId, ownerId) {
      const s = buildHasVerifiedReward(carId, ownerId);
      return (await q.query(s.text, s.values)).rows.length > 0;
    },
    async transition(input) {
      const r = (await run(buildTransition(input))).rows[0];
      if (!r) return null;
      // The transition's RETURNING has no join: re-read the joined row (the same transaction sees its own write).
      const full = (await run(buildFind(String(r.id), false))).rows[0];
      return full ? toRow(full) : null;
    },
  };
}
export function createPgModerationStore(db: Db): ModerationStore {
  return {
    cars: createPgModerationRepository(db),
    transaction: (fn) => db.tx((t) => fn({ cars: createPgModerationRepository(t), audit: createPgAuditRepository(t) })),
  };
}

// ---------------------------------------------------------------- service

/** users.role vocabulary for the audit table. */
const auditRole = (a: Actor): string => (a.role === 'member' ? 'user' : a.role);

export function toAdminMemberCar(r: ModeratedRow): AdminMemberCar {
  return { ...toOwnMemberCar(r), ownerId: r.ownerId, ownerName: r.ownerName, reviewedAt: r.reviewedAt ? r.reviewedAt.toISOString() : null };
}

export function createModerationService(deps: { store: ModerationStore }): ModerationApi {
  const { store } = deps;
  /** Non-administrators learn nothing (not even whether an id exists): 404 before any read. */
  const asAdmin = (actor: Actor | null): Actor => {
    if (!actor || actor.role !== 'admin') throw notFound();
    return actor;
  };
  const resourceOf = (row: ModeratedRow) => memberCarResource({ ownerId: row.ownerId, status: row.status, ownerActive: row.ownerActive, deleted: false });

  return {
    async list(actor, query) {
      asAdmin(actor);
      const q = parsed(parseAdminListQuery(query));
      const rows = await store.cars.list(q);
      const last = rows.length === q.limit ? rows[rows.length - 1] : undefined;
      return { items: rows.map(toAdminMemberCar), nextAfter: last ? last.id : null };
    },

    async get(actor, rawId) {
      const admin = asAdmin(actor);
      const id = parseCarId(rawId);
      if (id === null) throw notFound();
      const row = await store.cars.find(id);
      if (!row) throw notFound();
      authorize(admin, 'read', resourceOf(row));
      return toAdminMemberCar(row);
    },

    async act(actor, action, rawId, body, ctx = {}) {
      const admin = asAdmin(actor);
      const id = parseCarId(rawId);
      if (id === null || !Object.hasOwn(TRANSITIONS, action)) throw notFound();
      const input = parsed(parseActionInput(action, body));
      const t = TRANSITIONS[action];
      return store.transaction(async ({ cars, audit }) => {
        if (!(await cars.lockActingUser(admin.id))) throw notFound();
        const row = await cars.lock(id);
        if (!row) throw notFound();
        authorize(admin, 'moderate', resourceOf(row));
        if (row.version !== input.version) throw new ModerationError('version_conflict');
        if (row.status !== t.from) throw new ModerationError('invalid_state');
        // Publishing needs a rewarded ad verified by the SERVER. Nothing in the request can stand in for it.
        if (action === 'approve' && !(await cars.hasVerifiedReward(row.id, row.ownerId))) throw new ModerationError('reward_required');
        const updated = await cars.transition({ id, expectedVersion: input.version, action, reason: input.reason, reviewerId: admin.id });
        // Under the row lock this cannot happen; if it ever does, nothing was written and the administrator must reload.
        if (!updated) throw new ModerationError('version_conflict');
        await audit.record({ action: `member_car.admin_${action}`, actorUserId: admin.id, actorRole: auditRole(admin), entityType: 'car', entityId: id, afterData: { version: updated.version }, requestId: ctx.requestId });
        return toAdminMemberCar(updated);
      });
    },
  };
}

# Backend — أساس المرحلة 11.4.1

**الحالة بصراحة:** هذا الأساس **غير متصل بالواجهة** ولا يضيف أي ميزة للمستخدم. يحوي فقط: إعدادات البيئة، طبقة اتصال آمنة بـPostgreSQL 16، فحص الدور والمخطط عند الإقلاع، ونقطتَي صحة (`/healthz` و`/readyz`). الواجهة (التطبيق الحالي) ما زالت تعمل على `localStorage` كما كانت، ولم يُعدَّل فيها ملف.

## البنية
```
backend/
├── src/
│   ├── config.ts          إعدادات البيئة: تحقق كامل، لا كلمة مرور في الأخطاء أو السجلات
│   ├── errors.ts          تصنيف أخطاء المشغّل (SQLSTATE/شبكة) إلى DbError آمن (بلا SQL ولا قيم)
│   ├── http-errors.ts     تحويل الأخطاء إلى ردود HTTP عامة (409/422/403/503/500)
│   ├── role.ts            فحص أن الاتصال بدور أدنى امتيازًا (ليس superuser، عضو في najaf_app)
│   ├── schema-contract.ts العقد مع المخطط المُختبَر: 16 جدولًا + viewان (يُقارَن آليًا بالترحيلات)
│   ├── db.ts              Pool + query + tx (BEGIN/COMMIT/ROLLBACK مضمونة) + ping/verifyRole/checkSchema
│   ├── health.ts          liveness بلا قاعدة، readiness (اتصال + عقد المخطط) بلا تفاصيل للعميل
│   ├── server.ts          Fastify رفيع: /healthz و/readyz و404/خطأ عامّان، request-id، no-store
│   ├── index.ts           نقطة الدخول: config → db → سياسة الدور → خادم → إيقاف نظيف
│   └── types.ts           واجهة Logger (متوافقة مع pino)
├── scripts/db-check.ts    أداة تشغيل: تفحص الاتصال والدور والمخطط وتطبع JSON بلا أسرار
├── ops/create_app_login.sql  ينشئ دور الدخول الأدنى امتيازًا (كلمة المرور تُمرَّر -v ولا تُكتب في الملف)
├── test/unit/             اختبارات بلا قاعدة بيانات (تعمل في أي بيئة)
├── test/integration/      اختبارات على PostgreSQL حقيقي (تُتخطّى بوضوح بلا DATABASE_URL)
└── .env.example           كل متغيرات البيئة موثَّقة (اختبار آلي يمنع اختلافها عن الكود)
```
**القاعدة الحاكمة:** كل المنطق في وحدات **بلا اعتماديات** (تُختبر محليًا بالكامل)؛ و`pg` وFastify لا يظهران إلا في `db.ts` (استيراد كسول عبر factory) و`server.ts`.

## نموذج الأمان (ما اعتُمد)
- **لا اتصال بمشرف.** يتصل الـBackend بدور دخول (`najaf_app_login`) **عضو** في `najaf_app` (من الترحيل 0012) فيرث الامتيازات المُختبَرة فقط: بلا DDL ولا TRUNCATE، بلا DELETE على `users` و`showrooms` و`audit_logs` و`exchange_rates`، بلا تعديل `users.role`، وبعد 0013 بلا تعديل أعمدة الملكية والأوقات و`version`.
- **سياسة تُفرض عند الإقلاع** (`DB_REQUIRE_APP_ROLE=true`، ولا يُسمح بتعطيلها في الإنتاج): ترفض العملية الدور إن كان superuser أو يستطيع إنشاء أدوار/قواعد أو له replication/bypassrls أو ليس عضوًا في `najaf_app`، وترفض كذلك اسم المستخدم `postgres` في الإعداد. رمز الخروج 78.
- **TLS:** الافتراضي `verify-full` في الإنتاج، و`disable` مرفوض فيه؛ أنماط libpq التي تُضعف الأمان بصمت (`prefer`/`allow`/`verify-ca`) مرفوضة.
- **استعلامات مُعلَّمة فقط** (القيم لا تُدمج في SQL أبدًا)، و`checkSchema` يمرّر أسماء الكائنات معلَّمة كذلك.
- **مهلات من أول جملة:** `statement_timeout` و`lock_timeout` و`idle_in_transaction_session_timeout` كمعاملات بدء الاتصال (يتحقق منها اختبار التكامل بقراءة `current_setting`).
- **أخطاء بلا تسريب:** `DbError` يحمل النوع والـSQLSTATE واسم القيد فقط؛ رسالة المشغّل الأصلية للسجل الداخلي وحده؛ ردود HTTP عامة (لا SQL ولا أسماء قيود ولا تتبّع مكدّس).
- **المعاملات:** الاتصال يُحرَّر مرة واحدة دائمًا؛ فشل `ROLLBACK` يُتلف الاتصال بدل إعادة استعماله؛ استعلام المعاملة بعد انتهائها مرفوض.
- **readiness** لا يكشف شيئًا للعميل سوى حالات خشنة (`ok/fail/skipped`)؛ التفاصيل في السجل.

## البيئة (`.env.example`)
`DATABASE_URL` (أو `PGHOST`/`PGPORT`/`PGDATABASE`/`PGUSER`/`PGPASSWORD`)، `DB_SSL` و`DB_SSL_CA`، `DB_POOL_MAX` (10)، `DB_STATEMENT_TIMEOUT_MS` (15000)، `DB_LOCK_TIMEOUT_MS` (5000)، `DB_IDLE_IN_TX_TIMEOUT_MS` (15000)، `DB_CONNECT_TIMEOUT_MS` (5000)، `DB_IDLE_TIMEOUT_MS` (30000)، `DB_APPLICATION_NAME`، `DB_REQUIRE_APP_ROLE`، و`NODE_ENV` و`HOST` و`PORT` و`LOG_LEVEL`. القيم الخاطئة تُجمَع في خطأ واحد واضح، ولا يظهر فيه كلمة المرور أبدًا. لا ملف `.env` في المستودع (`.gitignore`).

## التشغيل
```bash
# 1) قاعدة PostgreSQL 16 بالترحيلات المُختبَرة
for f in ../database/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -1 -d najaf -f "$f"; done
# 2) دور الاتصال (مرة واحدة)
psql -v ON_ERROR_STOP=1 -d najaf -v login=najaf_app_login -v pw="$NAJAF_APP_PASSWORD" -f ops/create_app_login.sql
# 3) الاعتماديات والإعداد
npm install && cp .env.example .env     # عدّل DATABASE_URL
npm run db:check                         # يفحص الاتصال والدور والمخطط
npm run dev                              # خادم Node ≥ 22.18 يشغّل TypeScript مباشرة (بلا خطوة بناء)
```
`GET /healthz` ← `{"status":"ok"}`؛ `GET /readyz` ← 200 `{"status":"ready",...}` أو 503 `not_ready`.

## الاختبارات
| الأمر | ماذا يشغّل | يحتاج |
| --- | --- | --- |
| `npm test` | **117 اختبار وحدة** تعمل بلا أي اعتمادية: الإعدادات (27)، تصنيف الأخطاء وردود HTTP (44)، طبقة الاتصال بـpool مزيّف: خيارات `pg`، معاملات، تنظيف الاتصال، أخطاء (22)، سياسة الدور (8)، الصحة (7)، العقد مع الترحيلات (5)، توافق `.env.example` (4). ثم **7 اختبارات خادم HTTP** (Fastify `inject`) | Node ≥ 22.18. اختبارات الخادم تحتاج `npm install` وإلا تُتخطّى بوضوح كمجموعة |
| `npm run test:integration` | **58 اختبار تكامل** على PostgreSQL حقيقي: اتصال ودور ومهلات فعلية وكلمة مرور خاطئة وخادم غير متاح وحدّ الـpool وcommit/rollback وعدم تسريب الاتصالات (17)، **امتيازات الدور** (23 عملية ممنوعة و12 مسموحة + إضافة التدقيق + منع إنشاء مدير + 3 معارض/115 سيارة) (38)، وردود الصحة عبر HTTP (3) | `DATABASE_URL` (دور التطبيق) و`ADMIN_DATABASE_URL` (superuser للتجهيز فقط) |
| `npm run typecheck` | `tsc --noEmit` صارم (`erasableSyntaxOnly`) | `npm install` |

CI: `.github/workflows/backend.yml` (تشغيل يدوي) يطبّق الترحيلات المُختبَرة ويشغّل الثلاثة معًا + انحدار الواجهة (33 ملفًا) على PostgreSQL 16.

## التراجع (المرحلة قابلة للإزالة بالكامل)
هذه المرحلة **إضافية بحتة**: احذف `backend/` و`.github/workflows/backend.yml` وفقرة 11.4.1 من `README.md` الجذر، فيعود المشروع كما كان في 11p3 بلا أي أثر. لا ملف في الواجهة أو الخدمات أو المستودعات أو `database/` تغيّر.

## قرارات معمارية معلَّقة (لم تُنفَّذ عمدًا؛ تحتاج موافقتك قبل 11.4.2)
1. **TypeScript بلا بناء:** يُنفَّذ مباشرة بـNode ≥ 22.18 (type stripping) وتُفحَص أنواعه بـ`tsc` في CI. بديله: خطوة بناء (esbuild/tsc) — أُبقي المشروع بلا بناء اتساقًا مع قاعدته.
2. **Drizzle ORM** (المذكور في وثيقة 11.1) **مؤجَّل**: المخطط يعتمد مشغّلات وviews وصلاحيات أعمدة ومهاجرات SQL مكتوبة يدويًا واجتازت التحقق؛ فالمقترح SQL مُعلَّم مباشرة بـ`pg`، مع إعادة النظر عند نقل أول مستودع.
3. **Zod** مؤجَّل لحين وجود أول مسار يستقبل مدخلات.
4. **لا مشغّل ترحيلات في الباكند:** الترحيلات SQL تُطبَّق بـ`psql`؛ جدول تتبّع داخل المخطط سيغيّر ما اجتاز التحقق. خيارات 11.4.2: أداة خارجية (dbmate/graphile-migrate) أو مشغّل بمخطط `ops` منفصل.
5. **ملف قفل الحزم غير موجود:** بيئتي لا تثبّت حزم npm؛ يُنشأ `package-lock.json` من أول تشغيل ناجح في CI ويُلتزم به.

## خريطة الخدمات الحالية → وحدات الباكند القادمة (تصميم، غير منفَّذ)
| الواجهة الآن | وحدة الباكند | الجداول |
| --- | --- | --- |
| AuthService/SessionService/UserService | auth | users, sessions, verification_codes, message_deliveries |
| SearchService/VisibilityService/CarFilterService | catalog (قراءة عامة) | views: public_cars, public_showrooms |
| MemberCarsService/ShowroomCarsService/ShowroomService/FavoritesService | owners | cars, showrooms, favorites |
| CarImagesService/ImageService/ImageStore (IndexedDB) | uploads | assets, car_images + تخزين كائنات |
| AdminService | moderation | users, showrooms, cars, audit_logs |
| RewardService | rewards | reward_grants |
| FormatService (TEXT_LIMITS) وسعر الصرف | settings | app_settings, exchange_rates |
| AuthorizationService | سياسة `can(actor, action, resource)` واحدة | — |
| MigrationService (مخطط localStorage) | لا مقابل (تحلّ محلّه ترحيلات SQL) | — |

ربط الواجهة بالباكند (علم `DATA_SOURCE=local|api` ومستودعات بعيدة بالواجهة نفسها) في مرحلة لاحقة؛ الواجهة هنا لم تُلمَس.

## Migration Runner (دمج أداة الترحيلات)

أُدمجت **node-pg-migrate 9.0.0** (نسخة مثبَّتة بلا `^`) بعد أن نجح تقييمها المنفصل على PostgreSQL 16 (29 نجاحًا، 0 فشل، 3 معلومات). **لم يُعدَّل أي ملف في `database/migrations` (0001–0013)، ولم يتغير مخطط PostgreSQL.**

- **المصدر الوحيد للـSQL:** `database/migrations` (مجمَّد وبصماته في `database/CHECKSUMS.sha256`). الأداة لا تكتب فيه.
- **التغليف:** `db/migrations/NNNN_name.js` (13 ملف CommonJS) يقرأ ملف SQL الأصلي حرفيًا. و**`db/down/NNNN_name.down.sql`** (13) هي ملفات التراجع. التفاصيل في `db/README.md`.
- **التتبع:** `ops.pgmigrations` (لا شيء في `public`).
- **حساب منفصل:** `MIGRATION_DATABASE_URL` يشير إلى `najaf_migrator` (مالك قاعدة البيانات، `CREATEROLE`، ليس superuser، ولا يرث صلاحيات `najaf_app` ولا يستطيع `SET ROLE` إليه). يُنشأ بـ`ops/create_migration_role.sql`. الإعداد يرفض `najaf_app` و`najaf_app_login` و`najaf_report`، ويرفض الحساب نفسه المستعمل في `DATABASE_URL`، وفحص الدور قبل أي تشغيل يرفض أي حساب **يرث صلاحيات `najaf_app` أو يستطيع `SET ROLE` إليه** (هوية تطبيق). أما العضوية الإدارية `ADMIN OPTION` التي يمنحها PostgreSQL 16 تلقائيًا لمنشئ الدور فمقبولة لأنها لا تمنح صلاحياته ولا التحويل إليه.
- **المتغيرات:** `.env.migrations.example` (اختبار آلي يمنع اختلافها عن الكود).

```bash
npm run db:migrate                       # تطبيق كل الترحيلات المعلّقة
npm run db:migrate:status                # applied / pending / unknown
npm run db:rollback -- --steps 1         # تراجع آخر ترحيلة (لا عدد افتراضيًا)
npm run db:rollback -- --all             # تراجع كل شيء (تُحذف الجداول؛ الأدوار تبقى)
```
قواعد أمان: `down` بلا `--steps`/`--all` مرفوض؛ وفي الإنتاج مرفوض ما لم يُضبط `MIGRATION_ALLOW_ROLLBACK=true`؛ ولا تظهر كلمة المرور في أي مخرج.

**الاختبارات:** 60 اختبار وحدة (إعدادات الـRunner، الـRunner بـ`runner` مزيّف، فحص الدور، الحالة، وأصول الترحيل) + 9 اختبارات تكامل على PostgreSQL حقيقي (`test/integration/migrate.integration.test.ts`، تحتاج قاعدة **فارغة** واسمها فيه test أو mig أو ci لأنها تتراجع عن كل شيء) + `.github/workflows/migrations.yml` (تشغيل يدوي): يطبّق ويتراجع ويقارن `pg_dump` بمرجع `psql -1`.

**التراجع عن هذه الخطوة بالكامل** (إضافية بحتة، لا شيء قديم حُذف أو استُبدل): احذف `backend/src/migrate/` و`backend/scripts/migrate.ts` و`backend/db/` و`backend/ops/create_migration_role.sql` و`backend/.env.migrations.example` و`backend/test/**/migrate*` و`.github/workflows/migrations.yml` وهذا القسم، وأزل من `backend/package.json` ثلاثة أوامر `db:migrate*`/`db:rollback` وسطر `"node-pg-migrate": "9.0.0"`.

## المصادقة والحسابات (Phase 11.4): الخطوات 1 إلى 4

تسجيل مستخدم، والتحقق من بيانات الدخول، **رمز وصول 15 دقيقة**، **رمز تحديث دوّار مع كشف إعادة الاستعمال**، وحدّ معدّل، و**تحقق الهاتف واسترداد كلمة المرور برمز لمرة واحدة**. **لا ربط بالواجهة بعد**، ولا تسليم فعلي للرموز (انظر أدناه)، ولا تفويض (11.5). **لم يتغير مخطط PostgreSQL ولا أي ترحيلة** (يكفي `sessions` و`verification_codes`: الغرض والمستخدم والهاتف والتجزئة والمحاولات والانتهاء والاستهلاك والفهرس الفريد «رمز نشط واحد»).

| المسار | الطلب | النجاح | الفشل |
| --- | --- | --- | --- |
| `POST /v1/auth/register` | `{name, phone, password}` | 201 `{user, session}` | 400 تحقق، 409 تعذّر التسجيل، 429 |
| `POST /v1/auth/login` | `{phone, password}` | 200 `{user, session}` | 400، 401 `invalid_credentials`، 429 |
| `POST /v1/auth/refresh` | `{refreshToken}` | 200 `{user, session}` (جديدان كلاهما) | 400، 401 `unauthorized`، 429 |
| `GET /v1/auth/me` | `Authorization: Bearer <accessToken>` | 200 `{user}` | 401 `unauthorized` |
| `POST /v1/auth/logout` | `{refreshToken}` | 204 | 400، 429 |
| `POST /v1/auth/phone/verify/request` | `Bearer` (بلا جسم) | 202 `{status:'sent'}` أو 200 `{status:'already_verified'}` | 401، 429 |
| `POST /v1/auth/phone/verify/confirm` | `Bearer` + `{code}` | 200 `{user}` | 400 `invalid_code`، 401، 429 |
| `POST /v1/auth/password/forgot` | `{phone}` | 202 `{status:'accepted'}` **دائمًا** | 400 (مدخل معطوب)، 429 |
| `POST /v1/auth/password/reset` | `{phone, code, newPassword}` | 200 `{status:'password_reset'}` | 400 `invalid_code` أو تحقق، 429 |
| `POST /v1/auth/password/change` | `Bearer` + `{currentPassword, newPassword}` | 200 `{status:'password_changed'}` | 400 `invalid_current_password` أو تحقق، 401، 429 |
| `POST /v1/auth/logout/all` | `Bearer` (بلا جسم) | 204 | 401، 429 |

`session = {accessToken, accessExpiresAt, refreshToken, refreshExpiresAt}`، ويُعرض كل رمز **مرة واحدة**. المستخدم العام `{id, name, phone, role, status, createdAt}` يُبنى حقلًا حقلًا (لا كلمة مرور ولا تجزئة)، و`phone` بصيغة E.164.

**الرمزان**
- **رمز الوصول:** HS256 (على `node:crypto`، بلا تبعية)، 15 دقيقة، يحمل `sub` و`sid` فقط. **الدور والحالة لا تُقرأ منه أبدًا**: تُعاد قراءة الجلسة والمستخدم من القاعدة عند كل طلب، فيموت الرمز **فورًا** عند الخروج أو الإيقاف أو كشف إعادة الاستعمال أو تغيير كلمة المرور (مشغّلات القاعدة)، لا بعد 15 دقيقة. التحقق صارم: ترويسة ثابتة، توقيع بزمن ثابت، مطالبات محددة بالضبط، عمر لا يتجاوز السياسة.
- **رمز التحديث:** عشوائي 256 بت (`nsj_…`)، **SHA-256 فقط** في `sessions.token_hash`، **30 يومًا مطلقة** من الدخول (التدوير لا يمدّها). لا يُقبل رمز تحديث كرمز وصول، ولا العكس.
- **التدوير:** كل `/refresh` يُصدر زوجًا جديدًا في المعاملة نفسها (قفل الصف `FOR UPDATE`): يُلغى الصف القديم بسبب `rotated` مع `replaced_by`، ويُدرج جديد بنفس `family_id` ونفس الانتهاء.
- **كشف إعادة الاستعمال:** عرض رمز دُوِّر سابقًا يُلغي **كل** جلسة الدخول (`reuse_detected`) ويُثبَّت الإلغاء، ولا يُصدر شيئًا. وهو **صارم عمدًا**: طلبان متزامنان بالرمز نفسه يُنهيان الجلسة (فعلى العميل ألا يجدّد بالتوازي). الجلسات الأخرى للمستخدم لا تتأثر.
- **الخروج:** بـ`refreshToken` (يعمل ولو انتهى رمز الوصول)، ويُنهي جلسة الدخول كلها. وهو متساوي الأثر بأي رمز من السلسلة، ولا يُعدّ إعادة استعمال.
- **كل إخفاق تجديد** (مجهول، منتهٍ، مُلغى، مُعاد استعماله، حساب موقوف أو محذوف) هو **الخطأ نفسه** `unauthorized`.

**الإعداد** (وحدة منفصلة `src/auth/config.ts`، ومثال `.env.auth.example`)
- `AUTH_ACCESS_TOKEN_SECRET` **مطلوب** (32 حرفًا فأكثر، عشوائي: `openssl rand -base64 48`)، ويُرفض الفارغ والقصير وقليل التنوع والنماذج (`change-me`…). لا يُسجَّل ولا يُكرَّر في أي خطأ. **بدونه لا يبدأ الخادم** (`npm start` يخرج برمز 78).
- `AUTH_TRUSTED_PROXIES` اختياري: عناوين/CIDR للوكلاء الذين يُوثَق بـ`X-Forwarded-For` منهم (Cloudflare/موازن الحمل). الافتراضي **لا أحد**، و«الثقة بالجميع» (`/0` و`*` و`true`) **مرفوضة**. بدونه خلف وكيل تظهر كل الطلبات من عنوان الوكيل.
- تدوير السر يُبطل رموز الوصول فقط (رموز التحديث تعمل وتُصدر رموز وصول جديدة).

**حدّ المعدّل** (`src/auth/rate-limit.ts`): لكل عنوان عميل ولكل مسار، نوافذ ثابتة **في ذاكرة العملية** (بلا جدول ولا ترحيلة): `register` 5/ساعة، `login` 10/5 دقائق، `refresh` 60/10 دقائق، `logout` 30/5 دقائق. يُجاب 429 مع `Retry-After` **قبل قراءة الجسم**. الذاكرة محدودة (50 ألف مفتاح). **القيود:** الحدّ لكل نسخة تشغيل (عند عدة نسخ يتضاعف السقف)، ويضاف إلى قفل الحساب (5 إخفاقات/15 دقيقة) لا يحلّ محله.

**سائر الضمانات (الخطوة 1):**
- argon2id (`m=19456,t=2,p=1`)، ولا كلمة مرور تُسجَّل أو تُرجَع.
- فشل الدخول بكل أسبابه خطأ واحد، وتحقق argon2 واحد في كل مسار (لا فرق توقيت).
- الدور والحالة ليسا مدخلين (حقل `role` يُرفض).
- `register` و`login` و`refresh` و`logout` تقبل `application/json` فقط (415 قبل قراءة الجسم)، وحدّ الجسم 4 KiB.
- استعلامات SQL مُعلَّمة فقط، والوقت من ساعة القاعدة (انتهاء الجلسة) وساعة التطبيق (انتهاء رمز الوصول).

**الرموز لمرة واحدة (الخطوة 3)**
- **التوليد والتخزين:** رمز من 6 أرقام بـCSPRNG (`crypto.randomInt`)، ولا يُخزَّن إلا **HMAC-SHA256** بمفتاح مشتق من سر الخادم (التجزئة العادية عديمة الفائدة: 10^6 احتمال فقط)، **مرتبط بالغرض والمستخدم والهاتف** (لا يصلح رمز لغرض أو مستخدم أو رقم آخر). لا يُسجَّل ولا يُرجَع ولا يظهر في خطأ.
- **القيود:** صلاحية 10 دقائق، 5 محاولات للرمز (بعدها يُرفض حتى الصحيح)، مهلة 60 ثانية بين رمزين، 3 في الساعة و10 في اليوم لكل (مستخدم، غرض). رمز نشط واحد لكل (مستخدم، غرض): الجديد يُبطل القديم. تساوي القيم `app_settings` المبذورة `otp.policy` (ملاحظتها: «مقترح، يحتاج موافقة»)، والشيفرة **لا تقرؤها بعد**.
- **الاستعمال مرة واحدة:** يُستهلك الرمز في المعاملة نفسها التي تنفّذ أثره، تحت قفل الصف. محاولة فاشلة **تُثبَّت** (تُعاد النتيجة من المعاملة لا تُرمى منها). الطلبات المتزامنة: قفل استشاري لكل (مستخدم، غرض) يمنع تجاوز حدود الإرسال بالتزامن.
- **خطأ واحد** `invalid_code` لكل فشل: خاطئ، منتهٍ، مستعمل، مستنفد، غرض آخر، مستخدم آخر، حساب مجهول.
- **تحقق الهاتف:** التسجيل **لا** يوثّق الهاتف. الطلب يخص هاتف صاحب الرمز فقط (المعرّف من رمز الوصول لا من الطلب). عند النجاح يُضبط `phone_verified_at` ويُستهلك الرمز معًا. المستخدم الموثَّق: الطلب لا يرسل شيئًا، والتأكيد نجاح بلا أثر ولا يستبدل وقت التوثيق. `phoneVerified` ظاهر في `user` (register/login/refresh/me).
- **الاسترداد:** `forgot` يجيب **بالجواب نفسه** لحساب موجود أو غير موجود أو موقوف أو مخنوق. `reset` يتحقق من سياسة كلمة المرور **قبل** النظر في الرمز (كلمة ضعيفة لا تحرق محاولة)، ويجزّئ كلمة المرور **بعد** التحقق من الرمز (فلا يُستنزف المعالج بتخمينات)، ثم في معاملة واحدة: كلمة مرور جديدة بـargon2id، وفك قفل الدخول، و**إبطال كل جلسات المستخدم فورًا** (رموز الوصول والتحديث). الاستعمال الثاني للرمز مرفوض (لا إعادة تشغيل).
- **التسليم:** عبر واجهة `MessagingProvider` (`src/messaging/provider.ts`) **بعد الالتزام وبلا انتظار** (فلا يتأثر زمن الاستجابة بالمزوّد)، وفشله يُسجَّل بلا أي سر ولا يغيّر الجواب. **لا مزوّد SMS/WhatsApp مدمج بعد**: `npm start` يركّب مزوّدًا يرفض كل إرسال ويسجّل تحذيرًا عند الإقلاع، فالتدفقات تعمل من طرف إلى طرف لكن **لا شيء يصل إلى الهاتف**. لا مفتاح بيئة جديد (مفتاح التجزئة مشتق من `AUTH_ACCESS_TOKEN_SECRET`، وتدويره يُبطل الرموز المعلّقة فقط، 10 دقائق).
- **مخاطر معروفة:** تسجيل رقم غيرك قبله (بلا OTP عند التسجيل) ما زال ممكنًا، لكن صاحب الرقم يستردّ الحساب بـ`forgot`؛ وزمن استجابة `forgot` قد يختلف ميلي ثوانٍ بين الموجود والمجهول (إدراج واحد، والإرسال غير منتظَر، والحد لكل عنوان يقيّد الاستكشاف). تخمين رمز: أقصى 15 محاولة/ساعة من 10^6.

**أمان الحساب والجلسات (الخطوة 4)** — يحتاج المساران `Bearer <accessToken>`، **والمعرّف دائمًا من الرمز المُتحقَّق منه** (المدخلات تُرفض إن حملت `userId`، ولا يُقرأ معرّف من الجسم أو المعاملات أو الاستعلام).
- **تغيير كلمة المرور:** يتطلب الحالية؛ وكلمة المرور الجديدة بالسياسة نفسها (تُفحص **قبل** أي شيء، فلا تكلّف محاولة)؛ ولا يجوز أن تساوي الحالية (`same_as_current`، ولا تُذكر إلا لمن أثبت الحالية). المحاولات الخاطئة **تُحسب كالدخول الفاشل** (القفل نفسه: 5 ثم 15 دقيقة، وأثناء القفل لا تُفحص الحالية أصلًا)، فلا يخمّن رمز وصول مسروق كلمة المرور. التبديل **بشرط المقارنة** على التجزئة القديمة، فمن تغييرين متزامنين يُطبَّق واحد.
- **الجلسات عند تغيير كلمة المرور (قرار موثَّق):** تنتهي **كل** الجلسات **بما فيها الحالية**، فيدخل المستخدم من جديد بكلمته الجديدة. السبب: هذا نموذج المشروع القائم أصلًا (مشغّل `users_revoke_sessions` يلغي كل الجلسات عند تغيّر `password_hash`، والاسترداد كذلك)، ولا نصدر رموزًا داخل عملية تغيير كلمة المرور، ومن يحمل أي جلسة (ولو مسروقة) يفقدها. الثمن تسجيل دخول واحد على هذا الجهاز.
- **الخروج من كل الأجهزة:** يُنهي كل جلسة دخول للمستخدم (وصول وتحديث)، ولا ينشئ جلسة ولا يمدّد انتهاءً. **آمن مع تجديد جارٍ:** `revokeAllLive` يقفل أولًا كل الصفوف الحيّة بـ`SELECT … FOR UPDATE` (ينتظر أي تجديد جارٍ ليلتزم)، ثم `UPDATE` بلقطة جديدة ترى الصف الذي أدرجه ذلك التجديد. عبارة `UPDATE` واحدة كانت تفوّته فتبقى جلسة حيّة. وتجديد يبدأ بعدها يجد صفّه ملغى فيُرفض (ولا يُعدّ إعادة استعمال).
- **التدقيق (`audit_logs`):** حدثان فقط، بعرف الجدول نفسه `<نطاق>.<حدث>`: `auth.password_changed` و`auth.logout_all`، لكل منهما الفاعل ودوره والكيان `user` ومعرّفه و`request_id` وعدد الجلسات المُنهاة (`after_data = {"sessions_revoked": n}`). **أرقام فقط**: حارس في المستودع يرفض أي مفتاح يشبه سرًّا (`pass|hash|token|secret|code|otp|phone|key|cred`) أو قيمة غير رقمية. الحدث والفعل **معاملة واحدة** (لا فعل بلا حدث ولا حدث بلا فعل). الجدول إلحاق فقط بمشغّلات (حتى للمستخدم الأعلى) ودور التطبيق `SELECT, INSERT` فقط، والشيفرة كلها لا تحوي `UPDATE`/`DELETE`/`TRUNCATE` عليه (حارس ساكن في الاختبارات). **لا يُسجَّل** المحاولات الخاطئة ولا الرفض (مسجّلة في السجل التشغيلي بلا أسرار).
- **الحسابات الموقوفة/المحذوفة:** 401 على المسارين كأي رمز ميّت.

**تقوية ما قبل المرحلة 11.5 (الخطوة 5.0)** — ثلاثة إصلاحات فقط، بلا ترحيلة ولا تغيير في سياسات الرموز أو OTP أو كلمات المرور:
- **سباق الدخول مقابل تغيير كلمة المرور:** كان الدخول يتحقق من كلمة المرور خارج المعاملة ثم يُنشئ الجلسة دون إعادة التحقق، فدخول بدأ قبل التغيير قد ينتج جلسة حيّة بعده. الآن **أول** عبارة في معاملة الدخول تحديث مشروط (`recordSuccessfulLoginIf`): `WHERE id=$1 AND password_hash=$2 AND status='active' AND deleted_at IS NULL`، ولا تُدرج الجلسة إلا إن نجح. السلامة من **قفل صف المستخدم في PostgreSQL** لا من التوقيت: التغيير السابق يجعل المقارنة تفشل، والدخول السابق يمسك القفل فينتظر التغيير ثم يمسح المشغّل `users_revoke_sessions` الجلسة. الفشل `invalid_credentials` العام نفسه (لا يكشف تغيّر كلمة المرور) ولا يُحسب محاولة خاطئة. ويشمل الإيقاف والحذف بين التحقق وإنشاء الجلسة.
- **تدقيق الاسترداد:** نجاح الاسترداد يكتب حدثًا واحدًا `auth.password_reset` (الفاعل ودوره والكيان ومعرّف الطلب وعدد الجلسات المُنهاة، أرقام فقط) في **معاملة الاسترداد نفسها**: يتراجع معها. لا حدث لطلب الرمز ولا للتوثيق ولا للرفض.
- **توحيد إلغاء الجلسات:** آلية واحدة للإلغاء الآمن مع تجديد جارٍ (قفل صفوف الجلسات الحيّة بـ`SELECT … FOR UPDATE` فينتظر أي تجديد جارٍ، ثم `UPDATE` بلقطة جديدة ترى ما التزم)، في دالة مساعدة واحدة `revokeLive` لها نطاقان: `revokeAllLive` (كل جلسات المستخدم: تغيير كلمة المرور والخروج الشامل والاسترداد) و`revokeFamilyLive` (جلسة دخول واحدة: **الخروج**). كان الخروج `UPDATE` واحدًا تلقائي الالتزام، فتجديد جارٍ لجلسته نفسها كان يترك جلسة حيّة بعده؛ صار يعمل داخل معاملة (`store.transaction`) ويمس عائلة الجلسة وحدها بالسبب `logout`. أما `revokeAllForUser` و`revokeFamilyByTokenHash` (عبارة `UPDATE` واحدة) فبقيتا **كما هما حرفيًا** لأن اختباراتهما قائمة، لكن **لا شيء في الإنتاج يستدعيهما** (حارس ساكن يفرض ذلك). كشف إعادة الاستعمال في `rotate` لم يتغير (يعمل أصلًا تحت قفل صف داخل معاملة). وفي الاسترداد: تُجزَّأ كلمة المرور بعد التحقق من الرمز وقبل أي قفل على الجلسات، ثم `revokeAllLive`، ثم تغيير كلمة المرور، ثم حدث التدقيق.

**ما لم يُنفَّذ بعد:** مزوّد التسليم الفعلي (SMS/WhatsApp) وجدول `message_deliveries`، وتنظيف رموز `verification_codes` القديمة (وفهرس `(user_id, purpose, created_at)` إن كبر الجدول)، والمدير الأول، وتسجيل التجار والبريد، وأحداث تدقيق أخرى (الدخول الفاشل، والتوثيق)، وعرض الجلسات وإلغاء واحدة بعينها، وCORS وكوكي رمز التحديث (يُحسمان مع 11.7)، و`ip_hash` (يحتاج سرًّا)، وذاكرة مؤقتة ≤ 30 ثانية لقراءة المستخدم (حاليًا قراءة عند كل طلب: أدق وأبطأ).

**قرارات تنتظر موافقتك (غير واردة في الخطة):** أرقام القفل وحدّ المعدّل، والحد الأدنى لكلمة المرور 6 (يُنصح بـ8)، وكشف إعادة الاستعمال الصارم بلا مهلة سماح، وأرقام الرموز (6 أرقام، 10 دقائق، 5 محاولات، 60 ثانية، 3/ساعة، 10/يوم: «مقترح» في `otp.policy` نفسها)، وحدود المعدّل الأربعة للمسارات الجديدة، وأن إعادة التعيين لا توثّق الهاتف، وأن تغيير كلمة المرور يُنهي الجلسة الحالية أيضًا، وحدّي المسارين الجديدين (تغيير كلمة المرور 5/10 دقائق، والخروج الشامل 10/10 دقائق).
**التبعيات:** لا جديدة في هذه الخطوة (`argon2` من الخطوة 1 فقط).
**الاختبارات:** وحدات `test/unit/auth-*.test.ts` (رمز الوصول، الخدمة، التجديد، المستودعات، حدّ المعدّل، الإعداد، التحقق، HTTP، **الرموز لمرة واحدة**: الأساسيات والخدمة والمستودع والتحقق)، وتكامل `test/integration/auth*.integration.test.ts` على PostgreSQL حقيقي مع argon2id حقيقي (`auth-otp.integration.test.ts` للرموز).

### نقل رمز التجديد بملف ارتباط HttpOnly (المرحلة 11.7.2.2)
**الغرض:** بقاء متصفح المستخدم مسجّلًا بعد إعادة تحميل الصفحة **دون** أي رمز في `localStorage`/`sessionStorage` ودون أن يراه JavaScript. اختياري ومعطّل افتراضيًا؛ بدونه كل شيء كما كان (الرمز في جسم JSON).

**التفعيل:** `AUTH_COOKIE_ORIGINS=https://najaf.example.com` (أصول مطابقة تمامًا، بلا شرطة أخيرة أو مسار أو `*` أو `null`) ويُوثَّق في `.env.auth.example`. `AUTH_COOKIE_SECURE=false` مسموح فقط خارج الإنتاج ولأصول `http://localhost`. أي قيمة غير صالحة توقف الإقلاع (الرمز 78). **يجب أن تُخدَم الصفحة من أصل الـAPI نفسه** (وكيل عكسي واحد): لا CORS هنا، ولم يُضف.

**العقد (بالترويسة `X-Session-Transport: cookie` على الطلب):**
| الطلب | السلوك |
| --- | --- |
| `POST /v1/auth/login` | كما كان، لكن الرد `{user, session:{accessToken, accessExpiresAt, refreshExpiresAt}}` **بلا `refreshToken`**، و`Set-Cookie` برمز التجديد |
| `POST /v1/auth/refresh` (بلا جسم) | الرمز من الملف **فقط** (أي رمز في الجسم يُهمَل)، يُدوَّر، ويُضبط الملف الجديد. رفض التجديد (مجهول/منتهٍ/مُلغى/مُعاد استعماله) يحذف الملف. عطل الخادم لا يحذفه |
| `POST /v1/auth/logout` (بلا جسم) | يُبطل جلسة الملف (إن وُجد) ويحذف الملف دائمًا. إن فشل الإبطال (قاعدة البيانات) يبقى الملف ليُعاد المحاولة |

**الملف:** `__Secure-najaf_rt` (أو `najaf_rt` في التطوير فقط)، `Path=/v1/auth`، `HttpOnly`، `Secure`، `SameSite=Strict`، بلا `Domain`، و`Max-Age` = المتبقي من العمر **المطلق** (30 يومًا من الدخول؛ التدوير لا يمدّده). القيمة = رمز التجديد الغامض نفسه (يُخزَّن SHA-256 فقط كما كان).

**حماية CSRF (الملف وحده لا يثبت شيئًا لأن المتصفح يرسله مع طلبات صفحات خبيثة):** (1) `SameSite=Strict`؛ (2) ترويسة `Origin` **إلزامية** ومطابقة تمامًا لإحدى الأصول المسموحة، وإلا 403 `forbidden_origin` **قبل** معالجة أي اعتماد؛ (3) `Sec-Fetch-Site` إن وُجد يجب أن يكون `same-origin`/`same-site`؛ (4) الترويسة المخصّصة مطلوبة (لا يستطيع موقع آخر إضافتها دون preflight ولا يوجد CORS)؛ (5) JSON فقط (415 لغيره). الترويسة بلا تفعيل الخادم = 400 `session_transport_unsupported` (لا رمز يُسرَّب في الجسم بصمت). كل رفض يُسجَّل بسببه فقط (`auth.cookie.rejected`) والسجلات تحجب `cookie` و`set-cookie`.

**ما لم يتغيّر:** منطق التدوير وكشف إعادة الاستعمال (إعادة استعمال رمز قديم تُبطل الجلسة كلها — لذلك تُسلسِل الواجهة التجديد بين التبويبات)، حدود المعدّل، قفل الحساب، قاعدة البيانات (**لا ترحيلات**). `POST /v1/auth/register` يدعم الترويسة نفسها منذ 11.7.2.3 (الملف نفسه، الجسم بلا `refreshToken`، وفحص Origin نفسه)؛ بقية المسارات لا تضع الملف.

**استعادة كلمة المرور بلا مزوّد رسائل (11.7.2.3):** `MessagingProvider.configured === false` (المزوّد غير المُفعَّل) → `POST /v1/auth/password/forgot` يردّ **503 `delivery_unavailable`** لكل رقم بالتساوي (بعد التحقق من الصيغة، قبل أي بحث عن حساب، دون توليد رمز)، بدل 202 كاذب. مزوّد حقيقي (أو وهمي بلا الخاصية) يُبقي العقد القديم: 202 دائمًا. لا ترحيلات.

**الاختبارات:** `test/unit/auth-session-cookie.test.ts` (41): الإعداد، خصائص الملف، القراءة الصارمة، فحوص CSRF، ومعالجات المسارات الثلاثة مباشرة (بلا Fastify). **لم يُشغَّل** هنا: اختبار Fastify حقيقي/المتصفح الحقيقي/خادم فعلي بقاعدة بيانات (يتطلب `npm install` وPostgreSQL — يعمل في CI).

## Authorization & policy core (Phase 11.5, Step 5.1)

`src/authz/` is the reusable, I/O-free policy layer that every future business route must go through. It contains no routes.

- **Who** (`actor.ts`): `loadActor(auth, token)` verifies the access token, lets `authenticate` re-read the account from the database, and returns an `Actor {id, role: member|dealer|admin}` only for an ACTIVE, NOT-DELETED account with a known role. Suspended, pending, deleted, unknown-role or malformed-id accounts yield `null` (treated as a guest). Role and status are never in the token and never in the request.
- **What** (`resources.ts`): resources are built from rows the server loaded; factories reject malformed ids so a client string can never become an owner.
- **May they** (`policy.ts`): pure `can(actor, action, resource)`, deny by default. Ownership is by id; a dealer owns a showroom and its cars; a member is never a showroom owner; admin has broad access but cannot rewrite member ads, read favorites, or edit/delete showroom cars (an admin may only read them and change their status, `moderate`; Step 5.7 hardening).
- **Public vs private** (`public.ts`): `isPublic` mirrors the `public_showrooms`/`public_cars` views and grants nothing private.
- **Outcome** (`access.ts`): `authorize` / `authorizeRead` throw `AuthzError`; a private resource the caller cannot read is `404 not_found`, identical to a missing one; `403 forbidden` only when the caller can already read it.

Routes must pass the Actor from `loadActor` and the server-loaded resource; never `ownerId`, `showroomId` or `role` from the request. Out of scope here: business rules such as status transitions, quotas and subscriptions.

## Dealer lifecycle (Phase 11.5, Step 5.2)

- **Application:** `POST /v1/dealers/register` creates a `dealer` account with status `pending` and signs it in. No showroom exists yet.
- **Pending dealers may authenticate** (sign-in, refresh, session lookup, change password, sign out everywhere). One rule, `src/auth/account-state.ts`, mirrored in the SQL of `auth/repository.ts`. They get **no Actor** from `src/authz`, so they have no dealer or admin powers.
- **Phone verification and password recovery still refuse a pending dealer** (fail-closed). `auth/otp-service.ts` was deliberately left unchanged because the OTP files are frozen by the change-control rules. Lifting this needs an explicit approval.
- **Decisions** (admin only, `src/dealers/`): `approve` pending→active (creates or approves the showroom, once), `reject` pending→suspended, `suspend` active→suspended (ends all sessions), `reactivate` suspended→active. Each runs in one transaction with a compare-and-swap, a row lock, and an audit row (`dealer.approve|reject|suspend|reactivate`, numbers only).
- **The schema has no `rejected` account state.** A rejected application is `suspended`, as in the prototype; the audit action records which it was.
- **Routes:** `GET /v1/dealer/showroom` (active dealer, own showroom only), `GET /v1/admin/dealers`, and `POST /v1/admin/dealers/:id/{approve|reject|suspend|reactivate}`. The only input to an admin action is the `:id` target. Unknown fields and any body are refused with 400.
- **Errors:** 404 for anything the caller may not see (including an unknown id), 403 only for one's own account, 409 for an invalid transition.

## Public catalog (Phase 11.5, Step 5.3)

Read-only, **no authentication**: an `Authorization` header, valid or not, is ignored. Code is in `src/catalog/`.

- **Routes:** `GET /v1/public/showrooms`, `GET /v1/public/showrooms/:id`, `GET /v1/public/cars`, `GET /v1/public/cars/:id`. No write method exists.
- **Visibility comes only from the database views.** Every query reads `public_showrooms` or `public_cars` and nothing else (no base table, no `owner_id`, no reviewer or reason columns). A pending, suspended, deleted or otherwise non-public record, a record of a suspended or deleted owner, and a car of a hidden showroom are simply absent. A detail request for any of them is the same `404 not_found` as an unknown id, and a malformed id is that same 404 without touching the database.
- **Filters (whitelist, strict):** `q` (up to 100 characters, 5 terms, all must match; NFKC and case folded; LIKE metacharacters escaped), `source`, `showroomId`, `brand`, `model`, `color`, `transmission`, `fuelType`, `status` (`available|sold|active`), `yearMin/yearMax` (1980..2100), `currency` (`IQD|USD`), `priceMin/priceMax`. A price range requires `currency`: prices are never compared across currencies. Unknown keys, repeated keys, bad enum values, reversed ranges and ids above bigint are `400 validation_failed` with field names and codes only (never the submitted values).
- **Pagination:** keyset on `id DESC` (`before` = the last id received), default 20, maximum 50, no OFFSET. `nextBefore` is returned only after a full page.
- **Rate limit (PROPOSED, per address and per instance):** lists 240 / 10 min, details 480 / 10 min.
- **By design public:** member-car phone, WhatsApp, location and display name are exposed as the view defines them.
- **Migration:** none.

## Member cars (Phase 11.5, Step 5.4)

A member's OWN car ads, in `src/member-cars/`. Every route needs a bearer token. The owner is always the verified token's account, never a request field.

- **Routes:** `POST /v1/me/cars` (201 `{car}`), `GET /v1/me/cars?limit=&before=&status=`, `GET /v1/me/cars/:id`, `PATCH /v1/me/cars/:id` (body `{version, ...changed fields}`), and `DELETE /v1/me/cars/:id?version=N` (204, soft delete).
- **Publishing is disabled (decision D1):** every new ad is stored `pending` (not in `public_cars`), whatever the role, and no input can set `active`. The only status an owner sets is `active` → `sold` (`PATCH {version, status: "sold"}`); from any other state that is `409 invalid_state`. Publishing arrives with rewarded-ad verification.
- **Ownership (IDOR/BOLA):** enforced in three layers. The SQL is scoped by `owner_id = actor`, `source_type = 'member'` and `deleted_at IS NULL`; the service re-checks `row.ownerId === actor.id`; and `authorize()` from `src/authz` must allow the action. Another user's ad (an administrator's included: there is no admin car management here), a showroom car, a deleted ad, an unknown id and a malformed id are all the same `404`. An authenticated account that may not act (pending dealer) gets `403` on create/list and `404` on an item.
- **Input (strict whitelist):** `brand`, `model`, `year`, `price`, `currency` and `phone` are required on create. The optional fields are `mileage`, `transmission`, `fuelType`, `color`, `description`, `whatsapp` (defaults to the phone), `location`, and `latitude`/`longitude` as a pair. Types, lengths and ranges follow the `cars` CHECKs. Any owner, showroom, source, status, reviewer, reason, id, version-on-create or deletion field is `400 unknown_field`. Errors carry field names and codes only.
- **Optimistic concurrency:** in one transaction the acting account is re-checked and share-locked, the ad is locked `FOR UPDATE`, `version` is compared (`409 version_conflict`), the write is a compare-and-swap on `version` (the `touch_versioned` trigger increments it), and the audit row is written. All or nothing.
- **Soft delete:** `deleted_at = now()`, and the existing trigger removes the ad's favorites. There is no hard delete.
- **Audit:** `member_car.create|update|mark_sold|delete`, entity `car`, numbers only (version, number of fields changed), through the single writer in `auth/repository.ts`.
- **Rate limits (PROPOSED, per address and per instance):** create 20 / hour, update and delete 120 / 10 min, reads 240 / 10 min.
- **Migration:** none (the app role's column privileges from 0013 already cover exactly these writes).

## Member-car moderation (Phase 11.7.2-G)

Administrator review of member ads, in `src/member-cars/moderation.ts` and `moderation-routes.ts`. No migration (the columns and privileges exist since 0005/0013).

| Route (admin only) | Body | Transition |
|---|---|---|
| `GET /v1/admin/member-cars?status=&after=&limit=` | – | list (default `pending`) |
| `GET /v1/admin/member-cars/:id` | – | read |
| `POST …/:id/approve` | `{version}` | `pending → active` (publishes) |
| `POST …/:id/reject` | `{version, reason?}` | `pending → rejected` |
| `POST …/:id/suspend` | `{version, reason}` (required) | `active → suspended` |
| `POST …/:id/restore` | `{version}` | `suspended → active` |

- Non-admins (and unknown ids) get the same `404` before any read. Admins never edit an ad or mark it sold; only OWNERS mark `sold` (from `active`).
- A `rejected` ad cannot be approved or restored by an admin (`409 invalid_state`). Its owner edits it (a real change is required): it returns to `pending` with the reason cleared (audit `member_car.resubmit`) and is reviewed again.
- Concurrency: every action carries the `version` last seen (`409 version_conflict`); one transaction re-checks the admin, locks the row `FOR UPDATE`, compare-and-swaps on version AND source status, and writes the audit row (numbers only). Public visibility follows `status` through the `public_cars` view.
- **Known limitation – publishing is blocked.** Approve requires a `reward_grants` row that is `consumed`, has `ssv_transaction_id`, `verified_at`, `consumed_at`, and is bound to this ad and its owner. The AdMob server-side-verification callback that creates such rows does not exist in the backend yet, so today `approve` always answers `409 reward_required`. Nothing a client sends can satisfy the gate. Reject, suspend and restore are unaffected.

## Dealer registration over the cookie transport (Phase 11.7-H)

`POST /v1/dealers/register` now honours the opt-in cookie session transport exactly like login and `POST /v1/auth/register`: with `X-Session-Transport: cookie` the Origin / `Sec-Fetch-Site` checks run first (403 `forbidden_origin`, 400 for an unsupported value or when cookie transport is not configured), the refresh token goes only to the HttpOnly cookie and is removed from the body. Without the header nothing changes. The shared helper is `makeCookieTransport` (`auth/routes.ts`), used by both route modules; rate limiting (shared registration budget), JSON-only check, strict body validation (no role/status/extra fields) and session creation are untouched. The account is `role='dealer'`, `status='pending'`; it can sign in and its session can rotate, and approval stays the administrator's decision (11.7-E). Tests: `test/unit/dealer-register-cookie.test.ts`.

## Car images (Phase 11.5, Step 5.5)

Images of a member's OWN car, in `src/car-images/`. Every route needs a bearer token; the owner is always the verified token's account.

- **Routes:** `GET /v1/me/cars/:id/images` (200 `{images, maxImages}`), `POST /v1/me/cars/:id/images` (body `{assetId}`, 201 `{image}`) and `DELETE /v1/me/cars/:id/images/:imageId` (204, no body).
- **What "add" means:** it attaches an existing, `ready`, `car_image` asset owned by the caller to the car. Uploading, image processing and object storage (R2) are a later step; nothing here touches file bytes, and no response carries `storage_key`, `thumb_key` or the checksum (the DTO is `{id, assetId, sortOrder, isMain, width, height, createdAt}`). A pending, rejected, showroom-cover or already-attached asset is `409 invalid_state`.
- **Ownership (IDOR/BOLA):** car → car_images → assets. The car is found only as the actor's own member car (`owner_id = actor`, not deleted), re-checked in the service and authorized with the existing policy; an image is found only through that car (an image id of another car is 404 even if the caller owns both); an asset is found only if the caller owns it. Another user's car or asset (an administrator included), a deleted or showroom car, unknown and malformed ids are all the same `404`.
- **Limit:** read from `app_settings` `images.max_per_car` (member: 4), the value the database trigger enforces. Reaching it is `409 image_limit`; the check runs under the car's `FOR UPDATE` lock, so concurrent adds cannot exceed it.
- **Layout:** decided by the server. A new image goes last and is main if it is the first; deleting the main image promotes the first remaining one; positions stay contiguous (the deferred `car_images_require_main` trigger is satisfied at COMMIT). No set-main or reorder route in this step.
- **Delete:** removes the LINK only. The asset stays (ready, unattached, the caller's) for the cleanup job that also removes the stored files, so no file is orphaned. The car row and its `version` are never written.
- **Audit:** `member_car.image_add|image_delete`, entity `car`, numbers only, through the single writer in `auth/repository.ts`, in the same transaction.
- **Rate limits (PROPOSED, per address and per instance):** add and delete 60 / 10 min, list 240 / 10 min.
- **Migration:** none.

## Favorites (Phase 11.5, Step 5.6)

A member's OWN favorites, in `src/favorites/`. Every route needs a bearer token; the user is always the verified token's account, never a request field (a `userId` in the body or query is `400 unknown_field`).

- **Routes:** `POST /v1/me/favorites` (body `{carId}`; `201 {favorite}` when new, `200 {favorite}` when the car was already a favorite), `GET /v1/me/favorites?limit=&before=` (`200 {items: [{car, favoritedAt}], nextBefore}`) and `DELETE /v1/me/favorites/:carId` (`204`, no body).
- **Public cars only:** visibility is the existing view `public_cars`, not re-implemented. A favorite is created with `INSERT ... SELECT FROM public_cars`, and the list joins `public_cars`, so a deleted, pending, suspended or otherwise hidden car is never returned. An unknown, deleted, hidden or malformed car id on add is the same `404`. The `car` in the list is the public catalog DTO (Step 5.3): no owner id, reviewer data or search text.
- **Duplicates:** `UNIQUE (user_id, car_id)` with `ON CONFLICT DO NOTHING` decides, also under concurrency (never a second row, never a 500). The car row is locked `FOR SHARE` while adding, so the existing soft-delete trigger (which removes a car's favorites) cannot miss a favorite inserted at the same moment.
- **Delete is idempotent:** `204` whether or not the favorite existed, and it works for a car that is no longer public (the user can always clean up the list). It is scoped by `user_id = actor`, so it can never remove another user's row; another user's favorite and a missing one look the same. A malformed car id is `404`.
- **Hidden is not deleted:** suspending or hiding a car keeps the favorite row (only soft delete removes it, by trigger); the car is simply not listed until it is public again.
- **Pagination:** keyset on `favorites.id`, newest favorite first; `limit` 1-50 (default 20), `before` is the opaque `nextBefore` of the previous page. A cursor grants no access: the query is always scoped to the caller.
- **Authorization:** the existing `favorite` policy (strictly the owner, not even an administrator). An authenticated account that may not act (pending dealer) gets `403` on add/list and `404` on delete.
- **Audit:** `favorite.add` / `favorite.remove`, entity `car`, `{carId}` only, through the single writer in `auth/repository.ts`, in the same transaction and only when something changed.
- **Rate limits (PROPOSED, per address and per instance):** add and delete 120 / 10 min, list 240 / 10 min.
- **Migration:** none (SELECT/INSERT/DELETE on `favorites` and SELECT on `cars` and `public_cars` already exist; there is deliberately no UPDATE).

## Showroom cars: dealer and admin flows (Phase 11.5, Step 5.7)

A dealer's own showroom cars and the administrator's status change, in `src/showroom-cars/`. Every route needs a bearer token.

- **Dealer routes:** `POST /v1/dealer/cars` (201 `{car}`), `GET /v1/dealer/cars?limit=&before=&status=`, `GET /v1/dealer/cars/:id`, `PATCH /v1/dealer/cars/:id` (body `{version, ...changed fields, status?}`), `DELETE /v1/dealer/cars/:id?version=N` (204, soft delete).
- **Admin route:** `PATCH /v1/admin/showroom-cars/:id/status` with body `{version, status}` only. There is no administrator create, edit or delete route.
- **Who:** the dealer area is for an acting dealer (account `active`) only. A member, an administrator, a pending dealer and a dealer without a showroom get `404` on every dealer route, as on `GET /v1/dealer/showroom`. Non-administrators get `404` on the admin route before anything is read.
- **Ownership (IDOR/BOLA):** the showroom is always the one with `owner_id = actor` (never an input). Every statement is scoped by that showroom, `source_type = 'showroom'` and `deleted_at IS NULL`. The service re-checks the row's showroom, and `authorize()` must allow the action on a `showroomCarResource` built from the server-loaded showroom. Another showroom's car, a member ad, a deleted car, an unknown id and a malformed id are all the same `404`.
- **Status rule (unchanged):** a new car is `available` immediately, with no rewarded ad and no per-car approval. It is public only while its showroom is public (the `public_cars` view). The dealer switches a car between `available` and `sold`, the only two states of a showroom car. The administrator may set those same two states on any showroom car that is not deleted; setting the status a car already has writes nothing.
- **Input (strict whitelist):** `brand`, `model`, `year`, `price` and `currency` are required on create. `mileage` (null = unknown), `transmission`, `fuelType`, `color` and `description` are optional. Types, lengths and ranges follow the `cars` CHECKs. Any showroom, owner, source, status-on-create, version-on-create, member-only (phone, WhatsApp, location, coordinates, reasons) or deletion field is `400 unknown_field`.
- **Optimistic concurrency:** every write names `version`. In one transaction the acting account is re-checked and share-locked, the car is locked `FOR UPDATE`, the version is compared (`409 version_conflict`), the write is a compare-and-swap on `version`, and the audit row is written.
- **Soft delete:** `deleted_at = now()`; the existing trigger removes the car's favorites.
- **Audit:** `showroom_car.create|update|mark_sold|mark_available|delete` for the dealer and `showroom_car.admin_mark_sold|admin_mark_available` for the administrator, entity `car`, numbers only.
- **Rate limits (PROPOSED, per address and per instance):** create 60 / hour, update and delete 120 / 10 min, reads 240 / 10 min, admin status 120 / 10 min.
- **Migration:** none.

## Object storage foundation (Phase 11.6.1)

A replaceable storage layer in `src/storage/`, for the image pipeline of the next steps. **Nothing in the running server uses it yet**: there is no upload route, no image processing and no startup wiring in this step.

- **Interface** (`provider.ts`): `put(key, bytes, {contentType})`, `get(key)` → `{body, contentType, size} | null`, `delete(key)` (idempotent) and `exists(key)`. Errors are `StorageError` with a code (`invalid_key`, `invalid_content_type`, `too_large`, `unavailable`, `integrity`), a fixed message and, for backend failures, the HTTP status only. No error contains a key, bucket, endpoint, credential or backend response body.
- **Providers:** `createS3Storage` is Cloudflare R2 or any S3-compatible service, over the S3 REST API with Node's `fetch` and an AWS Signature V4 signer written on `node:crypto` (no SDK, no new dependency). `createMemoryStorage` is an in-memory provider with the same contract, for tests and local development. One contract test suite runs against both.
- **R2 requests:** path-style `<endpoint>/<bucket>/<prefix>/<key>`, signed payload (`x-amz-content-sha256`, never `UNSIGNED-PAYLOAD`), redirects refused, a per-request timeout, and size limits on upload and download (an announced or streamed size above the limit is refused, and a length mismatch is an `integrity` error). A 404 on `get`/`exists` means missing; any other failure is `unavailable`, never "missing".
- **Keys** (`keys.ts`) are generated by the server, never taken from a client, and never returned to one. They are still checked before every call: 1-8 segments of `[A-Za-z0-9._-]` that start with a letter or digit, at most 512 characters. Traversal (`..`), absolute paths, empty segments, backslashes, percent-encoding, whitespace, control and non-ASCII characters are refused.
- **Configuration** (`config.ts`, documented in `.env.storage.example`): `STORAGE_PROVIDER` (`r2` | `memory`; memory is refused in production). For r2, `STORAGE_S3_ENDPOINT` (an https origin, with plain http only for a loopback test server outside production), `STORAGE_S3_REGION` (`auto` for R2), `STORAGE_S3_BUCKET`, `STORAGE_S3_ACCESS_KEY_ID` and `STORAGE_S3_SECRET_ACCESS_KEY` are all required, with no built-in value. Optional: `STORAGE_KEY_PREFIX`, `STORAGE_TIMEOUT_MS` (default 10000) and `STORAGE_MAX_OBJECT_BYTES` (default 10 MiB). Problems are listed without values, and `redactStorageConfig` hides the endpoint, bucket and both credentials.
- **Verification:** the signer reproduces AWS's published S3 GET and PUT example signatures and matches botocore on 40 generated requests (`test/fixtures/sigv4-botocore-vectors.json`). `test/integration/storage.integration.test.ts` runs against a real bucket only with `STORAGE_IT=1`.
- **Migration:** none.

## Secure asset upload (Phase 11.6.2)

Authenticated image upload in `src/assets/`, built on the storage foundation (11.6.1) and the existing `assets` table. **No migration.**

- **Routes:** `POST /v1/me/assets?kind=car_image|showroom_cover` takes the raw image as the request body, with `Content-Type: image/jpeg | image/png | image/webp`. It answers `201 {asset: {id, kind, status: "pending", bytes, width, height, createdAt}}`. `GET /v1/me/assets/:id` returns the caller's own asset only. The routes are registered only when `STORAGE_PROVIDER` is set (then the whole storage configuration must be valid, or the process stops with exit code 78).
- **Who:** members and dealers upload car images; only dealers upload showroom covers. An administrator, a pending dealer or a suspended account is `403`. Authentication and the declared type are checked in an `onRequest` hook, before any byte of the body is read. The image body parser exists only inside the upload routes' encapsulated plugin.
- **What (the bytes decide):** the declared type must be one of the three, with no parameters, **and** match what the bytes prove (`image-sniff.ts`):
  - **PNG:** IHDR with a valid CRC, and IEND as the last chunk.
  - **JPEG:** a baseline, extended or progressive frame, and an EOI after it.
  - **WebP:** an exact RIFF size, and a still VP8, VP8L or VP8X image (animated WebP is refused).
  - **Refused:** GIF, BMP, TIFF, SVG, HTML, polyglots with appended data, truncated or corrupted files. No filename is ever read.
- **Limits (PROPOSED):** 8 MiB per upload (or the storage limit, if smaller; `413`), 10,000 px per side and 40 Mpx in total (`413`), 30 pending uploads per owner per 24 hours (`409 upload_limit`, checked under a per-owner advisory lock), and per-address rate limits (upload 30 / 10 min, read 240 / 10 min).
- **Storage keys** are generated by the server (`incoming/<kind>/<random UUID>`). They are never accepted from a client, never returned, and never logged.
- **Database row:** a `pending` asset owned by the actor, holding the storage key, byte size, SHA-256 and dimensions of the original. `mime`, `thumb_key` and `ready_at` stay empty: only the processing step (11.6.3) produces the WebP and its thumbnail and marks the asset `ready`. So a pending upload cannot be attached to a car yet (the existing `car_images` trigger refuses it).
- **Failure handling (no unknown objects):** the row (with its key) is committed **before** the object is written. If the write fails, the object is deleted (idempotent) and then the row. If that cleanup cannot finish, the row stays `pending`, so the cleanup job (pending rows older than 24 hours) still finds the key. The client gets `503 storage_unavailable`. Logs carry the asset id and error codes only.
- **Ownership:** every read and the compensating delete are scoped by `owner_id = actor`. Another user's asset is the same `404` as an unknown one, and attaching it to a car is `404` too (Step 5.5).

## Image processing (Phase 11.6.3)

Each uploaded image is processed right after the upload, in `src/assets/`. A `pending` asset becomes `ready` (a WebP main image plus a WebP thumbnail, with metadata stripped) or `rejected` (with a reason code). The upload answer carries the resulting state. **No migration.** Originals are never served, and no route reads storage.

- **Codec** (`codec.ts`): a small interface. Production uses **sharp** (libvips), the one dependency added in this step (`package.json`: `"sharp": ">=0.33.5 <0.35.0"`). Safe image decoding and WebP encoding are not possible without a native image library. The sharp codec (`sharp-codec.ts`):
  - decodes only JPEG, PNG and WebP (checked before every pipeline, because libvips also knows SVG, GIF, TIFF, HEIF and PDF);
  - uses `limitInputPixels` (refusal from the header, before pixels are decoded), `failOn: 'warning'`, one page, EXIF orientation, sRGB, and no metadata kept;
  - uses a per-image timeout, no operation cache, and one thread per pipeline.
- **Rules** (`processor.ts`, independent of the codec):
  1. The stored original is re-checked from its bytes (type, 10,000 px per side, 40 Mpx in total).
  2. The decoder's own header reading must agree with it (format, size, a single frame).
  3. The main image fits inside 1600 px, and the thumbnail (made from the main image) inside 400 px. Neither is ever enlarged.
  4. Every output is validated on its **bytes** (`webp-inspect.ts`): a clean still WebP with no EXIF, GPS, XMP, ICC, animation or unknown chunk; real size equal to the reported size; aspect ratio kept.
  5. Output budgets are 1.5 MiB for the main image and 150 KiB for the thumbnail. One lower quality is tried before rejecting. A 15 s timeout applies around every codec call.
- **Keys:** the original `incoming/<kind>/<uuid>`, the main image `processed/<kind>/<uuid>.webp` and the thumbnail `thumbs/<kind>/<uuid>.webp` share one UUID. Every object of an asset is therefore findable from its row (`derivedKeys()`, for the future cleanup job).
- **Order** (`processing-service.ts`):
  1. Read the pending row and the original; the original's size and SHA-256 must match the row, otherwise the asset is `rejected: integrity`.
  2. Process the image.
  3. Store both outputs, then **read both back** and verify them (same SHA-256, clean WebP, expected size).
  4. Only then mark the row `ready`, with a compare-and-swap on the pending original key, filling exactly the columns the `assets_ready_shape` CHECK requires.
  5. Delete the original (best effort).
- **Failures:**
  - A bad image (malformed, unsupported, too large, decompression bomb, timeout, output over budget, metadata that would not strip, a changed or missing original) makes the asset `rejected` with a reason, and its objects are deleted.
  - Storage or database trouble leaves it `pending`, never public. That attempt's outputs are deleted, and a later attempt can succeed.
  - A lost compare-and-swap never deletes objects the row points to.
- **Limits:** at most 2 images are processed at once per process, and the same asset never twice at the same time. Logs carry the asset id, the result and a reason code only.
- **Tests:** a Pillow-backed reference codec (`test/helpers/pil-codec.ts`, test-only) runs the real pipeline where sharp is not installed. One contract test suite holds sharp and Pillow to the same rules. The sharp suites run in CI after `npm install`.

## Image delivery, showroom cover and cleanup (Phase 11.6.4)

Serving the processed images, attaching a showroom cover, and removing abandoned uploads and orphaned objects, in `src/assets/` and `scripts/`. **No migration.** Like upload, all of it is registered only when `STORAGE_PROVIDER` is set.

- **Image routes** (`delivery.ts`, `delivery-routes.ts`):
  - `GET /v1/public/assets/:id/image` and `/thumb` (no authentication) serve a `ready` asset only when the public views allow it: a `car_image` attached to a car in `public_cars`, or a `showroom_cover` that is the cover of a showroom in `public_showrooms`. Anything else, including a malformed id, is the same `404`.
  - `GET /v1/me/assets/:id/image` and `/thumb` (Bearer) serve the caller's own `ready` assets only (attached or not). Nobody else's, an administrator included.
  - `GET /v1/public/cars/:id/images` → `{images: [{assetId, isMain, sortOrder, width, height}]}` and `GET /v1/public/showrooms/:id/cover` → `{cover: {assetId, width, height} | null}` let a client find the asset ids of a public car or showroom (the Step 5.3 catalog answers are unchanged). `404` when the car or showroom is not public.
- **Never an original:** only the row's processed keys (`storage_key` = main image, `thumb_key` = thumbnail) of a `ready` asset are read, and never a key under `incoming/`. The bytes must be a clean, still WebP (`webp-inspect.ts`); the main image must also match the row's SHA-256 and size, and a thumbnail may not be larger than the main image. A missing or invalid object is `404` and a log line (asset id + reason). A storage failure is `503 storage_unavailable`. No key, bucket or provider detail appears in a response or a log.
- **Headers:** `Content-Type: image/webp`, `Content-Length`, `ETag` (from the row's SHA-256; a matching `If-None-Match` is `304` without reading storage, but never before the visibility check), `Content-Security-Policy: default-src 'none'; sandbox`, `Content-Disposition: inline`, and the server-wide `X-Content-Type-Options: nosniff`. Public images: `Cache-Control: public, max-age=300` (short, so hiding a car or a showroom takes effect within minutes). Owner images: `private, no-store`.
  - **The one change to an earlier file's behaviour:** `server.ts` now sets `Cache-Control: no-store` only when a route has not set it. Only the two public image routes set it; every other answer (errors of the image routes included) keeps `no-store`, as before.
- **Rate limits (PROPOSED, per address):** public images 1200 / 10 min, owner images 600 / 10 min, discovery 480 / 10 min, cover read 240 / 10 min, cover write 60 / 10 min.
- **Showroom cover** (`cover.ts`, `cover-routes.ts`): `GET`, `PUT {assetId}` and `DELETE` on `/v1/dealer/showroom/cover`.
  - Only an active dealer, on the showroom found by `owner_id = the caller` (whatever its status, as the existing policy allows). A guest, a member, an administrator or a dealer without a showroom gets `404`.
  - The asset must be the caller's own (another user's is the same `404` as an unknown one), a `showroom_cover`, `ready`, and stored under processed keys. Otherwise `409 invalid_state`.
  - One transaction: the account re-checked, the showroom locked `FOR UPDATE`, one `UPDATE` of `cover_asset_id`. The database's `showrooms_cover_guard` trigger stays the backstop (its refusal is also `409`). The previous cover asset is not deleted. No audit row is written (the audit vocabulary belongs to Phase 11.5 and was not changed).
- **Car images:** attaching to a member's car (Step 5.5) already requires the caller's own `ready` `car_image`. This step adds tests for it, with no code change.
- **Cleanup** (`cleanup.ts`, `cleanup-repository.ts`, `scripts/assets-cleanup.ts`): `npm run assets:cleanup` (dry run: counts only) and `npm run assets:cleanup -- --execute` (deletes). Options: `--batch-size=1..1000` (100), `--max-batches=1..100` (10), `--older-than-hours=24..720` (24), `--shard=<0-2 hex digits>`, `--skip-rows`, `--skip-orphans`. It needs `STORAGE_PROVIDER=r2` (the memory provider's objects live in the server process). It prints one JSON report with counts only. Exit codes: 0 done, 1 stopped on a database or storage failure, 64 bad arguments, 78 bad configuration.
  1. **Stale rows:** `pending` or `rejected`, older than the threshold by the database clock, with no car image and no showroom cover. Each one is deleted by a compare-and-swap that re-checks all of this and its storage key. Only then are its objects (original, main, thumbnail, all derived from the key) deleted. A row with a key this backend did not generate is kept. `ready` rows are never deleted.
  2. **Orphaned objects:** only `incoming/`, `processed/` and `thumbs/` of the two kinds are listed (S3 `ListObjectsV2`, signed like every other request; `list` in `storage/`). An object is deleted only if its key has exactly a generated shape, it is older than the threshold, and **no row of any status** references it: as `storage_key` or `thumb_key`, or, for a processed image or thumbnail, through its original (an asset being processed) or its main image (a ready asset).
  3. **Bounds and failures:** at most `max-batches` batches of `batch-size` rows, and `max-batches` listing pages in total. `complete: false` says a bound was reached; the next run continues. A database or storage failure stops the run and is reported. Every finished step is consistent on its own: a row deleted before its objects leaves them as orphans for phase 2.

## Asset lifecycle reliability (Phase 11.6.5)

What already recovered each failure (11.6.2–11.6.4), and the one gap this step closes. **No migration, no new route.**

| Failure | Recovery |
|---|---|
| Upload: the object write fails | compensation (object, then row); if that fails too, the row stays `pending` → cleanup phase 1 after the threshold |
| Processing rejects the image | the row is `rejected`; leftover objects → phase 1 after the threshold |
| Ready, but the original could not be deleted | orphan sweep (phase 2) |
| Cleanup deleted a row but not its objects | orphan sweep (phase 2) of a later run |
| **Processing hit a transient storage/database failure, or the process crashed or restarted mid-processing** | **before 11.6.5: nothing retried; phase 1 deleted the upload after 24 h. Now: phase 0 retries it** |

- **Phase 0, retry** (`cleanup.ts`, `listRetryable` in `cleanup-repository.ts`): each run of `npm run assets:cleanup` first hands at most `--retry-limit` (default 20, max 200) `pending` assets to the **existing** processor (`processing-service.ts`, unchanged), oldest first. Only assets older than 15 minutes (the upload's own attempt is over) and younger than `--older-than-hours` (phase 1 owns older ones, so the two never overlap), by the database clock.
  - **Repeat-safe:** the processor's compare-and-swap on the pending original key means a second run or a concurrent one finds nothing to do, or leaves an asset another process finished as it is.
  - A transient database/storage outcome stops the run, as in the other phases. Any other outcome is counted (`ready`, `rejected`, `stillPending`, `skipped`), and the next run tries again until the asset becomes stale.
  - It deletes nothing itself: only the processor's own existing rules apply (they only ever touch a `pending` asset, which nothing can reference).
  - Dry run: candidates are counted, nothing is processed.
- The phase needs the image codec (sharp), like the server. Without it the tool stops with exit code 78 unless `--skip-retry` is given.
- **Recommended schedule:** `npm run assets:cleanup -- --execute` every 15–60 minutes. A user who saw `status: "pending"` after an upload can poll `GET /v1/me/assets/:id`.

## Asset integrity audit (Phase 11.6.6)

`npm run assets:audit` compares the database records of images with the stored objects, in both directions, and prints ONE JSON report. **Dry run by default**: it reads, counts and reports; it deletes only with an explicit `--execute`. No migration, no dependency, no scheduler, no HTTP route: it is an operator command (`scripts/assets-audit.ts`, `src/assets/audit.ts`, `src/assets/audit-repository.ts`). Phases 11.6.1–11.6.5 are unchanged.

**What it checks**
- **Records → objects.** Every `ready` asset (keyset-paged): the main image and the thumbnail must exist and be a clean still WebP (the processor's own rule, `inspectWebp`). For the main image it also compares, where the record makes it verifiable, the byte size, the SHA-256 and the dimensions; the thumbnail has no recorded checksum, so it is checked as a WebP and for not being larger than the main image. Verdict per asset: `missing` > `corrupt` (with a reason: `invalid_image`, `size_mismatch`, `hash_mismatch`, `dimension_mismatch`, `unreadable`) > `failed` (could not be verified) > `healthy`.
- **Unlinked assets.** `ready` assets that no car image and no showroom cover references (decided by the database in the same statement that lists them).
- **Objects → records.** The three areas the backend writes (`incoming/`, `processed/`, `thumbs/`) are listed page by page; an object no row refers to (any row's `storage_key`/`thumb_key`, or, for a processed image or thumbnail, the row of its original/main image) is an **orphan**. Same lookup as the cleanup job.

**What it may delete (only with `--execute`)** — and nothing else:
1. an **unlinked asset**: `ready`, referenced by nothing, **older than the grace period** (since it became ready, by the database clock), with keys of exactly the shape this backend generates. The row goes first, by a locked compare-and-swap (`SELECT … FOR UPDATE`, then a conditional `DELETE` re-checking status, keys, age and references), then its objects (original, main, thumbnail). The lock matters: a showroom cover set concurrently would otherwise be silently cleared by the foreign key (`ON DELETE SET NULL`); with the lock the delete waits for the attach and then refuses (checked on PostgreSQL 16, see below). After the delete commits, a late attach fails on the foreign key (the cover endpoint answers 409).
2. an **orphan object**: recognized key shape, older than the grace period (storage last-modified time), no row references it according to a lookup that **succeeded**, confirmed by a second lookup right before the delete.

**Never deleted:** a referenced asset, its objects or its record, whatever its health. A referenced asset that is `missing` or `corrupt` is **report-only**: it appears in `assets.referencedProblems` (asset ids, at most 50), `findings` is `true` and the exit code is 2. Someone has to restore the image or replace it (`PUT /v1/dealer/showroom/cover`, or the car's images).

**Failure rule.** The run has two passes. Pass 1 only reads. Pass 2 (the deletions) runs only if pass 1 finished with no failed or uncertain check: a database error, a storage error that survived its retries (2 retries, 200/400 ms), an unexpected error, or an asset whose objects could not be read blocks every deletion of the run (`deletion.mode: "blocked"`, `deletion.blockedBy`). A failed query is never read as "nothing references this". In pass 2, the first database or storage failure stops the deletions. Reads are retried; the delete of a row is not. After 5 failed object reads the run gives up (storage is clearly down).

**Options** (all optional): `--execute` | `--dry-run` (default; both together are refused) · `--grace-hours=24..720` (default **24**; never less, so an upload about to be attached is not removed) · `--batch-size=1..1000` (100) · `--max-batches=1..100` (10; at most this many pages of records and this many pages of object keys per run, `complete: false` when a limit was reached) · `--shard=<0-2 hex digits>` (only object keys whose uuid starts with it) · `--skip-assets` · `--skip-orphans`. It needs the server's environment (database + `STORAGE_*`) and `STORAGE_PROVIDER=r2`; the in-memory provider is refused.

**The report** (counts, plus asset ids of referenced problems; never a storage key, bucket, endpoint, signed URL or credential). `summary`: `scanned` (assets + objects listed), `healthy`, `missing`, `corrupt`, `unlinked`, `orphaned`, `deleted` (records + orphan objects; the objects of a deleted record are in `deletion.assetObjectsDeleted`), `skipped` (inside the grace period, unrecognized key, unsafe listing entry, refused at the last moment, not attempted because the run was blocked or stopped), `failed`. Details: `assets`, `orphans`, `deletion`, `findings`, `error`.

**Exit codes:** 0 audit done, nothing needs attention · 1 the audit could not finish, or an item could not be verified or deleted · 2 audit done, a referenced asset is missing or corrupt · 64 invalid arguments · 78 invalid configuration.

**Run it manually**
```
cd backend
npm run assets:audit                       # report only
npm run assets:audit -- --execute          # also delete unlinked assets and orphan objects older than 24 h
npm run assets:audit -- --grace-hours=72 --max-batches=50 --batch-size=500
```
Read the dry-run report first. Deleting an unlinked asset also means a dealer's previous cover (kept as a ready, unattached asset by 11.6.4) can no longer be re-selected after the grace period.

**Schedule it weekly, later** (nothing is scheduled by this project; pick the mechanism of the hosting you choose). The command is stateless and repeat-safe, so any scheduler works; run it with the same environment as the server:
- cron / systemd timer: `0 3 * * 0  cd /srv/najaf/backend && npm run assets:audit -- --execute >> /var/log/najaf-audit.log 2>&1` (Sunday 03:00);
- a hosting platform's cron job, or a scheduled GitHub Actions workflow, running the same command with the production secrets of that platform.
Alert on exit code 1 or 2 and keep the JSON output (it has no secrets). Start with a few weeks of dry runs (no `--execute`) before enabling deletion.

**Tests.** `test/unit/assets-audit.test.ts` (48: options and the execution guard, health checks, referenced assets, the grace boundary, unlinked assets, orphans, database/storage failures, bounds, exact reporting, a randomized safety property, statement shape, source guards); `test/integration/assets-audit.integration.test.ts` on PostgreSQL 16 with the application role (CI; skipped without `DATABASE_URL` and `ADMIN_DATABASE_URL`).

## Showroom-car images (Phase 11.7.2-I)

Images of a showroom owner's OWN showroom cars, in `src/showroom-car-images/`. Every route needs a bearer token of an ACTIVE dealer; the showroom is always the one owned by the verified account (`showrooms.owner_id`), never a request field. **Status: under verification: not complete until GitHub CI passes.**

- **Routes:** `GET /v1/dealer/cars/:id/images` (200 `{images, maxImages}`), `POST /v1/dealer/cars/:id/images` (body `{assetId}`, 201 `{image}`), `DELETE /v1/dealer/cars/:id/images/:imageId` (204). The DTO is the member one (`{id, assetId, sortOrder, isMain, width, height, createdAt}`): no storage key, thumbnail key or checksum.
- **Ownership (IDOR/BOLA), enforced three times per operation:** the SQL finds the car only as a car of that showroom (`showroom_id = <the showroom>`, `source_type = 'showroom'`, not deleted; locked `FOR UPDATE` for writes); the service re-checks `car.showroomId === showroom.id`; and the existing policy (`showroomCarResource`, owner `read`/`update`) must allow it. The asset is found only if the caller owns it; an image only through the authorized car. Members, administrators, pending dealers, other dealers, member ads, deleted/unknown/malformed ids and other users' assets are all the same `404`.
- **Asset flow reused:** the dealer uploads through the existing `POST /v1/me/assets?kind=car_image` (allowed for `member` and `dealer`), then attaches the READY asset. Pending / rejected / `showroom_cover` / already attached = `409 invalid_state`.
- **Limit:** `app_settings` `images.max_per_car` → `showroom` (5), the value the `car_images_guard` trigger enforces; `409 image_limit` under the car's row lock. The trigger also requires asset owner = showroom owner (verified on PostgreSQL 16 locally). No set-main or reorder route; layout is the server's (first image main, delete promotes the next, positions contiguous).
- **Delete** removes the LINK only (the asset stays for the cleanup job). The car row and `version` are never written.
- **Audit:** `showroom_car.image_add|image_delete` (actor role `dealer`, entity `car`, numbers only), through the single writer; the types extend `AuditEvent` via `ShowroomCarImageAuditAction` (the pinned `BaseAuditEvent` text is untouched).
- **Public display (verified, unchanged):** `GET /v1/public/cars/:id/images` reads `public_cars` (member and showroom cars alike, no source filter) and ready `car_image` assets; a car of a suspended/pending showroom is not public, so it has no public images.
- **Rate limits (PROPOSED, per address and per instance):** writes 60 / 10 min, reads 240 / 10 min (own buckets, `showroomCarImages.*`).
- **Migration:** none. Tests: `test/unit/showroom-car-images-service.test.ts`, `test/unit/showroom-car-images-http.test.ts`, and the CI-only `test/integration/showroom-car-images.integration.test.ts` (needs `DATABASE_URL` / `ADMIN_DATABASE_URL`).

## Admin user directory and dashboard statistics (Phase 11.7.2-J)

Read-only administrator views in `src/admin-users/`. **Status: complete (the user confirmed GitHub CI passed).** No migration.

| Route (admin only) | Response |
|---|---|
| `GET /v1/admin/users?role=&after=&limit=` | `{users: [{id, name, phone, email, role, status, createdAt}], nextAfter}`: role `user`/`dealer`/`admin` or all; keyset by ascending id; limit 1..100 (default 50) |
| `GET /v1/admin/users/:id` | `{user, showroom: {id, name, status} \| null, memberCars: [{id, brand, model, status}] (≤ 100, newest first), memberCarsTotal}` |
| `GET /v1/admin/stats` | `{stats}`: the ten dashboard counts `totalUsers, totalShowrooms, totalShowroomCars, totalMemberCars, pending/active/sold/rejected/suspendedMemberCars, pendingDealers` |

- **Authorization:** two dedicated least-privilege resources in the existing policy, `user_directory` and `platform_stats`: `read` for administrators only, no other action for anyone, never public. Non-admins (member, dealer, pending dealer, no actor) get the same `404` as an unknown account, before the query is parsed or the database is read.
- **Fields:** exactly what the existing admin screens display, built field by field. Never `password_hash`, login counters, lock state, sessions, tokens or verification codes (the repository never selects them).
- **Records:** soft-deleted accounts and cars are excluded from the directory and every count; showrooms have no `deleted_at` and are all counted. Statistics come from one SQL statement over the real tables (verified locally on PostgreSQL 16 as the `najaf_app` role).
- **No state change:** no suspend/activate/delete here; reads are not audited (as the other admin lists). Rate limit (PROPOSED): 240 reads / 10 min per address (`adminUsers.read`).
- Tests: `test/unit/admin-users.test.ts`, and the CI-only `test/integration/admin-users.integration.test.ts`.

## Asset integrity scan and confirmed cleanup (Phase 11.7.2-K)

An administrator-controlled version of the 11.6.6 audit, in `src/assets/integrity.ts` (service), `integrity-routes.ts` (HTTP), `integrity-repository.ts` (SQL). **Status: under verification: not complete until GitHub CI passes.** No migration, no new table, no new storage path or asset state: it reuses the storage provider (`list`/`get`/`delete`), the audit's checks (`audit.ts`, run with `dryRun: true` and a read-only observer), the cleanup job's key shapes and reference lookup, the locked compare-and-swap of 11.6.6, the authorization core and the single audit writer.

| Route (admin only) | Behaviour |
|---|---|
| `GET /v1/admin/asset-integrity/scan?scope=all\|assets\|objects&after=&shard=` | READ ONLY. `{scannedAt, scope, graceHours, complete, nextAfter, error, summary, items, truncated}`. Bounded (200–400 records / objects per call); `nextAfter` continues the record scan, `shard` narrows the object scan |
| `POST /v1/admin/asset-integrity/cleanup` `{confirm: true, items: [{type, id}]}` | 1..50 items. The literal `true` is required. Each item is re-validated by the server before anything is deleted |

- **Categories (never mixed):** `corrupt` (objects exist but do not match the record), `missing` (a record with an absent object), `orphaned` (an object with no record, or a healthy record nothing uses), `unverified` (storage trouble: could not be checked). A record that is both unused and corrupt/missing is listed as corrupt/missing, with `referenced: false`.
- **Deletable** = what the audit's own execute pass deletes: an unreferenced `ready` record past the grace period (24 h) with generated keys, or an unreferenced object of a generated shape past the grace period. Health never makes anything deletable; a referenced asset (car image or showroom cover) is report-only, an unverified one is never deletable, and `pending`/`rejected` assets (uploading, processing, refused) are protected.
- **Revalidation before deleting:** record: `ready`, unreferenced, old enough, generated keys, then the locked compare-and-swap (waits for a concurrent attach and refuses) with its audit row in ONE transaction, and only afterwards its objects; object: still listed, old enough, and unreferenced by TWO independent lookups. A database/storage/audit failure stops the run (the remaining items are `not_attempted`). One scan or cleanup at a time per process (`409 busy`).
- **Audit trail** (`audit_logs`, numbers only): `asset_integrity.delete_asset` (with the record), `asset_integrity.delete_object` (written BEFORE the delete), `asset_integrity.delete_failed`, `asset_integrity.cleanup` (one summary row per run). A deletion without its audit row cannot happen.
- **Authorization:** a dedicated `asset_integrity` resource (`read` = scan, `delete` = cleanup): administrators only; everyone else gets `404`, before the input is parsed. Rate limits (PROPOSED): scan 20 / 10 min, cleanup 30 / 10 min per address.
- **Keys stay internal:** a client sees an asset id or an object reference `<area>.<kind>.<uuid>`; never a prefix, bucket, endpoint or signed URL.
- The 11.6.6 command (`npm run assets:audit`) is unchanged: the observer added to `runAssetAudit` is optional and read-only.
- Registered only with authentication and configured storage. Tests: `test/unit/asset-integrity.test.ts` and the CI-only `test/integration/asset-integrity.integration.test.ts`.

## Rewarded-ad grants: shared backend (Phase 11.8, Steps 1, B, C, D, E and G)
Status: **Step 1 (core), 11.8-B (routes), 11.8-C (AdMob verification) and 11.8-D (integration tests) complete, CI confirmed. 11.8-E (rate limits and abuse protection) and 11.8-G (background maintenance and alerts) complete, CI confirmed. 11.8-H (operational logs and monitoring) complete, CI confirmed. 11.8-I (final verification) complete, CI confirmed: Phase 11.8 is complete.** The core is provider-independent. Without `REWARD_PROVIDER` the server uses the UNCONFIGURED verifier: a reward request answers 503 and nothing can be verified, consumed or published. With `REWARD_PROVIDER=admob` the AdMob verifier is used (Android rewarded ads only). No frontend, no Android UI or AdMob SDK (Phase 11.10), no web ads. No migration: `reward_grants` (0009) is used as it is.
- **Files:** `src/rewards/provider.ts` (the `RewardVerifier` interface and the unconfigured default that rejects everything), `src/rewards/repository.ts` (the only code that writes `reward_grants`), `src/rewards/service.ts`.
- **Life of a grant:** `requestReward` (an active account; unbound, 30 minutes, at most 3 open: PROPOSED, needs approval) -> `verifyReward` (only the verifier, from the provider's own evidence, can move it to `verified`; the provider transaction id is unique per provider) -> `consumeReward` (the owner attaches a `verified`, unexpired grant to ONE of their own `pending` ads: one compare-and-swap that also sets `car_id`, which is UNIQUE, and `consumed_at`; for a regular member the same transaction then sets the ad `active`). `car_id` is bound at consumption, not at request, so a failed or expired grant never blocks its ad.
- **Never trusts the client:** the verifier is handed the grant id and user id the SERVER holds and must check that the evidence names both; nothing a client sends sets a status. Replays are stopped by `reward_ssv_uq` (one receipt, one request), the expected-state CAS (one consumption), `car_id UNIQUE` (one grant per ad) and the user check. Expiry is judged by the database clock. Lock order is grant, then ad; moderation locks the ad, so a reward and a moderation action exclude each other.
- **Publication rule:** a regular member (`role = member`) whose reward was verified by the server's verifier and consumed here gets the ad published **in the same transaction** (`pending` -> `active`, one audit row `member_car.reward_publish`); there is no admin step and no pending state afterwards. If verification, consumption, the publish UPDATE or its audit row fails, everything rolls back: the reward is not spent and the ad stays `pending`. Nothing a client sends (a success flag, a transaction id) can publish; only a `consumed` grant can. Showroom-owner roles (`dealer`, and `admin` acting as an owner) keep the existing path: the grant is consumed, the ad stays `pending`, and moderation approves it (`409 reward_required` without a consumed grant). Showroom-owner ACCOUNT activation still requires admin approval (untouched). Moderation code is unchanged.
- **Answers:** a malformed id, an unknown grant, someone else's grant or ad: the same `not_found`. A verifier that is not configured (production default) refuses to open requests and rejects verification (`unavailable`).
- **Not done (later steps, each needs its own approval):** the Android UI and AdMob SDK (11.10), the web decision, the frontend, narrower column privileges on `reward_grants`.

### Background maintenance and alerts (Phase 11.8-G)
- **What it is:** one operator command, `npm run rewards:maintenance` (`scripts/rewards-maintenance.ts`, same model as `assets:cleanup`): never an HTTP route, never started by the server. No queue, timer or external service was added; run it from cron or any scheduler you already have.
- **Operations (in this order):** (1) **expire**: `requested`/`verified` grants past their expiry that hold no ad become `expired` (the live paths already refuse them; this fixes the stored status). (2) **purge**: `expired`/`failed` grants that hold no ad and expired more than `--retention-days` ago (default 30, never under 7) are deleted. A `consumed` grant is never touched: moderation and the audit trail rely on it. The 7-day floor exists because a purged grant frees its provider transaction id, and AdMob callbacks are only accepted within 1 hour of their timestamp.
- **Safety:** dry-run unless `--execute`; bounded (`--batch-size` 1-1000, default 500; `--max-batches` 1-100, default 10); each batch is one atomic statement using `FOR UPDATE SKIP LOCKED`, so a grant being consumed or verified right now is skipped, never blocked or raced, and two runs never touch the same row; repeat-safe (a rerun after a failure or a bound just continues). A database failure stops the run with a code (`database_unavailable`, `audit_unavailable`, `unexpected`), exit code 1; what was done stays consistent.
- **Alerts (signals, not delivery):** the JSON report has `alerts` and the same events go to stderr: `verified_rewards_expired_unused` (at least `--alert-verified-lost` verified rewards, default 10, expired unused in one run: viewers watched the ad and never published) and `backlog_remaining` (a bound was reached, run again). Alerts are only judged on executed runs. Sending them to people (e-mail/WhatsApp/SMS) is NOT part of this phase.
- **Audit:** one `reward_maintenance.run` row per executed run (`audit_logs`, actor `system`, numbers only: expired, expiredVerified, purged, retentionDays, stopped, alerts). The report and logs carry counts only: no user id, grant id or transaction id.
- **No migration.** Tests: `test/unit/rewards-maintenance.test.ts` (in-memory repository, failure and retry cases, SQL shape, command line, static guards) and the CI-only `test/integration/rewards-maintenance.integration.test.ts` (application role, real locks).

### Operational logs and monitoring (Phase 11.8-H)
- **Two records, never mixed.** The **audit trail** (`audit_logs`, only `createPgAuditRepository`) says who did what to which entity, inside the action's own transaction, append-only, numbers only. **Diagnostic logs** (pino JSON on stdout, `src/logging.ts`) say what the process observed: best effort, for an operator, never the source of a business fact. Nothing in `logging.ts` writes audit rows or touches the database.
- **What never reaches a log:** passwords, one-time codes, access/refresh tokens, session cookies, secrets, signatures, phone numbers, URL credentials, and the row values a PostgreSQL message quotes (`Key (phone_e164)=(...)`). Enforced in three layers: (1) serializers: a request is logged as method + PATH (the query string is dropped, `hasQuery: true` says there was one: the AdMob callback carries its signature, user id and transaction id there), a response as its status, an error as name/kind/sqlstate/constraint plus a masked message and stack; (2) a scrub over every plain log field (a field NAMED like a secret is replaced by `[redacted]`; a string that LOOKS like a bearer token, JWT, phone number, URL credential or quoted driver value is masked; bounded, cycle-safe, never throws); (3) pino header redaction (authorization, cookie, x-api-key, set-cookie). `describeError` (used by boot logs, readiness and the operator scripts) and the boot console logger apply the same masking. Before this phase a database error's raw driver message (which can contain a phone number) was passed to the log unmasked (`describeError`, and the `err` of a 500).
- **Operational events added** (warn, by route PATTERN, never the URL): `http.response_5xx` (any 5xx, including the 503s that routes send directly), `http.slow_request` (3 s or more); the error handler now tags its lines `http.request_failed` (5xx, with the masked error) and `http.request_rejected` (4xx, with the code). Existing events (`auth.*`, `reward.*`, `assets.*`, `*.rate_limited`, `reward_maintenance.*`) are unchanged. A log shipper or alert rule can watch: `http.response_5xx`, `http.request_failed`, `http.slow_request`, `reward.admob_keys_fetch_failed`, `auth.otp.delivery_failed`, `auth.refresh.reuse_detected`, `reward_maintenance.alert`, `reward_maintenance.failed`.
- **Not done:** an external monitoring/alerting service, dashboards, metrics endpoint, log shipping (deployment concern), delivery of alerts to people. No migration; no API contract changed. CI fixes: the serializers return the exact shapes Fastify 5's logger options require (`LoggedReq`/`LoggedRes`/`LoggedErr`, each with the `[key: string]: unknown` index signature Fastify's types demand; no casts); the real-server test registers its routes before the first `inject` (Fastify refuses routes once ready) and drives a 4xx through the error handler (an unknown path is answered by the not-found handler, which never logs `http.request_rejected`). Tests: `test/unit/logging.test.ts` (masking, serializers, failure paths, static guards; the pino and real-server cases run only where `fastify` is installed, i.e. CI).

### Phase 11.8 closure: verification record (Phase 11.8-I)
- **Policies confirmed unchanged (by code and tests, no edits):** website member-car submissions are always stored `pending` (`member-cars/repository.ts` insert) and need administrator approval; no website ads exist and the frontend has no reference to the reward routes; an Android member's ad is published only inside the transaction that consumes a grant the SERVER verified (`rewards/service.ts`; one compare-and-swap, `reward_publish` audit row, rollback on any failure); showroom-owner account activation still needs administrator approval; the OTP provider is still the unconfigured one and no WhatsApp/SMS integration exists; the reward verifier is unconfigured unless `REWARD_PROVIDER=admob`.
- **Still open by decision (not blockers of 11.8):** frontend server-mode wiring of the reward flow; real OTP delivery over WhatsApp/SMS, delivery log and send budget; limits shared across instances; an external monitoring service; website-ad approval path and re-submission of a rejected ad; Android UI/SDK (11.10); final server/browser verification (11.7.2-L, deferred to the end of the project).
- **Deployment prerequisites (unchanged):** a real AdMob ad unit and `REWARD_PROVIDER=admob` + `ADMOB_SSV_AD_UNIT_ID`; a public HTTPS URL for the SSV callback; egress to `gstatic.com`; `AUTH_TRUSTED_PROXIES` behind a proxy; a scheduler (cron) for `npm run rewards:maintenance -- --execute` and a log shipper/alert rule on the events listed under 11.8-H.

### Phase 11.8 checklist (marks only what is done)
- [x] **Step 1:** reward service and repository, atomic one-time consumption, direct publication of a regular member's ad after server-side verification and consumption (CI confirmed).
- [x] **11.8-B:** reward API routes (CI confirmed).
- [x] **11.8-C:** AdMob server-side verification for Android rewarded ads (CI confirmed). The Android UI and the AdMob SDK are Phase 11.10, not part of it.
- [x] **11.8-D:** reward-to-publish integration tests (tests only; CI confirmed).
- [x] **11.8-E:** rate limits and abuse protection for reward creation, consumption and the AdMob callback (CI confirmed).
- [x] **11.8-G:** background maintenance of reward grants (expire + purge, operator-run, dry-run by default) with alert signals and an audit row per run (CI confirmed).
- [x] **11.8-H:** operational logs and monitoring: log masking, operational events, audit/diagnostic separation (CI confirmed after two type/test fixes).
- [x] **11.8-I:** final verification and closure of Phase 11.8 (no code change; CI confirmed). **Phase 11.8 is complete.**
- [ ] Frontend server-mode wiring of the reward flow (not started).
- [ ] Real OTP delivery over WhatsApp/SMS, delivery log and send budget (not started).
- [ ] Send limits shared across instances (not started).
- [ ] Delivery of alerts/notifications to people (e-mail, WhatsApp, SMS) and a scheduler: not started; 11.8-G produces alert SIGNALS only (report + log) and is run by an operator or an external scheduler.
- [ ] An external monitoring/alerting service and dashboards (not started; 11.8-H only makes the logs safe and alertable).

### Reward API routes (Phase 11.8-B)
- `POST /v1/me/rewards` (Bearer, no body) -> `201 {reward:{id, expiresAt}}`.
- `POST /v1/me/rewards/:id/consume` (Bearer, JSON `{carId}`) -> `200 {reward:{id, carId, status:'consumed', published}}`.
- **Identity** comes only from the verified access token (re-read from the database, then the account-state rules). A pending showroom owner or any account without an actor gets 403; showroom-owner ACCOUNT activation is untouched.
- **No route verifies.** The routes file is typed with `Pick<RewardApi, 'requestReward' | 'consumeReward'>` and never mentions `verifyReward`; there is no endpoint that marks a grant verified or accepts a transaction id. The consume body accepts exactly one field, `carId`: any other field (`status`, `userId`, `transactionId`, a success flag) is a `400 validation_failed` with `unknown_field`, never ignored. The request route accepts no body.
- **Errors:** 401 / 403; 404 uniform for an unknown, malformed or someone else's grant or ad; 400 field names and codes only; 409 `invalid_state` / `expired` / `replayed`; 415 non-JSON; 429 too many open requests (service) or HTTP limit (`REWARD_RATE_LIMITS`: request 10 per hour, consume 30 per 10 minutes per address and instance: PROPOSED); 503 `unavailable` (verification not configured).
- **Safe failure:** a database failure while consuming is not mapped to success (the global handler answers 5xx); the transaction rolled back, so the grant stays `verified`, the ad `pending`, and a retry works once.
- **Not changed:** schema and migrations, moderation, frontend, OTP/messaging, jobs, monitoring. Tests: `test/unit/rewards-http.test.ts` (28, no Fastify) and the CI-only `test/integration/rewards-http.integration.test.ts` (real server and PostgreSQL 16).
### AdMob server-side verification (Phase 11.8-C)
- **Files:** `src/rewards/admob.ts` (parser, key store, verifier, callback handler, configuration), `src/rewards/admob-routes.ts` (the callback route). No migration, no change to the service, the member routes or moderation.
- **Route:** `GET /v1/rewards/admob/ssv` (called by Google, no bearer token) -> `200 {status:'ok'}`, `400 rejected` (one uniform answer for every untrustworthy callback), `503 unavailable` (Google's keys cannot be loaded: Google retries). A database failure propagates as 5xx so Google retries. It only moves a grant to `verified`; it never consumes a grant and never publishes an ad.
- **Protocol (Google's AdMob SSV documentation):** the query ends with `signature` then `key_id`; the signature is ECDSA P-256 over SHA-256 of the query string before `&signature=`, exactly as received (the RAW query string is used, nothing re-encoded), DER, web-safe base64. Keys come from Google's published key list over HTTPS (host-checked, 5 s timeout, 64 KB cap), are cached at most 6 hours (Google allows 24), a key older than 24 hours is never used, an unknown key id causes at most one refetch per minute, and any failure to load keys fails closed.
- **Checks on top of the signature:** `ad_unit` must be OUR ad unit (another AdMob account also produces valid signatures); `user_id` must equal the user the SERVER holds for the grant; `custom_data` must equal the grant id; `transaction_id` is the receipt (unique per provider in the database, so a replay or a second grant cannot reuse it); `timestamp` must be recent (1 hour) and not in the future (5 minutes). Nothing the app reports ("ad completed", flags, ids) is evidence: the only input is Google's own callback. Reverse-DNS checking of the caller is not done: the signature is the proof.
- **Configuration:** `REWARD_PROVIDER=admob` and `ADMOB_SSV_AD_UNIT_ID=<numeric ad unit id>`. If `REWARD_PROVIDER` is set and invalid the process stops with the problems listed (no values). Unset = provider off (unchanged production default). The server needs outbound HTTPS to `gstatic.com`.
- **Android / website:** the only accepted evidence is a callback for the Android ad unit configured above, so there is no web path to a verified reward and no website ads exist. Website submissions (`POST /v1/me/cars`) are still stored `pending` for administrator approval, and member-car creation does not know about rewards. The server cannot tell which client created an ad: a member who really earned a verified Android reward may consume it for any of their own pending ads.
- **Flow for the Android app (Phase 11.10):** set `ServerSideVerificationOptions` user id = the account's id and custom data = the grant id from `POST /v1/me/rewards`; after the SDK reports the reward, call `POST /v1/me/rewards/:id/consume`. Google's callback can arrive after the app's own event, so consume answers `409 invalid_state` until the callback has been verified: the app must retry for a short time. The app's own event is never proof.
- **Not done:** the Android UI and AdMob SDK (11.10), the web decision, the frontend wiring, alert delivery to people.
- **Tests:** `test/unit/rewards-admob.test.ts` (27: signatures made with a generated key, no network) and the CI-only `test/integration/rewards-admob.integration.test.ts`.

- **11.8-D tests (no source change):** `test/unit/rewards-publish-flow.test.ts` (13, in-memory store) and the CI-only `test/integration/rewards-publish-flow.integration.test.ts` (real server, PostgreSQL 16, application role) cover the Android lifecycle with its audit trail and version bump, stale/future/expired-grant callbacks, mismatched ad unit / user / grant data across accounts, spent transaction ids, concurrent repeats of Google's callback, failure safety (a database error injected INSIDE the real transaction after the verify / consume / publish / audit statements rolls everything back, and a healthy retry then publishes once) and the website boundary. Shared helper: `test/helpers/admob-sign.ts` (test only). Observation, not changed here: moderation approval still requires a consumed grant bound to the ad (`409 reward_required`), so a website ad has no approval path until that gate is revisited.

### Rate limits and abuse protection (Phase 11.8-E)
Gaps found and what changed (everything else was already sound and is only tested):
- **Creation had no cap over time.** `maxOpen` bounds simultaneous `requested` rows only; rows that expired or were verified stopped counting, so an account could keep opening grants. Now `REWARD_POLICY.maxPerHour` (PROPOSED: 20) counts the account's rows of ANY status created in the last hour (database clock, `reward_user_idx`, no migration). It runs in the same transaction, under the same per-account advisory lock, as the open-request check, so it holds across instances and under concurrency. Over the cap: `429 rate_limited`, the existing error.
- **The member routes were limited by address only.** An address is a poor key (mobile carriers put many people behind one) and a single account could rotate addresses. Now there are two layers: a coarse per-address guard BEFORE authentication (`REWARD_RATE_LIMITS`, relaxed to 60 requests per hour and 120 consumes per 10 minutes) and a precise per-ACCOUNT limit AFTER authentication (`REWARD_USER_RATE_LIMITS`: 20 requests per hour, 20 consumes per 10 minutes; PROPOSED). The account key is the verified token's account id: an id in a body, query, params or header changes nothing. Both are in-process (per instance); the creation cap above is the cross-instance guarantee.
- **The SSV callback was limited by address for everyone, and did a database read before checking the signature.** Now the signature is checked FIRST (no database access for garbage or forgeries). Untrusted callbacks (malformed, unknown key, bad signature) are counted per address (`ADMOB_UNTRUSTED_RATE_LIMIT`: 60 per 10 minutes). Genuinely signed callbacks cannot be forged, so they are NEVER counted against an address: Google's retries and callers that share addresses are not punished and a flood of garbage cannot starve them. They are limited per GRANT (the signed `custom_data`, `ADMOB_GRANT_RATE_LIMIT`: 30 per 10 minutes), so Google's few retries always get 200 while a captured callback replayed in a loop stops with 429. A key outage (503) is never counted as abuse. The 429 answers carry `Retry-After`.
- **Forwarded headers:** unchanged and now tested for the reward routes. `request.ip` is the socket address unless the server is started with an explicit trusted-proxy list (`AUTH_TRUSTED_PROXIES`); no code reads `X-Forwarded-For` itself. Without a list, a deployment behind a proxy sees one address for everyone; set the list.
- **Already guaranteed, now tested under concurrency:** repeated or concurrent requests cannot create extra grants beyond the caps, reuse a consumed grant, or publish a car twice (compare-and-swaps, `car_id` unique, one audit row); a hijacked or foreign grant cannot publish another account's ad.
- **Not changed:** the website policy (website submissions stay `pending` for administrator approval; no website ads), schema and migrations, API contracts (new 429 codes only), moderation.
- **Tests:** unit additions in `rewards.test.ts`, `rewards-http.test.ts` and `rewards-admob.test.ts`; `test/unit/rewards-abuse-server.test.ts` (real server, forwarded headers; needs fastify, skipped visibly without it) and the CI-only `test/integration/rewards-abuse.integration.test.ts` (real PostgreSQL, two connections).
- **Tests of the core (Step 1):** `test/unit/rewards.test.ts` (fake store `test/helpers/fake-rewards.ts` and a fake verifier, tests only) and the CI-only `test/integration/rewards.integration.test.ts` (PostgreSQL 16, application role, real concurrency, and the moderation gate end to end).

## Subscriptions (Phase 11.9)
Status: **11.9-A (baseline review, report only) done; 11.9-B (plans) done, CI confirmed; 11.9-C (editable prices, admin API) done, CI confirmed; 11.9-D (manual subscription activation / renewal and payment recording, admin API) done, CI confirmed (run #81); 11.9-E (subscription expiry processing, operator-run) done, CI confirmed (run #82); 11.9-F (free-plan car limit and paid entitlements, migration 0015) implemented, awaiting GitHub CI.** Nothing else of 11.9 exists: no entitlement enforcement, no price-editing UI, no payment gateway (deferred until explicitly approved).
- **11.9-B, plans:** forward-only migration `database/migrations/0014_subscription_plan_durations.sql` (wrapper `db/migrations/0014_subscription_plan_durations.js`, rollback `db/down/0014_subscription_plan_durations.down.sql`; no earlier migration was changed). It adds `subscription_plans.duration_months` (NULL or 3, 6, 12; one plan per duration) and seeds `plan_3m`, `plan_6m`, `plan_12m`: **IQD, initial price 0**, no entitlements, `billing_interval` NULL (month/year cannot express 3 or 6 months). The `free` plan is untouched. The old rule "a priced plan needs a billing interval" is widened (a duration also satisfies it); it never rejects a row that was valid before. Existing plans, subscriptions and payments are preserved.
- **Open before the plans are used:** the three plans are `is_active = true` at price 0. Nothing reads them yet; the active flag must be set deliberately and the prices set through 11.9-C before any later step exposes them. Which entitlements each plan grants, and what happens on expiry, are undecided.
- **Tests:** `test/unit/subscription-plans-migration.test.ts` (the SQL, the rollback, checksums), the CI-only `test/integration/subscription-plans.integration.test.ts` (PostgreSQL 16, application role), and the migration-asset counts in `test/unit/migrate-assets.test.ts` (13 -> 14 files, one more index).
- **11.9-C, editable prices (`src/subscription-plans/`):** `GET /v1/admin/subscription-plans` (the three plans, so an administrator can see the current prices) and `PUT /v1/admin/subscription-plans/:code/price` with `{"price": <whole IQD, 0..9,999,999,999,999>}`; `:code` is `plan_3m`, `plan_6m` or `plan_12m`. Administrators only (new `subscription_plan` resource: read and update); everyone else, an unknown code and the `free` plan answer 404 before the body is parsed; invalid input is 400 with field names only (a `currency` field is refused: the currency stays IQD); JSON only (415); rate limited. Only `subscription_plans.price` is written. In ONE transaction the plan row is locked, the price updated and one audit row `subscription_plan.price_update` written through the single audit writer (actor, plan id as the entity, `{oldPrice, newPrice}`, request id, the database timestamp). Setting the price a plan already has changes nothing and writes no audit row (`changed: false`). No migration was needed (0014's grants and constraints already cover it). No UI, no subscription logic, no payment.
- **11.9-C tests:** `test/unit/subscription-plans.test.ts` (policy, validation, service with an in-memory repository incl. audit rows, HTTP handlers, source guards) and the CI-only `test/integration/subscription-plans-prices.integration.test.ts` (PostgreSQL 16, application role: update, audit row, unchanged price, only-price-moves, invalid/unknown/unauthorized, rollback with the audit, concurrent changes).
- **11.9-D, manual activation / renewal (`src/subscriptions/`):** `POST /v1/admin/subscriptions` with `{showroomId, planCode (plan_3m|plan_6m|plan_12m), method (cash|bank_transfer|mobile_wallet|other), reference, amount (whole IQD >= 0), paidAt (ISO date or date-time, not in the future)}` -> 201 `{outcome: activated|renewed|renewed_after_expiry, subscription, payment}`; `GET /v1/admin/showrooms/:id/subscriptions` (read-only history with payments). Administrators only (new `subscription` resource); everyone else, an unknown showroom or plan answer 404 before the body is parsed; invalid input is 400 with field names only (no `currency` field exists: IQD); JSON only (415); rate limited. **Dates** (the period starts when the administrator records it, never at `paidAt`): no live subscription -> start now, end = now + plan months; live and not yet expired -> **extend from the current end** (same plan only, another plan is 409 `plan_mismatch`); live but its end has passed -> the old row is closed (`expired`) and a NEW row starts now. Months are UTC calendar months, clamped to the month's last day. **Duplicates:** a payment is `(provider 'manual', provider_ref '<method>:<reference>')`; the same one again is 409 `duplicate_payment` (checked first, and `UNIQUE (provider, provider_ref)` backstops a race; the same reference by another showroom is the same payment). **Atomic:** under a lock on the showroom row the subscription change, the payment row and the audit rows are written in ONE transaction (any failure rolls back all). **History:** payments are only ever inserted; a subscription row is only extended or closed, and after a lapse a new row is added; audit rows `subscription.activate` / `subscription.renew` / `subscription.close_lapsed` hold the actor, the subscription as the entity and numbers only (ids, plan, months, amount, payment id, old and new period end as epoch seconds). The amount is RECORDED as received and need not equal the plan price. No migration was needed. **Not built (later steps):** expiry processing, entitlement enforcement / hiding cars beyond the free plan's 3, any UI, any gateway or automatic billing, OTP, WhatsApp/SMS.
- **11.9-D tests:** `test/unit/subscriptions.test.ts` (policy, validation, date rules, service with an in-memory transactional repository: activation, renewal, lapse, duplicates, rollback, audit; HTTP handlers; source guards) and the CI-only `test/integration/subscriptions.integration.test.ts` (PostgreSQL 16, application role: activation, renewal from the current end, renewal after expiry, plan mismatch, duplicate payments sequential and concurrent, serialized concurrent payments, rollback on payment/audit failure, authorization and validation, no DELETE for the app role, month arithmetic equal to PostgreSQL's).
- **11.9-E, expiry processing (`src/subscriptions/expiry.ts`, `expiry-repository.ts`, `scripts/subscriptions-expire.ts`):** an OPERATOR / external scheduler runs `npm run subscriptions:expire` (dry run, counts only) or `npm run subscriptions:expire -- --execute [--batch-size=N (1-1000, default 200)] [--max-batches=N (1-100, default 10)]`; the server never starts it (no route, no timer, no queue). Every live subscription (`trialing`, `active`, `past_due`) whose paid period has ended becomes `expired`, and each change leaves ONE audit row `subscription.expire` (actor = the system, numbers only: showroom, plan, period end). **Boundary (one rule everywhere, in UTC, on the database clock):** a subscription is in force while `current_period_end > now()` (the `entitlements_for_showroom` function of migration 0011), so one that ends exactly now is expired, exactly as the manual renewal of 11.9-D treats it (a renewal then starts a new period from now). **Idempotent:** the batch is a single transaction that locks the rows (`FOR UPDATE SKIP LOCKED`), changes status by a compare-and-swap that re-checks status and end date, and audits only the rows it really changed, so a second or concurrent run (and a manual grant happening at the same time) cannot create a second transition, audit row, payment or subscription. **History:** nothing is inserted into or deleted from `subscriptions` or `payments`; only `status` moves to `expired`. Exit codes 0 done / 1 database failure / 64 invalid arguments / 78 invalid configuration; a bound reached before the work is done raises the `backlog_remaining` signal (run again). No migration was needed. **Not built (later steps):** enforcing the free plan's 3-car limit, hiding excess cars, any UI, gateway, OTP, WhatsApp/SMS.
- **11.9-E tests:** `test/unit/subscription-expiry.test.ts` (options, boundary, every status, dry run, one audit row each, idempotence, bounded batches, failure codes, script arguments, SQL and source guards) and the CI-only `test/integration/subscription-expiry.integration.test.ts` (PostgreSQL 16, application role: exact boundary at a fixed instant, all statuses, audit rows with the system actor, repeated and concurrent runs, a run beside a manual renewal, no insert/delete, plans untouched).
- **11.9-F, entitlements and the free-plan car limit (migration `0015_free_plan_car_limit.sql`, `src/showroom-cars/`):** the rule is the existing entitlement rule of 0011: a showroom with a live subscription in force (`trialing`/`active`/`past_due` and `current_period_end > now()`) is on its paid plan, otherwise on the free plan. **Free plan: at most 3 `available` showroom cars per showroom; paid plan in force: unlimited.** Sold cars and member ads are not counted and their visibility is unchanged. *Publishing* (backend, every path): creating a car, the dealer's `sold -> available` and the administrator's `sold -> available` lock the showroom row (`FOR NO KEY UPDATE`), re-read the limit (`showroom_active_car_limit`, `NULL` = unlimited) and the count in a fresh statement, and answer **409 `plan_limit_reached`** at the limit, so concurrent requests cannot exceed it; editing, marking sold and deleting are never limited. *Visibility* (database): the `public_cars` view (same columns) shows, for a showroom without a paid subscription in force, only its **3 oldest available cars (created_at, then id)**; this caps every public read (catalog, detail, favorites, image delivery) and also rows written around the service. After a subscription ends the excess is hidden from the public only (no row, status, image or decision is changed or deleted). **The owner still sees and manages ALL own cars:** the private dealer routes (`GET /v1/dealer/cars`, `GET/PATCH/DELETE /v1/dealer/cars/:id`, the car images routes, the owner's own asset bytes) read the `cars` / `assets` tables scoped to the owner's showroom, never `public_cars`, so hidden cars appear there with their real status; nobody else can read them (another dealer gets 404, the public catalog, favorites and public image delivery do not return them); when a paid subscription is in force again they are public again, and owner/moderation decisions (sold, deleted, suspended showroom) stay as they were. **Migration 0015** was necessary because visibility is decided by the `public_cars` view: it adds the function and re-creates the view with the extra condition (`CREATE OR REPLACE`, same columns); no earlier migration and no row is changed; hand-written rollback restores the 0012 view verbatim. Consequence for the staging seed (no subscriptions): 66 public cars instead of 115 (the 11.4 permissions check was updated accordingly).
- **11.9-F tests:** `test/unit/showroom-car-plan-limit.test.ts` (limit on create / dealer / admin paths, sold and deleted not counted, editing never limited, concurrent creates, HTTP 409, the lock, migration 0015 text and rollback, owner vs public reads), the CI-only `test/integration/plan-car-limit-owner-visibility.integration.test.ts` (after expiry: public catalog/detail/images show only the eligible 3, the owner lists, reads, edits and manages images of every own car, another dealer gets 404, moderation unchanged, renewal restores) and the CI-only `test/integration/plan-car-limit.integration.test.ts` (PostgreSQL 16, application role: function, free limit, paid unlimited, expiry downgrade with deterministic selection, renewal restoration preserving owner/moderation decisions, bypass attempts, concurrent creates and status changes over two pools, publishing while a subscription ends, member ads unaffected).

### Phase 11.9 checklist (marks only what is done)
- [x] **11.9-A:** subscription baseline review (report only, no files changed).
- [x] **11.9-B:** subscription plans for 3, 6 and 12 months in IQD at price 0 (migration 0014). GitHub CI confirmed.
- [x] **11.9-C:** editable plan prices, admin API only (no migration, no UI). GitHub CI confirmed.
- [x] **11.9-D:** manual subscription activation and renewal with payment recording, admin API only (no migration, no UI). GitHub CI confirmed (run #81, with the one-line typing fix).
- [x] **11.9-E:** subscription expiry processing, operator-run `npm run subscriptions:expire` (no migration, no route, no UI). GitHub CI confirmed (run #82).
- [ ] **11.9-F:** entitlement enforcement: the free plan's limit of 3 available cars per showroom, unlimited under a paid subscription in force, excess hidden (never deleted) after expiry and shown again on renewal (migration 0015, no UI). Implemented; **awaiting GitHub CI** (not checked until CI passes).
- [ ] Payment gateway (deferred until explicitly approved).

// Phase 11.9-C: the administrators' subscription plan prices. Unit level: policy, validation, the service with an in-memory repository
// (including the audit row), the HTTP handlers and source guards. The real SQL runs in test/integration/subscription-plans-prices.integration.test.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import { assertAuditSafe } from '../../src/auth/repository.ts';
import { AuthzError, can, subscriptionPlanResource } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { registerSubscriptionPlansRoutes, SUBSCRIPTION_PLANS_RATE_LIMITS, toSubscriptionPlansHttp } from '../../src/subscription-plans/routes.ts';
import type { PlanRow, PriceChange, SubscriptionPlansRepository } from '../../src/subscription-plans/repository.ts';
import { createSubscriptionPlansService, MAX_PLAN_PRICE, parsePriceBody, SubscriptionPlansError } from '../../src/subscription-plans/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const ADMIN: Actor = Object.freeze({ id: '1', role: 'admin' });
const MEMBER: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ROOT = join(import.meta.dirname, '..', '..');
const src = (rel: string) => readFileSync(join(ROOT, rel), 'utf8');
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const isValidation = (e: unknown) => e instanceof SubscriptionPlansError && e.code === 'validation_failed';

/** In-memory stand-in for the repository: same contract (unknown code = not_found, same price = unchanged, audit only on change). */
function fakeRepo() {
  const plans: PlanRow[] = [3, 6, 12].map((m, i) => ({ id: String(i + 4), code: `plan_${m}m`, name: `اشتراك ${m}`, durationMonths: m, price: 0, currency: 'IQD', isActive: true, updatedAt: new Date('2026-10-14T00:00:00Z') }));
  const audits: AuditEvent[] = [];
  const calls: string[] = [];
  const repo: SubscriptionPlansRepository = {
    async list() { calls.push('list'); return plans.map((p) => ({ ...p })); },
    async setPrice({ code, price, audit }): Promise<PriceChange> {
      calls.push('setPrice');
      const p = plans.find((x) => x.code === code);
      if (!p) return { kind: 'not_found' };
      if (p.price === price) return { kind: 'unchanged', plan: { ...p } };
      const old = p.price;
      p.price = price;
      audits.push(audit(old, p.id));
      return { kind: 'changed', plan: { ...p }, oldPrice: old };
    },
  };
  return { repo, plans, audits, calls };
}
function world() {
  const f = fakeRepo();
  return { f, svc: createSubscriptionPlansService({ repo: f.repo }) };
}

describe('subscription plans: policy', () => {
  it('only an administrator may read or update; nobody else, and no other action', () => {
    const r = subscriptionPlanResource();
    for (const a of ['read', 'update'] as const) {
      assert.equal(can(ADMIN, a, r), true);
      for (const who of [MEMBER, DEALER, null]) assert.equal(can(who, a, r), false);
    }
    for (const a of ['delete', 'moderate'] as const) assert.equal(can(ADMIN, a, r), false);
  });
});

describe('subscription plans: price validation', () => {
  it('accepts whole IQD amounts from 0 to the maximum', () => {
    for (const price of [0, 1, 25000, 150000, MAX_PLAN_PRICE]) assert.deepEqual(parsePriceBody({ price }), { ok: true, value: price });
  });
  it('rejects negative, fractional, huge, non-finite and non-number prices and a missing price', () => {
    const bad: Array<[unknown, string]> = [[-1, 'invalid_format'], [0.5, 'invalid_format'], [MAX_PLAN_PRICE + 1, 'invalid_format'], [Number.MAX_SAFE_INTEGER + 2, 'invalid_format'],
      [Number.NaN, 'invalid_type'], [Infinity, 'invalid_type'], ['25000', 'invalid_type'], [null, 'invalid_type'], [true, 'invalid_type'], [[25000], 'invalid_type'], [{}, 'invalid_type'], [undefined, 'required']];
    for (const [price, code] of bad) assert.deepEqual(parsePriceBody({ price }), { ok: false, errors: [{ field: 'price', code }] }, String(price));
  });
  it('rejects a body that is not an object and any other field (a currency cannot be sent)', () => {
    for (const body of [undefined, null, 5, 'x', [1]]) assert.deepEqual(parsePriceBody(body), { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] });
    assert.deepEqual(parsePriceBody({ price: 10, currency: 'USD' }), { ok: false, errors: [{ field: 'currency', code: 'unknown_field' }] });
    assert.deepEqual(parsePriceBody({ price: 10, 'bad key!': 1 }), { ok: false, errors: [{ field: 'unknown', code: 'unknown_field' }] });
  });
});

describe('subscription plans: service', () => {
  it('lists the three plans for an administrator, with IQD and no internal ids', async () => {
    const { svc } = world();
    const { plans } = await svc.listPlans(ADMIN);
    assert.deepEqual(plans.map((p) => [p.code, p.durationMonths, p.price, p.currency]), [['plan_3m', 3, 0, 'IQD'], ['plan_6m', 6, 0, 'IQD'], ['plan_12m', 12, 0, 'IQD']]);
    assert.ok(plans.every((p) => !('id' in p)));
  });

  it('updates the price of each plan and writes exactly one audit row per change (actor, plan, old, new)', async () => {
    const { svc, f } = world();
    const a = await svc.setPrice(ADMIN, 'plan_3m', { price: 30000 }, { requestId: 'req-1' });
    assert.equal(a.changed, true); assert.equal(a.plan.price, 30000); assert.equal(a.plan.currency, 'IQD');
    await svc.setPrice(ADMIN, 'plan_3m', { price: 45000 });
    await svc.setPrice(ADMIN, 'plan_12m', { price: 100000 });
    assert.equal(f.audits.length, 3);
    assert.deepEqual(f.audits[0], { action: 'subscription_plan.price_update', actorUserId: '1', actorRole: 'admin', entityType: 'subscription_plan', entityId: '4', afterData: { oldPrice: 0, newPrice: 30000 }, requestId: 'req-1' });
    assert.deepEqual(f.audits[1]!.afterData, { oldPrice: 30000, newPrice: 45000 });
    assert.equal(f.audits[2]!.entityId, '6');
    for (const e of f.audits) assertAuditSafe(e); // numbers only, no forbidden key
    assert.deepEqual((await svc.listPlans(ADMIN)).plans.map((p) => p.price), [45000, 0, 100000]);
  });

  it('the same price changes nothing and writes no audit row; zero is a valid price', async () => {
    const { svc, f } = world();
    const same = await svc.setPrice(ADMIN, 'plan_6m', { price: 0 });
    assert.deepEqual([same.changed, same.plan.price], [false, 0]);
    await svc.setPrice(ADMIN, 'plan_6m', { price: 5000 });
    await svc.setPrice(ADMIN, 'plan_6m', { price: 0 });
    assert.equal(f.audits.length, 2);
  });

  it('invalid prices are refused before anything is written', async () => {
    const { svc, f } = world();
    for (const body of [{ price: -5 }, { price: 1.5 }, { price: '100' }, {}, { price: 1, currency: 'USD' }, null]) {
      await assert.rejects(() => svc.setPrice(ADMIN, 'plan_3m', body), isValidation);
    }
    assert.deepEqual(f.calls, []); assert.deepEqual(f.audits, []);
  });

  it('an unknown or malformed plan code, the free plan and a missing row are all 404 (identical)', async () => {
    const { svc, f } = world();
    for (const code of ['free', 'plan_1m', 'plan_3m ', 'PLAN_3M', '', undefined, 3, null, '../x']) await assert.rejects(() => svc.setPrice(ADMIN, code, { price: 1 }), isNotFound);
    f.plans.length = 0; // the code is valid but the row is gone
    await assert.rejects(() => svc.setPrice(ADMIN, 'plan_3m', { price: 1 }), isNotFound);
    assert.deepEqual(f.audits, []);
  });

  it('a member, a dealer and no actor are refused (404) before the code or body is looked at; nothing is read or written', async () => {
    const { svc, f } = world();
    for (const who of [MEMBER, DEALER, null]) {
      await assert.rejects(() => svc.listPlans(who), isNotFound);
      await assert.rejects(() => svc.setPrice(who, 'plan_3m', { price: 1 }), isNotFound);
      await assert.rejects(() => svc.setPrice(who, 'bogus', 'not an object'), isNotFound);
    }
    assert.deepEqual(f.calls, []); assert.deepEqual(f.audits, []);
  });
});

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };

function http(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: 'unit-test-access-secret-0123456789abcdef-XYZ', logger: recordingLogger().logger, now: clock.now });
  const f = fakeRepo();
  const subscriptionPlans = createSubscriptionPlansService({ repo: f.repo });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  registerSubscriptionPlansRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, subscriptionPlans, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  let n = 0;
  const phone = () => `0771${String(2000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const sent: Sent = { headers: {} };
    const reply = { code: (c: number) => ((sent.status = c), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  async function account(role: 'member' | 'dealer' | 'admin') {
    const r = role === 'dealer' ? await auth.registerDealer({ name: 'تاجر', phone: phone(), password: 'Corr3ct-Horse-Battery' }) : await auth.register({ name: 'حساب', phone: phone(), password: 'Corr3ct-Horse-Battery' });
    const u = db.users().find((x) => x.id === r.user.id)!;
    if (role === 'dealer') u.status = 'active';
    if (role === 'admin') u.role = 'admin';
    return { authorization: `Bearer ${r.session.accessToken}` };
  }
  return { routes, call, account, f };
}
const PRICE = '/v1/admin/subscription-plans/:code/price';
const LIST = '/v1/admin/subscription-plans';

describe('subscription plans: HTTP', () => {
  it('registers exactly one GET and one PUT, each rate limited when a limiter is supplied; the PUT has a small body limit', () => {
    const { routes } = http(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`GET ${LIST}`, `PUT ${PRICE}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    assert.equal(routes.find((r) => r.method === 'PUT')!.opts!.bodyLimit, 1024);
  });

  it('401 without or with a bad token; 404 for a member and a dealer (same as an unknown plan)', async () => {
    const s = http();
    for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
      const r = await s.call('PUT', PRICE, { headers, params: { code: 'plan_3m' }, body: { price: 1 } });
      assert.equal(r.status, 401); assert.equal(r.headers['www-authenticate'], 'Bearer');
      assert.equal((await s.call('GET', LIST, { headers })).status, 401);
    }
    const unknown = await s.call('PUT', PRICE, { headers: await s.account('admin'), params: { code: 'free' }, body: { price: 1 } });
    assert.equal(unknown.status, 404);
    for (const role of ['member', 'dealer'] as const) {
      const h = await s.account(role);
      const w = await s.call('PUT', PRICE, { headers: h, params: { code: 'plan_3m' }, body: { price: 1 } });
      assert.equal(w.status, 404); assert.deepEqual(w.body, unknown.body);
      assert.equal((await s.call('GET', LIST, { headers: h })).status, 404);
    }
    assert.deepEqual(s.f.audits, []); assert.deepEqual(s.f.plans.map((p) => p.price), [0, 0, 0]);
  });

  it('an administrator reads the plans and changes a price (200 {plan, changed}) and the audit row names the actor and request', async () => {
    const s = http();
    const h = await s.account('admin');
    const list = await s.call('GET', LIST, { headers: h });
    assert.equal(list.status, 200); assert.equal((list.body as { plans: unknown[] }).plans.length, 3);
    const r = await s.call('PUT', PRICE, { headers: h, params: { code: 'plan_6m' }, body: { price: 55000 } });
    assert.equal(r.status, 200);
    assert.deepEqual(Object.keys(r.body as object).sort(), ['changed', 'plan']);
    assert.deepEqual((r.body as { plan: { code: string; price: number; currency: string } }).plan, { ...(r.body as { plan: object }).plan, code: 'plan_6m', price: 55000, currency: 'IQD' });
    assert.equal(s.f.audits.length, 1);
    assert.equal(s.f.audits[0]!.requestId, 'req-abcdef01'); assert.equal(s.f.audits[0]!.actorRole, 'admin');
  });

  it('answers 400 with field names only for invalid input, 404 for a missing plan, 415 for a non-JSON body', async () => {
    const s = http();
    const h = await s.account('admin');
    const bad = await s.call('PUT', PRICE, { headers: h, params: { code: 'plan_3m' }, body: { price: -1, currency: 'USD' } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as { error: { fields: unknown } }).error.fields, [{ field: 'currency', code: 'unknown_field' }, { field: 'price', code: 'invalid_format' }]);
    s.f.plans.length = 0;
    assert.equal((await s.call('PUT', PRICE, { headers: h, params: { code: 'plan_3m' }, body: { price: 1 } })).status, 404);
    const text = await s.call('PUT', PRICE, { headers: { ...h, 'content-type': 'text/plain' }, params: { code: 'plan_3m' }, body: '{"price":1}' });
    assert.equal(text.status, 415);
    assert.deepEqual(s.f.audits, []);
  });

  it('writes have a budget per address (429 with Retry-After)', async () => {
    const s = http(true);
    const h = await s.account('admin');
    for (let i = 0; i < SUBSCRIPTION_PLANS_RATE_LIMITS.write.limit; i++) assert.equal((await s.call('PUT', PRICE, { headers: h, params: { code: 'plan_3m' }, body: { price: i } })).status, 200);
    const denied = await s.call('PUT', PRICE, { headers: h, params: { code: 'plan_3m' }, body: { price: 999 } });
    assert.equal(denied.status, 429); assert.ok(Number(denied.headers['retry-after']) > 0);
  });

  it('maps errors: validation 400 with fields, authz 404, anything else not ours', () => {
    assert.equal(toSubscriptionPlansHttp(new SubscriptionPlansError([{ field: 'price', code: 'required' }]))?.status, 400);
    assert.equal(toSubscriptionPlansHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toSubscriptionPlansHttp(new Error('boom')), undefined);
  });
});

describe('subscription plans: SQL and source guards', () => {
  const code = (rel: string) => src(rel).replace(/\/\*[\s\S]*?\*\//g, '').split('\n').map((l) => l.replace(/^\s*\/\/.*$/, '')).join('\n');

  it('the repository changes only the price, of duration plans only, under a row lock, and writes the audit row through the single audit writer', () => {
    const r = code('src/subscription-plans/repository.ts');
    const writes = r.match(/(UPDATE|INSERT\s+INTO|DELETE\s+FROM|TRUNCATE)\s+\w+[^`]*/gi) ?? [];
    assert.equal(writes.length, 1); assert.match(writes[0]!, /^UPDATE subscription_plans SET price = \$2 WHERE id = \$1/);
    assert.doesNotMatch(r, /INSERT\s+INTO\s+audit_logs/i);
    assert.match(r, /createPgAuditRepository\(t\)\.record\(/);
    assert.match(r, /duration_months IS NOT NULL FOR UPDATE/);
    assert.doesNotMatch(r, /SELECT \*/);
    assert.doesNotMatch(r, /currency\s*=|entitlements\s*=|is_active\s*=|duration_months\s*=/);
  });

  it('no subscription is created, renewed, expired or enforced here, and no payment or money-moving code exists', () => {
    for (const f of ['repository', 'service', 'routes']) {
      const t = code(`src/subscription-plans/${f}.ts`);
      assert.doesNotMatch(t, /\bsubscriptions\b|\bpayments\b|entitlements_for_showroom|fetch\(|https?:\/\//i, f);
    }
  });

  it('the module is wired in server.ts and index.ts exactly once', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.subscriptionPlans\) registerSubscriptionPlansRoutes\(/);
    assert.match(code('src/index.ts'), /createSubscriptionPlansService\(\{ repo: createPgSubscriptionPlansRepository\(db\) \}\)/);
  });

  it('nothing else writes subscription_plans (only this repository and the migrations)', () => {
    const files = ['src/auth/repository.ts', 'src/rewards/repository.ts', 'src/admin-users/repository.ts', 'src/assets/integrity-repository.ts'];
    for (const f of files) assert.doesNotMatch(code(f), /(UPDATE|INSERT\s+INTO)\s+subscription_plans/i, f);
  });
});

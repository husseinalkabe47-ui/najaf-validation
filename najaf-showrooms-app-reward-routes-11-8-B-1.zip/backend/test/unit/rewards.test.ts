// Phase 11.8, Step 1: the shared reward backend (backend/src/rewards). Unit level: in-memory store (test/helpers/fake-rewards.ts) and a
// FAKE verifier. The same rules run against a real PostgreSQL 16 in test/integration/rewards.integration.test.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { DbError } from '../../src/errors.ts';
import { createUnconfiguredRewardVerifier } from '../../src/rewards/provider.ts';
import { buildCarHasGrant, buildConsume, buildCountOpen, buildFind, buildFindByTransaction, buildInsertRequest, buildLockOwnCar, buildMarkVerified, buildPublishOwnCar } from '../../src/rewards/repository.ts';
import { REWARD_POLICY, RewardError, createRewardService } from '../../src/rewards/service.ts';
import type { RewardErrorCode } from '../../src/rewards/service.ts';
import { buildHasVerifiedReward } from '../../src/member-cars/moderation.ts';
import { makeFakeRewards, makeFakeVerifier } from '../helpers/fake-rewards.ts';

const T0 = Date.UTC(2026, 0, 10, 12, 0, 0);
const member = (id: string): Actor => ({ id, role: 'member' });
const dealer = (id: string): Actor => ({ id, role: 'dealer' });
const isReward = (code: RewardErrorCode) => (e: unknown) => e instanceof RewardError && e.code === code;
const isForbidden = (e: unknown) => e instanceof AuthzError && e.code === 'forbidden';
const NEVER = '00000000-0000-4000-8000-0000000000ff';

function world(o: { verifier?: ReturnType<typeof makeFakeVerifier>; policy?: { ttlSeconds?: number; maxOpen?: number } } = {}) {
  const clock = { t: T0, now: () => clock.t };
  const fr = makeFakeRewards(clock);
  const verifier = o.verifier ?? makeFakeVerifier();
  const lines: string[] = [];
  const log = (level: string) => (obj: unknown) => void lines.push(JSON.stringify({ level, ...(obj as object) }));
  const logger = { debug: log('debug'), info: log('info'), warn: log('warn'), error: log('error') };
  const svc = createRewardService({ store: fr.store, verifier, logger, ...(o.policy ? { policy: o.policy } : {}) });
  fr.addUser('7');
  fr.addUser('8');
  fr.addCar('100', '7');
  fr.addCar('101', '7');
  fr.addCar('200', '8');
  const evidence = (g: { id: string; userId: string }, tx = `tx-${g.id}`) => ({ grantId: g.id, userId: g.userId, tx });
  /** A request that went through the whole life up to 'verified'. */
  async function verified(userId = '7') {
    const r = await svc.requestReward(member(userId));
    const g = fr.grants().find((x) => x.id === r.id)!;
    await svc.verifyReward(g.id, evidence(g));
    return fr.grants().find((x) => x.id === g.id)!;
  }
  return { clock, fr, svc, verifier, lines, evidence, verified };
}

describe('the production verifier is unconfigured and rejects by default', () => {
  it('createUnconfiguredRewardVerifier is configured:false and rejects any evidence', async () => {
    const v = createUnconfiguredRewardVerifier();
    assert.equal(v.configured, false);
    assert.deepEqual(await v.verify({ grantId: NEVER, userId: '7', evidence: { anything: true } }), { ok: false });
  });

  it('with it, no reward request is opened and no verification can change a grant', async () => {
    const clock = { now: () => T0 };
    const fr = makeFakeRewards(clock);
    fr.addUser('7');
    const svc = createRewardService({ store: fr.store, verifier: createUnconfiguredRewardVerifier() });
    await assert.rejects(svc.requestReward(member('7')), isReward('unavailable'));
    assert.equal(fr.grants().length, 0);
    const g = fr.seed({ userId: '7', provider: 'unconfigured' });
    await assert.rejects(svc.verifyReward(g.id, { tx: 'x', grantId: g.id, userId: '7' }), isReward('unavailable'));
    assert.equal(fr.grants()[0]!.status, 'requested');
    assert.equal(fr.grants()[0]!.ssvTransactionId, null);
  });
});

describe('requestReward', () => {
  it('opens an unbound, short-lived, unverified grant for an active account', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    assert.match(r.id, /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
    assert.equal(r.expiresAt, new Date(T0 + REWARD_POLICY.ttlSeconds * 1000).toISOString());
    assert.deepEqual(Object.keys(r).sort(), ['expiresAt', 'id']);
    const g = w.fr.grants()[0]!;
    assert.deepEqual([g.userId, g.provider, g.status, g.carId, g.ssvTransactionId, g.verifiedAt, g.consumedAt], ['7', 'fake', 'requested', null, null, null, null]);
  });

  it('a guest, a suspended account and a deleted account get 403 and leave nothing behind', async () => {
    const w = world();
    await assert.rejects(w.svc.requestReward(null), isForbidden);
    w.fr.setUserStatus('7', 'suspended');
    await assert.rejects(w.svc.requestReward(member('7')), isForbidden);
    w.fr.addUser('9', { deleted: true });
    await assert.rejects(w.svc.requestReward(member('9')), isForbidden);
    assert.equal(w.fr.grants().length, 0);
  });

  it('at most maxOpen requests are open per account; expired ones do not count; other accounts are independent', async () => {
    const w = world();
    for (let i = 0; i < REWARD_POLICY.maxOpen; i++) await w.svc.requestReward(member('7'));
    await assert.rejects(w.svc.requestReward(member('7')), isReward('rate_limited'));
    await w.svc.requestReward(member('8'));
    w.clock.t += (REWARD_POLICY.ttlSeconds + 1) * 1000;
    await w.svc.requestReward(member('7'));
    assert.equal(w.fr.grants().filter((g) => g.userId === '7').length, REWARD_POLICY.maxOpen + 1);
  });

  it('concurrent requests cannot exceed the limit', async () => {
    const w = world({ policy: { maxOpen: 2 } });
    const results = await Promise.allSettled([1, 2, 3, 4, 5].map(() => w.svc.requestReward(member('7'))));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 2);
    assert.equal(w.fr.grants().length, 2);
  });
});

describe('verifyReward: only the provider evidence verifies', () => {
  it('valid evidence for this grant and this user -> verified, with the provider transaction id and a verification time', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    const g = w.fr.grants()[0]!;
    assert.deepEqual(await w.svc.verifyReward(r.id, w.evidence(g, 'prov-tx-1')), { id: r.id, status: 'verified' });
    const v = w.fr.grants()[0]!;
    assert.deepEqual([v.status, v.ssvTransactionId, v.verifiedAt?.getTime(), v.carId, v.consumedAt], ['verified', 'prov-tx-1', T0, null, null]);
  });

  it('everything a client could claim is rejected and changes nothing', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    const other = w.fr.seed({ userId: '8' });
    const bad: unknown[] = [undefined, null, 'verified', 1, {}, { verified: true }, { status: 'verified', ssv_transaction_id: 'x', verified_at: 'now' }, { grantId: r.id, userId: '7' },
      { grantId: other.id, userId: '7', tx: 'a' }, { grantId: r.id, userId: '8', tx: 'a' }, { grantId: r.id, userId: '7', tx: 5 }];
    for (const evidence of bad) await assert.rejects(w.svc.verifyReward(r.id, evidence), isReward('verification_failed'));
    const g = w.fr.grants().find((x) => x.id === r.id)!;
    assert.deepEqual([g.status, g.ssvTransactionId, g.verifiedAt], ['requested', null, null]);
  });

  it('a verifier that throws, or answers badly, is a plain verification failure (and nothing about it is logged)', async () => {
    for (const verifier of [makeFakeVerifier({ throws: true }), { provider: 'fake', verify: async () => ({ ok: true, transactionId: '' }) }, { provider: 'fake', verify: async () => ({ ok: true, transactionId: 'x'.repeat(201) }) }, { provider: 'fake', verify: async () => null as never }]) {
      const w = world({ verifier: verifier as never });
      const r = await w.svc.requestReward(member('7'));
      await assert.rejects(w.svc.verifyReward(r.id, { SECRET: 'SECRET-EVIDENCE' }), isReward('verification_failed'));
      assert.equal(w.fr.grants()[0]!.status, 'requested');
      assert.ok(!w.lines.join('\n').includes('SECRET-EVIDENCE'));
    }
  });

  it('a malformed or unknown id, and a grant of another provider, are the same not_found', async () => {
    const w = world();
    for (const id of [undefined, null, 5, '', 'abc', '1', NEVER, `${NEVER}; DROP TABLE reward_grants`]) await assert.rejects(w.svc.verifyReward(id, {}), isReward('not_found'));
    const g = w.fr.seed({ userId: '7', provider: 'someone-else' });
    await assert.rejects(w.svc.verifyReward(g.id, w.evidence(g)), isReward('not_found'));
  });

  it('an expired request cannot be verified; a failed or expired grant cannot either', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    const g = w.fr.grants()[0]!;
    w.clock.t += (REWARD_POLICY.ttlSeconds + 1) * 1000;
    await assert.rejects(w.svc.verifyReward(r.id, w.evidence(g)), isReward('expired'));
    for (const status of ['failed', 'expired'] as const) {
      const s = w.fr.seed({ userId: '7', status });
      await assert.rejects(w.svc.verifyReward(s.id, w.evidence(s)), isReward('invalid_state'));
    }
    assert.equal(w.verifier.calls, 0, 'the provider is not even consulted for a grant that cannot change');
  });

  it('one receipt verifies one request: the same transaction id for another request is replayed', async () => {
    const w = world();
    const a = await w.svc.requestReward(member('7'));
    const b = await w.svc.requestReward(member('7'));
    const ga = w.fr.grants().find((g) => g.id === a.id)!;
    const gb = w.fr.grants().find((g) => g.id === b.id)!;
    await w.svc.verifyReward(a.id, w.evidence(ga, 'same-receipt'));
    await assert.rejects(w.svc.verifyReward(b.id, w.evidence(gb, 'same-receipt')), isReward('replayed'));
    assert.equal(w.fr.grants().find((g) => g.id === b.id)!.status, 'requested');
  });

  it('two requests racing for one receipt: the unique index lets one win; the loser is replayed and rolled back', async () => {
    const w = world();
    const a = await w.svc.requestReward(member('7'));
    const b = await w.svc.requestReward(member('8'));
    const ga = w.fr.grants().find((g) => g.id === a.id)!;
    const gb = w.fr.grants().find((g) => g.id === b.id)!;
    const results = await Promise.allSettled([w.svc.verifyReward(a.id, w.evidence(ga, 'race-tx')), w.svc.verifyReward(b.id, w.evidence(gb, 'race-tx'))]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.ok(results.some((r) => r.status === 'rejected' && isReward('replayed')(r.reason)));
    assert.equal(w.fr.grants().filter((g) => g.status === 'verified').length, 1);
  });

  it('the unique violation raised by the database itself (a receipt taken between the check and the write) is replayed too', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    const g = w.fr.grants()[0]!;
    w.fr.faults.beforeMarkVerified = () => {
      w.fr.faults.beforeMarkVerified = null;
      throw new DbError('unique', { sqlstate: '23505', constraint: 'reward_ssv_uq' });
    };
    await assert.rejects(w.svc.verifyReward(r.id, w.evidence(g)), isReward('replayed'));
    assert.equal(w.fr.grants()[0]!.status, 'requested');
  });

  it('the same evidence again is idempotent (no second write); other evidence for a verified grant is refused', async () => {
    const w = world();
    const g = await w.verified();
    const stamp = g.verifiedAt!.getTime();
    w.clock.t += 5000;
    assert.deepEqual(await w.svc.verifyReward(g.id, w.evidence(g)), { id: g.id, status: 'verified' });
    assert.equal(w.fr.grants()[0]!.verifiedAt!.getTime(), stamp, 'the verification time did not move');
    await assert.rejects(w.svc.verifyReward(g.id, w.evidence(g, 'a-different-receipt')), isReward('invalid_state'));
    assert.equal(w.fr.grants()[0]!.ssvTransactionId, `tx-${g.id}`);
  });

  it('the same evidence twice at once verifies once', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    const g = w.fr.grants()[0]!;
    const out = await Promise.all([w.svc.verifyReward(r.id, w.evidence(g)), w.svc.verifyReward(r.id, w.evidence(g))]);
    assert.deepEqual(out.map((o) => o.status), ['verified', 'verified']);
    assert.equal(w.fr.calls.filter((c) => c === 'markVerified').length, 1);
  });
});

describe('consumeReward: one-time, owner-only, pending ad only', () => {
  it('a verified grant attaches to the owner\'s pending ad and becomes exactly what moderation requires', async () => {
    const w = world();
    const g = await w.verified();
    w.clock.t += 1000;
    assert.deepEqual(await w.svc.consumeReward(member('7'), g.id, '100'), { id: g.id, carId: '100', status: 'consumed', published: true });
    const c = w.fr.grants()[0]!;
    assert.deepEqual([c.status, c.carId, c.consumedAt?.getTime(), c.userId], ['consumed', '100', T0 + 1000, '7']);
    // The moderation gate (member-cars/moderation.ts, unchanged) reads: consumed + ssv transaction + verified_at + consumed_at, bound to car and owner.
    const gate = buildHasVerifiedReward('100', '7');
    assert.match(gate.text, /status = 'consumed'/);
    assert.ok(c.status === 'consumed' && c.ssvTransactionId !== null && c.verifiedAt !== null && c.consumedAt !== null && c.carId === gate.values[0] && c.userId === gate.values[1]);
  });

  it('the same request again is idempotent; another ad with the same grant is refused', async () => {
    const w = world();
    const g = await w.verified();
    await w.svc.consumeReward(member('7'), g.id, '100');
    const stamp = w.fr.grants()[0]!.consumedAt!.getTime();
    w.clock.t += 9000;
    assert.deepEqual(await w.svc.consumeReward(member('7'), g.id, '100'), { id: g.id, carId: '100', status: 'consumed', published: true });
    assert.equal(w.fr.grants()[0]!.consumedAt!.getTime(), stamp);
    assert.equal(w.fr.audits().length, 1, 'the repeat publishes and audits nothing more');
    assert.equal(w.fr.car('100')!.version, 2);
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '101'), isReward('invalid_state'));
    assert.equal(w.fr.grants()[0]!.carId, '100');
  });

  it('only a verified grant can be consumed: requested, failed and expired are refused', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    await assert.rejects(w.svc.consumeReward(member('7'), r.id, '100'), isReward('invalid_state'));
    for (const status of ['failed', 'expired'] as const) {
      const s = w.fr.seed({ userId: '7', status });
      await assert.rejects(w.svc.consumeReward(member('7'), s.id, '100'), isReward('invalid_state'));
    }
    assert.ok(w.fr.grants().every((g) => g.carId === null));
  });

  it('a verified grant whose time ran out cannot be consumed', async () => {
    const w = world();
    const g = await w.verified();
    w.clock.t += (REWARD_POLICY.ttlSeconds + 1) * 1000;
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '100'), isReward('expired'));
    assert.equal(w.fr.grants()[0]!.status, 'verified');
    assert.equal(w.fr.grants()[0]!.carId, null);
  });

  it('another account\'s grant and another account\'s ad are the same not_found; so are malformed ids', async () => {
    const w = world();
    const g = await w.verified('7');
    await assert.rejects(w.svc.consumeReward(member('8'), g.id, '200'), isReward('not_found'));
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '200'), isReward('not_found'));
    for (const [gid, cid] of [[g.id, undefined], [g.id, '0'], [g.id, '01'], [g.id, '100; DROP'], [g.id, 100], ['x', '100'], [undefined, '100'], [NEVER, '100']] as const) {
      await assert.rejects(w.svc.consumeReward(member('7'), gid, cid), isReward('not_found'));
    }
    assert.equal(w.fr.grants()[0]!.status, 'verified');
  });

  it('only a live member ad can take a reward: a showroom car, a deleted ad and an unknown id are not_found', async () => {
    const w = world();
    const g = await w.verified();
    w.fr.addCar('300', '7', { source: 'showroom' });
    w.fr.addCar('301', '7', { deleted: true });
    for (const id of ['300', '301', '999']) await assert.rejects(w.svc.consumeReward(member('7'), g.id, id), isReward('not_found'));
    assert.equal(w.fr.grants()[0]!.carId, null);
  });

  it('only a PENDING ad takes a reward: active, rejected, suspended and sold ads are refused', async () => {
    const w = world();
    const g = await w.verified();
    let n = 400;
    for (const status of ['active', 'rejected', 'suspended', 'sold']) {
      w.fr.addCar(String(++n), '7', { status });
      await assert.rejects(w.svc.consumeReward(member('7'), g.id, String(n)), isReward('invalid_state'), status);
    }
    assert.equal(w.fr.grants()[0]!.status, 'verified');
  });

  it('an ad that already has a grant takes no second one', async () => {
    const w = world();
    const g1 = await w.verified();
    const g2 = await w.verified();
    await w.svc.consumeReward(member('7'), g1.id, '100');
    await assert.rejects(w.svc.consumeReward(member('7'), g2.id, '100'), isReward('invalid_state'));
    assert.equal(w.fr.grants().find((g) => g.id === g2.id)!.status, 'verified');
  });

  it('a guest and an account that may no longer act get 403, and the grant is untouched', async () => {
    const w = world();
    const g = await w.verified();
    await assert.rejects(w.svc.consumeReward(null, g.id, '100'), isForbidden);
    w.fr.setUserStatus('7', 'suspended');
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '100'), isForbidden);
    assert.equal(w.fr.grants()[0]!.status, 'verified');
  });

  it('two consumptions of one grant for two ads at once: exactly one succeeds', async () => {
    const w = world();
    const g = await w.verified();
    const results = await Promise.allSettled([w.svc.consumeReward(member('7'), g.id, '100'), w.svc.consumeReward(member('7'), g.id, '101')]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.ok(results.some((r) => r.status === 'rejected' && isReward('invalid_state')(r.reason)));
    assert.equal(w.fr.grants().filter((x) => x.carId !== null).length, 1);
  });

  it('two grants for one ad at once: exactly one succeeds', async () => {
    const w = world();
    const g1 = await w.verified();
    const g2 = await w.verified();
    const results = await Promise.allSettled([w.svc.consumeReward(member('7'), g1.id, '100'), w.svc.consumeReward(member('7'), g2.id, '100')]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(w.fr.grants().filter((x) => x.carId === '100').length, 1);
  });

  it('the database\'s own unique violation on car_id is reported as invalid_state and rolls the transaction back', async () => {
    const w = world();
    const g = await w.verified();
    w.fr.faults.beforeConsume = () => {
      w.fr.faults.beforeConsume = null;
      throw new DbError('unique', { sqlstate: '23505', constraint: 'reward_grants_car_id_key' });
    };
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '100'), isReward('invalid_state'));
    assert.deepEqual([w.fr.grants()[0]!.status, w.fr.grants()[0]!.carId], ['verified', null]);
    assert.equal(w.fr.openTransactions(), 0);
  });

  it('an unexpected database error propagates and leaves the grant verified', async () => {
    const w = world();
    const g = await w.verified();
    w.fr.faults.beforeConsume = () => {
      w.fr.faults.beforeConsume = null;
      throw new DbError('unavailable', { sqlstate: '08006' });
    };
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '100'), (e: unknown) => e instanceof DbError);
    assert.equal(w.fr.grants()[0]!.status, 'verified');
  });
});

describe('publication: a valid, consumed reward makes a regular member\'s ad public at once', () => {
  const car = (w: ReturnType<typeof world>, id = '100') => w.fr.car(id)!;

  it('the ad is pending before and active right after, in the same step, with its audit row (numbers only)', async () => {
    const w = world();
    const g = await w.verified();
    assert.equal(car(w).status, 'pending', 'a verified grant alone publishes nothing');
    const r = await w.svc.consumeReward(member('7'), g.id, '100');
    assert.equal(r.published, true);
    assert.deepEqual([car(w).status, car(w).version], ['active', 2]);
    assert.deepEqual(w.fr.audits().map((a) => [a.action, a.actorUserId, a.actorRole, a.entityType, a.entityId, a.afterData]), [['member_car.reward_publish', '7', 'user', 'car', '100', { version: 2 }]]);
  });

  it('no reward, an unverified grant, an expired one: the ad stays pending and no audit row exists', async () => {
    const w = world();
    const requested = await w.svc.requestReward(member('7'));
    await assert.rejects(w.svc.consumeReward(member('7'), requested.id, '100'), isReward('invalid_state'));
    const expired = await w.verified();
    w.clock.t += (REWARD_POLICY.ttlSeconds + 1) * 1000;
    await assert.rejects(w.svc.consumeReward(member('7'), expired.id, '100'), isReward('expired'));
    await assert.rejects(w.svc.consumeReward(member('7'), NEVER, '100'), isReward('not_found'));
    assert.deepEqual([car(w).status, w.fr.audits().length], ['pending', 0]);
  });

  it('failed verification (wrong evidence, a throwing provider, the unconfigured default) never publishes', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    await assert.rejects(w.svc.verifyReward(r.id, { verified: true, status: 'verified', published: true }), isReward('verification_failed'));
    await assert.rejects(w.svc.consumeReward(member('7'), r.id, '100'), isReward('invalid_state'));
    assert.deepEqual([car(w).status, w.fr.grants()[0]!.status], ['pending', 'requested']);
    const w2 = world({ verifier: makeFakeVerifier({ throws: true }) });
    const r2 = await w2.svc.requestReward(member('7'));
    await assert.rejects(w2.svc.verifyReward(r2.id, {}), isReward('verification_failed'));
    assert.equal(car(w2).status, 'pending');
    const clock = { now: () => T0 };
    const fr = makeFakeRewards(clock);
    fr.addUser('7');
    fr.addCar('100', '7');
    const g = fr.seed({ userId: '7', status: 'verified', ssvTransactionId: 'seeded', verifiedAt: new Date(T0), provider: 'unconfigured' });
    const unconfigured = createRewardService({ store: fr.store, verifier: createUnconfiguredRewardVerifier() });
    await assert.rejects(unconfigured.requestReward(member('7')), isReward('unavailable'));
    await assert.rejects(unconfigured.verifyReward(g.id, {}), isReward('unavailable'));
    // (a grant that somehow is verified and valid does publish, which is why only the verifier path may ever set that state)
    assert.equal(fr.car('100')!.status, 'pending');
  });

  it('replay: the same receipt cannot verify a second request, a consumed grant cannot publish a second ad, a second grant cannot republish', async () => {
    const w = world();
    const a = await w.svc.requestReward(member('7'));
    const b = await w.svc.requestReward(member('7'));
    const ga = w.fr.grants().find((g) => g.id === a.id)!;
    const gb = w.fr.grants().find((g) => g.id === b.id)!;
    await w.svc.verifyReward(a.id, w.evidence(ga, 'one-receipt'));
    await assert.rejects(w.svc.verifyReward(b.id, w.evidence(gb, 'one-receipt')), isReward('replayed'));
    await w.svc.consumeReward(member('7'), a.id, '100');
    await assert.rejects(w.svc.consumeReward(member('7'), a.id, '101'), isReward('invalid_state'));
    assert.equal(car(w, '101').status, 'pending', 'the second ad did not go public with the same reward');
    await assert.rejects(w.svc.consumeReward(member('7'), b.id, '100'), isReward('invalid_state'));
    assert.equal(w.fr.audits().length, 1);
  });

  it('cross-user: another account can neither spend my grant nor publish through it, nor attach mine to its ad', async () => {
    const w = world();
    const g = await w.verified('7');
    await assert.rejects(w.svc.consumeReward(member('8'), g.id, '200'), isReward('not_found'));
    await assert.rejects(w.svc.consumeReward(member('8'), g.id, '100'), isReward('not_found'));
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '200'), isReward('not_found'));
    assert.deepEqual([car(w, '100').status, car(w, '200').status, w.fr.grants()[0]!.status, w.fr.audits().length], ['pending', 'pending', 'verified', 0]);
  });

  it('fail safe: if the publication or its audit row fails, the consumption rolls back too (grant verified, ad pending, no audit)', async () => {
    for (const fault of ['publishError', 'publishNull', 'auditError'] as const) {
      const w = world();
      const g = await w.verified();
      if (fault === 'publishError') w.fr.faults.beforePublish = () => { throw new DbError('unavailable', { sqlstate: '08006' }); };
      if (fault === 'publishNull') w.fr.setCarStatus('100', 'pending'), (w.fr.faults.beforePublish = () => w.fr.setCarStatus('100', 'rejected'));
      if (fault === 'auditError') w.fr.faults.failAudit = true;
      await assert.rejects(w.svc.consumeReward(member('7'), g.id, '100'));
      assert.deepEqual([w.fr.grants()[0]!.status, w.fr.grants()[0]!.carId, car(w).status, w.fr.audits().length], ['verified', null, 'pending', 0], fault);
      assert.equal(w.fr.openTransactions(), 0);
    }
  });

  it('after a reward publication a later administrator suspension is not undone by repeating the request', async () => {
    const w = world();
    const g = await w.verified();
    await w.svc.consumeReward(member('7'), g.id, '100');
    w.fr.setCarStatus('100', 'suspended');
    const again = await w.svc.consumeReward(member('7'), g.id, '100');
    assert.deepEqual([again.published, car(w).status], [false, 'suspended']);
  });

  it('two concurrent consumptions of one grant publish at most one ad', async () => {
    const w = world();
    const g = await w.verified();
    await Promise.allSettled([w.svc.consumeReward(member('7'), g.id, '100'), w.svc.consumeReward(member('7'), g.id, '101')]);
    assert.equal([car(w, '100'), car(w, '101')].filter((c) => c.status === 'active').length, 1);
    assert.equal(w.fr.audits().length, 1);
  });

  it('showroom owners keep the existing path: a dealer\'s reward is consumed but the ad stays pending for administrator approval; the same for an administrator', async () => {
    for (const role of ['dealer', 'admin'] as const) {
      const w = world();
      const actor: Actor = { id: '7', role };
      const r = await w.svc.requestReward(actor);
      const g = w.fr.grants().find((x) => x.id === r.id)!;
      await w.svc.verifyReward(r.id, w.evidence(g));
      const out = await w.svc.consumeReward(actor, r.id, '100');
      assert.deepEqual([out.status, out.published, car(w).status, w.fr.audits().length], ['consumed', false, 'pending', 0], role);
      assert.equal(w.fr.grants()[0]!.carId, '100', 'the grant is still bound: the moderation gate can find it');
    }
    assert.ok(dealer('1').role === 'dealer');
  });

  it('a pending showroom owner and a suspended account have no actor: refused before anything is read, nothing published', async () => {
    const w = world();
    const g = await w.verified();
    await assert.rejects(w.svc.requestReward(null), isForbidden);
    await assert.rejects(w.svc.consumeReward(null, g.id, '100'), isForbidden);
    w.fr.setUserStatus('7', 'suspended');
    await assert.rejects(w.svc.consumeReward(member('7'), g.id, '100'), isForbidden);
    assert.deepEqual([car(w).status, w.fr.audits().length], ['pending', 0]);
  });
});

describe('the reward alone publishes nothing; logs hold ids only', () => {
  it('the whole life logs ids only: no evidence, no receipt', async () => {
    const w = world();
    const r = await w.svc.requestReward(member('7'));
    const g = w.fr.grants()[0]!;
    await w.svc.verifyReward(r.id, { ...w.evidence(g, 'RECEIPT-SECRET-123'), note: 'EVIDENCE-SECRET-456' });
    await w.svc.consumeReward(member('7'), r.id, '100');
    const text = w.lines.join('\n');
    assert.ok(!text.includes('RECEIPT-SECRET-123') && !text.includes('EVIDENCE-SECRET-456'));
    assert.deepEqual(w.lines.map((l) => (JSON.parse(l) as { event: string }).event), ['reward.requested', 'reward.verified', 'reward.consumed']);
  });

  it('constructor guards: a provider name that does not fit the column and an invalid policy are refused', () => {
    const fr = makeFakeRewards({ now: () => T0 });
    assert.throws(() => createRewardService({ store: fr.store, verifier: makeFakeVerifier({ provider: '' }) }));
    assert.throws(() => createRewardService({ store: fr.store, verifier: makeFakeVerifier({ provider: 'x'.repeat(41) }) }));
    assert.throws(() => createRewardService({ store: fr.store, verifier: makeFakeVerifier(), policy: { ttlSeconds: 0 } }));
    assert.throws(() => createRewardService({ store: fr.store, verifier: makeFakeVerifier(), policy: { maxOpen: 1.5 } }));
  });
});

describe('SQL pins: every statement is bound and enforces its state in the WHERE clause', () => {
  const flat = (s: string) => s.replace(/\s+/g, ' ');
  it('requests are always a fresh unbound row: status and car are literals, never parameters', () => {
    const s = buildInsertRequest({ userId: '7', provider: 'p', ttlSeconds: 60 });
    assert.match(flat(s.text), /VALUES \(\$1::bigint, \$2::varchar, 'requested', now\(\) \+ make_interval\(secs => \$3::int\)\)/);
    assert.deepEqual(s.values, ['7', 'p', 60]);
    assert.ok(!/car_id|ssv_transaction_id|verified_at|consumed_at/.test(s.text.split('RETURNING')[0]!));
  });

  it('verification: same user, same provider, still requested, unbound, unexpired; the receipt is a bound value', () => {
    const s = buildMarkVerified({ id: NEVER, userId: '7', provider: 'p', transactionId: 'tx' });
    const t = flat(s.text);
    assert.match(t, /SET status = 'verified', ssv_transaction_id = \$4::text, verified_at = now\(\)/);
    assert.match(t, /WHERE id = \$1::uuid AND user_id = \$2::bigint AND provider = \$3::varchar AND status = 'requested' AND car_id IS NULL AND expires_at > now\(\)/);
    assert.deepEqual(s.values, [NEVER, '7', 'p', 'tx']);
  });

  it('consumption: same user, still verified, unbound, unexpired; it sets car_id and consumed_at in the same statement', () => {
    const s = buildConsume({ id: NEVER, userId: '7', carId: '100' });
    const t = flat(s.text);
    assert.match(t, /SET status = 'consumed', car_id = \$3::bigint, consumed_at = now\(\)/);
    assert.match(t, /WHERE id = \$1::uuid AND user_id = \$2::bigint AND status = 'verified' AND car_id IS NULL AND expires_at > now\(\)/);
    assert.deepEqual(s.values, [NEVER, '7', '100']);
  });

  it('publication: a literal status, only the owner\'s pending member ad, bound values, returns the new version', () => {
    const s = buildPublishOwnCar({ carId: '100', userId: '7' });
    const t = flat(s.text);
    assert.match(t, /^UPDATE cars SET status = 'active', rejection_reason = NULL, suspension_reason = NULL WHERE id = \$1::bigint AND owner_id = \$2::bigint AND source_type = 'member' AND deleted_at IS NULL AND status = 'pending' RETURNING version$/);
    assert.deepEqual(s.values, ['100', '7']);
  });

  it('the locking reads: the grant and the owner\'s live member ad are FOR UPDATE; expiry is read by the database clock', () => {
    assert.match(flat(buildFind(NEVER, true).text), /FROM reward_grants WHERE id = \$1::uuid FOR UPDATE$/);
    assert.ok(!/FOR UPDATE/.test(buildFind(NEVER, false).text));
    assert.match(flat(buildFind(NEVER, false).text), /\(expires_at <= now\(\)\) AS expired/);
    assert.match(flat(buildLockOwnCar('100', '7').text), /WHERE id = \$1::bigint AND owner_id = \$2::bigint AND source_type = 'member' AND deleted_at IS NULL FOR UPDATE$/);
    assert.deepEqual(buildLockOwnCar('100', '7').values, ['100', '7']);
    assert.deepEqual(buildCarHasGrant('100').values, ['100']);
    assert.match(buildCountOpen('7').text, /status = 'requested' AND expires_at > now\(\)/);
    assert.deepEqual(buildFindByTransaction('p', 'tx').values, ['p', 'tx']);
  });
});

describe('static guards over the source tree', () => {
  const walk = (dir: string): string[] => readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? walk(join(dir, f)) : f.endsWith('.ts') ? [join(dir, f)] : []));
  const srcDir = join(import.meta.dirname, '..', '..', 'src');
  const sources = walk(srcDir).map((f) => ({ f: f.slice(srcDir.length + 1), text: readFileSync(f, 'utf8') }));
  const code = (t: string) => t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');

  it('reward_grants is written in exactly one place (rewards/repository.ts) and never deleted from', () => {
    const writers = sources.filter(({ text }) => /(INSERT\s+INTO|UPDATE)\s+reward_grants/i.test(code(text))).map((s) => s.f);
    assert.deepEqual(writers, ['rewards/repository.ts']);
    for (const { f, text } of sources) assert.ok(!/(DELETE\s+FROM|TRUNCATE(\s+TABLE)?)\s+reward_grants/i.test(code(text)), f);
  });

  it('no production file imports a test helper or the fake verifier, and only the composition root (index.ts) and the server (server.ts, for the route type) import the module from outside rewards/', () => {
    for (const { f, text } of sources) {
      assert.ok(!/from\s+['"][^'"]*(test\/|fake-rewards|makeFakeVerifier)/.test(code(text)), f);
      if (!f.startsWith('rewards/') && f !== 'index.ts' && f !== 'server.ts') assert.ok(!/from\s+['"][^'"]*rewards\//.test(code(text)), f);
    }
    assert.ok(!sources.some(({ f, text }) => f.startsWith('rewards/') && /makeFakeVerifier|createFake/.test(text)));
  });

  it('the rewards module has no HTTP outside routes.ts, no moderation write and no audit SQL', () => {
    for (const { f, text } of sources.filter((s) => s.f.startsWith('rewards/'))) {
      if (f !== 'rewards/routes.ts') assert.ok(!/fastify|app\.(get|post|patch|put|delete)\(/.test(code(text)), f);
      assert.ok(!/INSERT\s+INTO\s+audit_logs/i.test(code(text)), f);
    }
  });

  it('the only write outside reward_grants is ONE statement: a pending member ad of the owner becomes active; nothing touches users, showrooms or dealers', () => {
    const rewards = sources.filter((x) => x.f.startsWith('rewards/'));
    const updates = rewards.flatMap(({ f, text }) => [...code(text).matchAll(/UPDATE\s+(\w+)\s+SET\s+([\s\S]*?)\s+WHERE\s+([\s\S]*?)(?:RETURNING|`)/gi)].map((m) => ({ f, table: m[1]!, set: m[2]!.replace(/\s+/g, ' '), where: m[3]!.replace(/\s+/g, ' ') })));
    assert.deepEqual(updates.map((u) => u.table).sort(), ['cars', 'reward_grants', 'reward_grants']);
    const car = updates.find((u) => u.table === 'cars')!;
    assert.equal(car.set, "status = 'active', rejection_reason = NULL, suspension_reason = NULL");
    assert.match(car.where, /source_type = 'member' AND deleted_at IS NULL AND status = 'pending'/);
    for (const { f, text } of rewards) assert.ok(!/(UPDATE|INSERT\s+INTO|DELETE\s+FROM)\s+(users|showrooms|dealers|sessions|verification_codes|message_deliveries)\b/i.test(code(text)), f);
  });

  it('the member-car moderation module still only READS reward_grants', () => {
    const m = code(sources.find((s) => s.f === 'member-cars/moderation.ts')!.text);
    assert.ok(!/(INSERT\s+INTO|UPDATE|DELETE\s+FROM)\s+reward_grants/i.test(m));
    assert.match(m, /reward_required/);
  });
});

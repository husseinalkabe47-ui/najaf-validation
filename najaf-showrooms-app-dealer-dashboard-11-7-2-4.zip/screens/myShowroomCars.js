/* «سيارات معرضي» — سيارات معرض التاجر الحالي فقط (getMyShowroomCars عبر الصلاحيات)
   (11.7.2.4) وضع الخادم: القائمة من GET /v1/dealer/cars فقط (BackendDealer في api/authBridge.js)، عرض فقط — الإضافة/التعديل/الحذف لم تُربط بعد. */
function MyShowroomCarsScreen() {
  if (BackendDealer.isEnabled()) return _MyShowroomCarsRemote();
  const cars = getMyShowroomCars();
  const statusOptions = ShowroomCarsService.DEALER_STATUSES.map(s => `<option value="${s}">${CAR_STATUS_LABEL[s]}</option>`).join('');
  return `
  ${BackBar('dealerHome')}
  <div class="topbar"><div class="topbar-row"><h1>🚘 سيارات معرضي</h1></div></div>
  <div class="section">
    <button class="btn-primary" style="margin:0 0 14px" onclick="go('addShowroomCar')">+ إضافة سيارة</button>
    ${cars.length === 0 ? EmptyState({ icon: '🚘', title: 'لا توجد سيارات مضافة', hint: 'أضف أول سيارة لمعرضك لتظهر للزبائن فورًا.' }) :
      cars.map(c => `
      <div class="ad-row">
        <div class="card-img">${CarImageInner(c)}</div>
        <div class="ad-info">
          <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
          <p class="card-row">${val(c.year)}</p>
          <p class="price">${carPriceOrDash(c)}</p>
          ${carStatusBadge(c.status)}
          <div class="ad-actions">
            <button onclick="go('editShowroomCar', ${c.id})">تعديل</button>
            <select onchange="handleShowroomCarStatusChange(${c.id}, this.value)">
              <option value="">تغيير الحالة</option>${statusOptions}
            </select>
            <button class="danger" onclick="handleDeleteShowroomCar(${c.id})">حذف</button>
          </div>
        </div>
      </div>`).join('')}
  </div>`;
}

function _MyShowroomCarsRemote() {
  let st = BackendDealer.cars();
  if (st.status === 'idle') { BackendDealer.loadCars(_rerenderIf('myShowroomCars')); st = BackendDealer.cars(); }
  const retry = "BackendDealer.loadCars(_rerenderIf('myShowroomCars'));render()";
  const list = st.status === 'ready' ? st.items.map(c => `
      <div class="ad-row">
        <div class="card-img">${CAR_PLACEHOLDER}</div>
        <div class="ad-info">
          <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
          <p class="card-row">${val(c.year)}</p>
          <p class="price">${carPriceOrDash(c)}</p>
          ${carStatusBadge(c.status)}
        </div>
      </div>`).join('')
      + (st.error ? `<div class="form-note" role="alert">${esc(st.error)}</div>` : '')
      + (st.more ? '<div class="placeholder" role="status" aria-busy="true"><b>جارٍ تحميل المزيد…</b></div>'
        : st.nextBefore ? `<button class="action-btn" style="width:100%;margin-top:10px" onclick="BackendDealer.loadCars(_rerenderIf('myShowroomCars'), true);render()">عرض المزيد</button>` : '')
    : RemoteState(st, { loading: 'جارٍ تحميل سيارات معرضك…', retry,
        empty: { icon: '🚘', title: st.noShowroom ? 'لا يوجد معرض مرتبط بحسابك بعد.' : 'لا توجد سيارات في معرضك بعد' } });
  return `
  ${BackBar('dealerHome')}
  <div class="topbar"><div class="topbar-row"><h1>🚘 سيارات معرضي</h1></div></div>
  <div class="section">
    <p class="sub" style="margin:0 0 14px">إضافة السيارات وتعديلها وحذفها عبر الخادم ستتوفر في خطوة لاحقة.</p>
    ${list}
  </div>`;
}

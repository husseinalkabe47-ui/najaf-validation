/* Phase 11.7.2.1 — دخول/خروج حقيقيان عبر api/authBridge.js وapi/apiClient.js داخل بيئة التطبيق الفعلية (vm بنفس سكربتات index.html).
   fetch والمؤقّتات والساعة مُحقَنة: لا شبكة حقيقية، ولم يُجرَّب أي تكامل فعلي مع خادم. الوضع المحلي الافتراضي تغطّيه الاختبارات القديمة. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');

const T0 = Date.parse('2030-01-01T00:00:00Z');
const iso = ms => new Date(ms).toISOString();
const PASSWORD = 'Pa$$w0rd-SECRET-123';
const sessionOf = (n, o) => Object.assign({ accessToken: 'ACCESS-' + n, accessExpiresAt: iso(T0 + 15 * 60e3), refreshToken: 'REFRESH-' + n, refreshExpiresAt: iso(T0 + 30 * 864e5) }, o);
const serverUser = o => Object.assign({ id: '5', name: 'علي الاختبار', phone: '+9647701234567', role: 'user', status: 'active', phoneVerified: false, createdAt: '2030-01-01T00:00:00.000Z' }, o);
const res = (status, body, headers) => ({ status, headers: { get: k => ((headers || {})[String(k).toLowerCase()] ?? (body === undefined ? null : (String(k).toLowerCase() === 'content-type' ? 'application/json' : null))) }, text: async () => (body === undefined ? '' : typeof body === 'string' ? body : JSON.stringify(body)) });
const loginOk = (n, u) => res(200, { user: serverUser(u), session: sessionOf(n) });
const err = (status, code, headers) => res(status, { error: { code, message: 'm', requestId: 'r' } }, headers);

/** بيئة التطبيق في وضع الخادم. handler(call) يعيد استجابة (أو وعدًا أو يرمي). */
function remote(handler, opts) {
  opts = opts || {};
  const store = opts.store || {};
  const env = makeEnv(store);
  const calls = [];
  const clock = { t: T0 };
  const timers = new Map(); let seq = 1;
  env.ctx.__fetch = async (url, init) => {
    const call = { url, method: init.method, headers: init.headers, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    calls.push(call);
    return handler(call, calls.length);
  };
  env.ctx.URL = URL; env.ctx.AbortController = AbortController;
  env.ctx.__now = () => clock.t;
  env.ctx.__st = (fn, ms) => { const id = seq++; timers.set(id, fn); return id; };
  env.ctx.__ct = id => timers.delete(id);
  env.run("BackendAuth.init({ baseUrl: " + JSON.stringify(opts.baseUrl === undefined ? 'https://api.test' : opts.baseUrl) + ", fetch: __fetch, now: __now, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => { env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`); };
  return {
    env, store, calls, clock, set,
    fireTimers: () => [...timers.values()].forEach(f => f()),
    run: c => env.run(c),
    route: () => env.run('currentRoute'),
    user: () => env.run('SessionService.getCurrentUser()'),
    toast: () => env.els.toast && env.els.toast.textContent,
    login: async (id, pw) => { env.run("go('login')"); set('loginIdentifier', id === undefined ? '07701234567' : id); set('loginPassword', pw === undefined ? PASSWORD : pw); return env.run('handleLoginSubmit()'); },
  };
}
const tick = () => new Promise(r => setImmediate(r));

/* ---------------- الوضع ---------------- */

test('بلا عنوان خلفية: الوضع المحلي كما هو (لا عميل، لا شبكة، الحسابات التجريبية ظاهرة)', () => {
  const env = makeEnv();
  assert.equal(env.run('BackendAuth.isEnabled()'), false);
  assert.equal(env.run('AuthService.isRemote()'), false);
  assert.equal(env.run('BackendAuth.api()'), null);
  env.run("go('login')");
  assert.match(env.screen(), /حسابات تجريبية/);
  const r = JSON.parse(env.run("JSON.stringify(AuthService.login('07701234567', '123456'))"));
  assert.equal(typeof r.ok, 'boolean');
});

test('وضع الخادم: لا صندوق حسابات تجريبية في شاشة الدخول، والتصميم/الحقول كما هي', () => {
  const t = remote(() => res(200, {}));
  t.env.run("go('login')");
  const html = t.env.screen();
  assert.ok(!/حسابات تجريبية/.test(html));
  for (const id of ['loginIdentifier', 'loginPassword', 'loginError', 'loginNote']) assert.match(html, new RegExp('id="' + id + '"'));
  assert.match(html, /تسجيل الدخول/);
});

/* ---------------- دخول ناجح ---------------- */

test('دخول ناجح: POST /v1/auth/login بالعقد الفعلي، وحالة الواجهة متسقة', async () => {
  const t = remote(() => loginOk(1));
  await t.login('07701234567');
  assert.equal(t.calls.length, 1);
  const c = t.calls[0];
  assert.equal(c.url, 'https://api.test/v1/auth/login');
  assert.equal(c.method, 'POST');
  assert.deepEqual(c.body, { phone: '07701234567', password: PASSWORD });
  assert.equal(c.headers.Authorization, undefined, 'الدخول بلا Authorization');
  assert.equal(c.headers['Content-Type'], 'application/json');
  assert.equal(t.route(), 'home');
  const u = t.user();
  assert.deepEqual(JSON.parse(JSON.stringify(u)), { id: 'srv:5', name: 'علي الاختبار', phone: '07701234567', email: null, role: 'user', status: 'active', createdAt: '2030-01-01T00:00:00.000Z' });
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
  assert.equal(t.run('SessionService.hasRole(ROLES.USER)'), true);
  assert.equal(t.run('BackendAuth.api().hasSession()'), true);
  t.env.run("go('account')");
  assert.match(t.env.screen(), /علي الاختبار/);
  assert.match(t.env.screen(), /تسجيل الخروج/);
});

test('أشكال الهاتف المقبولة تُوحَّد إلى 07XXXXXXXXX قبل الإرسال', async () => {
  for (const input of ['+964 770 123 4567', '٠٧٧٠١٢٣٤٥٦٧', '00964-770-123-4567']) {
    const t = remote(() => loginOk(1));
    await t.login(input);
    assert.equal(t.calls[0].body.phone, '07701234567', input);
  }
});

test('العودة لما قبل الدخول: returnTo يُحترم بعد دخول ناجح', async () => {
  const t = remote(() => loginOk(1));
  t.env.run("go('login', { returnTo: 'recentCars' })");
  t.set('loginIdentifier', '07701234567'); t.set('loginPassword', PASSWORD);
  await t.run('handleLoginSubmit()');
  assert.equal(t.route(), 'recentCars');
});

test('الأدوار والحالات تأتي من الخادم كما هي (تاجر معلّق لا صلاحيات تاجر، مدير يرى الإدارة)', async () => {
  let t = remote(() => loginOk(1, { role: 'dealer', status: 'pending', id: '9' }));
  await t.login();
  assert.equal(t.user().role, 'dealer');
  assert.equal(t.user().status, 'pending');
  assert.equal(t.run('AuthorizationService.canAccessDealerArea()'), false);
  t = remote(() => loginOk(1, { role: 'admin', id: '2' }));
  await t.login();
  assert.equal(t.run('AuthorizationService.canAccessAdmin()'), true);
});

test('معرّف مستخدم الخادم لا يطابق أي مستخدم تجريبي محلي (لا ميراث ملكية بيانات)', async () => {
  const t = remote(() => loginOk(1, { id: '1', role: 'dealer', status: 'active' }));
  await t.login();
  const u = t.user();
  assert.equal(u.id, 'srv:1');
  assert.equal(t.run(`UserService.getPublicById(SessionService.getCurrentUser().id)`), null);
  assert.equal(t.run(`CarsRepository.getAll().some(c => c.ownerId === SessionService.getCurrentUser().id)`), false);
  assert.equal(t.run('AuthorizationService.canAccessDealerArea()'), true, 'الصلاحية من دور الخادم');
  assert.equal(t.run('AuthorizationService.getManagedShowrooms().length'), 0, 'لا معرض محلي مرتبط بهذا المعرّف');
});

/* ---------------- دخول فاشل ---------------- */

async function fails(handler, expectMsg, expectCalls) {
  const t = remote(handler);
  await t.login();
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.route(), 'login');
  assert.equal(t.env.els.loginError.textContent, expectMsg);
  assert.equal(t.env.els.loginError.style.display, 'block');
  assert.equal(t.env.els.loginPassword.value, '', 'كلمة المرور تُمسح من الحقل بعد الفشل');
  assert.equal(t.run('BackendAuth.api().hasSession()'), false);
  assert.equal(t.calls.length, expectCalls === undefined ? 1 : expectCalls);
  return t;
}

test('بيانات خاطئة (401 invalid_credentials): رسالة عربية عامة', async () => {
  await fails(() => err(401, 'invalid_credentials'), 'بيانات الدخول غير صحيحة.');
});
test('فشل الشبكة', async () => {
  await fails(() => { throw new TypeError('Failed to fetch https://api.test/v1/auth/login'); }, 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.');
});
test('انتهاء المهلة', async () => {
  const t = remote(() => new Promise(() => {}));
  t.env.run("go('login')"); t.set('loginIdentifier', '07701234567'); t.set('loginPassword', PASSWORD);
  const p = t.run('handleLoginSubmit()');
  await tick();
  t.fireTimers();
  await p;
  assert.equal(t.env.els.loginError.textContent, 'انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.');
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.route(), 'login');
});
test('429 مع Retry-After يُترجم إلى دقائق، و400 و5xx و JSON تالف', async () => {
  await fails(() => err(429, 'rate_limited', { 'retry-after': '290' }), 'محاولات كثيرة. حاول بعد 5 دقيقة.');
  await fails(() => err(429, 'rate_limited'), 'محاولات كثيرة. انتظر قليلًا ثم حاول مرة أخرى.');
  await fails(() => err(400, 'validation_failed'), 'تحقق من رقم الهاتف وكلمة المرور.');
  await fails(() => err(503, 'x'), 'حدث خطأ في الخادم. حاول لاحقًا.');
  await fails(() => res(200, '{"user":', { 'content-type': 'application/json' }), 'ردّ الخادم غير صالح. حاول لاحقًا.');
});
test('ردّ ناجح بمستخدم/دور/جلسة غير صالحة لا يُنشئ جلسة', async () => {
  // الخادم أنشأ جلسة لا نقبلها (مستخدم غير معروف الشكل): لا تبقى حيّة — طلب إبطال ثانٍ بأفضل جهد (11.7.2.2)
  const t1 = await fails(() => res(200, { user: serverUser({ role: 'superuser' }), session: sessionOf(1) }), 'ردّ الخادم غير صالح. حاول لاحقًا.', 2);
  assert.match(t1.calls[1].url, /\/v1\/auth\/logout$/);
  assert.deepEqual(t1.calls[1].body, { refreshToken: 'REFRESH-1' });
  await fails(() => res(200, { user: serverUser({ id: 'abc' }), session: sessionOf(1) }), 'ردّ الخادم غير صالح. حاول لاحقًا.', 2);
  const t = await fails(() => res(200, { user: serverUser(), session: { accessToken: 'x' } }), 'ردّ الخادم غير صالح. حاول لاحقًا.');
  assert.equal(t.run('BackendAuth.currentUser()'), null);
});
test('رسالة الخادم الإنجليزية أو أي تفاصيل لا تظهر للمستخدم', async () => {
  const t = await fails(() => res(401, { error: { code: 'invalid_credentials', message: 'Invalid phone number or password', requestId: 'req-SECRET' } }), 'بيانات الدخول غير صحيحة.');
  assert.ok(!/req-SECRET|Invalid phone/.test(t.env.screen()));
});

test('مدخلات ناقصة/بريد/هاتف غير صالح/كلمة مرور طويلة: لا طلب شبكة', async () => {
  const cases = [['', PASSWORD, 'أدخل رقم الهاتف وكلمة المرور.'], ['07701234567', '', 'أدخل رقم الهاتف وكلمة المرور.'],
    ['a@b.co', PASSWORD, 'تسجيل الدخول عبر الخادم يتم برقم الهاتف فقط.'], ['12345', PASSWORD, 'رقم الهاتف غير صحيح. مثال: 07701234567']];
  for (const [id, pw, msg] of cases) {
    const t = remote(() => loginOk(1));
    await t.login(id, pw);
    assert.equal(t.env.els.loginError.textContent, msg);
    assert.equal(t.calls.length, 0);
  }
  const t = remote(() => loginOk(1));
  await t.login('07701234567', 'x'.repeat(5000));
  assert.match(t.env.els.loginError.textContent, /طويل جدًا/);
  assert.equal(t.calls.length, 0);
});

test('نقرتان متتاليتان: طلب دخول واحد فقط', async () => {
  let release;
  const gate = new Promise(r => { release = r; });
  const t = remote(async () => { await gate; return loginOk(1); });
  t.env.run("go('login')"); t.set('loginIdentifier', '07701234567'); t.set('loginPassword', PASSWORD);
  const p1 = t.run('handleLoginSubmit()');
  const p2 = t.run('handleLoginSubmit()');
  await tick();
  release();
  await Promise.all([p1, p2]);
  assert.equal(t.calls.length, 1);
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
});

test('عنوان مضبوط لكنه غير صالح: يفشل الدخول برسالة إعداد، ولا رجوع إلى الحسابات المحلية', async () => {
  const t = remote(() => loginOk(1), { baseUrl: 'not a url' });
  assert.equal(t.run('AuthService.isRemote()'), true);
  await t.login();
  assert.equal(t.env.els.loginError.textContent, 'إعداد الاتصال بالخادم غير صحيح.');
  assert.equal(t.calls.length, 0);
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
});

/* ---------------- خروج ---------------- */

test('خروج: الواجهة تُمسح فورًا ثم POST /v1/auth/logout برمز التجديد، والجلسة تنتهي في العميل', async () => {
  let release;
  const gate = new Promise(r => { release = r; });
  const t = remote(async c => (c.url.endsWith('/logout') ? (await gate, res(204)) : loginOk(1)));
  await t.login();
  t.env.run("go('account')");
  t.env.run('handleLogout()');
  assert.equal(t.run('SessionService.isLoggedIn()'), false, 'قبل رد الخادم');
  assert.equal(t.route(), 'home');
  await tick(); release(); await tick(); await tick();
  const out = t.calls[1];
  assert.equal(out.url, 'https://api.test/v1/auth/logout');
  assert.equal(out.method, 'POST');
  assert.deepEqual(out.body, { refreshToken: 'REFRESH-1' });
  assert.equal(out.headers.Authorization, undefined);
  assert.equal(t.run('BackendAuth.api().hasSession()'), false);
  assert.ok(!t.toast() || !/تعذّر إبلاغ الخادم/.test(t.toast()));
});

test('فشل إبلاغ الخادم بالخروج: يخرج المستخدم محليًا ويُنبَّه برسالة عربية', async () => {
  const t = remote(c => { if (c.url.endsWith('/logout')) throw new TypeError('down'); return loginOk(1); });
  await t.login();
  t.env.run('handleLogout()');
  await tick(); await tick(); await tick();
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.run('BackendAuth.api().hasSession()'), false);
  assert.match(t.toast(), /تعذّر إبلاغ الخادم/);
});

test('خروج بلا جلسة: لا طلب شبكة', async () => {
  const t = remote(() => res(204));
  t.env.run('handleLogout()');
  await tick(); await tick();
  assert.equal(t.calls.length, 0);
  assert.equal(t.route(), 'home');
});

test('بعد الخروج يمكن الدخول من جديد، والطلب بعد الخروج لا يحمل رمزًا', async () => {
  const t = remote(c => (c.url.endsWith('/logout') ? res(204) : c.url.endsWith('/login') ? loginOk(t.calls.length) : res(200, { ok: 1 })));
  await t.login();
  t.env.run('handleLogout()'); await tick(); await tick(); await tick();
  await assert.rejects(t.run("BackendAuth.api().get('/v1/me/x')"), e => e.kind === 'auth' && e.code === 'not_authenticated');
  await t.login();
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
});

/* ---------------- الرموز وعدم تسريب الأسرار ---------------- */

test('الرمز يُرسل مع طلبات لاحقة بعقد Bearer، ولا يظهر في أي مكان آخر', async () => {
  const t = remote(c => (c.url.endsWith('/login') ? loginOk(1) : res(200, { ok: 1 })));
  await t.login();
  await t.run("BackendAuth.api().get('/v1/me/anything')");
  assert.equal(t.calls[1].headers.Authorization, 'Bearer ACCESS-1');
});

test('لا أسرار في localStorage ولا في console ولا في الصفحة: كلمة المرور والرموز', async () => {
  const logged = [];
  const orig = {};
  ['log', 'info', 'warn', 'error', 'debug'].forEach(k => { orig[k] = console[k]; console[k] = (...a) => logged.push(a.map(String).join(' ')); });
  let t;
  try {
    t = remote(c => (c.url.endsWith('/login') ? loginOk(1) : c.url.endsWith('/logout') ? res(204) : res(200, { ok: 1 })));
    await t.login();
    await t.run("BackendAuth.api().get('/v1/me/anything')");
    t.env.run("go('account')");
    t.env.run('handleLogout()'); await tick(); await tick(); await tick();
    const failing = remote(() => err(401, 'invalid_credentials'));
    await failing.login();
    t.failing = failing;
  } finally { Object.assign(console, orig); }
  const everything = JSON.stringify(t.store) + JSON.stringify(t.failing.store) + logged.join('|') + JSON.stringify(t.env.els) + JSON.stringify(t.failing.env.els);
  for (const secret of [PASSWORD, 'ACCESS-1', 'REFRESH-1']) assert.ok(!everything.includes(secret), 'تسرّب: ' + secret);
  assert.ok(!Object.keys(t.store).some(k => /token|session/i.test(k) && t.store[k] !== undefined && /ACCESS|REFRESH/.test(t.store[k])));
});

test('الواجهة العامة للجسر والعميل لا تكشف الرموز', async () => {
  const t = remote(() => loginOk(1));
  await t.login();
  const api = t.run('BackendAuth.api()');
  assert.ok(!JSON.stringify(api).includes('ACCESS-1'));
  assert.ok(!Object.keys(api).some(k => /^(getSession|getToken|accessToken|refreshToken|session)$/.test(k)));
  assert.ok(!JSON.stringify(t.run('BackendAuth.currentUser()')).includes('ACCESS'));
  assert.ok(!Object.keys(t.run('BackendAuth')).some(k => /token|password/i.test(k)));
});

/* ---------------- فقدان الجلسة ---------------- */

async function expired(t) {
  // رمز الوصول منتهٍ: الطلب التالي يجدّد، والخادم يرفض التجديد
  t.clock.t = T0 + 16 * 60e3;
}

test('رفض التجديد (onAuthLost): تُمسح الحالة، رسالة عربية، وعلى شاشة محمية يُحوَّل المستخدم إلى الدخول مع العودة', async () => {
  const t = remote(c => (c.url.endsWith('/login') ? loginOk(1) : c.url.endsWith('/refresh') ? err(401, 'unauthorized') : res(200, {})));
  await t.login();
  t.env.run("go('account')");
  await expired(t);
  await assert.rejects(t.run("BackendAuth.api().get('/v1/me/x')"), e => e.kind === 'auth' && e.code === 'session_expired');
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.run('BackendAuth.currentUser()'), null);
  assert.equal(t.route(), 'login');
  assert.equal(JSON.stringify(t.run('currentParam')), JSON.stringify({ returnTo: 'account' }));
  assert.equal(t.toast(), 'انتهت الجلسة. سجّل الدخول من جديد.');
  assert.ok(!/تسجيل الخروج/.test(t.env.screen()), 'الشاشة لا تعرض حالة مسجَّلة');
  // دخول جديد يعيد إلى account
  t.calls.length = 0;
  t.set('loginIdentifier', '07701234567'); t.set('loginPassword', PASSWORD);
});

test('فقدان الجلسة على شاشة عامة: تبقى الشاشة وتُعاد رسمها كزائر', async () => {
  const t = remote(c => (c.url.endsWith('/login') ? loginOk(1) : c.url.endsWith('/refresh') ? err(401, 'unauthorized') : res(200, {})));
  await t.login();
  t.env.run("go('cars')");
  await expired(t);
  await assert.rejects(t.run("BackendAuth.api().get('/v1/me/x')"));
  assert.equal(t.route(), 'cars');
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.toast(), 'انتهت الجلسة. سجّل الدخول من جديد.');
});

test('فقدان الجلسة من 401 ثم رفض التجديد أيضًا يعطي النتيجة نفسها', async () => {
  const t = remote(c => (c.url.endsWith('/login') ? loginOk(1) : c.url.endsWith('/refresh') ? err(401, 'unauthorized') : err(401, 'unauthorized')));
  await t.login();
  await assert.rejects(t.run("BackendAuth.api().get('/v1/me/x')"));
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.route(), 'login' === t.route() ? 'login' : t.route());
});

test('تجديد ناجح بعد انتهاء رمز الوصول: تبقى الجلسة، والخروج يستعمل رمز التجديد المُدوَّر', async () => {
  const t = remote(c => (c.url.endsWith('/login') ? loginOk(1) : c.url.endsWith('/refresh') ? res(200, { user: serverUser(), session: sessionOf(2) }) : c.url.endsWith('/logout') ? res(204) : res(200, { ok: 1 })));
  await t.login();
  await expired(t);
  await t.run("BackendAuth.api().get('/v1/me/x')");
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
  assert.equal(t.calls[2].headers.Authorization, 'Bearer ACCESS-2');
  t.env.run('handleLogout()'); await tick(); await tick(); await tick();
  const out = t.calls.find(c => c.url.endsWith('/logout'));
  assert.deepEqual(out.body, { refreshToken: 'REFRESH-2' });
});

test('فشل تجديد عابر (شبكة): لا يُخرَج المستخدم ولا رسالة انتهاء جلسة', async () => {
  const t = remote(c => { if (c.url.endsWith('/login')) return loginOk(1); throw new TypeError('down'); });
  await t.login();
  await expired(t);
  await assert.rejects(t.run("BackendAuth.api().get('/v1/me/x')"), e => e.kind === 'network');
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
  assert.ok(!t.toast() || !/انتهت الجلسة/.test(t.toast()));
});

test('خروج أثناء تجديد جارٍ: لا تُحيا الجلسة القديمة، ويُبطَل الرمز المُدوَّر', async () => {
  let releaseRefresh;
  const gate = new Promise(r => { releaseRefresh = r; });
  const t = remote(async c => {
    if (c.url.endsWith('/login')) return loginOk(1);
    if (c.url.endsWith('/refresh')) { await gate; return res(200, { user: serverUser(), session: sessionOf(2) }); }
    if (c.url.endsWith('/logout')) return res(204);
    return res(200, {});
  });
  await t.login();
  await expired(t);
  const req = t.run("BackendAuth.api().get('/v1/me/x')").catch(e => e);
  await tick();
  t.env.run('handleLogout()');          // الواجهة تُمسح فورًا
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  releaseRefresh();
  await req; await tick(); await tick(); await tick();
  assert.equal(t.run('BackendAuth.api().hasSession()'), false, 'الجلسة لم تُحيَ');
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  const logouts = t.calls.filter(c => c.url.endsWith('/logout'));
  assert.deepEqual(logouts.map(c => c.body.refreshToken), ['REFRESH-2'], 'أُبطل الرمز المُدوَّر الأحدث وحده');
});

/* ---------------- إعادة التحميل ---------------- */

test('إعادة تحميل الصفحة: لا استعادة للجلسة (الرموز في الذاكرة فقط) ولا شيء مخزَّن، والحالة زائر', async () => {
  const t = remote(() => loginOk(1));
  await t.login();
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
  const reloaded = remote(() => res(200, {}), { store: t.store });   // مثل تحميل جديد بالتخزين نفسه
  assert.equal(reloaded.run('SessionService.isLoggedIn()'), false);
  assert.equal(reloaded.run('SessionService.getCurrentUser()'), null);
  assert.equal(reloaded.run('BackendAuth.api().hasSession()'), false);
  assert.equal(reloaded.calls.length, 0, 'لا محاولة استعادة عبر الشبكة');
  assert.ok(!JSON.stringify(t.store).match(/ACCESS|REFRESH|accessToken|refreshToken/));
});

test('جلسة محلية تجريبية قديمة في التخزين لا تظهر ولا تُمسّ في وضع الخادم', () => {
  const local = makeEnv();
  local.run("AuthService.login('07701234567', '123456')");   // قد ينجح أو لا؛ المهم ما في التخزين بعده
  const demo = JSON.parse(local.run("JSON.stringify(DEMO_ACCOUNTS[0])"));
  const r = JSON.parse(local.run(`JSON.stringify(AuthService.login(${JSON.stringify(demo.identifier)}, ${JSON.stringify(demo.password)}))`));
  assert.equal(r.ok, true);
  const before = JSON.stringify(local.store);
  assert.ok(/najaf\.session/.test(Object.keys(local.store).join(',')), 'هناك جلسة محلية');
  const t = remote(() => res(200, {}), { store: local.store });
  const before2 = JSON.stringify(local.store);   // بعد إقلاع الاختبار (الإقلاع المحلي في الاختبار يجدّد الجلسة قبل تفعيل وضع الخادم)
  assert.equal(t.run('SessionService.isLoggedIn()'), false, 'لا تُقرأ الجلسة المحلية في وضع الخادم');
  assert.equal(t.run('SessionService.updateSession()'), null);
  assert.equal(JSON.stringify(local.store), before2, 'ولا تُمسح ولا تُعدَّل');
});

/* ---------------- التسجيل لم يُربط ---------------- */

test('التسجيل المحلي معطّل في وضع الخادم: لا حساب محلي ولا جلسة', () => {
  const t = remote(() => res(200, {}));
  const before = t.run('UsersRepository.getAll().length');
  const r = JSON.parse(t.run(`JSON.stringify(AuthService.register({ name: 'اسم طويل', phone: '07712345678', password: '123456', confirmPassword: '123456', accountType: 'user' }))`));
  assert.equal(r.ok, false);
  assert.equal(r.error, 'إنشاء الحساب عبر الخادم سيتوفر في خطوة لاحقة.');
  assert.equal(t.run('UsersRepository.getAll().length'), before);
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  assert.equal(t.calls.length, 0);
});

/* ---------------- اتساق الواجهة لمستخدم الخادم ---------------- */

test('عرض الشاشات الرئيسية لمستخدم خادم (عضو/تاجر معلّق/مدير) لا يرمي ولا يكسر الواجهة', async () => {
  for (const u of [{}, { role: 'dealer', status: 'pending', id: '9' }, { role: 'admin', id: '2' }]) {
    const t = remote(() => loginOk(1, u));
    await t.login();
    for (const r of ['home', 'showrooms', 'cars', 'map', 'favorites', 'recentCars', 'memberCars', 'account', 'myMemberCars', 'addMemberCar', 'dealerHome', 'adminHome', 'adminUsers', 'login', 'register']) {
      t.env.run(`go('${r}')`);
      assert.ok(t.env.screen().length > 50, r + ' فارغة');
    }
    assert.deepEqual(t.env.errors, []);
    t.env.run('toggleFavorite(1)');        // مفضلة محلية تجريبية: لا استثناء حتى لو لم تُحفظ لمعرّف الخادم
  }
});

test('تسجيل الدخول والخروج يعملان من جديد بعد فقدان الجلسة (دورة كاملة)', async () => {
  let phase = 0;
  const t = remote(c => {
    if (c.url.endsWith('/login')) return loginOk(++phase);
    if (c.url.endsWith('/refresh')) return err(401, 'unauthorized');
    if (c.url.endsWith('/logout')) return res(204);
    return res(200, {});
  });
  await t.login();
  await expired(t);
  await assert.rejects(t.run("BackendAuth.api().get('/v1/me/x')"));
  assert.equal(t.run('SessionService.isLoggedIn()'), false);
  t.clock.t = T0;
  await t.login();
  assert.equal(t.run('SessionService.isLoggedIn()'), true);
  await t.run("BackendAuth.api().get('/v1/me/x')");
  assert.equal(t.calls[t.calls.length - 1].headers.Authorization, 'Bearer ACCESS-2');
});

/* ---------------- حراس المصدر ---------------- */

test('الجسر: لا console ولا تخزين ولا fetch ولا كوكيز، وSessionService لا تكتب جلسة محلية في وضع الخادم', () => {
  const strip = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  const bridge = strip('api/authBridge.js');
  for (const bad of [/\bconsole\./, /localStorage|sessionStorage|indexedDB|document\.cookie|AppStorage|Repository/, /\bfetch\s*\(/, /\beval\(|new Function/]) assert.ok(!bad.test(bridge), String(bad));
  const s = strip('services/sessionService.js');
  assert.match(s, /function login\(userId\) \{\s*if \(_remote\(\)\) return;/);
  assert.match(s, /function getCurrentUser\(\) \{\s*if \(_remote\(\)\) return BackendAuth\.currentUser\(\);/);
  const login = strip('screens/login.js') + strip('navigation/actions.js');
  assert.ok(!/localStorage/.test(login));
});

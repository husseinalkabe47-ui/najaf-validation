/* بطاقة السيارة (المرحلة 10 / الجزء 3) — نفس لغة التصميم (card/car-card/price/badge/btn-primary) مع تسلسل أوضح:
   العنوان ← السعر ← المواصفات الموجزة (سنة • ناقل حركة • وقود) ← المسافة ← المعرض/الموقع ← الحالة ← زر العرض.
   عرض انتقائي: لا صف ولا «—» لقيمة ناقصة أو غير صالحة (السعر الناقص «السعر غير محدد»). الجذر class="card car-card" حرفيًا
   (تعتمد عليه الاختبارات)، والحالة في data-status لتعتيم المباعة. سجل معطوب ← '' فلا تسقط القائمة.
   سيارة المعرض: اسم المعرض من بيانات المعرض الظاهر للمشاهد فقط. سيارة العضو: الموقع + «من عضو» (+ حالتها إن لم تكن نشطة، لمالكها). */
function CarCard(c) {
  try { return _carCardHtml(c); } catch (e) { console.error('[CarCard]', e); return ''; }
}

/* ---- (11.7-A) وضع الخادم: بطاقة سيارة من /v1/public/cars (معرّفات الخادم نصية؛ بلا مفضلة ولا صور بعد) ---- */
function RemoteCarCard(c) {
  try {
    if (!c || typeof c !== 'object' || !/^[1-9][0-9]{0,18}$/.test(String(c.id))) return '';
    const isMember = c.sourceType === 'member';
    const sub = [yearText(c.year), plainText(c.transmission), plainText(c.fuelType)].filter(Boolean).join(' • ');
    const price = carPriceText(c), mileage = validMileage(c.mileage);
    const loc = isMember ? plainText(c.location) : '';
    const where = loc ? `<p class="card-row card-location">📍 ${esc(loc)}</p>` : '';
    const badges = isMember ? sourceBadge('member') + (c.status !== 'active' ? memberCarStatusBadge(c.status) : '') : carStatusBadge(c.status);
    const known = isMember ? MEMBER_CAR_STATUS_LABEL : CAR_STATUS_LABEL;
    const st = (typeof c.status === 'string' && Object.prototype.hasOwnProperty.call(known, c.status)) ? ` data-status="${c.status}"` : '';
    return `
  <div class="card car-card"${st}>
    <div class="card-img" onclick="go('carDetails','${c.id}')">${CAR_PLACEHOLDER}</div>
    <div class="card-body" onclick="go('carDetails','${c.id}')">
      <p class="card-title">🚘 ${esc(carTitle(c))}</p>
      ${price !== null ? `<p class="price">💰 ${price}</p>` : `<p class="price muted">السعر غير محدد</p>`}
      ${sub ? `<p class="card-sub">${esc(sub)}</p>` : ''}
      ${mileage !== null ? `<p class="card-row card-mileage">🛣️ ${km(mileage)}</p>` : ''}
      ${where}
      ${badges ? `<div class="card-badges">${badges}</div>` : ''}
      <button class="btn-primary">عرض السيارة</button>
    </div>
  </div>`;
  } catch (e) { console.error('[RemoteCarCard]', e); return ''; }
}
/** (11.7-B) سبب الرفض/الإيقاف لإعلان المستخدم نفسه (من الخادم). */
function OwnAdReason(c) { const r = BackendMember.reasonOf(c); return r ? `<div class="reason-box">السبب: ${esc(r)}</div>` : ''; }
/** (11.7-B) زر «مباعة»: الخادم يسمح للمالك به للإعلان النشط فقط. */
function OwnAdSoldButton(c) { return BackendMember.canSell(c) ? `<button onclick="handleMemberCarStatusChange('${c.id}')">تحديد كمباعة</button>` : ''; }
/** بوابة حالة قوائم الخادم: '' إن كانت النتائج جاهزة (أو فارغة بنجاح)، وإلا HTML التحميل/الخطأ/المنع (المنطق هنا لا في الشاشات). */
function RemoteGate(st, o) { return (st.status === 'ready' || st.status === 'empty') ? '' : RemoteState(st, o); }
/** قسم أفقي في الرئيسية: { n, body } بحسب حالة القسم (جاهز ← صف أفقي، فارغ ← empty، غير ذلك ← تحميل/خطأ). */
function RemoteSection(st, card, empty, o) {
  if (st.status === 'ready') return { n: st.items.length, body: `<div class="hscroll">${st.items.map(card).join('')}</div>` };
  return { n: 0, body: st.status === 'empty' ? empty : RemoteState(st, o) };
}
/** تذييل قائمة الخادم: خطأ «المزيد» (القائمة تبقى) + «جارٍ التحميل…» أو زر «عرض المزيد». st = حالة BackendCatalog.list، moreFn = اسم دالة عامة. */
function RemoteMoreFooter(st, moreFn) {
  return (st.error ? `<div class="form-note" role="alert">${esc(st.error)}</div>` : '')
    + (st.more ? '<div class="placeholder" role="status" aria-busy="true"><b>جارٍ تحميل المزيد…</b></div>'
      : st.nextBefore ? `<button type="button" class="action-btn" style="width:100%;margin-top:10px" onclick="${moreFn}()">عرض المزيد</button>` : '');
}
/** عدّاد نتائج الخادم: العدد المعروض حتى الآن (+ «والمزيد» إن وُجدت صفحة تالية) */
function remoteCountText(n, st) { return `${carCountLabel(n)}${st && st.nextBefore ? ' (والمزيد)' : ''}`; }

function _carCardHtml(c) {
  if (!c || typeof c !== 'object' || !Number.isFinite(c.id)) return '';
  const isFav = isFavorite(c.id);
  const isMember = c.sourceType === 'member';
  const route = isMember ? 'memberCarDetails' : 'carDetails';
  const sub = [yearText(c.year), plainText(c.transmission), plainText(c.fuelType)].filter(Boolean).join(' • ');
  const price = carPriceText(c), mileage = validMileage(c.mileage);
  let where = '', badges = '';
  if (isMember) {
    const loc = plainText(c.location);
    where = loc ? `<p class="card-row card-location">📍 ${esc(loc)}</p>` : '';
    badges = sourceBadge('member') + (c.status !== 'active' ? memberCarStatusBadge(c.status) : '');
  } else {
    const sh = getVisibleShowroomById(c.showroomId), name = sh ? plainText(sh.name) : '';
    // هوية المعرض: زر يفتح صفحة المعرض القائمة (وفيها الخريطة والتواصل) — لا يفتح التفاصيل لأن البطاقة نفسها تفتحها
    where = name ? `<button type="button" class="card-row card-showroom" aria-label="${esc('عرض المعرض: ' + name)}" onclick="event.stopPropagation();go('showroomDetails',${sh.id})">🏢 ${esc(name)}</button>` : '';
    badges = carStatusBadge(c.status);
  }
  const known = isMember ? MEMBER_CAR_STATUS_LABEL : CAR_STATUS_LABEL;
  const st = (typeof c.status === 'string' && Object.prototype.hasOwnProperty.call(known, c.status)) ? ` data-status="${c.status}"` : '';   // رمز معرَّف فقط
  return `
  <div class="card car-card"${st}>
    <button type="button" class="fav-btn" aria-label="${isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}" aria-pressed="${isFav ? 'true' : 'false'}" onclick="event.stopPropagation();handleFavoriteToggle(${c.id})">${isFav ? '❤️' : '🤍'}</button>
    <div class="card-img" onclick="go('${route}',${c.id})">${CarImageInner(c)}</div>
    <div class="card-body" onclick="go('${route}',${c.id})">
      <p class="card-title">🚘 ${esc(carTitle(c))}</p>
      ${price !== null ? `<p class="price">💰 ${price}</p>` : `<p class="price muted">السعر غير محدد</p>`}
      ${sub ? `<p class="card-sub">${esc(sub)}</p>` : ''}
      ${mileage !== null ? `<p class="card-row card-mileage">🛣️ ${km(mileage)}</p>` : ''}
      ${where}
      ${badges ? `<div class="card-badges">${badges}</div>` : ''}
      <button class="btn-primary">عرض السيارة</button>
    </div>
  </div>`;
}

/* ---- أجزاء مشتركة لشاشتي تفاصيل السيارة (معرض/عضو): تجميع المعلومات في أقسام، وكل قسم يظهر بما فيه من قيم فقط ---- */
/** السعر البارز: القيمة إن صحّت، وإلا «السعر غير محدد» */
function DetailPrice(c) {
  const p = carPriceText(c);
  return p !== null ? `<p class="price big">💰 ${p}</p>` : `<p class="price big muted">السعر غير محدد</p>`;
}
/** صف الحالة: «الحالة» + الشارة (محذوف إن لم تُعرَّف الحالة) */
function DetailStatusRow(badgeHtml) {
  return badgeHtml ? `<div class="status-row"><span class="meta-l">الحالة</span>${badgeHtml}</div>` : '';
}
/** قسم المواصفات: items = [[label, valueHtmlSafe]]؛ الخانات الفارغة تُحذف، ولا قسم إن لم تبقَ خانة */
function DetailSpecs(items) {
  const rows = items.filter(it => it && it[1]);
  return rows.length
    ? `<div class="info-block"><h3>⚙️ المواصفات</h3><div class="spec-grid">${rows.map(([l, v]) => `<div class="spec-item"><div class="l">${l}</div><div class="v">${v}</div></div>`).join('')}</div></div>` : '';
}
/** قسم الوصف (نص مهرَّب) إن وُجد */
function DetailDescription(c) {
  const d = plainText(c && c.description);
  return d ? `<div class="info-block"><h3>📝 الوصف</h3><p class="sub" style="line-height:1.7;margin:0">${esc(d)}</p></div>` : '';
}
/* ---- (UX ج5) عنصرا التحكم العلويان لتفاصيل السيارة: واجهة فقط فوق الخدمات القائمة، بلا حالة ولا منطق ثانٍ ---- */
/** زر رجوع واضح (سهم + «رجوع»، button حقيقي ≥ 44px). السلوك للراوتر القائم كما هو: goBack(fallback) يعود للشاشة السابقة في سجل التنقل (بحث/أعضاء/مفضلة/رئيسية/معرض…)
    وfallback للدخول المباشر بلا سجل صالح فقط (يُنتقل إليه بلا دفع الشاشة الحالية في السجل). plain: بلا صورة تحته (شاشات «غير موجود/غير متاح»). */
function DetailBackButton(fallback, plain = false) {
  return `<div class="back-btn${plain ? ' plain' : ''}"><button type="button" class="back-pill" aria-label="رجوع" onclick="goBack('${fallback}')"><span class="bp-arrow" aria-hidden="true">→</span><span>رجوع</span></button></div>`;
}
/** زر المفضلة المدمج بجانب هوية السيارة. المصدر الوحيد للحالة isFavorite (favoritesService) والفعل handleFavoriteToggle القائم
    (الزائر ← تسجيل الدخول، العضو/التاجر/المدير ← إضافة/إزالة، مخفية/محذوفة ← not_found آمن). الاسم الوصولي وaria-pressed يتبعان الحالة. */
function DetailFavoriteButton(carId) {
  const on = isFavorite(carId);
  return `<button type="button" class="fav-inline" aria-label="${on ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}" aria-pressed="${on ? 'true' : 'false'}" onclick="handleFavoriteToggle(${carId})"><span aria-hidden="true">${on ? '♥\uFE0E' : '♡\uFE0E'}</span></button>`;
}
/** رأس الهوية: العنوان (h1) + شارة المصدر + زر المفضلة المدمج في الصف نفسه (يبقى قرب العنوان حتى مع العنوان الطويل) */
function DetailIdentity(c, badgeHtml = '') {
  return `<div class="detail-head"><div class="detail-id"><h1>${esc(carTitle(c))}</h1>${badgeHtml}</div>${DetailFavoriteButton(c.id)}</div>`;
}
/** المواصفات المشتركة: السنة/المسافة/ناقل الحركة/الوقود/اللون (كل منها بقيمتها فقط) */
function CarCoreSpecs(c) {
  const y = yearText(c.year), m = validMileage(c.mileage), t = plainText(c.transmission), f = plainText(c.fuelType), col = plainText(c.color);
  return [['السنة', y ? esc(y) : ''], ['المسافة', m !== null ? km(m) : ''], ['ناقل الحركة', esc(t)], ['الوقود', esc(f)], ['اللون', esc(col)]];
}

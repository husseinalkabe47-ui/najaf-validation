// Phase 11.9-D against a real PostgreSQL 16 (migrations 0001-0014), through the least-privilege application role: an administrator's
// manual activation and renewal with payment recording. Needs DATABASE_URL and ADMIN_DATABASE_URL (superuser: fixtures and cleanup
// ONLY); skipped visibly without them. The service clock is injected so the date rules are exact; every row the suite creates is
// removed afterwards (audit rows are append-only and stay, keyed by the fixtures' own ids).
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgSubscriptionsRepository } from '../../src/subscriptions/repository.ts';
import type { SubscriptionsRepository } from '../../src/subscriptions/repository.ts';
import { addMonthsUtc, createSubscriptionsService, SubscriptionsError } from '../../src/subscriptions/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const T0 = new Date('2026-10-14T12:00:00Z');

describe('manual subscriptions and payments on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let admin: Db;
  let A: Actor;
  let clock = T0;
  let repo: SubscriptionsRepository;
  let svc: ReturnType<typeof createSubscriptionsService>;
  const userIds: string[] = [];
  const showroomIds: string[] = [];
  const run = String(randomInt(100000, 999999));
  let seq = 0;
  const ref = () => `IT${run}-${++seq}`;

  const newUser = async (role: 'dealer' | 'admin'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    userIds.push(String(r.rows[0]!.id));
    return String(r.rows[0]!.id);
  };
  const newShowroom = async (): Promise<string> => {
    const owner = await newUser('dealer');
    const id = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اشتراك', 'active') RETURNING id`, [owner])).rows[0]!.id);
    showroomIds.push(id);
    return id;
  };
  const body = (showroomId: string, over: Record<string, unknown> = {}) => ({ showroomId, planCode: 'plan_3m', method: 'cash', reference: ref(), amount: 75000, paidAt: '2026-10-14T09:30:00Z', ...over });
  const counts = async (showroomId: string) => {
    const s = await admin.query<{ n: string }>(`SELECT count(*) AS n FROM subscriptions WHERE showroom_id = $1::bigint`, [showroomId]);
    const p = await admin.query<{ n: string }>(`SELECT count(*) AS n FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = $1::bigint)`, [showroomId]);
    return [Number(s.rows[0]!.n), Number(p.rows[0]!.n)];
  };
  const audits = async (entityId: string) =>
    (await admin.query<{ actor_id: string; actor_role: string; action: string; after_data: Record<string, number>; request_id: string | null }>(
      `SELECT actor_id, actor_role, action, after_data, request_id FROM audit_logs WHERE entity_type = 'subscription' AND entity_id = $1 ORDER BY id`, [entityId])).rows;

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    A = { id: await newUser('admin'), role: 'admin' };
    repo = createPgSubscriptionsRepository(app);
    svc = createSubscriptionsService({ repo, now: () => clock });
  });
  after(async () => {
    if (admin) {
      if (showroomIds.length > 0) {
        await admin.query(`DELETE FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = ANY($1::bigint[]))`, [showroomIds]);
        await admin.query(`DELETE FROM subscriptions WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM showrooms WHERE id = ANY($1::bigint[])`, [showroomIds]);
      }
      if (userIds.length > 0) await admin.query(`DELETE FROM users WHERE id = ANY($1::bigint[])`, [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  it('activates a showroom under the app role: subscription row, payment row (paid, IQD, manual) and an audit row with the actor', async () => {
    clock = T0;
    const sid = await newShowroom();
    const r = await svc.grant(A, body(sid, { reference: `ACT-${run}` }), { requestId: 'it-req-1' });
    assert.equal(r.outcome, 'activated');
    assert.deepEqual([r.subscription.status, r.subscription.periodStart, r.subscription.periodEnd, r.subscription.plan.code], ['active', T0.toISOString(), '2027-01-14T12:00:00.000Z', 'plan_3m']);
    const sub = (await admin.query<{ status: string; granted_by: string; current_period_end: Date }>(`SELECT status, granted_by, current_period_end FROM subscriptions WHERE id = $1::bigint`, [r.subscription.id])).rows[0]!;
    assert.deepEqual([sub.status, String(sub.granted_by), sub.current_period_end.toISOString()], ['active', A.id, '2027-01-14T12:00:00.000Z']);
    const pay = (await admin.query<{ amount: string; currency: string; status: string; provider: string; provider_ref: string; recorded_by: string; paid_at: Date }>(`SELECT amount, currency, status, provider, provider_ref, recorded_by, paid_at FROM payments WHERE id = $1::bigint`, [r.payment.id])).rows[0]!;
    assert.deepEqual([pay.amount, pay.currency, pay.status, pay.provider, pay.provider_ref, String(pay.recorded_by), pay.paid_at.toISOString()], ['75000', 'IQD', 'paid', 'manual', `cash:ACT-${run}`, A.id, '2026-10-14T09:30:00.000Z']);
    const rows = await audits(r.subscription.id);
    assert.equal(rows.length, 1);
    assert.deepEqual([String(rows[0]!.actor_id), rows[0]!.actor_role, rows[0]!.action, rows[0]!.request_id], [A.id, 'admin', 'subscription.activate', 'it-req-1']);
    assert.equal(rows[0]!.after_data['paymentId'], Number(r.payment.id));
    assert.equal(rows[0]!.after_data['amount'], 75000);
  });

  it('renews before expiry from the CURRENT end on the same row (version +1), and the history keeps both payments', async () => {
    clock = T0;
    const sid = await newShowroom();
    const first = await svc.grant(A, body(sid));
    clock = new Date('2026-12-01T00:00:00Z'); // still running (ends 14 Jan 2027)
    const r = await svc.grant(A, body(sid, { amount: 80000 }));
    assert.equal(r.outcome, 'renewed');
    assert.equal(r.subscription.id, first.subscription.id);
    assert.deepEqual([r.subscription.periodStart, r.subscription.periodEnd, r.subscription.version], [T0.toISOString(), '2027-04-14T12:00:00.000Z', 2]);
    assert.deepEqual(await counts(sid), [1, 2]);
    const rows = await audits(r.subscription.id);
    assert.deepEqual(rows.map((x) => x.action), ['subscription.activate', 'subscription.renew']);
    assert.equal(rows[1]!.after_data['oldPeriodEnd'], Math.floor(new Date('2027-01-14T12:00:00Z').getTime() / 1000));
    assert.equal(rows[1]!.after_data['newPeriodEnd'], Math.floor(new Date('2027-04-14T12:00:00Z').getTime() / 1000));
    const h = await svc.history(A, sid);
    assert.deepEqual(h.subscriptions.map((s) => s.payments.map((p) => p.amount)), [[80000, 75000]]);
  });

  it('renews after expiry from the renewal date: the old row is closed and kept, a new row starts (any plan), one live row at all times', async () => {
    clock = T0;
    const sid = await newShowroom();
    const first = await svc.grant(A, body(sid));
    clock = new Date('2027-03-01T08:00:00Z'); // the 3-month plan ended on 14 Jan 2027
    const r = await svc.grant(A, body(sid, { planCode: 'plan_6m' }));
    assert.equal(r.outcome, 'renewed_after_expiry');
    assert.notEqual(r.subscription.id, first.subscription.id);
    assert.deepEqual([r.subscription.periodStart, r.subscription.periodEnd], ['2027-03-01T08:00:00.000Z', '2027-09-01T08:00:00.000Z']);
    const all = (await admin.query<{ id: string; status: string; current_period_end: Date }>(`SELECT id, status, current_period_end FROM subscriptions WHERE showroom_id = $1::bigint ORDER BY id`, [sid])).rows;
    assert.deepEqual(all.map((s) => s.status), ['expired', 'active']);
    assert.equal(all[0]!.current_period_end.toISOString(), '2027-01-14T12:00:00.000Z'); // history untouched
    assert.deepEqual((await audits(first.subscription.id)).map((x) => x.action), ['subscription.activate', 'subscription.close_lapsed']);
    assert.deepEqual(await counts(sid), [2, 2]);
  });

  it('a different plan while a live one is still running is refused (409) and nothing changes', async () => {
    clock = T0;
    const sid = await newShowroom();
    await svc.grant(A, body(sid));
    await assert.rejects(() => svc.grant(A, body(sid, { planCode: 'plan_12m' })), (e) => e instanceof SubscriptionsError && e.code === 'plan_mismatch');
    assert.deepEqual(await counts(sid), [1, 1]);
  });

  it('the same payment is never processed twice: sequentially (409) and concurrently (exactly one wins), with no extra rows', async () => {
    clock = T0;
    const sid = await newShowroom();
    const dup = ref();
    await svc.grant(A, body(sid, { reference: dup }));
    await assert.rejects(() => svc.grant(A, body(sid, { reference: dup })), (e) => e instanceof SubscriptionsError && e.code === 'duplicate_payment');
    assert.deepEqual(await counts(sid), [1, 1]);
    const other = await newShowroom();
    const race = ref();
    const results = await Promise.allSettled([svc.grant(A, body(other, { reference: race })), svc.grant(A, body(other, { reference: race }))]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    const lost = results.find((x) => x.status === 'rejected') as PromiseRejectedResult;
    assert.ok(lost.reason instanceof SubscriptionsError && lost.reason.code === 'duplicate_payment');
    assert.deepEqual(await counts(other), [1, 1]);
    // the same reference by another showroom is the same payment too
    const third = await newShowroom();
    await assert.rejects(() => svc.grant(A, body(third, { reference: dup })), (e) => e instanceof SubscriptionsError && e.code === 'duplicate_payment');
  });

  it('two different payments for one showroom at once serialize: one activation then one renewal, a single live subscription', async () => {
    clock = T0;
    const sid = await newShowroom();
    const [a, b] = await Promise.all([svc.grant(A, body(sid)), svc.grant(A, body(sid))]);
    assert.deepEqual([a.outcome, b.outcome].sort(), ['activated', 'renewed']);
    assert.deepEqual(await counts(sid), [1, 2]);
    const end = (await admin.query<{ e: Date }>(`SELECT current_period_end AS e FROM subscriptions WHERE showroom_id = $1::bigint`, [sid])).rows[0]!.e;
    assert.equal(end.toISOString(), '2027-04-14T12:00:00.000Z'); // 3 + 3 months from the first start
  });

  it('is atomic: a failure after the subscription change (payment insert, audit write) rolls back the subscription AND the payment', async () => {
    clock = T0;
    const sid = await newShowroom();
    await svc.grant(A, body(sid));
    const endBefore = (await admin.query<{ e: Date; v: number }>(`SELECT current_period_end AS e, version AS v FROM subscriptions WHERE showroom_id = $1::bigint`, [sid])).rows[0]!;
    const total = async () => Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM audit_logs WHERE entity_type = 'subscription'`)).rows[0]!.n);
    const auditsBefore = await total();
    const failing = (patch: (t: Parameters<Parameters<SubscriptionsRepository['transaction']>[0]>[0]) => object): SubscriptionsRepository => ({ ...repo, transaction: (fn) => repo.transaction((t) => fn({ ...t, ...patch(t) })) });
    const brokenPayment = createSubscriptionsService({ repo: failing(() => ({ insertPayment: async () => { throw new Error('payment insert failed'); } })), now: () => clock });
    const brokenAudit = createSubscriptionsService({ repo: failing((t) => ({ audit: { record: async (e) => { if (e.action === 'subscription.renew') throw new Error('audit write failed'); await t.audit.record(e); } } })), now: () => clock });
    await assert.rejects(() => brokenPayment.grant(A, body(sid)), /payment insert failed/);
    await assert.rejects(() => brokenAudit.grant(A, body(sid)), /audit write failed/);
    const endAfter = (await admin.query<{ e: Date; v: number }>(`SELECT current_period_end AS e, version AS v FROM subscriptions WHERE showroom_id = $1::bigint`, [sid])).rows[0]!;
    assert.deepEqual([endAfter.e.toISOString(), endAfter.v], [endBefore.e.toISOString(), endBefore.v]);
    assert.deepEqual(await counts(sid), [1, 1]);
    assert.equal(await total(), auditsBefore);
    assert.equal((await svc.grant(A, body(sid))).outcome, 'renewed'); // nothing was left half-done
  });

  it('refuses invalid input, an unknown showroom or plan, and every non-administrator; nothing is written', async () => {
    clock = T0;
    const sid = await newShowroom();
    for (const over of [{ amount: -1 }, { amount: 1.5 }, { planCode: 'free' }, { planCode: 'plan_1m' }, { paidAt: '2026-02-31' }, { paidAt: '2030-01-01' }, { method: 'bitcoin' }, { reference: '' }, { showroomId: 'abc' }]) {
      await assert.rejects(() => svc.grant(A, body(sid, over)), (e) => e instanceof SubscriptionsError && e.code === 'validation_failed', JSON.stringify(over));
    }
    await assert.rejects(() => svc.grant(A, body('999999999')), (e) => e instanceof AuthzError && e.code === 'not_found');
    for (const who of [{ id: '5', role: 'member' }, { id: '6', role: 'dealer' }, null] as Array<Actor | null>) {
      await assert.rejects(() => svc.grant(who, body(sid)), (e) => e instanceof AuthzError && e.code === 'not_found');
      await assert.rejects(() => svc.history(who, sid), (e) => e instanceof AuthzError);
    }
    assert.deepEqual(await counts(sid), [0, 0]);
  });

  it('the free plan is untouched, nothing else of the plans changes, and the app role can neither delete payments nor audit rows', async () => {
    const before = (await admin.query(`SELECT code, price, currency, is_active FROM subscription_plans ORDER BY id`)).rows;
    clock = T0;
    await svc.grant(A, body(await newShowroom()));
    assert.deepEqual((await admin.query(`SELECT code, price, currency, is_active FROM subscription_plans ORDER BY id`)).rows, before);
    await assert.rejects(app.query(`DELETE FROM payments WHERE provider = 'manual'`));
    await assert.rejects(app.query(`DELETE FROM audit_logs WHERE entity_type = 'subscription'`));
  });

  it('the calendar-month arithmetic in the service agrees with PostgreSQL', async () => {
    for (const [iso, months] of [['2026-01-31T10:00:00Z', 1], ['2028-01-31T10:00:00Z', 1], ['2026-10-14T12:00:00Z', 3], ['2026-08-31T00:00:00Z', 6], ['2024-02-29T00:00:00Z', 12], ['2026-12-31T23:59:59Z', 3]] as const) {
      const r = await admin.query<{ t: string }>(`SELECT to_char(($1::timestamptz AT TIME ZONE 'UTC') + make_interval(months => $2::int), 'YYYY-MM-DD"T"HH24:MI:SS') AS t`, [iso, months]);
      assert.equal(addMonthsUtc(new Date(iso), months).toISOString().slice(0, 19), r.rows[0]!.t, `${iso} + ${months}`);
    }
  });
});

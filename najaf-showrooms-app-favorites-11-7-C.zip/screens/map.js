/* الخريطة — بلا أي Maps API: قائمة بمواقع المعارض مع زر «الموقع على الخريطة» (رابط عادي
   يفتح تطبيق الخرائط في الهاتف) لكل معرض لديه إحداثيات. الخريطة التفاعلية لاحقًا. */
/* (11.7-A) وضع الخادم: المعارض (بإحداثياتها) من GET /v1/public/showrooms؛ الأرقام نصية فتُقتبس في onclick */
function _mapRemoteDone() { if (currentRoute === 'map') render(); }
function MapScreen() {
  const remote = BackendCatalog.isEnabled();
  let showrooms, st = null;
  if (remote) {
    st = BackendCatalog.list('/v1/public/showrooms', {}, _mapRemoteDone);
    if (st.status !== 'ready' && st.status !== 'empty') return `<div class="topbar"><h1>📍 مواقع المعارض</h1></div><div class="section">${RemoteState(st, { loading: 'جارٍ تحميل المعارض…', retry: "BackendCatalog.reload('/v1/public/showrooms', {}, _mapRemoteDone);render()" })}</div>`;
    showrooms = st.items;
  } else showrooms = searchShowrooms('');
  const idArg = s => (remote ? `'${s.id}'` : s.id);
  return `
  <div class="topbar"><h1>📍 مواقع المعارض</h1><p class="sub">اضغط «الموقع على الخريطة» لفتح الموقع في تطبيق الخرائط</p></div>
  <div class="section">
    ${showrooms.length === 0 ? EmptyState({ icon: '📍', title: 'لا توجد معارض' }) : showrooms.map(s => `
    <div class="info-block">
      <h3 onclick="go('showroomDetails',${idArg(s)})" style="cursor:pointer">🏢 ${esc(s.name)}</h3>
      <div class="info-row">📍 ${val(s.address)}</div>
      ${mapLink(s.latitude, s.longitude)
        ? `<a class="action-btn" href="${mapLink(s.latitude, s.longitude)}" target="_blank" rel="noopener">📍 الموقع على الخريطة</a>`
        : `<div class="sub">الموقع غير متوفر لهذا المعرض.</div>`}
      <button class="link-btn" onclick="go('showroomDetails',${idArg(s)})">عرض المعرض</button>
    </div>`).join('')}
    ${st ? RemoteMoreFooter(st, '_mapMore') : ''}
  </div>`;
}
function _mapMore() { BackendCatalog.more('/v1/public/showrooms', {}, _mapRemoteDone); render(); }

/* تفاصيل المعرض: اسم، صورة، وصف، هاتف، عنوان، دوام، خدمات، موقع، وسيارات المعرض */
/* (11.7-A) وضع الخادم: GET /v1/public/showrooms/:id + سياراته GET /v1/public/cars?showroomId=:id (بصفحات). 404 = «غير موجود». بلا صورة (غير مربوطة بعد). */
function _showroomCarsMore() { BackendCatalog.more('/v1/public/cars', { showroomId: String(currentParam) }, _detailsDone('showroomDetails')); render(); }
const _SR_BACK = 'showrooms';   // مسار الرجوع لوضع الخادم (الوضع المحلي يحتفظ بنداءاته الحرفية)
function _ShowroomDetailsRemote(id) {
  const done = _detailsDone('showroomDetails');
  const st = BackendCatalog.detail('showroom', id, done);
  const back = DetailBackButton(_SR_BACK, true);
  if (st.status === 'missing') return `${back}${EmptyState({ icon: '🏢', heading: true, title: 'المعرض غير موجود أو غير متاح حاليًا', actions: [{ label: 'تصفح المعارض', onclick: "go('showrooms')" }] })}`;
  if (st.status !== 'ready') return back + RemoteState(st, { loading: 'جارٍ تحميل المعرض…', retry: "BackendCatalog.reloadDetail('showroom', currentParam, _detailsDone('showroomDetails'));render()" });
  const s = st.item, services = (s.services || []).filter(Boolean);
  const cs = BackendCatalog.list('/v1/public/cars', { showroomId: id }, done);
  const carsBody = cs.status === 'ready'
    ? `<div class="list-grid" style="margin-top:10px;">${cs.items.map(RemoteCarCard).join('')}</div>${RemoteMoreFooter(cs, '_showroomCarsMore')}`
    : cs.status === 'empty'
      ? `<div class="list-grid" style="margin-top:10px;">${EmptyState({ icon: '🚘', heading: true, title: 'لا توجد سيارات في هذا المعرض حاليًا', hint: 'يمكنك تصفح سيارات المعارض الأخرى.', actions: [{ label: 'تصفح كل السيارات', onclick: "go('cars')" }] })}</div>`
      : RemoteState(cs, { loading: 'جارٍ تحميل سيارات المعرض…', retry: "BackendCatalog.reload('/v1/public/cars', { showroomId: String(currentParam) }, _detailsDone('showroomDetails'));render()" });
  return `
  ${DetailBackButton(_SR_BACK)}
  <div class="detail-hero">${SHOWROOM_PLACEHOLDER}</div>
  <div class="detail-body">
    <h1>${esc(s.name)}</h1>
    ${s.description ? `<p class="sub" style="line-height:1.7;margin-top:10px">${esc(s.description)}</p>` : ''}
    <div class="info-row">📍 ${val(s.address)}</div>
    <div class="info-row">🕐 ${val(s.workingHours)}</div>
    ${s.phone ? `<div class="info-row">📞 ${val(s.phone)}</div>` : ''}
    ${services.length ? `<div class="chips">${services.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</div>` : ''}
    ${ContactButtons({ phone: s.phone, whatsapp: s.whatsapp, lat: s.latitude, lng: s.longitude })}
    ${AdSlot('showroom_details')}
    <h2 style="margin-top:22px;font-size:15px;">سيارات المعرض${cs.status === 'ready' ? ` (${cs.items.length}${cs.nextBefore ? '+' : ''})` : ''}</h2>
    ${carsBody}
  </div>`;
}
function ShowroomDetailsScreen(id) {
  if (BackendCatalog.isEnabled()) return _ShowroomDetailsRemote(String(id));
  const access = getShowroomAccess(id);   // المسار العام: ok | hidden (موقوف/مالكه غير فعّال لمن لا يملك رؤيته) | missing
  if (access.status === 'missing') return `${DetailBackButton('showrooms', true)}${EmptyState({ icon: '🏢', heading: true, title: 'المعرض غير موجود', actions: [{ label: 'تصفح المعارض', onclick: "go('showrooms')" }] })}`;
  if (access.status === 'hidden') return `${DetailBackButton('showrooms', true)}${EmptyState({ icon: '🏢', heading: true, title: 'هذا المعرض غير متاح حاليًا', actions: [{ label: 'تصفح المعارض', onclick: "go('showrooms')" }] })}`;
  const s = access.showroom;
  const cars = getVisibleCarsByShowroom(s.id);
  const services = Array.isArray(s.services) ? s.services.filter(Boolean) : [];
  return `
  ${DetailBackButton('showrooms')}
  <div class="detail-hero">${ShowroomImageInner(s)}</div>
  <div class="detail-body">
    <h1>${esc(s.name)}</h1>
    ${showroomStatusBadge(s.status)}
    ${s.description ? `<p class="sub" style="line-height:1.7;margin-top:10px">${esc(s.description)}</p>` : ''}
    <div class="info-row">📍 ${val(s.address)}</div>
    <div class="info-row">🕐 ${val(s.workingHours)}</div>
    ${s.phone ? `<div class="info-row">📞 ${val(s.phone)}</div>` : ''}
    ${services.length ? `<div class="chips">${services.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</div>` : ''}
    ${ContactButtons({ phone: s.phone, whatsapp: s.whatsapp, lat: s.latitude, lng: s.longitude })}
    ${AdSlot('showroom_details')}
    <h2 style="margin-top:22px;font-size:15px;">سيارات المعرض (${cars.length})</h2>
    <div class="list-grid" style="margin-top:10px;">${cars.length
      ? cars.map(CarCard).join('')
      : EmptyState({ icon: '🚘', heading: true, title: 'لا توجد سيارات في هذا المعرض حاليًا', hint: 'يمكنك تصفح سيارات المعارض الأخرى.', actions: [{ label: 'تصفح كل السيارات', onclick: "go('cars')" }] })}</div>
  </div>`;
}

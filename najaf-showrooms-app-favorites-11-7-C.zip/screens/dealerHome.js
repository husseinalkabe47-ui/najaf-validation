/* «إدارة معرضي» — تفتح «سيارات معرضي» (المرحلة 7) لإضافة/تعديل/حذف سيارات المعرض.
   لا تُعرض إلا المعارض التي يحق للمستخدم إدارتها (ownerId) عبر AuthorizationService.
   (11.7.2.4) وضع الخادم: المعرض من GET /v1/dealer/showroom فقط (BackendDealer في api/authBridge.js) — لا بيانات تجريبية محلية. */
function DealerHomeScreen() {
  const user = SessionService.getCurrentUser();
  if (BackendDealer.isEnabled()) return _DealerHomeRemote(user);
  const showrooms = AuthorizationService.getManagedShowrooms();
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>🏢 إدارة معرضي</h1><p class="sub">مرحبًا ${user ? esc(user.name) : ''}</p></div>
  <div class="section">
    ${AccountCard(user)}
    <button class="action-btn" style="width:100%;margin-bottom:14px" onclick="go('myMemberCars')">📋 إعلاناتي (سياراتي الشخصية)</button>
    <h2>معرضك</h2>
    <div class="list-grid">${showrooms.map(ShowroomCard).join('') || '<div class="placeholder">لا يوجد معرض مرتبط بحسابك بعد.</div>'}</div>
    <button class="btn-primary" style="margin-top:14px" onclick="go('myShowroomCars')">🚘 سيارات معرضي (إضافة / تعديل / حذف)</button>
  </div>`;
}

/** إعادة الرسم بعد اكتمال الطلب فقط إن بقي المستخدم على الشاشة نفسها */
function _rerenderIf(route) { return () => { if (currentRoute === route) render(); }; }

/** حالة تحميل/فارغة/خطأ/غير مصرّح موحّدة لشاشات التاجر في وضع الخادم. retry = نص onclick. */
function RemoteState(st, o) {
  if (st.status === 'idle' || st.status === 'loading') return `<div class="placeholder" role="status" aria-busy="true"><span class="ic" aria-hidden="true">⏳</span><b>${esc(o.loading)}</b></div>`;
  if (st.status === 'empty') return EmptyState(o.empty);
  if (st.status === 'denied') return EmptyState({ icon: '⛔', title: st.error, actions: [{ label: 'العودة للرئيسية', onclick: "go('home')", primary: false }] });
  return `<div role="alert">${EmptyState({ icon: '⚠️', title: st.error || 'تعذّر تحميل البيانات من الخادم. حاول مرة أخرى.', actions: [{ label: 'إعادة المحاولة', onclick: o.retry }] })}</div>`;
}

function _DealerHomeRemote(user) {
  let st = BackendDealer.showroom();
  if (st.status === 'idle') { BackendDealer.loadShowroom(_rerenderIf('dealerHome')); st = BackendDealer.showroom(); }
  const s = st.status === 'ready' ? st.data : null;
  const body = s ? `
    <div class="card">
      <div class="card-body">
        <p class="card-title">🏢 ${esc(plainText(s.name) || 'معرض')}</p>
        ${s.address ? `<p class="card-row">📍 ${esc(s.address)}</p>` : ''}
        ${s.phone ? `<p class="card-row">📞 <span dir="ltr">${esc(s.phone)}</span></p>` : ''}
        ${showroomStatusBadge(s.status)}
      </div>
    </div>
    <button class="btn-primary" style="margin-top:14px" onclick="go('myShowroomCars')">🚘 سيارات معرضي</button>`
    : RemoteState(st, { loading: 'جارٍ تحميل بيانات معرضك…', retry: "BackendDealer.loadShowroom(_rerenderIf('dealerHome'));render()",
        empty: { icon: '🏢', title: 'لا يوجد معرض مرتبط بحسابك بعد.' } });
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>🏢 إدارة معرضي</h1><p class="sub">مرحبًا ${user ? esc(user.name) : ''}</p></div>
  <div class="section">
    ${AccountCard(user)}
    <button class="action-btn" style="width:100%;margin-bottom:14px" onclick="go('myMemberCars')">📋 إعلاناتي (سياراتي الشخصية)</button>
    <h2>معرضك</h2>
    ${body}
  </div>`;
}

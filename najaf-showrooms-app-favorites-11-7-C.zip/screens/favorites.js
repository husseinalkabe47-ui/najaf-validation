/* المفضلة — favoritesService كما هو. تُعرض فقط السيارات المتاحة للمشاهد (قاعدة الظهور في visibilityService وحدها:
   سيارة عضو غير نشطة لا تظهر لغير مالكها/المدير، وسيارات معرض موقوف/مالكه غير فعّال لا تظهر لغير المدير/المالك). */
function FavoritesScreen() {
  if (!SessionService.isLoggedIn()) {
    return `
    <div class="topbar"><h1>❤️ المفضلة</h1></div>
    <div class="section">${EmptyState({ icon: '🔐', title: 'سجّل الدخول لحفظ سياراتك المفضلة', hint: 'احفظ السيارات التي تعجبك وارجع إليها في أي وقت.',
      actions: [{ label: 'تسجيل الدخول', onclick: "go('login',{returnTo:'favorites'})" }] })}</div>`;
  }
  if (BackendFavorites.isEnabled()) return _FavoritesRemote();   // 11.7-C: وضع الخادم (GET /v1/me/favorites)
  const favCars = getFavoriteCars();   // خدمة المفضلة تعيد ما يحق للمشاهد رؤيته فقط (المسار العام)
  if (favCars.length === 0) {
    return `
    <div class="topbar"><h1>❤️ المفضلة</h1></div>
    <div class="section">${EmptyState({ icon: '💔', title: 'لا توجد سيارات في المفضلة حاليًا',
      hint: 'اضغط على أيقونة 🤍 في أي سيارة لإضافتها إلى المفضلة.',
      actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }, { label: 'سيارات الأعضاء', onclick: "go('memberCars')", primary: false }] })}</div>`;
  }
  return `
  <div class="topbar"><h1>❤️ المفضلة</h1><p class="sub">${favCars.length} سيارة محفوظة</p></div>
  <div class="section"><div class="list-grid">${favCars.map(CarCard).join('')}</div></div>`;
}

/* (11.7-C) وضع الخادم: المفضلة من GET /v1/me/favorites فقط — لا بيانات محلية. السيارات غير العامة تُحذف من الخادم نفسه فلا تظهر. */
function _FavoritesRemote() {
  let st = BackendFavorites.list();
  if (st.status === 'idle') { BackendFavorites.ensure(_rerenderIf('favorites')); st = BackendFavorites.list(); }
  const body = st.status === 'ready'
    ? `<div class="list-grid">${st.items.map(x => RemoteCarCard(x.car)).join('')}</div>`
      + (st.error ? `<div class="form-note" role="alert">${esc(st.error)}</div>` : '')
      + (st.more ? '<div class="placeholder" role="status" aria-busy="true"><b>جارٍ تحميل المزيد…</b></div>'
        : st.nextBefore ? `<button class="action-btn" style="width:100%;margin-top:10px" onclick="BackendFavorites.more(_rerenderIf('favorites'));render()">عرض المزيد</button>` : '')
    : RemoteState(st, { loading: 'جارٍ تحميل مفضلتك…', retry: "BackendFavorites.reload(_rerenderIf('favorites'));render()",
        empty: { icon: '💔', title: 'لا توجد سيارات في المفضلة حاليًا', hint: 'اضغط على أيقونة 🤍 في أي سيارة لإضافتها إلى المفضلة.',
          actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }, { label: 'سيارات الأعضاء', onclick: "go('memberCars')", primary: false }] } });
  return `
  <div class="topbar"><h1>❤️ المفضلة</h1>${st.status === 'ready' ? `<p class="sub">${st.items.length}${st.nextBefore ? '+' : ''} سيارة محفوظة</p>` : ''}</div>
  <div class="section">${body}</div>`;
}

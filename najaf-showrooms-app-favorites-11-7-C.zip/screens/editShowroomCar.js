/* تعديل سيارة معرض. الراوتر يمنع فتحها لغير مالك المعرض (canManageCar) قبل العرض. */
function EditShowroomCarScreen(id) {
  if (BackendDealer.isEnabled()) return _EditShowroomCarRemote(id);   // 11.7.2.5: وضع الخادم
  const c = getCarById(id);
  if (!c || c.sourceType !== 'showroom') return `<div class="placeholder">السيارة غير موجودة</div>`;
  initImageCtxCar(id);
  const sel = (v, cur) => (v === cur ? 'selected' : '');
  return `
  ${BackBar('myShowroomCars')}
  <div class="topbar"><h1>✏️ تعديل السيارة</h1><p class="sub">${esc(c.brand)} ${esc(c.model)}</p></div>
  <div class="section"><div class="form-card">
    <div class="field"><label for="scBrand">الماركة</label><input id="scBrand" type="text" value="${esc(c.brand)}"></div>
    <div class="field"><label for="scModel">الموديل</label><input id="scModel" type="text" value="${esc(c.model)}"></div>
    <div class="field"><label for="scYear">سنة الصنع</label><input id="scYear" inputmode="numeric" type="text" dir="ltr" value="${esc(c.year)}"></div>
    <div class="field"><label for="scPrice">السعر</label><input id="scPrice" inputmode="numeric" type="text" dir="ltr" value="${esc(c.price)}"></div>
    <div class="field"><label for="scCurrency">عملة السعر *</label><select id="scCurrency">${currencyOptionsHtml(carCurrency(c))}</select></div>
    <div class="field"><label for="scMileage">المسافة المقطوعة (كم)</label><input id="scMileage" inputmode="numeric" type="text" dir="ltr" value="${esc(c.mileage)}"></div>
    <div class="field"><label for="scTransmission">ناقل الحركة</label>
      <select id="scTransmission"><option value="أوتوماتيك" ${sel('أوتوماتيك', c.transmission)}>أوتوماتيك</option><option value="يدوي" ${sel('يدوي', c.transmission)}>يدوي</option></select></div>
    <div class="field"><label for="scFuelType">نوع الوقود</label>
      <select id="scFuelType">${['بنزين', 'ديزل', 'هايبرد', 'كهرباء'].map(f => `<option value="${f}" ${sel(f, c.fuelType)}>${f}</option>`).join('')}</select></div>
    <div class="field"><label for="scColor">اللون</label><input id="scColor" type="text" value="${esc(c.color)}"></div>
    <div class="field"><label for="scDescription">الوصف</label><textarea id="scDescription">${esc(c.description)}</textarea></div>
    <div class="field" role="group" aria-labelledby="imgPickerLabel"><label id="imgPickerLabel">الصور</label>${ImagePickerHtml()}</div>
    <div id="showroomCarError" class="form-error" role="alert" style="display:none"></div>
    <button class="btn-primary" onclick="handleEditShowroomCarSubmit(${c.id})">حفظ التعديلات</button>
  </div></div>`;
}

/* (11.7.2.5) وضع الخادم: السيارة تُجلب طازجة (GET /v1/dealer/cars/:id) لأخذ «version» الحالي قبل التعديل. بلا بيانات محلية. */
function _EditShowroomCarRemote(id) {
  let st = BackendDealer.car();
  if (st.id !== id || st.status === 'idle') { BackendDealer.loadCar(id, _rerenderIf('editShowroomCar')); st = BackendDealer.car(); }
  if (st.status === 'ready' && st.id === id) return ShowroomCarFormRemote(st.car);
  const back = BackBar('myShowroomCars');
  if (st.status === 'empty') return back + EmptyState({ icon: '🚘', title: 'السيارة غير موجودة أو لم تعد في معرضك.', heading: true, actions: [{ label: 'سيارات معرضي', onclick: "go('myShowroomCars')" }] });
  return back + RemoteState(st.status === 'idle' ? { status: 'loading' } : st, { loading: 'جارٍ تحميل بيانات السيارة…', retry: `BackendDealer.loadCar(currentParam, _rerenderIf('editShowroomCar'));render()`, empty: { icon: '🚘', title: '' } });
}

/* MyMemberCarsScreen — «سياراتي / إعلاناتي». يعتمد على ownerId===currentUser.id فقط
   (getMemberCarsByOwner من الخدمة)، وليس على إخفاء في الواجهة. */
function MyMemberCarsScreen() {
  if (BackendMember.isEnabled()) return _MyMemberCarsRemote();   // 11.7-B: وضع الخادم (GET /v1/me/cars)
  const user = SessionService.getCurrentUser();
  const myCars = user ? getMemberCarsByOwner(user.id) : [];
  return `
  ${BackBar('account')}
  <div class="topbar"><h1>📋 سياراتي (إعلاناتي)</h1></div>
  <div class="section">
    ${myCars.length === 0
      ? EmptyState({ icon: '🚘', title: 'لا توجد سيارات مضافة', hint: 'انشر سيارتك مجانًا لتظهر للمشترين.', actions: [{ label: '➕ نشر سيارة جديدة', onclick: "go('addMemberCar')" }] })
      : `<button class="btn-primary" style="margin:0 0 14px" onclick="go('addMemberCar')">➕ نشر سيارة جديدة</button>` + myCars.map(c => `
      <div class="ad-row">
        <div class="card-img">${CarImageInner(c)}</div>
        <div class="ad-info">
          <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
          <p class="card-row">${val(c.year)}</p>
          <p class="price">${carPriceOrDash(c)}</p>
          ${memberCarStatusBadge(c.status)}
          ${c.status === 'rejected' && c.rejectionReason ? `<div class="reason-box">السبب: ${esc(c.rejectionReason)}</div>` : ''}
          ${c.status === 'suspended' && c.suspensionReason ? `<div class="reason-box">السبب: ${esc(c.suspensionReason)}</div>` : ''}
          <p class="card-row">🗓️ ${val(createdDateText(c.createdAt))}</p>
          <div class="ad-actions">
            <button onclick="go('memberCarDetails', ${c.id})">عرض</button>
            <button onclick="go('editMemberCar', ${c.id})">تعديل</button>
            <button onclick="handleMemberCarStatusChange(${c.id})">تغيير الحالة</button>
            <button class="danger" onclick="handleDeleteMemberCar(${c.id})">حذف</button>
          </div>
        </div>
      </div>`).join('')}
  </div>`;
}

/* (11.7-B) وضع الخادم: إعلانات المستخدم نفسه من GET /v1/me/cars فقط — لا بيانات محلية. الصور غير مربوطة بعد. */
const _MY_ADS_RETRY = "BackendMember.loadList(_rerenderIf('myMemberCars'));render()";
function _OwnAdRow(c) {
  const rid = "'" + c.id + "'";
  return `
      <div class="ad-row">
        <div class="card-img">${CAR_PLACEHOLDER}</div>
        <div class="ad-info">
          <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
          <p class="card-row">${val(c.year)}</p>
          <p class="price">${carPriceOrDash(c)}</p>
          ${memberCarStatusBadge(c.status)}
          ${OwnAdReason(c)}
          <p class="card-row">🗓️ ${val(createdDateText(c.createdAt))}</p>
          <div class="ad-actions">
            <button onclick="go('memberCarDetails', ${rid})">عرض</button>
            <button onclick="go('editMemberCar', ${rid})">تعديل</button>
            ${OwnAdSoldButton(c)}
            <button class="danger" onclick="handleDeleteMemberCar(${rid})">حذف</button>
          </div>
        </div>
      </div>`;
}
function _MyMemberCarsRemote() {
  let st = BackendMember.list();
  if (st.status === 'idle') { BackendMember.loadList(_rerenderIf('myMemberCars')); st = BackendMember.list(); }
  const add = `<button class="btn-primary" style="margin:0 0 14px" onclick="go('addMemberCar')">➕ نشر سيارة جديدة</button>`;
  const body = st.status === 'ready' ? add + st.items.map(_OwnAdRow).join('')
      + (st.error ? `<div class="form-note" role="alert">${esc(st.error)}</div>` : '')
      + (st.more ? '<div class="placeholder" role="status" aria-busy="true"><b>جارٍ تحميل المزيد…</b></div>'
        : st.nextBefore ? `<button class="action-btn" style="width:100%;margin-top:10px" onclick="BackendMember.loadList(_rerenderIf('myMemberCars'), true);render()">عرض المزيد</button>` : '')
    : RemoteState(st, { loading: 'جارٍ تحميل إعلاناتك…', retry: _MY_ADS_RETRY,
        empty: { icon: '🚘', title: 'لا توجد سيارات مضافة', hint: 'انشر سيارتك مجانًا لتظهر للمشترين بعد المراجعة.', actions: [{ label: '➕ نشر سيارة جديدة', onclick: "go('addMemberCar')" }] } });
  return `
  ${BackBar('account')}
  <div class="topbar"><h1>📋 سياراتي (إعلاناتي)</h1></div>
  <div class="section">${body}</div>`;
}

/* شاشتا استعادة كلمة المرور (11.7.2.3) — وضع الخادم فقط (في الوضع المحلي زر «نسيت كلمة المرور؟» يبقى كما كان). عرض فقط؛ المنطق في navigation/actions.js */
function ForgotPasswordScreen() {
  const p = (typeof currentParam === 'object' && currentParam && currentParam.phone) || '';
  return `
  ${BackBar('login')}
  <div class="topbar"><h1>🔑 استعادة كلمة المرور</h1><p class="sub">سنرسل رمز تحقق إلى هاتفك</p></div>
  <div class="section">
    <div class="form-card">
      <div class="field"><label for="forgotPhone">رقم الهاتف</label>
        <input id="forgotPhone" type="text" inputmode="tel" dir="ltr" autocomplete="tel" placeholder="07XXXXXXXXX" value="${esc(p)}"
               onkeydown="if(event.key==='Enter')handleForgotSubmit()"></div>
      <div id="forgotError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleForgotSubmit()">إرسال رمز التحقق</button>
      <div class="form-links">
        <button class="link-btn" onclick="go('resetPassword')">لديّ رمز بالفعل</button>
        <button class="link-btn" onclick="go('login')">العودة لتسجيل الدخول</button>
      </div>
      <div id="forgotNote" class="form-note" role="status" style="display:none"></div>
    </div>
  </div>`;
}

function ResetPasswordScreen() {
  const p = (typeof currentParam === 'object' && currentParam && currentParam.phone) || '';
  const sent = !!(typeof currentParam === 'object' && currentParam && currentParam.sent);
  return `
  ${BackBar('forgotPassword')}
  <div class="topbar"><h1>🔑 كلمة مرور جديدة</h1><p class="sub">أدخل الرمز الذي وصلك وكلمة المرور الجديدة</p></div>
  <div class="section">
    <div class="form-card">
      ${sent ? `<div class="form-note" role="status">${esc(BackendAuth.messages.recoverySent)}</div>` : ''}
      <div class="field"><label for="resetPhone">رقم الهاتف</label>
        <input id="resetPhone" type="text" inputmode="tel" dir="ltr" autocomplete="tel" placeholder="07XXXXXXXXX" value="${esc(p)}"></div>
      <div class="field"><label for="resetCode">رمز التحقق (6 أرقام)</label>
        <input id="resetCode" type="text" inputmode="numeric" dir="ltr" autocomplete="one-time-code" maxlength="12" placeholder="••••••"></div>
      <div class="field"><label for="resetPassword">كلمة المرور الجديدة</label>
        <input id="resetPassword" type="password" dir="ltr" autocomplete="new-password"></div>
      <div class="field"><label for="resetConfirm">تأكيد كلمة المرور</label>
        <input id="resetConfirm" type="password" dir="ltr" autocomplete="new-password"
               onkeydown="if(event.key==='Enter')handleResetSubmit()"></div>
      <div id="resetError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleResetSubmit()">تغيير كلمة المرور</button>
      <div class="form-links"><button class="link-btn" onclick="go('forgotPassword')">طلب رمز جديد</button></div>
    </div>
  </div>`;
}

/* شاشة تسجيل الدخول — عرض فقط؛ المنطق في navigation/actions.js و AuthService */
function LoginScreen() {
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>🔐 تسجيل الدخول</h1><p class="sub">أهلاً بك في معارض النجف</p></div>
  <div class="section">
    <div class="form-card">
      <div class="field"><label for="loginIdentifier">رقم الهاتف أو البريد الإلكتروني</label>
        <input id="loginIdentifier" type="text" dir="ltr" autocomplete="username" placeholder="07XXXXXXXXX"
               onkeydown="if(event.key==='Enter')handleLoginSubmit()"></div>
      <div class="field"><label for="loginPassword">كلمة المرور</label>
        <input id="loginPassword" type="password" dir="ltr" autocomplete="current-password" placeholder="••••••"
               onkeydown="if(event.key==='Enter')handleLoginSubmit()"></div>
      <div id="loginError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleLoginSubmit()">تسجيل الدخول</button>
      <div class="form-links">
        <button class="link-btn" onclick="go('register')">إنشاء حساب</button>
        <button class="link-btn" onclick="handleForgotPassword()">نسيت كلمة المرور؟</button>
      </div>
      <div id="loginNote" class="form-note" role="status" style="display:none"></div>
    </div>
    ${AuthService.isRemote() ? '' : `<div class="demo-box">
      <h3>🧪 حسابات تجريبية للاختبار فقط</h3>
      ${DEMO_ACCOUNTS.map((a, i) => `
        <div class="demo-row"><span>${a.label}</span><button onclick="fillDemoAccount(${i})">تعبئة</button></div>`).join('')}
    </div>`}
  </div>`;
}

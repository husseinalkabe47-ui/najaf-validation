/* ==========================================================================
   SESSION SERVICE
   إدارة الجلسة الحالية. تُخزَّن في الجلسة معرّف المستخدم فقط (userId)،
   أما الدور والحالة فتُقرأ دائمًا من سجل المستخدم نفسه في كل مرة —
   فتغيير بيانات الجلسة وحده لا يمنح أي صلاحية.
   ========================================================================== */
const SessionService = (function () {
  const TTL_MS = 7 * 24 * 60 * 60 * 1000; // أسبوع

  /** (11.7.2.1) وضع الخادم: المستخدم الحالي هو مستخدم الخادم في الذاكرة فقط (api/authBridge.js)؛ لا تُقرأ الجلسة المحلية ولا تُكتب. */
  function _remote() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }

  function _read() {
    const s = SessionRepository.get();            // null إن لم توجد/تالفة/بلا userId رقمي
    if (!s) return null;
    if (s.expiresAt && Date.now() > s.expiresAt) { SessionRepository.clear(); return null; }
    return s;
  }

  /** بدء جلسة لمستخدم (يُستدعى بعد نجاح التحقق من كلمة المرور) */
  function login(userId) {
    if (_remote()) return;   // لا جلسة محلية في وضع الخادم
    SessionRepository.save({ userId, createdAt: Date.now(), expiresAt: Date.now() + TTL_MS });
  }

  function logout() { if (_remote()) { BackendAuth.forgetUser(); return; } SessionRepository.clear(); }

  /** المستخدم الحالي (نسخة عامة بدون كلمة المرور) أو null للزائر */
  function getCurrentUser() {
    if (_remote()) return BackendAuth.currentUser();
    const s = _read();
    if (!s) return null;
    const user = UserService.getPublicById(s.userId);
    if (!user || user.status === USER_STATUS.SUSPENDED) { logout(); return null; }
    return user;
  }

  function isLoggedIn() { return getCurrentUser() !== null; }

  function hasRole(...roles) {
    const u = getCurrentUser();
    return !!u && roles.includes(u.role);
  }

  /** تجديد الجلسة والتحقق منها (تنتهي إن حُذف المستخدم أو أُوقف حسابه) */
  function updateSession() {
    if (_remote()) return BackendAuth.currentUser();
    const u = getCurrentUser();
    if (u) login(u.id);
    return u;
  }

  return { login, logout, getCurrentUser, isLoggedIn, hasRole, updateSession };
})();

/* Phase 11.7.2.5 — إضافة/تعديل/تغيير حالة/حذف سيارات المعرض عبر الخادم داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/showroom-cars): POST/GET/PATCH/DELETE على /v1/dealer/cars مع version (409 version_conflict) والتحقق نفسه بحدوده.
   لا خادم ولا قاعدة بيانات حقيقية. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const iso = '2026-01-01T00:00:00.000Z';
const KEYS = ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description'];
const view = r => Object.assign({}, r);

function dealerWorld(role) {
  const w = world();
  const d = { role: role || 'dealer', hasShowroom: true, seq: 100, cars: [], gate: null, fail: null };
  const add = o => { const c = Object.assign({ id: String(++d.seq), showroomId: '7', brand: 'تويوتا', model: 'كامري', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: 'نظيفة', status: 'available', version: 1, createdAt: iso, updatedAt: iso }, o); d.cars.unshift(c); return c; };
  d.add = add;
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    if (!u.pathname.startsWith('/v1/dealer/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const m = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = m && w.srv.access.get(m[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (d.role !== 'dealer' || !d.hasShowroom) return err(404, 'not_found');
    const mm = /^\/v1\/dealer\/cars(?:\/([^/]+))?$/.exec(u.pathname);
    if (!mm) return err(404, 'not_found');
    const id = mm[1], b = call.body;
    if (!id) {
      if (call.method === 'GET') return json(200, { items: d.cars.map(view), nextBefore: null });
      if (call.method === 'POST') {
        const bad = []; Object.keys(b).forEach(k => { if (!KEYS.includes(k)) bad.push({ field: k, code: 'unknown_field' }); });
        ['brand', 'model', 'year', 'price', 'currency'].forEach(k => { if (b[k] === undefined || b[k] === null) bad.push({ field: k, code: 'required' }); });
        if (bad.length) return err(400, 'validation_failed', bad);
        const c = add(Object.assign({}, b, { status: 'available', version: 1 })); return json(201, { car: view(c) });
      }
    }
    const c = d.cars.find(x => x.id === id);
    if (!c) return err(404, 'not_found');
    if (call.method === 'GET') return json(200, { car: view(c) });
    if (call.method === 'PATCH') {
      const bad = []; Object.keys(b).forEach(k => { if (![...KEYS, 'version', 'status'].includes(k)) bad.push({ field: k, code: 'unknown_field' }); });
      if (b.status !== undefined && !['available', 'sold'].includes(b.status)) bad.push({ field: 'status', code: 'invalid_format' });
      if (!Number.isInteger(b.version)) bad.push({ field: 'version', code: 'required' });
      if (bad.length) return err(400, 'validation_failed', bad);
      if (b.version !== c.version) return err(409, 'version_conflict');
      Object.keys(b).forEach(k => { if (k !== 'version') c[k] = b[k]; }); c.version++; return json(200, { car: view(c) });
    }
    if (call.method === 'DELETE') {
      if (!/^[1-9][0-9]{0,9}$/.test(call.query.version || '')) return err(400, 'validation_failed', [{ field: 'version', code: 'required' }]);
      if (Number(call.query.version) !== c.version) return err(409, 'version_conflict');
      d.cars = d.cars.filter(x => x !== c); return new Response(null, { status: 204 });
    }
    return err(405, 'method_not_allowed');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  const p = {
    env, run: c => env.run(c), set, screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    toast: () => env.els.toast && env.els.toast.textContent,
    err: () => env.els.showroomCarError && env.els.showroomCarError.textContent,
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
    fill(o) { o = Object.assign({ scBrand: 'Kia', scModel: 'Sportage', scYear: '٢٠٢٢', scPrice: '18,000,000', scCurrency: 'IQD', scMileage: '', scTransmission: 'يدوي', scFuelType: 'ديزل', scColor: 'أسود', scDescription: 'وصف' }, o); Object.keys(o).forEach(k => set(k, o[k])); },
  };
  return p;
}
const settle = async () => { for (let i = 0; i < 25; i++) await tick(); };
async function open(p, route) { await p.login(); p.run(`go('${route}')`); await settle(); }

test('الوضع المحلي دون تغيير: إضافة/تعديل/حذف/تغيير حالة محليًا بلا أي اتصال، ومنتقي الصور باقٍ', async () => {
  const env = makeEnv();
  env.run("AuthService.login('07701234567', 'dealer123')");
  env.run("go('addShowroomCar')");
  assert.match(env.screen(), /imgPickerLabel/);
  const n0 = env.run('getMyShowroomCars().length');
  ['scBrand', 'scModel', 'scYear', 'scPrice'].forEach((id, i) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(['Kia', 'Rio', '2021', '9000000'][i])}`));
  env.run("document.getElementById('scCurrency').value = 'IQD'");
  await env.run('handleAddShowroomCarSubmit()');
  assert.equal(env.run('getMyShowroomCars().length'), n0 + 1);
  assert.equal(env.run('BackendDealer.isEnabled()'), false);
  assert.deepEqual(env.errors, []);
});

test('إضافة: جسم الطلب بالحقول المسموحة فقط (لا معرض/دور/حالة)، الأرقام العربية تُحوَّل، ثم قائمة محدَّثة', async () => {
  const { w, d } = dealerWorld(); const p = page(w);
  await open(p, 'addShowroomCar');
  const html = p.screen();
  assert.match(html, /scBrand/); assert.ok(!/imgPickerLabel|handlePickImages/.test(html), 'بلا صور');
  p.fill(); await p.run('handleAddShowroomCarSubmit()'); await settle();
  const c = p.calls('POST', /^\/v1\/dealer\/cars$/);
  assert.equal(c.length, 1);
  assert.deepEqual(Object.keys(c[0].body).sort(), [...KEYS].sort());
  assert.deepEqual(c[0].body, { brand: 'Kia', model: 'Sportage', year: 2022, price: 18000000, currency: 'IQD', mileage: null, transmission: 'يدوي', fuelType: 'ديزل', color: 'أسود', description: 'وصف' });
  assert.match(c[0].headers.authorization, /^Bearer AT-/);
  assert.equal(p.route(), 'myShowroomCars');
  assert.equal(d.cars.length, 1);
  assert.match(p.screen(), /Kia Sportage/);
  assert.match(p.toast(), /تمت إضافة السيارة/);
  assert.ok(!Object.keys(p.env.store).some(k => /car/i.test(k) && /najaf\.cars/.test(k) && p.env.store[k].includes('Sportage')), 'لا نسخة محلية');
});

test('إضافة: تحقق الواجهة (حقول ناقصة/سنة/سعر/عملة) قبل أي طلب؛ ورفض الخادم 400 يظهر باسم الحقل بلا إنشاء محلي', async () => {
  const { w, d } = dealerWorld(); const p = page(w);
  await open(p, 'addShowroomCar');
  p.fill({ scBrand: '' }); await p.run('handleAddShowroomCarSubmit()'); assert.match(p.err(), /الحقول المطلوبة/);
  p.fill({ scYear: '1900' }); await p.run('handleAddShowroomCarSubmit()'); assert.match(p.err(), /سنة الصنع/);
  p.fill({ scPrice: '0' }); await p.run('handleAddShowroomCarSubmit()'); assert.match(p.err(), /السعر/);
  p.fill({ scCurrency: 'EUR' }); await p.run('handleAddShowroomCarSubmit()'); assert.match(p.err(), /عملة/);
  assert.equal(w.srv.calls.filter(c => c.path === '/v1/dealer/cars').length, 0, 'لا طلب مع بيانات غير صالحة');
  p.fill(); d.fail = c => (c.method === 'POST' ? err(400, 'validation_failed', [{ field: 'model', code: 'invalid_format' }]) : null);
  await p.run('handleAddShowroomCarSubmit()');
  assert.match(p.err(), /الموديل/); assert.equal(p.route(), 'addShowroomCar'); assert.equal(d.cars.length, 0);
});

test('إضافة: ضغط مزدوج = طلب واحد فقط؛ وفشل الخادم (500/شبكة) رسالة بلا إنشاء محلي ويمكن إعادة المحاولة', async () => {
  const { w, d } = dealerWorld(); const p = page(w);
  await open(p, 'addShowroomCar');
  p.fill(); let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
  const a = p.run('handleAddShowroomCarSubmit()'); const b = p.run('handleAddShowroomCarSubmit()');
  await tick(); await tick(); release(); await Promise.all([a, b]); await settle();
  assert.equal(p.calls('POST', /cars$/).length, 1);
  d.gate = null;
  p.run("go('addShowroomCar')"); p.fill(); d.fail = c => (c.method === 'POST' ? err(500, 'internal') : null);
  await p.run('handleAddShowroomCarSubmit()');
  assert.match(p.err(), /خطأ في الخادم/); assert.equal(p.route(), 'addShowroomCar'); assert.equal(d.cars.length, 1);
  d.fail = null; w.srv.down = true; await p.run('handleAddShowroomCarSubmit()'); assert.match(p.err(), /تعذّر الاتصال/);
  w.srv.down = false; await p.run('handleAddShowroomCarSubmit()'); await settle();
  assert.equal(d.cars.length, 2);
});

test('تعديل: تُجلب السيارة (GET /:id) لإصدارها الحالي ثم PATCH بالإصدار؛ القائمة تُحدَّث، ويُرفع الإصدار', async () => {
  const { w, d } = dealerWorld(); const car = d.add({}); const p = page(w);
  await open(p, 'myShowroomCars');
  assert.match(p.screen(), new RegExp(`go\\('editShowroomCar', '${car.id}'\\)`));
  p.run(`go('editShowroomCar', '${car.id}')`);
  assert.match(p.screen(), /جارٍ تحميل بيانات السيارة/);
  await settle();
  assert.equal(p.calls('GET', new RegExp(`/cars/${car.id}$`)).length, 1);
  assert.match(p.screen(), /value="تويوتا"/); assert.ok(!/imgPickerLabel/.test(p.screen()));
  p.fill({ scBrand: 'Toyota', scModel: 'Camry', scYear: '2021', scPrice: '30000000', scMileage: '5000', scTransmission: 'أوتوماتيك', scFuelType: 'بنزين', scColor: 'أبيض', scDescription: 'نظيفة' });
  await p.run(`handleEditShowroomCarSubmit('${car.id}')`); await settle();
  const c = p.calls('PATCH', new RegExp(`/cars/${car.id}$`));
  assert.equal(c.length, 1); assert.equal(c[0].body.version, 1); assert.equal(c[0].body.brand, 'Toyota'); assert.equal(c[0].body.mileage, 5000);
  assert.ok(!('status' in c[0].body) && !('showroomId' in c[0].body));
  assert.equal(p.route(), 'myShowroomCars'); assert.equal(d.cars[0].version, 2); assert.equal(d.cars[0].brand, 'Toyota');
  assert.match(p.screen(), /Toyota Camry/);
  assert.match(p.toast(), /تم حفظ التعديلات/);
});

test('تعديل: تعارض إصدار (409) = رسالة، وتُعاد نسخة الخادم الحالية دون الكتابة فوقها؛ و404 = «غير موجودة»', async () => {
  const { w, d } = dealerWorld(); const car = d.add({}); const p = page(w);
  await open(p, 'myShowroomCars'); p.run(`go('editShowroomCar', '${car.id}')`); await settle();
  car.version = 5; car.brand = 'مغيَّرة من مكان آخر';                      // تعديل من جهاز آخر
  p.fill({ scBrand: 'Mine' }); await p.run(`handleEditShowroomCarSubmit('${car.id}')`); await settle();
  assert.match(p.toast(), /تغيّرت هذه السيارة/);
  assert.equal(car.brand, 'مغيَّرة من مكان آخر', 'لم تُكتب فوق نسخة الخادم');
  assert.match(p.screen(), /value="مغيَّرة من مكان آخر"/, 'عُرضت النسخة الحالية');
  d.cars = [];                                                          // حُذفت
  p.run('render()'); await settle();
  p.run(`go('editShowroomCar', '999')`); await settle();
  assert.match(p.screen(), /غير موجودة أو لم تعد في معرضك/);
});

test('تغيير الحالة: PATCH {version, status} فقط، القائمة تتحدّث، وتعارض الإصدار لا يمرّ', async () => {
  const { w, d } = dealerWorld(); const car = d.add({}); const p = page(w);
  await open(p, 'myShowroomCars');
  assert.match(p.screen(), /handleShowroomCarStatusChange\('\d+'/);
  await p.run(`handleShowroomCarStatusChange('${car.id}', 'sold')`); await settle();
  const c = p.calls('PATCH', /cars\/\d+$/);
  assert.deepEqual(c[0].body, { version: 1, status: 'sold' });
  assert.equal(car.status, 'sold'); assert.match(p.screen(), /مباعة/); assert.match(p.toast(), /تم تغيير الحالة/);
  car.version = 9; await p.run(`handleShowroomCarStatusChange('${car.id}', 'available')`); await settle();
  assert.match(p.toast(), /تغيّرت هذه السيارة/); assert.equal(car.status, 'sold');
  await p.run(`handleShowroomCarStatusChange('${car.id}', 'reserved')`);
  assert.equal(p.calls('PATCH', /cars\/\d+$/).length, 2, 'حالة غير مسموحة لا تُرسل');
});

test('حذف: تأكيد ثم DELETE ?version=n؛ الإلغاء لا يرسل؛ تعارض الإصدار يعيد التحميل ولا يحذف؛ آخر سيارة = حالة فارغة', async () => {
  const { w, d } = dealerWorld(); const car = d.add({}); const p = page(w);
  await open(p, 'myShowroomCars');
  p.run('askConfirm = (spec, yes, no) => no()');
  await p.run(`handleDeleteShowroomCar('${car.id}')`);
  assert.equal(p.calls('DELETE', /cars/).length, 0);
  p.run('askConfirm = (spec, yes, no) => yes()');
  car.version = 3; await p.run(`handleDeleteShowroomCar('${car.id}')`); await settle();
  assert.match(p.toast(), /تغيّرت هذه السيارة/); assert.equal(d.cars.length, 1);
  await p.run(`handleDeleteShowroomCar('${car.id}')`); await settle();
  const c = p.calls('DELETE', /cars\/\d+$/);
  assert.equal(c.length, 2); assert.deepEqual(c[1].query, { version: '3' }); assert.equal(c[1].body, undefined);
  assert.equal(d.cars.length, 0);
  assert.match(p.screen(), /لا توجد سيارات في معرضك بعد/); assert.match(p.toast(), /تم حذف السيارة/);
});

test('حذف: نقرتان سريعتان = طلب واحد؛ وفشل الخادم لا يزيل السيارة من القائمة', async () => {
  const { w, d } = dealerWorld(); const car = d.add({}); const p = page(w);
  await open(p, 'myShowroomCars'); p.run('askConfirm = (spec, yes) => yes()');
  d.fail = c => (c.method === 'DELETE' ? err(503, 'unavailable') : null);
  await Promise.all([p.run(`handleDeleteShowroomCar('${car.id}')`), p.run(`handleDeleteShowroomCar('${car.id}')`)]); await settle();
  assert.equal(p.calls('DELETE', /cars/).length, 1);
  assert.match(p.toast(), /خطأ في الخادم/); assert.equal(d.cars.length, 1); assert.match(p.screen(), /تويوتا كامري/);
});

test('غير مصرّح: مستخدم عادي لا يفتح شاشات التاجر في وضع الخادم، ولا طلب كتابة؛ والخروج أثناء كتابة لا يلوّث المستخدم التالي', async () => {
  { const { w } = dealerWorld('user'); const p = page(w); await p.login();
    for (const r of ['addShowroomCar']) { p.run(`go('${r}')`); assert.equal(p.route(), 'accessDenied'); }
    p.run("go('editShowroomCar', '1')"); assert.equal(p.route(), 'accessDenied');
    assert.equal(w.srv.calls.filter(c => c.path.startsWith('/v1/dealer/')).length, 0); }
  { const { w, d } = dealerWorld(); const p = page(w); await open(p, 'addShowroomCar'); p.fill();
    let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
    const a = p.run('handleAddShowroomCarSubmit()'); await tick(); await tick();
    p.run('handleLogout()'); release(); await a; await settle();
    assert.equal(p.run('BackendDealer.cars().status'), 'idle'); }
});

test('انتهاء الجلسة أثناء الحفظ (401 ثم رفض التجديد) يعيد للدخول، ولا تُنشأ سيارة محليًا', async () => {
  const { w, d } = dealerWorld(); const p = page(w); await open(p, 'addShowroomCar'); p.fill();
  w.srv.families.forEach(f => { f.revoked = true; });
  await p.run('handleAddShowroomCarSubmit()'); await settle();
  assert.equal(p.route(), 'login'); assert.equal(d.cars.length, 0);
  assert.equal(p.run('getMyShowroomCars().length'), 0);
});

test('عزل: لا ملفات محلية للسيارات تُكتب في وضع الخادم، ولا سكربت جديد (87)، ولا مسار خارج /v1/dealer/cars للكتابة', () => {
  const root = path.join(__dirname, '..');
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.equal((html.match(/<script src=/g) || []).length, 87);
  const bridge = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const src = bridge.slice(bridge.indexOf('const BackendDealer')).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|\bconsole\.|\bfetch\s*\(|Repository/.test(src));
  const writes = [...src.matchAll(/api\.(post|patch|put|delete)\(\s*'([^']+)'/g)].map(m => m[1] + ' ' + m[2]);
  assert.deepEqual(writes.sort(), ["delete /v1/dealer/cars/", "patch /v1/dealer/cars/", "patch /v1/dealer/cars/", "post /v1/dealer/cars"].sort());
  const act = fs.readFileSync(path.join(root, 'navigation/dealerActions.js'), 'utf8');
  assert.ok(!/BackendDealer[^\n]*(role|showroomId|ownerId)/.test(act));
});

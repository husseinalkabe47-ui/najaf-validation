/* Phase 11.7-C — المفضلة عبر /v1/me/favorites داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/favorites): POST {carId} (201 جديدة/200 موجودة، 404 لسيارة غير عامة)، GET بمؤشر معتم،
   DELETE idempotent، قائمة بيضاء للحقول، 401 بلا رمز — مع كتالوج عام بسيط لعرض البطاقات. لا خادم ولا قاعدة بيانات حقيقية:
   النتائج لا تُثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const iso = '2026-01-01T00:00:00.000Z';

function favWorld() {
  const w = world();
  const d = { seq: 100, cars: [], favs: [], fail: null, gate: null, favSeq: 0 };   // favs: { carId, n } الأحدث رقمًا أولًا
  d.car = o => { const c = Object.assign({ id: String(++d.seq), sourceType: 'showroom', showroomId: null, brand: 'Toyota', model: 'Camry', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', status: 'available', phone: null, whatsapp: null, location: '', latitude: null, longitude: null, ownerName: null, createdAt: iso, updatedAt: iso }, o); d.cars.push(c); return c; };
  d.fav = c => { d.favs.push({ carId: c.id, n: ++d.favSeq }); };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const pub = u.pathname.startsWith('/v1/public/'), fav = u.pathname.startsWith('/v1/me/favorites');
    if (!pub && !fav) return base(url, init);
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    if (pub) {
      const m = /^\/v1\/public\/cars\/([^/]+)$/.exec(u.pathname);
      if (m) { const c = d.cars.find(x => x.id === m[1]); return c ? json(200, { car: c }) : err(404, 'not_found'); }
      if (u.pathname === '/v1/public/cars') { const rows = d.cars.slice().sort((a, b) => Number(b.id) - Number(a.id)).slice(0, Number(call.query.limit || 20)); return json(200, { items: rows, nextBefore: null }); }
      if (u.pathname === '/v1/public/showrooms') return json(200, { items: [], nextBefore: null });
      return err(404, 'not_found');
    }
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (call.method === 'POST' && u.pathname === '/v1/me/favorites') {
      const b = call.body, bad = Object.keys(b || {}).filter(k => k !== 'carId').map(k => ({ field: k, code: 'unknown_field' }));
      if (!b || b.carId === undefined) bad.push({ field: 'carId', code: 'required' }); else if (typeof b.carId !== 'string' || !/^[1-9][0-9]{0,18}$/.test(b.carId)) bad.push({ field: 'carId', code: 'invalid_format' });
      if (bad.length) return err(400, 'validation_failed', bad);
      const c = d.cars.find(x => x.id === b.carId && x.status !== 'hidden'); if (!c) return err(404, 'not_found');
      if (d.favs.some(f => f.carId === c.id)) return json(200, { favorite: { carId: c.id, createdAt: iso } });
      d.fav(c); return json(201, { favorite: { carId: c.id, createdAt: iso } });
    }
    if (call.method === 'GET' && u.pathname === '/v1/me/favorites') {
      const q = Object.keys(call.query).filter(k => !['limit', 'before'].includes(k)); if (q.length) return err(400, 'validation_failed', q.map(f => ({ field: f, code: 'unknown_field' })));
      const limit = Number(call.query.limit || 20); if (!(limit >= 1 && limit <= 50)) return err(400, 'validation_failed', [{ field: 'limit', code: 'invalid_format' }]);
      let rows = d.favs.slice().sort((a, b) => b.n - a.n); if (call.query.before) { if (!/^c[0-9]+$/.test(call.query.before)) return err(400, 'validation_failed', [{ field: 'before', code: 'invalid_format' }]); rows = rows.filter(r => r.n < Number(call.query.before.slice(1))); }
      const page = rows.slice(0, limit);
      return json(200, { items: page.map(f => ({ car: d.cars.find(c => c.id === f.carId), favoritedAt: iso })), nextBefore: page.length === limit ? 'c' + page[page.length - 1].n : null });
    }
    const dm = /^\/v1\/me\/favorites\/([^/]+)$/.exec(u.pathname);
    if (call.method === 'DELETE' && dm) { d.favs = d.favs.filter(f => f.carId !== dm[1]); return new Response(null, { status: 204 }); }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  return {
    env, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    toast: () => env.els.toast && env.els.toast.textContent,
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
  };
}
const settle = async () => { for (let i = 0; i < 30; i++) await tick(); };
const FAV = /^\/v1\/me\/favorites/;
const pressed = (html, id) => new RegExp(`aria-pressed="true" onclick="event\\.stopPropagation\\(\\);handleFavoriteToggle\\('${id}'\\)"`).test(html);
const unpressed = (html, id) => new RegExp(`aria-pressed="false" onclick="event\\.stopPropagation\\(\\);handleFavoriteToggle\\('${id}'\\)"`).test(html);
async function open(p, route, param) { await p.login(); p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle(); }

test('الوضع المحلي دون تغيير: المفضلة محلية بلا أي اتصال، والقلب بمعرّف رقمي، والمفضلة تعمل', async () => {
  const env = makeEnv();
  assert.equal(env.run('BackendFavorites.isEnabled()'), false);
  env.run("AuthService.login('07701234567', 'dealer123')");
  const id = env.run('getCars()[0].id');
  env.run(`handleFavoriteToggle(${id})`); assert.equal(env.run(`isFavorite(${id})`), true);
  env.run("go('favorites')"); assert.match(env.screen(), /car-card/);
  env.run(`handleFavoriteToggle(${id})`); assert.equal(env.run(`isFavorite(${id})`), false);
  assert.deepEqual(env.errors, []);
});

test('الزائر: القلب 🤍 يظهر، والنقر يحوّل للدخول بلا أي طلب مفضلة؛ وشاشة المفضلة تطلب الدخول', async () => {
  const { w, d } = favWorld(); const c = d.car({}); const p = page(w);
  p.run("go('cars')"); await settle();
  assert.ok(unpressed(p.env.els.carsList.innerHTML, c.id) || /handleFavoriteToggle\('\d+'\)/.test(p.screen()));
  p.run(`handleFavoriteToggle('${c.id}')`); await settle();
  assert.equal(p.route(), 'login'); assert.equal(w.srv.calls.filter(x => FAV.test(x.path)).length, 0);
  p.run("go('favorites')"); assert.match(p.screen(), /سجّل الدخول لحفظ سياراتك المفضلة/);
  assert.equal(w.srv.calls.filter(x => FAV.test(x.path)).length, 0);
});

test('المسجَّل: تُحمَّل المفضلة (GET limit=50 بترويسة دخول) فتظهر القلوب مضغوطة لما في المفضلة فقط؛ الكتالوج العام بلا ترويسة دخول', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }), b = d.car({ brand: 'Honda', model: 'City' }); d.fav(a);
  const p = page(w); await open(p, 'cars');
  const g = p.calls('GET', FAV); assert.equal(g.length, 1); assert.equal(g[0].query.limit, '50'); assert.match(g[0].headers.authorization, /^Bearer AT-/);
  const html = p.screen();
  assert.ok(pressed(html, a.id), 'مفضلة'); assert.ok(unpressed(html, b.id), 'ليست مفضلة');
  assert.ok(w.srv.calls.filter(x => /^\/v1\/public\//.test(x.path)).every(x => !x.headers.authorization), 'العام بلا دخول');
  assert.equal(p.run('BackendFavorites.isFavorite(' + a.id + ')'), true);
  assert.deepEqual(p.env.errors, []);
});

test('إضافة: POST {carId} فقط؛ القلب يُضغط والرسالة تظهر؛ وتظهر السيارة في شاشة المفضلة (إعادة جلب)؛ لا نسخة محلية', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }); const p = page(w); await open(p, 'cars');
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle();
  const pc = p.calls('POST', FAV); assert.equal(pc.length, 1); assert.deepEqual(pc[0].body, { carId: a.id }); assert.match(pc[0].headers.authorization, /^Bearer AT-/);
  assert.equal(d.favs.length, 1); assert.match(p.toast(), /أُضيفت السيارة إلى المفضلة/);
  assert.ok(pressed(p.screen(), a.id));
  p.run("go('favorites')"); await settle();
  assert.match(p.screen(), /Kia Rio/); assert.match(p.screen(), /1 سيارة محفوظة/);
  assert.ok(!/Corolla|Land Cruiser/.test(p.screen()), 'لا بيانات محلية');
  assert.ok(!JSON.stringify(p.env.store).includes('Rio'), 'لا تخزين محلي');
});

test('إزالة: DELETE /:carId؛ تختفي البطاقة من المفضلة؛ آخر سيارة = حالة فارغة؛ idempotent عند عدم وجودها', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }), b = d.car({ brand: 'Honda', model: 'City' }); d.fav(a); d.fav(b);
  const p = page(w); await open(p, 'favorites');
  assert.match(p.screen(), /Kia Rio/); assert.match(p.screen(), /Honda City/);
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle();
  const dc = p.calls('DELETE', FAV); assert.equal(dc.length, 1); assert.equal(dc[0].path, '/v1/me/favorites/' + a.id);
  assert.ok(!/Kia Rio/.test(p.screen())); assert.match(p.screen(), /Honda City/); assert.match(p.toast(), /أُزيلت/);
  await p.run(`handleFavoriteToggle('${b.id}')`); await settle();
  assert.match(p.screen(), /لا توجد سيارات في المفضلة حاليًا/); assert.equal(d.favs.length, 0);
});

test('منع التكرار: نقرتان سريعتان = طلب واحد؛ فشل الخادم (500/404/403/شبكة) رسالة بلا تغيير في القلب ولا في القائمة، ثم نجاح عند إعادة المحاولة', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }); const p = page(w); await open(p, 'cars');
  let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
  const x = p.run(`handleFavoriteToggle('${a.id}')`), y = p.run(`handleFavoriteToggle('${a.id}')`);
  await tick(); await tick(); release(); await Promise.all([x, y]); await settle();
  assert.equal(p.calls('POST', FAV).length, 1); assert.equal(d.favs.length, 1); d.gate = null;
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle(); assert.equal(d.favs.length, 0);   // إزالة
  d.fail = c => (c.method === 'POST' ? err(500, 'internal') : null);
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle();
  assert.match(p.toast(), /خطأ في الخادم/); assert.equal(p.run(`BackendFavorites.isFavorite('${a.id}')`), false); assert.equal(d.favs.length, 0);
  d.fail = c => (c.method === 'POST' ? err(404, 'not_found') : null);
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle(); assert.match(p.toast(), /غير متاحة حاليًا/);
  d.fail = c => (c.method === 'POST' ? err(403, 'forbidden') : null);
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle(); assert.match(p.toast(), /صلاحية/);
  d.fail = null; w.srv.down = true; await p.run(`handleFavoriteToggle('${a.id}')`); await settle(); assert.match(p.toast(), /تعذّر الاتصال/); assert.equal(d.favs.length, 0);
  w.srv.down = false; await p.run(`handleFavoriteToggle('${a.id}')`); await settle(); assert.equal(d.favs.length, 1); assert.ok(pressed(p.screen(), a.id));
});

test('فشل الإزالة لا يزيل السيارة من المفضلة محليًا', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }); d.fav(a); const p = page(w); await open(p, 'favorites');
  d.fail = c => (c.method === 'DELETE' ? err(503, 'unavailable') : null);
  await p.run(`handleFavoriteToggle('${a.id}')`); await settle();
  assert.match(p.toast(), /خطأ في الخادم/); assert.match(p.screen(), /Kia Rio/); assert.equal(d.favs.length, 1);
});

test('شاشة المفضلة: فراغ، خطأ برسالة وإعادة المحاولة، 403 = منع، بلا رجوع صامت لبيانات محلية', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }); const p = page(w);
  await open(p, 'favorites'); assert.match(p.screen(), /لا توجد سيارات في المفضلة حاليًا/); assert.match(p.screen(), /تصفح السيارات/);
  d.fav(a); d.fail = c => (c.method === 'GET' && FAV.test(c.path) ? err(503, 'unavailable') : null);
  p.run('BackendFavorites.reset()'); p.run("go('home')"); p.run("go('favorites')"); await settle();
  assert.match(p.screen(), /role="alert"/); assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!/Kia Rio/.test(p.screen()));
  d.fail = null; p.run("BackendFavorites.reload(_rerenderIf('favorites'));render()"); await settle(); assert.match(p.screen(), /Kia Rio/);
  p.run('BackendFavorites.reset()'); d.fail = c => (FAV.test(c.path) ? err(403, 'forbidden') : null); p.run("go('home')"); p.run("go('favorites')"); await settle();
  assert.match(p.screen(), /صلاحية استخدام المفضلة/); assert.ok(!/Kia Rio/.test(p.screen()));
  d.fail = null; w.srv.down = true; p.run('BackendFavorites.reset()'); p.run("go('home')"); p.run("go('favorites')"); await settle();
  assert.match(p.screen(), /تعذّر الاتصال/); assert.ok(!/Kia Rio/.test(p.screen()));
});

test('الصفحات: المؤشر المعتم nextBefore يُمرَّر كما هو؛ التحميل الأول حتى 4 صفحات؛ «عرض المزيد» بعدها؛ وفشله يُبقي القائمة', async () => {
  const { w, d } = favWorld(); for (let i = 0; i < 230; i++) d.fav(d.car({ brand: 'B' + i, model: 'M' }));
  const p = page(w); await open(p, 'favorites');
  assert.equal(p.calls('GET', FAV).length, 4, 'حتى 4 صفحات تلقائيًا');
  assert.equal((p.screen().match(/class="card car-card"/g) || []).length, 200); assert.match(p.screen(), /200\+ سيارة محفوظة/); assert.match(p.screen(), /عرض المزيد/);
  const second = p.calls('GET', FAV)[1]; assert.match(second.query.before, /^c[0-9]+$/, 'المؤشر كما أرسله الخادم');
  d.fail = c => (c.query.before ? err(503, 'unavailable') : null);
  p.run("BackendFavorites.more(_rerenderIf('favorites'));render()"); await settle();
  assert.equal((p.screen().match(/class="card car-card"/g) || []).length, 200); assert.match(p.screen(), /خطأ في الخادم/);
  d.fail = null; p.run("BackendFavorites.more(_rerenderIf('favorites'));render()"); await settle();
  assert.equal((p.screen().match(/class="card car-card"/g) || []).length, 230); assert.ok(!/عرض المزيد/.test(p.screen()));
});

test('التفاصيل: القلب المضمَّن (fav-inline) بحالته من الخادم ويعمل بالتبديل', async () => {
  const { w, d } = favWorld(); const a = d.car({ brand: 'Kia', model: 'Rio' }), b = d.car({ brand: 'Honda', model: 'City' }); d.fav(a);
  const p = page(w); await open(p, 'carDetails', a.id);
  assert.match(p.screen(), new RegExp(`fav-inline" aria-label="إزالة من المفضلة" aria-pressed="true" onclick="event\\.stopPropagation\\(\\);handleFavoriteToggle\\('${a.id}'\\)"`));
  p.run(`go('carDetails', '${b.id}')`); await settle(); assert.match(p.screen(), /aria-pressed="false"/);
  await p.run(`handleFavoriteToggle('${b.id}')`); await settle(); assert.match(p.screen(), /aria-pressed="true"/); assert.equal(d.favs.length, 2);
});

test('الجلسة: انتهاء الجلسة أثناء الإضافة (401 ثم رفض التجديد) تُنهي الجلسة برسالة بلا تغيير محلي (والقلب بعدها يحوّل للدخول)؛ والخروج أثناء طلب لا يلوّث المستخدم التالي', async () => {
  { const { w, d } = favWorld(); const a = d.car({}); const p = page(w); await open(p, 'cars');
    w.srv.families.forEach(f => { f.revoked = true; });
    await p.run(`handleFavoriteToggle('${a.id}')`); await settle();
    assert.equal(p.run('SessionService.isLoggedIn()'), false, 'الجلسة انتهت (الشاشة عامة فتبقى كزائر)'); assert.equal(p.toast(), p.run('BackendAuth.messages.expired'), 'رسالة انتهاء الجلسة لا تُستبدل'); assert.equal(d.favs.length, 0); assert.equal(p.run('BackendFavorites.isFavorite(' + a.id + ')'), false); }
  { const { w, d } = favWorld(); const a = d.car({}); const p = page(w); await open(p, 'cars');
    let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
    const x = p.run(`handleFavoriteToggle('${a.id}')`); await tick(); await tick();
    p.run('handleLogout()'); release(); await x; await settle();
    assert.equal(p.run('BackendFavorites.list().status'), 'idle'); assert.equal(p.run('BackendFavorites.isFavorite(' + a.id + ')'), false); }
});

test('عزل: BackendFavorites يستعمل /v1/me/favorites فقط بلا تخزين/console/fetch ولا بيانات محلية، ولا سكربت جديد (87)', () => {
  const root = path.join(__dirname, '..');
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendFavorites'), b = all.indexOf('const BackendMember');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(src.length > 3000);
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|Repository|AppStorage|getFavoriteCars|FavoritesRepository/.test(src));
  const paths = [...src.matchAll(/api\.(get|post|delete)\(\s*('[^']+'(?:\s*\+\s*carId)?)/g)].map(m => m[1] + ' ' + m[2].replace(/\s+/g, ''));
  assert.deepEqual(paths.sort(), ["delete '/v1/me/favorites/'+carId", "get '/v1/me/favorites'", "post '/v1/me/favorites'"].sort());
  assert.ok(!/\/v1\/(?!me\/favorites)/.test(src));
  assert.equal((fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/<script src=/g) || []).length, 87);
});

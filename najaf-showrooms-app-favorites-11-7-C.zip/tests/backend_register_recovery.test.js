/* Phase 11.7.2.3 — التسجيل واستعادة كلمة المرور عبر الخادم داخل التطبيق الفعلي (vm بسكربتات index.html) مقابل «الخادم» الوهمي في session_world.js.
   الخادم الوهمي يحاكي العقد الموجود فقط (register/forgot/reset + تدوير ملف الارتباط). لا مزوّد رسائل حقيقي ولا خادم ولا متصفح حقيقي:
   لا شيء هنا يثبت وصول رسالة SMS أو عمل الاستعادة من طرف إلى طرف. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const PASSWORD = 'Pa$$w0rd-SECRET-123';
const HINT = 'najaf-auth-hint';
const NAME = 'علي حسين';
const PHONE = '07711112222';

function page(w, store) {
  const env = makeEnv(store || {});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController;
  env.ctx.__timers = []; env.ctx.__st = fn => { env.ctx.__timers.push(fn); return env.ctx.__timers.length; }; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  const val = id => env.run(`document.getElementById('${id}').value`);
  const text = id => env.els[id] && env.els[id].textContent;
  const p = {
    env, store: env.store, set, val, text,
    run: c => env.run(c),
    route: () => env.run('currentRoute'),
    param: () => env.run('currentParam'),
    user: () => env.run('SessionService.getCurrentUser()'),
    calls: path => w.srv.calls.filter(c => c.path === path),
    fillRegister(o) {
      o = Object.assign({ name: NAME, phone: PHONE, password: PASSWORD, confirm: PASSWORD }, o);
      env.run("go('register')");
      set('regName', o.name); set('regPhone', o.phone); set('regPassword', o.password); set('regConfirm', o.confirm);
    },
    register: async o => { p.fillRegister(o); return env.run('handleRegisterSubmit()'); },
    forgot: async phone => { env.run("go('forgotPassword')"); set('forgotPhone', phone === undefined ? PHONE : phone); return env.run('handleForgotSubmit()'); },
    reset: async o => {
      o = Object.assign({ phone: PHONE, code: '123456', password: 'New-Passw0rd-9', confirm: 'New-Passw0rd-9' }, o);
      env.run("go('resetPassword')");
      set('resetPhone', o.phone); set('resetCode', o.code); set('resetPassword', o.password); set('resetConfirm', o.confirm);
      return env.run('handleResetSubmit()');
    },
  };
  return p;
}
const errResp = (status, code, headers, fields) => new Response(JSON.stringify({ error: { code, message: 'm', requestId: 'r', fields } }), { status, headers: Object.assign({ 'content-type': 'application/json' }, headers) });

/* ====================== التسجيل ====================== */

test('الوضع المحلي دون تغيير: شاشة التسجيل بحقولها الكاملة (بريد ونوع الحساب)، والتسجيل المحلي يعمل، ولا استدعاء للجسر', () => {
  const env = makeEnv();
  env.run("go('register')");
  const html = env.screen();
  assert.match(html, /id="regEmail"/); assert.match(html, /name="accountType"/); assert.match(html, /id="dealerNote"/);
  env.run("document.getElementById('regName').value='سالم حسن'; document.getElementById('regPhone').value='07712345678'; document.getElementById('regPassword').value='123456'; document.getElementById('regConfirm').value='123456'");
  env.run('handleRegisterSubmit()');
  assert.equal(env.run('SessionService.isLoggedIn()'), true);
  assert.equal(env.run('BackendAuth.isEnabled()'), false);
  env.run("go('login')"); env.run('handleForgotPassword()');
  assert.match(env.els.loginNote.textContent, /تحتاج خادمًا/, 'سلوك «نسيت كلمة المرور» المحلي كما كان');
});

test('وضع الخادم: الشاشة بلا حقل البريد ولا نوع الحساب (لا يختار العميل دورًا)، والتصميم والحقول الأخرى كما هي', () => {
  const p = page(world());
  p.env.run("go('register')");
  const html = p.env.screen();
  for (const id of ['regName', 'regPhone', 'regPassword', 'regConfirm', 'registerError']) assert.match(html, new RegExp('id="' + id + '"'));
  assert.ok(!/regEmail|accountType|dealerNote/.test(html));
});

test('تسجيل ناجح: الجسم {name, phone, password} فقط (لا دور ولا نوع ولا بريد)، ونقل الملف، ولا رمز تجديد في JavaScript، وكلمات المرور تُفرَّغ', async () => {
  const w = world(); const p = page(w);
  await p.register();
  const c = p.calls('/v1/auth/register');
  assert.equal(c.length, 1);
  assert.deepEqual(Object.keys(c[0].body).sort(), ['name', 'password', 'phone']);
  assert.equal(c[0].body.name, NAME); assert.equal(c[0].body.phone, PHONE);
  assert.equal(c[0].headers['x-session-transport'], 'cookie');
  assert.equal(c[0].credentials, 'same-origin');
  assert.equal(p.route(), 'account');
  const u = p.user();
  assert.equal(u.role, 'user'); assert.equal(u.status, 'active'); assert.match(u.id, /^srv:\d+$/); assert.equal(u.name, NAME);
  assert.equal(p.run('AuthorizationService.canAccessAdmin()'), false);
  assert.equal(p.run('AuthorizationService.canAccessDealerArea()'), false);
  assert.equal(p.val('regPassword'), ''); assert.equal(p.val('regConfirm'), '');
  assert.equal(p.store[HINT], '1');
  assert.ok(w.jar.rt, 'الملف عند «المتصفح» لا في JavaScript');
  const dump = JSON.stringify(p.store) + JSON.stringify(p.env.els);
  assert.ok(!dump.includes(w.jar.rt) && !dump.includes(PASSWORD) && !/AT-\d+/.test(dump));
  assert.ok(Object.keys(p.store).every(k => k.startsWith('najaf.') || k === HINT));
  assert.deepEqual(p.env.errors, []);
});

test('لا حساب محلي ولا جلسة محلية تُنشأ في وضع الخادم', async () => {
  const w = world(); const p = page(w);
  const before = JSON.stringify(p.store);
  await p.register();
  assert.ok(!Object.keys(p.store).some(k => /najaf\.session/.test(k)));
  assert.equal(p.run("UserService.getAll ? UserService.getAll().some(u => u.name === 'علي حسين') : false"), false);
  void before;
});

test('الجلسة المسجَّلة تُستعاد بعد إعادة التحميل (ملف الارتباط من التسجيل)', async () => {
  const w = world(); const p = page(w);
  await p.register();
  const p2 = page(w, p.store);
  const r = await p2.run('restoreBackendSession()');
  assert.equal(r.status, 'restored');
  assert.equal(p2.user().name, NAME);
  assert.equal(w.srv.reuse || 0, 0);
});

test('حساب صاحب معرض مرفوض دفاعيًا (لو ظهر الحقل): رسالة عربية بلا طلب شبكة', async () => {
  const w = world(); const p = page(w);
  p.fillRegister();
  p.env.radios.accountType = 'dealer';
  await p.run('handleRegisterSubmit()');
  assert.equal(p.text('registerError'), p.run('BackendAuth.messages.dealerLater'));
  assert.equal(w.srv.calls.length, 0);
  assert.equal(p.user(), null);
});

test('تحقق العميل قبل الشبكة: اسم قصير/طويل، هاتف خاطئ، كلمة مرور قصيرة/طويلة، عدم تطابق — بلا أي طلب', async () => {
  const w = world(); const p = page(w);
  const cases = [
    [{ name: 'ab' }, 'الاسم يجب ألا يقل عن 3 أحرف.'],
    [{ name: '' }, 'الاسم يجب ألا يقل عن 3 أحرف.'],
    [{ name: 'x'.repeat(101) }, 'الاسم طويل جدًا (الحد الأقصى 100 حرف).'],
    [{ name: 'علي\u0007حسين' }, 'الاسم يحوي رموزًا غير مسموحة.'],
    [{ phone: '12345' }, 'رقم الهاتف غير صحيح. مثال: 07701234567'],
    [{ phone: '' }, 'رقم الهاتف غير صحيح. مثال: 07701234567'],
    [{ password: '12345', confirm: '12345' }, 'كلمة المرور يجب ألا تقل عن 6 أحرف.'],
    [{ password: 'x'.repeat(129), confirm: 'x'.repeat(129) }, 'كلمة المرور طويلة جدًا (الحد الأقصى 128 حرفًا).'],
    [{ confirm: 'different' }, 'كلمتا المرور غير متطابقتين.'],
  ];
  for (const [o, msg] of cases) {
    await p.register(o);
    assert.equal(p.text('registerError'), msg, JSON.stringify(Object.keys(o)));
    assert.equal(p.route(), 'register');
  }
  assert.equal(w.srv.calls.length, 0);
  assert.equal(p.user(), null);
});

test('رقم بأرقام عربية أو بصيغة +964 يُقبل ويُرسل مُطبَّعًا', async () => {
  const w = world(); const p = page(w);
  await p.register({ phone: '+964 771 111 2222' });
  assert.equal(p.calls('/v1/auth/register')[0].body.phone, PHONE);
});

test('رقم مسجَّل مسبقًا (409): رسالة عامة بلا كشف، لا جلسة ولا ملف ولا تلميح، وتبقى في شاشة التسجيل', async () => {
  const w = world(); const p0 = page(w);
  await p0.register();
  const w2jar = w.jar.rt;
  await p0.run('handleLogout()'); await tick(); await tick(); await tick();
  const p = page(w);
  await p.register({ name: 'اسم آخر' });
  assert.equal(p.text('registerError'), 'تعذّر إنشاء الحساب بهذه البيانات. إن كان لديك حساب فسجّل الدخول.');
  assert.equal(p.route(), 'register');
  assert.equal(p.user(), null);
  assert.equal(p.store[HINT], undefined);
  assert.equal(w.jar.rt, null);
  void w2jar;
});

test('أخطاء الخادم: تحقق (حقول)، حد المعدّل بالدقائق، شبكة، 5xx، ردّ غير صالح — رسائل عربية عامة بلا تفاصيل الخادم', async () => {
  const w = world(); const p = page(w);
  const run = async (fail, msg) => {
    w.srv.fail = c => (c.path === '/v1/auth/register' ? fail(c) : null);
    await p.register();
    assert.equal(p.text('registerError'), msg);
    assert.equal(p.user(), null); assert.equal(p.route(), 'register');
    assert.equal(p.val('regPassword'), '', 'كلمة المرور تُفرَّغ بعد الفشل');
  };
  await run(() => errResp(400, 'validation_failed', {}, [{ field: 'name', code: 'too_short' }]), 'الاسم يجب ألا يقل عن 3 أحرف.');
  await run(() => errResp(400, 'validation_failed', {}, [{ field: 'password', code: 'too_short' }]), 'كلمة المرور يجب ألا تقل عن 6 أحرف.');
  await run(() => errResp(400, 'validation_failed', {}, [{ field: 'phone', code: 'invalid_format' }]), 'رقم الهاتف غير صحيح. مثال: 07701234567');
  await run(() => errResp(400, 'validation_failed'), 'تحقق من رقم الهاتف وكلمة المرور.');
  await run(() => errResp(429, 'rate_limited', { 'retry-after': '3000' }), 'محاولات كثيرة. حاول بعد 50 دقيقة.');
  await run(() => errResp(429, 'rate_limited'), 'محاولات كثيرة. انتظر قليلًا ثم حاول مرة أخرى.');
  await run(() => errResp(503, 'x'), 'حدث خطأ في الخادم. حاول لاحقًا.');
  await run(() => new Response('<html>', { status: 200, headers: { 'content-type': 'application/json' } }), 'ردّ الخادم غير صالح. حاول لاحقًا.');
  await run(() => errResp(403, 'forbidden_origin'), 'إعداد الاتصال بالخادم غير صحيح.');
  w.srv.fail = null; w.srv.down = true;
  await p.register();
  assert.equal(p.text('registerError'), 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.');
  assert.ok(!/requestId|forbidden_origin|validation_failed|rate_limited/.test(p.env.screen() + p.text("registerError")));
});

test('انتهاء المهلة أثناء التسجيل', async () => {
  const w = world(); const p = page(w);
  w.srv.gate = () => new Promise(() => {});
  p.fillRegister();
  const pr = p.run('handleRegisterSubmit()');
  await tick(); await tick();
  p.env.ctx.__timers.forEach(f => f());
  await pr;
  assert.equal(p.text('registerError'), 'انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.');
  assert.equal(p.user(), null);
});

test('نقرتان متتاليتان: طلب تسجيل واحد فقط', async () => {
  const w = world(); const p = page(w);
  p.fillRegister();
  const a = p.run('handleRegisterSubmit()'); const b = p.run('handleRegisterSubmit()');
  await Promise.all([a, b]);
  assert.equal(p.calls('/v1/auth/register').length, 1);
});

test('ردّ تسجيل بمستخدم غير معروف الشكل/الدور: لا جلسة، وتُبطَل الجلسة التي أنشأها الخادم والملف يُحذف', async () => {
  const w = world(); const p = page(w);
  w.srv.fail = c => {
    if (c.path !== '/v1/auth/register') return null;
    return new Response(JSON.stringify({ user: { id: '5', name: 'x', phone: '+964771', role: 'superuser', status: 'active' }, session: { accessToken: 'a', accessExpiresAt: new Date(w.clock.t + 9e5).toISOString(), refreshExpiresAt: new Date(w.clock.t + 9e8).toISOString() } }), { status: 201, headers: { 'content-type': 'application/json' } });
  };
  await p.register();
  assert.equal(p.text('registerError'), 'ردّ الخادم غير صالح. حاول لاحقًا.');
  assert.equal(p.user(), null);
  assert.equal(p.run('BackendAuth.api().hasSession()'), false);
  assert.equal(p.calls('/v1/auth/logout').length, 1, 'إبطال بأفضل جهد');
});

test('ردّ تسجيل يحمل refreshToken في نقل الملف يُرفض ولا يُخزَّن', async () => {
  const w = world(); const p = page(w);
  w.srv.fail = c => c.path === '/v1/auth/register' ? new Response(JSON.stringify({ user: { id: '5', name: 'x', phone: '+9647711112222', role: 'user', status: 'active' }, session: { accessToken: 'a', accessExpiresAt: new Date(w.clock.t + 9e5).toISOString(), refreshToken: 'LEAKED-RT', refreshExpiresAt: new Date(w.clock.t + 9e8).toISOString() } }), { status: 201, headers: { 'content-type': 'application/json' } }) : null;
  await p.register();
  assert.equal(p.user(), null);
  assert.ok(!JSON.stringify(p.store).includes('LEAKED-RT') && !JSON.stringify(p.env.els).includes('LEAKED-RT'));
});

test('مستخدم مسجَّل الدخول لا يصل لشاشة التسجيل أو الاستعادة (الحراسة)', async () => {
  const w = world(); const p = page(w);
  await p.register();
  for (const r of ['register', 'forgotPassword', 'resetPassword', 'login']) { p.run(`go('${r}')`); assert.equal(p.route(), 'account', r); }
});

/* ====================== استعادة كلمة المرور ====================== */

test('الوضع المحلي: شاشتا الاستعادة تُحوِّلان إلى الدخول (لا خادم)', () => {
  const env = makeEnv();
  env.run("go('forgotPassword')"); assert.equal(env.run('currentRoute'), 'login');
  env.run("go('resetPassword')"); assert.equal(env.run('currentRoute'), 'login');
});

test('وضع الخادم: «نسيت كلمة المرور؟» تفتح شاشة الاستعادة وتحمل الرقم المكتوب', () => {
  const p = page(world());
  p.env.run("go('login')"); p.set('loginIdentifier', PHONE);
  p.run('handleForgotPassword()');
  assert.equal(p.route(), 'forgotPassword');
  assert.match(p.env.screen(), new RegExp('value="' + PHONE + '"'));
});

test('طلب رمز ناجح: الجسم {phone} فقط بلا مصادقة ولا ملف، وننتقل لشاشة الإعادة مع رسالة محايدة (لا ادّعاء بوجود حساب)', async () => {
  const w = world(); const p0 = page(w); await p0.register(); await p0.run('handleLogout()'); await tick(); await tick(); await tick();
  const p = page(w);
  await p.forgot();
  const c = p.calls('/v1/auth/password/forgot');
  assert.equal(c.length, 1);
  assert.deepEqual(c[0].body, { phone: PHONE });
  assert.equal(c[0].headers.authorization, undefined);
  assert.equal(c[0].credentials, 'omit');
  assert.equal(c[0].headers['x-session-transport'], undefined);
  assert.equal(p.route(), 'resetPassword');
  assert.equal(p.param().phone, PHONE);
  assert.match(p.env.screen(), /إن كان الرقم مسجّلًا لدينا فسيصلك رمز/);
});

test('رقم غير مسجَّل: الاستجابة والانتقال والرسالة مطابقة تمامًا (لا تعداد حسابات)', async () => {
  const w = world(); const p0 = page(w); await p0.register(); await p0.run('handleLogout()'); await tick(); await tick(); await tick();
  const known = page(w); await known.forgot(PHONE);
  const unknown = page(w); await unknown.forgot('07799990000');
  assert.equal(known.route(), unknown.route());
  assert.equal(known.env.screen().replace(PHONE, 'P'), unknown.env.screen().replace('07799990000', 'P'));
});

test('مزوّد الرسائل غير مُفعَّل (503 delivery_unavailable): رسالة عربية صريحة، لا انتقال، ولا ادّعاء بأن رمزًا أُرسل', async () => {
  const w = world(); w.srv.delivery = false; const p = page(w);
  await p.forgot();
  assert.equal(p.route(), 'forgotPassword');
  assert.equal(p.text('forgotError'), 'استعادة كلمة المرور غير متاحة الآن: خدمة إرسال الرموز (SMS/واتساب) لم تُفعَّل على الخادم بعد. تواصل مع الدعم.');
  assert.ok(!/سيصلك|تم إرسال/.test(p.env.screen()));
  const r = await p.run("BackendAuth.requestRecovery('07711112222')");
  assert.equal(r.ok, false); assert.equal(r.unavailable, true);
});

test('طلب الرمز: تحقق قبل الشبكة (فارغ، بريد، هاتف خاطئ)، 429 بالدقائق، شبكة، نقرتان', async () => {
  const w = world(); const p = page(w);
  await p.forgot(''); assert.equal(p.text('forgotError'), 'أدخل رقم الهاتف وكلمة المرور.');
  await p.forgot('a@b.com'); assert.equal(p.text('forgotError'), 'تسجيل الدخول عبر الخادم يتم برقم الهاتف فقط.');
  await p.forgot('123'); assert.equal(p.text('forgotError'), 'رقم الهاتف غير صحيح. مثال: 07701234567');
  assert.equal(w.srv.calls.length, 0);
  w.srv.fail = c => (c.path === '/v1/auth/password/forgot' ? errResp(429, 'rate_limited', { 'retry-after': '600' }) : null);
  await p.forgot(); assert.equal(p.text('forgotError'), 'محاولات كثيرة. حاول بعد 10 دقيقة.');
  w.srv.fail = null; w.srv.down = true;
  await p.forgot(); assert.equal(p.text('forgotError'), 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.');
  assert.equal(p.route(), 'forgotPassword');
  w.srv.down = false;
  p.env.run("go('forgotPassword')"); p.set('forgotPhone', PHONE);
  await Promise.all([p.run('handleForgotSubmit()'), p.run('handleForgotSubmit()')]);
  assert.equal(p.calls('/v1/auth/password/forgot').length, 3, 'الطلبان الفاشلان (429، شبكة) + طلب واحد فقط للنقرتين');
});

test('إعادة التعيين ناجحة: الجسم {phone, code, newPassword} فقط، أرقام الرمز العربية تُطبَّع، الحقول تُفرَّغ، وننتقل للدخول برسالة', async () => {
  const w = world(); const p0 = page(w); await p0.register(); await p0.run('handleLogout()'); await tick(); await tick(); await tick();
  const p = page(w);
  await p.forgot();
  await p.reset({ code: '١٢٣٤٥٦' });
  const c = p.calls('/v1/auth/password/reset');
  assert.equal(c.length, 1);
  assert.deepEqual(c[0].body, { phone: PHONE, code: '123456', newPassword: 'New-Passw0rd-9' });
  assert.equal(c[0].headers.authorization, undefined); assert.equal(c[0].credentials, 'omit');
  assert.equal(p.route(), 'login');
  assert.equal(p.text('loginNote'), 'تم تغيير كلمة المرور. سجّل الدخول بكلمة المرور الجديدة.');
  assert.equal(p.val('resetPassword'), ''); assert.equal(p.val('resetConfirm'), ''); assert.equal(p.val('resetCode'), '');
  assert.equal(w.srv.passwords.get(PHONE), 'New-Passw0rd-9');
  assert.ok(!JSON.stringify(p.store).includes('New-Passw0rd-9') && !JSON.stringify(p.env.els).includes('New-Passw0rd-9'));
});

test('رمز خاطئ أو رقم غير مسجَّل: الرسالة نفسها، وتبقى الشاشة، والحقول الحساسة تُفرَّغ', async () => {
  const w = world(); const p0 = page(w); await p0.register(); await p0.run('handleLogout()'); await tick(); await tick(); await tick();
  const p = page(w); await p.forgot();
  await p.reset({ code: '000000' });
  const wrong = p.text('resetError');
  assert.equal(wrong, 'الرمز غير صحيح أو منتهي الصلاحية. اطلب رمزًا جديدًا إن لزم.');
  assert.equal(p.route(), 'resetPassword');
  assert.equal(p.val('resetPassword'), ''); assert.equal(p.val('resetCode'), '');
  await p.reset({ phone: '07799990000', code: '123456' });
  assert.equal(p.text('resetError'), wrong);
  assert.equal(w.srv.passwords.get(PHONE), PASSWORD, 'لم تتغيّر كلمة المرور');
});

test('تحقق العميل قبل الشبكة في الإعادة: رمز بصيغة خاطئة، كلمة مرور قصيرة، عدم تطابق، هاتف خاطئ', async () => {
  const w = world(); const p = page(w);
  await p.reset({ code: '12345' }); assert.equal(p.text('resetError'), 'الرمز مكوّن من 6 أرقام.');
  await p.reset({ code: 'abcdef' }); assert.equal(p.text('resetError'), 'الرمز مكوّن من 6 أرقام.');
  await p.reset({ password: '123', confirm: '123' }); assert.equal(p.text('resetError'), 'كلمة المرور يجب ألا تقل عن 6 أحرف.');
  await p.reset({ confirm: 'other-pass-1' }); assert.equal(p.text('resetError'), 'كلمتا المرور غير متطابقتين.');
  await p.reset({ phone: 'abc' }); assert.equal(p.text('resetError'), 'رقم الهاتف غير صحيح. مثال: 07701234567');
  assert.equal(w.srv.calls.length, 0);
});

test('أخطاء الخادم في الإعادة: سياسة كلمة المرور (حقول)، 429، شبكة، 5xx، ونقرتان = طلب واحد', async () => {
  const w = world(); const p = page(w);
  const run = async (fail, msg) => { w.srv.fail = c => (c.path === '/v1/auth/password/reset' ? fail() : null); await p.reset(); assert.equal(p.text('resetError'), msg); assert.equal(p.route(), 'resetPassword'); };
  await run(() => errResp(400, 'validation_failed', {}, [{ field: 'newPassword', code: 'too_short' }]), 'كلمة المرور يجب ألا تقل عن 6 أحرف.');
  await run(() => errResp(429, 'rate_limited', { 'retry-after': '120' }), 'محاولات كثيرة. حاول بعد 2 دقيقة.');
  await run(() => errResp(500, 'internal'), 'حدث خطأ في الخادم. حاول لاحقًا.');
  w.srv.fail = null; w.srv.down = true;
  await p.reset(); assert.equal(p.text('resetError'), 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.');
  w.srv.down = false;
  const before = p.calls('/v1/auth/password/reset').length;
  p.env.run("go('resetPassword')");
  p.set('resetPhone', PHONE); p.set('resetCode', '123456'); p.set('resetPassword', 'New-Passw0rd-9'); p.set('resetConfirm', 'New-Passw0rd-9');
  await Promise.all([p.run('handleResetSubmit()'), p.run('handleResetSubmit()')]);
  assert.equal(p.calls('/v1/auth/password/reset').length - before, 1);
});

test('أمان الجلسات: نجاح الإعادة يُنهي جلسات الحساب في الخادم؛ تبويب آخر مسجَّل يفقد جلسته عند التجديد ولا تُستعاد بعد إعادة التحميل', async () => {
  const w = world(); const a = page(w);
  await a.register();                                    // تبويب A مسجَّل
  const b = page(w);                                     // تبويب B (زائر) يستعيد الحساب
  b.store[HINT] = '1'; await b.run('restoreBackendSession()');
  assert.equal(b.user().name, NAME);
  w.srv.codes.set(PHONE, '123456');
  await a.run('BackendAuth.completeRecovery({ phone: "07711112222", code: "123456", newPassword: "New-Passw0rd-9" })');
  assert.equal(a.user(), null, 'الحالة المحلية مُسحت فورًا');
  assert.equal(a.store[HINT], undefined);
  w.clock.t += 20 * 60e3;
  await b.run("BackendAuth.api().get('/v1/me').catch(() => null)");
  assert.equal(b.user(), null);                          // فقدت الجلسة
  const c = page(w, a.store);
  assert.equal((await c.run('restoreBackendSession()')).status, 'none');
});

test('لا console ولا تخزين متصفح ولا أسرار في الجسر لهذه التدفقات (حارس مصدر)، وبلا دور في جسم التسجيل', () => {
  const strip = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '').replace(/\/\/[^\n]*$/gm, '');
  const bridge = strip('api/authBridge.js');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\./.test(bridge));
  const reg = bridge.slice(bridge.indexOf('async function register('), bridge.indexOf('async function requestRecovery('));
  assert.match(reg, /client\.register\(\{ name: name, phone: phone, password: pw \}/);
  assert.ok(!/role|accountType|status:/.test(reg.replace(/Role|toLocalShape/g, '')), 'لا يوجد في جسم التسجيل أي دور');
  const actions = strip('navigation/actions.js');
  const handler = actions.slice(actions.indexOf('async function handleRemoteRegister'), actions.indexOf('function handleRegisterSubmit'));
  assert.ok(!/regEmail|accountType\b.*value\s*[,}]/.test(handler.replace(/typeEl\.value === 'dealer'/, '')));
});

test('index.html: لا سكربتات جديدة (87)، ووسوم الإعداد كما هي', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert.equal((html.match(/<script src=/g) || []).length, 87);
  assert.match(html, /<meta name="najaf-api-base-url" content="">/);
});

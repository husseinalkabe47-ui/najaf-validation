/* Phase 11.7.2.2 — استعادة الجلسة بملف ارتباط HttpOnly: عميل الـ API مقابل «خادم» وهمي يحاكي عقد الخلفية الجديد
   (تدوير رمز التجديد + كشف إعادة الاستعمال + ملف ارتباط مشترك بين «تبويبات»). لا متصفح حقيقي ولا خادم حقيقي ولا Fastify:
   المحاكاة تثبت منطق العميل فقط، ولا تغني عن اختبار تكامل فعلي في CI/بيئة حقيقية. */
const test = require('node:test');
const assert = require('node:assert/strict');
const ApiClient = require('../api/apiClient.js');
const { ApiError } = ApiClient;


const { world, T0, iso, tick } = require('./session_world.js');
const credentials = { phone: '07700000001', password: 'pw-secret-1' };
const login = async (t, n) => t.api.login({ phone: '0770000000' + (n || 1), password: 'pw' });

test('الإعداد: نقل الملف يتطلب أصل الصفحة نفسه (لا CORS في الخلفية)، وقيم غير معروفة تُرفض', () => {
  assert.throws(() => ApiClient.create({ baseUrl: 'https://api.other.test', sessionTransport: 'cookie', pageOrigin: 'https://app.test' }), e => e.kind === 'config' && e.code === 'cookie_cross_origin');
  assert.throws(() => ApiClient.create({ baseUrl: 'https://api.other.test', sessionTransport: 'cookie' }), e => e.code === 'cookie_cross_origin', 'بلا أصل صفحة معروف لا نفترض التطابق');
  assert.equal(ApiClient.create({ baseUrl: 'https://app.test/api', sessionTransport: 'cookie', pageOrigin: 'https://app.test' }).sessionTransport, 'cookie');
  assert.equal(ApiClient.create({ baseUrl: '/api', sessionTransport: 'cookie' }).sessionTransport, 'cookie');
  assert.equal(ApiClient.create({ baseUrl: '/' , sessionTransport: 'cookie' }).sessionTransport, 'cookie');
  assert.equal(ApiClient.create({ baseUrl: 'https://x.test' }).sessionTransport, 'body', 'الافتراضي كما في 11.7.2.1');
  assert.throws(() => ApiClient.create({ baseUrl: '/', sessionTransport: 'localStorage' }), e => e.code === 'invalid_transport');
});

test('دخول بنقل الملف: الترويسة وcredentials على نداءات المصادقة فقط، والرد بلا refreshToken، ولا يحتفظ العميل بأي رمز تجديد', async () => {
  const w = world(); const t = w.tab();
  const r = await login(t);
  assert.deepEqual(Object.keys(r), ['user']);
  assert.equal(t.api.hasSession(), true);
  const c = w.srv.calls[0];
  assert.equal(c.headers['x-session-transport'], 'cookie');
  assert.equal(c.credentials, 'same-origin');
  assert.ok(typeof w.jar.rt === 'string' && w.jar.rt.startsWith('nsj_'), 'الخادم وضع الملف');
  await t.api.get('/v1/me');
  const data = w.srv.calls[1];
  assert.equal(data.credentials, 'omit', 'طلبات البيانات لا ترسل ملفات ارتباط');
  assert.equal(data.headers['x-session-transport'], undefined);
  assert.match(data.headers.authorization, /^Bearer AT-/);
  // لا أثر لرمز التجديد في أي مكان يصل إليه JavaScript: لا في الكائن العام ولا في تمثيله النصي
  const dump = JSON.stringify(t.api) + Object.getOwnPropertyNames(t.api).join();
  assert.ok(!dump.includes(w.jar.rt));
});

test('ردّ دخول يحمل refreshToken في نقل الملف يُرفض ولا يُخزَّن، وتُبطَل الجلسة بأفضل جهد', async () => {
  const w = world(); const t = w.tab();
  w.srv.fail = c => c.path === '/v1/auth/login' ? new Response(JSON.stringify({ user: { id: '1' }, session: { accessToken: 'a', accessExpiresAt: iso(T0 + 9e5), refreshToken: 'LEAK', refreshExpiresAt: iso(T0 + 9e8) } }), { status: 200, headers: { 'content-type': 'application/json' } }) : null;
  await assert.rejects(login(t), e => e instanceof ApiError && e.kind === 'invalid_response');
  assert.equal(t.api.hasSession(), false);
});

test('إعادة التحميل: عميل جديد (ذاكرة فارغة) يستعيد الجلسة من الملف بتجديد واحد، ثم تعمل الطلبات برمز وصول جديد', async () => {
  const w = world();
  const t1 = w.tab(); await login(t1, 3);
  const before = w.jar.rt;
  const t2 = w.tab();                                   // صفحة جديدة بعد إعادة التحميل
  assert.equal(t2.api.hasSession(), false);
  const r = await t2.api.restore();
  assert.equal(r.status, 'restored');
  assert.equal(r.user.id, '3');
  assert.equal(t2.api.hasSession(), true);
  assert.notEqual(w.jar.rt, before, 'الرمز دُوِّر');
  assert.equal(w.srv.calls.filter(c => c.path === '/v1/auth/refresh').length, 1);
  assert.deepEqual(await t2.api.get('/v1/me'), { ok: true, userId: 3 });
  assert.equal(w.srv.reuse || 0, 0);
  const refreshCall = w.srv.calls.find(c => c.path === '/v1/auth/refresh');
  assert.equal(refreshCall.body, undefined, 'لا جسم: الرمز من الملف فقط');
  assert.equal(refreshCall.headers['x-session-transport'], 'cookie');
});

test('استعادة بلا ملف / ملف منتهٍ أو مرفوض: none (زائر)، بلا onAuthLost، وبلا استثناء', async () => {
  const w = world(); const t = w.tab();
  assert.deepEqual(await t.api.restore(), { status: 'none' });
  assert.equal(t.lost.length, 0);
  const t1 = w.tab(); await login(t1);
  const fam = [...w.srv.families.values()][0]; fam.revoked = true;   // أُبطلت من مكان آخر
  const t2 = w.tab();
  assert.deepEqual(await t2.api.restore(), { status: 'none' });
  assert.equal(w.jar.rt, null, 'الخادم حذف الملف غير الصالح');
  assert.equal(t2.lost.length, 0);
});

test('فشل عابر أثناء الاستعادة (شبكة/5xx/429): error، والملف لم يُمسّ، وإعادة المحاولة لاحقًا تنجح', async () => {
  const w = world(); const t1 = w.tab(); await login(t1);
  const keep = w.jar.rt;
  const t2 = w.tab();
  w.srv.down = true;
  let r = await t2.api.restore();
  assert.equal(r.status, 'error'); assert.equal(r.error.kind, 'network');
  assert.equal(w.jar.rt, keep);
  w.srv.down = false;
  w.srv.fail = c => c.path === '/v1/auth/refresh' ? new Response(JSON.stringify({ error: { code: 'rate_limited', message: 'x', requestId: 'r' } }), { status: 429, headers: { 'content-type': 'application/json', 'retry-after': '30' } }) : null;
  r = await t2.api.restore(); assert.equal(r.status, 'error'); assert.equal(r.error.status, 429);
  w.srv.fail = c => c.path === '/v1/auth/refresh' ? new Response('boom', { status: 503 }) : null;
  r = await t2.api.restore(); assert.equal(r.status, 'error'); assert.equal(r.error.status, 503);
  assert.equal(w.jar.rt, keep, 'الأعطال لا تمسح الملف');
  w.srv.fail = null;
  assert.equal((await t2.api.restore()).status, 'restored');
  assert.equal(t2.lost.length, 0);
});

test('انتهاء رمز الوصول: تجديد بالملف قبل الإرسال، تدوير الرمز في كل مرة، ولا رمز تجديد يُرسل في الجسم', async () => {
  const w = world(); const t = w.tab(); await login(t);
  const seen = [w.jar.rt];
  for (let i = 0; i < 3; i++) {
    w.clock.t += 20 * 60e3;                             // انتهى رمز الوصول
    assert.equal((await t.api.get('/v1/me')).ok, true);
    seen.push(w.jar.rt);
  }
  assert.equal(new Set(seen).size, 4, 'رمز جديد في كل تجديد');
  assert.equal(w.srv.rotations, 3);
  assert.equal(w.srv.reuse || 0, 0);
  assert.ok(w.srv.calls.filter(c => c.path === '/v1/auth/refresh').every(c => c.body === undefined));
});

test('تزامن: عدة طلبات برمز وصول منتهٍ → تجديد واحد فقط', async () => {
  const w = world(); const t = w.tab(); await login(t);
  w.clock.t += 20 * 60e3;
  const rs = await Promise.all([1, 2, 3, 4, 5].map(() => t.api.get('/v1/me')));
  assert.ok(rs.every(r => r.ok));
  assert.equal(w.srv.calls.filter(c => c.path === '/v1/auth/refresh').length, 1);
});

test('401 من الخادم (رمز وصول أُبطل) → تجديد ثم إعادة واحدة', async () => {
  const w = world(); const t = w.tab(); await login(t);
  w.srv.access.forEach(rec => { rec.exp = 0; });        // الخادم يرفض الرمز الحالي رغم أن العميل يظنه صالحًا
  assert.equal((await t.api.get('/v1/me')).ok, true);
  assert.equal(w.srv.calls.filter(c => c.path === '/v1/auth/refresh').length, 1);
});

test('رفض التجديد (جلسة أُبطلت أو إعادة استعمال): onAuthLost مرة واحدة، تُمسح الجلسة، والملف محذوف', async () => {
  const w = world(); const t = w.tab(); await login(t);
  [...w.srv.families.values()][0].revoked = true;
  w.clock.t += 20 * 60e3;
  await assert.rejects(t.api.get('/v1/me'), e => e.kind === 'auth');
  assert.deepEqual(t.lost, ['refresh_rejected']);
  assert.equal(t.api.hasSession(), false);
  assert.equal(w.jar.rt, null);
});

test('فشل تجديد عابر أثناء الجلسة: لا خروج ولا onAuthLost، وتنجح المحاولة التالية بالملف نفسه', async () => {
  const w = world(); const t = w.tab(); await login(t);
  w.clock.t += 20 * 60e3;
  w.srv.down = true;
  await assert.rejects(t.api.get('/v1/me'), e => e.kind === 'network');
  assert.equal(t.api.hasSession(), true); assert.equal(t.lost.length, 0);
  w.srv.down = false;
  assert.equal((await t.api.get('/v1/me')).ok, true);
});

test('تبويبان يستعيدان في اللحظة نفسها: مع القفل المشترك يتسلسل التجديدان فلا إعادة استعمال ولا إبطال للجلسة', async () => {
  const w = world(); const t0 = w.tab(); await login(t0, 4);
  const a = w.tab(), b = w.tab();                       // نفس القفل ونفس الملف
  w.srv.gate = async () => { await tick(); await tick(); };   // يترك فرصة للتداخل
  const [ra, rb] = await Promise.all([a.api.restore(), b.api.restore()]);
  assert.equal(ra.status, 'restored'); assert.equal(rb.status, 'restored');
  assert.equal(w.srv.reuse || 0, 0, 'لم تُكتشف إعادة استعمال');
  assert.equal([...w.srv.families.values()][0].revoked, false);
  assert.equal(w.srv.rotations, 2, 'كل تبويب دوّر الرمز الأحدث بعد الآخر');
  assert.equal((await a.api.get('/v1/me')).ok, true); assert.equal((await b.api.get('/v1/me')).ok, true);
});

test('الدليل على ضرورة القفل: بدونه يرسل التبويبان الرمز القديم نفسه فتُبطَل الجلسة كلها (سلوك الخلفية الحالي)', async () => {
  const w = world(); const t0 = w.tab(); await login(t0, 4);
  const a = w.tab({ locks: null }), b = w.tab({ locks: null });
  w.srv.gate = async () => { await tick(); await tick(); };
  const rs = await Promise.all([a.api.restore(), b.api.restore()]);
  assert.equal(w.srv.reuse, 1);
  assert.ok(rs.some(r => r.status === 'none'), 'أحدهما فقد الجلسة');
  assert.equal([...w.srv.families.values()][0].revoked, true);
});

test('خروج: تُمسح الذاكرة فورًا، ويُبطل الخادم الجلسة، ويُحذف الملف، وإعادة التحميل لا تستعيد شيئًا', async () => {
  const w = world(); const t = w.tab(); await login(t);
  const p = t.api.logout();
  assert.equal(t.api.hasSession(), false, 'محليًا فورًا');
  assert.deepEqual({ h: (await p).hadSession, r: (await p).revoked }, { h: true, r: true });
  assert.equal(w.jar.rt, null);
  assert.equal([...w.srv.families.values()][0].revoked, true);
  const lo = w.srv.calls.find(c => c.path === '/v1/auth/logout');
  assert.equal(lo.headers['x-session-transport'], 'cookie'); assert.equal(lo.body, undefined);
  assert.deepEqual(await w.tab().api.restore(), { status: 'none' });
});

test('فشل إبلاغ الخادم بالخروج: يخرج محليًا، revoked=false، والملف يبقى لإعادة المحاولة (لا ادّعاء نجاح كاذب)', async () => {
  const w = world(); const t = w.tab(); await login(t);
  const keep = w.jar.rt;
  w.srv.down = true;
  const r = await t.api.logout();
  assert.equal(r.hadSession, true); assert.equal(r.revoked, false); assert.equal(r.error.kind, 'network');
  assert.equal(t.api.hasSession(), false);
  assert.equal(w.jar.rt, keep);
});

test('خروج أثناء تجديد جارٍ: ينتظر التجديد ثم يُبطل الرمز المُدوَّر الأحدث؛ لا جلسة حيّة تبقى', async () => {
  const w = world(); const t = w.tab(); await login(t);
  w.clock.t += 20 * 60e3;
  let release; const hold = new Promise(r => { release = r; });
  w.srv.gate = async c => { if (c.path === '/v1/auth/refresh') await hold; };
  const req = t.api.get('/v1/me').catch(e => e);
  await tick(); await tick();
  const out = t.api.logout();
  release();
  await out; await req;
  assert.equal(t.api.hasSession(), false);
  assert.equal([...w.srv.families.values()][0].revoked, true);
  assert.equal(w.jar.rt, null);
  assert.equal(t.lost.length, 0);
});

test('خروج أثناء استعادة جارية: نتيجة الاستعادة تُهمَل، وتُبطَل الجلسة المُستعادة في الخادم، ولا تُحيا في العميل', async () => {
  const w = world(); const t1 = w.tab(); await login(t1);
  const t = w.tab();
  let release; const hold = new Promise(r => { release = r; });
  w.srv.gate = async c => { if (c.path === '/v1/auth/refresh') await hold; };
  const rp = t.api.restore();
  await tick(); await tick();
  const lo = await t.api.logout();                      // لا جلسة ظاهرة بعد: لا طلب، لكن الهوية تتغيّر
  assert.equal(lo.hadSession, false);
  release();
  assert.equal((await rp).status, 'superseded');
  assert.equal(t.api.hasSession(), false);
  assert.equal([...w.srv.families.values()][0].revoked, true, 'الجلسة التي جدّدها الخادم أُنهيت');
  assert.equal(w.jar.rt, null);
});

test('دخول أثناء استعادة جارية: يتسلسلان بالقفل، والنتيجة النهائية هي حساب الدخول لا الاستعادة القديمة (ولا يعود ملف الحساب القديم)', async () => {
  const w = world(); const t1 = w.tab(); await login(t1, 1);   // مستخدم 1 له ملف
  const t = w.tab();
  let release; const hold = new Promise(r => { release = r; });
  w.srv.gate = async c => { if (c.path === '/v1/auth/refresh') await hold; };
  const rp = t.api.restore();
  await tick(); await tick();
  const lp = t.api.login({ phone: '07700000002', password: 'pw' });
  await tick();
  release();
  const [rr, lr] = await Promise.all([rp, lp]);
  assert.equal(rr.status, 'restored'); assert.equal(rr.user.id, '1');
  assert.equal(lr.user.id, '2');
  const me = await t.api.get('/v1/me');
  assert.equal(me.userId, 2, 'الجلسة الحالية للمستخدم 2');
  const reloaded = await w.tab().api.restore();
  assert.equal(reloaded.user.id, '2', 'ملف الارتباط يخص حساب الدخول الأخير');
});

test('تجديد قديم معلّق ثم دخول بحساب آخر: التجديد يكتمل أولًا (قفل)، فلا يكتب ملف حساب قديم فوق ملف الحساب الجديد', async () => {
  const w = world(); const t = w.tab(); await login(t, 1);
  w.clock.t += 20 * 60e3;
  let release; const hold = new Promise(r => { release = r; });
  w.srv.gate = async c => { if (c.path === '/v1/auth/refresh') await hold; };
  const req = t.api.get('/v1/me').catch(e => e);
  await tick(); await tick();
  const lp = t.api.login({ phone: '07700000002', password: 'pw' });
  release();
  await req; await lp;
  assert.equal((await t.api.get('/v1/me')).userId, 2);
  assert.equal((await w.tab().api.restore()).user.id, '2');
});

test('restore: إن وُجدت جلسة أصلًا لا طلب جديد (active)، وفي وضع الجسم لا استعادة أبدًا', async () => {
  const w = world(); const t = w.tab(); await login(t);
  const n = w.srv.calls.length;
  assert.deepEqual(await t.api.restore(), { status: 'active' });
  assert.equal(w.srv.calls.length, n);
  const body = ApiClient.create({ baseUrl: '/', fetch: w.fetchImpl });
  assert.deepEqual(await body.restore(), { status: 'none' });
  assert.equal(w.srv.calls.length, n);
});

test('استعادتان متتاليتان بالعميل نفسه تتسلسلان ولا تُرسلان رمزًا قديمًا مرتين', async () => {
  const w = world(); const t1 = w.tab(); await login(t1);
  const t = w.tab();
  const [a, b] = await Promise.all([t.api.restore(), t.api.restore()]);
  assert.equal(a.status, 'restored'); assert.equal(b.status, 'active');
  assert.equal(w.srv.reuse || 0, 0);
});

test('لا console ولا تخزين متصفح ولا أسرار في الأخطاء والرسائل أثناء كل ما سبق', async () => {
  const logged = []; const orig = {};
  ['log', 'info', 'warn', 'error', 'debug'].forEach(k => { orig[k] = console[k]; console[k] = (...a) => logged.push(a.map(String).join(' ')); });
  try {
    const w = world(); const t = w.tab();
    await login(t); const rt = w.jar.rt;
    w.srv.down = true; const err = await t.api.restore().catch(e => e); w.srv.down = false;
    await t.api.logout();
    const text = logged.join('|') + JSON.stringify(err);
    assert.ok(!text.includes(rt) && !/AT-\d+|pw/.test(text));
  } finally { Object.assign(console, orig); }
});

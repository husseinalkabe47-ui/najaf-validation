/* Phase 11.7-B — إعلانات المستخدم نفسه (/v1/me/cars) داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/member-cars): GET/POST /v1/me/cars، GET/PATCH/DELETE /v1/me/cars/:id،
   كل الحقول بقائمة بيضاء (حقل مجهول = 400)، رقم الهاتف إلزامي عند الإنشاء، الحالة pending، «sold» من active فقط، version (409)،
   و404 لإعلان غير المالك. لا خادم ولا قاعدة بيانات حقيقية: النتائج هنا لا تُثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const iso = '2026-01-01T00:00:00.000Z';
const FIELDS = ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description', 'phone', 'whatsapp', 'location', 'latitude', 'longitude'];
const REQUIRED = ['brand', 'model', 'year', 'price', 'currency', 'phone'];
const SAME = { mcBrand: 'Kia', mcModel: 'Rio', mcYear: '2020', mcPrice: '25000000', mcPhone: '07709999999', mcWhatsapp: '07709999999', mcLocation: 'النجف' };   // الحقول المحمّلة (لا يقرأ الـDOM الوهمي value من الـHTML)
const E164 = s => { const d = String(s).replace(/\D/g, ''); return /^07[0-9]{9}$/.test(d) ? '+964' + d.slice(1) : /^9647[0-9]{9}$/.test(d) ? '+' + d : null; };

function memberWorld(role) {
  const w = world();
  const d = { role: role || 'user', seq: 100, cars: [], others: [], gate: null, fail: null };
  d.add = (o, mine) => { const c = Object.assign({ id: String(++d.seq), brand: 'Toyota', model: 'Camry', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', phone: '+9647709999999', whatsapp: '+9647709999999', location: 'النجف', latitude: null, longitude: null, status: 'active', rejectionReason: null, suspensionReason: null, version: 1, createdAt: iso, updatedAt: iso }, o); (mine === false ? d.others : d.cars).push(c); return c; };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    if (!u.pathname.startsWith('/v1/me/cars')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const m = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = m && w.srv.access.get(m[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    const mm = /^\/v1\/me\/cars(?:\/([^/]+))?$/.exec(u.pathname);
    if (!mm) return err(404, 'not_found');
    const id = mm[1], b = call.body;
    if (!id) {
      if (call.method === 'GET') {
        const q = Object.keys(call.query).filter(k => !['limit', 'before', 'status'].includes(k)); if (q.length) return err(400, 'validation_failed', q.map(f => ({ field: f, code: 'unknown_field' })));
        const limit = Number(call.query.limit || 20); if (!(limit >= 1 && limit <= 50)) return err(400, 'validation_failed', [{ field: 'limit', code: 'invalid_format' }]);
        let rows = d.cars.slice().sort((a, c) => Number(c.id) - Number(a.id)); if (call.query.before) rows = rows.filter(r => Number(r.id) < Number(call.query.before));
        const page = rows.slice(0, limit);
        return json(200, { items: page.map(x => Object.assign({}, x)), nextBefore: page.length === limit ? page[page.length - 1].id : null });
      }
      if (call.method === 'POST') {
        const bad = []; Object.keys(b).forEach(k => { if (!FIELDS.includes(k)) bad.push({ field: k, code: 'unknown_field' }); });
        REQUIRED.forEach(k => { if (b[k] === undefined || b[k] === null) bad.push({ field: k, code: 'required' }); });
        if (b.phone && !E164(b.phone)) bad.push({ field: 'phone', code: 'invalid_format' });
        if (b.whatsapp && !E164(b.whatsapp)) bad.push({ field: 'whatsapp', code: 'invalid_format' });
        if (bad.length) return err(400, 'validation_failed', bad);
        const c = d.add(Object.assign({}, b, { phone: E164(b.phone), whatsapp: b.whatsapp === undefined ? E164(b.phone) : (b.whatsapp ? E164(b.whatsapp) : null), status: 'pending', version: 1 }));
        return json(201, { car: Object.assign({}, c) });
      }
    }
    const c = d.cars.find(x => x.id === id);
    if (!c) return err(404, 'not_found');
    if (call.method === 'GET') return json(200, { car: Object.assign({}, c) });
    if (call.method === 'PATCH') {
      const bad = []; Object.keys(b).forEach(k => { if (![...FIELDS, 'version', 'status'].includes(k)) bad.push({ field: k, code: 'unknown_field' }); });
      if (b.status !== undefined && b.status !== 'sold') bad.push({ field: 'status', code: 'invalid_format' });
      if (!Number.isInteger(b.version)) bad.push({ field: 'version', code: 'required' });
      if (b.phone && !E164(b.phone)) bad.push({ field: 'phone', code: 'invalid_format' });
      if (bad.length) return err(400, 'validation_failed', bad);
      if (b.version !== c.version) return err(409, 'version_conflict');
      if (b.status === 'sold' && c.status !== 'active') return err(409, 'invalid_state');
      Object.keys(b).forEach(k => { if (k !== 'version') c[k] = k === 'phone' ? E164(b[k]) : b[k]; }); c.version++; return json(200, { car: Object.assign({}, c) });
    }
    if (call.method === 'DELETE') {
      if (!/^[1-9][0-9]{0,9}$/.test(call.query.version || '')) return err(400, 'validation_failed', [{ field: 'version', code: 'required' }]);
      if (Number(call.query.version) !== c.version) return err(409, 'version_conflict');
      d.cars = d.cars.filter(x => x !== c); return new Response(null, { status: 204 });
    }
    return err(405, 'method_not_allowed');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  const p = {
    env, run: c => env.run(c), set, screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    toast: () => env.els.toast && env.els.toast.textContent,
    err: id => env.els[id] && env.els[id].textContent,
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
    fill(o) { Object.entries(Object.assign({ mcBrand: 'Kia', mcModel: 'Sportage', mcYear: '٢٠٢٢', mcPrice: '18,000,000', mcCurrency: 'IQD', mcMileage: '', mcTransmission: 'يدوي', mcFuelType: 'ديزل', mcColor: 'أسود', mcLocation: 'النجف', mcPhone: '07701234567', mcWhatsapp: '', mcDescription: 'وصف' }, o)).forEach(([k, v]) => set(k, v)); },
  };
  return p;
}
const settle = async () => { for (let i = 0; i < 25; i++) await tick(); };
async function open(p, route, param) { await p.login(); p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle(); }
const yes = p => p.run('askConfirm = (spec, ok) => ok()');
const ME = /^\/v1\/me\/cars$/;

test('الوضع المحلي دون تغيير: النماذج والقوائم محلية بلا أي اتصال، ومنتقي الصور وإعلان المكافأة باقيان', async () => {
  const env = makeEnv();
  env.run("AuthService.login('07701234567', 'dealer123')");
  assert.equal(env.run('BackendMember.isEnabled()'), false);
  env.run("go('addMemberCar')"); const h = env.screen();
  assert.match(h, /imgPickerLabel/); assert.match(h, /rewardAdOverlay/);
  env.run("go('myMemberCars')"); assert.match(env.screen(), /ad-row|لا توجد سيارات مضافة/);
  assert.deepEqual(env.errors, []);
});

test('القائمة: GET /v1/me/cars (limit=50) بترويسة دخول؛ الحالة والسبب وزر «مباعة» للنشط فقط؛ لا بيانات محلية ولا إعلانات الآخرين', async () => {
  const { w, d } = memberWorld(); const p = page(w);
  d.add({ brand: 'Kia', model: 'Rio', status: 'active' }); d.add({ brand: 'Honda', model: 'City', status: 'pending' });
  d.add({ brand: 'Nissan', model: 'Sunny', status: 'rejected', rejectionReason: 'صور غير واضحة' }); d.add({ brand: 'Mazda', model: '3', status: 'suspended', suspensionReason: 'مخالفة' });
  d.add({ brand: 'Secret', model: 'Other' }, false);
  await open(p, 'myMemberCars');
  const c = p.calls('GET', ME);
  assert.equal(c.length, 1); assert.equal(c[0].query.limit, '50'); assert.match(c[0].headers.authorization, /^Bearer AT-/);
  const h = p.screen();
  for (const t of ['Kia Rio', 'Honda City', 'Nissan Sunny', 'Mazda 3']) assert.match(h, new RegExp(t));
  assert.ok(!/Secret/.test(h) && !/Corolla|Land Cruiser/.test(h), 'لا بيانات محلية ولا لغير المالك');
  assert.match(h, /صور غير واضحة/); assert.match(h, /مخالفة/);
  assert.equal((h.match(/تحديد كمباعة/g) || []).length, 1, 'للنشط فقط');
  assert.match(h, /go\('memberCarDetails', '10[0-9]'\)/); assert.match(h, /handleDeleteMemberCar\('10[0-9]'\)/);
  assert.ok(!/imgPicker/.test(h)); assert.deepEqual(p.env.errors, []);
});

test('القائمة: فراغ، خطأ خادم/شبكة برسالة وإعادة المحاولة تنجح، 403 = منع، وبلا رجوع صامت للبيانات المحلية', async () => {
  const { w, d } = memberWorld(); const p = page(w);
  await open(p, 'myMemberCars');
  assert.match(p.screen(), /لا توجد سيارات مضافة/); assert.match(p.screen(), /نشر سيارة جديدة/);
  d.add({ brand: 'Kia', model: 'Rio' }); d.fail = c => (c.method === 'GET' ? err(503, 'unavailable') : null);
  p.run("BackendMember.loadList(() => render())"); await settle(); p.run('BackendMember.reset()'); p.run("go('home')"); p.run("go('myMemberCars')"); await settle();
  assert.match(p.screen(), /role="alert"/); assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!/Kia Rio/.test(p.screen()));
  d.fail = null; p.run(_ => 0); p.run("BackendMember.loadList(_rerenderIf('myMemberCars'));render()"); await settle();
  assert.match(p.screen(), /Kia Rio/);
  p.run('BackendMember.reset()'); d.fail = c => err(403, 'forbidden'); p.run("go('home')"); p.run("go('myMemberCars')"); await settle();
  assert.match(p.screen(), /لا يملك صلاحية|لا تملك صلاحية|صلاحية إدارة الإعلانات/); assert.ok(!/Kia Rio/.test(p.screen()));
  d.fail = null; w.srv.down = true; p.run('BackendMember.reset()'); p.run("go('home')"); p.run("go('myMemberCars')"); await settle();
  assert.match(p.screen(), /تعذّر الاتصال/); assert.ok(!/Kia Rio/.test(p.screen()));
});

test('الصفحات: «عرض المزيد» بـ before=nextBefore يُلحق الصفحة التالية؛ وفشله يُبقي القائمة مع رسالة', async () => {
  const { w, d } = memberWorld(); const p = page(w);
  for (let i = 0; i < 55; i++) d.add({ brand: 'Brand' + i, model: 'M' });
  await open(p, 'myMemberCars');
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 50); assert.match(p.screen(), /عرض المزيد/);
  d.fail = c => (c.query.before ? err(503, 'unavailable') : null);
  p.run("BackendMember.loadList(_rerenderIf('myMemberCars'), true);render()"); await settle();
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 50); assert.match(p.screen(), /خطأ في الخادم/);
  d.fail = null; p.run("BackendMember.loadList(_rerenderIf('myMemberCars'), true);render()"); await settle();
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 55); assert.ok(!/عرض المزيد/.test(p.screen()));
  const second = p.calls('GET', ME).find(x => x.query.before); assert.ok(second && second.query.limit === '50');
});

test('إضافة: جسم الطلب بالحقول المسموحة (لا مالك/حالة)، بلا واتساب = لا يُرسل، الأرقام العربية تُحوَّل، pending، ولا صور/إعلان مكافأة', async () => {
  const { w, d } = memberWorld(); const p = page(w);
  await open(p, 'addMemberCar');
  const html = p.screen(); assert.match(html, /mcPhone/); assert.ok(!/imgPickerLabel|rewardAdOverlay|handleWatchRewardAd/.test(html));
  p.fill(); await p.run('handleAddMemberCarSubmit()'); await settle();
  const c = p.calls('POST', ME); assert.equal(c.length, 1);
  assert.deepEqual(c[0].body, { brand: 'Kia', model: 'Sportage', year: 2022, price: 18000000, currency: 'IQD', mileage: null, transmission: 'يدوي', fuelType: 'ديزل', color: 'أسود', description: 'وصف', phone: '07701234567', location: 'النجف' });
  assert.ok(!('ownerId' in c[0].body) && !('status' in c[0].body) && !('whatsapp' in c[0].body));
  assert.match(c[0].headers.authorization, /^Bearer AT-/);
  assert.equal(p.route(), 'myMemberCars'); assert.equal(d.cars.length, 1); assert.equal(d.cars[0].status, 'pending');
  assert.match(p.screen(), /Kia Sportage/); assert.match(p.toast(), /بعد المراجعة/);
  assert.ok(!JSON.stringify(p.env.store).includes('Sportage'), 'لا نسخة محلية');
});

test('إضافة: تحقق الواجهة قبل أي طلب؛ 400 من الخادم يظهر باسم الحقل (الهاتف) بلا إنشاء محلي؛ ضغط مزدوج = طلب واحد؛ فشل 500/شبكة ثم نجاح', async () => {
  const { w, d } = memberWorld(); const p = page(w);
  await open(p, 'addMemberCar');
  p.fill({ mcBrand: '' }); await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /الحقول المطلوبة/);
  p.fill({ mcPhone: '' }); await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /الحقول المطلوبة/);
  p.fill({ mcYear: '1900' }); await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /سنة الصنع/);
  p.fill({ mcPrice: '0' }); await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /السعر/);
  p.fill({ mcCurrency: 'EUR' }); await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /عملة/);
  assert.equal(p.calls('POST', ME).length, 0, 'لا طلب مع بيانات غير صالحة');
  p.fill({ mcPhone: '123' }); await p.run('handleAddMemberCarSubmit()');
  assert.match(p.err('addMemberCarError'), /رقم الهاتف/); assert.equal(p.route(), 'addMemberCar'); assert.equal(d.cars.length, 0);
  p.fill(); let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
  const a = p.run('handleAddMemberCarSubmit()'); const b = p.run('handleAddMemberCarSubmit()');
  await tick(); await tick(); release(); await Promise.all([a, b]); await settle();
  assert.equal(p.calls('POST', ME).length, 2, 'محاولة 400 (هاتف) + طلب واحد للضغطتين');
  assert.equal(d.cars.length, 1); d.gate = null;
  p.run("go('addMemberCar')"); p.fill(); d.fail = c => (c.method === 'POST' ? err(500, 'internal') : null);
  await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /خطأ في الخادم/); assert.equal(d.cars.length, 1);
  d.fail = null; w.srv.down = true; await p.run('handleAddMemberCarSubmit()'); assert.match(p.err('addMemberCarError'), /تعذّر الاتصال/);
  w.srv.down = false; await p.run('handleAddMemberCarSubmit()'); await settle(); assert.equal(d.cars.length, 2);
});

test('تعديل: تُجلب السيارة (GET /:id) ثم PATCH بالإصدار؛ مسح الواتساب = null؛ القائمة تُحدَّث؛ تعارض الإصدار يعيد الجلب ولا يكتب فوقه', async () => {
  const { w, d } = memberWorld(); const p = page(w); const car = d.add({ brand: 'Kia', model: 'Rio', version: 3 });
  await open(p, 'editMemberCar', car.id);
  assert.equal(p.calls('GET', /\/v1\/me\/cars\/\d+$/).length, 1); assert.match(p.screen(), /value="Kia"/); assert.match(p.screen(), /editMemberCarBtn/);
  p.fill(Object.assign({}, SAME, { mcModel: 'Pegas', mcWhatsapp: '', mcColor: 'أبيض', mcDescription: '', mcTransmission: 'أوتوماتيك', mcFuelType: 'بنزين' })); await p.run(`handleEditMemberCarSubmit('${car.id}')`); await settle();
  const pc = p.calls('PATCH', /cars/); assert.equal(pc.length, 1); assert.equal(pc[0].body.version, 3); assert.equal(pc[0].body.model, 'Pegas'); assert.equal(pc[0].body.whatsapp, null);
  assert.ok(!('status' in pc[0].body) && !('ownerId' in pc[0].body));
  assert.equal(car.version, 4); assert.equal(p.route(), 'myMemberCars'); assert.match(p.screen(), /Kia Pegas/);
  // تعارض: تغيّر في مكان آخر
  p.run(`go('editMemberCar', '${car.id}')`); await settle(); car.version = 9; car.model = 'ServerSide';
  p.fill(Object.assign({}, SAME, { mcModel: 'Mine', mcColor: 'أبيض', mcDescription: '', mcTransmission: 'أوتوماتيك', mcFuelType: 'بنزين' })); await p.run(`handleEditMemberCarSubmit('${car.id}')`); await settle();
  assert.match(p.toast(), /تغيّر هذا الإعلان/); assert.equal(car.model, 'ServerSide');
  assert.match(p.screen(), /value="ServerSide"/); assert.equal(p.calls('PATCH', /cars/).length, 2);
});

test('تعديل: إعلان غير المالك/غير موجود = رسالة (404) بلا نموذج؛ و400 باسم الحقل؛ والإرسال المزدوج طلب واحد', async () => {
  const { w, d } = memberWorld(); const p = page(w); const car = d.add({}); d.add({ brand: 'Secret' }, false);
  await open(p, 'editMemberCar', '999');
  assert.match(p.screen(), /الإعلان غير موجود أو لم يعد لك/); assert.ok(!/mcBrand/.test(p.screen()));
  p.run(`go('editMemberCar', '${car.id}')`); await settle();
  d.fail = c => (c.method === 'PATCH' ? err(400, 'validation_failed', [{ field: 'phone', code: 'invalid_format' }]) : null);
  p.fill(Object.assign({}, SAME, { mcPhone: '07705556666', mcColor: 'أبيض', mcDescription: '', mcTransmission: 'أوتوماتيك', mcFuelType: 'بنزين' })); await p.run(`handleEditMemberCarSubmit('${car.id}')`); assert.match(p.err('editMemberCarError'), /رقم الهاتف/); assert.equal(p.route(), 'editMemberCar');
  d.fail = null; let release; d.gate = c => (c.method === 'PATCH' ? new Promise(r => { release = r; }) : null);
  const a = p.run(`handleEditMemberCarSubmit('${car.id}')`); const b = p.run(`handleEditMemberCarSubmit('${car.id}')`);
  await tick(); await tick(); release(); await Promise.all([a, b]); await settle();
  assert.equal(p.calls('PATCH', /cars/).length, 2, 'محاولة 400 + محاولة واحدة ناجحة');
});

test('تحديد «مباعة»: بعد تأكيد، PATCH {version,status:"sold"} للنشط فقط؛ الإلغاء لا يرسل؛ غير النشط لا يُرسل شيئًا؛ تعارض الإصدار يعيد التحميل', async () => {
  const { w, d } = memberWorld(); const p = page(w); const a = d.add({ brand: 'Kia', status: 'active', version: 2 }), b = d.add({ brand: 'Honda', status: 'pending' });
  await open(p, 'myMemberCars'); p.run('askConfirm = (spec, yes, no) => no && no()');
  await p.run(`handleMemberCarStatusChange('${a.id}')`); await settle(); assert.equal(p.calls('PATCH', /cars/).length, 0);
  yes(p); await p.run(`handleMemberCarStatusChange('${b.id}')`); await settle(); assert.equal(p.calls('PATCH', /cars/).length, 0, 'pending لا يُرسل');
  assert.match(p.toast(), /النشط فقط/);
  a.version = 7; await p.run(`handleMemberCarStatusChange('${a.id}')`); await settle();
  assert.equal(p.calls('PATCH', /cars/).length, 1); assert.match(p.toast(), /تغيّر هذا الإعلان/); assert.equal(a.status, 'active');
  await settle(); assert.equal(p.calls('GET', ME).length >= 2, true, 'أُعيد تحميل القائمة');
  await p.run(`handleMemberCarStatusChange('${a.id}')`); await settle();
  const pc = p.calls('PATCH', /cars/); assert.deepEqual(pc[pc.length - 1].body, { version: 7, status: 'sold' });
  assert.equal(a.status, 'sold'); assert.match(p.toast(), /مباع/); assert.ok(!/تحديد كمباعة/.test(p.screen()));
});

test('حذف: تأكيد ثم DELETE ?version=n؛ الإلغاء لا يرسل؛ تعارض يعيد التحميل ولا يحذف؛ نقرتان = طلب واحد؛ فشل الخادم لا يزيل الإعلان', async () => {
  const { w, d } = memberWorld(); const p = page(w); const a = d.add({ brand: 'Kia', model: 'Rio', version: 4 }), b = d.add({ brand: 'Honda', model: 'City' });
  await open(p, 'myMemberCars'); p.run('askConfirm = (spec, yes, no) => no && no()');
  await p.run(`handleDeleteMemberCar('${a.id}')`); await settle(); assert.equal(p.calls('DELETE', /cars/).length, 0);
  yes(p); a.version = 8; await p.run(`handleDeleteMemberCar('${a.id}')`); await settle();
  assert.equal(p.calls('DELETE', /cars/)[0].query.version, '4'); assert.match(p.toast(), /تغيّر هذا الإعلان/); assert.equal(d.cars.length, 2);
  d.fail = c => (c.method === 'DELETE' ? err(503, 'unavailable') : null);
  await Promise.all([p.run(`handleDeleteMemberCar('${b.id}')`), p.run(`handleDeleteMemberCar('${b.id}')`)]); await settle();
  assert.equal(p.calls('DELETE', /cars/).length, 2, 'تعارض + محاولة واحدة'); assert.match(p.toast(), /خطأ في الخادم/); assert.equal(d.cars.length, 2); assert.match(p.screen(), /Honda City/);
  d.fail = null; await p.run(`handleDeleteMemberCar('${b.id}')`); await settle();
  assert.equal(d.cars.some(x => x.id === b.id), false); assert.match(p.toast(), /تم حذف الإعلان/); assert.ok(!/Honda City/.test(p.screen()));
});

test('التفاصيل: إعلاني من GET /v1/me/cars/:id بحالته وسببه وأزراره؛ غير موجود/ليس لي = رسالة؛ خطأ = إعادة محاولة؛ التنقل يعمل', async () => {
  const { w, d } = memberWorld(); const p = page(w); const a = d.add({ brand: 'Kia', model: 'Rio', status: 'rejected', rejectionReason: 'صور غير واضحة', description: 'وصف الإعلان' }), b = d.add({ brand: 'Honda', model: 'City', status: 'active' });
  await open(p, 'memberCarDetails', a.id);
  let h = p.screen(); assert.match(h, /Kia Rio/); assert.match(h, /صور غير واضحة/); assert.match(h, /وصف الإعلان/); assert.match(h, /handleDeleteMemberCar\('/); assert.ok(!/تحديد كمباعة/.test(h));
  p.run(`go('memberCarDetails', '${b.id}')`); await settle(); assert.match(p.screen(), /تحديد كمباعة/);
  p.run("go('memberCarDetails', '999')"); await settle(); assert.match(p.screen(), /الإعلان غير موجود أو لم يعد لك/);
  d.fail = c => (/\/\d+$/.test(c.path) ? err(503, 'unavailable') : null); p.run(`go('memberCarDetails', '${a.id}')`); await settle();
  p.run('BackendMember.reset()'); p.run("go('home')"); p.run(`go('memberCarDetails', '${a.id}')`); await settle();
  assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!/Kia Rio/.test(p.screen()));
  d.fail = null; p.run("BackendMember.loadCar(currentParam, _rerenderIf('memberCarDetails'));render()"); await settle(); assert.match(p.screen(), /Kia Rio/);
  p.run('goBack("myMemberCars")'); assert.equal(p.route() === 'myMemberCars' || p.route() === 'home', true);
});

test('الدخول والجلسة: بلا دخول = login ولا طلب؛ انتهاء الجلسة أثناء الحفظ يعيد للدخول بلا إنشاء محلي؛ الخروج أثناء كتابة لا يلوّث المستخدم التالي', async () => {
  { const { w } = memberWorld(); const p = page(w);
    p.run("go('myMemberCars')"); assert.equal(p.route(), 'login'); p.run("go('addMemberCar')"); assert.equal(p.route(), 'login'); p.run("go('editMemberCar', '1')"); assert.equal(p.route(), 'login');
    assert.equal(w.srv.calls.filter(c => c.path.startsWith('/v1/me/')).length, 0); }
  { const { w, d } = memberWorld(); const p = page(w); await open(p, 'addMemberCar'); p.fill();
    w.srv.families.forEach(f => { f.revoked = true; });
    await p.run('handleAddMemberCarSubmit()'); await settle();
    assert.equal(p.route(), 'login'); assert.equal(d.cars.length, 0); }
  { const { w, d } = memberWorld(); const p = page(w); await open(p, 'addMemberCar'); p.fill();
    let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
    const a = p.run('handleAddMemberCarSubmit()'); await tick(); await tick();
    p.run('handleLogout()'); release(); await a; await settle();
    assert.equal(p.run('BackendMember.list().status'), 'idle'); }
});

test('الحساب: شاشة حسابي تبقى وتعرض الروابط، والمفضلة/الصور/إعلان المكافأة خارج هذه المرحلة (لا طلبات لها)', async () => {
  const { w } = memberWorld(); const p = page(w); await open(p, 'account');
  assert.match(p.screen(), /myMemberCars/); assert.match(p.screen(), /addMemberCar/);
  assert.equal(w.srv.calls.filter(c => /favorites|assets|images/.test(c.path)).length, 0);
});

test('عزل: BackendMember يستعمل /v1/me/cars فقط بلا تخزين/console/fetch ولا بيانات محلية، ولا سكربت جديد (87)', () => {
  const root = path.join(__dirname, '..');
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendMember'), b = all.indexOf('const BackendDealer');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(src.length > 3000);
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|Repository|AppStorage|getMemberCars|MEMBER_CARS/.test(src));
  const paths = [...src.matchAll(/api\.(get|post|patch|delete)\(\s*('[^']+'(?:\s*\+\s*id)?)/g)].map(m => m[1] + ' ' + m[2].replace(/\s+/g, ''));
  assert.deepEqual(paths.sort(), ["delete '/v1/me/cars/'+id", "get '/v1/me/cars'", "get '/v1/me/cars/'+id", "patch '/v1/me/cars/'+id", "patch '/v1/me/cars/'+id", "post '/v1/me/cars'"].sort());
  assert.ok(!/\/v1\/(?!me\/cars)/.test(src));
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.equal((html.match(/<script src=/g) || []).length, 87);
});

/* Phase 11.7.2.2 — استعادة الجلسة داخل التطبيق الفعلي (vm بسكربتات index.html نفسها) مقابل «الخادم» الوهمي في session_world.js.
   fetch والمؤقّتات والساعة وWeb Locks مُحقَنة. لا متصفح ولا خادم حقيقي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const PASSWORD = 'Pa$$w0rd-SECRET-123';
const HINT = 'najaf-auth-hint';

/** يشغّل «صفحة» جديدة (ذاكرة جديدة) بالتخزين نفسه والعالم (الملف + الخادم) نفسه. */
const publess = w => w.srv.calls.filter(c => !/^\/v1\/public\//.test(c.path)).length;   // 11.7-A: طلبات الكتالوج العام لا تُحسب
function page(w, store, opts) {
  opts = opts || {};
  const env = makeEnv(store || {});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = opts.locks === undefined ? w.locks : opts.locks;
  env.ctx.AbortController = AbortController;
  env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  return {
    env, store: env.store, set,
    run: c => env.run(c),
    route: () => env.run('currentRoute'),
    user: () => env.run('SessionService.getCurrentUser()'),
    toast: () => env.els.toast && env.els.toast.textContent,
    restore: () => env.run('restoreBackendSession()'),
    login: async (phone) => { env.run("go('login')"); set('loginIdentifier', phone || '07700000003'); set('loginPassword', PASSWORD); return env.run('handleLoginSubmit()'); },
    logout: async () => { env.run('handleLogout()'); await tick(); await tick(); await tick(); },
  };
}

test('الإعداد المرفق: وسم العنوان فارغ (الوضع المحلي) ووسم النقل cookie؛ والوضع المحلي لا يستعيد ولا يتصل', async () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert.match(html, /<meta name="najaf-api-base-url" content="">/);
  assert.match(html, /<meta name="najaf-session-transport" content="cookie">/);
  const env = makeEnv();
  assert.equal(env.run('BackendAuth.isEnabled()'), false);
  assert.equal(env.run('BackendAuth.canRestore()'), false);
  assert.deepEqual(JSON.parse(JSON.stringify(await env.run('restoreBackendSession()'))), { status: 'none' });
});

test('دخول: يُخزَّن تلميح بوليانيّ فقط (لا رمز)، وكلمة المرور تُفرَّغ، والملف عند الخادم لا في التخزين', async () => {
  const w = world(); const p = page(w);
  await p.login();
  assert.equal(p.user().id, 'srv:3');
  assert.equal(p.store[HINT], '1');
  assert.equal(p.env.els.loginPassword.value, '');
  const dump = JSON.stringify(p.store) + JSON.stringify(p.env.els);
  assert.ok(!dump.includes(w.jar.rt) && !dump.includes(PASSWORD) && !/AT-\d+/.test(dump), 'لا رمز ولا كلمة مرور في التخزين أو الصفحة');
  assert.ok(Object.keys(p.store).every(k => k.startsWith('najaf.') || k === HINT));
  assert.ok(w.jar.rt, 'الملف موجود في «المتصفح» لا في JavaScript');
});

test('إعادة تحميل الصفحة: المستخدم يعود بتجديد واحد، بالدور والاسم من الخادم، وتعمل الشاشات', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const p2 = page(w, p1.store);                          // صفحة جديدة: ذاكرة فارغة، التخزين والملف باقيان
  assert.equal(p2.user(), null, 'قبل الاستعادة زائر');
  const r = await p2.restore();
  assert.equal(r.status, 'restored');
  assert.equal(p2.user().id, 'srv:3');
  assert.equal(p2.run('SessionService.isLoggedIn()'), true);
  assert.equal(w.srv.calls.filter(c => c.path === '/v1/auth/refresh').length, 1);
  assert.equal(w.srv.reuse || 0, 0);
  for (const route of ['home', 'account', 'cars', 'showrooms', 'favorites']) { p2.run(`go('${route}')`); assert.deepEqual(p2.env.errors, []); }
  assert.equal(p2.toast() === undefined || p2.toast() === '' || !/جلسة/.test(p2.toast()), true);
});

test('الاستعادة وأنت على شاشة الدخول: تنتقل للشاشة المطلوبة (returnTo) أو الرئيسية', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const p2 = page(w, p1.store);
  p2.run("go('login', { returnTo: 'recentCars' })");
  await p2.restore();
  assert.equal(p2.route(), 'recentCars');
});

test('بلا تلميح (زائر): لا طلب شبكة إطلاقًا حتى لو وُجد ملف عند المتصفح', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const n = publess(w);
  const p2 = page(w, {});                                // تخزين فارغ = لا تلميح
  assert.equal(p2.run('BackendAuth.canRestore()'), false);
  assert.equal((await p2.restore()).status, 'none');
  assert.equal((await p2.run('BackendAuth.restore()')).status, 'none', 'الجسر نفسه لا يطلب أيضًا');
  assert.equal(publess(w), n);
  assert.equal(p2.user(), null);
});

test('التخزين غير متاح (يرمي): تُجرَّب الاستعادة، ولا استثناء', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const p2 = page(w, {});
  p2.env.ctx.localStorage = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('blocked'); }, removeItem() { throw new Error('blocked'); } };
  const r = await p2.restore();
  assert.equal(r.status, 'restored');
  assert.deepEqual(p2.env.errors, []);
});

test('ملف منتهٍ/مرفوض: زائر بصمت، ويُمسح التلميح فلا طلبات متكررة', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  [...w.srv.families.values()][0].revoked = true;
  const p2 = page(w, p1.store);
  const r = await p2.restore();
  assert.equal(r.status, 'none');
  assert.equal(p2.user(), null);
  assert.equal(p2.store[HINT], undefined);
  assert.ok(!p2.toast(), 'لا رسالة للزائر');
  const n = publess(w);
  const p3 = page(w, p2.store); await p3.restore();
  assert.equal(publess(w), n, 'لا محاولة ثانية');
});

test('فشل شبكة/خادم أثناء الاستعادة: زائر مع رسالة عربية، والتلميح والملف يبقيان، وإعادة المحاولة تنجح', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const keep = w.jar.rt;
  const p2 = page(w, p1.store);
  w.srv.down = true;
  const r = await p2.restore();
  assert.equal(r.status, 'error');
  assert.equal(p2.user(), null);
  assert.match(p2.toast(), /تعذّر الاتصال بالخادم/);
  assert.equal(p2.store[HINT], '1'); assert.equal(w.jar.rt, keep);
  w.srv.down = false;
  assert.equal((await p2.run('BackendAuth.restore()')).status, 'restored');
  assert.equal(p2.user().id, 'srv:3');
});

test('استدعاءان للاستعادة معًا: طلب شبكة واحد', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const p2 = page(w, p1.store);
  const n = publess(w);
  const [a, b] = await Promise.all([p2.run('BackendAuth.restore()'), p2.run('BackendAuth.restore()')]);
  assert.equal(a.status, 'restored'); assert.equal(b.status, 'restored');
  assert.equal(publess(w) - n, 1);
});

test('خروج: يُبطل الخادم الجلسة ويحذف الملف ويمسح التلميح، وإعادة التحميل بعده زائر بلا طلب', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  await p1.logout();
  assert.equal(p1.user(), null);
  assert.equal(p1.store[HINT], undefined);
  assert.equal(w.jar.rt, null);
  assert.equal([...w.srv.families.values()][0].revoked, true);
  const n = publess(w);
  const p2 = page(w, p1.store); assert.equal((await p2.restore()).status, 'none');
  assert.equal(publess(w), n);
});

test('خروج فشل إبلاغ الخادم فيه: يخرج المستخدم ويظهر التنبيه، وتلميح الاستعادة ممسوح (لا استعادة تلقائية لجلسة قال المستخدم إنه أنهاها)', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  w.srv.down = true;
  await p1.logout();
  assert.equal(p1.user(), null);
  assert.equal(p1.store[HINT], undefined);
  assert.ok(p1.toast(), 'تنبيه عربي بأن إبلاغ الخادم تعذّر');
});

test('خروج أثناء استعادة جارية: يبقى زائرًا، لا تُحيا الجلسة، وتُبطَل في الخادم', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const p2 = page(w, p1.store);
  let release; const hold = new Promise(r => { release = r; });
  w.srv.gate = async c => { if (c.path === '/v1/auth/refresh') await hold; };
  const rp = p2.run('BackendAuth.restore()');
  await tick(); await tick();
  await p2.logout();
  release();
  assert.equal((await rp).status, 'superseded');
  assert.equal(p2.user(), null);
  assert.equal([...w.srv.families.values()][0].revoked, true);
  assert.equal(p2.store[HINT], undefined);
});

test('دخول أثناء استعادة جارية: المستخدم الذي دخل هو الحالي بعد الانتهاء', async () => {
  const w = world(); const p1 = page(w); await p1.login('07700000001');
  const p2 = page(w, p1.store);
  let release; const hold = new Promise(r => { release = r; });
  w.srv.gate = async c => { if (c.path === '/v1/auth/refresh') await hold; };
  const rp = p2.run('BackendAuth.restore()');
  await tick(); await tick();
  p2.run("go('login')"); p2.set('loginIdentifier', '07700000002'); p2.set('loginPassword', PASSWORD);
  const lp = p2.run('handleLoginSubmit()');
  await tick();
  release();
  await rp; await lp;
  assert.equal(p2.user().id, 'srv:2');
  assert.equal(p2.run('BackendAuth.api().hasSession()'), true);
});

test('فقدان الجلسة بعد الاستعادة (جلسة أُبطلت): رسالة انتهاء، تحويل للدخول من شاشة محمية، تلميح ممسوح', async () => {
  const w = world(); const p1 = page(w); await p1.login();
  const p2 = page(w, p1.store); await p2.restore();
  p2.run("go('account')");
  [...w.srv.families.values()][0].revoked = true;
  w.clock.t += 20 * 60e3;
  await p2.run("BackendAuth.api().get('/v1/me').catch(() => null)");
  assert.equal(p2.user(), null);
  assert.match(p2.toast(), /انتهت الجلسة/);
  assert.equal(p2.store[HINT], undefined);
  assert.equal(p2.route(), 'login');
});

test('تبويبان يُحمَّلان معًا: القفل المشترك يمنع إبطال الجلسة بإعادة استعمال الرمز', async () => {
  const w = world(); const p0 = page(w); await p0.login();
  const a = page(w, p0.store), b = page(w, p0.store);
  w.srv.gate = async () => { await tick(); await tick(); };
  const [ra, rb] = await Promise.all([a.restore(), b.restore()]);
  assert.equal(ra.status, 'restored'); assert.equal(rb.status, 'restored');
  assert.equal(w.srv.reuse || 0, 0);
  assert.equal(a.user().id, 'srv:3'); assert.equal(b.user().id, 'srv:3');
});

test('حراس المصدر: الجسر لا يذكر التخزين، والمحوّل وحده يعرّف التلميح خارج بادئة التطبيق، والاستعادة لا تلمس الجلسة المحلية', () => {
  const root = path.join(__dirname, '..');
  const strip = f => fs.readFileSync(path.join(root, f), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '').replace(/\/\/[^\n]*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\./.test(strip('api/authBridge.js')));
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\./.test(strip('api/apiClient.js')));
  const adapter = strip('storage/localStorageAdapter.js');
  assert.match(adapter, /const KEY = 'najaf-auth-hint'/);
  assert.ok(!/najaf-auth-hint/.test(strip('api/authBridge.js')));
  assert.ok(!'najaf-auth-hint'.startsWith('najaf.'), 'خارج بادئة AppStorage: لا يُحتسب بيانات تطبيق ولا يُطلق مزامنة التبويبات');
  // لا رموز: المحوّل يكتب القيمة '1' فقط
  assert.match(adapter, /setItem\(KEY, '1'\)/);
});

test('hasData والهجرات لا ترى التلميح (ليس بيانات تطبيق)', async () => {
  const w = world(); const p = page(w); await p.login();
  const fresh = makeEnv({ [HINT]: '1' });
  assert.equal(fresh.run('SchemaRepository.hasData()'), false);
});

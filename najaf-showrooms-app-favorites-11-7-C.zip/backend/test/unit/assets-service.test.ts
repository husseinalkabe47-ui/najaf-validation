// Phase 11.6.2: secure asset upload through the real service, the real policy, the real image sniffer and the real in-memory
// storage provider, over an in-memory asset store that mirrors the SQL and the table constraints.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { crc32 } from 'node:zlib';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { ASSET_UPLOAD_MAX_BYTES, AssetError, MAX_PENDING_PER_DAY, createAssetService } from '../../src/assets/service.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { StorageProvider } from '../../src/storage/index.ts';
import { makeFakeAssetStore } from '../helpers/fake-assets.ts';

const M: Actor = Object.freeze({ id: '1', role: 'member' });
const M2: Actor = Object.freeze({ id: '2', role: 'member' });
const D: Actor = Object.freeze({ id: '3', role: 'dealer' });
const A: Actor = Object.freeze({ id: '4', role: 'admin' });
const FIX = join(import.meta.dirname, '..', 'fixtures', 'images');
const file = (name: string) => new Uint8Array(readFileSync(join(FIX, name)));
const JPG = file('baseline-3x2.jpg');
const PNG = file('rgba-7x3.png');
const WEBP = file('lossy-9x6.webp');

/** A structurally valid PNG header + IEND with the given size (valid CRCs). */
function png(width: number, height: number): Uint8Array {
  const ihdr = Buffer.alloc(17);
  ihdr.write('IHDR', 0, 'ascii');
  ihdr.writeUInt32BE(width, 4);
  ihdr.writeUInt32BE(height, 8);
  ihdr[12] = 8;
  ihdr[13] = 6;
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(ihdr));
  return new Uint8Array(Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13]), ihdr, crc, Buffer.from([0, 0, 0, 0, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82])]));
}

type Flaky = StorageProvider & { putFails: 'no' | 'before' | 'after'; deleteFails: boolean; mem: ReturnType<typeof createMemoryStorage> };
function flaky(maxObjectBytes = 10 * 1024 * 1024): Flaky {
  const mem = createMemoryStorage({ maxObjectBytes });
  const s: Flaky = {
    kind: 'memory', putFails: 'no', deleteFails: false, mem,
    async put(key, body, opts) {
      if (s.putFails === 'before') throw new StorageError('unavailable', 500);
      await mem.put(key, body, opts);
      if (s.putFails === 'after') throw new StorageError('unavailable'); // e.g. a timeout after the object was written
    },
    get: (k) => mem.get(k),
    exists: (k) => mem.exists(k),
    async delete(k) {
      if (s.deleteFails) throw new StorageError('unavailable', 503);
      await mem.delete(k);
    },
  };
  return s;
}

function setup(opts: { maxObjectBytes?: number; now?: () => Date } = {}) {
  const f = makeFakeAssetStore(opts.now ? { now: opts.now } : {});
  for (const a of [M, M2, D, A]) f.addUser(a.id);
  const storage = flaky(opts.maxObjectBytes);
  const logs: Array<Record<string, unknown>> = [];
  let k = 0;
  const svc = createAssetService({ store: f.store, storage, ...(opts.maxObjectBytes ? { maxObjectBytes: opts.maxObjectBytes } : {}), newKeyId: () => `0f8fad5b-d9cb-469f-a165-${String(++k).padStart(12, '0')}`, logger: { warn: (o) => void logs.push(o) } });
  const up = (actor: Actor | null, body: unknown, contentType: unknown = 'image/jpeg', query: unknown = { kind: 'car_image' }) => svc.upload(actor, { query, contentType, body });
  return { f, storage, svc, up, logs };
}
const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isAsset = (code: string) => (e: unknown) => e instanceof AssetError && e.code === code;
async function fieldsOf(p: Promise<unknown>) {
  try {
    await p;
  } catch (e) {
    if (e instanceof AssetError && e.code === 'validation_failed') return e.fields;
    throw e;
  }
  throw new Error('expected validation_failed');
}

describe('asset upload: success', () => {
  it('stores each accepted format under a server key, creates a pending asset owned by the actor, answers a whitelist', async () => {
    const { f, storage, up } = setup();
    for (const [name, type, w, h] of [['baseline-3x2.jpg', 'image/jpeg', 3, 2], ['progressive-exif-5x4.jpg', 'image/jpeg', 5, 4], ['rgba-7x3.png', 'image/png', 7, 3], ['gray16-6x2.png', 'image/png', 6, 2], ['lossy-9x6.webp', 'image/webp', 9, 6], ['lossless-11x5.webp', 'image/webp', 11, 5], ['alpha-13x7.webp', 'image/webp', 13, 7]] as const) {
      const bytes = file(name);
      const asset = await up(M, bytes, type);
      assert.deepEqual(Object.keys(asset).sort(), ['bytes', 'createdAt', 'height', 'id', 'kind', 'status', 'width']);
      assert.deepEqual({ kind: asset.kind, status: asset.status, bytes: asset.bytes, width: asset.width, height: asset.height }, { kind: 'car_image', status: 'pending', bytes: bytes.length, width: w, height: h }, name);
      const row = f.rows().find((r) => r.id === asset.id)!;
      assert.equal(row.ownerId, M.id);
      assert.match(row.storageKey!, /^incoming\/car_image\/0f8fad5b-d9cb-469f-a165-\d{12}$/);
      assert.equal(row.sha256, createHash('sha256').update(bytes).digest('hex'));
      assert.equal(row.mime, null, 'mime is left for the processing step (the table only admits image/webp)');
      const stored = await storage.mem.get(row.storageKey!);
      assert.deepEqual(Buffer.from(stored!.body), Buffer.from(bytes));
      assert.equal(stored!.contentType, type, 'stored with the DETECTED type');
      assert.ok(!JSON.stringify(asset).includes('incoming') && !JSON.stringify(asset).includes(row.sha256!), 'no key or checksum in the answer');
    }
  });

  it('a dealer may upload a showroom cover; the declared type is matched case-insensitively', async () => {
    const { f, up } = setup();
    const a = await up(D, PNG, 'IMAGE/PNG', { kind: 'showroom_cover' });
    assert.equal(a.kind, 'showroom_cover');
    assert.match(f.rows()[0]!.storageKey!, /^incoming\/showroom_cover\//);
  });

  it('each upload gets its own key; the bytes stored are a copy taken before any await', async () => {
    const { f, storage, up } = setup();
    const body = new Uint8Array(JPG);
    const p = up(M, body);
    body.fill(0);
    await p;
    await up(M, JPG);
    const [k1, k2] = f.rows().map((r) => r.storageKey!);
    assert.notEqual(k1, k2);
    assert.deepEqual(Buffer.from((await storage.mem.get(k1!))!.body), Buffer.from(JPG));
  });
});

describe('asset upload: who may upload', () => {
  it('no actor, an administrator, and a member uploading a showroom cover are 403; nothing is stored', async () => {
    const { f, storage, up } = setup();
    await assert.rejects(up(null, JPG), isAuthz('forbidden'));
    await assert.rejects(up(A, JPG), isAuthz('forbidden'));
    await assert.rejects(up(A, JPG, 'image/jpeg', { kind: 'showroom_cover' }), isAuthz('forbidden'));
    await assert.rejects(up(M, JPG, 'image/jpeg', { kind: 'showroom_cover' }), isAuthz('forbidden'));
    assert.equal(f.rows().length, 0);
    assert.equal(storage.mem.size(), 0);
  });

  it('an account suspended since its token was issued is refused inside the transaction; nothing is stored', async () => {
    const { f, storage, up } = setup();
    f.setUser(M.id, 'suspended');
    await assert.rejects(up(M, JPG), isAuthz('forbidden'));
    assert.equal(f.rows().length, 0);
    assert.equal(storage.mem.size(), 0);
  });
});

describe('asset upload: the bytes decide, not the client', () => {
  it('a declared type that is not JPEG/PNG/WebP is 415 (SVG, GIF, HEIC, parameters, missing header)', async () => {
    const { f, svc } = setup();
    for (const t of ['image/svg+xml', 'image/gif', 'image/heic', 'text/html', 'application/octet-stream', 'image/png; charset=utf-8', 'image/jpg', '', undefined, null, ['image/png']]) {
      await assert.rejects(svc.upload(M, { query: { kind: 'car_image' }, contentType: t, body: PNG }), isAsset('unsupported_media_type'), String(t));
    }
    assert.equal(f.rows().length, 0);
  });

  it('bytes that are not the declared image are 400 (mismatch, other formats, polyglots, truncation, corruption)', async () => {
    const { f, storage, up } = setup();
    const bad: Array<[Uint8Array, string, string]> = [
      [PNG, 'image/jpeg', 'PNG declared as JPEG'],
      [JPG, 'image/webp', 'JPEG declared as WebP'],
      [file('refused-4x4.gif'), 'image/png', 'GIF'],
      [file('refused-4x4.bmp'), 'image/jpeg', 'BMP'],
      [file('refused-4x4.tiff'), 'image/png', 'TIFF'],
      [file('refused.svg'), 'image/png', 'SVG with script'],
      [new TextEncoder().encode('<html><script>alert(1)</script></html>'), 'image/jpeg', 'HTML'],
      [new Uint8Array([...PNG, ...new TextEncoder().encode('<script>alert(1)</script>')]), 'image/png', 'PNG + appended script'],
      [PNG.slice(0, PNG.length - 12), 'image/png', 'PNG without IEND'],
      [(() => { const b = new Uint8Array(PNG); b[29] ^= 0xff; return b; })(), 'image/png', 'PNG with a bad IHDR CRC'],
      [JPG.slice(0, JPG.length - 2), 'image/jpeg', 'JPEG without EOI'],
      [JPG.slice(0, 40), 'image/jpeg', 'JPEG truncated before the frame'],
      [WEBP.slice(0, WEBP.length - 1), 'image/webp', 'WebP shorter than its RIFF size'],
      [new Uint8Array([...WEBP, 0]), 'image/webp', 'WebP with trailing bytes'],
    ];
    for (const [bytes, type, label] of bad) assert.deepEqual(await fieldsOf(up(M, bytes, type)), [{ field: 'body', code: 'invalid_format' }], label);
    assert.equal(f.rows().length, 0);
    assert.equal(storage.mem.size(), 0);
  });

  it('an empty or non-byte body is 400; a body over the limit is 413 (and the storage limit wins when smaller)', async () => {
    const { up } = setup();
    for (const body of [undefined, null, '', 'abc', {}, new Uint8Array(0)]) assert.deepEqual(await fieldsOf(up(M, body)), [{ field: 'body', code: 'required' }]);
    await assert.rejects(up(M, new Uint8Array(ASSET_UPLOAD_MAX_BYTES + 1)), isAsset('too_large'));
    const small = setup({ maxObjectBytes: 100 });
    await assert.rejects(small.up(M, JPG), isAsset('too_large'));
    assert.equal(small.storage.mem.size(), 0);
  });

  it('dimensions are bounded (per side and in total pixels) before anything is stored', async () => {
    const { f, up } = setup();
    await up(M, png(10_000, 4_000), 'image/png');
    for (const [w, h] of [[10_001, 10], [10, 10_001], [8_000, 6_000]]) await assert.rejects(up(M, png(w, h), 'image/png'), isAsset('too_large'), `${w}x${h}`);
    assert.equal(f.rows().length, 1);
  });

  it('the query is a strict whitelist: kind only; a filename, key, owner or status is refused', async () => {
    const { f, up } = setup();
    assert.deepEqual(await fieldsOf(up(M, JPG, 'image/jpeg', {})), [{ field: 'kind', code: 'required' }]);
    assert.deepEqual(await fieldsOf(up(M, JPG, 'image/jpeg', { kind: 'avatar' })), [{ field: 'kind', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(up(M, JPG, 'image/jpeg', { kind: ['car_image'] })), [{ field: 'kind', code: 'invalid_type' }]);
    for (const k of ['filename', 'storageKey', 'storage_key', 'key', 'ownerId', 'status', 'mime']) {
      assert.deepEqual(await fieldsOf(up(M, JPG, 'image/jpeg', { kind: 'car_image', [k]: '../../x' })), [{ field: k, code: 'unknown_field' }], k);
    }
    assert.deepEqual(await fieldsOf(up(M, JPG, 'image/jpeg', 'kind=car_image')), [{ field: 'query', code: 'invalid_type' }]);
    assert.equal(f.rows().length, 0);
    assert.deepEqual(f.calls, [], 'invalid input never reaches the database');
  });
});

describe('asset upload: quota', () => {
  it(`at most ${MAX_PENDING_PER_DAY} pending uploads per owner in 24 hours (409 upload_limit); older or processed ones do not count`, async () => {
    const { f, storage, up } = setup();
    f.addAsset({ ownerId: M.id, createdAt: new Date(Date.now() - 25 * 3600 * 1000) });
    f.addAsset({ ownerId: M.id, status: 'ready' });
    f.addAsset({ ownerId: M2.id });
    for (let i = 0; i < MAX_PENDING_PER_DAY; i++) await up(M, JPG);
    await assert.rejects(up(M, JPG), isAsset('upload_limit'));
    assert.equal(storage.mem.size(), MAX_PENDING_PER_DAY, 'the refused upload stored nothing');
    await up(M2, JPG);
  });

  it('concurrent uploads cannot exceed the quota', async () => {
    const { f, up } = setup();
    const results = await Promise.allSettled(Array.from({ length: MAX_PENDING_PER_DAY + 7 }, () => up(M, JPG)));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, MAX_PENDING_PER_DAY);
    for (const r of results) if (r.status === 'rejected') assert.ok(isAsset('upload_limit')(r.reason));
    assert.equal(f.rows().length, MAX_PENDING_PER_DAY);
  });
});

describe('asset upload: failures leave nothing unknown behind', () => {
  it('a failed storage write removes the object and the row; the client gets 503; the log has ids and codes only', async () => {
    const { f, storage, up, logs } = setup();
    for (const mode of ['before', 'after'] as const) {
      storage.putFails = mode;
      await assert.rejects(up(M, JPG), isAsset('storage_unavailable'), mode);
      assert.equal(storage.mem.size(), 0, `${mode}: no object left`);
      assert.equal(f.rows().length, 0, `${mode}: no row left`);
    }
    assert.equal(logs.length, 2);
    for (const l of logs) {
      assert.equal(l['event'], 'assets.upload_failed');
      assert.equal(l['cleanedUp'], true);
      assert.ok(!JSON.stringify(l).includes('incoming'), 'the storage key is never logged');
    }
  });

  it('when the object cannot be deleted, the pending row is KEPT (with its key) for the cleanup job', async () => {
    const { f, storage, up, logs } = setup();
    storage.putFails = 'after';
    storage.deleteFails = true;
    await assert.rejects(up(M, JPG), isAsset('storage_unavailable'));
    assert.equal(f.rows().length, 1);
    assert.equal(f.rows()[0]!.status, 'pending');
    assert.ok(await storage.mem.exists(f.rows()[0]!.storageKey!), 'the object that may exist is still findable through the row');
    assert.equal(logs[0]!['cleanedUp'], false);
  });

  it('when the row cannot be deleted after the object was, the row stays pending (no object): the cleanup job removes it', async () => {
    const { f, storage, up } = setup();
    storage.putFails = 'before';
    f.faults.failDelete = true;
    await assert.rejects(up(M, JPG), isAsset('storage_unavailable'));
    assert.equal(f.rows().length, 1);
    assert.equal(storage.mem.size(), 0);
  });

  it('a failed database insert writes nothing to storage', async () => {
    const { f, storage, up } = setup();
    f.faults.failInsert = true;
    await assert.rejects(up(M, JPG));
    assert.equal(storage.mem.size(), 0);
    assert.equal(f.rows().length, 0);
  });

  it('an unsafe generated key (a bug) is refused before the database and the storage are touched', async () => {
    const f = makeFakeAssetStore();
    f.addUser(M.id);
    const storage = createMemoryStorage();
    const svc = createAssetService({ store: f.store, storage, newKeyId: () => '../../etc' });
    await assert.rejects(svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: JPG }), (e: unknown) => e instanceof StorageError && e.code === 'invalid_key');
    assert.equal(f.rows().length, 0);
    assert.equal(storage.size(), 0);
  });
});

describe('asset read: own only', () => {
  it('the owner reads its asset; anyone else (an administrator included), an unknown and a malformed id get the same 404', async () => {
    const { f, svc, up } = setup();
    const a = await up(M, JPG);
    assert.deepEqual(await svc.getOwn(M, a.id.toUpperCase()), a);
    for (const who of [M2, D, A, null]) await assert.rejects(svc.getOwn(who, a.id), isAuthz('not_found'));
    await assert.rejects(svc.getOwn(M, 'a0000000-0000-4000-8000-999999999999'), isAuthz('not_found'));
    f.calls.length = 0;
    for (const id of ['abc', '../x', '', undefined, 1, a.id + 'x']) await assert.rejects(svc.getOwn(M, id), isAuthz('not_found'));
    assert.deepEqual(f.calls, []);
  });
});

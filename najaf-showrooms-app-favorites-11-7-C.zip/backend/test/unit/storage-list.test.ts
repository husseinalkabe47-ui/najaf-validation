// Phase 11.6.4: object listing for the cleanup job. The same contract against the R2 provider (over the fake S3 endpoint, which
// verifies every signature INCLUDING the query) and the in-memory provider; the R2 request signature against botocore; and the
// strict parsing of the ListObjectsV2 answer.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { LIST_MAX_KEYS, StorageError, createMemoryStorage, createS3Storage, createStorage, isListable } from '../../src/storage/index.ts';
import type { ListableStorage, ListedObject } from '../../src/storage/index.ts';
import { LIST_RESPONSE_MAX_BYTES, parseListObjectsV2 } from '../../src/storage/s3.ts';
import { makeFakeS3 } from '../helpers/fake-s3.ts';

const SECRET = 'q7Rk2vN9xT4bL8mZ3cW6yH1jP5sF0dGaE9uK2rQ7vX4nB8tM';
const AKID = 'f3a9c27d41b8e6a05c9d2e7b1a4f8c63';
const S3 = { endpoint: 'https://acct0123.r2.cloudflarestorage.test', region: 'auto', bucket: 'najaf-media', accessKeyId: AKID, secretAccessKey: SECRET };
const NOW = new Date(Date.UTC(2026, 9, 9, 0, 0, 0));
const bytes = (s: string) => new TextEncoder().encode(s);
const LEAKS = [SECRET, AKID, 'acct0123', 'najaf-media', 'cloudflarestorage', 'processed/', 'incoming/', 'InternalError'];

function r2(opts: { keyPrefix?: string } = {}) {
  const fake = makeFakeS3({ host: 'acct0123.r2.cloudflarestorage.test', bucket: S3.bucket, region: S3.region, accessKeyId: AKID, secretAccessKey: SECRET });
  const storage = createS3Storage({ s3: S3, keyPrefix: opts.keyPrefix ?? '', timeoutMs: 1000, maxObjectBytes: 1024 }, { fetch: fake.fetch, now: () => NOW });
  return { fake, storage };
}
async function noLeak(p: Promise<unknown>, code: string) {
  try {
    await p;
    assert.fail('expected a StorageError');
  } catch (e) {
    assert.ok(e instanceof StorageError, String(e));
    assert.equal(e.code, code);
    const text = `${e.message} ${e.stack} ${JSON.stringify(e)}`;
    for (const s of LEAKS) assert.ok(!text.includes(s), `error leaks ${s}`);
  }
}
async function listAll(s: ListableStorage, prefix: string, maxKeys: number): Promise<{ keys: string[]; pages: number }> {
  const keys: string[] = [];
  let token: string | null = null;
  let pages = 0;
  do {
    const page = await s.list(prefix, { maxKeys, token });
    pages++;
    assert.ok(page.objects.length <= maxKeys);
    keys.push(...page.objects.map((o: ListedObject) => o.key));
    token = page.nextToken;
  } while (token !== null);
  return { keys, pages };
}

const KEYS = ['incoming/car_image/0a', 'incoming/car_image/0b', 'incoming/car_image/1c', 'incoming/showroom_cover/2d', 'processed/car_image/0a.webp', 'thumbs/car_image/0a.webp', 'cars/1/legacy/full.webp', 'incomingX/z'];

const providers: Array<[string, (o?: { keyPrefix?: string }) => ListableStorage]> = [
  ['r2', (o) => r2(o).storage],
  ['memory', (o) => createMemoryStorage({ maxObjectBytes: 1024, ...o })],
];
for (const [name, make] of providers) {
  describe(`storage listing contract: ${name}`, () => {
    it('lists exactly the keys that start with the prefix, in key order, relative to the configured prefix', async () => {
      for (const keyPrefix of ['', 'env/prod']) {
        const s = make({ keyPrefix });
        for (const k of KEYS) await s.put(k, bytes(k), { contentType: 'image/webp' });
        assert.deepEqual((await listAll(s, 'incoming/', 1000)).keys, ['incoming/car_image/0a', 'incoming/car_image/0b', 'incoming/car_image/1c', 'incoming/showroom_cover/2d']);
        assert.deepEqual((await listAll(s, 'incoming/car_image/0', 1000)).keys, ['incoming/car_image/0a', 'incoming/car_image/0b'], 'a prefix may end inside a segment (uuid shards)');
        assert.deepEqual((await listAll(s, 'incoming', 1000)).keys, ['incoming/car_image/0a', 'incoming/car_image/0b', 'incoming/car_image/1c', 'incoming/showroom_cover/2d', 'incomingX/z'], 'no trailing "/" = a plain string prefix');
        assert.deepEqual((await listAll(s, 'nothing/', 1000)).keys, []);
        const page = await s.list('processed/', { maxKeys: 10 });
        assert.deepEqual(page.objects.map((o) => [o.key, o.size]), [['processed/car_image/0a.webp', 'processed/car_image/0a.webp'.length]]);
        assert.ok(page.objects[0]!.lastModified instanceof Date && !Number.isNaN(page.objects[0]!.lastModified.getTime()));
        assert.equal(page.nextToken, null);
        assert.equal(page.skipped, 0);
      }
    });

    it('pages with maxKeys: every key exactly once, a token while more remain, none after the last page', async () => {
      const s = make();
      const keys = Array.from({ length: 7 }, (_, i) => `thumbs/car_image/k${i}.webp`);
      for (const k of [...keys].reverse()) await s.put(k, bytes('x'), { contentType: 'image/webp' });
      for (const max of [1, 2, 3, 6, 7, 8]) {
        const r = await listAll(s, 'thumbs/', max);
        assert.deepEqual(r.keys, keys, `maxKeys ${max}`);
        assert.equal(r.pages, Math.ceil(7 / max), `pages for maxKeys ${max}`);
      }
      const first = await s.list('thumbs/', { maxKeys: 3 });
      assert.equal(first.objects.length, 3);
      assert.notEqual(first.nextToken, null);
      const last = await s.list('thumbs/', { maxKeys: 7 });
      assert.equal(last.nextToken, null);
    });

    it('refuses an unsafe prefix BEFORE any I/O, and a maxKeys outside 1..1000', async () => {
      const s = make();
      for (const bad of ['', '/', '../x', 'a//', 'a/../b', '/incoming', 'a b', 'incoming//', '.hidden/', 'x\\y', 'a%2F', undefined, 7]) {
        await assert.rejects(s.list(bad as string, { maxKeys: 1 }), (e: unknown) => e instanceof StorageError && e.code === 'invalid_key', String(bad));
      }
      for (const bad of [0, -1, 1.5, LIST_MAX_KEYS + 1, Number.NaN, '10']) {
        await assert.rejects(s.list('incoming/', { maxKeys: bad as number }), RangeError, String(bad));
      }
      await s.list('incoming/', { maxKeys: LIST_MAX_KEYS });
      await s.list('incoming/', { maxKeys: 1 });
    });
  });
}

describe('storage listing: providers', () => {
  it('both providers (and createStorage) are listable', () => {
    assert.ok(isListable(r2().storage));
    assert.ok(isListable(createMemoryStorage()));
    assert.ok(isListable(createStorage({ provider: 'memory', keyPrefix: '', maxObjectBytes: 10, timeoutMs: 10 } as never)));
    assert.equal(isListable({ kind: 'memory', put: async () => undefined, get: async () => null, delete: async () => undefined, exists: async () => false }), false);
  });

  it('memory: last-modified comes from the clock at put time and can be set by the test helper', async () => {
    let t = new Date(Date.UTC(2026, 0, 1));
    const s = createMemoryStorage({ now: () => t });
    await s.put('incoming/car_image/a', bytes('a'), { contentType: 'image/webp' });
    t = new Date(Date.UTC(2026, 0, 2));
    await s.put('incoming/car_image/b', bytes('b'), { contentType: 'image/webp' });
    const p = await s.list('incoming/', { maxKeys: 10 });
    assert.deepEqual(p.objects.map((o) => o.lastModified.toISOString()), ['2026-01-01T00:00:00.000Z', '2026-01-02T00:00:00.000Z']);
    assert.equal(s.touch('incoming/car_image/a', new Date(0)), true);
    assert.equal(s.touch('incoming/car_image/zz', new Date(0)), false);
    assert.equal((await s.list('incoming/', { maxKeys: 10 })).objects[0]!.lastModified.getTime(), 0);
  });

  it('memory: a token from another prefix (or not a string) is refused', async () => {
    const s = createMemoryStorage();
    await s.put('incoming/car_image/a', bytes('a'), { contentType: 'image/webp' });
    await assert.rejects(s.list('thumbs/', { maxKeys: 1, token: 'incoming/car_image/a' }), RangeError);
    await assert.rejects(s.list('thumbs/', { maxKeys: 1, token: 5 as never }), RangeError);
  });
});

describe('storage listing: R2 requests', () => {
  it('sends a signed ListObjectsV2 GET on the bucket (path-style), with prefix (configured prefix included), max-keys and the token', async () => {
    const { fake, storage } = r2({ keyPrefix: 'env/prod' });
    for (const k of ['incoming/car_image/a', 'incoming/car_image/b', 'incoming/car_image/c']) await storage.put(k, bytes('x'), { contentType: 'image/webp' });
    fake.seen.length = 0;
    const p1 = await storage.list('incoming/', { maxKeys: 2 });
    const p2 = await storage.list('incoming/', { maxKeys: 2, token: p1.nextToken });
    assert.deepEqual([...p1.objects, ...p2.objects].map((o) => o.key), ['incoming/car_image/a', 'incoming/car_image/b', 'incoming/car_image/c']);
    assert.equal(fake.seen.length, 2);
    for (const r of fake.seen) {
      assert.equal(r.method, 'GET');
      assert.equal(r.path, '/najaf-media');
      assert.equal(r.redirect, 'error');
      assert.equal(r.hasSignal, true);
      const u = new URL(r.url);
      assert.equal(u.searchParams.get('list-type'), '2');
      assert.equal(u.searchParams.get('prefix'), 'env/prod/incoming/');
      assert.equal(u.searchParams.get('max-keys'), '2');
      assert.match(r.headers['authorization']!, /^AWS4-HMAC-SHA256 /);
    }
    assert.equal(new URL(fake.seen[0]!.url).searchParams.has('continuation-token'), false);
    assert.equal(new URL(fake.seen[1]!.url).searchParams.get('continuation-token'), p1.nextToken);
  });

  it('a request whose query was not signed is refused by the endpoint (the fake verifies the query too)', async () => {
    const { fake } = r2();
    const res = await fake.fetch('https://acct0123.r2.cloudflarestorage.test/najaf-media?list-type=2&prefix=incoming%2F&max-keys=1', { method: 'GET', headers: {} });
    assert.equal(res.status, 403);
  });

  it(`matches botocore's signature on generated ListObjectsV2 requests (hosts, regions, prefixes, tokens, dates)`, async () => {
    const d = JSON.parse(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'sigv4-botocore-list-vectors.json'), 'utf8')) as {
      cases: Array<{ host: string; region: string; bucket: string; prefix: string; maxKeys: number; token: string | null; accessKeyId: string; secretAccessKey: string; now: string; expected: Record<string, string> }>;
    };
    assert.equal(d.cases.length, 24);
    for (const c of d.cases) {
      let seen: { url: string; headers: Record<string, string> } | undefined;
      const fetchFn = (async (url: string, init: RequestInit) => {
        seen = { url: String(url), headers: init.headers as Record<string, string> };
        return new Response('<ListBucketResult><IsTruncated>false</IsTruncated></ListBucketResult>', { status: 200 });
      }) as unknown as typeof fetch;
      const s = createS3Storage(
        { s3: { endpoint: `https://${c.host}`, region: c.region, bucket: c.bucket, accessKeyId: c.accessKeyId, secretAccessKey: c.secretAccessKey }, keyPrefix: '', timeoutMs: 1000, maxObjectBytes: 1024 },
        { fetch: fetchFn, now: () => new Date(c.now) },
      );
      const page = await s.list(c.prefix, { maxKeys: c.maxKeys, token: c.token });
      assert.deepEqual(page, { objects: [], skipped: 0, nextToken: null });
      assert.equal(seen!.headers['authorization'], c.expected['authorization'], `${c.bucket} ${c.prefix}`);
      assert.equal(seen!.headers['x-amz-date'], c.expected['x-amz-date']);
      assert.equal(seen!.headers['x-amz-content-sha256'], c.expected['x-amz-content-sha256']);
      const u = new URL(seen!.url);
      assert.equal(u.pathname, `/${c.bucket}`);
      assert.equal(u.searchParams.get('prefix'), c.prefix);
      assert.equal(u.searchParams.get('continuation-token'), c.token);
    }
  });

  it('a backend failure, a network failure or a redirect is unavailable, without the URL, bucket, prefix or credentials', async () => {
    for (const fault of ['status', 'network', 'redirect'] as const) {
      const { fake, storage } = r2();
      if (fault === 'status') {
        fake.faults.status = 500;
        fake.faults.statusBody = '<Error><Code>InternalError</Code><Resource>/najaf-media?prefix=incoming/</Resource></Error>';
      } else if (fault === 'network') fake.faults.network = true;
      else fake.faults.redirect = true;
      await noLeak(storage.list('incoming/', { maxKeys: 5 }), 'unavailable');
    }
    const { fake, storage } = r2();
    fake.faults.status = 403;
    await assert.rejects(storage.list('incoming/', { maxKeys: 5 }), (e: unknown) => e instanceof StorageError && e.status === 403);
  });

  it('a malformed or unexpected answer is integrity (never a partial or guessed listing)', async () => {
    const wrap = (inner: string) => `<?xml version="1.0" encoding="UTF-8"?>\n<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">${inner}</ListBucketResult>`;
    const entry = (k: string, size = '3', at = '2026-01-01T00:00:00.000Z') => `<Contents><Key>${k}</Key><LastModified>${at}</LastModified><Size>${size}</Size></Contents>`;
    const bad = [
      'not xml at all',
      '<Error><Code>AccessDenied</Code></Error>',
      wrap(entry('incoming/a')), // no IsTruncated
      wrap('<IsTruncated>maybe</IsTruncated>'),
      wrap('<IsTruncated>true</IsTruncated>' + entry('incoming/a')), // truncated without a token
      wrap('<IsTruncated>false</IsTruncated><IsTruncated>true</IsTruncated>'),
      wrap('<IsTruncated>false</IsTruncated>' + entry('processed/a')), // outside the requested prefix
      wrap('<IsTruncated>false</IsTruncated>' + entry('incoming/a', 'x')),
      wrap('<IsTruncated>false</IsTruncated>' + entry('incoming/a', '3', 'yesterday')),
      wrap('<IsTruncated>false</IsTruncated><Contents><Key>incoming/a</Key><Size>3</Size></Contents>'),
      wrap('<IsTruncated>false</IsTruncated><Contents><Key>incoming/a</Key><Key>incoming/b</Key><LastModified>2026-01-01T00:00:00Z</LastModified><Size>3</Size></Contents>'),
      wrap('<IsTruncated>false</IsTruncated>' + entry('incoming/a') + entry('incoming/b') + entry('incoming/c')), // more than maxKeys (2)
      wrap('<IsTruncated>false</IsTruncated>' + entry('incoming/a&b')), // a bare ampersand
      wrap('<IsTruncated>false</IsTruncated>' + entry('incoming/a&#0;')),
      wrap('<IsTruncated>false</IsTruncated>') + '<trailing/>',
    ];
    for (const body of bad) {
      const { fake, storage } = r2();
      fake.faults.listBody = body;
      await noLeak(storage.list('incoming/', { maxKeys: 2 }), 'integrity');
    }
    // Not UTF-8.
    const fetchFn = (async () => new Response(new Uint8Array([0x3c, 0xff, 0xfe, 0x3e]), { status: 200 })) as unknown as typeof fetch;
    const s = createS3Storage({ s3: S3, keyPrefix: '', timeoutMs: 1000, maxObjectBytes: 1024 }, { fetch: fetchFn, now: () => NOW });
    await noLeak(s.list('incoming/', { maxKeys: 2 }), 'integrity');
  });

  it('an answer larger than the listing limit is refused (announced or streamed)', async () => {
    assert.equal(LIST_RESPONSE_MAX_BYTES, 4 * 1024 * 1024);
    const announced = (async () => new Response('<x/>', { status: 200, headers: { 'content-length': String(LIST_RESPONSE_MAX_BYTES + 1) } })) as unknown as typeof fetch;
    const s1 = createS3Storage({ s3: S3, keyPrefix: '', timeoutMs: 1000, maxObjectBytes: 1024 }, { fetch: announced, now: () => NOW });
    await noLeak(s1.list('incoming/', { maxKeys: 2 }), 'too_large');
    const streamed = (async () =>
      new Response(
        new ReadableStream<Uint8Array>({
          start(c) {
            c.enqueue(new Uint8Array(LIST_RESPONSE_MAX_BYTES));
            c.enqueue(new Uint8Array(1));
            c.close();
          },
        }),
        { status: 200 },
      )) as unknown as typeof fetch;
    const s2 = createS3Storage({ s3: S3, keyPrefix: '', timeoutMs: 1000, maxObjectBytes: 1024 }, { fetch: streamed, now: () => NOW });
    await noLeak(s2.list('incoming/', { maxKeys: 2 }), 'too_large');
  });

  it('unsafe listed keys are skipped (counted, never returned); XML entities are decoded; the configured prefix is stripped', () => {
    const xml = `<ListBucketResult><IsTruncated>true</IsTruncated>
      <Contents><Key>p/incoming/ok.webp</Key><LastModified>2026-01-01T00:00:00.000Z</LastModified><Size>3</Size></Contents>
      <Contents><Key>p/incoming/../../etc</Key><LastModified>2026-01-01T00:00:00.000Z</LastModified><Size>3</Size></Contents>
      <Contents><Key>p/incoming/a b</Key><LastModified>2026-01-01T00:00:00.000Z</LastModified><Size>3</Size></Contents>
      <Contents><Key>p/incoming/x&amp;y</Key><LastModified>2026-01-01T00:00:00.000Z</LastModified><Size>3</Size></Contents>
      <Contents><Key>p/incoming//double</Key><LastModified>2026-01-01T00:00:00.000Z</LastModified><Size>3</Size></Contents>
      <NextContinuationToken>a+b/c&amp;d&#61;</NextContinuationToken></ListBucketResult>`;
    const r = parseListObjectsV2(xml, { keyPrefix: 'p', requestedPrefix: 'p/incoming/', maxKeys: 10 });
    assert.deepEqual(r.objects.map((o) => o.key), ['incoming/ok.webp']);
    assert.equal(r.skipped, 4);
    assert.equal(r.nextToken, 'a+b/c&d=');
    assert.equal(r.objects[0]!.size, 3);
    assert.equal(r.objects[0]!.lastModified.toISOString(), '2026-01-01T00:00:00.000Z');
  });
});

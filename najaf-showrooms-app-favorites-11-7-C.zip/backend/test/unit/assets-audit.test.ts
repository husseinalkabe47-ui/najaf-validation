// Phase 11.6.6: the asset integrity audit. Rules over the in-memory audit repository and the real in-memory storage provider
// (listing included): dry-run by default and the explicit execution guard, referenced assets (report-only, never deleted), the
// 24-hour grace period, database and storage failures (nothing is deleted on doubt), bounded batches, accurate reporting, a
// randomized safety property, the CLI parser and exit codes, SQL and source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { AUDIT_DEFAULTS, AUDIT_LIMITS, AUDIT_MAX_FAILURES, AuditOptionsError, resolveAuditOptions, runAssetAudit } from '../../src/assets/audit.ts';
import type { AuditReport } from '../../src/assets/audit.ts';
import { LOCK_READY_SQL, buildDeleteUnlinked, buildListReady, createPgAuditRepository } from '../../src/assets/audit-repository.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { ListableStorage } from '../../src/storage/index.ts';
import type { Db } from '../../src/db.ts';
import { auditExitCode, parseAuditArgs } from '../../scripts/assets-audit.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { makeFakeAudit } from '../helpers/fake-audit.ts';
import type { AuditRow } from '../helpers/fake-audit.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const T0 = Date.UTC(2026, 9, 10);
const H = 3600 * 1000;
const u = (i: number) => `d0000000-0000-4000-8000-${String(i).padStart(12, '0')}`;
const inc = (i: number, kind = 'car_image') => `incoming/${kind}/${u(i)}`;
const proc = (i: number, kind = 'car_image') => `processed/${kind}/${u(i)}.webp`;
const thumb = (i: number, kind = 'car_image') => `thumbs/${kind}/${u(i)}.webp`;
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');
const noSleep = async () => {};

type Brk = 'missing_main' | 'missing_thumb' | 'garbage_main' | 'garbage_thumb' | 'hash' | 'size' | 'dims' | 'thumb_larger';
interface ReadyOpts {
  /** Hours since the asset became ready (also the age of its objects). */
  ageH?: number;
  referenced?: boolean;
  kind?: string;
  broken?: Brk;
}

function world() {
  const t = new Date(T0);
  const clock = { now: () => t };
  const storeTime = { at: new Date(T0) };
  const mem = createMemoryStorage({ now: () => storeTime.at });
  const fa = makeFakeAudit(clock);
  const deleted: string[] = [];
  const gets: string[] = [];
  const faults: { get: ((key: string) => StorageError | null) | null; delete: ((key: string) => StorageError | null) | null; list: StorageError | null; getFailuresLeft: number } = { get: null, delete: null, list: null, getFailuresLeft: 0 };
  const storage: ListableStorage = {
    kind: 'memory',
    put: (k, b, o) => mem.put(k, b, o),
    async get(k) {
      gets.push(k);
      const f = faults.get?.(k);
      if (f) throw f;
      if (faults.getFailuresLeft > 0) {
        faults.getFailuresLeft--;
        throw new StorageError('unavailable', 503);
      }
      return mem.get(k);
    },
    async delete(k) {
      const f = faults.delete?.(k);
      if (f) throw f;
      deleted.push(k);
      return mem.delete(k);
    },
    exists: (k) => mem.exists(k),
    async list(p, o) {
      if (faults.list) throw faults.list;
      return mem.list(p, o);
    },
  };
  const putAt = async (key: string, body: Uint8Array, ageH: number) => {
    storeTime.at = new Date(T0 - ageH * H);
    await mem.put(key, body, { contentType: 'image/webp' });
    storeTime.at = new Date(T0);
  };
  /** A ready asset with its two valid objects and a matching record. */
  async function ready(i: number, o: ReadyOpts = {}): Promise<AuditRow> {
    const ageH = o.ageH ?? 48;
    const kind = o.kind ?? 'car_image';
    const main = fakeWebp(40, 30, { payload: 16 + (i % 9) * 2 });
    const th = fakeWebp(20, 15, { payload: 16 + (i % 5) * 2 });
    const row = fa.add({
      id: u(i), kind, storageKey: proc(i, kind), thumbKey: thumb(i, kind), bytes: main.byteLength, width: 40, height: 30, sha256: sha(main),
      readyAt: new Date(T0 - ageH * H), referenced: o.referenced ?? false,
    });
    const b = o.broken;
    if (b === 'dims') row.width = 99; // the record disagrees with the (valid, same-size, same-hash) object
    if (b !== 'missing_main') await putAt(row.storageKey!, b === 'garbage_main' ? new Uint8Array([1, 2, 3, 4]) : b === 'size' ? fakeWebp(40, 30, { payload: 64 }) : b === 'hash' ? main.map((x, j, a) => (j === a.length - 1 ? x ^ 1 : x)) : main, ageH);
    if (b !== 'missing_thumb') await putAt(row.thumbKey!, b === 'garbage_thumb' ? new Uint8Array([9, 9, 9]) : b === 'thumb_larger' ? fakeWebp(80, 60) : th, ageH);
    return row;
  }
  const run = (input: Parameters<typeof runAssetAudit>[1] = {}, extra: { logger?: { info(o: object): void; warn(o: object): void } } = {}): Promise<AuditReport> =>
    runAssetAudit({ repo: fa.repo, storage, now: clock.now, sleep: noSleep, ...extra }, input);
  return { fa, mem, storage, faults, deleted, gets, ready, putAt, run, storeTime };
}

describe('options and the execution guard', () => {
  it('defaults: dry run, 24-hour grace, bounded batches', () => {
    const o = resolveAuditOptions();
    assert.deepEqual(o, { dryRun: true, batchSize: AUDIT_DEFAULTS.batchSize, maxBatches: AUDIT_DEFAULTS.maxBatches, graceHours: 24, shard: '', assets: true, orphans: true });
    assert.equal(resolveAuditOptions({ dryRun: undefined }).dryRun, true);
    assert.equal(resolveAuditOptions({ dryRun: false }).dryRun, false);
  });

  it('rejects every out-of-range option (the grace period is never below 24 hours)', () => {
    const bad: Array<[object, string]> = [
      [{ batchSize: 0 }, 'batchSize'], [{ batchSize: AUDIT_LIMITS.batchSizeMax + 1 }, 'batchSize'], [{ batchSize: 1.5 }, 'batchSize'],
      [{ maxBatches: 0 }, 'maxBatches'], [{ maxBatches: 101 }, 'maxBatches'],
      [{ graceHours: 23 }, 'graceHours'], [{ graceHours: 721 }, 'graceHours'], [{ graceHours: Number.NaN }, 'graceHours'], [{ graceHours: 0 }, 'graceHours'],
      [{ shard: 'xyz' }, 'shard'], [{ shard: 'A1' }, 'shard'], [{ shard: '123' }, 'shard'],
      [{ assets: false, orphans: false }, 'nothingToAudit'],
    ];
    for (const [input, problem] of bad) assert.throws(() => resolveAuditOptions(input), (e) => e instanceof AuditOptionsError && e.problems.includes(problem), JSON.stringify(input));
    assert.equal(resolveAuditOptions({ graceHours: 24 }).graceHours, 24);
    assert.equal(resolveAuditOptions({ graceHours: 720 }).graceHours, 720);
  });

  it('CLI: nothing deletes without --execute; contradictory or unknown arguments are refused', () => {
    assert.equal(parseAuditArgs([]).dryRun, true);
    assert.equal(parseAuditArgs(['--dry-run']).dryRun, true);
    assert.equal(parseAuditArgs(['--execute']).dryRun, false);
    assert.equal(parseAuditArgs(['--batch-size=50', '--max-batches=3', '--grace-hours=48', '--shard=a', '--skip-orphans']).graceHours, 48);
    assert.equal(parseAuditArgs(['--skip-assets']).assets, false);
    for (const argv of [['--execute', '--dry-run'], ['--execute=true'], ['--delete'], ['execute'], ['--grace-hours=1'], ['--grace-hours=abc'], ['--batch-size=0'], ['--shard'], ['--skip-assets', '--skip-orphans'], ['-x'], ['--grace-hours']])
      assert.throws(() => parseAuditArgs(argv), AuditOptionsError, argv.join(' '));
    try {
      parseAuditArgs(['--grace-hours=SECRET-VALUE']);
      assert.fail('should throw');
    } catch (e) {
      assert.ok(e instanceof AuditOptionsError && !JSON.stringify(e.problems).includes('SECRET'), 'the value is never echoed');
    }
  });

  it('run with no options deletes nothing even when everything is deletable (dry run is the default)', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    await w.putAt(proc(2), fakeWebp(4, 4), 100); // orphan object
    const before = w.mem.keys();
    const r = await w.run();
    assert.equal(r.dryRun, true);
    assert.equal(r.deletion.mode, 'dry_run');
    assert.deepEqual(w.deleted, []);
    assert.deepEqual(w.mem.keys(), before);
    assert.equal(w.fa.rows().length, 1);
    assert.equal(w.fa.calls.filter((c) => c.op === 'deleteUnlinked').length, 0);
    assert.equal(r.summary.unlinked, 1);
    assert.equal(r.summary.orphaned, 1);
    assert.equal(r.summary.deleted, 0);
  });
});

describe('records -> objects: health checks', () => {
  it('a healthy ready asset is counted healthy and nothing else', async () => {
    const w = world();
    await w.ready(1, { referenced: true });
    const r = await w.run();
    assert.deepEqual({ ...r.summary }, { scanned: 3, healthy: 1, missing: 0, corrupt: 0, unlinked: 0, orphaned: 0, deleted: 0, skipped: 0, failed: 0 });
    assert.equal(r.error, null);
    assert.equal(r.findings, false);
    assert.equal(auditExitCode(r), 0);
  });

  it('detects a missing main image and a missing thumbnail', async () => {
    const w = world();
    await w.ready(1, { referenced: true, broken: 'missing_main' });
    await w.ready(2, { referenced: true, broken: 'missing_thumb' });
    const r = await w.run();
    assert.equal(r.assets!.missing, 2);
    assert.equal(r.assets!.healthy, 0);
    assert.equal(r.assets!.referencedMissing, 2);
  });

  it('detects unreadable/invalid, size, hash, dimension and oversize-thumbnail corruption, each with its reason', async () => {
    const w = world();
    const cases: Array<[number, Brk, string]> = [[1, 'garbage_main', 'invalid_image'], [2, 'garbage_thumb', 'invalid_image'], [3, 'size', 'size_mismatch'], [4, 'hash', 'hash_mismatch'], [5, 'dims', 'dimension_mismatch'], [6, 'thumb_larger', 'dimension_mismatch']];
    for (const [i, b] of cases) await w.ready(i, { referenced: true, broken: b });
    const r = await w.run();
    assert.equal(r.assets!.corrupt, 6);
    assert.deepEqual({ ...r.assets!.corruptReasons }, { invalid_image: 2, size_mismatch: 1, hash_mismatch: 1, dimension_mismatch: 2, unreadable: 0 });
    assert.equal(r.assets!.healthy, 0);
  });

  it('an object too large for the storage limit is unreadable (corrupt), not a run failure', async () => {
    const w = world();
    await w.ready(1, { referenced: true });
    w.faults.get = (k) => (k === proc(1) ? new StorageError('too_large') : null);
    const r = await w.run();
    assert.equal(r.assets!.corrupt, 1);
    assert.equal(r.assets!.corruptReasons.unreadable, 1);
    assert.equal(r.error, null);
  });

  it('missing wins over corrupt in the verdict of one asset', async () => {
    const w = world();
    const row = await w.ready(1, { referenced: true, broken: 'garbage_main' });
    await w.mem.delete(row.thumbKey!);
    const r = await w.run();
    assert.equal(r.assets!.missing, 1);
    assert.equal(r.assets!.corrupt, 0);
  });

  it('only ready assets are audited (pending and rejected rows are the cleanup job\'s)', async () => {
    const w = world();
    w.fa.add({ status: 'pending', storageKey: inc(1) });
    w.fa.add({ status: 'rejected', storageKey: inc(2) });
    const r = await w.run();
    assert.equal(r.assets!.scanned, 0);
    assert.equal(r.assets!.complete, true);
  });
});

describe('referenced assets are report-only', () => {
  it('missing/corrupt referenced assets are reported by id, never deleted, even with execution and old age', async () => {
    const w = world();
    const m = await w.ready(1, { referenced: true, ageH: 5000 / 10, broken: 'missing_main' });
    const c = await w.ready(2, { referenced: true, ageH: 500, broken: 'hash' });
    const cover = await w.ready(3, { referenced: true, ageH: 500, kind: 'showroom_cover', broken: 'garbage_thumb' });
    const healthy = await w.ready(4, { referenced: true, ageH: 500 });
    const before = w.mem.keys();
    const r = await w.run({ dryRun: false });
    assert.deepEqual(w.deleted, []);
    assert.deepEqual(w.mem.keys(), before, 'every object of a referenced asset is still there');
    assert.deepEqual(w.fa.rows().map((x) => x.id).sort(), [m, c, cover, healthy].map((x) => x.id).sort());
    assert.equal(w.fa.calls.filter((x) => x.op === 'deleteUnlinked').length, 0, 'the delete statement is never even issued');
    assert.equal(r.findings, true);
    assert.equal(auditExitCode(r), 2);
    assert.deepEqual(r.assets!.referencedProblems.map((p) => [p.assetId, p.problem]), [[m.id, 'missing'], [c.id, 'corrupt'], [cover.id, 'corrupt']]);
    assert.equal(r.deletion.mode, 'none');
  });

  it('the problem list is capped at 50 ids and says so', async () => {
    const w = world();
    for (let i = 1; i <= 52; i++) await w.ready(i, { referenced: true, broken: 'missing_main' });
    const r = await w.run({ batchSize: 100 });
    assert.equal(r.assets!.referencedMissing, 52);
    assert.equal(r.assets!.referencedProblems.length, 50);
    assert.equal(r.assets!.referencedProblemsTruncated, true);
  });

  it('a referenced asset is never an orphan or unlinked, whatever its objects', async () => {
    const w = world();
    await w.ready(1, { referenced: true, ageH: 900 });
    const r = await w.run({ dryRun: false });
    assert.equal(r.summary.unlinked, 0);
    assert.equal(r.summary.orphaned, 0);
    assert.equal(r.orphans!.referenced, 2);
  });
});

describe('the grace period (default 24 hours)', () => {
  it('an unlinked asset is eligible only when STRICTLY older than the grace period', async () => {
    const w = world();
    const young = await w.ready(1, { ageH: 23.99 });
    const exact = await w.ready(2, { ageH: 24 });
    const old = await w.ready(3, { ageH: 24 + 1 / 3600 });
    const r = await w.run({ dryRun: false });
    assert.equal(r.assets!.unlinked, 3);
    assert.equal(r.assets!.unlinkedWithinGrace, 2);
    assert.equal(r.assets!.unlinkedEligible, 1);
    assert.deepEqual(w.fa.rows().map((x) => x.id).sort(), [young.id, exact.id]);
    assert.ok(!w.fa.rows().some((x) => x.id === old.id));
    assert.deepEqual(w.deleted.sort(), [inc(3), proc(3), thumb(3)].sort());
  });

  it('a custom grace period applies to rows and to objects', async () => {
    const w = world();
    await w.ready(1, { ageH: 40 });
    await w.putAt(proc(9), fakeWebp(4, 4), 40);
    const r48 = await w.run({ dryRun: false, graceHours: 48 });
    assert.equal(r48.summary.deleted, 0);
    assert.equal(r48.summary.unlinked, 1);
    assert.equal(r48.orphans!.tooRecent, 1 + 2, 'the orphan and the two objects of the (referenced-by-row) asset are all too recent');
    const r24 = await w.run({ dryRun: false });
    assert.equal(r24.assets!.unlinkedEligible, 1);
    assert.equal(r24.orphans!.orphaned, 1);
    assert.equal(r24.summary.deleted, 2);
  });

  it('an orphan object younger than (or exactly at) the grace period is kept; older is eligible', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(4, 4), 23.9);
    await w.putAt(proc(2), fakeWebp(4, 4), 24);
    await w.putAt(proc(3), fakeWebp(4, 4), 24.01);
    const r = await w.run({ dryRun: false });
    assert.equal(r.orphans!.tooRecent, 2);
    assert.equal(r.orphans!.orphaned, 1);
    assert.deepEqual(w.deleted, [proc(3)]);
    assert.deepEqual(w.mem.keys().sort(), [proc(1), proc(2)]);
  });

  it('the grace period is measured by the database clock for rows, by the storage time for objects', async () => {
    const w = world();
    // The row says 100 hours; the objects were just written (e.g. re-uploaded): the row is eligible, the objects are "too recent" as orphans.
    const row = await w.ready(1, { ageH: 100 });
    w.mem.touch(row.storageKey!, new Date(T0));
    const r = await w.run({ dryRun: false });
    assert.equal(r.assets!.unlinkedEligible, 1);
    assert.equal(r.summary.deleted >= 1, true);
  });
});

describe('unlinked assets', () => {
  it('dry run counts them and deletes nothing; execution removes the row first, then all three objects', async () => {
    const w = world();
    const a = await w.ready(1, { ageH: 72 });
    await w.putAt(inc(1), new Uint8Array([1, 2, 3]), 72); // a leftover original of the same asset
    const dry = await w.run();
    assert.equal(dry.assets!.unlinkedEligible, 1);
    assert.equal(dry.deletion.mode, 'dry_run');
    assert.equal(w.fa.rows().length, 1);
    const calls = w.fa.calls.length;
    const r = await w.run({ dryRun: false });
    assert.equal(r.deletion.mode, 'executed');
    assert.equal(r.deletion.assetsDeleted, 1);
    assert.equal(r.deletion.assetObjectsDeleted, 3);
    assert.deepEqual(w.deleted, [inc(1), proc(1), thumb(1)], 'each object once (the leftover original is also an orphan candidate, but is not deleted twice)');
    assert.equal(w.fa.rows().length, 0);
    assert.ok(w.fa.calls.slice(calls).some((c) => c.op === 'deleteUnlinked' && c.arg === a.id));
    assert.equal(r.summary.deleted, 1, 'deleted = records + orphan objects; the objects of a deleted record are in deletion.assetObjectsDeleted');
    assert.equal(r.deletion.objectsDeleted, 0);
    // Idempotent: a second run finds nothing.
    const again = await w.run({ dryRun: false });
    assert.equal(again.summary.scanned, 0);
    assert.equal(again.summary.deleted, 0);
  });

  it('a missing or corrupt UNLINKED asset is garbage and is removed like any other unlinked asset', async () => {
    const w = world();
    await w.ready(1, { ageH: 72, broken: 'missing_main' });
    await w.ready(2, { ageH: 72, broken: 'garbage_main' });
    const r = await w.run({ dryRun: false });
    assert.equal(r.assets!.missing, 1);
    assert.equal(r.assets!.corrupt, 1);
    assert.equal(r.deletion.assetsDeleted, 2);
    assert.equal(r.findings, false, 'not referenced: nothing needs a person');
  });

  it('keys this backend did not generate are never deleted', async () => {
    const w = world();
    const odd = w.fa.add({ id: u(7), storageKey: 'legacy/photo-7.webp', thumbKey: 'legacy/photo-7-thumb.webp', bytes: 10, width: 4, height: 4, sha256: 'a'.repeat(64), readyAt: new Date(T0 - 99 * H) });
    await w.putAt(odd.storageKey!, fakeWebp(4, 4), 99);
    await w.putAt(odd.thumbKey!, fakeWebp(4, 4), 99);
    const mismatch = w.fa.add({ id: u(8), storageKey: proc(8), thumbKey: thumb(9), bytes: 10, width: 4, height: 4, sha256: 'a'.repeat(64), readyAt: new Date(T0 - 99 * H) });
    const wrongKind = w.fa.add({ id: u(10), kind: 'showroom_cover', storageKey: proc(10, 'car_image'), thumbKey: thumb(10, 'car_image'), bytes: 10, width: 4, height: 4, sha256: 'a'.repeat(64), readyAt: new Date(T0 - 99 * H) });
    const r = await w.run({ dryRun: false });
    assert.equal(r.assets!.unlinkedUnrecognized, 3);
    assert.equal(r.assets!.unlinkedEligible, 0);
    assert.deepEqual(w.deleted, []);
    assert.deepEqual(w.fa.rows().map((x) => x.id).sort(), [odd.id, mismatch.id, wrongKind.id].sort());
  });

  it('a row attached between the audit and the delete is refused by the compare-and-swap: its objects stay', async () => {
    const w = world();
    const a = await w.ready(1, { ageH: 72 });
    w.fa.faults.beforeDelete = (row) => { row.referenced = true; };
    const r = await w.run({ dryRun: false });
    assert.equal(r.deletion.assetsChanged, 1);
    assert.equal(r.deletion.assetsDeleted, 0);
    assert.deepEqual(w.deleted, []);
    assert.deepEqual(w.mem.keys().sort(), [proc(1), thumb(1)].sort());
    assert.equal(w.fa.rows()[0]!.id, a.id);
    assert.equal(r.summary.skipped >= 1, true);
  });
});

describe('storage objects with no database record', () => {
  it('reports orphans in all three areas; deletes only on execution; keeps referenced and unrecognized keys', async () => {
    const w = world();
    await w.ready(1, { referenced: true });               // processed + thumb referenced
    await w.putAt(inc(2), new Uint8Array([1]), 72);        // orphan original
    await w.putAt(proc(3), fakeWebp(4, 4), 72);            // orphan main
    await w.putAt(thumb(4, 'showroom_cover'), fakeWebp(4, 4), 72); // orphan thumb
    await w.putAt('processed/car_image/not-a-uuid.webp', fakeWebp(4, 4), 72); // unrecognized shape
    w.fa.add({ status: 'pending', storageKey: inc(5) });
    await w.putAt(inc(5), new Uint8Array([1]), 72);        // belongs to a pending row: referenced
    const dry = await w.run();
    assert.equal(dry.orphans!.orphaned, 3);
    assert.equal(dry.orphans!.unrecognized, 1);
    assert.equal(dry.orphans!.referenced, 3);
    assert.deepEqual(w.deleted, []);
    const r = await w.run({ dryRun: false });
    assert.deepEqual(w.deleted.sort(), [inc(2), proc(3), thumb(4, 'showroom_cover')].sort());
    assert.equal(r.deletion.objectsDeleted, 3);
    assert.deepEqual(w.mem.keys().sort(), ['processed/car_image/not-a-uuid.webp', inc(5), proc(1), thumb(1)].sort());
  });

  it('a thumbnail or main image of a row whose ORIGINAL key is recorded counts as referenced (processing may be writing it)', async () => {
    const w = world();
    w.fa.add({ status: 'pending', storageKey: inc(6) });
    await w.putAt(proc(6), fakeWebp(4, 4), 72);
    await w.putAt(thumb(6), fakeWebp(4, 4), 72);
    const r = await w.run({ dryRun: false });
    assert.equal(r.orphans!.referenced, 2);
    assert.deepEqual(w.deleted, []);
  });

  it('a second lookup right before the delete protects an object that became referenced meanwhile', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(4, 4), 72);
    w.fa.faults.afterRefs = (n) => { if (n === 3) w.fa.add({ status: 'pending', storageKey: inc(1) }); };
    const r = await w.run({ dryRun: false });
    assert.equal(r.orphans!.orphaned, 1);
    assert.equal(r.deletion.objectsReferencedOnRecheck, 1);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.mem.size(), 1);
  });

  it('unsafe listing entries are counted and never touched; a shard narrows the listing', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(4, 4), 72);
    await w.putAt(proc(2), fakeWebp(4, 4), 72);
    const r = await w.run({ dryRun: false, shard: 'd' });
    assert.equal(r.orphans!.orphaned, 2);
    const none = await w.run({ dryRun: false, shard: 'ff' });
    assert.equal(none.orphans!.scanned, 0);
  });
});

describe('failures: nothing is deleted on doubt', () => {
  const seed = async (w: ReturnType<typeof world>) => {
    await w.ready(1, { ageH: 72 });            // an unlinked, deletable asset
    await w.putAt(proc(50), fakeWebp(4, 4), 72); // a deletable orphan
  };

  it('a database failure while listing assets stops the run and blocks every deletion, including candidates found earlier', async () => {
    const w = world();
    for (let i = 1; i <= 3; i++) await w.ready(i, { ageH: 72 });
    w.fa.faults.failListFrom = 2; // the second page fails (after retries)
    const r = await w.run({ dryRun: false, batchSize: 2 });
    assert.equal(r.error, 'database_unavailable');
    assert.equal(r.deletion.mode, 'blocked');
    assert.equal(r.deletion.blockedBy, 'database_unavailable');
    assert.equal(r.deletion.notAttempted, 2);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.fa.rows().length, 3);
    assert.equal(auditExitCode(r), 1);
    assert.equal(r.summary.failed >= 1, true);
  });

  it('a failed reference lookup is never read as "no references": the orphan survives, the report says why', async () => {
    const w = world();
    await seed(w);
    w.fa.faults.failRefsFrom = 1;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'database_unavailable');
    assert.equal(r.orphans!.orphaned, 0);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.mem.size() >= 3, true);
    assert.equal(r.deletion.mode, 'blocked');
  });

  it('a storage listing failure blocks deletion of everything, rows included', async () => {
    const w = world();
    await seed(w);
    w.faults.list = new StorageError('unavailable', 503);
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'storage_unavailable');
    assert.equal(r.deletion.mode, 'blocked');
    assert.deepEqual(w.deleted, []);
    assert.equal(w.fa.rows().length, 1);
  });

  it('an asset whose objects could not be read is "failed" (uncertain) and blocks all deletion', async () => {
    const w = world();
    await seed(w);
    await w.ready(2, { referenced: true });
    w.faults.get = (k) => (k === proc(2) ? new StorageError('unavailable', 500) : null);
    const r = await w.run({ dryRun: false });
    assert.equal(r.assets!.failed, 1);
    assert.equal(r.assets!.healthy, 1, 'the failed asset is not healthy');
    assert.equal(r.error, null, 'the read pass finished');
    assert.equal(r.deletion.mode, 'blocked');
    assert.equal(r.deletion.blockedBy, 'unverified_assets');
    assert.deepEqual(w.deleted, []);
    assert.equal(auditExitCode(r), 1);
  });

  it('a transient read failure is retried and then succeeds: no failure, deletion proceeds normally', async () => {
    const w = world();
    await seed(w);
    w.faults.getFailuresLeft = 2;
    w.fa.faults.failListFirst = 1;
    w.fa.faults.failRefsFirst = 2;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, null);
    assert.equal(r.summary.failed, 0);
    assert.equal(r.deletion.mode, 'executed');
    assert.equal(r.deletion.assetsDeleted, 1);
    assert.equal(r.deletion.objectsDeleted, 1);
  });

  it('too many failed reads abort the run (storage is clearly down)', async () => {
    const w = world();
    for (let i = 1; i <= AUDIT_MAX_FAILURES + 2; i++) await w.ready(i, { ageH: 72 });
    w.faults.get = () => new StorageError('unavailable', 503);
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'storage_unavailable');
    assert.deepEqual(w.deleted, []);
    assert.ok(r.assets!.scanned < AUDIT_MAX_FAILURES + 2);
  });

  it('a non-database, non-storage error is "unexpected" and blocks deletion', async () => {
    const w = world();
    await seed(w);
    w.fa.faults.nonDbError = true;
    w.fa.faults.failListFrom = 1;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'unexpected');
    assert.deepEqual(w.deleted, []);
  });

  it('a failure while deleting a row stops the deletions and is reported (the row is not retried)', async () => {
    const w = world();
    await w.ready(1, { ageH: 72 });
    await w.ready(2, { ageH: 72 });
    w.fa.faults.failDelete = true;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'database_unavailable');
    assert.equal(r.deletion.failed, 1);
    assert.equal(w.fa.calls.filter((c) => c.op === 'deleteUnlinked').length, 1, 'one attempt, no retry, no further deletions');
    assert.deepEqual(w.deleted, []);
    assert.equal(r.deletion.notAttempted >= 1, true);
  });

  it('a storage failure while deleting stops further deletions; objects of a removed row are left as orphans for a later run', async () => {
    const w = world();
    await w.ready(1, { ageH: 72 });
    w.faults.delete = (k) => (k === proc(1) ? new StorageError('unavailable', 500) : null);
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'storage_unavailable');
    assert.equal(r.deletion.assetsDeleted, 1);
    assert.equal(r.deletion.failed, 1);
    assert.equal(w.fa.rows().length, 0);
    assert.ok(w.mem.keys().includes(proc(1)));
    w.faults.delete = null;
    const later = await w.run({ dryRun: false });
    assert.equal(later.orphans!.orphaned, 2, 'main and thumbnail are orphans now');
    assert.deepEqual(w.mem.keys(), []);
  });

  it('with no deletion candidates a failure is only reported, never "blocked"', async () => {
    const w = world();
    w.faults.list = new StorageError('unavailable', 503);
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'storage_unavailable');
    assert.equal(r.deletion.mode, 'none');
  });
});

describe('bounds and reporting', () => {
  it('pages through all records in batches; stops at maxBatches and says the run is not complete', async () => {
    const w = world();
    for (let i = 1; i <= 7; i++) await w.ready(i, { referenced: true });
    const full = await w.run({ batchSize: 3, maxBatches: 10 });
    assert.equal(full.assets!.scanned, 7);
    assert.equal(full.assets!.complete, true);
    assert.equal(full.assets!.batches, 3);
    const limited = await w.run({ batchSize: 3, maxBatches: 2, orphans: false });
    assert.equal(limited.assets!.scanned, 6);
    assert.equal(limited.assets!.complete, false);
    for (const c of w.fa.calls) if (c.op === 'listReady') assert.ok((c.arg as { limit: number }).limit <= 3);
  });

  it('the object listing is bounded too', async () => {
    const w = world();
    for (let i = 1; i <= 7; i++) await w.putAt(proc(i), fakeWebp(4, 4), 72);
    const r = await w.run({ batchSize: 2, maxBatches: 2, assets: false });
    assert.equal(r.orphans!.pages, 2);
    assert.equal(r.orphans!.complete, false);
    assert.ok(r.orphans!.scanned <= 4);
  });

  it('a mixed world is reported exactly', async () => {
    const w = world();
    await w.ready(1, { referenced: true });                                  // healthy, linked
    await w.ready(2, { referenced: true, broken: 'missing_thumb' });          // missing, linked
    await w.ready(3, { referenced: true, broken: 'dims' });                   // corrupt, linked
    await w.ready(4, { ageH: 72 });                                           // healthy, unlinked, eligible
    await w.ready(5, { ageH: 2 });                                            // healthy, unlinked, within grace
    await w.putAt(proc(60), fakeWebp(4, 4), 72);                              // orphan
    await w.putAt(thumb(61), fakeWebp(4, 4), 3);                              // too recent
    await w.putAt('thumbs/car_image/zzz.webp', fakeWebp(4, 4), 72);           // unrecognized
    const r = await w.run({ dryRun: false });
    assert.deepEqual({ ...r.summary }, {
      scanned: 5 + 12, // 5 ready assets + 9 objects of assets (asset 2 lacks its thumbnail) + 3 extra objects
      healthy: 3,
      missing: 1,
      corrupt: 1,
      unlinked: 2,
      orphaned: 1,
      deleted: 2,      // the unlinked asset (1) + the orphan object (1)
      skipped: 5,      // asset 5 within grace (1) + too-recent objects (asset 5's two, thumb 61) (3) + unrecognized key (1)
      failed: 0,
    });
    assert.equal(r.assets!.referenced, 3);
    assert.equal(r.assets!.referencedMissing, 1);
    assert.equal(r.assets!.referencedCorrupt, 1);
    assert.equal(r.deletion.assetObjectsDeleted, 3);
    assert.equal(r.deletion.objectsDeleted, 1);
    assert.equal(auditExitCode(r), 2);
  });

  it('the report and the log carry counts and asset ids only: no storage key, bucket, URL or secret', async () => {
    const w = world();
    await w.ready(1, { referenced: true, broken: 'missing_main' });
    await w.ready(2, { ageH: 72 });
    await w.putAt(proc(9), fakeWebp(4, 4), 72);
    const logged: string[] = [];
    const logger = { info: (o: object) => logged.push(JSON.stringify(o)), warn: (o: object) => logged.push(JSON.stringify(o)) };
    const r = await w.run({ dryRun: false }, { logger });
    const text = JSON.stringify(r) + logged.join('');
    assert.ok(logged.length === 1);
    assert.ok(!/processed\/|thumbs\/|incoming\/|https?:|X-Amz|signature|secret|bucket|endpoint/i.test(text), text);
    assert.ok(!text.includes(sha(fakeWebp(40, 30))), 'no checksum');
    assert.match(text, /d0000000-0000-4000-8000-000000000001/, 'the id of the referenced problem is reported');
  });
});

describe('safety property', () => {
  it('random worlds: with execution, a referenced asset, its objects and every young object always survive; only old, unreferenced things go', async () => {
    let seed = 12345;
    const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
    for (let round = 0; round < 40; round++) {
      const w = world();
      const protectedKeys = new Set<string>();
      const protectedRows = new Set<string>();
      const n = 1 + Math.floor(rnd() * 8);
      for (let i = 1; i <= n; i++) {
        const referenced = rnd() < 0.4;
        const ageH = [1, 23, 24, 25, 100][Math.floor(rnd() * 5)]!;
        const broken = rnd() < 0.3 ? (['missing_main', 'missing_thumb', 'garbage_main', 'hash', 'dims', 'thumb_larger'] as const)[Math.floor(rnd() * 6)] : undefined;
        const row = await w.ready(i, { referenced, ageH, ...(broken ? { broken } : {}) });
        if (referenced || ageH <= 24) {
          protectedRows.add(row.id);
          for (const k of [row.storageKey!, row.thumbKey!]) protectedKeys.add(k);
        }
      }
      for (let i = 20; i < 20 + Math.floor(rnd() * 6); i++) {
        const ageH = [1, 24, 30, 90][Math.floor(rnd() * 4)]!;
        const key = [inc(i), proc(i), thumb(i)][Math.floor(rnd() * 3)]!;
        await w.putAt(key, fakeWebp(4, 4), ageH);
        if (ageH <= 24) protectedKeys.add(key);
      }
      // faults at random: whatever happens, the property must hold
      if (rnd() < 0.2) w.fa.faults.failRefsFrom = 1 + Math.floor(rnd() * 3);
      if (rnd() < 0.2) w.faults.delete = () => new StorageError('unavailable', 500);
      const existedBefore = new Set(w.mem.keys());
      await w.run({ dryRun: false, batchSize: 1 + Math.floor(rnd() * 4) });
      for (const k of protectedKeys) if (existedBefore.has(k)) assert.ok(w.mem.keys().includes(k), `round ${round}: protected object ${k} was deleted`);
      for (const id of protectedRows) assert.ok(w.fa.rows().some((x) => x.id === id), `round ${round}: protected record deleted`);
      for (const d of w.deleted) assert.ok(!protectedKeys.has(d), `round ${round}: deleted a protected key ${d}`);
    }
  });
});

describe('PostgreSQL repository (statement shape and order, with a recording Db)', () => {
  const recording = (answers: Array<unknown[]>) => {
    const log: Array<{ text: string; values: readonly unknown[] | undefined }> = [];
    let i = 0;
    const q = async (text: string, values?: readonly unknown[]) => {
      log.push({ text, values });
      return { rows: (answers[i++] ?? []) as never[], rowCount: 0 };
    };
    const db = { query: q, tx: async <T>(fn: (t: { query: typeof q }) => Promise<T>) => fn({ query: q }) } as unknown as Db;
    return { db, log };
  };

  it('deleteUnlinked: lock the row FOR UPDATE first, then one conditional DELETE re-checking everything', async () => {
    const { db, log } = recording([[], [{ id: 'x' }], [{ id: 'x' }]]);
    const repo = createPgAuditRepository(db);
    assert.equal(await repo.deleteUnlinked({ id: u(1), storageKey: proc(1), thumbKey: thumb(1), graceSeconds: 86400 }), true);
    assert.deepEqual(log.map((l) => l.text.replace(/\s+/g, ' ').split(' ').slice(0, 2).join(' ')), ['SET LOCAL', 'SELECT a.id', 'DELETE FROM']);
    assert.equal(log[1]!.text, LOCK_READY_SQL);
    assert.match(LOCK_READY_SQL, /FOR UPDATE/);
    const del = buildDeleteUnlinked({ id: u(1), storageKey: proc(1), thumbKey: thumb(1), graceSeconds: 86400 }).text;
    for (const part of [/a\.status = 'ready'/, /a\.storage_key IS NOT DISTINCT FROM \$2/, /a\.thumb_key IS NOT DISTINCT FROM \$3/, /a\.ready_at < now\(\) - make_interval/, /NOT EXISTS \(SELECT 1 FROM car_images/, /NOT EXISTS \(SELECT 1 FROM showrooms s WHERE s\.cover_asset_id/, /RETURNING/]) assert.match(del, part);
  });

  it('deleteUnlinked: a row that is gone or no longer ready is not even deleted', async () => {
    const { db, log } = recording([[], []]);
    assert.equal(await createPgAuditRepository(db).deleteUnlinked({ id: u(1), storageKey: proc(1), thumbKey: thumb(1), graceSeconds: 86400 }), false);
    assert.equal(log.length, 2);
  });

  it('deleteUnlinked: a refused DELETE (changed or attached) is false; a database error propagates', async () => {
    const { db } = recording([[], [{ id: 'x' }], []]);
    assert.equal(await createPgAuditRepository(db).deleteUnlinked({ id: u(1), storageKey: proc(1), thumbKey: thumb(1), graceSeconds: 86400 }), false);
    const failing = { query: async () => { throw new Error('x'); }, tx: async (fn: (t: unknown) => Promise<unknown>) => fn({ query: async () => { throw new Error('boom'); } }) } as unknown as Db;
    await assert.rejects(() => createPgAuditRepository(failing).deleteUnlinked({ id: u(1), storageKey: null, thumbKey: null, graceSeconds: 1 }));
  });

  it('listReady: keyset, bounded, ready only, referenced and age decided by the database; mapping never trusts a missing flag', async () => {
    const s = buildListReady({ afterId: null, limit: 5 });
    assert.match(s.text, /a\.status = 'ready'/);
    assert.match(s.text, /ORDER BY a\.id/);
    assert.match(s.text, /LIMIT \$2::int/);
    assert.match(s.text, /EXISTS \(SELECT 1 FROM car_images/);
    assert.match(s.text, /cover_asset_id = a\.id/);
    assert.match(s.text, /now\(\) - a\.ready_at/);
    assert.deepEqual(s.values, [null, 5]);
    const { db } = recording([[{ id: u(1), kind: 'car_image', storage_key: proc(1), thumb_key: thumb(1), bytes: '10', width: 4, height: 3, sha256: 'a'.repeat(64) + ' ', referenced: null, age_seconds: '90000.5' }]]);
    const rows = await createPgAuditRepository(db).listReady({ afterId: null, limit: 1 });
    assert.equal(rows[0]!.referenced, true, 'anything but a definite false is treated as referenced');
    assert.equal(rows[0]!.bytes, 10);
    assert.equal(rows[0]!.sha256, 'a'.repeat(64));
    assert.equal(rows[0]!.ageSeconds, 90000.5);
  });

  it('findReferencedKeys: no keys, no query; otherwise the cleanup job\'s statement', async () => {
    const { db, log } = recording([[{ k: proc(1) }, { k: null }]]);
    const repo = createPgAuditRepository(db);
    assert.equal((await repo.findReferencedKeys([])).size, 0);
    assert.equal(log.length, 0);
    assert.deepEqual([...(await repo.findReferencedKeys([proc(1), proc(2)]))], [proc(1)]);
    assert.equal(log.length, 1);
  });
});

describe('source guards', () => {
  const walk = (dir: string): string[] => readdirSync(join(ROOT, dir), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(`${dir}/${e.name}`) : e.name.endsWith('.ts') ? [`${dir}/${e.name}`] : []));

  it('the audit modules never log to the console, hardcode no endpoint, and the script is the only entry (no route, no scheduler)', () => {
    for (const f of ['src/assets/audit.ts', 'src/assets/audit-repository.ts']) {
      const src = code(f);
      assert.ok(!/console\.|process\.env/.test(src), `${f} logs or reads the environment`);
      assert.ok(!/https?:\/\/[a-z0-9]/i.test(src), `${f}: a URL literal`);
      assert.ok(!/setInterval|cron|schedule/i.test(src.replace(/\bsetTimeout\b/g, '')), `${f}: a scheduler`);
    }
    const importers = walk('src').concat(walk('scripts')).filter((f) => /assets\/audit(-repository)?\.ts'/.test(code(f)));
    assert.deepEqual(importers, ['scripts/assets-audit.ts']);
    assert.ok(!/audit/.test(code('src/index.ts')), 'the server never starts the audit');
  });

  it('only the locked, conditional delete removes asset rows; nothing touches car_images or showrooms; no migration, no dependency', () => {
    const repoSrc = code('src/assets/audit-repository.ts');
    assert.equal((repoSrc.match(/DELETE FROM/g) ?? []).length, 1);
    assert.match(repoSrc, /DELETE FROM assets a/);
    assert.ok(!/(INSERT INTO|UPDATE |TRUNCATE|DROP |ALTER )/.test(repoSrc));
    assert.ok(!/DELETE FROM (car_images|showrooms|users)/.test(repoSrc + code('src/assets/audit.ts')));
    const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8')) as { scripts: Record<string, string>; dependencies: Record<string, string> };
    assert.match(pkg.scripts['assets:audit']!, /scripts\/assets-audit\.ts$/);
    assert.deepEqual(Object.keys(pkg.dependencies).sort(), ['argon2', 'fastify', 'node-pg-migrate', 'pg', 'sharp']);
    assert.match(readFileSync(join(ROOT, 'scripts/assets-audit.ts'), 'utf8'), /EX_USAGE = 64/);
  });

  it('deletion in audit.ts happens only after the dry-run check, in the execution pass', () => {
    const src = code('src/assets/audit.ts');
    const first = src.indexOf('repo.deleteUnlinked');
    const guard = src.indexOf('if (!opts.dryRun && candidatesTotal > 0)');
    assert.ok(guard > 0 && first > guard, 'deleteUnlinked only inside the guarded block');
    const del = src.indexOf('storage.delete(');
    assert.ok(del > guard, 'storage.delete only inside the guarded block');
    assert.equal((src.match(/storage\.delete\(/g) ?? []).length, 2);
    assert.match(src, /error !== null \|\| unverified/);
  });
});

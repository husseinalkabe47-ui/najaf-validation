// Phase 11.6.4: image delivery. The service (visibility, never originals, byte checks, ETag/304, failures) over the in-memory
// delivery repository and the real in-memory storage provider; the HTTP contract through the real routes and the real
// authentication service; and source guards (SQL visibility, caching headers, no key in logs or responses).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { DeliveryError, createAssetDelivery, etagOf, ifNoneMatchMatches, isServableKey } from '../../src/assets/delivery.ts';
import { DELIVERY_RATE_LIMITS, IMAGE_CSP, PRIVATE_IMAGE_CACHE_CONTROL, PUBLIC_IMAGE_CACHE_CONTROL, registerAssetDeliveryRoutes, toDeliveryHttp } from '../../src/assets/delivery-routes.ts';
import { buildFindOwnReady, buildFindPublic, buildFindPublicShowroomCover, buildListPublicCarImages, toDeliverable } from '../../src/assets/delivery-repository.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { StorageProvider } from '../../src/storage/index.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeDelivery } from '../helpers/fake-delivery.ts';
import type { WorldAsset } from '../helpers/fake-delivery.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const MAIN = fakeWebp(16, 12, { payload: 40 });
const THUMB = fakeWebp(8, 6, { payload: 20 });
const actor = (id: string, role: Actor['role'] = 'member'): Actor => ({ id, role }) as Actor;

/** A storage spy: counts reads, and can fail. */
function spyStorage(inner: StorageProvider = createMemoryStorage()) {
  const gets: string[] = [];
  const faults: { get: StorageError | null } = { get: null };
  const storage: StorageProvider = {
    kind: 'memory',
    put: (k, b, o) => inner.put(k, b, o),
    get: async (k) => {
      gets.push(k);
      if (faults.get) throw faults.get;
      return inner.get(k);
    },
    delete: (k) => inner.delete(k),
    exists: (k) => inner.exists(k),
  };
  return { storage, gets, faults };
}

function setup() {
  const world = makeFakeDelivery();
  const spy = spyStorage();
  const logs: Array<Record<string, unknown>> = [];
  const delivery = createAssetDelivery({ repo: world.repo, storage: spy.storage, logger: { warn: (o) => void logs.push(o) } });
  /** A ready asset with its two objects stored (consistent with the row). */
  async function ready(fields: Partial<WorldAsset> & { ownerId: string }, main = MAIN, thumb = THUMB): Promise<WorldAsset> {
    const a = world.addAsset({ sha256: sha(main), width: 16, height: 12, ...fields });
    if (a.storageKey && isServableKey(a.storageKey)) await spy.storage.put(a.storageKey, main, { contentType: 'image/webp' });
    if (a.thumbKey && isServableKey(a.thumbKey)) await spy.storage.put(a.thumbKey, thumb, { contentType: 'image/webp' });
    return a;
  }
  async function publicCarImage(ownerId = '7') {
    const car = world.addCar(true);
    const a = await ready({ ownerId });
    world.attach(car.id, a.id, true, 0);
    return { car, a };
  }
  return { world, spy, logs, delivery, ready, publicCarImage };
}

describe('image delivery: public visibility', () => {
  it('serves the processed image and the thumbnail of a car image attached to a public car (bytes, ETag)', async () => {
    const s = setup();
    const { a } = await s.publicCarImage();
    const main = await s.delivery.publicImage(a.id, 'main');
    assert.deepEqual([...main.body!], [...MAIN]);
    assert.equal(main.etag, `"${sha(MAIN)}"`);
    assert.equal(main.notModified, false);
    const thumb = await s.delivery.publicImage(a.id.toUpperCase(), 'thumb');
    assert.deepEqual([...thumb.body!], [...THUMB]);
    assert.equal(thumb.etag, `"${sha(MAIN)}-thumb"`);
    assert.deepEqual(s.spy.gets, [a.storageKey, a.thumbKey]);
  });

  it('serves the cover of a public showroom', async () => {
    const s = setup();
    const a = await s.ready({ ownerId: '9', kind: 'showroom_cover' });
    s.world.addShowroom(true, a.id);
    assert.deepEqual([...(await s.delivery.publicImage(a.id, 'main')).body!], [...MAIN]);
  });

  it('everything else is the same 404, decided before storage is touched', async () => {
    const s = setup();
    const hiddenCar = s.world.addCar(false);
    const onHidden = await s.ready({ ownerId: '7' });
    s.world.attach(hiddenCar.id, onHidden.id);
    const unattached = await s.ready({ ownerId: '7' });
    const pendingOnPublic = await s.ready({ ownerId: '7', status: 'pending' });
    const rejectedOnPublic = await s.ready({ ownerId: '7', status: 'rejected' });
    const pub = s.world.addCar(true);
    s.world.attach(pub.id, pendingOnPublic.id);
    s.world.attach(pub.id, rejectedOnPublic.id);
    const hiddenCover = await s.ready({ ownerId: '9', kind: 'showroom_cover' });
    s.world.addShowroom(false, hiddenCover.id);
    const coverNotUsed = await s.ready({ ownerId: '9', kind: 'showroom_cover' });
    s.world.addShowroom(true, null);
    for (const id of [onHidden.id, unattached.id, pendingOnPublic.id, rejectedOnPublic.id, hiddenCover.id, coverNotUsed.id, 'c0000000-0000-4000-8000-999999999999']) {
      for (const v of ['main', 'thumb'] as const) await assert.rejects(s.delivery.publicImage(id, v), isNotFound, `${id} ${v}`);
    }
    for (const bad of [undefined, null, '', 'abc', '1', '../processed/x', 'c0000000-0000-4000-8000-00000000000', ['c0000000-0000-4000-8000-000000000001'], 42]) {
      await assert.rejects(s.delivery.publicImage(bad, 'main'), isNotFound, String(bad));
    }
    assert.equal(s.spy.gets.length, 0, 'no storage read for an invisible or malformed asset');
  });

  it('an unknown variant is 404', async () => {
    const s = setup();
    const { a } = await s.publicCarImage();
    for (const v of ['original', 'full', '', undefined, 'MAIN']) await assert.rejects(s.delivery.publicImage(a.id, v as never), isNotFound, String(v));
    assert.equal(s.spy.gets.length, 0);
  });
});

describe('image delivery: never an original, only clean processed bytes', () => {
  it('a row whose main or thumbnail key is an original upload (incoming/) or not a safe key is 404 + a log line, storage untouched', async () => {
    for (const fields of [{ storageKey: 'incoming/car_image/d0000000-0000-4000-8000-000000000001' }, { thumbKey: 'incoming/car_image/d0000000-0000-4000-8000-000000000002' }, { storageKey: '../secret' }, { thumbKey: 'thumbs//x.webp' }]) {
      const s = setup();
      const car = s.world.addCar(true);
      const a = await s.ready({ ownerId: '7', ...fields });
      s.world.attach(car.id, a.id);
      const variant = 'storageKey' in fields ? 'main' : 'thumb';
      await assert.rejects(s.delivery.publicImage(a.id, variant), isNotFound);
      assert.equal(s.spy.gets.length, 0, JSON.stringify(fields));
      assert.deepEqual(s.logs, [{ event: 'assets.delivery_failed', assetId: a.id, variant, reason: 'unservable_key', requestId: undefined }]);
    }
    assert.equal(isServableKey('incoming/x'), false);
    assert.equal(isServableKey('processed/car_image/x.webp'), true);
    assert.equal(isServableKey('cars/1/u/full.webp'), true, 'legacy processed keys stay servable');
    assert.equal(isServableKey('incoming'), true, 'only the incoming/ AREA is refused (a key without a slash is not an upload)');
  });

  it('a missing object is 404 and logged with the asset id and a reason only (never the key)', async () => {
    const s = setup();
    const { a } = await s.publicCarImage();
    await s.spy.storage.delete(a.thumbKey!);
    await assert.rejects(s.delivery.publicImage(a.id, 'thumb', { requestId: 'req-1' }), isNotFound);
    assert.deepEqual(s.logs, [{ event: 'assets.delivery_failed', assetId: a.id, variant: 'thumb', reason: 'missing_object', requestId: 'req-1' }]);
    assert.ok(!JSON.stringify(s.logs).includes('thumbs/'));
  });

  it('bytes that are not a clean still WebP (JPEG, EXIF/XMP/ICC chunk, animation flag, truncated) are 404 invalid_object', async () => {
    const jpg = new Uint8Array(readFileSync(join(ROOT, 'test', 'fixtures', 'images', 'baseline-3x2.jpg')));
    const bad = [jpg, fakeWebp(16, 12, { extraChunks: [['EXIF', 30]] }), fakeWebp(16, 12, { extraChunks: [['XMP ', 30]] }), fakeWebp(16, 12, { vp8xFlags: 0x20 }), fakeWebp(16, 12, { vp8xFlags: 0x02 }), MAIN.slice(0, MAIN.length - 4), new Uint8Array(0)];
    for (const body of bad) {
      const s = setup();
      const { a } = await s.publicCarImage();
      await s.spy.storage.put(a.thumbKey!, body.length === 0 ? new Uint8Array([0]) : body, { contentType: 'image/webp' });
      await assert.rejects(s.delivery.publicImage(a.id, 'thumb'), isNotFound);
      assert.equal(s.logs[0]!['reason'], 'invalid_object');
    }
  });

  it('a main image that differs from the row (checksum or dimensions) and a thumbnail larger than the image are 404 integrity', async () => {
    const cases: Array<[Partial<WorldAsset>, 'main' | 'thumb', Uint8Array, Uint8Array]> = [
      [{ sha256: 'f'.repeat(64) }, 'main', MAIN, THUMB],
      [{ width: 15 }, 'main', MAIN, THUMB],
      [{ height: 13 }, 'main', MAIN, THUMB],
      [{}, 'thumb', MAIN, fakeWebp(17, 6)],
      [{}, 'thumb', MAIN, fakeWebp(8, 13)],
    ];
    for (const [fields, variant, main, thumb] of cases) {
      const s = setup();
      const car = s.world.addCar(true);
      const a = await s.ready({ ownerId: '7', ...fields }, main, thumb);
      s.world.attach(car.id, a.id);
      await assert.rejects(s.delivery.publicImage(a.id, variant), isNotFound, JSON.stringify(fields));
      assert.equal(s.logs[0]!['reason'], 'integrity');
    }
    // A thumbnail equal to the image size is accepted (a small image is not enlarged).
    const s = setup();
    const car = s.world.addCar(true);
    const a = await s.ready({ ownerId: '7' }, MAIN, fakeWebp(16, 12));
    s.world.attach(car.id, a.id);
    assert.ok((await s.delivery.publicImage(a.id, 'thumb')).body);
  });

  it('a storage failure is 503 storage_unavailable (no detail); an oversized object is 404; other errors propagate', async () => {
    const s = setup();
    const { a } = await s.publicCarImage();
    s.spy.faults.get = new StorageError('unavailable', 500);
    await assert.rejects(s.delivery.publicImage(a.id, 'main'), (e: unknown) => e instanceof DeliveryError && e.code === 'storage_unavailable' && !/500|processed/.test(e.message));
    assert.equal(s.logs.at(-1)!['reason'], 'storage_unavailable');
    s.spy.faults.get = new StorageError('integrity');
    await assert.rejects(s.delivery.publicImage(a.id, 'main'), DeliveryError);
    s.spy.faults.get = new StorageError('too_large');
    await assert.rejects(s.delivery.publicImage(a.id, 'main'), isNotFound);
    assert.equal(s.logs.at(-1)!['reason'], 'invalid_object');
    s.spy.faults.get = new TypeError('boom') as never;
    await assert.rejects(s.delivery.publicImage(a.id, 'main'), TypeError);
  });

  it('a database failure propagates (mapped to 503 by the server), and nothing is read from storage', async () => {
    const s = setup();
    const { a } = await s.publicCarImage();
    s.world.faults.fail = true;
    await assert.rejects(s.delivery.publicImage(a.id, 'main'), (e: unknown) => (e as { kind?: string }).kind === 'unavailable');
    assert.equal(s.spy.gets.length, 0);
  });
});

describe('image delivery: conditional requests', () => {
  it('a matching If-None-Match is 304 without reading storage; anything else is the full image', async () => {
    const s = setup();
    const { a } = await s.publicCarImage();
    const etag = `"${sha(MAIN)}"`;
    for (const h of [etag, `W/${etag}`, `"zzz", ${etag}`, '*', ` ${etag} `]) {
      const r = await s.delivery.publicImage(a.id, 'main', { ifNoneMatch: h });
      assert.deepEqual(r, { body: null, etag, notModified: true }, h);
    }
    assert.equal(s.spy.gets.length, 0);
    for (const h of [`"${sha(MAIN)}-thumb"`, sha(MAIN), '"other"', '', undefined, ['*'], `${etag}${' '.repeat(3000)}`]) {
      assert.equal((await s.delivery.publicImage(a.id, 'main', { ifNoneMatch: h })).notModified, false, String(h).slice(0, 40));
    }
  });

  it('If-None-Match never bypasses visibility', async () => {
    const s = setup();
    const a = await s.ready({ ownerId: '7' });
    await assert.rejects(s.delivery.publicImage(a.id, 'main', { ifNoneMatch: '*' }), isNotFound);
  });

  it('ETag and If-None-Match helpers', () => {
    assert.equal(etagOf({ sha256: 'ab' }, 'main'), '"ab"');
    assert.equal(etagOf({ sha256: 'ab' }, 'thumb'), '"ab-thumb"');
    assert.equal(ifNoneMatchMatches('W/"ab"', '"ab"'), true);
    assert.equal(ifNoneMatchMatches('"ab-thumb"', '"ab"'), false);
    assert.equal(ifNoneMatchMatches('"a", "b",W/"c"', '"c"'), true);
    assert.equal(ifNoneMatchMatches(null, '"c"'), false);
  });
});

describe('image delivery: the owner', () => {
  it('the owner gets their own READY asset, attached or not, public or not; pending/rejected are 404', async () => {
    const s = setup();
    const a = await s.ready({ ownerId: '7' });
    assert.deepEqual([...(await s.delivery.ownImage(actor('7'), a.id, 'main')).body!], [...MAIN]);
    assert.deepEqual([...(await s.delivery.ownImage(actor('7', 'dealer'), a.id, 'thumb')).body!], [...THUMB]);
    for (const status of ['pending', 'rejected'] as const) {
      const p = await s.ready({ ownerId: '7', status });
      await assert.rejects(s.delivery.ownImage(actor('7'), p.id, 'main'), isNotFound, status);
    }
  });

  it("anyone else's asset (an administrator's view included) and no actor are 404, before storage", async () => {
    const s = setup();
    const { a } = await s.publicCarImage('7');
    s.spy.gets.length = 0;
    for (const who of [actor('8'), actor('8', 'dealer'), actor('1', 'admin'), null]) await assert.rejects(s.delivery.ownImage(who, a.id, 'main'), isNotFound);
    await assert.rejects(s.delivery.ownImage(actor('7'), 'nope', 'main'), isNotFound);
    assert.equal(s.spy.gets.length, 0);
  });
});

describe('image delivery: discovery', () => {
  it('lists the ready images of a public car in display order with ids and sizes only', async () => {
    const s = setup();
    const car = s.world.addCar(true);
    const a1 = await s.ready({ ownerId: '7', width: 10, height: 5 });
    const a2 = await s.ready({ ownerId: '7' });
    const p = await s.ready({ ownerId: '7', status: 'pending' });
    s.world.attach(car.id, a2.id, false, 1);
    s.world.attach(car.id, a1.id, true, 0);
    s.world.attach(car.id, p.id, false, 2);
    const r = await s.delivery.publicCarImages(car.id);
    assert.deepEqual(r, { images: [{ assetId: a1.id, isMain: true, sortOrder: 0, width: 10, height: 5 }, { assetId: a2.id, isMain: false, sortOrder: 1, width: 16, height: 12 }] });
    assert.ok(!/processed|thumbs|incoming|sha|owner|0{64}/.test(JSON.stringify(r)));
    assert.deepEqual(await s.delivery.publicCarImages(s.world.addCar(true).id), { images: [] });
  });

  it('a car that is not public, unknown or malformed is 404', async () => {
    const s = setup();
    const hidden = s.world.addCar(false);
    for (const id of [hidden.id, '999999', '0', '-1', '1.5', 'x', '', undefined, '99999999999999999999']) await assert.rejects(s.delivery.publicCarImages(id), isNotFound, String(id));
  });

  it("a public showroom's cover (or null); a showroom that is not public is 404", async () => {
    const s = setup();
    const a = await s.ready({ ownerId: '9', kind: 'showroom_cover', width: 20, height: 10 });
    const pub = s.world.addShowroom(true, a.id);
    assert.deepEqual(await s.delivery.publicShowroomCover(pub.id), { cover: { assetId: a.id, width: 20, height: 10 } });
    assert.deepEqual(await s.delivery.publicShowroomCover(s.world.addShowroom(true, null).id), { cover: null });
    for (const id of [s.world.addShowroom(false, a.id).id, '424242', 'abc', undefined]) await assert.rejects(s.delivery.publicShowroomCover(id), isNotFound);
  });
});

// ---------------------------------------------------------------------------------------------------------------------------
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { onRequest?: Array<(request: unknown, reply: unknown) => Promise<unknown>> };
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';

function http(withLimiter = false) {
  const s = setup();
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: recordingLogger().logger, now: clock.now });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => void routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  const app = { get: add('GET'), post: add('POST'), put: add('PUT'), patch: add('PATCH'), delete: add('DELETE') };
  registerAssetDeliveryRoutes(app as never, { auth, delivery: s.delivery, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  async function call(path: string, request: Record<string, unknown> = {}): Promise<Sent & { handlerRan: boolean }> {
    const route = routes.find((r) => r.method === 'GET' && r.path === path);
    if (!route) throw new Error(`no route ${path}`);
    const sent: Sent = { headers: {} };
    const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, params: {}, query: {}, log: { warn() {}, info() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return { ...sent, handlerRan: false };
    }
    await route.handler(req, reply);
    return { ...sent, handlerRan: true };
  }
  let n = 0;
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: `0771${String(1000000 + ++n).slice(-7)}`, password: PW });
    return { id: r.user.id, headers: { authorization: `Bearer ${r.session.accessToken}` } };
  }
  return { ...s, routes, call, member };
}

describe('image delivery: HTTP', () => {
  it('registers exactly the six delivery/discovery GET routes, each rate-limitable', () => {
    const h = http(true);
    assert.deepEqual(h.routes.map((r) => `${r.method} ${r.path}`).sort(), [
      'GET /v1/me/assets/:id/image', 'GET /v1/me/assets/:id/thumb', 'GET /v1/public/assets/:id/image', 'GET /v1/public/assets/:id/thumb', 'GET /v1/public/cars/:id/images', 'GET /v1/public/showrooms/:id/cover',
    ]);
    for (const r of h.routes) assert.equal(r.opts?.onRequest?.length, 1, r.path);
  });

  it('a public image: 200 image/webp with length, ETag, public short caching, a sandboxing CSP and inline disposition', async () => {
    const h = http();
    const { a } = await h.publicCarImage();
    const r = await h.call('/v1/public/assets/:id/image', { params: { id: a.id } });
    assert.equal(r.status, 200);
    assert.ok(Buffer.isBuffer(r.body));
    assert.deepEqual([...(r.body as Buffer)], [...MAIN]);
    assert.deepEqual(r.headers, {
      etag: `"${sha(MAIN)}"`, 'cache-control': PUBLIC_IMAGE_CACHE_CONTROL, 'content-security-policy': IMAGE_CSP, 'content-disposition': 'inline', 'content-type': 'image/webp', 'content-length': String(MAIN.byteLength),
    });
    assert.equal(PUBLIC_IMAGE_CACHE_CONTROL, 'public, max-age=300');
    assert.equal(IMAGE_CSP, "default-src 'none'; sandbox");
    const t = await h.call('/v1/public/assets/:id/thumb', { params: { id: a.id }, headers: { 'if-none-match': `"${sha(MAIN)}-thumb"` } });
    assert.equal(t.status, 304);
    assert.equal(t.body, undefined);
    assert.equal(t.headers['etag'], `"${sha(MAIN)}-thumb"`);
    assert.equal(t.headers['cache-control'], PUBLIC_IMAGE_CACHE_CONTROL);
    assert.equal(t.headers['content-type'], undefined);
  });

  it('errors are JSON with a code and the request id, and set NO cache-control (the server-wide no-store applies)', async () => {
    const h = http();
    const { a } = await h.publicCarImage();
    const r = await h.call('/v1/public/assets/:id/image', { params: { id: 'c0000000-0000-4000-8000-999999999999' } });
    assert.equal(r.status, 404);
    assert.deepEqual(r.body, { error: { code: 'not_found', message: 'Not found', requestId: 'req-abcdef01' } });
    assert.deepEqual(r.headers, {});
    h.spy.faults.get = new StorageError('unavailable', 503);
    const u = await h.call('/v1/public/assets/:id/image', { params: { id: a.id } });
    assert.equal(u.status, 503);
    assert.equal((u.body as { error: { code: string } }).error.code, 'storage_unavailable');
    assert.deepEqual(u.headers, {});
    assert.ok(!JSON.stringify(u.body).includes('processed/'));
  });

  it("the owner's routes need a token (401 + WWW-Authenticate), serve only the caller's ready assets, privately", async () => {
    const h = http();
    const m = await h.member();
    const other = await h.member();
    const mine = await h.ready({ ownerId: m.id });
    const theirs = await h.ready({ ownerId: other.id });
    for (const headers of [{}, { authorization: 'Bearer nope' }]) {
      const r = await h.call('/v1/me/assets/:id/image', { params: { id: mine.id }, headers });
      assert.equal(r.status, 401);
      assert.equal(r.headers['www-authenticate'], 'Bearer');
    }
    const ok = await h.call('/v1/me/assets/:id/thumb', { params: { id: mine.id }, headers: m.headers });
    assert.equal(ok.status, 200);
    assert.equal(ok.headers['cache-control'], PRIVATE_IMAGE_CACHE_CONTROL);
    assert.equal(PRIVATE_IMAGE_CACHE_CONTROL, 'private, no-store');
    assert.deepEqual([...(ok.body as Buffer)], [...THUMB]);
    const no = await h.call('/v1/me/assets/:id/image', { params: { id: theirs.id }, headers: m.headers });
    assert.equal(no.status, 404);
  });

  it('discovery routes answer JSON (and 404 for a car or showroom that is not public)', async () => {
    const h = http();
    const { car, a } = await h.publicCarImage();
    const r = await h.call('/v1/public/cars/:id/images', { params: { id: car.id } });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body, { images: [{ assetId: a.id, isMain: true, sortOrder: 0, width: 16, height: 12 }] });
    assert.equal((await h.call('/v1/public/cars/:id/images', { params: { id: h.world.addCar(false).id } })).status, 404);
    assert.equal((await h.call('/v1/public/showrooms/:id/cover', { params: { id: h.world.addShowroom(true).id } })).status, 200);
    assert.equal((await h.call('/v1/public/showrooms/:id/cover', { params: { id: h.world.addShowroom(false).id } })).status, 404);
  });

  it('rate limits per route and client address (429 + Retry-After, before any lookup)', async () => {
    const h = http(true);
    const { a } = await h.publicCarImage();
    for (const [path, route] of [['/v1/public/assets/:id/thumb', 'publicImage'], ['/v1/me/assets/:id/image', 'ownImage'], ['/v1/public/cars/:id/images', 'discovery']] as const) {
      const limit = DELIVERY_RATE_LIMITS[route].limit;
      for (let i = 0; i < limit; i++) await h.call(path, { params: { id: a.id } });
      const calls = h.world.calls.length;
      const r = await h.call(path, { params: { id: a.id } });
      assert.equal(r.status, 429, path);
      assert.equal(r.handlerRan, false);
      assert.ok(Number(r.headers['retry-after']) > 0);
      assert.equal(h.world.calls.length, calls);
    }
  });

  it('error mapping: auth, authz, delivery; anything else is rethrown (server error handler)', () => {
    assert.equal(toDeliveryHttp(new DeliveryError('storage_unavailable'))?.status, 503);
    assert.equal(toDeliveryHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toDeliveryHttp(new Error('x')), undefined);
  });
});

describe('image delivery: source guards', () => {
  it('PUBLIC visibility is the public_cars / public_showrooms views and status ready; the owner read is scoped by owner_id', () => {
    const p = buildFindPublic('x').text.replace(/\s+/g, ' ');
    assert.match(p, /a\.status = 'ready'/);
    assert.match(p, /a\.kind = 'car_image' AND EXISTS \(SELECT 1 FROM car_images ci JOIN public_cars pc ON pc\.id = ci\.car_id WHERE ci\.asset_id = a\.id\)/);
    assert.match(p, /a\.kind = 'showroom_cover' AND EXISTS \(SELECT 1 FROM public_showrooms ps WHERE ps\.cover_asset_id = a\.id\)/);
    assert.ok(!/\bFROM cars\b|\bFROM showrooms\b|JOIN cars\b|JOIN showrooms\b/.test(p), 'never the base tables');
    const o = buildFindOwnReady('x', '7');
    assert.match(o.text, /a\.id = \$1::uuid AND a\.owner_id = \$2::bigint AND a\.status = 'ready'/);
    assert.deepEqual(o.values, ['x', '7']);
    assert.match(buildListPublicCarImages('1').text, /FROM public_cars pc[\s\S]*a\.status = 'ready' AND a\.kind = 'car_image'[\s\S]*ORDER BY ci\.sort_order, ci\.id/);
    assert.match(buildFindPublicShowroomCover('1').text, /FROM public_showrooms ps[\s\S]*a\.status = 'ready' AND a\.kind = 'showroom_cover'/);
    for (const b of [buildFindPublic('x'), buildFindOwnReady('x', '1'), buildListPublicCarImages('1'), buildFindPublicShowroomCover('1')]) assert.ok(!/SELECT \*|\ba\.\*/.test(b.text));
  });

  it('a row missing any delivery column is not deliverable', () => {
    const full = { id: 'x', kind: 'car_image', storage_key: 'k', thumb_key: 't', sha256: 'a'.repeat(64), width: 1, height: 1 };
    assert.ok(toDeliverable(full));
    for (const k of ['storage_key', 'thumb_key', 'sha256', 'width', 'height'] as const) assert.equal(toDeliverable({ ...full, [k]: null }), null, k);
    assert.equal(toDeliverable(undefined), null);
  });

  it('only the delivery routes make a caching decision; the server keeps no-store for everything else', () => {
    const server = code('src/server.ts');
    assert.match(server, /if \(!reply\.hasHeader\('cache-control'\)\) reply\.header\('cache-control', 'no-store'\);/);
    const walk = (dir: string): string[] => readdirSync(join(ROOT, dir), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(`${dir}/${e.name}`) : e.name.endsWith('.ts') ? [`${dir}/${e.name}`] : []));
    const files = walk('src').filter((f) => /cache-control/.test(code(f)));
    assert.deepEqual(files.sort(), ['src/assets/delivery-routes.ts', 'src/server.ts']);
  });

  it('delivery logs carry an asset id, a variant and a reason: never a key; the routes never touch storage', () => {
    const src = code('src/assets/delivery.ts');
    const logs = [...src.matchAll(/logger\?\.warn\(\{([^}]*)\}/g)].map((m) => m[1]!);
    assert.equal(logs.length, 1);
    assert.match(logs[0]!, /^ event: 'assets\.delivery_failed', assetId: asset\.id, variant, reason, requestId: ctx\.requestId $/);
    assert.ok(!/storage/.test(code('src/assets/delivery-routes.ts').replace(/storage_unavailable/g, '')));
  });
});


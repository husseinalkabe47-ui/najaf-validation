// Phase 11.7.2.3: password recovery must not pretend. With no messaging provider wired in, the request answers 503
// delivery_unavailable (for every phone alike), generates and stores no code, and the rest of the contract is unchanged.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAuthService } from '../../src/auth/service.ts';
import { createOtpService } from '../../src/auth/otp-service.ts';
import { AuthError } from '../../src/auth/types.ts';
import { registerAuthRoutes, toAuthHttp } from '../../src/auth/routes.ts';
import { createUnconfiguredMessagingProvider } from '../../src/messaging/provider.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeProvider } from '../helpers/fake-messaging.ts';

const SECRET = 'otp-service-test-secret-0123456789abcdef-QWE';
function setup(unconfigured: boolean) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const msg = makeFakeProvider();
  const provider = unconfigured ? createUnconfiguredMessagingProvider() : msg.provider;
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const otp = createOtpService({ store: db.store, hasher, provider, otpSecret: SECRET, logger: log.logger });
  return { db, msg, auth, otp, log };
}
const fail = async (p: Promise<unknown>): Promise<AuthError> => { try { await p; } catch (e) { assert.ok(e instanceof AuthError); return e; } throw new Error('expected failure'); };

describe('the unconfigured provider says so', () => {
  it('is marked configured=false; a fake provider (no flag) is treated as able to deliver', () => {
    assert.equal(createUnconfiguredMessagingProvider().configured, false);
    assert.equal(makeFakeProvider().provider.configured, undefined);
  });
  it('maps to HTTP 503 with a fixed generic body', () => {
    assert.deepEqual(toAuthHttp(new AuthError('delivery_unavailable')), { status: 503, code: 'delivery_unavailable', message: 'One-time code delivery is not available' });
  });
  it('password-reset request: 503 for a registered phone and an unknown phone ALIKE (reveals nothing about accounts), nothing stored', async () => {
    const env = setup(true);
    await env.auth.register({ name: 'علي حسين', phone: '07701234567', password: 'Passw0rd-123' });
    const known = await fail(env.otp.requestPasswordReset({ phone: '07701234567' }));
    const unknown = await fail(env.otp.requestPasswordReset({ phone: '07709999999' }));
    assert.equal(known.code, 'delivery_unavailable');
    assert.equal(JSON.stringify({ c: known.code, m: known.message, f: known.fields }), JSON.stringify({ c: unknown.code, m: unknown.message, f: unknown.fields }));
    assert.equal(env.db.codes().length, 0, 'no code generated or stored');
    assert.ok(env.log.entries.some(e => JSON.stringify(e).includes('delivery_unavailable')));
  });
  it('validation still comes first (a malformed phone is a 400-class validation error, not 503)', async () => {
    const env = setup(true);
    assert.equal((await fail(env.otp.requestPasswordReset({ phone: 'abc' }))).code, 'validation_failed');
    assert.equal((await fail(env.otp.requestPasswordReset({ phone: '07701234567', extra: 1 }))).code, 'validation_failed');
  });
  it('with a provider that can deliver the contract is unchanged: ALWAYS accepted, known or not', async () => {
    const env = setup(false);
    await env.auth.register({ name: 'علي حسين', phone: '07701234567', password: 'Passw0rd-123' });
    assert.deepEqual(await env.otp.requestPasswordReset({ phone: '07701234567' }), { status: 'accepted' });
    assert.deepEqual(await env.otp.requestPasswordReset({ phone: '07709999999' }), { status: 'accepted' });
    assert.equal(env.msg.sent.length, 1);
  });
  it('reset with a code and phone verification are untouched by the flag', async () => {
    const env = setup(true);
    const r = await env.auth.register({ name: 'علي حسين', phone: '07701234567', password: 'Passw0rd-123' });
    assert.equal((await fail(env.otp.resetPassword({ phone: '07701234567', code: '123456', newPassword: 'Another-Passw0rd' }))).code, 'invalid_code');
    assert.deepEqual(await env.otp.requestPhoneVerification(r.user.id), { status: 'sent' });
  });
});

describe('the forgot-password ROUTE', () => {
  it('answers 503 delivery_unavailable with the fixed body and no Retry-After/cookie, and 202 when delivery works', async () => {
    for (const [unconfigured, status] of [[true, 503], [false, 202]] as const) {
      const env = setup(unconfigured);
      let handler: ((req: unknown, rep: unknown) => Promise<unknown>) | undefined;
      const app = { get() {}, post: (p: string, ...r: unknown[]) => { if (p === '/v1/auth/password/forgot') handler = r[r.length - 1] as typeof handler; } };
      registerAuthRoutes(app as never, { auth: env.auth, otp: env.otp });
      const sent: { status?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
      const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
      await handler!({ id: 'req-1', ip: '1.1.1.1', headers: {}, body: { phone: '07701234567' }, log: { warn() {} } }, reply);
      assert.equal(sent.status, status);
      if (unconfigured) assert.deepEqual(sent.body, { error: { code: 'delivery_unavailable', message: 'One-time code delivery is not available', requestId: 'req-1' } });
      else assert.deepEqual(sent.body, { status: 'accepted' });
      assert.equal(sent.headers['set-cookie'], undefined);
    }
  });
});

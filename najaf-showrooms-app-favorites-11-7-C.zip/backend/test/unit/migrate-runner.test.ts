import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DbError } from '../../src/errors.ts';
import { loadMigrationConfig } from '../../src/migrate/config.ts';
import { MIGRATIONS_DIR, TRACKING_SCHEMA, TRACKING_TABLE, listMigrationNames } from '../../src/migrate/paths.ts';
import {
  MIGRATION_ROLE_QUERY,
  MigrationRoleError,
  assertMigrationRole,
  createClientFactory,
  migrationRoleViolations,
  parseMigrationRoleRow,
  preflightMigrationRole,
} from '../../src/migrate/preflight.ts';
import type { MigrationRoleReport, PgClientLike, PgClientModuleLike } from '../../src/migrate/preflight.ts';
import { MigrationError, assertCleanMigrationsDir, buildRunnerOptions, migrationStatus, parseMigrateArgs, runMigrations } from '../../src/migrate/runner.ts';
import type { RunnerFn, RunnerOptions } from '../../src/migrate/runner.ts';
import type { Logger } from '../../src/types.ts';
import { pgError } from '../helpers/fake-pool.ts';

const URL_OK = 'postgres://najaf_migrator:S3cr3tMig@db.internal:5432/najaf';
const cfgOf = (extra: Record<string, string> = {}) => loadMigrationConfig({ MIGRATION_DATABASE_URL: URL_OK, ...extra });
const prodCfg = (extra: Record<string, string> = {}) => cfgOf({ NODE_ENV: 'production', MIGRATION_DB_SSL: 'verify-full', ...extra });

function fakeRunner(result: Array<{ name?: string; path?: string }> = [{ name: '0001_extensions_helpers' }]) {
  const calls: RunnerOptions[] = [];
  const fn: RunnerFn = async (o) => {
    calls.push(o);
    return result;
  };
  return { fn, calls };
}

function recorder() {
  const infos: unknown[] = [];
  const logger: Logger = { debug() {}, info: (o) => infos.push(o), warn() {}, error() {} };
  return { logger, infos };
}

describe('runner: options passed to node-pg-migrate', () => {
  it('up: wrappers dir, tracking in ops.pgmigrations, no count, account from the config', async () => {
    const { fn, calls } = fakeRunner();
    const cfg = cfgOf();
    await runMigrations(cfg, { direction: 'up' }, { runnerFn: fn });
    const o = calls[0]!;
    assert.deepEqual(o.databaseUrl, cfg.client);
    assert.equal(o.dir, MIGRATIONS_DIR);
    assert.equal(o.direction, 'up');
    assert.equal(o.migrationsTable, 'pgmigrations');
    assert.equal(o.migrationsSchema, 'ops');
    assert.equal(o.createMigrationsSchema, true);
    assert.equal(o.singleTransaction, false);
    assert.equal('count' in o, false);
    assert.equal(typeof o.log, 'function');
  });

  it('the tracking location constants are exactly ops.pgmigrations', () => {
    assert.equal(TRACKING_SCHEMA, 'ops');
    assert.equal(TRACKING_TABLE, 'pgmigrations');
  });

  it('single-transaction mode is passed through', async () => {
    const { fn, calls } = fakeRunner();
    await runMigrations(cfgOf({ MIGRATION_SINGLE_TRANSACTION: 'true' }), { direction: 'up' }, { runnerFn: fn });
    assert.equal(calls[0]?.singleTransaction, true);
  });

  it('down: --steps N becomes count N; --all becomes the number of migrations (13)', async () => {
    const { fn, calls } = fakeRunner();
    await runMigrations(cfgOf(), { direction: 'down', steps: 1 }, { runnerFn: fn });
    await runMigrations(cfgOf(), { direction: 'down', steps: 5 }, { runnerFn: fn });
    await runMigrations(cfgOf(), { direction: 'down', steps: 'all' }, { runnerFn: fn });
    assert.deepEqual(calls.map((c) => c.count), [1, 5, 13]);
    assert.equal(listMigrationNames().length, 13);
    assert.ok(calls.every((c) => c.direction === 'down'));
  });

  it('down never has an implicit count: missing, zero, fractional, or too many steps are rejected before the tool runs', async () => {
    const { fn, calls } = fakeRunner();
    for (const steps of [undefined, 0, -1, 1.5, 14, Number.NaN]) {
      await assert.rejects(
        runMigrations(cfgOf(), { direction: 'down', ...(steps === undefined ? {} : { steps }) }, { runnerFn: fn }),
        (e: unknown) => e instanceof MigrationError && e.code === 'bad_request',
        String(steps),
      );
    }
    assert.equal(calls.length, 0);
  });

  it('forwards node-pg-migrate log lines to the logger', async () => {
    const { fn, calls } = fakeRunner();
    const { logger, infos } = recorder();
    await runMigrations(cfgOf(), { direction: 'up' }, { runnerFn: fn, logger });
    calls[0]?.log('Migrating files');
    assert.deepEqual(infos, [{ migration: 'Migrating files' }]);
  });

  it('buildRunnerOptions honours a custom directory (used by tests)', () => {
    const o = buildRunnerOptions(cfgOf(), { direction: 'up', steps: undefined }, () => {}, '/tmp/x');
    assert.equal(o.dir, '/tmp/x');
  });
});

describe('runner: the directory handed to node-pg-migrate contains only wrappers', () => {
  const dirWith = (files: string[]): string => {
    const d = mkdtempSync(join(tmpdir(), 'migdir-'));
    for (const f of files) writeFileSync(join(d, f), '');
    return d;
  };
  const invalid = (e: unknown) => e instanceof MigrationError && e.code === 'invalid_migrations_dir';

  it('the real directory passes', () => {
    assert.doesNotThrow(() => assertCleanMigrationsDir());
  });

  it('a stray package.json (the original failure) is refused with an explicit message, before the tool runs', async () => {
    const { fn, calls } = fakeRunner();
    const dir = dirWith(['0001_a.js', '0002_b.js', 'package.json']);
    await assert.rejects(runMigrations(cfgOf(), { direction: 'up' }, { runnerFn: fn, dir }), (e: unknown) => invalid(e) && (e as Error).message.includes('package.json'));
    assert.equal(calls.length, 0);
  });

  it('any other unexpected entry, a badly named wrapper, an empty or unreadable directory is refused', () => {
    for (const extra of ['README.md', 'notes.txt', '1_x.js', '0003_Upper.js', '0004_x.cjs', '0005_x.down.sql']) {
      assert.throws(() => assertCleanMigrationsDir(dirWith(['0001_a.js', extra])), invalid, extra);
    }
    assert.throws(() => assertCleanMigrationsDir(dirWith([])), invalid);
    assert.throws(() => assertCleanMigrationsDir(join(tmpdir(), 'does-not-exist-migdir')), invalid);
  });

  it('the guard applies to down as well, and does not run for a rollback that production forbids (that error comes first)', async () => {
    const { fn, calls } = fakeRunner();
    const dir = dirWith(['0001_a.js', 'package.json']);
    await assert.rejects(runMigrations(cfgOf(), { direction: 'down', steps: 1 }, { runnerFn: fn, dir }), invalid);
    await assert.rejects(runMigrations(prodCfg(), { direction: 'down', steps: 1 }, { runnerFn: fn, dir }), (e: unknown) => e instanceof MigrationError && e.code === 'rollback_disabled');
    assert.equal(calls.length, 0);
  });
});

describe('runner: production rollback guard', () => {
  it('blocks down in production unless explicitly allowed, without touching the tool', async () => {
    const { fn, calls } = fakeRunner();
    await assert.rejects(
      runMigrations(prodCfg(), { direction: 'down', steps: 1 }, { runnerFn: fn }),
      (e: unknown) => e instanceof MigrationError && e.code === 'rollback_disabled',
    );
    assert.equal(calls.length, 0);
  });

  it('allows down in production with MIGRATION_ALLOW_ROLLBACK=true, and always allows up', async () => {
    const { fn, calls } = fakeRunner();
    await runMigrations(prodCfg({ MIGRATION_ALLOW_ROLLBACK: 'true' }), { direction: 'down', steps: 1 }, { runnerFn: fn });
    await runMigrations(prodCfg(), { direction: 'up' }, { runnerFn: fn });
    assert.equal(calls.length, 2);
  });

  it('outside production rollback needs no opt-in', async () => {
    const { fn, calls } = fakeRunner();
    await runMigrations(cfgOf({ NODE_ENV: 'test' }), { direction: 'down', steps: 1 }, { runnerFn: fn });
    assert.equal(calls.length, 1);
  });
});

describe('runner: results and errors', () => {
  it('reports the migration names that ran, from names or file paths', async () => {
    const { fn } = fakeRunner([{ name: '0001_extensions_helpers' }, { path: '/x/db/migrations/0002_users.js' }]);
    assert.deepEqual((await runMigrations(cfgOf(), { direction: 'up' }, { runnerFn: fn })).ran, ['0001_extensions_helpers', '0002_users']);
  });

  it('an empty run (nothing pending) is a normal result', async () => {
    const { fn } = fakeRunner([]);
    assert.deepEqual(await runMigrations(cfgOf(), { direction: 'up' }, { runnerFn: fn }), { direction: 'up', ran: [] });
  });

  it('a tool failure becomes MigrationError(runner_failed) and never contains the password', async () => {
    const fn: RunnerFn = async () => {
      throw new Error('connect failed for postgres://najaf_migrator:S3cr3tMig@db.internal/najaf');
    };
    await assert.rejects(runMigrations(cfgOf(), { direction: 'up' }, { runnerFn: fn }), (e: unknown) => {
      return e instanceof MigrationError && e.code === 'runner_failed' && !e.message.includes('S3cr3tMig') && e.message.includes('***');
    });
  });

  it('a driver error is classified as a DbError (no SQL, no values)', async () => {
    const fn: RunnerFn = async () => {
      throw pgError('42501', 'permission denied for schema public');
    };
    await assert.rejects(runMigrations(cfgOf(), { direction: 'up' }, { runnerFn: fn }), (e: unknown) => e instanceof DbError && e.kind === 'forbidden');
  });
});

describe('runner: command-line parsing', () => {
  it('parses up, status, down --steps N and down --all', () => {
    assert.deepEqual(parseMigrateArgs(['up']), { kind: 'up' });
    assert.deepEqual(parseMigrateArgs(['status']), { kind: 'status' });
    assert.deepEqual(parseMigrateArgs(['down', '--steps', '3']), { kind: 'down', steps: 3 });
    assert.deepEqual(parseMigrateArgs(['down', '--all']), { kind: 'down', steps: 'all' });
  });

  it('rejects anything ambiguous: bare down, zero/negative/huge steps, extra arguments, unknown commands', () => {
    const bad: string[][] = [[], ['down'], ['down', '--steps'], ['down', '--steps', '0'], ['down', '--steps', '-1'], ['down', '--steps', '1000'], ['down', '--steps', 'x'], ['down', '--all', '--steps', '1'], ['up', '--force'], ['status', 'x'], ['drop']];
    for (const a of bad) assert.throws(() => parseMigrateArgs(a), (e: unknown) => e instanceof MigrationError && e.code === 'bad_request', a.join(' '));
  });
});

function fakeClient(rows: Array<Record<string, unknown>>, failOn?: Error) {
  const calls: string[] = [];
  const client: PgClientLike = {
    connect: async () => {
      calls.push('connect');
    },
    query: async (text) => {
      calls.push('query');
      if (failOn) throw failOn;
      void text;
      return { rows };
    },
    end: async () => {
      calls.push('end');
    },
  };
  return { client, calls, factory: async () => client };
}

const goodRow = { cur_user: 'najaf_migrator', is_super: false, can_create_role: true, is_app_member: false, can_use_app_role: false, can_set_app_role: false, server_version_num: 160013 };
const goodReport: MigrationRoleReport = { currentUser: 'najaf_migrator', isSuperuser: false, canCreateRole: true, isAppMember: false, canUseAppRole: false, canSetAppRole: false, serverVersionNum: 160013 };

describe('preflight: the migration account is not an application identity', () => {
  it('parses the catalog row and passes for an owner-level, non-member account', () => {
    assert.deepEqual(parseMigrationRoleRow(goodRow), goodReport);
    assert.deepEqual(migrationRoleViolations(goodReport), []);
  });

  it('ADMIN-only membership in najaf_app (what PostgreSQL 16 gives the creator of the role) is accepted: it neither inherits nor can SET ROLE', () => {
    assert.deepEqual(migrationRoleViolations({ ...goodReport, isAppMember: true, canUseAppRole: false, canSetAppRole: false }), []);
  });

  it('rejects an account that inherits the privileges of najaf_app, or can SET ROLE to it (an application identity)', () => {
    assert.equal(migrationRoleViolations({ ...goodReport, isAppMember: true, canUseAppRole: true }).length, 1);
    assert.equal(migrationRoleViolations({ ...goodReport, isAppMember: true, canSetAppRole: true }).length, 1);
    assert.equal(migrationRoleViolations({ ...goodReport, isAppMember: true, canUseAppRole: true, canSetAppRole: true }).length, 2);
  });

  it('a superuser (who has every role implicitly) is not rejected for that', () => {
    assert.deepEqual(migrationRoleViolations({ ...goodReport, isSuperuser: true, isAppMember: true, canUseAppRole: true, canSetAppRole: true }), []);
  });

  it('rejects PostgreSQL older than 16', () => {
    assert.ok(migrationRoleViolations({ ...goodReport, serverVersionNum: 150004 }).some((m) => m.includes('older than the supported 16')));
  });

  it('the query is one read-only statement tolerant of a missing najaf_app role', () => {
    assert.ok(!MIGRATION_ROLE_QUERY.includes(';'));
    assert.ok(MIGRATION_ROLE_QUERY.includes("rolname = 'najaf_app'"));
    assert.ok(MIGRATION_ROLE_QUERY.includes("'USAGE'") && MIGRATION_ROLE_QUERY.includes("'SET'"), 'the query must test USAGE and SET, not only membership');
    for (const w of ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER', 'CREATE']) assert.ok(!new RegExp(`\\b${w}\\b`).test(MIGRATION_ROLE_QUERY), w);
  });

  it('connects, queries, always closes', async () => {
    const f = fakeClient([goodRow]);
    assert.deepEqual(await preflightMigrationRole(cfgOf().client, { clientFactory: f.factory }), goodReport);
    assert.deepEqual(f.calls, ['connect', 'query', 'end']);
  });

  it('classifies a driver failure (wrong password) without leaking it, and still closes', async () => {
    const f = fakeClient([], pgError('28P01', 'password authentication failed for user "najaf_migrator"'));
    await assert.rejects(preflightMigrationRole(cfgOf().client, { clientFactory: f.factory }), (e: unknown) => e instanceof DbError && e.kind === 'auth_failed' && !JSON.stringify(e).includes('S3cr3tMig'));
    assert.equal(f.calls.at(-1), 'end');
  });

  it('assertMigrationRole throws MigrationRoleError for an application identity', async () => {
    const f = fakeClient([{ ...goodRow, cur_user: 'najaf_app_login', is_app_member: true, can_use_app_role: true }]);
    await assert.rejects(assertMigrationRole(cfgOf(), { clientFactory: f.factory }), (e: unknown) => e instanceof MigrationRoleError && e.violations.length === 1);
  });

  it('the client factory builds a pg Client from the default or a named export, with the full config', async () => {
    const seen: Array<Record<string, unknown>> = [];
    class Client {
      constructor(o: Record<string, unknown>) {
        seen.push(o);
      }
    }
    await createClientFactory(async () => ({ default: { Client } }) as unknown as PgClientModuleLike)(cfgOf().client);
    await createClientFactory(async () => ({ Client }) as unknown as PgClientModuleLike)(cfgOf().client);
    assert.equal(seen.length, 2);
    assert.equal(seen[0]?.['user'], 'najaf_migrator');
    assert.equal(seen[0]?.['application_name'], 'najaf-migrate');
    await assert.rejects(createClientFactory(async () => ({}))(cfgOf().client), /Client/);
  });
});

describe('status', () => {
  const names = listMigrationNames();

  it('splits applied and pending', async () => {
    const f = fakeClient(names.slice(0, 10).map((name) => ({ name })));
    const s = await migrationStatus(cfgOf(), { clientFactory: f.factory });
    assert.equal(s.applied.length, 10);
    assert.deepEqual(s.pending, names.slice(10));
    assert.deepEqual(s.unknown, []);
    assert.equal(f.calls.at(-1), 'end');
  });

  it('reports tracked names that no longer exist in db/migrations', async () => {
    const f = fakeClient([...names.map((name) => ({ name })), { name: '9999_ghost' }]);
    const s = await migrationStatus(cfgOf(), { clientFactory: f.factory });
    assert.deepEqual(s.unknown, ['9999_ghost']);
    assert.deepEqual(s.pending, []);
  });

  it('a missing tracking table means nothing applied yet', async () => {
    const f = fakeClient([], pgError('42P01', 'relation "ops.pgmigrations" does not exist'));
    const s = await migrationStatus(cfgOf(), { clientFactory: f.factory });
    assert.deepEqual(s, { applied: [], pending: names, unknown: [] });
  });

  it('any other failure is classified and the connection is closed', async () => {
    const f = fakeClient([], pgError('42501', 'permission denied for schema ops'));
    await assert.rejects(migrationStatus(cfgOf(), { clientFactory: f.factory }), (e: unknown) => e instanceof DbError && e.kind === 'forbidden');
    assert.equal(f.calls.at(-1), 'end');
  });
});

describe('CLI output contract (scripts/migrate.ts): stdout carries the result document only', () => {
  const src = readFileSync(join(import.meta.dirname, '..', '..', 'scripts', 'migrate.ts'), 'utf8');

  it('sends node-pg-migrate log lines to stderr, never through the default (stdout) console logger', () => {
    assert.ok(!/createConsoleLogger\(\s*\)/.test(src), 'createConsoleLogger() with no writer logs to stdout and corrupts the result document');
    assert.match(src, /createConsoleLogger\(\(line\) => console\.error\(line\)\)/);
  });

  it('the only stdout writes are the two JSON result documents (status, and up/down)', () => {
    const stdoutWrites = src.split('\n').filter((l) => /console\.log\(/.test(l));
    assert.equal(stdoutWrites.length, 2);
    for (const l of stdoutWrites) assert.match(l, /console\.log\(JSON\.stringify\(\{ ok: true,/);
  });
});

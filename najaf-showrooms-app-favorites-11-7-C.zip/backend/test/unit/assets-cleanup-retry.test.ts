// Phase 11.6.5: recovery of pending assets left by a transient failure. The cleanup job's retry phase (phase 0) over the
// in-memory cleanup repository with a scripted processor (window, bounds, dry run, outcomes, failures), then end to end with the
// REAL upload service and the REAL processor (fake codec, in-memory storage with fault injection, in-memory asset store):
// a transient failure is recovered by a later run, repeat runs are harmless, and the other phases never touch the outputs.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Actor } from '../../src/authz/index.ts';
import { CleanupOptionsError, RETRY_MIN_AGE_MINUTES, resolveCleanupOptions, runAssetCleanup } from '../../src/assets/cleanup.ts';
import { buildListRetryable } from '../../src/assets/cleanup-repository.ts';
import type { CleanupRepository } from '../../src/assets/cleanup-repository.ts';
import { createAssetProcessor, derivedKeys } from '../../src/assets/processing-service.ts';
import type { ProcessOutcome } from '../../src/assets/processing-service.ts';
import { createAssetService } from '../../src/assets/service.ts';
import { inspectWebp } from '../../src/assets/webp-inspect.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { ListableStorage } from '../../src/storage/index.ts';
import { parseCleanupArgs } from '../../scripts/assets-cleanup.ts';
import { makeFakeAssetStore } from '../helpers/fake-assets.ts';
import { makeFakeCleanup } from '../helpers/fake-cleanup.ts';
import { createFakeCodec } from '../helpers/fake-codec.ts';
import { makeFakeProcessingRepo } from '../helpers/fake-processing.ts';
import type { ProcessedFakeAsset } from '../helpers/fake-processing.ts';

const T0 = Date.UTC(2026, 9, 10);
const MIN = 60 * 1000;
const H = 60 * MIN;
const u = (i: number) => `d0000000-0000-4000-8000-${String(i).padStart(12, '0')}`;
const inc = (i: number) => `incoming/car_image/${u(i)}`;
const PHOTO = new Uint8Array(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'processing', 'photo-2400x1600.jpg')));
const M: Actor = Object.freeze({ id: '1', role: 'member' });

/** A scripted processor: answers per id (default 'ready'), records calls. */
function scripted(answers: Record<string, ProcessOutcome | 'throw'> = {}) {
  const calls: string[] = [];
  return {
    calls,
    processor: {
      async process(id: string): Promise<ProcessOutcome> {
        calls.push(id);
        const a = answers[id];
        if (a === 'throw') throw new Error('boom');
        return a ?? { result: 'ready', asset: null };
      },
    },
  };
}

function world() {
  const clock = { now: () => new Date(T0) };
  const fc = makeFakeCleanup(clock);
  const storage = createMemoryStorage();
  const row = (ageMinutes: number, fields: Parameters<typeof fc.add>[0] = {}) => fc.add({ status: 'pending', storageKey: inc(Math.round(ageMinutes)), createdAt: new Date(T0 - ageMinutes * MIN), ...fields });
  return { clock, fc, storage, row };
}

describe('retry phase: window and bounds', () => {
  it('retries only PENDING assets older than 15 minutes and younger than the threshold, oldest first', async () => {
    const w = world();
    w.row(5); // the upload's own attempt may still run
    const r20 = w.row(20);
    const r120 = w.row(120);
    const r23h = w.row(23 * 60);
    w.row(25 * 60); // stale: phase 1's
    w.row(120, { status: 'ready', storageKey: 'processed/car_image/x.webp' });
    w.row(120, { status: 'rejected' });
    const p = scripted();
    const r = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: p.processor, now: w.clock.now }, { dryRun: false, rows: false, orphans: false });
    assert.equal(r.error, null);
    assert.deepEqual(p.calls, [r23h.id, r120.id, r20.id]);
    assert.deepEqual(r.retry, { candidates: 3, attempted: 3, ready: 3, rejected: 0, stillPending: 0, skipped: 0 });
    const call = w.fc.calls.find((c) => c.op === 'listRetryable')!.arg as Record<string, number>;
    assert.deepEqual(call, { minAgeSeconds: RETRY_MIN_AGE_MINUTES * 60, maxAgeSeconds: 24 * 3600, limit: 20 });
    assert.equal(RETRY_MIN_AGE_MINUTES, 15);
  });

  it('the window follows --older-than-hours (never overlapping phase 1) and is bounded by retryLimit', async () => {
    const w = world();
    const r30h = w.row(30 * 60);
    for (let i = 0; i < 5; i++) w.row(60 + i);
    const p = scripted();
    const r = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: p.processor, now: w.clock.now }, { dryRun: false, rows: false, orphans: false, olderThanHours: 48, retryLimit: 2 });
    assert.deepEqual(p.calls, [r30h.id, w.fc.rows()[5]!.id]);
    assert.equal(r.retry!.candidates, 2);
    assert.equal((w.fc.calls.find((c) => c.op === 'listRetryable')!.arg as Record<string, number>)['maxAgeSeconds'], 48 * 3600);
  });

  it('never attempts more than retryLimit, even if the listing returned more', async () => {
    const w = world();
    const repo: CleanupRepository = { ...w.fc.repo, listRetryable: async () => [u(1), u(2), u(3)] };
    const p = scripted();
    const r = await runAssetCleanup({ repo, storage: w.storage, processor: p.processor }, { dryRun: false, rows: false, orphans: false, retryLimit: 2 });
    assert.deepEqual(p.calls, [u(1), u(2)]);
    assert.equal(r.retry!.attempted, 2);
  });

  it('a dry run counts the candidates and processes nothing', async () => {
    const w = world();
    w.row(30);
    w.row(40);
    const p = scripted();
    const r = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: p.processor, now: w.clock.now }, { rows: false, orphans: false });
    assert.equal(r.dryRun, true);
    assert.deepEqual(r.retry, { candidates: 2, attempted: 0, ready: 0, rejected: 0, stillPending: 0, skipped: 0 });
    assert.deepEqual(p.calls, []);
  });

  it('without a processor, or with retry off, the phase does not run (report null, no query)', async () => {
    const w = world();
    w.row(30);
    const a = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage }, { dryRun: false, rows: false, orphans: false });
    assert.equal(a.retry, null);
    const p = scripted();
    const b = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: p.processor }, { dryRun: false, rows: false, orphans: false, retry: false });
    assert.equal(b.retry, null);
    assert.deepEqual(p.calls, []);
    assert.ok(!w.fc.calls.some((c) => c.op === 'listRetryable'));
  });

  it('options: retryLimit 1..200 (default 20); the CLI has --retry-limit and --skip-retry', () => {
    assert.equal(resolveCleanupOptions().retryLimit, 20);
    assert.equal(resolveCleanupOptions().retry, true);
    for (const bad of [0, 201, 1.5, Number.NaN]) assert.throws(() => resolveCleanupOptions({ retryLimit: bad }), (e: unknown) => e instanceof CleanupOptionsError && e.problems.includes('retryLimit'));
    assert.equal(resolveCleanupOptions({ retryLimit: 200 }).retryLimit, 200);
    assert.equal(parseCleanupArgs(['--retry-limit=7']).retryLimit, 7);
    assert.equal(parseCleanupArgs(['--skip-retry']).retry, false);
    for (const bad of [['--retry-limit'], ['--retry-limit=0'], ['--retry-limit=500'], ['--skip-retry=yes']]) {
      assert.throws(() => parseCleanupArgs(bad), (e: unknown) => e instanceof CleanupOptionsError && e.problems.some((p) => p.startsWith('--')), bad.join(' '));
    }
  });
});

describe('retry phase: outcomes and failures', () => {
  it('counts ready, rejected, skipped and non-transient pending outcomes, and runs the other phases afterwards', async () => {
    const w = world();
    const ids = [w.row(100), w.row(90), w.row(80), w.row(70)].map((r) => r.id);
    const p = scripted({
      [ids[0]!]: { result: 'rejected', asset: null, reason: 'invalid_image' },
      [ids[1]!]: { result: 'skipped', asset: null, reason: 'in_progress' },
      [ids[2]!]: { result: 'pending', asset: null, reason: 'verification_failed' },
    });
    const r = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: p.processor, now: w.clock.now }, { dryRun: false });
    assert.equal(r.error, null);
    assert.deepEqual(r.retry, { candidates: 4, attempted: 4, ready: 1, rejected: 1, stillPending: 1, skipped: 1 });
    assert.ok(r.rows && r.orphans, 'phases 1 and 2 still run');
    const ops = w.fc.calls.map((c) => c.op);
    assert.ok(ops.indexOf('listRetryable') < ops.indexOf('listStale'), 'retry runs first');
  });

  it('a transient database or storage outcome stops the whole run (nothing further attempted, other phases not run)', async () => {
    for (const reason of ['database_unavailable', 'storage_unavailable'] as const) {
      const w = world();
      const ids = [w.row(100), w.row(90)].map((r) => r.id);
      const p = scripted({ [ids[0]!]: { result: 'pending', asset: null, reason } });
      const r = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: p.processor, now: w.clock.now }, { dryRun: false });
      assert.equal(r.error, reason);
      assert.deepEqual(p.calls, [ids[0]]);
      assert.equal(r.rows, null);
      assert.equal(r.orphans, null);
    }
  });

  it('a failing retry listing is database_unavailable; a processor that throws is unexpected; neither is thrown to the caller', async () => {
    const w = world();
    w.fc.faults.failRetryList = true;
    assert.equal((await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: scripted().processor }, { dryRun: false })).error, 'database_unavailable');
    const w2 = world();
    const r = w2.row(30);
    const res = await runAssetCleanup({ repo: w2.fc.repo, storage: w2.storage, processor: scripted({ [r.id]: 'throw' }).processor, now: w2.clock.now }, { dryRun: false });
    assert.equal(res.error, 'unexpected');
  });

  it('the report and the log carry counts only (no asset id, no key)', async () => {
    const w = world();
    w.row(30);
    const logs: unknown[] = [];
    const r = await runAssetCleanup({ repo: w.fc.repo, storage: w.storage, processor: scripted().processor, now: w.clock.now, logger: { info: (o) => void logs.push(o), warn: (o) => void logs.push(o) } }, { dryRun: false });
    const text = JSON.stringify(r) + JSON.stringify(logs);
    for (const s of ['a0000000', 'd0000000', 'incoming']) assert.ok(!text.includes(s), s);
    assert.deepEqual((logs[0] as Record<string, unknown>)['retry'], r.retry);
  });

  it('SQL: pending only, a window on the DATABASE clock, oldest first, bounded', () => {
    const s = buildListRetryable({ minAgeSeconds: 900, maxAgeSeconds: 86400, limit: 20 });
    assert.match(s.text, /WHERE a\.status = 'pending'\s+AND a\.created_at < now\(\) - make_interval\(secs => \$1::double precision\)\s+AND a\.created_at >= now\(\) - make_interval\(secs => \$2::double precision\)\s+ORDER BY a\.created_at, a\.id\s+LIMIT \$3::int$/);
    assert.deepEqual(s.values, [900, 86400, 20]);
    assert.ok(!/SELECT \*|storage_key|thumb_key/.test(s.text), 'ids only');
  });
});

// ------------------------------------------------------------------------------------------------------------------------------
/** A CleanupRepository over the SAME rows as the asset store used by the real upload service and processor (mirrors the SQL). */
function cleanupOver(fa: ReturnType<typeof makeFakeAssetStore>, now: () => Date): CleanupRepository {
  const rows = () => fa.rows() as ProcessedFakeAsset[];
  const age = (r: ProcessedFakeAsset) => now().getTime() - r.createdAt.getTime();
  return {
    async listStale(i) {
      return rows()
        .filter((r) => (r.status === 'pending' || r.status === 'rejected') && age(r) > i.olderThanSeconds * 1000 && (i.afterId === null || r.id > i.afterId))
        .sort((a, b) => (a.id < b.id ? -1 : 1))
        .slice(0, i.limit)
        .map((r) => ({ id: r.id, status: r.status, storageKey: r.storageKey }));
    },
    async deleteStale(i) {
      const k = rows().findIndex((r) => r.id === i.id && (r.status === 'pending' || r.status === 'rejected') && r.storageKey === i.storageKey && age(r) > i.olderThanSeconds * 1000);
      if (k === -1) return false;
      fa.rows().splice(k, 1);
      return true;
    },
    async findReferencedKeys(keys) {
      return new Set(rows().flatMap((r) => [r.storageKey, r.thumbKey ?? null]).filter((k): k is string => k !== null && keys.includes(k)));
    },
    async listRetryable(i) {
      return rows()
        .filter((r) => r.status === 'pending' && age(r) > i.minAgeSeconds * 1000 && age(r) <= i.maxAgeSeconds * 1000)
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
        .slice(0, i.limit)
        .map((r) => r.id);
    },
  };
}

function e2e() {
  let t = T0;
  const now = () => new Date(t);
  const fa = makeFakeAssetStore({ now });
  fa.addUser(M.id);
  const fp = makeFakeProcessingRepo(fa);
  const mem = createMemoryStorage({ now });
  const faults: { put: RegExp | null; get: RegExp | null } = { put: null, get: null };
  const deletes: string[] = [];
  const storage: ListableStorage = {
    kind: 'memory',
    async put(k, b, o) {
      if (faults.put?.test(k)) throw new StorageError('unavailable', 503);
      return mem.put(k, b, o);
    },
    async get(k) {
      if (faults.get?.test(k)) throw new StorageError('unavailable', 503);
      return mem.get(k);
    },
    exists: (k) => mem.exists(k),
    delete: async (k) => (deletes.push(k), mem.delete(k)),
    list: (p, o) => mem.list(p, o),
  };
  const codec = createFakeCodec().codec;
  const processor = createAssetProcessor({ repo: fp.repo, storage, codec });
  const svc = createAssetService({ store: fa.store, storage, processor });
  const repo = cleanupOver(fa, now);
  const cleanup = (opts: Parameters<typeof runAssetCleanup>[1] = {}) => runAssetCleanup({ repo, storage, processor, now }, { dryRun: false, ...opts });
  return { fa, fp, mem, faults, deletes, processor, svc, cleanup, advance: (ms: number) => (t += ms) };
}

describe('retry end to end (real upload service and processor)', () => {
  it('a transient storage failure during processing leaves the upload pending; a later run makes it ready, and later runs keep it', async () => {
    const s = e2e();
    s.faults.put = /^processed\//;
    const a = await s.svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: PHOTO });
    assert.equal(a.status, 'pending', 'the upload succeeded, processing did not');
    const original = s.fa.rows()[0]!.storageKey!;
    assert.ok(await s.mem.exists(original));
    s.faults.put = null;

    // Too early: the upload's own attempt might still be running.
    s.advance(5 * MIN);
    assert.equal((await s.cleanup()).retry!.candidates, 0);

    s.advance(15 * MIN);
    const r = await s.cleanup();
    assert.equal(r.error, null);
    assert.deepEqual(r.retry, { candidates: 1, attempted: 1, ready: 1, rejected: 0, stillPending: 0, skipped: 0 });
    const row = s.fp.row(a.id)!;
    assert.equal(row.status, 'ready');
    const keys = derivedKeys(original)!;
    for (const k of [keys.main, keys.thumb]) assert.ok(inspectWebp((await s.mem.get(k))!.body), k);
    assert.equal(await s.mem.exists(original), false, 'the original is removed once ready');

    // Much later: phases 1 and 2 never touch a ready asset or its objects; the retry phase has nothing to do.
    s.advance(100 * H);
    s.deletes.length = 0;
    const later = await s.cleanup();
    assert.equal(later.error, null);
    assert.equal(later.retry!.candidates, 0);
    assert.deepEqual(s.deletes, []);
    assert.equal(s.fp.row(a.id)!.status, 'ready');
    for (const k of [keys.main, keys.thumb]) assert.ok(await s.mem.exists(k));
  });

  it('while storage is still failing, the run stops with storage_unavailable and the asset stays pending (retried next time)', async () => {
    const s = e2e();
    s.faults.get = /^incoming\//;
    const a = await s.svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: PHOTO });
    assert.equal(a.status, 'pending');
    s.advance(20 * MIN);
    const r = await s.cleanup();
    assert.equal(r.error, 'storage_unavailable');
    assert.equal(s.fp.row(a.id)!.status, 'pending');
    assert.ok(await s.mem.exists(s.fa.rows()[0]!.storageKey!), 'nothing was deleted');
    s.faults.get = null;
    assert.equal((await s.cleanup()).retry!.ready, 1);
  });

  it('repeat-safe: two concurrent runs and a re-run process the asset once; outputs stay intact', async () => {
    const s = e2e();
    s.faults.put = /^processed\//;
    const a = await s.svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: PHOTO });
    s.faults.put = null;
    s.advance(20 * MIN);
    const [r1, r2] = await Promise.all([s.cleanup({ rows: false, orphans: false }), s.cleanup({ rows: false, orphans: false })]);
    assert.equal(r1.retry!.ready + r2.retry!.ready, 1);
    assert.equal(r1.retry!.skipped + r2.retry!.skipped, 1);
    const r3 = await s.cleanup({ rows: false, orphans: false });
    assert.equal(r3.retry!.candidates, 0);
    const keys = derivedKeys(s.fp.row(a.id)!.storageKey!.replace(/^processed\/(\w+)\/(.+)\.webp$/, 'incoming/$1/$2'))!;
    for (const k of [keys.main, keys.thumb]) assert.ok(inspectWebp((await s.mem.get(k))!.body), k);
  });

  it('an upload whose original never reached storage (crash, failed compensation) is rejected by the retry, then removed when stale', async () => {
    const s = e2e();
    s.faults.put = /^incoming\//;
    // The upload's compensation also fails to delete the row? Simulate the crash case directly: a pending row without its object.
    await assert.rejects(s.svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: PHOTO }));
    s.faults.put = null;
    const crashed = s.fa.addAsset({ ownerId: M.id, storageKey: `incoming/car_image/${u(77)}` });
    s.advance(20 * MIN);
    const r = await s.cleanup();
    assert.equal(r.retry!.rejected, 1);
    assert.equal(s.fp.row(crashed.id)!.status, 'rejected');
    s.advance(25 * H);
    const later = await s.cleanup();
    assert.equal(later.rows!.deleted, 1);
    assert.equal(s.fa.rows().length, 0);
  });
});

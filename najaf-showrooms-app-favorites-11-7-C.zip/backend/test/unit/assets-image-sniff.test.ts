// Phase 11.6.2: image detection from bytes. Real encoder output (PIL) is accepted with the right dimensions; everything else,
// including hand-crafted edge cases and thousands of random/mutated inputs, is refused without ever throwing.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { crc32 } from 'node:zlib';
import { sniffImage } from '../../src/assets/image-sniff.ts';

const FIX = join(import.meta.dirname, '..', 'fixtures', 'images');
const file = (name: string) => new Uint8Array(readFileSync(join(FIX, name)));

function pngWith(fields: { w?: number; h?: number; depth?: number; colour?: number; interlace?: number; badCrc?: boolean }): Uint8Array {
  const ihdr = Buffer.alloc(17);
  ihdr.write('IHDR', 0, 'ascii');
  ihdr.writeUInt32BE(fields.w ?? 4, 4);
  ihdr.writeUInt32BE(fields.h ?? 4, 8);
  ihdr[12] = fields.depth ?? 8;
  ihdr[13] = fields.colour ?? 2;
  ihdr[16] = fields.interlace ?? 0;
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE((crc32(ihdr) ^ (fields.badCrc ? 1 : 0)) >>> 0);
  return new Uint8Array(Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13]), ihdr, crc, Buffer.from([0, 0, 0, 0, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82])]));
}
/** A minimal JPEG: SOI, one SOFn segment, EOI. */
function jpegWith(fields: { sof?: number; w?: number; h?: number; comps?: number; len?: number }): Uint8Array {
  const comps = fields.comps ?? 3;
  const len = fields.len ?? 8 + 3 * comps;
  const seg = [0xff, fields.sof ?? 0xc0, len >> 8, len & 0xff, 8, (fields.h ?? 4) >> 8, (fields.h ?? 4) & 0xff, (fields.w ?? 4) >> 8, (fields.w ?? 4) & 0xff, comps, ...new Array(3 * comps).fill(1)];
  return new Uint8Array([0xff, 0xd8, ...seg, 0xff, 0xd9]);
}
function riff(chunk: string, data: number[]): Uint8Array {
  const body = [...Buffer.from('WEBP'), ...Buffer.from(chunk), data.length & 0xff, (data.length >> 8) & 0xff, 0, 0, ...data];
  const size = body.length;
  return new Uint8Array([...Buffer.from('RIFF'), size & 0xff, (size >> 8) & 0xff, 0, 0, ...body]);
}

describe('image sniffing: real encoder output', () => {
  it('detects every fixture produced by PIL with its exact size, and refuses GIF, BMP, TIFF and SVG', () => {
    const expected: Record<string, [string, number, number] | null> = {
      'baseline-3x2.jpg': ['image/jpeg', 3, 2], 'progressive-exif-5x4.jpg': ['image/jpeg', 5, 4], 'rgba-7x3.png': ['image/png', 7, 3],
      'gray16-6x2.png': ['image/png', 6, 2], 'lossy-9x6.webp': ['image/webp', 9, 6], 'lossless-11x5.webp': ['image/webp', 11, 5],
      'alpha-13x7.webp': ['image/webp', 13, 7], 'refused-4x4.gif': null, 'refused-4x4.bmp': null, 'refused-4x4.tiff': null, 'refused.svg': null,
    };
    assert.deepEqual(readdirSync(FIX).sort(), Object.keys(expected).sort());
    for (const [name, want] of Object.entries(expected)) {
      const got = sniffImage(file(name));
      assert.deepEqual(got && [got.type, got.width, got.height], want, name);
    }
  });
});

describe('image sniffing: hand-crafted edge cases', () => {
  it('PNG: valid depth/colour pairs only, interlace 0/1, non-zero size, valid CRC, IEND last', () => {
    assert.deepEqual(sniffImage(pngWith({})), { type: 'image/png', width: 4, height: 4 });
    assert.ok(sniffImage(pngWith({ interlace: 1 })));
    assert.ok(sniffImage(pngWith({ colour: 3, depth: 1 })));
    for (const f of [{ depth: 3 }, { colour: 2, depth: 4 }, { colour: 5 }, { colour: 6, depth: 1 }, { interlace: 2 }, { w: 0 }, { h: 0 }, { w: 0x80000000 }, { badCrc: true }]) assert.equal(sniffImage(pngWith(f)), null, JSON.stringify(f));
  });

  it('JPEG: only baseline, extended and progressive frames; sane component count and segment length; EOI required', () => {
    assert.deepEqual(sniffImage(jpegWith({})), { type: 'image/jpeg', width: 4, height: 4 });
    assert.ok(sniffImage(jpegWith({ sof: 0xc1 })));
    assert.ok(sniffImage(jpegWith({ sof: 0xc2, comps: 1 })));
    for (const f of [{ sof: 0xc3 }, { sof: 0xc9 }, { sof: 0xcb }, { sof: 0xc5 }, { w: 0 }, { h: 0 }, { comps: 2 }, { comps: 5 }, { len: 100 }, { len: 1 }, { len: 12 }]) assert.equal(sniffImage(jpegWith(f)), null, JSON.stringify(f));
    assert.equal(sniffImage(new Uint8Array([0xff, 0xd8, 0xff, 0xda, 0, 2, 0xff, 0xd9])), null, 'scan before any frame');
    assert.equal(sniffImage(new Uint8Array([0xff, 0xd8, 0xff, 0xd9])), null, 'empty image');
    const sof0 = [...jpegWith({})].slice(2, -2); // the SOF0 segment alone
    assert.equal(sniffImage(new Uint8Array([0xff, 0xd8, 0xff, 0xda, 0, 2, ...sof0, 0xff, 0xd9])), null, 'a scan before the frame, even if a frame follows');
    const sof9 = [...jpegWith({ sof: 0xc9 })].slice(2, -2);
    assert.equal(sniffImage(new Uint8Array([0xff, 0xd8, ...sof9, ...sof0, 0xff, 0xd9])), null, 'an arithmetic-coded frame is refused even if a baseline frame follows');
  });

  it('WebP: exact RIFF size, VP8 key frames with the start code, VP8L version 0, still VP8X only', () => {
    const vp8 = (tag: number) => riff('VP8 ', [tag, 0, 0, 0x9d, 0x01, 0x2a, 20, 0, 10, 0]);
    assert.deepEqual(sniffImage(vp8(0x10)), { type: 'image/webp', width: 20, height: 10 });
    assert.equal(sniffImage(vp8(0x11)), null, 'not a key frame');
    assert.equal(sniffImage(riff('VP8 ', [0, 0, 0, 0x9d, 0x01, 0x2b, 20, 0, 10, 0])), null, 'bad start code');
    const bits = (w: number, h: number, v = 0) => { const x = ((w - 1) | ((h - 1) << 14) | (v << 29)) >>> 0; return [x & 255, (x >>> 8) & 255, (x >>> 16) & 255, x >>> 24]; };
    assert.deepEqual(sniffImage(riff('VP8L', [0x2f, ...bits(300, 200), 0, 0, 0, 0, 0])), { type: 'image/webp', width: 300, height: 200 });
    assert.equal(sniffImage(riff('VP8L', [0x2f, ...bits(300, 200, 1), 0, 0, 0, 0, 0])), null, 'version 1');
    assert.equal(sniffImage(riff('VP8L', [0x2e, ...bits(300, 200), 0, 0, 0, 0, 0])), null, 'bad signature');
    const vp8x = (flags: number) => riff('VP8X', [flags, 0, 0, 0, 99, 0, 0, 49, 0, 0]);
    assert.deepEqual(sniffImage(vp8x(0x10)), { type: 'image/webp', width: 100, height: 50 });
    assert.equal(sniffImage(vp8x(0x02)), null, 'animated');
    const wrongSize = vp8x(0);
    wrongSize[4] = (wrongSize[4]! + 1) & 0xff;
    assert.equal(sniffImage(wrongSize), null, 'RIFF size does not match');
    assert.equal(sniffImage(riff('VP8 ', [0x10, 0, 0, 0x9d])), null, 'chunk too short');
    assert.equal(sniffImage(riff('ALPH', [0, 0, 0, 0, 0, 0, 0, 0, 0, 0])), null, 'unknown first chunk');
  });

  it('refuses non-bytes and empty input', () => {
    for (const v of [new Uint8Array(0), 'PNG' as never, null as never, undefined as never, [0xff, 0xd8] as never]) assert.equal(sniffImage(v), null);
  });
});

describe('image sniffing: robustness', () => {
  it('never throws on random bytes or on random mutations and truncations of real images; any result has sane dimensions', () => {
    let seed = 0x2f6e2b1;
    const rnd = () => ((seed = (seed * 1103515245 + 12345) >>> 0) >>> 8) & 0xff;
    const bases = ['baseline-3x2.jpg', 'progressive-exif-5x4.jpg', 'rgba-7x3.png', 'lossy-9x6.webp', 'lossless-11x5.webp', 'alpha-13x7.webp'].map(file);
    const check = (b: Uint8Array) => {
      const r = sniffImage(b);
      if (r) assert.ok(r.width >= 1 && r.height >= 1 && Number.isSafeInteger(r.width) && Number.isSafeInteger(r.height));
    };
    for (let i = 0; i < 3000; i++) check(new Uint8Array(Array.from({ length: rnd() % 64 }, rnd)));
    for (const base of bases) {
      for (let i = 0; i < 600; i++) {
        const b = new Uint8Array(base);
        for (let m = 0; m < 1 + (rnd() % 4); m++) b[rnd() * 4 % b.length] = rnd();
        check(b);
        check(b.slice(0, rnd() * 3 % b.length));
      }
    }
  });
});

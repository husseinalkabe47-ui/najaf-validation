// Phase 11.6.3: processing orchestration (processing-service.ts) and its use right after upload: states, storage, verification,
// partial failures, concurrency and logs. Storage is the real in-memory provider (with fault injection), the database the
// in-memory store (CAS + CHECK backstops), the codec either scripted or real (Pillow).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Actor } from '../../src/authz/index.ts';
import { MAX_CONCURRENT_PROCESSING, createAssetProcessor, derivedKeys } from '../../src/assets/processing-service.ts';
import { createAssetService } from '../../src/assets/service.ts';
import { inspectWebp } from '../../src/assets/webp-inspect.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { StorageProvider } from '../../src/storage/index.ts';
import { makeFakeAssetStore } from '../helpers/fake-assets.ts';
import { createFakeCodec } from '../helpers/fake-codec.ts';
import type { FakeCodecBehaviour } from '../helpers/fake-codec.ts';
import { makeFakeProcessingRepo } from '../helpers/fake-processing.ts';
import { createPilCodec, pilAvailable } from '../helpers/pil-codec.ts';

const M: Actor = Object.freeze({ id: '1', role: 'member' });
const M2: Actor = Object.freeze({ id: '2', role: 'member' });
const JPG = new Uint8Array(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'images', 'baseline-3x2.jpg')));
const EXIF_JPG = new Uint8Array(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'processing', 'exif-gps-orient6-64x32.jpg')));
const PHOTO = new Uint8Array(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'processing', 'photo-2400x1600.jpg')));
const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/;

type Faulty = StorageProvider & { mem: ReturnType<typeof createMemoryStorage>; failPut: RegExp | null; failGet: RegExp | null; corruptGet: RegExp | null; failDelete: RegExp | null; ops: string[] };
function faulty(): Faulty {
  const mem = createMemoryStorage();
  const s: Faulty = {
    kind: 'memory', mem, failPut: null, failGet: null, corruptGet: null, failDelete: null, ops: [],
    async put(k, b, o) {
      s.ops.push(`put ${k}`);
      if (s.failPut?.test(k)) throw new StorageError('unavailable', 500);
      await mem.put(k, b, o);
    },
    async get(k) {
      s.ops.push(`get ${k}`);
      if (s.failGet?.test(k)) throw new StorageError('unavailable', 503);
      const o = await mem.get(k);
      if (o && s.corruptGet?.test(k)) o.body[o.body.length - 1] ^= 0xff;
      return o;
    },
    exists: (k) => mem.exists(k),
    async delete(k) {
      s.ops.push(`delete ${k}`);
      if (s.failDelete?.test(k)) throw new StorageError('unavailable', 503);
      await mem.delete(k);
    },
  };
  return s;
}

function setup(codecBehaviour: FakeCodecBehaviour = {}, opts: { realCodec?: boolean; withProcessor?: boolean } = {}) {
  const fa = makeFakeAssetStore();
  for (const a of [M, M2]) fa.addUser(a.id);
  const fp = makeFakeProcessingRepo(fa);
  const storage = faulty();
  const fake = createFakeCodec(codecBehaviour);
  const logs: Array<Record<string, unknown>> = [];
  const logger = { info: (o: Record<string, unknown>) => void logs.push({ level: 'info', ...o }), warn: (o: Record<string, unknown>) => void logs.push({ level: 'warn', ...o }) };
  const processor = createAssetProcessor({ repo: fp.repo, storage, codec: opts.realCodec ? createPilCodec() : fake.codec, logger });
  const plain = createAssetService({ store: fa.store, storage, logger });
  const withProc = createAssetService({ store: fa.store, storage, logger, processor });
  const upload = (actor: Actor, body = JPG, svc = plain) => svc.upload(actor, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body });
  return { fa, fp, storage, fake, processor, plain, withProc, upload, logs };
}
const keysOf = (row: { storageKey: string | null }) => derivedKeys(row.storageKey!.replace(/^processed\/(\w+)\/(.+)\.webp$/, 'incoming/$1/$2'))!;

describe('processing: success', () => {
  it('pending -> ready: main and thumbnail stored and verified, row filled as the ready CHECK requires, original deleted', async () => {
    const s = setup();
    const a = await s.upload(M, PHOTO);
    const original = s.fa.rows()[0]!.storageKey!;
    const out = await s.processor.process(a.id, M.id);
    assert.equal(out.result, 'ready');
    assert.deepEqual(Object.keys(out.asset!).sort(), ['bytes', 'createdAt', 'height', 'id', 'kind', 'status', 'width']);
    const row = s.fp.row(a.id)!;
    const keys = derivedKeys(original)!;
    assert.deepEqual([row.status, row.storageKey, row.thumbKey, row.mime], ['ready', keys.main, keys.thumb, 'image/webp']);
    assert.match(keys.main, new RegExp(`^processed/car_image/${UUID.source}\\.webp$`));
    assert.match(keys.thumb, new RegExp(`^thumbs/car_image/${UUID.source}\\.webp$`));
    const main = (await s.storage.mem.get(keys.main))!;
    const thumb = (await s.storage.mem.get(keys.thumb))!;
    assert.notDeepEqual(Buffer.from(main.body), Buffer.from(thumb.body));
    assert.equal(row.sha256, createHash('sha256').update(main.body).digest('hex'), 'the row describes the MAIN image');
    assert.deepEqual([row.width, row.height], [1600, 1067]);
    assert.equal(row.bytes, main.body.byteLength);
    assert.equal(main.contentType, 'image/webp');
    assert.ok(await s.storage.mem.exists(keys.thumb));
    assert.equal(await s.storage.mem.exists(original), false, 'the original is deleted once the asset is ready');
    assert.ok(s.storage.ops.indexOf(`get ${keys.main}`) > s.storage.ops.indexOf(`put ${keys.thumb}`), 'both objects are read back before the row changes');
  });

  it('the derived keys share the original UUID, so every object of an asset is findable from its row', () => {
    const k = derivedKeys('incoming/showroom_cover/0f8fad5b-d9cb-469f-a165-70867728950e')!;
    assert.deepEqual(k, { original: 'incoming/showroom_cover/0f8fad5b-d9cb-469f-a165-70867728950e', main: 'processed/showroom_cover/0f8fad5b-d9cb-469f-a165-70867728950e.webp', thumb: 'thumbs/showroom_cover/0f8fad5b-d9cb-469f-a165-70867728950e.webp' });
    for (const bad of ['incoming/avatar/0f8fad5b-d9cb-469f-a165-70867728950e', 'incoming/car_image/x', 'processed/car_image/0f8fad5b-d9cb-469f-a165-70867728950e.webp', '../incoming/car_image/0f8fad5b-d9cb-469f-a165-70867728950e']) assert.equal(derivedKeys(bad), null, bad);
  });

  it('upload with processing answers the final state (ready) and the response carries no key or checksum', async () => {
    const s = setup();
    const a = await s.upload(M, JPG, s.withProc);
    assert.equal(a.status, 'ready');
    const row = s.fp.row(a.id)!;
    const text = JSON.stringify(a);
    for (const secret of [row.storageKey!, row.thumbKey!, row.sha256!, 'incoming', 'processed', 'thumbs']) assert.ok(!text.includes(secret));
  });

  it('logs carry ids, outcomes and reason codes only, never a storage key', async () => {
    const s = setup();
    await s.upload(M, JPG, s.withProc);
    const s2 = setup({ renderError: 'invalid_image' });
    await s2.upload(M, JPG, s2.withProc);
    for (const l of [...s.logs, ...s2.logs]) assert.ok(!/incoming|processed\/|thumbs\//.test(JSON.stringify(l)), JSON.stringify(l));
    assert.ok(s.logs.some((l) => l['event'] === 'assets.processed' && l['result'] === 'ready'));
    assert.ok(s2.logs.some((l) => l['event'] === 'assets.processed' && l['result'] === 'rejected' && l['reason'] === 'invalid_image'));
  });
});

describe('processing: bad images are rejected and cleaned up', () => {
  it('a codec rejection marks the asset rejected with a reason and deletes every object of the asset', async () => {
    for (const code of ['invalid_image', 'unsupported', 'too_large', 'timeout'] as const) {
      const s = setup({ renderError: code });
      const a = await s.upload(M);
      const keys = derivedKeys(s.fa.rows()[0]!.storageKey!)!;
      const out = await s.processor.process(a.id);
      assert.deepEqual([out.result, out.reason, out.asset?.status], ['rejected', code, 'rejected'], code);
      const row = s.fp.row(a.id)!;
      assert.equal(row.rejectReason, code);
      assert.equal(row.storageKey, keys.original, 'the row keeps the original key (whatever is left stays findable)');
      assert.equal(s.storage.mem.size(), 0, `${code}: nothing left in storage`);
    }
  });

  it('an original that changed in storage (size or checksum) or disappeared is rejected', async () => {
    const s = setup();
    const a = await s.upload(M);
    const key = s.fa.rows()[0]!.storageKey!;
    await s.storage.mem.put(key, new Uint8Array([...JPG.slice(0, -2), 0xff, 0xd9]).map((v, i) => (i === 300 ? v ^ 1 : v)), { contentType: 'image/jpeg' });
    assert.deepEqual([(await s.processor.process(a.id)).reason, s.fp.row(a.id)!.status], ['integrity', 'rejected']);
    const t = setup();
    const b = await t.upload(M);
    await t.storage.mem.delete(t.fa.rows()[0]!.storageKey!);
    assert.deepEqual([(await t.processor.process(b.id)).reason, t.fp.row(b.id)!.status], ['missing_original', 'rejected']);
  });

  it('output that keeps metadata never reaches storage; the asset is rejected', async () => {
    const s = setup({ addChunk: 'EXIF' });
    const a = await s.upload(M);
    const out = await s.processor.process(a.id);
    assert.deepEqual([out.result, out.reason], ['rejected', 'output_invalid']);
    assert.ok(!s.storage.ops.some((o) => o.startsWith('put processed/') || o.startsWith('put thumbs/')));
  });

  it('with the upload: a rejected image answers status "rejected" (the upload itself succeeded)', async () => {
    const s = setup({ probeError: 'invalid_image' });
    const a = await s.upload(M, JPG, s.withProc);
    assert.equal(a.status, 'rejected');
  });
});

describe('processing: transient failures keep the asset pending (never public) and retryable', () => {
  it('a failed write of the main image or the thumbnail: pending, outputs removed, original kept; a retry succeeds', async () => {
    for (const which of [/^processed\//, /^thumbs\//]) {
      const s = setup();
      const a = await s.upload(M);
      const keys = derivedKeys(s.fa.rows()[0]!.storageKey!)!;
      s.storage.failPut = which;
      const out = await s.processor.process(a.id);
      assert.deepEqual([out.result, out.reason, s.fp.row(a.id)!.status], ['pending', 'storage_unavailable', 'pending']);
      assert.equal(await s.storage.mem.exists(keys.main), false);
      assert.equal(await s.storage.mem.exists(keys.thumb), false);
      assert.ok(await s.storage.mem.exists(keys.original));
      s.storage.failPut = null;
      assert.equal((await s.processor.process(a.id)).result, 'ready');
    }
  });

  it('a stored object that does not read back identically is not used: pending, outputs removed', async () => {
    for (const which of [/^processed\//, /^thumbs\//]) {
      const s = setup();
      const a = await s.upload(M);
      s.storage.corruptGet = which;
      const out = await s.processor.process(a.id);
      assert.deepEqual([out.result, out.reason, s.fp.row(a.id)!.status], ['pending', 'verification_failed', 'pending']);
      assert.equal(s.storage.mem.keys().filter((k) => !k.startsWith('incoming/')).length, 0);
    }
  });

  it('storage unavailable while reading the original, or the database unavailable: pending, nothing written', async () => {
    const s = setup();
    const a = await s.upload(M);
    s.storage.failGet = /^incoming\//;
    assert.deepEqual([(await s.processor.process(a.id)).result, s.fp.row(a.id)!.status], ['pending', 'pending']);
    s.storage.failGet = null;
    s.fp.faults.failFind = true;
    assert.equal((await s.processor.process(a.id)).result, 'pending');
    assert.equal(s.storage.mem.keys().length, 1);
  });

  it('marking ready fails: outputs removed unless the row turns out to point to them (update committed before the error)', async () => {
    const s = setup();
    const a = await s.upload(M);
    const keys = derivedKeys(s.fa.rows()[0]!.storageKey!)!;
    s.fp.faults.failMarkReady = 'throw';
    assert.deepEqual([(await s.processor.process(a.id)).result, s.fp.row(a.id)!.status], ['pending', 'pending']);
    assert.equal(await s.storage.mem.exists(keys.main), false);
    s.fp.faults.failMarkReady = 'throw_after_commit';
    const out = await s.processor.process(a.id);
    assert.deepEqual([out.result, out.reason, s.fp.row(a.id)!.status], ['ready', 'confirmed_after_error', 'ready']);
    assert.ok(await s.storage.mem.exists(keys.main), 'objects in use are never deleted');
    assert.ok(await s.storage.mem.exists(keys.thumb));
  });

  it('the row vanished before it could be marked ready: outputs removed, nothing else touched', async () => {
    const s = setup();
    const a = await s.upload(M);
    const keys = derivedKeys(s.fa.rows()[0]!.storageKey!)!;
    s.fp.faults.deleteRowBeforeMarkReady = true;
    const out = await s.processor.process(a.id);
    assert.deepEqual([out.result, out.reason], ['skipped', 'changed']);
    assert.equal(await s.storage.mem.exists(keys.main), false);
    assert.equal(await s.storage.mem.exists(keys.thumb), false);
  });

  it('another processor finished the same asset first: the lost compare-and-swap never deletes the objects the row now uses', async () => {
    const s = setup();
    const a = await s.upload(M);
    const keys = derivedKeys(s.fa.rows()[0]!.storageKey!)!;
    s.fp.faults.otherProcessorWins = true;
    const out = await s.processor.process(a.id);
    assert.deepEqual([out.result, out.reason], ['skipped', 'changed']);
    assert.ok(await s.storage.mem.exists(keys.main), 'in use by the ready row');
    assert.ok(await s.storage.mem.exists(keys.thumb));
  });

  it('marking rejected fails: the asset stays pending (not public) and its outputs are removed', async () => {
    const s = setup({ renderError: 'invalid_image' });
    const a = await s.upload(M);
    s.fp.faults.failMarkRejected = true;
    assert.deepEqual([(await s.processor.process(a.id)).result, s.fp.row(a.id)!.status], ['pending', 'pending']);
  });

  it('the original cannot be deleted after ready: the asset is still ready (the original stays findable from the key)', async () => {
    const s = setup();
    const a = await s.upload(M);
    const keys = derivedKeys(s.fa.rows()[0]!.storageKey!)!;
    s.storage.failDelete = /^incoming\//;
    assert.equal((await s.processor.process(a.id)).result, 'ready');
    assert.ok(await s.storage.mem.exists(keys.original));
    assert.deepEqual(keysOf(s.fp.row(a.id)!), keys);
    assert.ok(s.logs.some((l) => l['result'] === 'ready' && l['originalDeleted'] === false));
  });

  it('with the upload: a processing failure leaves the answer "pending"; a processor that throws does not fail the upload', async () => {
    const s = setup();
    s.storage.failPut = /^processed\//;
    assert.equal((await s.upload(M, JPG, s.withProc)).status, 'pending');
    const fa = makeFakeAssetStore();
    fa.addUser(M.id);
    const svc = createAssetService({ store: fa.store, storage: createMemoryStorage(), processor: { process: async () => Promise.reject(new Error('boom')) } });
    assert.equal((await svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: JPG })).status, 'pending');
  });
});

describe('processing: ownership, state and concurrency', () => {
  it('another owner, an unknown asset, a processed asset and a foreign key format are skipped and nothing is touched', async () => {
    const s = setup();
    const a = await s.upload(M);
    const opsBefore = s.storage.ops.length;
    assert.deepEqual(await s.processor.process(a.id, M2.id), { result: 'skipped', asset: null, reason: 'not_found' });
    assert.equal((await s.processor.process('a0000000-0000-4000-8000-999999999999')).reason, 'not_found');
    const odd = s.fa.addAsset({ ownerId: M.id, storageKey: 'incoming/car_image/legacy-1' });
    assert.equal((await s.processor.process(odd.id)).reason, 'unexpected_key');
    const mismatch = s.fa.addAsset({ ownerId: M.id, kind: 'showroom_cover', storageKey: 'incoming/car_image/0f8fad5b-d9cb-469f-a165-70867728950e' });
    assert.equal((await s.processor.process(mismatch.id)).reason, 'unexpected_key');
    assert.equal(s.storage.ops.length, opsBefore, 'no storage access for skipped assets');
    await s.processor.process(a.id);
    assert.equal((await s.processor.process(a.id)).reason, 'not_pending');
  });

  it(`at most ${MAX_CONCURRENT_PROCESSING} images are processed at once; the same asset is never processed twice concurrently`, async () => {
    const s = setup();
    const ids: string[] = [];
    for (let i = 0; i < 6; i++) ids.push((await s.upload(M)).id);
    const outs = await Promise.all([...ids.map((id) => s.processor.process(id)), s.processor.process(ids[0]!)]);
    assert.ok(s.fake.maxActive() <= MAX_CONCURRENT_PROCESSING, String(s.fake.maxActive()));
    assert.equal(outs.filter((o) => o.result === 'ready').length, 6);
    assert.deepEqual(outs.at(-1), { result: 'skipped', asset: null, reason: 'in_progress' });
  });
});

describe('processing end to end with a real codec (Pillow)', { skip: pilAvailable ? false : 'python3 with Pillow (WebP) is not available' }, () => {
  it('an EXIF/GPS-tagged JPEG upload becomes a ready asset whose stored objects are clean, oriented WebP; the original is gone', async () => {
    const s = setup({}, { realCodec: true });
    const a = await s.upload(M, EXIF_JPG, s.withProc);
    assert.deepEqual([a.status, a.width, a.height], ['ready', 32, 64]);
    const row = s.fp.row(a.id)!;
    for (const key of [row.storageKey!, row.thumbKey!]) {
      const o = (await s.storage.mem.get(key))!;
      assert.ok(inspectWebp(o.body), key);
      for (const secret of ['SECRETCAM', 'GPS', 'Exif', 'ModelX']) assert.ok(!Buffer.from(o.body).toString('latin1').includes(secret));
    }
    assert.deepEqual(s.storage.mem.keys().filter((k) => k.startsWith('incoming/')), []);
  });
});

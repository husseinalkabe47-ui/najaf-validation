// Phase 11.6.4: image delivery and the showroom cover through the REAL Fastify server (buildServer + inject): the server-wide
// headers combine correctly with the image routes' own caching decision. Needs `fastify` (installed in CI by npm install);
// without it the whole file is SKIPPED visibly, never silently passed.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { createAssetDelivery } from '../../src/assets/delivery.ts';
import { createShowroomCoverService } from '../../src/assets/cover.ts';
import { createMemoryStorage } from '../../src/storage/index.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeDelivery } from '../helpers/fake-delivery.ts';
import { makeFakeCoverStore } from '../helpers/fake-cover.ts';

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let reason: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'silent', NODE_ENV: 'test' });
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };
const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const MAIN = fakeWebp(16, 12, { payload: 40 });
const THUMB = fakeWebp(8, 6, { payload: 20 });
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');

async function server() {
  const clock = makeClock();
  const authStore = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: authStore.store, hasher, accessTokenSecret: SECRET, logger: recordingLogger().logger, now: clock.now });
  const world = makeFakeDelivery();
  const storage = createMemoryStorage();
  const assetDelivery = createAssetDelivery({ repo: world.repo, storage });
  const showroomCover = createShowroomCoverService({ store: makeFakeCoverStore().store });
  const car = world.addCar(true);
  const a = world.addAsset({ ownerId: '7', sha256: sha(MAIN), width: 16, height: 12 });
  await storage.put(a.storageKey!, MAIN, { contentType: 'image/webp' });
  await storage.put(a.thumbKey!, THUMB, { contentType: 'image/webp' });
  world.attach(car.id, a.id, true, 0);
  const app = await buildServer!({ config, db: okDb, auth, assetDelivery, showroomCover });
  return { app, a, car, world };
}

describe('image delivery over the real server', { skip: reason }, () => {
  it('a public image keeps its own caching (public, max-age=300) and gets the server-wide nosniff and request id', async () => {
    const { app, a } = await server();
    const r = await app.inject({ method: 'GET', url: `/v1/public/assets/${a.id}/image` });
    assert.equal(r.statusCode, 200);
    assert.equal(r.headers['content-type'], 'image/webp');
    assert.equal(r.headers['content-length'], String(MAIN.byteLength));
    assert.equal(r.headers['cache-control'], 'public, max-age=300');
    assert.equal(r.headers['x-content-type-options'], 'nosniff');
    assert.equal(r.headers['content-security-policy'], "default-src 'none'; sandbox");
    assert.equal(r.headers['content-disposition'], 'inline');
    assert.equal(r.headers['etag'], `"${sha(MAIN)}"`);
    assert.ok(r.headers['x-request-id']);
    assert.deepEqual([...r.rawPayload], [...MAIN]);
    const t = await app.inject({ method: 'GET', url: `/v1/public/assets/${a.id}/thumb`, headers: { 'if-none-match': `"${sha(MAIN)}-thumb"` } });
    assert.equal(t.statusCode, 304);
    assert.equal(t.headers['cache-control'], 'public, max-age=300');
    assert.equal(t.rawPayload.length, 0);
    await app.close();
  });

  it('everything else keeps no-store: errors of the image routes, discovery JSON, the owner routes, health', async () => {
    const { app, car } = await server();
    const missing = await app.inject({ method: 'GET', url: '/v1/public/assets/c0000000-0000-4000-8000-999999999999/image' });
    assert.equal(missing.statusCode, 404);
    assert.equal(missing.headers['cache-control'], 'no-store');
    assert.equal(missing.json().error.code, 'not_found');
    const list = await app.inject({ method: 'GET', url: `/v1/public/cars/${car.id}/images` });
    assert.equal(list.statusCode, 200);
    assert.equal(list.headers['cache-control'], 'no-store');
    const own = await app.inject({ method: 'GET', url: '/v1/me/assets/c0000000-0000-4000-8000-000000000001/image' });
    assert.equal(own.statusCode, 401);
    assert.equal(own.headers['cache-control'], 'no-store');
    const health = await app.inject({ method: 'GET', url: '/healthz' });
    assert.equal(health.headers['cache-control'], 'no-store');
    await app.close();
  });

  it('a database failure during delivery is the generic 503 of the server error handler (no detail)', async () => {
    const { app, a, world } = await server();
    world.faults.fail = true;
    const r = await app.inject({ method: 'GET', url: `/v1/public/assets/${a.id}/image` });
    assert.equal(r.statusCode, 503);
    assert.equal(r.headers['cache-control'], 'no-store');
    assert.ok(!r.body.includes('08006'));
    await app.close();
  });

  it('the cover routes are registered: PUT refuses text/plain with 415, and anonymous calls are 401', async () => {
    const { app } = await server();
    const plain = await app.inject({ method: 'PUT', url: '/v1/dealer/showroom/cover', headers: { 'content-type': 'text/plain' }, payload: '{}' });
    assert.equal(plain.statusCode, 415);
    const anon = await app.inject({ method: 'GET', url: '/v1/dealer/showroom/cover' });
    assert.equal(anon.statusCode, 401);
    await app.close();
  });

  it('without assetDelivery/showroomCover nothing of this step is registered (storage not configured)', async () => {
    const app = await buildServer!({ config, db: okDb });
    for (const url of ['/v1/public/assets/c0000000-0000-4000-8000-000000000001/image', '/v1/public/cars/1/images', '/v1/dealer/showroom/cover']) {
      assert.equal((await app.inject({ method: 'GET', url })).statusCode, 404, url);
    }
    await app.close();
  });
});

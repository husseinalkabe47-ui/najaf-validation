// Phase 11.6.4: a dealer's showroom cover. The service over the in-memory cover store (which mirrors the database's cover guard),
// the HTTP contract through the real routes and the real authentication service, and SQL/source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { DbError } from '../../src/errors.ts';
import { CoverError, createShowroomCoverService, parseSetCoverInput } from '../../src/assets/cover.ts';
import { COVER_RATE_LIMITS, registerShowroomCoverRoutes, toCoverHttp } from '../../src/assets/cover-routes.ts';
import { FIND_OWN_COVER_ASSET_SQL, FIND_OWN_COVER_SQL, LOCK_OWN_SHOWROOM_SQL, SET_COVER_SQL } from '../../src/assets/cover-repository.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeCoverStore } from '../helpers/fake-cover.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const actor = (id: string, role: Actor['role'] = 'dealer'): Actor => ({ id, role }) as Actor;
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const isCoverErr = (c: string) => (e: unknown) => e instanceof CoverError && e.code === c;

function setup() {
  const fc = makeFakeCoverStore();
  const svc = createShowroomCoverService({ store: fc.store });
  fc.addUser('10');
  const showroom = fc.addShowroom('10');
  return { fc, svc, showroom, D: actor('10') };
}

describe('showroom cover: set', () => {
  it("attaches the dealer's own ready, processed showroom_cover to their own showroom", async () => {
    const { fc, svc, showroom, D } = setup();
    const a = fc.addAsset({ ownerId: '10' });
    assert.deepEqual(await svc.setCover(D, { assetId: a.id.toUpperCase() }), { cover: { assetId: a.id, width: 1600, height: 900 } });
    assert.equal(fc.showrooms()[0]!.coverAssetId, a.id);
    assert.deepEqual(fc.writes, [{ showroomId: showroom.id, assetId: a.id }]);
    assert.deepEqual(fc.calls, ['lockActingUser', 'lockOwnShowroom', 'findOwnAsset', 'setCover']);
  });

  it('setting the current cover again writes nothing; replacing it writes once', async () => {
    const { fc, svc, D } = setup();
    const a = fc.addAsset({ ownerId: '10' });
    const b = fc.addAsset({ ownerId: '10' });
    await svc.setCover(D, { assetId: a.id });
    await svc.setCover(D, { assetId: a.id });
    assert.equal(fc.writes.length, 1);
    await svc.setCover(D, { assetId: b.id });
    assert.deepEqual(fc.writes.map((w) => w.assetId), [a.id, b.id]);
  });

  it("another user's asset (another dealer's, an administrator's, a member's) is the same 404 as an unknown one; nothing changes", async () => {
    const { fc, svc, D } = setup();
    fc.addUser('11');
    fc.addUser('1', 'admin');
    for (const ownerId of ['11', '1', '12']) {
      const a = fc.addAsset({ ownerId });
      await assert.rejects(svc.setCover(D, { assetId: a.id }), isNotFound, ownerId);
    }
    await assert.rejects(svc.setCover(D, { assetId: 'f0000000-0000-4000-8000-999999999999' }), isNotFound);
    assert.equal(fc.writes.length, 0);
    assert.equal(fc.showrooms()[0]!.coverAssetId, null);
  });

  it('only a READY, PROCESSED showroom_cover can be a cover (pending, rejected, car_image, original keys: 409 invalid_state)', async () => {
    const { fc, svc, D } = setup();
    const bad = [
      { status: 'pending' }, { status: 'rejected' }, { kind: 'car_image' },
      { storageKey: 'incoming/showroom_cover/e0000000-0000-4000-8000-000000000001' }, { thumbKey: 'incoming/showroom_cover/e0000000-0000-4000-8000-000000000001' }, { thumbKey: null },
    ];
    for (const fields of bad) {
      const a = fc.addAsset({ ownerId: '10', ...fields });
      await assert.rejects(svc.setCover(D, { assetId: a.id }), isCoverErr('invalid_state'), JSON.stringify(fields));
    }
    assert.equal(fc.writes.length, 0);
  });

  it('a guest, a member, an administrator: 404 before any database access', async () => {
    const { fc, svc } = setup();
    const a = fc.addAsset({ ownerId: '10' });
    for (const who of [null, actor('10', 'member'), actor('1', 'admin')]) {
      await assert.rejects(svc.setCover(who, { assetId: a.id }), isNotFound);
      await assert.rejects(svc.clearCover(who), isNotFound);
      await assert.rejects(svc.getCover(who), isNotFound);
    }
    assert.deepEqual(fc.calls, []);
  });

  it('a dealer without a showroom, or whose account is no longer active, is 404 and nothing changes', async () => {
    const { fc, svc } = setup();
    fc.addUser('20');
    const a = fc.addAsset({ ownerId: '20' });
    await assert.rejects(svc.setCover(actor('20'), { assetId: a.id }), isNotFound);
    fc.addUser('21', 'dealer', 'suspended');
    fc.addShowroom('21');
    const b = fc.addAsset({ ownerId: '21' });
    await assert.rejects(svc.setCover(actor('21'), { assetId: b.id }), isNotFound);
    fc.addUser('22', 'dealer', 'active', true);
    fc.addShowroom('22');
    await assert.rejects(svc.setCover(actor('22'), { assetId: b.id }), isNotFound);
    assert.equal(fc.writes.length, 0);
  });

  it('the owner manages the cover whatever the showroom status (pending, suspended), as the existing policy allows', async () => {
    for (const status of ['pending', 'suspended', 'active']) {
      const fc = makeFakeCoverStore();
      fc.addUser('30');
      fc.addShowroom('30', status);
      const a = fc.addAsset({ ownerId: '30' });
      const svc = createShowroomCoverService({ store: fc.store });
      assert.equal((await svc.setCover(actor('30'), { assetId: a.id })).cover.assetId, a.id, status);
    }
  });

  it('a refusal by the database guard is 409 invalid_state (never a 500 or a detail); other database failures propagate', async () => {
    for (const guard of ['check', 'forbidden'] as const) {
      const { fc, svc, D } = setup();
      const a = fc.addAsset({ ownerId: '10' });
      fc.faults.guard = guard;
      await assert.rejects(svc.setCover(D, { assetId: a.id }), isCoverErr('invalid_state'));
      assert.equal(fc.showrooms()[0]!.coverAssetId, null);
    }
    const { fc, svc, D } = setup();
    const a = fc.addAsset({ ownerId: '10' });
    fc.faults.failSet = true;
    await assert.rejects(svc.setCover(D, { assetId: a.id }), (e: unknown) => e instanceof DbError && e.kind === 'unavailable');
    assert.equal(fc.showrooms()[0]!.coverAssetId, null);
  });

  it('invalid input is 400 with field names and codes only (never the value)', async () => {
    const { fc, svc, D } = setup();
    const cases: Array<[unknown, Array<{ field: string; code: string }>]> = [
      [undefined, [{ field: 'body', code: 'invalid_type' }]],
      [null, [{ field: 'body', code: 'invalid_type' }]],
      [[], [{ field: 'body', code: 'invalid_type' }]],
      ['x', [{ field: 'body', code: 'invalid_type' }]],
      [{}, [{ field: 'assetId', code: 'required' }]],
      [{ assetId: 5 }, [{ field: 'assetId', code: 'invalid_type' }]],
      [{ assetId: 'not-a-uuid<script>' }, [{ field: 'assetId', code: 'invalid_format' }]],
      [{ assetId: 'f0000000-0000-4000-8000-000000000001', showroomId: '1' }, [{ field: 'showroomId', code: 'unknown_field' }]],
      [{ assetId: 'f0000000-0000-4000-8000-000000000001', 'bad key!': 1 }, [{ field: 'unknown', code: 'unknown_field' }]],
    ];
    for (const [body, fields] of cases) {
      await assert.rejects(svc.setCover(D, body), (e: unknown) => isCoverErr('validation_failed')(e) && JSON.stringify((e as CoverError).fields) === JSON.stringify(fields), JSON.stringify(body));
    }
    assert.deepEqual(fc.calls, []);
    assert.deepEqual(parseSetCoverInput({ assetId: 'F0000000-0000-4000-8000-00000000000A' }), { ok: true, value: { assetId: 'f0000000-0000-4000-8000-00000000000a' } });
  });
});

describe('showroom cover: clear and read', () => {
  it('clears the cover (one write); clearing when none is set writes nothing', async () => {
    const { fc, svc, D } = setup();
    const a = fc.addAsset({ ownerId: '10' });
    await svc.setCover(D, { assetId: a.id });
    await svc.clearCover(D);
    assert.equal(fc.showrooms()[0]!.coverAssetId, null);
    await svc.clearCover(D);
    assert.deepEqual(fc.writes.map((w) => w.assetId), [a.id, null]);
  });

  it('clear: no showroom or an inactive account is 404', async () => {
    const { fc, svc } = setup();
    fc.addUser('20');
    await assert.rejects(svc.clearCover(actor('20')), isNotFound);
    fc.addUser('21', 'dealer', 'suspended');
    fc.addShowroom('21');
    await assert.rejects(svc.clearCover(actor('21')), isNotFound);
  });

  it('read: the current cover (id and size) or null; a dealer without a showroom is 404', async () => {
    const { fc, svc, D } = setup();
    assert.deepEqual(await svc.getCover(D), { cover: null });
    const a = fc.addAsset({ ownerId: '10', width: 1200, height: 800 });
    await svc.setCover(D, { assetId: a.id });
    const r = await svc.getCover(D);
    assert.deepEqual(r, { cover: { assetId: a.id, width: 1200, height: 800 } });
    assert.ok(!/processed|thumbs|incoming|owner/.test(JSON.stringify(r)));
    fc.addUser('40');
    await assert.rejects(svc.getCover(actor('40')), isNotFound);
  });
});

// ---------------------------------------------------------------------------------------------------------------------------
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Array<(request: unknown, reply: unknown) => Promise<unknown>> };
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const PATH = '/v1/dealer/showroom/cover';

function http(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: recordingLogger().logger, now: clock.now });
  const fc = makeFakeCoverStore();
  const covers = createShowroomCoverService({ store: fc.store });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => void routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  registerShowroomCoverRoutes({ get: add('GET'), post: add('POST'), put: add('PUT'), patch: add('PATCH'), delete: add('DELETE') } as never, { auth, covers, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  async function call(method: string, request: Record<string, unknown> = {}): Promise<Sent & { handlerRan: boolean }> {
    const route = routes.find((r) => r.method === method && r.path === PATH)!;
    const sent: Sent = { headers: {} };
    const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, params: {}, query: {}, body: undefined, log: { warn() {}, info() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return { ...sent, handlerRan: false };
    }
    await route.handler(req, reply);
    return { ...sent, handlerRan: true };
  }
  let n = 0;
  /** An APPROVED dealer: registered through the real service, then activated in the fake auth store (as an admin approval would). */
  async function dealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: `0772${String(1000000 + ++n).slice(-7)}`, password: PW });
    const u = db.users().find((x) => x.id === r.user.id)!;
    u.status = 'active';
    fc.addUser(r.user.id);
    fc.addShowroom(r.user.id);
    return { id: r.user.id, headers: { authorization: `Bearer ${r.session.accessToken}`, 'content-type': 'application/json' } };
  }
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: `0771${String(1000000 + ++n).slice(-7)}`, password: PW });
    return { id: r.user.id, headers: { authorization: `Bearer ${r.session.accessToken}`, 'content-type': 'application/json' } };
  }
  return { routes, call, dealer, member, fc };
}

describe('showroom cover: HTTP', () => {
  it('registers GET, PUT and DELETE on /v1/dealer/showroom/cover; PUT/DELETE have a small body limit', () => {
    const h = http(true);
    assert.deepEqual(h.routes.map((r) => `${r.method} ${r.path}`).sort(), [`DELETE ${PATH}`, `GET ${PATH}`, `PUT ${PATH}`]);
    assert.equal(h.routes.find((r) => r.method === 'PUT')!.opts?.bodyLimit, 1024);
    assert.equal(h.routes.find((r) => r.method === 'DELETE')!.opts?.bodyLimit, 1024);
  });

  it('a dealer sets, reads and clears the cover', async () => {
    const h = http();
    const d = await h.dealer();
    const a = h.fc.addAsset({ ownerId: d.id });
    const put = await h.call('PUT', { headers: d.headers, body: { assetId: a.id } });
    assert.equal(put.status, 200);
    assert.deepEqual(put.body, { cover: { assetId: a.id, width: 1600, height: 900 } });
    assert.deepEqual((await h.call('GET', { headers: d.headers })).body, { cover: { assetId: a.id, width: 1600, height: 900 } });
    const del = await h.call('DELETE', { headers: { authorization: d.headers.authorization } });
    assert.equal(del.status, 204);
    assert.equal(del.body, undefined);
    assert.deepEqual((await h.call('GET', { headers: d.headers })).body, { cover: null });
  });

  it('401 without a valid token; 404 for a member and for a pending dealer; 409 for a pending asset; 400 for a bad body', async () => {
    const h = http();
    const r401 = await h.call('PUT', { headers: { 'content-type': 'application/json' }, body: { assetId: 'f0000000-0000-4000-8000-000000000001' } });
    assert.equal(r401.status, 401);
    assert.equal(r401.headers['www-authenticate'], 'Bearer');
    const m = await h.member();
    const ma = h.fc.addAsset({ ownerId: m.id });
    assert.equal((await h.call('PUT', { headers: m.headers, body: { assetId: ma.id } })).status, 404);
    assert.equal((await h.call('GET', { headers: m.headers })).status, 404);
    const d = await h.dealer();
    const pending = h.fc.addAsset({ ownerId: d.id, status: 'pending' });
    const r409 = await h.call('PUT', { headers: d.headers, body: { assetId: pending.id } });
    assert.equal(r409.status, 409);
    assert.equal((r409.body as { error: { code: string } }).error.code, 'invalid_state');
    const r400 = await h.call('PUT', { headers: d.headers, body: { assetId: 'nope' } });
    assert.equal(r400.status, 400);
    assert.deepEqual((r400.body as { error: { fields: unknown } }).error.fields, [{ field: 'assetId', code: 'invalid_format' }]);
    assert.ok(!JSON.stringify(r400.body).includes('nope'));
  });

  it('PUT refuses a non-JSON body with 415 before authentication or the handler; DELETE refuses a body with 400', async () => {
    const h = http();
    const d = await h.dealer();
    for (const ct of ['text/plain', 'application/x-www-form-urlencoded', 'multipart/form-data; boundary=x']) {
      const r = await h.call('PUT', { headers: { ...d.headers, 'content-type': ct }, body: '{}' });
      assert.equal(r.status, 415, ct);
      assert.equal(r.handlerRan, false);
    }
    const r = await h.call('DELETE', { headers: d.headers, body: { assetId: 'x' } });
    assert.equal(r.status, 400);
    assert.equal(h.fc.writes.length, 0);
  });

  it('rate limits reads and writes separately (429 before the handler)', async () => {
    const h = http(true);
    const d = await h.dealer();
    for (let i = 0; i < COVER_RATE_LIMITS.write.limit; i++) await h.call('DELETE', { headers: { authorization: d.headers.authorization } });
    const r = await h.call('PUT', { headers: d.headers, body: {} });
    assert.equal(r.status, 429);
    assert.equal(r.handlerRan, false);
    assert.equal((await h.call('GET', { headers: d.headers })).status, 200, 'reads have their own budget');
  });

  it('error mapping', () => {
    assert.equal(toCoverHttp(new CoverError('invalid_state'))?.status, 409);
    assert.equal(toCoverHttp(new CoverError('validation_failed'))?.status, 400);
    assert.equal(toCoverHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toCoverHttp(new DbError('unavailable')), undefined);
  });
});

describe('showroom cover: SQL and source guards', () => {
  it('the showroom and the asset are found by owner only; the only write is cover_asset_id of the owner\'s showroom', () => {
    assert.match(LOCK_OWN_SHOWROOM_SQL, /FROM showrooms s WHERE s\.owner_id = \$1::bigint FOR UPDATE$/);
    assert.match(FIND_OWN_COVER_ASSET_SQL, /FROM assets a WHERE a\.id = \$1::uuid AND a\.owner_id = \$2::bigint$/);
    assert.match(FIND_OWN_COVER_ASSET_SQL, /a\.storage_key NOT LIKE 'incoming\/%' AND a\.thumb_key NOT LIKE 'incoming\/%'\) AS servable/);
    assert.ok(!/SELECT[^]*\bstorage_key\b[^]*,\s*a\.thumb_key\s*,/.test(FIND_OWN_COVER_ASSET_SQL), 'keys are only compared in SQL, never selected');
    assert.equal(SET_COVER_SQL, 'UPDATE showrooms SET cover_asset_id = $3::uuid WHERE id = $1::bigint AND owner_id = $2::bigint');
    assert.match(FIND_OWN_COVER_SQL, /WHERE s\.owner_id = \$1::bigint$/);
    const repo = code('src/assets/cover-repository.ts');
    assert.equal((repo.match(/UPDATE /g) ?? []).length, 1);
    assert.ok(!/INSERT |DELETE /.test(repo));
  });

  it('the service decides the role before any database access, and never writes an audit row (Phase 11.5 vocabulary unchanged)', () => {
    const src = code('src/assets/cover.ts');
    for (const fn of ['getCover', 'setCover', 'clearCover']) assert.match(src, new RegExp(`async ${fn}\\(actor[^)]*\\) \\{\\s*if \\(!isDealer\\(actor\\)\\) throw notFound\\(\\);`), fn);
    assert.ok(!/audit/i.test(src));
  });
});

// Phase 11.6.3: the ImageCodec contract (src/assets/codec.ts), held against EVERY implementation available here:
//  - sharp (production; installed by `npm install`, so it runs in CI) - skipped visibly where it is not installed;
//  - Pillow (test reference; python3 + Pillow) - skipped visibly where it is not available.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { CodecError } from '../../src/assets/codec.ts';
import type { ImageCodec } from '../../src/assets/codec.ts';
import { inspectWebp } from '../../src/assets/webp-inspect.ts';
import { createPilCodec, pilAvailable } from '../helpers/pil-codec.ts';

const PROC = join(import.meta.dirname, '..', 'fixtures', 'processing');
const IMG = join(import.meta.dirname, '..', 'fixtures', 'images');
const proc = (n: string) => new Uint8Array(readFileSync(join(PROC, n)));
const img = (n: string) => new Uint8Array(readFileSync(join(IMG, n)));
const LIMIT = 40_000_000;
const R = (maxSide: number, quality = 80) => ({ maxSide, quality, maxInputPixels: LIMIT, timeoutMs: 15_000 });
const codecErr = (...codes: string[]) => (e: unknown) => e instanceof CodecError && codes.includes(e.code);

let sharpCodec: ImageCodec | null = null;
let sharpMissing: string | false = false;
try {
  sharpCodec = (await import('../../src/assets/sharp-codec.ts')).createSharpCodec();
} catch (e) {
  sharpMissing = `sharp is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const implementations: Array<[string, () => ImageCodec, string | false]> = [
  ['sharp', () => sharpCodec!, sharpMissing],
  ['pillow', createPilCodec, pilAvailable ? false : 'python3 with Pillow (WebP) is not available'],
];

for (const [name, make, skip] of implementations) {
  describe(`image codec contract: ${name}`, { skip }, () => {
    const codec = skip ? (null as never) : make();

    it('probe reports format, stored size and one frame for every accepted format, without the EXIF rotation', async () => {
      for (const [n, format, w, h] of [['baseline-3x2.jpg', 'jpeg', 3, 2], ['rgba-7x3.png', 'png', 7, 3], ['lossy-9x6.webp', 'webp', 9, 6], ['lossless-11x5.webp', 'webp', 11, 5], ['alpha-13x7.webp', 'webp', 13, 7]] as const) {
        assert.deepEqual(await codec.probe(img(n), { maxInputPixels: LIMIT }), { format, width: w, height: h, pages: 1 }, n);
      }
      const p = await codec.probe(proc('exif-gps-orient6-64x32.jpg'), { maxInputPixels: LIMIT });
      assert.deepEqual([p.width, p.height], [64, 32]);
    });

    it('render outputs a clean WebP: no EXIF/GPS/XMP/ICC chunk or flag, JPEG EXIF orientation applied, never enlarged', async () => {
      // JPEG EXIF orientation is universal; for PNG eXIf / WebP EXIF either orientation is accepted (decoder-dependent), the
      // metadata must be gone either way.
      for (const [n, w, h, strict] of [['exif-gps-orient6-64x32.jpg', 32, 64, true], ['meta-exif-xmp-icc-48x30.webp', 30, 48, false], ['text-exif-30x20.png', 20, 30, false], ['baseline-3x2.jpg', 3, 2, true]] as const) {
        const r = await codec.render(n.startsWith('baseline') ? img(n) : proc(n), R(1600));
        const info = inspectWebp(r.data);
        assert.ok(info, `${n}: a clean still WebP`);
        assert.deepEqual([info.width, info.height], [r.width, r.height], `${n}: reported size is the real size`);
        if (strict) assert.deepEqual([r.width, r.height], [w, h], n);
        else assert.ok((r.width === w && r.height === h) || (r.width === h && r.height === w), n);
        const text = Buffer.from(r.data).toString('latin1');
        for (const s of ['SECRETCAM', 'SECRETPERSON', 'GPS', 'Exif', 'xmpmeta', 'Location']) assert.ok(!text.includes(s), `${n}: ${s} survived`);
      }
    });

    it('render fits inside maxSide keeping the aspect ratio', async () => {
      const r = await codec.render(proc('photo-2400x1600.jpg'), R(1600));
      assert.equal(r.width, 1600);
      assert.ok(Math.abs(r.height - 1067) <= 1, String(r.height));
      const t = await codec.render(r.data, R(400, 70));
      assert.equal(t.width, 400);
      assert.ok(Math.abs(t.height - 267) <= 1);
    });

    it('refuses an image above the pixel limit before decoding, and malformed or unsupported input', async () => {
      // probe: refusing is preferred; reporting the true size is acceptable (the processor applies its own header limit first).
      await codec.probe(proc('photo-2400x1600.jpg'), { maxInputPixels: 1_000_000 }).then(
        (p) => assert.deepEqual([p.width, p.height], [2400, 1600]),
        (e: unknown) => assert.ok(codecErr('too_large')(e)),
      );
      await assert.rejects(codec.render(proc('photo-2400x1600.jpg'), { ...R(1600), maxInputPixels: 1_000_000 }), codecErr('too_large'));
      await assert.rejects(codec.render(proc('bomb-10000x10000.png'), R(1600)), codecErr('too_large'));
      await assert.rejects(codec.render(proc('corrupt-idat-32x32.png'), R(1600)), codecErr('invalid_image'));
      await assert.rejects(codec.render(new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg" width="8" height="8"/>'), R(1600)), codecErr('unsupported', 'invalid_image'));
      for (const other of ['refused-4x4.gif', 'refused-4x4.tiff', 'refused-4x4.bmp']) await assert.rejects(codec.render(img(other), R(1600)), codecErr('unsupported', 'invalid_image'), other);
      await assert.rejects(codec.probe(new Uint8Array([1, 2, 3, 4]), { maxInputPixels: LIMIT }), codecErr('unsupported', 'invalid_image'));
    });
  });
}

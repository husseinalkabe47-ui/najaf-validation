// Phase 11.6.3: the processing rules (processor.ts) and the output check (webp-inspect.ts), with a scriptable fake codec for every
// failure mode, and with a REAL decoder/encoder (Pillow) on real fixtures carrying EXIF, GPS, XMP, ICC and text metadata.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { ImageRejected, MAIN_MAX_SIDE, MAX_MAIN_OUTPUT_BYTES, MAX_THUMB_OUTPUT_BYTES, THUMB_MAX_SIDE, processImage } from '../../src/assets/processor.ts';
import { inspectWebp } from '../../src/assets/webp-inspect.ts';
import { createFakeCodec, fakeWebp } from '../helpers/fake-codec.ts';
import { createPilCodec, pilAvailable } from '../helpers/pil-codec.ts';

const PROC = join(import.meta.dirname, '..', 'fixtures', 'processing');
const IMG = join(import.meta.dirname, '..', 'fixtures', 'images');
const proc = (n: string) => new Uint8Array(readFileSync(join(PROC, n)));
const img = (n: string) => new Uint8Array(readFileSync(join(IMG, n)));
const rejected = (reason: string) => (e: unknown) => e instanceof ImageRejected && e.reason === reason;
const ascii = (b: Uint8Array) => Buffer.from(b).toString('latin1');

describe('processed-output check (inspectWebp)', () => {
  it('accepts a clean still WebP (VP8, VP8L, VP8X+ALPH without metadata flags) and reports its size and chunks', () => {
    assert.deepEqual(inspectWebp(fakeWebp(20, 10)), { width: 20, height: 10, chunks: ['VP8L'] });
    assert.deepEqual(inspectWebp(img('lossy-9x6.webp'))?.chunks, ['VP8 ']);
    assert.deepEqual(inspectWebp(fakeWebp(20, 10, { vp8xFlags: 0x10, extraChunks: [['ALPH', 4]] }))?.chunks, ['VP8X', 'ALPH', 'VP8L']);
  });

  it('refuses any metadata or animation chunk or flag, unknown chunks, broken chunk sizes and non-WebP input', () => {
    for (const c of ['EXIF', 'XMP ', 'ICCP', 'ANIM', 'ANMF', 'abcd']) assert.equal(inspectWebp(fakeWebp(20, 10, { vp8xFlags: 0, extraChunks: [[c, 6]] })), null, c);
    for (const flag of [0x20, 0x08, 0x04, 0x02]) assert.equal(inspectWebp(fakeWebp(20, 10, { vp8xFlags: flag })), null, `flag ${flag}`);
    assert.equal(inspectWebp(proc('meta-exif-xmp-icc-48x30.webp')), null, 'the metadata-laden fixture is refused as output');
    const two = fakeWebp(20, 10, { extraChunks: [['VP8L', 6]] });
    assert.equal(inspectWebp(two), null, 'two image chunks');
    const broken = new Uint8Array(fakeWebp(20, 10));
    broken[16] = 0xff; // VP8L chunk size beyond the file
    assert.equal(inspectWebp(broken), null);
    // A chunk AFTER the image chunk whose size runs past the end of the file (RIFF size still consistent).
    const tail = Buffer.concat([Buffer.from(fakeWebp(20, 10)), Buffer.from('ALPH', 'ascii'), Buffer.from([0xff, 0, 0, 0])]);
    tail.writeUInt32LE(tail.length - 8, 4);
    assert.equal(inspectWebp(new Uint8Array(tail)), null, 'a trailing chunk beyond the file');
    // Two complete, valid image chunks.
    const vp8l = Buffer.from(fakeWebp(20, 10)).subarray(12);
    const twice = Buffer.concat([Buffer.from(fakeWebp(20, 10)), vp8l]);
    twice.writeUInt32LE(twice.length - 8, 4);
    assert.equal(inspectWebp(new Uint8Array(twice)), null, 'two image chunks');
    assert.equal(inspectWebp(img('rgba-7x3.png')), null);
    assert.equal(inspectWebp(new Uint8Array(0)), null);
  });
});

describe('processing rules with a scripted codec', () => {
  const jpg = img('baseline-3x2.jpg');
  const photoLike = proc('photo-2400x1600.jpg');

  it('produces a main image within MAIN_MAX_SIDE and a thumbnail within THUMB_MAX_SIDE from it, never enlarged', async () => {
    const { codec, calls } = createFakeCodec();
    const r = await processImage(photoLike, codec);
    assert.deepEqual([r.main.width, r.main.height], [MAIN_MAX_SIDE, 1067]);
    assert.deepEqual([r.thumb.width, r.thumb.height], [THUMB_MAX_SIDE, 267]);
    assert.match(r.main.sha256, /^[0-9a-f]{64}$/);
    assert.deepEqual(calls.map((c) => c.op), ['probe', 'render', 'render']);
    const small = await processImage(jpg, codec);
    assert.deepEqual([small.main.width, small.main.height, small.thumb.width, small.thumb.height], [3, 2, 3, 2]);
  });

  it('an orientation swap is accepted (same aspect ratio)', async () => {
    const r = await processImage(photoLike, createFakeCodec({ rotate: true }).codec);
    assert.deepEqual([r.main.width, r.main.height], [1067, MAIN_MAX_SIDE]);
  });

  it('rejects a stored original that is not an accepted image, or over the pixel/side limits, before the codec is called', async () => {
    const { codec, calls } = createFakeCodec();
    await assert.rejects(processImage(img('refused-4x4.gif'), codec), rejected('invalid_image'));
    await assert.rejects(processImage(new TextEncoder().encode('<svg/>'), codec), rejected('invalid_image'));
    await assert.rejects(processImage(proc('bomb-10000x10000.png'), codec), rejected('too_large'));
    assert.deepEqual(calls, []);
  });

  it('rejects when the decoder disagrees with the header (format, size) or reports more than one frame', async () => {
    await assert.rejects(processImage(jpg, createFakeCodec({ probe: { format: 'png' } }).codec), rejected('inconsistent'));
    await assert.rejects(processImage(jpg, createFakeCodec({ probe: { width: 4 } }).codec), rejected('inconsistent'));
    await assert.rejects(processImage(jpg, createFakeCodec({ probe: { pages: 3 } }).codec), rejected('animated'));
  });

  it('maps codec failures to rejection reasons (malformed, unsupported, pixel limit, timeout)', async () => {
    for (const code of ['invalid_image', 'unsupported', 'too_large', 'timeout'] as const) {
      await assert.rejects(processImage(jpg, createFakeCodec({ probeError: code }).codec), rejected(code), `probe ${code}`);
      await assert.rejects(processImage(jpg, createFakeCodec({ renderError: code }).codec), rejected(code), `render ${code}`);
    }
  });

  it('a codec that hangs is cut off by the processor own timeout', async () => {
    const t0 = Date.now();
    await assert.rejects(processImage(jpg, createFakeCodec({ hang: true }).codec, { timeoutMs: 50 }), rejected('timeout'));
    assert.ok(Date.now() - t0 < 3000);
  });

  it('refuses output that keeps metadata, lies about its size, is enlarged, cropped, or not bytes', async () => {
    for (const [b, label] of [[{ addChunk: 'EXIF' }, 'EXIF chunk'], [{ addChunk: 'XMP ' }, 'XMP chunk'], [{ addChunk: 'ICCP' }, 'ICC chunk'], [{ vp8xFlags: 0x08 }, 'EXIF flag'], [{ lie: true }, 'wrong size'], [{ enlarge: true }, 'enlarged'], [{ crop: true }, 'cropped'], [{ notBytes: true }, 'not bytes']] as const) {
      await assert.rejects(processImage(photoLike, createFakeCodec(b).codec), rejected('output_invalid'), label);
    }
  });

  it('an output that ignores the size bound, or enlarges a small image within the bound, is refused', async () => {
    await assert.rejects(processImage(photoLike, createFakeCodec({ noResize: true }).codec), rejected('output_invalid'), 'not resized');
    await assert.rejects(processImage(jpg, createFakeCodec({ enlarge: true }).codec), rejected('output_invalid'), '3x2 -> 6x4');
  });

  it('over the output budget, one lower quality is tried; still over is output_too_large', async () => {
    const big = (q: number) => (q >= 80 ? MAX_MAIN_OUTPUT_BYTES + 10 : 1000);
    const { codec, calls } = createFakeCodec({ payload: big });
    const r = await processImage(photoLike, codec);
    assert.ok(r.main.data.byteLength < MAX_MAIN_OUTPUT_BYTES);
    assert.deepEqual(calls.filter((c) => c.op === 'render').map((c) => (c.opts as { quality: number }).quality), [80, 60, 70]);
    await assert.rejects(processImage(photoLike, createFakeCodec({ payload: () => MAX_MAIN_OUTPUT_BYTES + 10 }).codec), rejected('output_too_large'));
    await assert.rejects(processImage(photoLike, createFakeCodec({ payload: (q) => (q === 70 || q === 50 ? MAX_THUMB_OUTPUT_BYTES + 10 : 100) }).codec), rejected('output_too_large'));
  });

  it('passes the pixel limit and the timeout to every codec call', async () => {
    const { codec, calls } = createFakeCodec();
    await processImage(jpg, codec, { timeoutMs: 1234 });
    for (const c of calls) assert.equal((c.opts as { maxInputPixels: number }).maxInputPixels, 40_000_000);
    for (const c of calls.filter((x) => x.op === 'render')) assert.equal((c.opts as { timeoutMs: number }).timeoutMs, 1234);
  });
});

describe('processing with a real decoder and encoder (Pillow)', { skip: pilAvailable ? false : 'python3 with Pillow (WebP) is not available' }, () => {
  const codec = pilAvailable ? createPilCodec() : (null as never);
  const SECRETS = ['SECRETCAM', 'SECRETPERSON', 'ModelX', 'GPS', 'Exif', 'XMP', 'xmpmeta', 'ICC_PROFILE', 'sRGB', 'Author', 'Location', 'eXIf', 'tEXt'];

  for (const [name, w, h] of [['exif-gps-orient6-64x32.jpg', 32, 64], ['meta-exif-xmp-icc-48x30.webp', 30, 48], ['text-exif-30x20.png', 20, 30]] as const) {
    it(`${name}: oriented, re-encoded as WebP, and every metadata trace (EXIF, GPS, XMP, ICC, text) is gone`, async () => {
      const original = proc(name);
      assert.ok(SECRETS.some((s) => ascii(original).includes(s)), 'the fixture really carries metadata');
      const r = await processImage(original, codec);
      for (const out of [r.main, r.thumb]) {
        const info = inspectWebp(out.data);
        assert.ok(info, 'a clean WebP');
        assert.deepEqual([info.width, info.height], [w, h], 'EXIF orientation applied');
        for (const s of SECRETS) assert.ok(!ascii(out.data).includes(s), `${s} must not survive`);
      }
    });
  }

  it('a 2400x1600 photo becomes a 1600x1067 main image and a 400x267 thumbnail, both within budget', async () => {
    const r = await processImage(proc('photo-2400x1600.jpg'), codec);
    assert.deepEqual([r.main.width, r.main.height, r.thumb.width, r.thumb.height], [1600, 1067, 400, 267]);
    assert.ok(r.main.data.byteLength <= MAX_MAIN_OUTPUT_BYTES && r.thumb.data.byteLength <= MAX_THUMB_OUTPUT_BYTES);
  });

  it('every accepted upload format processes (JPEG baseline/progressive, PNG RGBA/16-bit, WebP lossy/lossless/alpha)', async () => {
    for (const n of ['baseline-3x2.jpg', 'progressive-exif-5x4.jpg', 'rgba-7x3.png', 'gray16-6x2.png', 'lossy-9x6.webp', 'lossless-11x5.webp', 'alpha-13x7.webp']) {
      const r = await processImage(img(n), codec);
      assert.ok(inspectWebp(r.main.data) && inspectWebp(r.thumb.data), n);
    }
  });

  it('a corrupted pixel stream is rejected (invalid_image); the 100 Mpx bomb is rejected before decoding (too_large)', async () => {
    await assert.rejects(processImage(proc('corrupt-idat-32x32.png'), codec), rejected('invalid_image'));
    const t0 = Date.now();
    await assert.rejects(processImage(proc('bomb-10000x10000.png'), codec), rejected('too_large'));
    assert.ok(Date.now() - t0 < 500, 'refused from the header, not by decoding 100 Mpx');
  });
});

// Secure asset upload (Phase 11.6.2) against a real PostgreSQL 16 (migrations 0001-0013) through the least-privilege application
// role, with the in-memory storage provider. Needs DATABASE_URL and ADMIN_DATABASE_URL (fixtures/cleanup only); skipped otherwise.
// A second suite drives the REAL Fastify server (app.inject) when fastify is installed, to prove what the unit tests' fake app
// cannot: the image parsers exist only inside the encapsulated plugin, authentication and the type check run before the body is
// read, the body limit is enforced (413), and a JSON body to the upload route is refused.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgAssetStore } from '../../src/assets/repository.ts';
import { ASSET_UPLOAD_MAX_BYTES, AssetError, MAX_PENDING_PER_DAY, createAssetService } from '../../src/assets/service.ts';
import { createPgCarImageStore } from '../../src/car-images/repository.ts';
import { CarImageError, createCarImageService } from '../../src/car-images/service.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { StorageProvider } from '../../src/storage/index.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const JPG = new Uint8Array(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'images', 'baseline-3x2.jpg')));
const PNG = new Uint8Array(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'images', 'rgba-7x3.png')));

describe('asset upload on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  let M: Actor;
  let M2: Actor;
  let D: Actor;
  let storage: ReturnType<typeof createMemoryStorage>;

  const newUser = async (role: 'user' | 'dealer'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone, role],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const rowOf = async (id: string) => (await admin.query<Record<string, unknown>>('SELECT owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at FROM assets WHERE id = $1::uuid', [id])).rows[0];
  const up = (svc: ReturnType<typeof createAssetService>, actor: Actor, body = JPG, type = 'image/jpeg', kind = 'car_image') => svc.upload(actor, { query: { kind }, contentType: type, body });

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    M = { id: await newUser('user'), role: 'member' };
    M2 = { id: await newUser('user'), role: 'member' };
    D = { id: await newUser('dealer'), role: 'dealer' };
    storage = createMemoryStorage();
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM car_images WHERE car_id IN (SELECT id FROM cars WHERE owner_id = ANY($1::bigint[]))', [userIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('creates a pending asset owned by the actor (storage key, size, checksum, dimensions; no mime/thumb/ready) and stores the object', async () => {
    const svc = createAssetService({ store: createPgAssetStore(app), storage });
    const a = await up(svc, M);
    assert.equal(a.status, 'pending');
    const r = (await rowOf(a.id))!;
    assert.equal(String(r['owner_id']), M.id);
    assert.match(String(r['storage_key']), /^incoming\/car_image\/[0-9a-f-]{36}$/);
    assert.equal(r['mime'], null);
    assert.equal(r['thumb_key'], null);
    assert.equal(r['ready_at'], null);
    assert.equal(Number(r['bytes']), JPG.length);
    assert.equal(Number(r['width']), 3);
    assert.match(String(r['sha256']), /^[0-9a-f]{64}$/);
    assert.ok(await storage.exists(String(r['storage_key'])));
    const d = await up(svc, D, PNG, 'image/png', 'showroom_cover');
    assert.equal((await rowOf(d.id))!['kind'], 'showroom_cover');
  });

  it('another user can neither read the asset (404) nor attach it to a car (404); the owner cannot attach it while it is pending', async () => {
    const svc = createAssetService({ store: createPgAssetStore(app), storage });
    const a = await up(svc, M);
    await assert.rejects(svc.getOwn(M2, a.id), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    assert.equal((await svc.getOwn(M, a.id)).id, a.id);
    const car = async (owner: string) => String((await admin.query<{ id: string }>(`INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status) VALUES ('member', $1::bigint, 'Kia', 'Rio', 2018, 9000, 'USD', '+9647701234567', 'النجف', 'pending') RETURNING id`, [owner])).rows[0]!.id);
    const images = createCarImageService({ store: createPgCarImageStore(app) });
    await assert.rejects(images.add(M2, await car(M2.id), { assetId: a.id }), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    await assert.rejects(images.add(M, await car(M.id), { assetId: a.id }), (e: unknown) => e instanceof CarImageError && e.code === 'invalid_state');
  });

  it(`the quota (${MAX_PENDING_PER_DAY} pending per 24 hours) holds under concurrent uploads over two connections`, async () => {
    const owner: Actor = { id: await newUser('user'), role: 'member' };
    const s1 = createAssetService({ store: createPgAssetStore(app), storage });
    const s2 = createAssetService({ store: createPgAssetStore(app2), storage });
    const results = await Promise.allSettled(Array.from({ length: MAX_PENDING_PER_DAY + 6 }, (_, i) => up(i % 2 ? s1 : s2, owner)));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, MAX_PENDING_PER_DAY);
    for (const r of results) if (r.status === 'rejected') assert.ok(r.reason instanceof AssetError && r.reason.code === 'upload_limit');
    const n = await admin.query<{ n: number }>(`SELECT count(*)::int AS n FROM assets WHERE owner_id = $1::bigint`, [owner.id]);
    assert.equal(n.rows[0]!.n, MAX_PENDING_PER_DAY);
  });

  it('a failed storage write leaves neither a row nor an object; when the object cannot be removed the pending row is kept', async () => {
    const owner: Actor = { id: await newUser('user'), role: 'member' };
    const mem = createMemoryStorage();
    let deleteFails = false;
    const failing: StorageProvider = {
      kind: 'memory',
      async put(k, b, o) {
        await mem.put(k, b, o);
        throw new StorageError('unavailable');
      },
      get: (k) => mem.get(k),
      exists: (k) => mem.exists(k),
      async delete(k) {
        if (deleteFails) throw new StorageError('unavailable');
        await mem.delete(k);
      },
    };
    const svc = createAssetService({ store: createPgAssetStore(app), storage: failing });
    await assert.rejects(up(svc, owner), (e: unknown) => e instanceof AssetError && e.code === 'storage_unavailable');
    assert.equal((await admin.query(`SELECT 1 FROM assets WHERE owner_id = $1::bigint`, [owner.id])).rows.length, 0);
    assert.equal(mem.size(), 0);
    deleteFails = true;
    await assert.rejects(up(svc, owner), (e: unknown) => e instanceof AssetError && e.code === 'storage_unavailable');
    const kept = await admin.query<{ status: string; storage_key: string }>(`SELECT status, storage_key FROM assets WHERE owner_id = $1::bigint`, [owner.id]);
    assert.equal(kept.rows.length, 1);
    assert.equal(kept.rows[0]!.status, 'pending');
    assert.ok(await mem.exists(kept.rows[0]!.storage_key), 'the object that may exist is reachable through the kept row');
  });
});

// ---- the real Fastify server ----
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let missing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  missing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

describe('asset upload through the real Fastify server', { skip: missing }, () => {
  it('parses image bodies only on the upload route, checks auth and type before the body, enforces the body limit', async () => {
    const { loadConfig } = await import('../../src/config.ts');
    const config = loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: 'postgres://u:p@localhost:5432/x' });
    const db = { ping: async () => undefined, checkSchema: async () => ({ missing: [] }) } as never;
    const uploads: unknown[] = [];
    const assets = {
      async upload(actor: unknown, input: { body: unknown }) {
        uploads.push(input.body);
        return { id: '0f8fad5b-d9cb-469f-a165-70867728950e', kind: 'car_image', status: 'pending', bytes: (input.body as Uint8Array).length, width: 3, height: 2, createdAt: new Date(0).toISOString(), actor };
      },
      async getOwn() {
        throw new AuthzError('not_found');
      },
    };
    const auth = { authenticate: async (t: string | undefined) => (t === 'good' ? { user: { id: '1', role: 'user', status: 'active', deletedAt: null } } : null) } as never;
    const server = await buildServer!({ config, db, auth, assets: assets as never });
    try {
      const post = (headers: Record<string, string>, payload: Buffer | string, url = '/v1/me/assets?kind=car_image') => server.inject({ method: 'POST', url, headers, payload });
      const ok = await post({ authorization: 'Bearer good', 'content-type': 'image/jpeg' }, Buffer.from(JPG));
      assert.equal(ok.statusCode, 201, ok.body);
      assert.ok(Buffer.isBuffer(uploads[0]), 'the body reaches the service as raw bytes');
      assert.equal((await post({ 'content-type': 'image/jpeg' }, Buffer.from(JPG))).statusCode, 401);
      assert.equal((await post({ authorization: 'Bearer good', 'content-type': 'application/json' }, '{"kind":"car_image"}')).statusCode, 415);
      assert.equal((await post({ authorization: 'Bearer good', 'content-type': 'image/svg+xml' }, '<svg/>')).statusCode, 415);
      const big = await post({ authorization: 'Bearer good', 'content-type': 'image/jpeg' }, Buffer.alloc(ASSET_UPLOAD_MAX_BYTES + 1));
      assert.equal(big.statusCode, 413);
      assert.equal(uploads.length, 1, 'refused requests never reached the service');
      // Image bodies are NOT accepted anywhere else (the parser is encapsulated): Fastify answers 415 (or 404 for no route).
      const elsewhere = await server.inject({ method: 'POST', url: '/healthz', headers: { 'content-type': 'image/jpeg' }, payload: Buffer.from(JPG) });
      assert.ok([404, 415].includes(elsewhere.statusCode), String(elsewhere.statusCode));
    } finally {
      await server.close();
    }
  });
});

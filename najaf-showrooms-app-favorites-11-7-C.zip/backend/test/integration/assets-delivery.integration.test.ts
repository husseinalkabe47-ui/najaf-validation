// Phase 11.6.4 against a real PostgreSQL 16 (application role) and the in-memory storage provider: public visibility through the
// real views, the owner's images, the dealer's showroom cover (with the database's cover guard as backstop), attaching only ready
// assets to a car, and the cleanup job's statements (database clock, compare-and-swap, reference lookup). Needs DATABASE_URL and
// ADMIN_DATABASE_URL; without them the suite is skipped visibly. Fixtures are written with the admin handle and removed afterwards.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash, randomInt, randomUUID } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { createPgDeliveryRepository } from '../../src/assets/delivery-repository.ts';
import { createAssetDelivery } from '../../src/assets/delivery.ts';
import { createPgCoverRepository, createPgCoverStore } from '../../src/assets/cover-repository.ts';
import { CoverError, createShowroomCoverService } from '../../src/assets/cover.ts';
import { createPgCleanupRepository } from '../../src/assets/cleanup-repository.ts';
import type { CleanupRepository } from '../../src/assets/cleanup-repository.ts';
import { runAssetCleanup } from '../../src/assets/cleanup.ts';
import { createPgCarImageStore } from '../../src/car-images/repository.ts';
import { CarImageError, createCarImageService } from '../../src/car-images/service.ts';
import { createMemoryStorage } from '../../src/storage/index.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const MAIN = fakeWebp(16, 12, { payload: 40 });
const THUMB = fakeWebp(8, 6, { payload: 20 });
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';

describe('image delivery, showroom cover and cleanup on PostgreSQL 16', { skip }, () => {
  let app: Db;
  let admin: Db;
  const userIds: string[] = [];
  const storage = createMemoryStorage();
  let M: Actor;
  let S: Actor;
  let D: Actor;
  let D2: Actor;
  let showroomD: string;
  let showroomD2: string;

  const newUser = async (role: 'user' | 'dealer', status = 'active'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, $3, $4) RETURNING id`, [phone, role, status, HASH]);
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const newCar = async (owner: string, status = 'active'): Promise<string> =>
    String((await admin.query<{ id: string }>(`INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status) VALUES ('member', $1::bigint, 'Kia', 'Rio', 2018, 9000, 'USD', '+9647701234567', 'النجف', $2) RETURNING id`, [owner, status])).rows[0]!.id);
  /** A READY asset as the processor leaves it, with both objects stored. */
  const readyAsset = async (owner: string, kind = 'car_image', ageHours = 0): Promise<{ id: string; key: string; thumbKey: string }> => {
    const u = randomUUID();
    const key = `processed/${kind}/${u}.webp`;
    const thumbKey = `thumbs/${kind}/${u}.webp`;
    const r = await admin.query<{ id: string }>(
      `INSERT INTO assets (owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at, created_at)
       VALUES ($1::bigint, $2, 'ready', $3, $4, 'image/webp', $5, 16, 12, $6, now(), now() - make_interval(hours => $7)) RETURNING id`,
      [owner, kind, key, thumbKey, MAIN.byteLength, sha(MAIN), ageHours],
    );
    await storage.put(key, MAIN, { contentType: 'image/webp' });
    await storage.put(thumbKey, THUMB, { contentType: 'image/webp' });
    return { id: String(r.rows[0]!.id), key, thumbKey };
  };
  const unprocessed = async (owner: string, status: 'pending' | 'rejected', ageHours: number, kind = 'car_image'): Promise<{ id: string; key: string }> => {
    const key = `incoming/${kind}/${randomUUID()}`;
    const r = await admin.query<{ id: string }>(
      `INSERT INTO assets (owner_id, kind, status, storage_key, bytes, width, height, sha256, reject_reason, created_at)
       VALUES ($1::bigint, $2, $3, $4, 10, 4, 3, $5, $6, now() - make_interval(hours => $7)) RETURNING id`,
      [owner, kind, status, key, 'b'.repeat(64), status === 'rejected' ? 'invalid_image' : null, ageHours],
    );
    await storage.put(key, new Uint8Array([1, 2, 3]), { contentType: 'image/jpeg' });
    return { id: String(r.rows[0]!.id), key };
  };
  const attach = async (car: string, asset: string, sortOrder = 0) =>
    admin.query(`INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES ($1::bigint, $2::uuid, $3, $4)`, [car, asset, sortOrder, sortOrder === 0]);

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    M = { id: await newUser('user'), role: 'member' };
    S = { id: await newUser('user', 'suspended'), role: 'member' };
    D = { id: await newUser('dealer'), role: 'dealer' };
    D2 = { id: await newUser('dealer'), role: 'dealer' };
    showroomD = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', 'active') RETURNING id`, [D.id])).rows[0]!.id);
    showroomD2 = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', 'pending') RETURNING id`, [D2.id])).rows[0]!.id);
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('UPDATE showrooms SET cover_asset_id = NULL WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM car_images WHERE car_id IN (SELECT id FROM cars WHERE owner_id = ANY($1::bigint[]))', [userIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM showrooms WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  it('public images follow the public views: a public car or showroom serves; pending, deleted, suspended-owner or unattached does not', async () => {
    const delivery = createAssetDelivery({ repo: createPgDeliveryRepository(app), storage });
    const pub = await newCar(M.id);
    const a1 = await readyAsset(M.id);
    const a2 = await readyAsset(M.id);
    await attach(pub, a1.id, 0);
    await attach(pub, a2.id, 1);
    assert.deepEqual([...(await delivery.publicImage(a1.id, 'main')).body!], [...MAIN]);
    assert.deepEqual([...(await delivery.publicImage(a2.id, 'thumb')).body!], [...THUMB]);
    assert.deepEqual((await delivery.publicCarImages(pub)).images.map((i) => [i.assetId, i.isMain, i.sortOrder, i.width, i.height]), [[a1.id, true, 0, 16, 12], [a2.id, false, 1, 16, 12]]);

    const pendingCar = await newCar(M.id, 'pending');
    const onPending = await readyAsset(M.id);
    await attach(pendingCar, onPending.id);
    const deletedCar = await newCar(M.id);
    const onDeleted = await readyAsset(M.id);
    await attach(deletedCar, onDeleted.id);
    await admin.query('UPDATE cars SET deleted_at = now() WHERE id = $1::bigint', [deletedCar]);
    const suspendedCar = await newCar(S.id);
    const onSuspended = await readyAsset(S.id);
    await attach(suspendedCar, onSuspended.id);
    const unattached = await readyAsset(M.id);
    for (const a of [onPending, onDeleted, onSuspended, unattached]) await assert.rejects(delivery.publicImage(a.id, 'main'), isNotFound);
    for (const car of [pendingCar, deletedCar, suspendedCar]) await assert.rejects(delivery.publicCarImages(car), isNotFound);

    const cover = await readyAsset(D.id, 'showroom_cover');
    const cover2 = await readyAsset(D2.id, 'showroom_cover');
    await admin.query('UPDATE showrooms SET cover_asset_id = $2::uuid WHERE id = $1::bigint', [showroomD, cover.id]);
    await admin.query('UPDATE showrooms SET cover_asset_id = $2::uuid WHERE id = $1::bigint', [showroomD2, cover2.id]);
    assert.ok((await delivery.publicImage(cover.id, 'main')).body);
    assert.deepEqual(await delivery.publicShowroomCover(showroomD), { cover: { assetId: cover.id, width: 16, height: 12 } });
    await assert.rejects(delivery.publicImage(cover2.id, 'main'), isNotFound, 'the cover of a pending showroom is not public');
    await assert.rejects(delivery.publicShowroomCover(showroomD2), isNotFound);
    await admin.query('UPDATE showrooms SET cover_asset_id = NULL WHERE id = ANY($1::bigint[])', [[showroomD, showroomD2]]);
  });

  it("the owner sees their own ready assets only (attached or not); anyone else's is 404", async () => {
    const delivery = createAssetDelivery({ repo: createPgDeliveryRepository(app), storage });
    const mine = await readyAsset(M.id);
    assert.ok((await delivery.ownImage(M, mine.id, 'thumb')).body);
    await assert.rejects(delivery.ownImage(D, mine.id, 'main'), isNotFound);
    const pending = await unprocessed(M.id, 'pending', 0);
    await assert.rejects(delivery.ownImage(M, pending.id, 'main'), isNotFound);
  });

  it('attaching to a car still requires the caller\'s own READY car_image (pending is 409, another user\'s is 404)', async () => {
    const images = createCarImageService({ store: createPgCarImageStore(app) });
    const car = await newCar(M.id);
    const pending = await unprocessed(M.id, 'pending', 0);
    await assert.rejects(images.add(M, car, { assetId: pending.id }), (e: unknown) => e instanceof CarImageError && e.code === 'invalid_state');
    const theirs = await readyAsset(D.id);
    await assert.rejects(images.add(M, car, { assetId: theirs.id }), isNotFound);
    const cover = await readyAsset(M.id, 'showroom_cover');
    await assert.rejects(images.add(M, car, { assetId: cover.id }), (e: unknown) => e instanceof CarImageError && e.code === 'invalid_state');
  });

  it("a dealer sets and clears their own showroom's cover; foreign, pending and car_image assets are refused; the guard is the backstop", async () => {
    const covers = createShowroomCoverService({ store: createPgCoverStore(app) });
    const own = await readyAsset(D.id, 'showroom_cover');
    assert.deepEqual(await covers.setCover(D, { assetId: own.id }), { cover: { assetId: own.id, width: 16, height: 12 } });
    assert.equal((await admin.query<{ c: string }>('SELECT cover_asset_id AS c FROM showrooms WHERE id = $1::bigint', [showroomD])).rows[0]!.c, own.id);
    assert.deepEqual(await covers.getCover(D), { cover: { assetId: own.id, width: 16, height: 12 } });
    const foreign = await readyAsset(D2.id, 'showroom_cover');
    await assert.rejects(covers.setCover(D, { assetId: foreign.id }), isNotFound);
    const pending = await unprocessed(D.id, 'pending', 0, 'showroom_cover');
    await assert.rejects(covers.setCover(D, { assetId: pending.id }), (e: unknown) => e instanceof CoverError && e.code === 'invalid_state');
    const carImage = await readyAsset(D.id, 'car_image');
    await assert.rejects(covers.setCover(D, { assetId: carImage.id }), (e: unknown) => e instanceof CoverError && e.code === 'invalid_state');
    await assert.rejects(covers.setCover(M, { assetId: own.id }), isNotFound);
    // The pending showroom's owner manages it too (the existing policy).
    const own2 = await readyAsset(D2.id, 'showroom_cover');
    assert.equal((await covers.setCover(D2, { assetId: own2.id })).cover.assetId, own2.id);
    await covers.clearCover(D2);
    await covers.clearCover(D);
    assert.equal((await admin.query<{ c: string | null }>('SELECT cover_asset_id AS c FROM showrooms WHERE id = $1::bigint', [showroomD])).rows[0]!.c, null);
    // Backstop: the repository alone (bypassing the service checks) cannot set another user's asset; the trigger refuses it.
    await assert.rejects(app.tx((t) => createPgCoverRepository(t).setCover(showroomD, D.id, foreign.id)), (e: unknown) => e instanceof DbError && e.kind === 'forbidden');
  });

  it('cleanup statements: database clock, stale = pending/rejected + old + unreferenced, compare-and-swap delete, reference lookup', async () => {
    const repo = createPgCleanupRepository(app);
    const oldPending = await unprocessed(M.id, 'pending', 48);
    const oldRejected = await unprocessed(M.id, 'rejected', 30);
    const young = await unprocessed(M.id, 'pending', 2);
    const oldReady = await readyAsset(M.id, 'car_image', 400);
    const mine = new Set([oldPending.id, oldRejected.id, young.id, oldReady.id]);
    const listed = async (hours: number) => {
      const out: string[] = [];
      let afterId: string | null = null;
      for (;;) {
        const page = await repo.listStale({ olderThanSeconds: hours * 3600, afterId, limit: 100 });
        out.push(...page.filter((r) => mine.has(r.id)).map((r) => r.id));
        if (page.length < 100) return out.sort();
        afterId = page[page.length - 1]!.id;
      }
    };
    assert.deepEqual(await listed(24), [oldPending.id, oldRejected.id].sort());
    assert.deepEqual(await listed(36), [oldPending.id]);
    assert.equal(await repo.deleteStale({ id: oldPending.id, storageKey: 'incoming/car_image/other', olderThanSeconds: 86400 }), false);
    assert.equal(await repo.deleteStale({ id: young.id, storageKey: young.key, olderThanSeconds: 86400 }), false);
    assert.equal(await repo.deleteStale({ id: oldReady.id, storageKey: oldReady.key, olderThanSeconds: 86400 }), false);
    const refs = await repo.findReferencedKeys([oldReady.key, oldReady.thumbKey, young.key, 'incoming/car_image/none']);
    assert.deepEqual([...refs].sort(), [oldReady.key, oldReady.thumbKey, young.key].sort());

    // The whole job, restricted to this suite's rows (other suites' rows are never touched by the test).
    const scoped: CleanupRepository = {
      listStale: async (i) => (await repo.listStale(i)).filter((r) => mine.has(r.id)),
      deleteStale: (i) => (mine.has(i.id) ? repo.deleteStale(i) : Promise.resolve(false)),
      findReferencedKeys: (k) => repo.findReferencedKeys(k),
      listRetryable: async (i) => (await repo.listRetryable(i)).filter((id) => mine.has(id)),
    };
    const dry = await runAssetCleanup({ repo: scoped, storage }, { orphans: false });
    assert.equal(dry.rows!.eligible, 2);
    assert.equal((await admin.query('SELECT 1 FROM assets WHERE id = ANY($1::uuid[])', [[oldPending.id, oldRejected.id]])).rows.length, 2);
    const run = await runAssetCleanup({ repo: scoped, storage }, { dryRun: false, orphans: false });
    assert.equal(run.error, null);
    assert.equal(run.rows!.deleted, 2);
    assert.equal((await admin.query('SELECT 1 FROM assets WHERE id = ANY($1::uuid[])', [[oldPending.id, oldRejected.id]])).rows.length, 0);
    assert.equal(await storage.exists(oldPending.key), false);
    assert.equal(await storage.exists(oldRejected.key), false);
    assert.equal(await storage.exists(young.key), true);
    assert.equal(await storage.exists(oldReady.key), true);
  });
});

// Phase 11.6.6 against a real PostgreSQL 16 (application role) and the in-memory storage provider: the audit's listing (referenced
// flag and age decided by the database clock), the locked compare-and-swap that removes an unlinked asset (refusing referenced,
// young, changed and non-ready rows), the race with a concurrent cover attach (the asset and the cover survive), and a whole run
// that reports a damaged referenced asset without touching it. Needs DATABASE_URL and ADMIN_DATABASE_URL; without them the suite
// is skipped visibly. Fixtures are written with the admin handle and removed afterwards.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash, randomInt, randomUUID } from 'node:crypto';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgAuditRepository } from '../../src/assets/audit-repository.ts';
import type { AuditRepository } from '../../src/assets/audit-repository.ts';
import { runAssetAudit } from '../../src/assets/audit.ts';
import { createMemoryStorage } from '../../src/storage/index.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const MAIN = fakeWebp(16, 12, { payload: 40 });
const THUMB = fakeWebp(8, 6, { payload: 20 });
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');
const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const DAY = 24;

describe('asset integrity audit on PostgreSQL 16', { skip }, () => {
  let app: Db;
  let admin: Db;
  let repo: AuditRepository;
  const userIds: string[] = [];
  const storage = createMemoryStorage();
  let dealer: string;
  let showroom: string;

  const newUser = async (role: 'user' | 'dealer'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  /** A READY showroom_cover asset (the kind a dealer can attach), ready `ageHours` ago, with its objects stored unless told otherwise. */
  const readyAsset = async (ageHours: number, o: { objects?: boolean } = {}): Promise<{ id: string; key: string; thumbKey: string }> => {
    const u = randomUUID();
    const key = `processed/showroom_cover/${u}.webp`;
    const thumbKey = `thumbs/showroom_cover/${u}.webp`;
    const r = await admin.query<{ id: string }>(
      `INSERT INTO assets (owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at, created_at)
       VALUES ($1::bigint, 'showroom_cover', 'ready', $2, $3, 'image/webp', $4, 16, 12, $5, now() - make_interval(hours => $6), now() - make_interval(hours => $6 + 1)) RETURNING id`,
      [dealer, key, thumbKey, MAIN.byteLength, sha(MAIN), ageHours],
    );
    if (o.objects !== false) {
      await storage.put(key, MAIN, { contentType: 'image/webp' });
      await storage.put(thumbKey, THUMB, { contentType: 'image/webp' });
    }
    return { id: String(r.rows[0]!.id), key, thumbKey };
  };
  const setCover = (assetId: string | null) => admin.query('UPDATE showrooms SET cover_asset_id = $2::uuid WHERE id = $1::bigint', [showroom, assetId]);
  const exists = async (id: string) => (await admin.query<{ c: string }>('SELECT count(*) AS c FROM assets WHERE id = $1::uuid', [id])).rows[0]!.c === '1';
  const coverOf = async () => (await admin.query<{ c: string | null }>('SELECT cover_asset_id AS c FROM showrooms WHERE id = $1::bigint', [showroom])).rows[0]!.c;

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    repo = createPgAuditRepository(app);
    dealer = await newUser('dealer');
    showroom = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', 'active') RETURNING id`, [dealer])).rows[0]!.id);
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('UPDATE showrooms SET cover_asset_id = NULL WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM showrooms WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  it('listReady: ready rows only, referenced and age decided by the database', async () => {
    const old = await readyAsset(48);
    const cover = await readyAsset(48);
    await setCover(cover.id);
    const pending = String((await admin.query<{ id: string }>(`INSERT INTO assets (owner_id, kind, status, storage_key, bytes, width, height, sha256) VALUES ($1::bigint, 'showroom_cover', 'pending', $2, 10, 4, 3, $3) RETURNING id`, [dealer, `incoming/showroom_cover/${randomUUID()}`, 'b'.repeat(64)])).rows[0]!.id);
    const rows = (await repo.listReady({ afterId: null, limit: 1000 })).filter((r) => [old.id, cover.id, pending].includes(r.id));
    assert.deepEqual(rows.map((r) => r.id).sort(), [old.id, cover.id].sort(), 'the pending row is not listed');
    const byId = new Map(rows.map((r) => [r.id, r]));
    assert.equal(byId.get(old.id)!.referenced, false);
    assert.equal(byId.get(cover.id)!.referenced, true);
    assert.ok(byId.get(old.id)!.ageSeconds > 47 * 3600 && byId.get(old.id)!.ageSeconds < 49 * 3600);
    assert.equal(byId.get(old.id)!.sha256, sha(MAIN));
    assert.equal(byId.get(old.id)!.bytes, MAIN.byteLength);
    const one = await repo.listReady({ afterId: null, limit: 1 });
    assert.equal(one.length, 1);
    await setCover(null);
  });

  it('deleteUnlinked removes only a ready, unreferenced, old row with the keys the audit read', async () => {
    const referenced = await readyAsset(48);
    const young = await readyAsset(1);
    const old = await readyAsset(48);
    await setCover(referenced.id);
    const del = (a: { id: string; key: string; thumbKey: string }, o: { key?: string; grace?: number } = {}) => repo.deleteUnlinked({ id: a.id, storageKey: o.key ?? a.key, thumbKey: a.thumbKey, graceSeconds: o.grace ?? DAY * 3600 });
    assert.equal(await del(referenced), false, 'a showroom cover is never removed');
    assert.equal(await del(young), false, 'inside the grace period');
    assert.equal(await del(old, { key: old.key + 'x' }), false, 'the keys must be the ones that were read');
    assert.equal(await del(old, { grace: 72 * 3600 }), false, 'a longer grace period protects it');
    assert.equal(await exists(referenced.id) && (await exists(young.id)) && (await exists(old.id)), true);
    assert.equal(await del(old), true);
    assert.equal(await exists(old.id), false);
    assert.equal(await del(old), false, 'repeat-safe');
    assert.equal(await coverOf(), referenced.id);
    await setCover(null);
    // not ready: never
    const pendingId = String((await admin.query<{ id: string }>(`INSERT INTO assets (owner_id, kind, status, storage_key, bytes, width, height, sha256, created_at) VALUES ($1::bigint, 'showroom_cover', 'pending', $2, 10, 4, 3, $3, now() - interval '100 hours') RETURNING id`, [dealer, `incoming/showroom_cover/${randomUUID()}`, 'b'.repeat(64)])).rows[0]!.id);
    assert.equal(await repo.deleteUnlinked({ id: pendingId, storageKey: null, thumbKey: null, graceSeconds: DAY * 3600 }), false);
    assert.equal(await exists(pendingId), true);
  });

  it('a cover attached concurrently is never cleared: the delete waits for the attach and then refuses', async () => {
    const a = await readyAsset(48);
    let attached!: () => void;
    const holding = new Promise<void>((resolve) => { attached = resolve; });
    // The attacher updates the cover (taking the foreign key's share lock on the asset) and holds its transaction open.
    const attacher = admin.tx(async (t) => {
      await t.query('UPDATE showrooms SET cover_asset_id = $2::uuid WHERE id = $1::bigint', [showroom, a.id]);
      attached();
      await new Promise((r) => setTimeout(r, 1500));
    });
    await holding;
    const started = Date.now();
    const removed = await repo.deleteUnlinked({ id: a.id, storageKey: a.key, thumbKey: a.thumbKey, graceSeconds: DAY * 3600 });
    await attacher;
    assert.equal(removed, false);
    assert.ok(Date.now() - started >= 1000, 'the delete waited for the attacher instead of racing it');
    assert.equal(await exists(a.id), true);
    assert.equal(await coverOf(), a.id, 'the live cover is intact');
    await setCover(null);
  });

  it('a whole run: reports a damaged referenced asset without touching it, deletes the old unlinked one and its objects', async () => {
    const damaged = await readyAsset(72, { objects: false }); // referenced by the cover, its objects are gone
    const garbage = await readyAsset(72);                     // unlinked, old
    const fresh = await readyAsset(2);                        // unlinked, inside the grace period
    await setCover(damaged.id);
    const mine = new Set([damaged.id, garbage.id, fresh.id]);
    // Only this test's own rows are audited, so a shared database cannot be touched by the run.
    const scoped: AuditRepository = { ...repo, async listReady(i) { return (await repo.listReady(i)).filter((r) => mine.has(r.id)); } };
    const dry = await runAssetAudit({ repo: scoped, storage, sleep: async () => {} }, { batchSize: 1000, orphans: false });
    assert.equal(dry.assets!.missing, 1);
    assert.equal(dry.findings, true);
    assert.deepEqual(dry.assets!.referencedProblems, [{ assetId: damaged.id, problem: 'missing' }]);
    assert.equal(dry.deletion.mode, 'dry_run');
    assert.equal(await exists(garbage.id), true);
    const run = await runAssetAudit({ repo: scoped, storage, sleep: async () => {} }, { batchSize: 1000, orphans: false, dryRun: false });
    assert.equal(run.deletion.assetsDeleted, 1);
    assert.equal(await exists(garbage.id), false);
    assert.equal(await storage.exists(garbage.key), false);
    assert.equal(await storage.exists(garbage.thumbKey), false);
    assert.equal(await exists(damaged.id), true, 'the damaged referenced asset is untouched');
    assert.equal(await coverOf(), damaged.id);
    assert.equal(await exists(fresh.id), true);
    assert.equal(await storage.exists(fresh.key), true);
    await setCover(null);
  });
});

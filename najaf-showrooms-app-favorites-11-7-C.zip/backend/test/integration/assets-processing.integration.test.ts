// Image processing (Phase 11.6.3) end to end against a real PostgreSQL 16 (application role) with the PRODUCTION codec (sharp)
// and the in-memory storage provider. Needs DATABASE_URL/ADMIN_DATABASE_URL and sharp (installed by `npm install` in CI); each
// missing piece skips the suite visibly. Proves: the ready row satisfies the table's CHECKs, the stored objects are clean
// oriented WebP without EXIF/GPS, the original is removed, a ready asset can be attached to a car, a bad image is rejected with a
// reason, and a second attempt never overwrites a processed asset.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import type { ImageCodec } from '../../src/assets/codec.ts';
import { createPgProcessingRepository } from '../../src/assets/processing-repository.ts';
import { createAssetProcessor } from '../../src/assets/processing-service.ts';
import { createPgAssetStore } from '../../src/assets/repository.ts';
import { createAssetService } from '../../src/assets/service.ts';
import { inspectWebp } from '../../src/assets/webp-inspect.ts';
import { createPgCarImageStore } from '../../src/car-images/repository.ts';
import { createCarImageService } from '../../src/car-images/service.ts';
import { createMemoryStorage } from '../../src/storage/index.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

let codec: ImageCodec | null = null;
let sharpMissing: string | false = false;
try {
  codec = (await import('../../src/assets/sharp-codec.ts')).createSharpCodec();
} catch (e) {
  sharpMissing = `sharp is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const PROC = join(import.meta.dirname, '..', 'fixtures', 'processing');
const EXIF_JPG = new Uint8Array(readFileSync(join(PROC, 'exif-gps-orient6-64x32.jpg')));
const CORRUPT_PNG = new Uint8Array(readFileSync(join(PROC, 'corrupt-idat-32x32.png')));

describe('image processing on PostgreSQL 16 with sharp', { skip: skip || sharpMissing }, () => {
  let app: Db;
  let admin: Db;
  const userIds: string[] = [];
  let M: Actor;

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, 'user', 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`, [phone]);
    M = { id: String(r.rows[0]!.id), role: 'member' };
    userIds.push(M.id);
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM car_images WHERE car_id IN (SELECT id FROM cars WHERE owner_id = ANY($1::bigint[]))', [userIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  const setup = () => {
    const storage = createMemoryStorage();
    const processor = createAssetProcessor({ repo: createPgProcessingRepository(app), storage, codec: codec! });
    const svc = createAssetService({ store: createPgAssetStore(app), storage, processor });
    return { storage, processor, svc };
  };

  it('upload -> ready: a clean, oriented WebP and thumbnail, the row meets the ready CHECK, the original is gone, the asset attaches to a car', async () => {
    const { storage, svc } = setup();
    const a = await svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/jpeg', body: EXIF_JPG });
    assert.deepEqual([a.status, a.width, a.height], ['ready', 32, 64]);
    const row = (await admin.query<Record<string, unknown>>('SELECT status, storage_key, thumb_key, mime, bytes, sha256, ready_at FROM assets WHERE id = $1::uuid', [a.id])).rows[0]!;
    assert.equal(row['mime'], 'image/webp');
    assert.match(String(row['storage_key']), /^processed\/car_image\/[0-9a-f-]{36}\.webp$/);
    assert.match(String(row['thumb_key']), /^thumbs\/car_image\/[0-9a-f-]{36}\.webp$/);
    assert.notEqual(row['ready_at'], null);
    for (const key of [String(row['storage_key']), String(row['thumb_key'])]) {
      const o = (await storage.get(key))!;
      assert.ok(inspectWebp(o.body), key);
      for (const s of ['SECRETCAM', 'GPS', 'Exif']) assert.ok(!Buffer.from(o.body).toString('latin1').includes(s));
    }
    assert.deepEqual(storage.keys().filter((k) => k.startsWith('incoming/')), []);
    const car = String((await admin.query<{ id: string }>(`INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status) VALUES ('member', $1::bigint, 'Kia', 'Rio', 2018, 9000, 'USD', '+9647701234567', 'النجف', 'pending') RETURNING id`, [M.id])).rows[0]!.id);
    const image = await createCarImageService({ store: createPgCarImageStore(app) }).add(M, car, { assetId: a.id });
    assert.equal(image.isMain, true);
  });

  it('a corrupt image is rejected with a reason code; nothing is left in storage; a second attempt never changes a processed asset', async () => {
    const { storage, processor, svc } = setup();
    const a = await svc.upload(M, { query: { kind: 'car_image' }, contentType: 'image/png', body: CORRUPT_PNG });
    assert.equal(a.status, 'rejected');
    const row = (await admin.query<{ reject_reason: string }>('SELECT reject_reason FROM assets WHERE id = $1::uuid', [a.id])).rows[0]!;
    assert.equal(row.reject_reason, 'invalid_image');
    assert.equal(storage.size(), 0);
    assert.deepEqual(await processor.process(a.id), { result: 'skipped', asset: null, reason: 'not_pending' });
  });
});

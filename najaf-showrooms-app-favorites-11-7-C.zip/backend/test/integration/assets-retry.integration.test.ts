// Phase 11.6.5 against a real PostgreSQL 16 (application role): the retry query of the cleanup job selects exactly the pending
// assets inside the window (database clock), oldest first, bounded; the processing repository's compare-and-swap then makes a
// retried asset ready exactly once. Needs DATABASE_URL and ADMIN_DATABASE_URL; without them the suite is skipped visibly.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt, randomUUID } from 'node:crypto';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgCleanupRepository } from '../../src/assets/cleanup-repository.ts';
import { createPgProcessingRepository } from '../../src/assets/processing-repository.ts';
import { derivedKeys } from '../../src/assets/processing-service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

describe('asset retry window on PostgreSQL 16', { skip }, () => {
  let app: Db;
  let admin: Db;
  let owner: string;

  const asset = async (status: 'pending' | 'ready' | 'rejected', ageMinutes: number): Promise<{ id: string; key: string }> => {
    const u = randomUUID();
    const key = status === 'ready' ? `processed/car_image/${u}.webp` : `incoming/car_image/${u}`;
    const r = await admin.query<{ id: string }>(
      status === 'ready'
        ? `INSERT INTO assets (owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at, created_at)
           VALUES ($1::bigint, 'car_image', 'ready', $2, $3, 'image/webp', 10, 4, 3, $4, now(), now() - make_interval(mins => $5)) RETURNING id`
        : `INSERT INTO assets (owner_id, kind, status, storage_key, bytes, width, height, sha256, reject_reason, created_at)
           VALUES ($1::bigint, 'car_image', $6, $2, 10, 4, 3, $4, $3, now() - make_interval(mins => $5)) RETURNING id`,
      status === 'ready'
        ? [owner, key, `thumbs/car_image/${u}.webp`, 'a'.repeat(64), ageMinutes]
        : [owner, key, status === 'rejected' ? 'invalid_image' : null, 'b'.repeat(64), ageMinutes, status],
    );
    return { id: String(r.rows[0]!.id), key };
  };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    owner = String((await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, 'user', 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`, [phone])).rows[0]!.id);
  });
  after(async () => {
    if (admin && owner) {
      await admin.query('DELETE FROM assets WHERE owner_id = $1::bigint', [owner]);
      await admin.query('DELETE FROM users WHERE id = $1::bigint', [owner]);
    }
    await app?.close();
    await admin?.close();
  });

  it('selects pending assets older than the minimum and younger than the threshold, oldest first, at most `limit`', async () => {
    const repo = createPgCleanupRepository(app);
    const young = await asset('pending', 5);
    const p20 = await asset('pending', 20);
    const p120 = await asset('pending', 120);
    const stale = await asset('pending', 25 * 60);
    const ready = await asset('ready', 120);
    const rejected = await asset('rejected', 120);
    const mine = new Set([young.id, p20.id, p120.id, stale.id, ready.id, rejected.id]);
    const ids = (await repo.listRetryable({ minAgeSeconds: 15 * 60, maxAgeSeconds: 24 * 3600, limit: 200 })).filter((id) => mine.has(id));
    assert.deepEqual(ids, [p120.id, p20.id]);
    const one = await repo.listRetryable({ minAgeSeconds: 15 * 60, maxAgeSeconds: 24 * 3600, limit: 1 });
    assert.equal(one.length, 1);
    // The windows of retry (age < threshold) and of phase 1 (age > threshold) never overlap.
    const staleIds = (await repo.listStale({ olderThanSeconds: 24 * 3600, afterId: null, limit: 1000 })).map((r) => r.id).filter((id) => mine.has(id));
    assert.deepEqual(staleIds, [stale.id]);
  });

  it('a retried asset becomes ready exactly once (the second compare-and-swap finds nothing)', async () => {
    const repo = createPgProcessingRepository(app);
    const p = await asset('pending', 30);
    const keys = derivedKeys(p.key)!;
    const input = { id: p.id, originalKey: keys.original, mainKey: keys.main, thumbKey: keys.thumb, bytes: 20, width: 4, height: 3, sha256: 'c'.repeat(64) };
    const first = await repo.markReady(input);
    assert.equal(first?.status, 'ready');
    assert.equal(await repo.markReady(input), null);
    assert.equal(await repo.markRejected({ id: p.id, originalKey: keys.original, reason: 'invalid_image' }), null);
  });
});

// Test-only ImageCodec backed by Pillow (python3 test/helpers/pil_codec.py), so the processing pipeline runs against a REAL decoder
// and WebP encoder where sharp is not installed. `pilAvailable` lets suites skip visibly where Python/Pillow are missing.
import { spawn, spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { CodecError } from '../../src/assets/codec.ts';
import type { CodecErrorCode, ImageCodec } from '../../src/assets/codec.ts';

const SCRIPT = join(import.meta.dirname, 'pil_codec.py');

export const pilAvailable: boolean = (() => {
  try {
    return spawnSync('python3', ['-c', 'from PIL import features; import sys; sys.exit(0 if features.check("webp") else 1)'], { timeout: 20_000 }).status === 0;
  } catch {
    return false;
  }
})();

function call(args: Record<string, unknown>, input: Uint8Array, timeoutMs: number): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    const child = spawn('python3', ['-I', SCRIPT, JSON.stringify(args)], { stdio: ['pipe', 'pipe', 'pipe'] });
    const chunks: Buffer[] = [];
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new CodecError('timeout'));
    }, timeoutMs);
    child.stdout.on('data', (c: Buffer) => chunks.push(c));
    child.on('error', () => reject(new CodecError('invalid_image')));
    child.on('close', () => {
      clearTimeout(timer);
      try {
        const r = JSON.parse(Buffer.concat(chunks).toString('utf8')) as Record<string, unknown>;
        if (typeof r['error'] === 'string') reject(new CodecError(r['error'] as CodecErrorCode));
        else resolve(r);
      } catch {
        reject(new CodecError('invalid_image'));
      }
    });
    child.stdin.on('error', () => undefined);
    child.stdin.end(Buffer.from(input));
  });
}

export function createPilCodec(): ImageCodec {
  return {
    name: 'pillow',
    async probe(input, opts) {
      const r = await call({ op: 'probe', maxInputPixels: opts.maxInputPixels }, input, 20_000);
      return { format: r['format'] as 'jpeg' | 'png' | 'webp', width: Number(r['width']), height: Number(r['height']), pages: Number(r['pages']) };
    },
    async render(input, opts) {
      const r = await call({ op: 'render', maxInputPixels: opts.maxInputPixels, maxSide: opts.maxSide, quality: opts.quality }, input, opts.timeoutMs);
      return { data: new Uint8Array(Buffer.from(String(r['data']), 'base64')), width: Number(r['width']), height: Number(r['height']) };
    },
  };
}

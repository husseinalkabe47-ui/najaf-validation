// In-memory CleanupRepository (Phase 11.6.4). Mirrors, independently of src, what the SQL does: stale = pending/rejected, older
// than the threshold (by the "database" clock), referenced by nothing; the delete is a compare-and-swap re-checking all of that
// and the storage key; key references = any row's storage_key or thumb_key (any status). Faults and a hook to change a row between
// the listing and the delete (a concurrent processor or attach).
import { DbError } from '../../src/errors.ts';
import type { CleanupRepository } from '../../src/assets/cleanup-repository.ts';

export interface CleanRow {
  id: string;
  status: 'pending' | 'ready' | 'rejected';
  storageKey: string | null;
  thumbKey: string | null;
  createdAt: Date;
  /** Attached to a car or used as a showroom cover. */
  referenced: boolean;
}

export function makeFakeCleanup(clock: { now(): Date }) {
  let rows: CleanRow[] = [];
  const calls: Array<{ op: string; arg?: unknown }> = [];
  const faults: { failListAt: number | null; failDelete: boolean; failRefs: boolean; beforeDelete: ((row: CleanRow) => void) | null; nonDbError: boolean; failRetryList: boolean } = {
    failListAt: null, failDelete: false, failRefs: false, beforeDelete: null, nonDbError: false, failRetryList: false,
  };
  let listCalls = 0;
  let n = 0;
  const fail = () => {
    throw faults.nonDbError ? new TypeError('boom') : new DbError('unavailable', { sqlstate: '08006' });
  };
  const stale = (r: CleanRow, olderThanSeconds: number) =>
    (r.status === 'pending' || r.status === 'rejected') && r.createdAt.getTime() < clock.now().getTime() - olderThanSeconds * 1000 && !r.referenced;

  const repo: CleanupRepository = {
    async listStale(i) {
      calls.push({ op: 'listStale', arg: { ...i } });
      if (faults.failListAt !== null && ++listCalls >= faults.failListAt) fail();
      if (!(Number.isInteger(i.limit) && i.limit >= 1 && i.limit <= 1000)) throw new Error('unbounded listing');
      return rows
        .filter((r) => stale(r, i.olderThanSeconds) && (i.afterId === null || r.id > i.afterId))
        .sort((a, b) => (a.id < b.id ? -1 : 1))
        .slice(0, i.limit)
        .map((r) => ({ id: r.id, status: r.status, storageKey: r.storageKey }));
    },
    async deleteStale(i) {
      calls.push({ op: 'deleteStale', arg: i.id });
      if (faults.failDelete) fail();
      const r = rows.find((x) => x.id === i.id);
      if (r && faults.beforeDelete) faults.beforeDelete(r);
      if (!r || !stale(r, i.olderThanSeconds) || r.storageKey !== i.storageKey) return false;
      rows = rows.filter((x) => x !== r);
      return true;
    },
    async findReferencedKeys(keys) {
      calls.push({ op: 'findReferencedKeys', arg: keys.length });
      if (faults.failRefs) fail();
      const set = new Set<string>();
      for (const r of rows) for (const k of [r.storageKey, r.thumbKey]) if (k !== null && keys.includes(k)) set.add(k);
      return set;
    },
    // Phase 11.6.5: pending rows with minAge < age <= maxAge (database clock), oldest first, bounded.
    async listRetryable(i) {
      calls.push({ op: 'listRetryable', arg: { ...i } });
      if (faults.failRetryList) fail();
      if (!(Number.isInteger(i.limit) && i.limit >= 1 && i.limit <= 200)) throw new Error('unbounded retry listing');
      const t = clock.now().getTime();
      return rows
        .filter((r) => r.status === 'pending' && r.createdAt.getTime() < t - i.minAgeSeconds * 1000 && r.createdAt.getTime() >= t - i.maxAgeSeconds * 1000)
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime() || (a.id < b.id ? -1 : 1))
        .slice(0, i.limit)
        .map((r) => r.id);
    },
  };

  return {
    repo,
    calls,
    faults,
    rows: () => rows,
    add(fields: Partial<CleanRow>): CleanRow {
      const r: CleanRow = { id: `a0000000-0000-4000-8000-${String(++n).padStart(12, '0')}`, status: 'pending', storageKey: null, thumbKey: null, createdAt: clock.now(), referenced: false, ...fields };
      rows.push(r);
      return r;
    },
  };
}

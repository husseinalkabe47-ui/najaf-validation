# Reference image codec for TESTS ONLY (Phase 11.6.3): implements the ImageCodec contract with Pillow, so the processing rules can
# be exercised against a real decoder/encoder where sharp is not installed. Never used by the server.
# argv[1] = JSON {op: probe|render, maxInputPixels, maxSide?, quality?}; stdin = image bytes; stdout = one JSON line.
import base64, io, json, sys
from PIL import Image, ImageOps

def out(obj):
    sys.stdout.write(json.dumps(obj))
    sys.exit(0)

args = json.loads(sys.argv[1])
data = sys.stdin.buffer.read()
Image.MAX_IMAGE_PIXELS = None  # the limit below is applied from the header, before any pixel is decoded
try:
    im = Image.open(io.BytesIO(data))
except Exception:
    out({'error': 'invalid_image'})
fmt = {'JPEG': 'jpeg', 'PNG': 'png', 'WEBP': 'webp'}.get(im.format)
if fmt is None:
    out({'error': 'unsupported'})
w, h = im.size
if w * h > args['maxInputPixels']:
    out({'error': 'too_large'})
pages = getattr(im, 'n_frames', 1)
if args['op'] == 'probe':
    out({'format': fmt, 'width': w, 'height': h, 'pages': pages})
try:
    im.load()                       # full decode: truncated or corrupt data raises
    im = ImageOps.exif_transpose(im)  # apply the EXIF orientation
    alpha = 'A' in im.getbands() or (im.mode == 'P' and 'transparency' in im.info)
    im = im.convert('RGBA' if alpha else 'RGB')
    im.info = {}                    # drop every metadata item (EXIF, ICC, XMP, text)
    im.thumbnail((args['maxSide'], args['maxSide']))  # fit inside, keep aspect, never enlarge
    buf = io.BytesIO()
    im.save(buf, 'WEBP', quality=args['quality'], method=4)
except Exception:
    out({'error': 'invalid_image'})
out({'data': base64.b64encode(buf.getvalue()).decode('ascii'), 'width': im.size[0], 'height': im.size[1]})

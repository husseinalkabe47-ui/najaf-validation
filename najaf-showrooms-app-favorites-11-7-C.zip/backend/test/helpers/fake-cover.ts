// In-memory CoverStore (Phase 11.6.4). Mirrors, independently of src, the SQL scoping and the database's showrooms_cover_guard:
//  - the showroom is found by owner; the asset by owner; the acting account must be active and not deleted;
//  - setCover THROWS like the trigger if the service ever let a bad cover through: not a ready showroom_cover -> DbError('check'),
//    another user's asset (not an administrator's) -> DbError('forbidden');
//  - transactions are all-or-nothing (snapshot/restore) and serialized; every write is recorded.
import { DbError } from '../../src/errors.ts';
import type { CoverAssetRow, CoverRepository, CoverShowroomRow, CoverStore } from '../../src/assets/cover-repository.ts';

export interface CoverWorldAsset {
  id: string;
  ownerId: string;
  kind: string;
  status: string;
  storageKey: string | null;
  thumbKey: string | null;
  width: number | null;
  height: number | null;
}

export function makeFakeCoverStore() {
  const users = new Map<string, { status: string; deleted: boolean; role: string }>();
  let showrooms: CoverShowroomRow[] = [];
  const assets: CoverWorldAsset[] = [];
  const calls: string[] = [];
  const writes: Array<{ showroomId: string; assetId: string | null }> = [];
  const faults: { guard: 'none' | 'check' | 'forbidden'; failSet: boolean; failLock: boolean } = { guard: 'none', failSet: false, failLock: false };
  let n = 0;

  const toAsset = (a: CoverWorldAsset): CoverAssetRow => ({
    id: a.id, kind: a.kind, status: a.status, width: a.width, height: a.height,
    servable: a.storageKey !== null && a.thumbKey !== null && !a.storageKey.startsWith('incoming/') && !a.thumbKey.startsWith('incoming/'),
  });

  const repo: CoverRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      const u = users.get(userId);
      return u !== undefined && u.status === 'active' && !u.deleted;
    },
    async lockOwnShowroom(ownerId) {
      calls.push('lockOwnShowroom');
      if (faults.failLock) throw new DbError('unavailable', { sqlstate: '08006' });
      const s = showrooms.find((x) => x.ownerId === ownerId);
      return s ? { ...s } : null;
    },
    async findOwnAsset(assetId, ownerId) {
      calls.push('findOwnAsset');
      const a = assets.find((x) => x.id === assetId && x.ownerId === ownerId);
      return a ? toAsset(a) : null;
    },
    async setCover(showroomId, ownerId, assetId) {
      calls.push('setCover');
      if (faults.failSet) throw new DbError('unavailable', { sqlstate: '08006' });
      const s = showrooms.find((x) => x.id === showroomId && x.ownerId === ownerId);
      if (!s) return false;
      if (assetId !== null) {
        if (faults.guard === 'check') throw new DbError('check', { sqlstate: '23514' });
        if (faults.guard === 'forbidden') throw new DbError('forbidden', { sqlstate: '42501' });
        const a = assets.find((x) => x.id === assetId);
        if (!a || a.kind !== 'showroom_cover' || a.status !== 'ready') throw new DbError('check', { sqlstate: '23514' });
        if (a.ownerId !== s.ownerId && users.get(a.ownerId)?.role !== 'admin') throw new DbError('forbidden', { sqlstate: '42501' });
      }
      s.coverAssetId = assetId;
      writes.push({ showroomId, assetId });
      return true;
    },
    async findOwnCover(ownerId) {
      calls.push('findOwnCover');
      const s = showrooms.find((x) => x.ownerId === ownerId);
      if (!s) return null;
      const a = s.coverAssetId === null ? undefined : assets.find((x) => x.id === s.coverAssetId);
      return { showroom: { ...s }, cover: s.coverAssetId === null ? null : { assetId: s.coverAssetId, width: a?.width ?? null, height: a?.height ?? null } };
    },
  };

  let chain: Promise<unknown> = Promise.resolve();
  const store: CoverStore = {
    covers: repo,
    transaction(fn) {
      const run = async () => {
        const snap = showrooms.map((s) => ({ ...s }));
        const w = writes.length;
        try {
          return await fn({ covers: repo });
        } catch (e) {
          showrooms = snap;
          writes.length = w;
          throw e;
        }
      };
      const result = chain.then(run, run);
      chain = result.catch(() => undefined);
      return result;
    },
  };

  return {
    store,
    calls,
    writes,
    faults,
    showrooms: () => showrooms,
    addUser(id: string, role = 'dealer', status = 'active', deleted = false) {
      users.set(id, { role, status, deleted });
    },
    addShowroom(ownerId: string, status = 'active', coverAssetId: string | null = null): CoverShowroomRow {
      const s = { id: String(500 + ++n), ownerId, status, coverAssetId };
      showrooms.push(s);
      return s;
    },
    addAsset(fields: Partial<CoverWorldAsset> & { ownerId: string }): CoverWorldAsset {
      const uuid = `e0000000-0000-4000-8000-${String(++n).padStart(12, '0')}`;
      const kind = fields.kind ?? 'showroom_cover';
      const a: CoverWorldAsset = { id: `f0000000-0000-4000-8000-${String(n).padStart(12, '0')}`, kind, status: 'ready', storageKey: `processed/${kind}/${uuid}.webp`, thumbKey: `thumbs/${kind}/${uuid}.webp`, width: 1600, height: 900, ...fields };
      assets.push(a);
      return a;
    },
  };
}
export type FakeCoverStore = ReturnType<typeof makeFakeCoverStore>;

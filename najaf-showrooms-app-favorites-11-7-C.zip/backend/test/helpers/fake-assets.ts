// In-memory stand-in for the asset store (Phase 11.6.2). It mirrors, independently of src, what the SQL and the database do:
//  - reads and the compensating delete are scoped by owner; the delete only removes an unreferenced 'pending' row;
//  - CHECK/UNIQUE backstops that THROW if the service ever let a violation through: kind vocabulary, status 'pending' on insert,
//    mime never set (only image/webp is legal and only after processing), bytes > 0, sha256 hex, dimensions within smallint, unique
//    storage_key, a safe storage key;
//  - transactions are all-or-nothing (snapshot/restore) and SERIALIZED (a stand-in for the per-owner advisory lock).
import { DbError } from '../../src/errors.ts';
import type { AssetRepository, AssetRow, AssetStore } from '../../src/assets/repository.ts';
import { isSafeKey } from '../../src/storage/index.ts';

export interface FakeAsset {
  id: string;
  ownerId: string;
  kind: string;
  status: string;
  storageKey: string | null;
  bytes: number | null;
  width: number | null;
  height: number | null;
  sha256: string | null;
  mime: string | null;
  createdAt: Date;
}

export function makeFakeAssetStore(opts: { userState?: (id: string) => { status: string; deleted: boolean } | undefined; now?: () => Date } = {}) {
  const users = new Map<string, { status: string; deleted: boolean }>();
  let assets: FakeAsset[] = [];
  const referenced = new Set<string>();
  const calls: string[] = [];
  const faults: { failInsert: boolean; failDelete: boolean } = { failInsert: false, failDelete: false };
  let n = 0;
  const now = opts.now ?? (() => new Date());
  let slotLocked = false; // per transaction (transactions are serialized)
  const live = (id: string) => {
    const u = (opts.userState ?? ((x: string) => users.get(x)))(id);
    return u !== undefined && u.status === 'active' && !u.deleted;
  };
  const view = (a: FakeAsset): AssetRow => ({ id: a.id, kind: a.kind, status: a.status, bytes: a.bytes, width: a.width, height: a.height, createdAt: a.createdAt });

  const repo: AssetRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      return live(userId);
    },
    async lockUploadSlot() {
      calls.push('lockUploadSlot');
      slotLocked = true;
    },
    async countRecentPending(ownerId) {
      calls.push('countRecentPending');
      // The quota is only meaningful under the owner's lock (two concurrent uploads would both see room otherwise).
      if (!slotLocked) throw new Error('the upload quota was counted without holding the owner upload lock');
      const since = now().getTime() - 24 * 3600 * 1000;
      return assets.filter((a) => a.ownerId === ownerId && a.status === 'pending' && a.createdAt.getTime() > since).length;
    },
    async insertPending(a) {
      calls.push('insertPending');
      if (faults.failInsert) throw new DbError('unavailable', { sqlstate: '08006' });
      if (!['car_image', 'showroom_cover'].includes(a.kind)) throw new DbError('check', { sqlstate: '23514', constraint: 'assets_kind_vocab' });
      if (!(a.bytes > 0)) throw new DbError('check', { sqlstate: '23514', constraint: 'assets_bytes_pos' });
      if (!/^[0-9a-f]{64}$/.test(a.sha256)) throw new DbError('check', { sqlstate: '23514', constraint: 'assets_sha256_hex' });
      if (!(a.width > 0 && a.height > 0 && a.width <= 32767 && a.height <= 32767)) throw new DbError('check', { sqlstate: '23514', constraint: 'assets_dims_pos' });
      if (!isSafeKey(a.storageKey)) throw new Error('unsafe storage key reached the database');
      if (assets.some((x) => x.storageKey === a.storageKey)) throw new DbError('unique', { sqlstate: '23505', constraint: 'assets_storage_key_uq' });
      const row: FakeAsset = { id: `a0000000-0000-4000-8000-${String(++n).padStart(12, '0')}`, ownerId: a.ownerId, kind: a.kind, status: 'pending', storageKey: a.storageKey, bytes: a.bytes, width: a.width, height: a.height, sha256: a.sha256, mime: null, createdAt: now() };
      assets.push(row);
      return view(row);
    },
    async deletePendingOwn(id, ownerId) {
      calls.push('deletePendingOwn');
      if (faults.failDelete) throw new DbError('unavailable', { sqlstate: '08006' });
      const before = assets.length;
      assets = assets.filter((a) => !(a.id === id && a.ownerId === ownerId && a.status === 'pending' && !referenced.has(a.id)));
      return assets.length < before;
    },
    async findOwn(id, ownerId) {
      calls.push('findOwn');
      const a = assets.find((x) => x.id === id && x.ownerId === ownerId);
      return a ? view(a) : null;
    },
  };

  let chain: Promise<unknown> = Promise.resolve();
  const store: AssetStore = {
    assets: repo,
    transaction(fn) {
      const run = async () => {
        const snap = assets.map((a) => ({ ...a }));
        slotLocked = false;
        try {
          return await fn({ assets: repo });
        } catch (e) {
          assets = snap;
          throw e;
        } finally {
          slotLocked = false;
        }
      };
      const result = chain.then(run, run);
      chain = result.catch(() => undefined);
      return result;
    },
  };

  return {
    store,
    calls,
    faults,
    rows: () => assets,
    addUser(id: string, status = 'active', deleted = false) {
      users.set(id, { status, deleted });
    },
    setUser(id: string, status: string, deleted = false) {
      users.set(id, { status, deleted });
    },
    /** Fixture: an existing asset (e.g. older, or already processed). */
    addAsset(fields: Partial<FakeAsset> & { ownerId: string }): FakeAsset {
      const a: FakeAsset = { id: `b0000000-0000-4000-8000-${String(++n).padStart(12, '0')}`, kind: 'car_image', status: 'pending', storageKey: `incoming/car_image/fixture-${n}`, bytes: 10, width: 1, height: 1, sha256: '0'.repeat(64), mime: null, createdAt: now(), ...fields };
      assets.push(a);
      return a;
    },
    reference(id: string) {
      referenced.add(id);
    },
  };
}
export type FakeAssetStore = ReturnType<typeof makeFakeAssetStore>;

// In-memory ProcessingRepository (Phase 11.6.3) over the SAME rows as the asset fake store (fake-assets.ts), mirroring the SQL:
// compare-and-swap on (status = 'pending' AND storage_key = original), and the assets_ready_shape / assets_rejected_why /
// assets_mime_vocab CHECKs as backstops that THROW if the service ever tried to write an invalid row.
import { DbError } from '../../src/errors.ts';
import type { ProcessingRepository } from '../../src/assets/processing-repository.ts';
import type { AssetRow } from '../../src/assets/repository.ts';
import type { FakeAsset, FakeAssetStore } from './fake-assets.ts';

export type ProcessedFakeAsset = FakeAsset & { thumbKey?: string | null; readyAt?: Date | null; rejectReason?: string | null };

export function makeFakeProcessingRepo(fa: FakeAssetStore) {
  const faults: { failFind: boolean; failMarkReady: 'no' | 'throw' | 'throw_after_commit'; deleteRowBeforeMarkReady: boolean; otherProcessorWins: boolean; failMarkRejected: boolean } = {
    failFind: false, failMarkReady: 'no', deleteRowBeforeMarkReady: false, otherProcessorWins: false, failMarkRejected: false,
  };
  const calls: string[] = [];
  const view = (a: FakeAsset): AssetRow => ({ id: a.id, kind: a.kind, status: a.status, bytes: a.bytes, width: a.width, height: a.height, createdAt: a.createdAt });
  const row = (id: string) => fa.rows().find((a) => a.id === id) as ProcessedFakeAsset | undefined;

  const repo: ProcessingRepository = {
    async findForProcessing(id, ownerId) {
      calls.push('findForProcessing');
      if (faults.failFind) throw new DbError('unavailable', { sqlstate: '08006' });
      const a = row(id);
      if (!a || (ownerId !== null && a.ownerId !== ownerId)) return null;
      return { id: a.id, ownerId: a.ownerId, kind: a.kind, status: a.status, storageKey: a.storageKey, bytes: a.bytes, sha256: a.sha256 };
    },
    async markReady(i) {
      calls.push('markReady');
      if (faults.deleteRowBeforeMarkReady) fa.rows().splice(fa.rows().findIndex((a) => a.id === i.id), 1);
      // Another processor (another instance) finished the same asset first, with the same derived keys.
      if (faults.otherProcessorWins) Object.assign(row(i.id)!, { status: 'ready', storageKey: i.mainKey, thumbKey: i.thumbKey, mime: 'image/webp' });
      if (faults.failMarkReady === 'throw') throw new DbError('unavailable', { sqlstate: '08006' });
      const a = row(i.id);
      if (!a || a.status !== 'pending' || a.storageKey !== i.originalKey) return null;
      if (!(i.bytes > 0) || !(i.width > 0) || !(i.height > 0) || !/^[0-9a-f]{64}$/.test(i.sha256) || !i.mainKey || !i.thumbKey) throw new DbError('check', { sqlstate: '23514', constraint: 'assets_ready_shape' });
      if (fa.rows().some((x) => x.id !== a.id && (x.storageKey === i.mainKey))) throw new DbError('unique', { sqlstate: '23505', constraint: 'assets_storage_key_uq' });
      Object.assign(a, { status: 'ready', storageKey: i.mainKey, thumbKey: i.thumbKey, mime: 'image/webp', bytes: i.bytes, width: i.width, height: i.height, sha256: i.sha256, readyAt: new Date() });
      if (faults.failMarkReady === 'throw_after_commit') throw new DbError('unavailable', { sqlstate: '08006' });
      return view(a);
    },
    async markRejected(i) {
      calls.push('markRejected');
      if (faults.failMarkRejected) throw new DbError('unavailable', { sqlstate: '08006' });
      const a = row(i.id);
      if (!a || a.status !== 'pending' || a.storageKey !== i.originalKey) return null;
      if (!i.reason || i.reason.length > 200) throw new DbError('check', { sqlstate: '23514', constraint: 'assets_rejected_why' });
      Object.assign(a, { status: 'rejected', rejectReason: i.reason });
      return view(a);
    },
  };
  return { repo, faults, calls, row };
}

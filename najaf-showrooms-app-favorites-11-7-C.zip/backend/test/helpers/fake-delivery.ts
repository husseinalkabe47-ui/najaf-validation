// In-memory DeliveryRepository (Phase 11.6.4) over a small world (assets, cars, car images, showrooms). It mirrors, independently
// of src, what the SQL decides: PUBLIC = a ready asset that is a car_image attached to a public car, or a showroom_cover that is the
// cover of a public showroom ("public" stands for "in the public_cars / public_showrooms view"); OWNER = the owner's ready asset.
import { DbError } from '../../src/errors.ts';
import type { DeliverableAsset, DeliveryRepository } from '../../src/assets/delivery-repository.ts';

export interface WorldAsset {
  id: string;
  ownerId: string;
  kind: 'car_image' | 'showroom_cover';
  status: 'pending' | 'ready' | 'rejected';
  storageKey: string | null;
  thumbKey: string | null;
  sha256: string | null;
  width: number | null;
  height: number | null;
}
export interface WorldCar {
  id: string;
  public: boolean;
}
export interface WorldImage {
  id: number;
  carId: string;
  assetId: string;
  isMain: boolean;
  sortOrder: number;
}
export interface WorldShowroom {
  id: string;
  public: boolean;
  coverAssetId: string | null;
}

export function makeFakeDelivery() {
  const assets: WorldAsset[] = [];
  const cars: WorldCar[] = [];
  const images: WorldImage[] = [];
  const showrooms: WorldShowroom[] = [];
  const calls: string[] = [];
  const faults = { fail: false };
  let n = 0;
  const deliverable = (a: WorldAsset | undefined): DeliverableAsset | null =>
    a && a.status === 'ready' && a.storageKey !== null && a.thumbKey !== null && a.sha256 !== null && a.width !== null && a.height !== null
      ? { id: a.id, kind: a.kind, storageKey: a.storageKey, thumbKey: a.thumbKey, sha256: a.sha256, width: a.width, height: a.height }
      : null;
  const check = () => {
    if (faults.fail) throw new DbError('unavailable', { sqlstate: '08006' });
  };
  // Like the SQL casts ($1::uuid, $1::bigint): a malformed id never reaches a query, or it fails.
  const uuid = (v: unknown) => {
    if (typeof v !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v)) throw new DbError('invalid_value', { sqlstate: '22P02' });
  };
  const bigint = (v: unknown) => {
    if (typeof v !== 'string' || !/^[1-9][0-9]{0,18}$/.test(v) || BigInt(v) > 9223372036854775807n) throw new DbError('invalid_value', { sqlstate: '22P02' });
  };

  const repo: DeliveryRepository = {
    async findPublic(assetId) {
      calls.push('findPublic');
      check();
      uuid(assetId);
      const a = assets.find((x) => x.id === assetId);
      if (!a || a.status !== 'ready') return null;
      const visible =
        (a.kind === 'car_image' && images.some((i) => i.assetId === a.id && cars.some((c) => c.id === i.carId && c.public))) ||
        (a.kind === 'showroom_cover' && showrooms.some((s) => s.public && s.coverAssetId === a.id));
      return visible ? deliverable(a) : null;
    },
    async findOwnReady(assetId, ownerId) {
      calls.push('findOwnReady');
      check();
      uuid(assetId);
      bigint(ownerId);
      return deliverable(assets.find((x) => x.id === assetId && x.ownerId === ownerId));
    },
    async listPublicCarImages(carId) {
      calls.push('listPublicCarImages');
      check();
      bigint(carId);
      if (!cars.some((c) => c.id === carId && c.public)) return null;
      return images
        .filter((i) => i.carId === carId)
        .map((i) => ({ i, a: assets.find((x) => x.id === i.assetId)! }))
        .filter(({ a }) => a.status === 'ready' && a.kind === 'car_image')
        .sort((x, y) => x.i.sortOrder - y.i.sortOrder || x.i.id - y.i.id)
        .map(({ i, a }) => ({ assetId: a.id, isMain: i.isMain, sortOrder: i.sortOrder, width: a.width!, height: a.height! }));
    },
    async findPublicShowroomCover(showroomId) {
      calls.push('findPublicShowroomCover');
      check();
      bigint(showroomId);
      const s = showrooms.find((x) => x.id === showroomId && x.public);
      if (!s) return undefined;
      const a = assets.find((x) => x.id === s.coverAssetId && x.status === 'ready' && x.kind === 'showroom_cover');
      return a ? { assetId: a.id, width: a.width!, height: a.height! } : null;
    },
  };

  return {
    repo,
    calls,
    faults,
    assets,
    cars,
    images,
    showrooms,
    addAsset(fields: Partial<WorldAsset> & { ownerId: string }): WorldAsset {
      const id = `c0000000-0000-4000-8000-${String(++n).padStart(12, '0')}`;
      const uuid = `d0000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
      const kind = fields.kind ?? 'car_image';
      const a: WorldAsset = { id, kind, status: 'ready', storageKey: `processed/${kind}/${uuid}.webp`, thumbKey: `thumbs/${kind}/${uuid}.webp`, sha256: '0'.repeat(64), width: 8, height: 6, ...fields };
      assets.push(a);
      return a;
    },
    addCar(isPublic = true): WorldCar {
      const c = { id: String(1000 + ++n), public: isPublic };
      cars.push(c);
      return c;
    },
    attach(carId: string, assetId: string, isMain = false, sortOrder = 0): void {
      images.push({ id: ++n, carId, assetId, isMain, sortOrder });
    },
    addShowroom(isPublic = true, coverAssetId: string | null = null): WorldShowroom {
      const s = { id: String(2000 + ++n), public: isPublic, coverAssetId };
      showrooms.push(s);
      return s;
    },
  };
}
export type FakeDelivery = ReturnType<typeof makeFakeDelivery>;

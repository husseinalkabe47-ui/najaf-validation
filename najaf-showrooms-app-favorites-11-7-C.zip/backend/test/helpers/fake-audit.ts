// In-memory AuditRepository (Phase 11.6.6). Mirrors, independently of src, what the SQL does: listReady = status 'ready' rows in id
// order (keyset) with `referenced` and the age since ready_at by the "database" clock; deleteUnlinked is a compare-and-swap
// (still ready, same keys, older than the grace period, unreferenced); key references = any row's storage_key or thumb_key (any
// status). Faults and hooks to change a row between the listing and the delete (a concurrent attach).
import { DbError } from '../../src/errors.ts';
import type { AuditAssetRow, AuditRepository } from '../../src/assets/audit-repository.ts';

export interface AuditRow {
  id: string;
  kind: string;
  status: 'pending' | 'ready' | 'rejected';
  storageKey: string | null;
  thumbKey: string | null;
  bytes: number | null;
  width: number | null;
  height: number | null;
  sha256: string | null;
  readyAt: Date | null;
  referenced: boolean;
}

export function makeFakeAudit(clock: { now(): Date }) {
  let rows: AuditRow[] = [];
  const calls: Array<{ op: string; arg?: unknown }> = [];
  const faults: {
    /** Fail every listReady call from the Nth on (1-based). */
    failListFrom: number | null;
    /** Fail the first N listReady calls (transient), then succeed. */
    failListFirst: number;
    failDelete: boolean;
    /** Fail every findReferencedKeys call from the Nth on (1-based). */
    failRefsFrom: number | null;
    failRefsFirst: number;
    nonDbError: boolean;
    beforeDelete: ((row: AuditRow) => void) | null;
    /** Runs after the Nth findReferencedKeys call has computed its answer (to simulate a row appearing meanwhile). */
    afterRefs: ((callNo: number) => void) | null;
  } = { failListFrom: null, failListFirst: 0, failDelete: false, failRefsFrom: null, failRefsFirst: 0, nonDbError: false, beforeDelete: null, afterRefs: null };
  let listCalls = 0;
  let refCalls = 0;
  let n = 0;
  const fail = () => {
    throw faults.nonDbError ? new TypeError('boom') : new DbError('unavailable', { sqlstate: '08006' });
  };
  const age = (r: AuditRow) => (r.readyAt ? (clock.now().getTime() - r.readyAt.getTime()) / 1000 : 0);

  const repo: AuditRepository = {
    async listReady(i) {
      calls.push({ op: 'listReady', arg: { ...i } });
      listCalls++;
      if (listCalls <= faults.failListFirst || (faults.failListFrom !== null && listCalls >= faults.failListFrom)) fail();
      if (!(Number.isInteger(i.limit) && i.limit >= 1 && i.limit <= 1000)) throw new Error('unbounded listing');
      return rows
        .filter((r) => r.status === 'ready' && (i.afterId === null || r.id > i.afterId))
        .sort((a, b) => (a.id < b.id ? -1 : 1))
        .slice(0, i.limit)
        .map((r): AuditAssetRow => ({ id: r.id, kind: r.kind, storageKey: r.storageKey, thumbKey: r.thumbKey, bytes: r.bytes, width: r.width, height: r.height, sha256: r.sha256, referenced: r.referenced, ageSeconds: age(r) }));
    },
    async deleteUnlinked(i) {
      calls.push({ op: 'deleteUnlinked', arg: i.id });
      if (faults.failDelete) fail();
      const r = rows.find((x) => x.id === i.id);
      if (r && faults.beforeDelete) faults.beforeDelete(r);
      if (!r || r.status !== 'ready' || r.storageKey !== i.storageKey || r.thumbKey !== i.thumbKey || !(age(r) > i.graceSeconds) || r.referenced) return false;
      rows = rows.filter((x) => x !== r);
      return true;
    },
    async findReferencedKeys(keys) {
      calls.push({ op: 'findReferencedKeys', arg: keys.length });
      refCalls++;
      if (refCalls <= faults.failRefsFirst || (faults.failRefsFrom !== null && refCalls >= faults.failRefsFrom)) fail();
      const set = new Set<string>();
      for (const r of rows) for (const k of [r.storageKey, r.thumbKey]) if (k !== null && keys.includes(k)) set.add(k);
      faults.afterRefs?.(refCalls);
      return set;
    },
  };

  return {
    repo,
    calls,
    faults,
    rows: () => rows,
    add(fields: Partial<AuditRow>): AuditRow {
      const r: AuditRow = { id: `a0000000-0000-4000-8000-${String(++n).padStart(12, '0')}`, kind: 'car_image', status: 'ready', storageKey: null, thumbKey: null, bytes: null, width: null, height: null, sha256: null, readyAt: clock.now(), referenced: false, ...fields };
      rows.push(r);
      return r;
    },
  };
}

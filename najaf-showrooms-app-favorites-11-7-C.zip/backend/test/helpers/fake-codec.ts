// A scriptable fake ImageCodec for the processing rules (Phase 11.6.3). It never decodes: probe() trusts the header (as a decoder
// would report it) and render() returns a structurally valid WebP of the size a correct codec would produce (fit inside maxSide,
// never enlarged, optional 90-degree orientation swap). Every misbehaviour the processor must catch can be switched on.
import { CodecError } from '../../src/assets/codec.ts';
import type { CodecErrorCode, ImageCodec, ProbeResult, RenderOptions } from '../../src/assets/codec.ts';
import { sniffImage } from '../../src/assets/image-sniff.ts';

/** A header-valid lossless WebP (VP8L) of the given size, optionally padded and with extra chunks. */
export function fakeWebp(width: number, height: number, opts: { payload?: number; extraChunks?: Array<[string, number]>; vp8xFlags?: number } = {}): Uint8Array {
  const chunk = (fourcc: string, data: Buffer): Buffer => {
    const head = Buffer.alloc(8);
    head.write(fourcc, 0, 'ascii');
    head.writeUInt32LE(data.length, 4);
    return Buffer.concat([head, data, Buffer.alloc(data.length & 1)]);
  };
  const bits = ((width - 1) | ((height - 1) << 14)) >>> 0;
  const vp8lData = Buffer.alloc(Math.max(5, opts.payload ?? 16));
  vp8lData[0] = 0x2f;
  vp8lData.writeUInt32LE(bits, 1);
  const parts: Buffer[] = [];
  if (opts.vp8xFlags !== undefined) {
    const x = Buffer.alloc(10);
    x[0] = opts.vp8xFlags;
    x.writeUIntLE(width - 1, 4, 3);
    x.writeUIntLE(height - 1, 7, 3);
    parts.push(chunk('VP8X', x));
  }
  for (const [fourcc, n] of opts.extraChunks ?? []) parts.push(chunk(fourcc, Buffer.alloc(n, 65)));
  parts.push(chunk('VP8L', vp8lData));
  const body = Buffer.concat([Buffer.from('WEBP', 'ascii'), ...parts]);
  const head = Buffer.alloc(8);
  head.write('RIFF', 0, 'ascii');
  head.writeUInt32LE(body.length, 4);
  return new Uint8Array(Buffer.concat([head, body]));
}

export interface FakeCodecBehaviour {
  probeError?: CodecErrorCode;
  renderError?: CodecErrorCode;
  /** Override what probe reports. */
  probe?: Partial<ProbeResult>;
  /** Swap width/height like an EXIF-rotated image. */
  rotate?: boolean;
  /** Misbehaviours of render(). */
  addChunk?: string;
  vp8xFlags?: number;
  enlarge?: boolean;
  /** Ignore maxSide (return the source size). */
  noResize?: boolean;
  crop?: boolean;
  lie?: boolean;
  payload?: (quality: number) => number;
  hang?: boolean;
  notBytes?: boolean;
}

export function createFakeCodec(b: FakeCodecBehaviour = {}) {
  const calls: Array<{ op: string; opts: unknown }> = [];
  let active = 0;
  let maxActive = 0;
  const codec: ImageCodec = {
    name: 'fake',
    async probe(input, opts) {
      calls.push({ op: 'probe', opts });
      if (b.probeError) throw new CodecError(b.probeError);
      const s = sniffImage(input);
      if (!s) throw new CodecError('invalid_image');
      if (s.width * s.height > opts.maxInputPixels) throw new CodecError('too_large');
      return { format: ({ 'image/jpeg': 'jpeg', 'image/png': 'png', 'image/webp': 'webp' } as const)[s.type], width: s.width, height: s.height, pages: 1, ...b.probe };
    },
    async render(input, opts: RenderOptions) {
      calls.push({ op: 'render', opts });
      active++;
      maxActive = Math.max(maxActive, active);
      try {
        await new Promise((r) => setTimeout(r, 5));
        if (b.hang) await new Promise(() => undefined);
        if (b.renderError) throw new CodecError(b.renderError);
        const s = sniffImage(input);
        if (!s) throw new CodecError('invalid_image');
        if (s.width * s.height > opts.maxInputPixels) throw new CodecError('too_large');
        let [w, h] = b.rotate && s.type !== 'image/webp' ? [s.height, s.width] : [s.width, s.height];
        const scale = b.noResize ? 1 : Math.min(1, opts.maxSide / Math.max(w, h));
        w = Math.max(1, Math.round(w * scale));
        h = Math.max(1, Math.round(h * scale));
        if (b.enlarge) [w, h] = [w * 2, h * 2];
        if (b.crop) h = Math.max(1, Math.round(h / 2));
        if (b.notBytes) return { data: 'webp' as never, width: w, height: h };
        const data = fakeWebp(w, h, { payload: b.payload?.(opts.quality) ?? 16, extraChunks: b.addChunk ? [[b.addChunk, 8]] : [], ...(b.vp8xFlags !== undefined ? { vp8xFlags: b.vp8xFlags } : {}) });
        return { data, width: b.lie ? w + 1 : w, height: h };
      } finally {
        active--;
      }
    },
  };
  return { codec, calls, maxActive: () => maxActive };
}

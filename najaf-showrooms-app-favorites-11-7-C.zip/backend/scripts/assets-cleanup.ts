// Operator tool (Phase 11.6.4): cleans up abandoned uploads and orphaned image objects. DRY-RUN by default.
//   npm run assets:cleanup                          count only (nothing is deleted)
//   npm run assets:cleanup -- --execute             delete
// Options (all optional): --batch-size=N (1-1000, default 100)  --max-batches=N (1-100, default 10)
//   --older-than-hours=N (24-720, default 24)  --shard=H (0-2 hex digits: only object keys whose uuid starts with H)
//   --skip-rows  --skip-orphans
//   --retry-limit=N (1-200, default 20)  --skip-retry       (Phase 11.6.5: retry processing of pending uploads first)
// The retry phase needs the image codec (sharp, installed by npm install): without it the tool stops with exit code 78 unless
// --skip-retry is given. Reads the same environment as the server (database + STORAGE_*). The in-memory storage provider is refused: its objects live in
// the server process, not here. Prints ONE JSON report with counts only: no storage key, bucket, endpoint or credential.
// Exit codes: 0 done (also when a bound was reached: see "complete"), 1 the run stopped on a database/storage failure,
// 64 invalid arguments, 78 invalid configuration.
import { ConfigError, describeDbTarget, loadConfig } from '../src/config.ts';
import { createDb } from '../src/db.ts';
import { describeError } from '../src/errors.ts';
import { CleanupOptionsError, resolveCleanupOptions, runAssetCleanup } from '../src/assets/cleanup.ts';
import type { CleanupOptions } from '../src/assets/cleanup.ts';
import { createPgCleanupRepository } from '../src/assets/cleanup-repository.ts';
import type { ImageCodec } from '../src/assets/codec.ts';
import { createPgProcessingRepository } from '../src/assets/processing-repository.ts';
import { createAssetProcessor } from '../src/assets/processing-service.ts';
import { StorageConfigError, createStorage, loadStorageConfig } from '../src/storage/index.ts';

const EX_USAGE = 64;
const EX_CONFIG = 78;

/** Parses the command line. Throws CleanupOptionsError naming the offending arguments (never echoing values). */
export function parseCleanupArgs(argv: readonly string[]): CleanupOptions {
  const input: Partial<CleanupOptions> = {};
  const problems: string[] = [];
  const NUM = /^[1-9][0-9]{0,5}$/;
  for (const arg of argv) {
    const eq = arg.indexOf('=');
    const name = eq === -1 ? arg : arg.slice(0, eq);
    const value = eq === -1 ? undefined : arg.slice(eq + 1);
    const flag = (set: () => void) => (value === undefined ? set() : problems.push(name));
    const num = (set: (n: number) => void) => (value !== undefined && NUM.test(value) ? set(Number(value)) : problems.push(name));
    switch (name) {
      case '--execute': flag(() => (input.dryRun = false)); break;
      case '--dry-run': flag(() => (input.dryRun = true)); break;
      case '--skip-rows': flag(() => (input.rows = false)); break;
      case '--skip-orphans': flag(() => (input.orphans = false)); break;
      case '--skip-retry': flag(() => (input.retry = false)); break;
      case '--retry-limit': num((n) => (input.retryLimit = n)); break;
      case '--batch-size': num((n) => (input.batchSize = n)); break;
      case '--max-batches': num((n) => (input.maxBatches = n)); break;
      case '--older-than-hours': num((n) => (input.olderThanHours = n)); break;
      case '--shard': value !== undefined ? (input.shard = value) : problems.push(name); break;
      default: problems.push(/^--[a-z-]{1,30}$/.test(name) ? name : 'unknown argument');
    }
  }
  const ARG: Record<string, string> = { batchSize: '--batch-size', maxBatches: '--max-batches', olderThanHours: '--older-than-hours', shard: '--shard', retryLimit: '--retry-limit' };
  try {
    const opts = resolveCleanupOptions(input);
    if (problems.length === 0) return opts;
  } catch (e) {
    if (!(e instanceof CleanupOptionsError)) throw e;
    for (const p of e.problems) problems.push(ARG[p] ?? p);
  }
  throw new CleanupOptionsError(problems);
}

async function run(): Promise<number> {
  let opts: CleanupOptions;
  try {
    opts = parseCleanupArgs(process.argv.slice(2));
  } catch (e) {
    if (e instanceof CleanupOptionsError) {
      console.error(JSON.stringify({ ok: false, invalidArguments: e.problems }, null, 2));
      return EX_USAGE;
    }
    throw e;
  }
  let config;
  let storageConfig;
  try {
    config = loadConfig();
    storageConfig = loadStorageConfig();
  } catch (e) {
    if (e instanceof ConfigError || e instanceof StorageConfigError) {
      console.error(JSON.stringify({ ok: false, configProblems: e.problems }, null, 2));
      return EX_CONFIG;
    }
    throw e;
  }
  if (storageConfig.provider !== 'r2') {
    console.error(JSON.stringify({ ok: false, configProblems: ['the cleanup job needs persistent storage (STORAGE_PROVIDER=r2)'] }, null, 2));
    return EX_CONFIG;
  }
  // The retry phase reuses the server's own processor, so it needs the same native codec (loaded only when needed).
  let codec: ImageCodec | null = null;
  if (opts.retry) {
    try {
      codec = (await import('../src/assets/sharp-codec.ts')).createSharpCodec();
    } catch {
      console.error(JSON.stringify({ ok: false, configProblems: ['the retry phase needs the image codec (sharp): run "npm install", or pass --skip-retry'] }, null, 2));
      return EX_CONFIG;
    }
  }
  const db = await createDb(config.db);
  try {
    const storage = createStorage(storageConfig);
    const processor = codec ? createAssetProcessor({ repo: createPgProcessingRepository(db), storage, codec }) : undefined;
    const report = await runAssetCleanup({ repo: createPgCleanupRepository(db), storage, ...(processor ? { processor } : {}) }, opts);
    const ok = report.error === null;
    (ok ? console.log : console.error)(JSON.stringify({ ok, ...report }, null, 2));
    return ok ? 0 : 1;
  } catch (e) {
    console.error(JSON.stringify({ ok: false, target: describeDbTarget(config.db), error: describeError(e) }, null, 2));
    return 1;
  } finally {
    await db.close();
  }
}

// Run only as a script (the argument parser is imported by the unit tests).
if (import.meta.filename === process.argv[1]) process.exitCode = await run();

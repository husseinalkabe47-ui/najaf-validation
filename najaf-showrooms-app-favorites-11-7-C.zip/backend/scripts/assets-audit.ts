// Operator tool (Phase 11.6.6): audits the integrity of image records and stored objects. DRY-RUN by default.
//   npm run assets:audit                            report only (nothing is deleted)
//   npm run assets:audit -- --execute               also delete unlinked assets and orphan objects older than the grace period
// Options (all optional): --batch-size=N (1-1000, default 100)  --max-batches=N (1-100, default 10)
//   --grace-hours=N (24-720, default 24)  --shard=H (0-2 hex digits: only object keys whose uuid starts with H)
//   --skip-assets  --skip-orphans
// Reads the same environment as the server (database + STORAGE_*). The in-memory storage provider is refused: its objects live in
// the server process, not here. Prints ONE JSON report: counts, and ids of referenced assets with a problem; no storage key, bucket,
// endpoint, signed URL or credential. Referenced assets are never deleted, whatever their state.
// Exit codes: 0 audit done, nothing needs attention | 1 the audit could not finish, or an item could not be verified or deleted |
//   2 audit done, but a referenced asset is missing or corrupt (needs a person) | 64 invalid arguments | 78 invalid configuration.
import { ConfigError, describeDbTarget, loadConfig } from '../src/config.ts';
import { createDb } from '../src/db.ts';
import { describeError } from '../src/errors.ts';
import { AuditOptionsError, resolveAuditOptions, runAssetAudit } from '../src/assets/audit.ts';
import type { AuditOptions, AuditReport } from '../src/assets/audit.ts';
import { createPgAuditRepository } from '../src/assets/audit-repository.ts';
import { StorageConfigError, createStorage, loadStorageConfig } from '../src/storage/index.ts';

const EX_USAGE = 64;
const EX_CONFIG = 78;

/** Parses the command line. Throws AuditOptionsError naming the offending arguments (never echoing values). */
export function parseAuditArgs(argv: readonly string[]): AuditOptions {
  const input: Partial<AuditOptions> = {};
  const problems: string[] = [];
  const NUM = /^[1-9][0-9]{0,5}$/;
  for (const arg of argv) {
    const eq = arg.indexOf('=');
    const name = eq === -1 ? arg : arg.slice(0, eq);
    const value = eq === -1 ? undefined : arg.slice(eq + 1);
    const flag = (set: () => void) => (value === undefined ? set() : problems.push(name));
    const num = (set: (n: number) => void) => (value !== undefined && NUM.test(value) ? set(Number(value)) : problems.push(name));
    switch (name) {
      case '--execute': flag(() => (input.dryRun = false)); break;
      case '--dry-run': flag(() => (input.dryRun = true)); break;
      case '--skip-assets': flag(() => (input.assets = false)); break;
      case '--skip-orphans': flag(() => (input.orphans = false)); break;
      case '--batch-size': num((n) => (input.batchSize = n)); break;
      case '--max-batches': num((n) => (input.maxBatches = n)); break;
      case '--grace-hours': num((n) => (input.graceHours = n)); break;
      case '--shard': value !== undefined ? (input.shard = value) : problems.push(name); break;
      default: problems.push(/^--[a-z-]{1,30}$/.test(name) ? name : 'unknown argument');
    }
  }
  // `--execute` together with `--dry-run` is contradictory: refused rather than guessed.
  if (argv.includes('--execute') && argv.includes('--dry-run')) problems.push('--execute with --dry-run');
  const ARG: Record<string, string> = { batchSize: '--batch-size', maxBatches: '--max-batches', graceHours: '--grace-hours', shard: '--shard', nothingToAudit: '--skip-assets with --skip-orphans' };
  try {
    const opts = resolveAuditOptions(input);
    if (problems.length === 0) return opts;
  } catch (e) {
    if (!(e instanceof AuditOptionsError)) throw e;
    for (const p of e.problems) problems.push(ARG[p] ?? p);
  }
  throw new AuditOptionsError(problems);
}

/** 0 clean | 1 incomplete, unverified or failed | 2 finished with referenced problems. */
export function auditExitCode(report: AuditReport): number {
  if (report.error !== null || report.summary.failed > 0) return 1;
  return report.findings ? 2 : 0;
}

async function run(): Promise<number> {
  let opts: AuditOptions;
  try {
    opts = parseAuditArgs(process.argv.slice(2));
  } catch (e) {
    if (e instanceof AuditOptionsError) {
      console.error(JSON.stringify({ ok: false, invalidArguments: e.problems }, null, 2));
      return EX_USAGE;
    }
    throw e;
  }
  let config;
  let storageConfig;
  try {
    config = loadConfig();
    storageConfig = loadStorageConfig();
  } catch (e) {
    if (e instanceof ConfigError || e instanceof StorageConfigError) {
      console.error(JSON.stringify({ ok: false, configProblems: e.problems }, null, 2));
      return EX_CONFIG;
    }
    throw e;
  }
  if (storageConfig.provider !== 'r2') {
    console.error(JSON.stringify({ ok: false, configProblems: ['the audit needs persistent storage (STORAGE_PROVIDER=r2)'] }, null, 2));
    return EX_CONFIG;
  }
  const db = await createDb(config.db);
  try {
    const report = await runAssetAudit({ repo: createPgAuditRepository(db), storage: createStorage(storageConfig) }, opts);
    const code = auditExitCode(report);
    (code === 1 ? console.error : console.log)(JSON.stringify({ ok: code === 0, exitCode: code, ...report }, null, 2));
    return code;
  } catch (e) {
    console.error(JSON.stringify({ ok: false, target: describeDbTarget(config.db), error: describeError(e) }, null, 2));
    return 1;
  } finally {
    await db.close();
  }
}

// Run only as a script (the argument parser is imported by the unit tests).
if (import.meta.filename === process.argv[1]) process.exitCode = await run();

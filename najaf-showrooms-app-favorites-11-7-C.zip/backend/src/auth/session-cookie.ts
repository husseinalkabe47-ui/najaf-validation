// Cookie transport for the refresh token (Phase 11.7.2.2). Dependency-free and pure (no Fastify), so every rule is unit-testable.
//
// WHY: a browser page that must survive a reload cannot keep the refresh token in JavaScript-readable storage. In "cookie transport" the
// refresh token travels ONLY in an HttpOnly cookie: the browser stores it and sends it, page scripts can never read it, and the JSON
// body of login/refresh no longer contains it. The access token (15 minutes) stays in page memory exactly as before.
//
// OPT-IN, PER REQUEST, AND OFF BY DEFAULT:
//  - Disabled unless AUTH_COOKIE_ORIGINS is set. Without it nothing here runs and every existing client (bearer/body transport) is unchanged.
//  - A request opts in with the header `X-Session-Transport: cookie` on POST /v1/auth/login, /refresh and /logout. Any other value, or the
//    header on a server where cookie transport is disabled, is refused (400) rather than silently answered with a token in the body.
//
// CSRF (a cookie is sent by the browser even for requests a hostile page triggers, so the cookie alone proves nothing):
//  1. SameSite=Strict: the browser does not attach the cookie to any cross-site request.
//  2. The Origin header is REQUIRED and must be exactly one of AUTH_COOKIE_ORIGINS (browsers always send it on a fetch POST). No Origin,
//     `null`, or any other origin = 403. Sec-Fetch-Site, when the browser sends it, must be same-origin or same-site.
//  3. The custom header X-Session-Transport is itself required; a cross-origin page cannot add a custom header without a CORS preflight,
//     and this server answers no preflight (there is no CORS: cookie transport is for a page served from the API's own origin).
//  4. JSON-only bodies (routes.ts already answers 415 to anything else), so a plain HTML form cannot reach these routes.
//
// COOKIE: `__Secure-najaf_rt` (the prefix makes browsers refuse it unless it was set over HTTPS with the Secure attribute),
// Path=/v1/auth (sent only to the auth routes), HttpOnly, Secure, SameSite=Strict, no Domain (host-only), Max-Age = the remaining absolute
// lifetime of the session (rotation never extends it). Value = the opaque refresh token. Plain HTTP (AUTH_COOKIE_SECURE=false) is refused in
// production and exists only for local development on http://localhost, where the unprefixed name `najaf_rt` is used.
import { isWellFormedToken } from './tokens.ts';

export const SESSION_COOKIE_ENV_VARS = ['AUTH_COOKIE_ORIGINS', 'AUTH_COOKIE_SECURE'] as const;
export const TRANSPORT_HEADER = 'x-session-transport';
export const COOKIE_TRANSPORT = 'cookie';
export const COOKIE_PATH = '/v1/auth';
const MAX_ORIGINS = 10;

export interface SessionCookieConfig {
  /** Secure attribute (and the __Secure- name prefix). Always true in production. */
  readonly secure: boolean;
  /** Exact origins (scheme://host[:port]) allowed to use cookie transport. Never empty. */
  readonly allowedOrigins: readonly string[];
  readonly cookieName: string;
}

export class SessionCookieConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`Invalid session cookie configuration:\n- ${problems.join('\n- ')}`);
    this.name = 'SessionCookieConfigError';
    this.problems = problems;
  }
}

const LOOPBACK = new Set(['localhost', '127.0.0.1', '[::1]']);

/** null = cookie transport disabled (AUTH_COOKIE_ORIGINS empty or unset). Throws SessionCookieConfigError on any invalid value. */
export function loadSessionCookieConfig(env: Record<string, string | undefined> = process.env): SessionCookieConfig | null {
  const raw = (env['AUTH_COOKIE_ORIGINS'] ?? '').trim();
  const secureRaw = env['AUTH_COOKIE_SECURE'];
  if (raw === '') {
    if (secureRaw !== undefined && secureRaw !== '') throw new SessionCookieConfigError(['AUTH_COOKIE_SECURE is set but AUTH_COOKIE_ORIGINS is empty (cookie transport is disabled)']);
    return null;
  }
  const problems: string[] = [];
  const production = env['NODE_ENV'] === 'production';

  let secure = true;
  if (secureRaw !== undefined && secureRaw !== '') {
    const v = secureRaw.toLowerCase();
    if (v === 'true' || v === '1') secure = true;
    else if (v === 'false' || v === '0') secure = false;
    else problems.push('AUTH_COOKIE_SECURE must be true or false');
  }
  if (!secure && production) problems.push('AUTH_COOKIE_SECURE=false is not allowed in production');

  const entries = raw.split(',').map((s) => s.trim()).filter((s) => s !== '');
  if (entries.length > MAX_ORIGINS) problems.push(`AUTH_COOKIE_ORIGINS lists more than ${MAX_ORIGINS} origins`);
  const origins: string[] = [];
  entries.forEach((entry, i) => {
    const label = `AUTH_COOKIE_ORIGINS entry #${i + 1}`;
    if (entry === '*' || entry.includes('*') || entry.toLowerCase() === 'null') { problems.push(`${label} must be an exact origin (no wildcard, not "null")`); return; }
    let u: URL;
    try { u = new URL(entry); } catch { problems.push(`${label} is not a valid origin (expected https://host[:port])`); return; }
    if (u.origin === 'null' || u.origin !== entry) { problems.push(`${label} must be exactly scheme://host[:port] with no path, query, fragment or trailing slash`); return; }
    if (u.protocol === 'https:') { origins.push(u.origin); return; }
    if (u.protocol === 'http:' && !secure && LOOPBACK.has(u.hostname)) { origins.push(u.origin); return; }
    problems.push(`${label} must use https (http is accepted only for localhost when AUTH_COOKIE_SECURE=false)`);
  });
  if (secure && origins.some((o) => o.startsWith('http:'))) problems.push('http origins require AUTH_COOKIE_SECURE=false');

  if (problems.length > 0) throw new SessionCookieConfigError(problems);
  return Object.freeze({ secure, allowedOrigins: Object.freeze([...new Set(origins)]), cookieName: secure ? '__Secure-najaf_rt' : 'najaf_rt' });
}

export function redactSessionCookieConfig(cfg: SessionCookieConfig | null): Record<string, unknown> {
  return cfg ? { enabled: true, secure: cfg.secure, origins: [...cfg.allowedOrigins], cookieName: cfg.cookieName } : { enabled: false };
}

/** The request asks for cookie transport (header present with any value). The value is validated by checkCookieRequest. */
export function requestsCookieTransport(headers: Record<string, unknown>): boolean {
  return headers[TRANSPORT_HEADER] !== undefined;
}

export type CookieRejection = 'transport_value' | 'origin_missing' | 'origin_not_allowed' | 'fetch_site';

/** undefined = acceptable. Otherwise the reason (never echoed to the client). */
export function checkCookieRequest(cfg: SessionCookieConfig, headers: Record<string, unknown>): CookieRejection | undefined {
  const transport = headers[TRANSPORT_HEADER];
  if (typeof transport !== 'string' || transport.trim().toLowerCase() !== COOKIE_TRANSPORT) return 'transport_value';
  const origin = headers['origin'];
  if (typeof origin !== 'string' || origin === '') return 'origin_missing';
  if (!cfg.allowedOrigins.includes(origin)) return 'origin_not_allowed';
  const site = headers['sec-fetch-site'];
  if (site !== undefined && site !== 'same-origin' && site !== 'same-site') return 'fetch_site';
  return undefined;
}

/**
 * The refresh token from the Cookie header, or undefined. Strict: exactly one cookie with our name (a duplicate means somebody else
 * may have set one, so it is refused, not guessed), and the value must have the exact token shape.
 */
export function readSessionCookie(cfg: SessionCookieConfig, cookieHeader: unknown): string | undefined {
  if (typeof cookieHeader !== 'string' || cookieHeader.length > 4096) return undefined;
  let found: string | undefined;
  let count = 0;
  for (const part of cookieHeader.split(';')) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    if (part.slice(0, eq).trim() !== cfg.cookieName) continue;
    count++;
    found = part.slice(eq + 1).trim();
  }
  if (count !== 1 || found === undefined) return undefined;
  return isWellFormedToken(found) ? found : undefined;
}

function attributes(cfg: SessionCookieConfig): string {
  return `Path=${COOKIE_PATH}; HttpOnly; SameSite=Strict${cfg.secure ? '; Secure' : ''}`;
}

/** Set-Cookie value for a (new or rotated) refresh token. Max-Age follows the ABSOLUTE expiry, so rotation never extends the session. */
export function serializeSessionCookie(cfg: SessionCookieConfig, token: string, expiresAtMs: number, nowMs: number): string {
  if (!isWellFormedToken(token)) throw new Error('refusing to set a malformed session cookie');
  const maxAge = Math.max(0, Math.floor((expiresAtMs - nowMs) / 1000));
  return `${cfg.cookieName}=${token}; ${attributes(cfg)}; Max-Age=${maxAge}`;
}

/** Set-Cookie value that deletes the cookie (same name/path/attributes, empty value, already expired). */
export function serializeClearCookie(cfg: SessionCookieConfig): string {
  return `${cfg.cookieName}=; ${attributes(cfg)}; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT`;
}

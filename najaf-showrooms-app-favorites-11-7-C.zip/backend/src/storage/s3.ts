// Cloudflare R2 (or any S3-compatible service) provider (Phase 11.6.1), over the S3 REST API with node's fetch and the SigV4 signer
// in sigv4.ts. No SDK dependency. Everything (endpoint, region, bucket, credentials, prefix, limits) comes from StorageConfig.
//
//  - path-style addressing: <endpoint>/<bucket>/<prefix>/<key>, every segment URI-encoded (keys are already restricted to safe
//    characters by assertSafeKey, which runs before any I/O);
//  - every request is signed with the payload hash (x-amz-content-sha256 = SHA-256 of the body), sent with a timeout, and
//    redirects are refused (signed headers are never replayed to another host);
//  - status mapping: GET/HEAD 404 -> missing (null/false); DELETE 404 -> success (idempotent); any other non-2xx, a network failure,
//    a timeout or a redirect -> StorageError('unavailable', status). The backend's body, the URL, the key and the credentials never
//    appear in an error;
//  - size limits on both directions: a body above maxObjectBytes is refused before sending, and a download is refused (and the
//    stream cancelled) as soon as it is announced or seen to exceed the limit.
//  - listing (Phase 11.6.4, the cleanup job only): ListObjectsV2 (GET /<bucket>?list-type=2&prefix=..&max-keys=..), the query
//    signed like every other request; the XML answer is size-limited and parsed strictly (a malformed answer, a key outside the
//    requested prefix or more entries than asked is 'integrity'); keys that are not safe keys are skipped, never returned.

/** The largest ListObjectsV2 answer accepted (1000 entries are far below this). */
export const LIST_RESPONSE_MAX_BYTES = 4 * 1024 * 1024;

const XML_ENTITY = /&(amp|lt|gt|quot|apos|#\d{1,7}|#x[0-9a-fA-F]{1,6});/g;
const NAMED: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function xmlText(s: string): string {
  if (s.includes('&') && s.replace(XML_ENTITY, '').includes('&')) throw new StorageError('integrity');
  return s.replace(XML_ENTITY, (_m, e: string) => {
    if (NAMED[e] !== undefined) return NAMED[e];
    const cp = e[1] === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
    if (!(cp > 0 && cp <= 0x10ffff)) throw new StorageError('integrity');
    return String.fromCodePoint(cp);
  });
}
const one = (block: string, tag: string): string | null => {
  const all = [...block.matchAll(new RegExp(`<${tag}>([^<]*)</${tag}>`, 'g'))];
  if (all.length > 1) throw new StorageError('integrity');
  return all.length === 1 ? all[0]![1]! : null;
};

/** Parses a ListObjectsV2 answer. Keys are returned relative to `keyPrefix`; anything unexpected is StorageError('integrity'). */
export function parseListObjectsV2(xml: string, opts: { keyPrefix: string; requestedPrefix: string; maxKeys: number }): ListPage {
  if (!/^(<\?xml[^>]*\?>\s*)?<ListBucketResult[\s>]/.test(xml.trimStart()) || !xml.trimEnd().endsWith('</ListBucketResult>')) throw new StorageError('integrity');
  const truncated = one(xml.replace(/<Contents>[\s\S]*?<\/Contents>/g, ''), 'IsTruncated');
  if (truncated !== 'true' && truncated !== 'false') throw new StorageError('integrity');
  const blocks = [...xml.matchAll(/<Contents>([\s\S]*?)<\/Contents>/g)].map((m) => m[1]!);
  if (blocks.length > opts.maxKeys) throw new StorageError('integrity');
  const objects: ListedObject[] = [];
  let skipped = 0;
  for (const b of blocks) {
    const rawKey = one(b, 'Key');
    const size = one(b, 'Size');
    const modified = one(b, 'LastModified');
    if (rawKey === null || size === null || modified === null || !/^\d{1,15}$/.test(size)) throw new StorageError('integrity');
    const at = new Date(xmlText(modified));
    if (Number.isNaN(at.getTime())) throw new StorageError('integrity');
    const key = xmlText(rawKey);
    if (!key.startsWith(opts.requestedPrefix)) throw new StorageError('integrity');
    const rel = opts.keyPrefix === '' ? key : key.slice(opts.keyPrefix.length + 1);
    if (isSafeKey(rel)) objects.push({ key: rel, size: Number(size), lastModified: at });
    else skipped++;
  }
  let nextToken: string | null = null;
  if (truncated === 'true') {
    const t = one(xml.replace(/<Contents>[\s\S]*?<\/Contents>/g, ''), 'NextContinuationToken');
    if (t === null || t.length === 0 || t.length > 1024) throw new StorageError('integrity');
    nextToken = xmlText(t);
  }
  return { objects, skipped, nextToken };
}

/** The query string exactly as it is signed (sigv4.ts sorts and encodes the same way). */
function queryString(query: ReadonlyArray<[string, string]>): string {
  return [...query]
    .map(([k, v]) => [uriEncode(k), uriEncode(v)] as const)
    .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join('&');
}
import type { S3Settings, StorageConfig } from './config.ts';
import { assertSafeKey, assertSafePrefix, isSafeKey } from './keys.ts';
import { StorageError, assertBody, assertContentType, assertMaxKeys } from './provider.ts';
import type { ListableStorage, ListPage, ListedObject, StoredObject } from './provider.ts';
import { EMPTY_SHA256, sha256Hex, signV4, uriEncode } from './sigv4.ts';

export interface S3Deps {
  fetch?: typeof fetch;
  now?: () => Date;
}

type Method = 'PUT' | 'GET' | 'HEAD' | 'DELETE';

export function createS3Storage(config: Pick<StorageConfig, 'keyPrefix' | 'timeoutMs' | 'maxObjectBytes'> & { s3: S3Settings }, deps: S3Deps = {}): ListableStorage {
  const doFetch = deps.fetch ?? globalThis.fetch;
  const now = deps.now ?? (() => new Date());
  const { s3, keyPrefix, timeoutMs, maxObjectBytes } = config;
  const origin = new URL(s3.endpoint);
  if (origin.protocol !== 'https:' && origin.protocol !== 'http:') throw new StorageError('unavailable');
  const host = origin.host;
  if (keyPrefix !== '') assertSafeKey(keyPrefix);

  function pathOf(key: string): string {
    const full = keyPrefix === '' ? assertSafeKey(key) : `${keyPrefix}/${assertSafeKey(key)}`;
    return '/' + [s3.bucket, ...full.split('/')].map(uriEncode).join('/');
  }

  async function send(method: Method, key: string, body?: Uint8Array<ArrayBuffer>, contentType?: string): Promise<Response> {
    return sendTo(method, pathOf(key), [], body, contentType);
  }

  async function sendTo(method: Method, canonicalPath: string, query: ReadonlyArray<[string, string]>, body?: Uint8Array<ArrayBuffer>, contentType?: string): Promise<Response> {
    const payloadHash = body ? sha256Hex(body) : EMPTY_SHA256;
    const signed = signV4({
      method, host, canonicalPath, query, headers: contentType ? { 'content-type': contentType } : {}, payloadHash,
      accessKeyId: s3.accessKeyId, secretAccessKey: s3.secretAccessKey, region: s3.region, service: 's3', now: now(),
    });
    const qs = queryString(query);
    try {
      return await doFetch(`${origin.origin}${canonicalPath}${qs === '' ? '' : `?${qs}`}`, {
        method,
        headers: signed.headers,
        ...(body ? { body } : {}),
        redirect: 'error',
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch {
      // Network failure, timeout or a redirect. The underlying error may contain the URL: it is deliberately dropped.
      throw new StorageError('unavailable');
    }
  }

  const discard = async (res: Response): Promise<void> => {
    try {
      await res.body?.cancel();
    } catch {
      /* nothing to release */
    }
  };
  const fail = async (res: Response): Promise<never> => {
    await discard(res);
    throw new StorageError('unavailable', res.status);
  };

  async function readLimited(res: Response, limit: number = maxObjectBytes): Promise<Uint8Array> {
    const declared = res.headers.get('content-length');
    if (declared !== null && (!/^\d{1,15}$/.test(declared) || Number(declared) > limit)) {
      await discard(res);
      throw new StorageError(/^\d{1,15}$/.test(declared) ? 'too_large' : 'integrity');
    }
    if (!res.body) return new Uint8Array(0);
    const reader = res.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    for (;;) {
      let step: ReadableStreamReadResult<Uint8Array>;
      try {
        step = await reader.read();
      } catch {
        throw new StorageError('unavailable');
      }
      if (step.done) break;
      total += step.value.byteLength;
      if (total > limit) {
        try {
          await reader.cancel();
        } catch {
          /* already closed */
        }
        throw new StorageError('too_large');
      }
      chunks.push(step.value);
    }
    if (declared !== null && Number(declared) !== total) throw new StorageError('integrity');
    const out = new Uint8Array(total);
    let at = 0;
    for (const c of chunks) {
      out.set(c, at);
      at += c.byteLength;
    }
    return out;
  }

  return {
    kind: 'r2',
    async put(key, body, opts) {
      pathOf(key);
      const type = assertContentType(opts?.contentType);
      // A private copy: the caller cannot change the bytes between hashing and sending.
      const bytes = new Uint8Array(assertBody(body, maxObjectBytes));
      const res = await send('PUT', key, bytes, type);
      if (res.status !== 200) return fail(res);
      await discard(res);
    },
    async get(key): Promise<StoredObject | null> {
      pathOf(key);
      const res = await send('GET', key);
      if (res.status === 404) {
        await discard(res);
        return null;
      }
      if (res.status !== 200) return fail(res);
      const body = await readLimited(res);
      return { body, contentType: res.headers.get('content-type'), size: body.byteLength };
    },
    async delete(key) {
      pathOf(key);
      const res = await send('DELETE', key);
      if (res.status === 204 || res.status === 200 || res.status === 404) return void (await discard(res));
      return fail(res);
    },
    async exists(key) {
      pathOf(key);
      const res = await send('HEAD', key);
      await discard(res);
      if (res.status === 200) return true;
      if (res.status === 404) return false;
      throw new StorageError('unavailable', res.status);
    },
    async list(prefix, o) {
      const rel = assertSafePrefix(prefix);
      const maxKeys = assertMaxKeys(o?.maxKeys);
      const token = o?.token ?? null;
      if (token !== null && (typeof token !== 'string' || token.length === 0 || token.length > 1024)) throw new RangeError('invalid continuation token');
      const requestedPrefix = keyPrefix === '' ? rel : `${keyPrefix}/${rel}`;
      const query: Array<[string, string]> = [['list-type', '2'], ['prefix', requestedPrefix], ['max-keys', String(maxKeys)]];
      if (token !== null) query.push(['continuation-token', token]);
      const res = await sendTo('GET', '/' + uriEncode(s3.bucket), query);
      if (res.status !== 200) return fail(res);
      const body = await readLimited(res, LIST_RESPONSE_MAX_BYTES);
      let xml: string;
      try {
        xml = new TextDecoder('utf-8', { fatal: true }).decode(body);
      } catch {
        throw new StorageError('integrity');
      }
      return parseListObjectsV2(xml, { keyPrefix, requestedPrefix, maxKeys });
    },
  };
}

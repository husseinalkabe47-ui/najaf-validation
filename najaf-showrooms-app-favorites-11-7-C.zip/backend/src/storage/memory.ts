// In-memory storage provider (Phase 11.6.1): the replaceable fake for tests and local development (refused in production by
// loadStorageConfig). It enforces EXACTLY the same contract as the R2 provider (safe keys, content types, size limit, copies in and
// out, idempotent delete), so code written against it behaves the same against R2. Nothing persists across process restarts.
import { assertSafeKey, assertSafePrefix, isSafeKey } from './keys.ts';
import { assertBody, assertContentType, assertMaxKeys } from './provider.ts';
import type { ListableStorage, ListedObject, StoredObject } from './provider.ts';
import { MAX_OBJECT_BYTES_DEFAULT } from './config.ts';

export interface MemoryStorage extends ListableStorage {
  /** Test helper: the number of stored objects. */
  size(): number;
  /** Test helper: the stored keys (prefix included), sorted. Never exposed through any route. */
  keys(): string[];
  /** Test helper: sets an object's last-modified time (to simulate old objects). false if there is no such object. */
  touch(key: string, at: Date): boolean;
}

export function createMemoryStorage(opts: { keyPrefix?: string; maxObjectBytes?: number; now?: () => Date } = {}): MemoryStorage {
  const keyPrefix = opts.keyPrefix ?? '';
  if (keyPrefix !== '') assertSafeKey(keyPrefix);
  const maxObjectBytes = opts.maxObjectBytes ?? MAX_OBJECT_BYTES_DEFAULT;
  const now = opts.now ?? (() => new Date());
  const objects = new Map<string, { body: Uint8Array; contentType: string; lastModified: Date }>();
  const full = (key: string): string => (keyPrefix === '' ? assertSafeKey(key) : `${keyPrefix}/${assertSafeKey(key)}`);

  return {
    kind: 'memory',
    async put(key, body, opts) {
      const k = full(key);
      const type = assertContentType(opts?.contentType);
      const bytes = assertBody(body, maxObjectBytes);
      objects.set(k, { body: new Uint8Array(bytes), contentType: type, lastModified: now() });
    },
    async get(key): Promise<StoredObject | null> {
      const o = objects.get(full(key));
      return o ? { body: new Uint8Array(o.body), contentType: o.contentType, size: o.body.byteLength } : null;
    },
    async delete(key) {
      objects.delete(full(key));
    },
    async exists(key) {
      return objects.has(full(key));
    },
    // Listing (Phase 11.6.4): ascending key order, `maxKeys` per page; the token is the last key returned (opaque to callers).
    async list(prefix, o) {
      const p = keyPrefix === '' ? assertSafePrefix(prefix) : `${keyPrefix}/${assertSafePrefix(prefix)}`;
      const max = assertMaxKeys(o?.maxKeys);
      const after = o?.token ?? null;
      if (after !== null && (typeof after !== 'string' || !after.startsWith(p))) throw new RangeError('invalid continuation token');
      const all = [...objects.keys()].filter((k) => k.startsWith(p) && (after === null || k > after)).sort();
      const page = all.slice(0, max);
      const out: ListedObject[] = [];
      let skipped = 0;
      for (const k of page) {
        const rel = keyPrefix === '' ? k : k.slice(keyPrefix.length + 1);
        const v = objects.get(k)!;
        if (isSafeKey(rel)) out.push({ key: rel, size: v.body.byteLength, lastModified: new Date(v.lastModified) });
        else skipped++;
      }
      return { objects: out, skipped, nextToken: all.length > max ? page[page.length - 1]! : null };
    },
    size: () => objects.size,
    keys: () => [...objects.keys()].sort(),
    touch(key, at) {
      const o = objects.get(full(key));
      if (!o) return false;
      o.lastModified = new Date(at);
      return true;
    },
  };
}

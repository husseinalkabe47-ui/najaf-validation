// Image processing rules (Phase 11.6.3), pure and codec-independent: from an uploaded original to a WebP main image and a WebP
// thumbnail, or a rejection with a machine reason. Nothing here touches storage or the database.
//
//  1. The original is checked again from its bytes (type, dimensions within MAX_IMAGE_SIDE / MAX_IMAGE_PIXELS): a stored object
//     is never trusted just because it was accepted at upload.
//  2. The decoder's own header reading (probe) must agree with it: same format, same dimensions, exactly one frame. A disagreement
//     (a polyglot, a crafted header) is a rejection.
//  3. The main image is rendered from the original (fits MAIN_MAX_SIDE), the thumbnail from the main image (fits THUMB_MAX_SIDE);
//     every render is bounded by the input pixel limit and a timeout (enforced here too, whatever the codec does).
//  4. Every output is validated on its BYTES (inspectWebp): a clean still WebP without EXIF/GPS/XMP/ICC or animation, whose real
//     dimensions are the reported ones, fit the bound, and keep the original's aspect ratio. Over the size budget, one lower quality
//     is tried; still over is a rejection.
import { createHash } from 'node:crypto';
import { CodecError } from './codec.ts';
import type { ImageCodec, Rendered } from './codec.ts';
import { sniffImage } from './image-sniff.ts';
import { MAX_IMAGE_PIXELS, MAX_IMAGE_SIDE } from './service.ts';
import { inspectWebp } from './webp-inspect.ts';

/** PROPOSED output settings and budgets. */
export const MAIN_MAX_SIDE = 1600;
export const THUMB_MAX_SIDE = 400;
export const MAIN_QUALITIES = [80, 60] as const;
export const THUMB_QUALITIES = [70, 50] as const;
export const MAX_MAIN_OUTPUT_BYTES = 1536 * 1024;
export const MAX_THUMB_OUTPUT_BYTES = 150 * 1024;
export const RENDER_TIMEOUT_MS = 15_000;

export type RejectReason = 'invalid_image' | 'unsupported' | 'too_large' | 'timeout' | 'inconsistent' | 'animated' | 'output_invalid' | 'output_too_large';
export class ImageRejected extends Error {
  readonly reason: RejectReason;
  constructor(reason: RejectReason) {
    super(`image rejected: ${reason}`);
    this.name = 'ImageRejected';
    this.reason = reason;
  }
}

export interface ProcessedImage {
  data: Uint8Array;
  width: number;
  height: number;
  sha256: string;
}
export interface ProcessResult {
  main: ProcessedImage;
  thumb: ProcessedImage;
}

const SNIFF_FORMAT = { 'image/jpeg': 'jpeg', 'image/png': 'png', 'image/webp': 'webp' } as const;

async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([p, new Promise<never>((_, reject) => (timer = setTimeout(() => reject(new CodecError('timeout')), ms)))]);
  } finally {
    clearTimeout(timer);
  }
}

const asRejection = (e: unknown): ImageRejected => (e instanceof ImageRejected ? e : e instanceof CodecError ? new ImageRejected(e.code) : new ImageRejected('invalid_image'));

/** The long/short ratio of the output must match the source's (orientation may swap the sides), within rounding. */
function keepsAspect(src: { width: number; height: number }, out: { width: number; height: number }): boolean {
  const ratio = (a: number, b: number) => Math.max(a, b) / Math.min(a, b);
  const want = ratio(src.width, src.height);
  const got = ratio(out.width, out.height);
  return Math.abs(got - want) <= want * 0.02 + 1 / Math.min(out.width, out.height);
}

async function renderChecked(codec: ImageCodec, input: Uint8Array, src: { width: number; height: number }, maxSide: number, qualities: readonly number[], maxBytes: number, timeoutMs: number): Promise<ProcessedImage> {
  for (const quality of qualities) {
    let r: Rendered;
    try {
      r = await withTimeout(codec.render(input, { maxSide, quality, maxInputPixels: MAX_IMAGE_PIXELS, timeoutMs }), timeoutMs + 1000);
    } catch (e) {
      throw asRejection(e);
    }
    if (!(r.data instanceof Uint8Array)) throw new ImageRejected('output_invalid');
    const info = inspectWebp(r.data);
    if (!info || info.width !== r.width || info.height !== r.height) throw new ImageRejected('output_invalid');
    if (Math.max(info.width, info.height) > maxSide || !keepsAspect(src, info)) throw new ImageRejected('output_invalid');
    // Never enlarged: the long side is the source's long side or the bound, whichever is smaller (1px rounding allowed).
    if (Math.max(info.width, info.height) > Math.max(src.width, src.height)) throw new ImageRejected('output_invalid');
    if (r.data.byteLength <= maxBytes) return { data: r.data, width: info.width, height: info.height, sha256: createHash('sha256').update(r.data).digest('hex') };
  }
  throw new ImageRejected('output_too_large');
}

/** `timeoutMs` exists for tests; production uses RENDER_TIMEOUT_MS. */
export async function processImage(original: Uint8Array, codec: ImageCodec, opts: { timeoutMs?: number } = {}): Promise<ProcessResult> {
  const timeoutMs = opts.timeoutMs ?? RENDER_TIMEOUT_MS;
  const sniffed = sniffImage(original);
  if (!sniffed) throw new ImageRejected('invalid_image');
  if (sniffed.width > MAX_IMAGE_SIDE || sniffed.height > MAX_IMAGE_SIDE || sniffed.width * sniffed.height > MAX_IMAGE_PIXELS) throw new ImageRejected('too_large');
  let probe;
  try {
    probe = await withTimeout(codec.probe(original, { maxInputPixels: MAX_IMAGE_PIXELS }), timeoutMs);
  } catch (e) {
    throw asRejection(e);
  }
  if (probe.pages !== 1) throw new ImageRejected('animated');
  if (probe.format !== SNIFF_FORMAT[sniffed.type] || probe.width !== sniffed.width || probe.height !== sniffed.height) throw new ImageRejected('inconsistent');
  const main = await renderChecked(codec, original, sniffed, MAIN_MAX_SIDE, MAIN_QUALITIES, MAX_MAIN_OUTPUT_BYTES, timeoutMs);
  const thumb = await renderChecked(codec, main.data, main, THUMB_MAX_SIDE, THUMB_QUALITIES, MAX_THUMB_OUTPUT_BYTES, timeoutMs);
  return { main, thumb };
}

// Secure asset upload (Phase 11.6.2): an authenticated account uploads ONE image and gets a 'pending' asset it owns.
//
// Decisions (each is covered by tests):
//  - WHO: the verified actor. car_image uploads are for members and dealers; showroom_cover uploads for dealers only (the
//    showroom-cover guard of migration 0004 accepts only the showroom owner's assets anyway). An administrator, a pending dealer
//    (no actor) or any other role is 403: there is no resource to hide yet.
//  - WHAT: the bytes decide. The declared Content-Type must be an accepted image type AND match what the bytes prove (PNG, JPEG or
//    still WebP, see image-sniff.ts); the dimensions must be within MAX_IMAGE_SIDE and MAX_IMAGE_PIXELS. A client filename is never
//    read. The size limit is the smaller of ASSET_UPLOAD_MAX_BYTES and the storage provider's object limit.
//  - WHERE: the storage key is generated here (incoming/<kind>/<random UUID>), never taken from the client, never returned, never
//    logged. The asset id (a different random UUID, from the database) is the only identifier the client sees.
//  - QUOTA: at most MAX_PENDING_PER_DAY unprocessed uploads per owner in 24 hours, checked under a per-owner lock (409 upload_limit).
//  - ORDER, so that no stored object is ever unknown to the database: (1) the 'pending' row (with its storage key) is committed
//    FIRST; (2) the object is written; (3) if writing fails, the object is deleted (idempotent; it may have been written before a
//    timeout) and only then the row; if that cleanup cannot finish, the row is KEPT so the cleanup job (pending rows older than
//    24 hours, migration 0003 index) still finds the key. The client gets 503 storage_unavailable either way.
//  - Reads: an asset is found only among the actor's own; anyone else's (an administrator's included) is the same 404 as unknown.
import { createHash, randomUUID } from 'node:crypto';
import { AuthzError, notFound } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError } from '../auth/validation.ts';
import { StorageError, assertSafeKey } from '../storage/index.ts';
import type { StorageProvider } from '../storage/index.ts';
import { sniffImage } from './image-sniff.ts';
import type { AssetRow, AssetStore } from './repository.ts';
import { parseAssetId, parseDeclaredType, parseUploadQuery } from './validation.ts';
import type { AssetKind } from './validation.ts';

/** PROPOSED limits. */
export const ASSET_UPLOAD_MAX_BYTES = 8 * 1024 * 1024;
export const MAX_IMAGE_SIDE = 10_000;
export const MAX_IMAGE_PIXELS = 40_000_000;
export const MAX_PENDING_PER_DAY = 30;

export type AssetErrorCode = 'validation_failed' | 'unsupported_media_type' | 'too_large' | 'upload_limit' | 'storage_unavailable';
const MESSAGES: Record<AssetErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  unsupported_media_type: 'Only JPEG, PNG and WebP images are accepted',
  too_large: 'The image is larger than allowed',
  upload_limit: 'Too many unprocessed uploads; try again later',
  storage_unavailable: 'The image could not be stored; try again later',
};
export class AssetError extends Error {
  readonly code: AssetErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: AssetErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'AssetError';
    this.code = code;
    this.fields = fields;
  }
}

/** What a client may see of its own asset. No storage key, thumbnail key, checksum, MIME column or owner. */
export interface OwnAsset {
  id: string;
  kind: string;
  status: string;
  bytes: number | null;
  width: number | null;
  height: number | null;
  createdAt: string;
}
export const toOwnAsset = (r: AssetRow): OwnAsset => ({ id: r.id, kind: r.kind, status: r.status, bytes: r.bytes, width: r.width, height: r.height, createdAt: r.createdAt.toISOString() });

export interface UploadInput {
  /** The query string (only `kind`). */
  query: unknown;
  /** The Content-Type header as received. */
  contentType: unknown;
  /** The raw request body. */
  body: unknown;
}
export interface RequestContext {
  requestId?: string | undefined;
}
export interface AssetLogger {
  warn(obj: Record<string, unknown>, msg?: string): void;
}

export interface AssetApi {
  upload(actor: Actor | null, input: UploadInput, ctx?: RequestContext): Promise<OwnAsset>;
  getOwn(actor: Actor | null, rawId: unknown): Promise<OwnAsset>;
}

const MAY_UPLOAD: Readonly<Record<AssetKind, readonly string[]>> = Object.freeze({ car_image: ['member', 'dealer'], showroom_cover: ['dealer'] });

/** Image processing (Phase 11.6.3), run right after a successful upload when supplied. Must not throw (it reports outcomes). */
export interface UploadProcessor {
  process(assetId: string, ownerId?: string): Promise<{ asset: AssetRow | null }>;
}

export function createAssetService(deps: { store: AssetStore; storage: StorageProvider; maxObjectBytes?: number; newKeyId?: () => string; logger?: AssetLogger; processor?: UploadProcessor }): AssetApi {
  const { store, storage } = deps;
  const maxBytes = Math.min(ASSET_UPLOAD_MAX_BYTES, deps.maxObjectBytes ?? ASSET_UPLOAD_MAX_BYTES);
  const newKeyId = deps.newKeyId ?? randomUUID;
  const log = deps.logger;

  /** Removes what a failed upload may have left. Returns true when nothing is left behind. */
  async function compensate(row: AssetRow, ownerId: string, key: string): Promise<boolean> {
    try {
      await storage.delete(key);
    } catch {
      return false; // the object may exist: keep the row so the cleanup job can find the key
    }
    try {
      return await store.transaction(({ assets }) => assets.deletePendingOwn(row.id, ownerId));
    } catch {
      return false;
    }
  }

  return {
    async upload(actor, input, ctx = {}) {
      if (!actor) throw new AuthzError('forbidden');
      const q = parseUploadQuery(input.query);
      if (!q.ok) throw new AssetError('validation_failed', q.errors);
      const { kind } = q.value;
      if (!MAY_UPLOAD[kind].includes(actor.role)) throw new AuthzError('forbidden');

      const declared = parseDeclaredType(input.contentType);
      if (declared === null) throw new AssetError('unsupported_media_type');
      if (!(input.body instanceof Uint8Array) || input.body.byteLength === 0) throw new AssetError('validation_failed', [{ field: 'body', code: 'required' }]);
      if (input.body.byteLength > maxBytes) throw new AssetError('too_large');
      // A private copy: the bytes checked, hashed and stored are the same bytes.
      const bytes = new Uint8Array(input.body);
      const image = sniffImage(bytes);
      if (!image || image.type !== declared) throw new AssetError('validation_failed', [{ field: 'body', code: 'invalid_format' }]);
      if (image.width > MAX_IMAGE_SIDE || image.height > MAX_IMAGE_SIDE || image.width * image.height > MAX_IMAGE_PIXELS) throw new AssetError('too_large');

      const storageKey = assertSafeKey(`incoming/${kind}/${newKeyId()}`);
      const sha256 = createHash('sha256').update(bytes).digest('hex');

      // (1) The row first, committed: from here on the key is known to the database.
      const row = await store.transaction(async ({ assets }) => {
        if (!(await assets.lockActingUser(actor.id))) throw new AuthzError('forbidden');
        await assets.lockUploadSlot(actor.id);
        if ((await assets.countRecentPending(actor.id)) >= MAX_PENDING_PER_DAY) throw new AssetError('upload_limit');
        return assets.insertPending({ ownerId: actor.id, kind, storageKey, bytes: bytes.byteLength, width: image.width, height: image.height, sha256 });
      });

      // (2) The object.
      try {
        await storage.put(storageKey, bytes, { contentType: image.type });
      } catch (e) {
        // (3) Compensation. Logged with ids and codes only (never the key).
        const clean = await compensate(row, actor.id, storageKey);
        log?.warn({ event: 'assets.upload_failed', assetId: row.id, reason: e instanceof StorageError ? e.code : 'error', cleanedUp: clean, requestId: ctx.requestId });
        throw new AssetError('storage_unavailable');
      }
      // (4) Processing (11.6.3): the answer carries the resulting state (ready, rejected, or still pending after a transient
      // failure). The upload itself has succeeded either way.
      if (deps.processor) {
        try {
          const processed = await deps.processor.process(row.id, actor.id);
          if (processed.asset) return toOwnAsset(processed.asset);
        } catch {
          log?.warn({ event: 'assets.processing_failed', assetId: row.id, stage: 'unexpected', requestId: ctx.requestId });
        }
      }
      return toOwnAsset(row);
    },

    async getOwn(actor, rawId) {
      const id = parseAssetId(rawId);
      if (!actor || id === null) throw notFound();
      const row = await store.assets.findOwn(id, actor.id);
      if (!row) throw notFound();
      return toOwnAsset(row);
    },
  };
}

// PostgreSQL access for uploaded assets (Phase 11.6.2). The existing `assets` table (migration 0003) is used as it is:
//  - an upload creates a 'pending' row owned by the verified actor, holding the server-generated storage key of the ORIGINAL
//    upload, its byte size, its SHA-256 and the dimensions read from its header. mime stays NULL (the table only admits the
//    processed format, image/webp) and thumb_key/ready_at stay NULL: 'ready' is the processing step's job (11.6.3);
//  - every read and the compensating delete are scoped by `owner_id = <the actor>`: another user's asset is simply not found;
//  - the compensating delete removes only a 'pending' row that nothing references (no car image, no showroom cover);
//  - a per-owner advisory transaction lock serializes the upload quota check with the insert;
//  - no SELECT *: storage_key, thumb_key and sha256 are written here but never read back by any statement in this module.
import type { Db, Tx } from '../db.ts';
import type { AssetKind } from './validation.ts';

export interface AssetRow {
  id: string;
  kind: string;
  status: string;
  bytes: number | null;
  width: number | null;
  height: number | null;
  createdAt: Date;
}

export interface NewPendingAsset {
  ownerId: string;
  kind: AssetKind;
  storageKey: string;
  bytes: number;
  width: number;
  height: number;
  sha256: string;
}

export interface AssetRepository {
  /** Re-checks INSIDE the transaction that the acting account is still active and not deleted, and SHARE-locks it to commit. */
  lockActingUser(userId: string): Promise<boolean>;
  /** Serializes this owner's uploads until the end of the transaction (quota check + insert). */
  lockUploadSlot(ownerId: string): Promise<void>;
  /** The owner's 'pending' assets created in the last 24 hours. */
  countRecentPending(ownerId: string): Promise<number>;
  insertPending(a: NewPendingAsset): Promise<AssetRow>;
  /** Compensation after a failed upload: deletes the owner's unreferenced 'pending' row. false = nothing deleted. */
  deletePendingOwn(id: string, ownerId: string): Promise<boolean>;
  /** One of the owner's assets; null for anything else (another owner's, unknown). */
  findOwn(id: string, ownerId: string): Promise<AssetRow | null>;
}

export interface AssetStore {
  assets: AssetRepository;
  transaction<T>(fn: (repos: { assets: AssetRepository }) => Promise<T>): Promise<T>;
}

const COLUMNS = 'a.id, a.kind, a.status, a.bytes, a.width, a.height, a.created_at';
interface SqlRow {
  id: string;
  kind: string;
  status: string;
  bytes: number | null;
  width: number | null;
  height: number | null;
  created_at: Date;
}
const toRow = (r: SqlRow): AssetRow => ({
  id: String(r.id),
  kind: r.kind,
  status: r.status,
  bytes: r.bytes === null ? null : Number(r.bytes),
  width: r.width === null ? null : Number(r.width),
  height: r.height === null ? null : Number(r.height),
  createdAt: r.created_at,
});

export const LOCK_ACTING_USER_SQL = `SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`;
export const LOCK_UPLOAD_SLOT_SQL = `SELECT pg_advisory_xact_lock(hashtextextended('najaf.asset-upload:' || $1::bigint::text, 0))`;
export const COUNT_RECENT_PENDING_SQL = `SELECT count(*)::int AS n FROM assets WHERE owner_id = $1::bigint AND status = 'pending' AND created_at > now() - interval '24 hours'`;

export function buildInsertPending(a: NewPendingAsset): { text: string; values: unknown[] } {
  return {
    text: `INSERT INTO assets AS a (owner_id, kind, status, storage_key, bytes, width, height, sha256)
           VALUES ($1::bigint, $2, 'pending', $3, $4, $5, $6, $7)
           RETURNING ${COLUMNS}`,
    values: [a.ownerId, a.kind, a.storageKey, a.bytes, a.width, a.height, a.sha256],
  };
}

export function buildDeletePendingOwn(id: string, ownerId: string): { text: string; values: unknown[] } {
  return {
    text: `DELETE FROM assets a
            WHERE a.id = $1::uuid AND a.owner_id = $2::bigint AND a.status = 'pending'
              AND NOT EXISTS (SELECT 1 FROM car_images ci WHERE ci.asset_id = a.id)
              AND NOT EXISTS (SELECT 1 FROM showrooms s WHERE s.cover_asset_id = a.id)`,
    values: [id, ownerId],
  };
}

export function buildFindOwn(id: string, ownerId: string): { text: string; values: unknown[] } {
  return { text: `SELECT ${COLUMNS} FROM assets a WHERE a.id = $1::uuid AND a.owner_id = $2::bigint`, values: [id, ownerId] };
}

export function createPgAssetRepository(q: Tx): AssetRepository {
  return {
    async lockActingUser(userId) {
      return (await q.query(LOCK_ACTING_USER_SQL, [userId])).rows.length === 1;
    },
    async lockUploadSlot(ownerId) {
      await q.query(LOCK_UPLOAD_SLOT_SQL, [ownerId]);
    },
    async countRecentPending(ownerId) {
      return Number((await q.query<{ n: number }>(COUNT_RECENT_PENDING_SQL, [ownerId])).rows[0]?.n ?? 0);
    },
    async insertPending(a) {
      const s = buildInsertPending(a);
      return toRow((await q.query<SqlRow>(s.text, s.values)).rows[0]!);
    },
    async deletePendingOwn(id, ownerId) {
      const s = buildDeletePendingOwn(id, ownerId);
      return ((await q.query(s.text, s.values)).rowCount ?? 0) === 1;
    },
    async findOwn(id, ownerId) {
      const s = buildFindOwn(id, ownerId);
      const r = (await q.query<SqlRow>(s.text, s.values)).rows[0];
      return r ? toRow(r) : null;
    },
  };
}

export function createPgAssetStore(db: Db): AssetStore {
  return {
    assets: createPgAssetRepository(db),
    transaction: (fn) => db.tx((t) => fn({ assets: createPgAssetRepository(t) })),
  };
}

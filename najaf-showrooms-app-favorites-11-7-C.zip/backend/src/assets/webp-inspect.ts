// Validation of PROCESSED output (Phase 11.6.3), independent of the codec that produced it. A processed object is accepted only if
// it is a well-formed RIFF/WebP file (exact size, every chunk inside the file) holding ONE still image, and carries NO metadata
// chunk: no EXIF (camera data, GPS position), no XMP, no ICC profile, no animation. So "metadata was stripped" is checked on the
// bytes that will be stored, whatever the codec did.
import { sniffImage } from './image-sniff.ts';

// An ALLOW-list: every other chunk is refused, in particular EXIF, 'XMP ', ICCP, ANIM and ANMF (metadata and animation).
const ALLOWED = new Set(['VP8 ', 'VP8L', 'VP8X', 'ALPH']);

export interface WebpInfo {
  width: number;
  height: number;
  chunks: string[];
}

/** The dimensions and chunk list of a clean, still WebP; null for anything else (including any metadata chunk). */
export function inspectWebp(bytes: Uint8Array): WebpInfo | null {
  const image = sniffImage(bytes);
  if (!image || image.type !== 'image/webp') return null;
  const chunks: string[] = [];
  let i = 12;
  while (i < bytes.length) {
    if (i + 8 > bytes.length) return null;
    const fourcc = String.fromCharCode(bytes[i]!, bytes[i + 1]!, bytes[i + 2]!, bytes[i + 3]!);
    const size = (bytes[i + 4]! | (bytes[i + 5]! << 8) | (bytes[i + 6]! << 16) | (bytes[i + 7]! << 24)) >>> 0;
    const next = i + 8 + size + (size & 1); // chunks are padded to an even size
    if (next > bytes.length) return null;
    if (!ALLOWED.has(fourcc)) return null;
    chunks.push(fourcc);
    i = next;
  }
  if (chunks.filter((c) => c === 'VP8 ' || c === 'VP8L').length !== 1) return null;
  if (chunks.includes('VP8X')) {
    // The extended header must not announce metadata or animation either (flags: ICC 0x20, EXIF 0x08, XMP 0x04, animation 0x02).
    if ((bytes[20]! & 0x2e) !== 0) return null;
  }
  return { width: image.width, height: image.height, chunks };
}

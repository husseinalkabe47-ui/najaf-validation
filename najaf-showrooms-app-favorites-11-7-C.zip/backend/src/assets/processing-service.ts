// Image processing orchestration (Phase 11.6.3): a 'pending' asset becomes 'ready' (WebP main + WebP thumbnail, metadata stripped)
// or 'rejected', and partial failures leave nothing unknown behind.
//
// Keys. The three objects of an asset share the random UUID of its original key, so ANY of them can be found from the row:
//    original  incoming/<kind>/<uuid>        (written at upload; storage_key while pending)
//    main      processed/<kind>/<uuid>.webp  (storage_key once ready)
//    thumbnail thumbs/<kind>/<uuid>.webp     (thumb_key once ready)
// derivedKeys() is exported for the cleanup job of a later step.
//
// Order:
//  1. read the pending row; read the original object; check its size and SHA-256 against the row (a changed object is rejected);
//  2. process it (processor.ts: decode with limits, orient, strip metadata, WebP, validate the bytes);
//  3. store main and thumbnail, then READ BOTH BACK and verify them (same SHA-256, a clean WebP of the expected size);
//  4. only then mark the row ready (compare-and-swap on the original key); 5. delete the original (best effort).
// Failures:
//  - the image itself is bad (malformed, unsupported, too large, decompression bomb, timeout, output over budget): the row becomes
//    'rejected' with a machine reason, and the original and any outputs are deleted (best effort; the row keeps the original key);
//  - storage or database trouble (transient): the row stays 'pending' (never public), outputs written by this attempt are deleted
//    (best effort; they stay findable from the row anyway), and the attempt reports 'pending';
//  - a lost compare-and-swap (the row was deleted or changed meanwhile): the outputs are deleted unless the row now points to them.
// Concurrency: at most `maxConcurrent` images are processed at once in this process (memory bound); the same asset is never
// processed twice at the same time in this process. Logs carry the asset id, the outcome and a reason code only.
import { createHash } from 'node:crypto';
import { StorageError } from '../storage/index.ts';
import type { StorageProvider } from '../storage/index.ts';
import type { ImageCodec } from './codec.ts';
import { ImageRejected, processImage } from './processor.ts';
import type { ProcessedImage } from './processor.ts';
import type { ProcessingRepository } from './processing-repository.ts';
import type { AssetRow } from './repository.ts';
import { inspectWebp } from './webp-inspect.ts';

export const MAX_CONCURRENT_PROCESSING = 2;

const ORIGINAL = /^incoming\/(car_image|showroom_cover)\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/;

/** The three object keys of an asset, from its original key; null for a key this module did not generate. */
export function derivedKeys(originalKey: string): { original: string; main: string; thumb: string } | null {
  const m = ORIGINAL.exec(originalKey);
  if (!m) return null;
  return { original: originalKey, main: `processed/${m[1]}/${m[2]}.webp`, thumb: `thumbs/${m[1]}/${m[2]}.webp` };
}

export type ProcessResultKind = 'ready' | 'rejected' | 'pending' | 'skipped';
export interface ProcessOutcome {
  result: ProcessResultKind;
  /** The updated asset when this attempt changed it (ready/rejected); null otherwise (the caller keeps what it has). */
  asset: AssetRow | null;
  /** A machine code (rejection reason, or why the attempt left the asset pending / skipped it). */
  reason?: string;
}

export interface AssetProcessorLogger {
  info(obj: Record<string, unknown>, msg?: string): void;
  warn(obj: Record<string, unknown>, msg?: string): void;
}

export interface AssetProcessor {
  /** Processes one pending asset. Never throws: every failure is an outcome. */
  process(assetId: string, ownerId?: string): Promise<ProcessOutcome>;
}

class Semaphore {
  private active = 0;
  private readonly waiting: Array<() => void> = [];
  private readonly max: number;
  constructor(max: number) {
    this.max = max;
  }
  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active >= this.max) await new Promise<void>((resolve) => this.waiting.push(resolve));
    this.active++;
    try {
      return await fn();
    } finally {
      this.active--;
      this.waiting.shift()?.();
    }
  }
}

const sha256 = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');

export function createAssetProcessor(deps: { repo: ProcessingRepository; storage: StorageProvider; codec: ImageCodec; logger?: AssetProcessorLogger; maxConcurrent?: number }): AssetProcessor {
  const { repo, storage, codec, logger } = deps;
  const gate = new Semaphore(deps.maxConcurrent ?? MAX_CONCURRENT_PROCESSING);
  const inFlight = new Set<string>();

  const quietDelete = async (keys: string[]): Promise<boolean> => {
    let all = true;
    for (const k of keys) {
      try {
        await storage.delete(k);
      } catch {
        all = false;
      }
    }
    return all;
  };

  /** Reads an object back and checks it is exactly what was written (hash), and a clean WebP of the expected size. */
  async function verifyStored(key: string, img: ProcessedImage): Promise<boolean> {
    const o = await storage.get(key);
    if (!o || sha256(o.body) !== img.sha256 || o.body.byteLength !== img.data.byteLength) return false;
    const info = inspectWebp(o.body);
    return info !== null && info.width === img.width && info.height === img.height;
  }

  async function reject(row: { id: string }, keys: { original: string; main: string; thumb: string }, reason: string): Promise<ProcessOutcome> {
    let asset: AssetRow | null;
    try {
      asset = await repo.markRejected({ id: row.id, originalKey: keys.original, reason });
    } catch {
      logger?.warn({ event: 'assets.processing_failed', assetId: row.id, stage: 'mark_rejected' });
      await quietDelete([keys.main, keys.thumb]);
      return { result: 'pending', asset: null, reason: 'database_unavailable' };
    }
    if (!asset) return { result: 'skipped', asset: null, reason: 'changed' };
    const clean = await quietDelete([keys.original, keys.main, keys.thumb]);
    logger?.info({ event: 'assets.processed', assetId: row.id, result: 'rejected', reason, cleanedUp: clean });
    return { result: 'rejected', asset, reason };
  }

  async function run(assetId: string, ownerId: string | undefined): Promise<ProcessOutcome> {
    let row;
    try {
      row = await repo.findForProcessing(assetId, ownerId ?? null);
    } catch {
      return { result: 'pending', asset: null, reason: 'database_unavailable' };
    }
    if (!row) return { result: 'skipped', asset: null, reason: 'not_found' };
    if (row.status !== 'pending' || !row.storageKey) return { result: 'skipped', asset: null, reason: 'not_pending' };
    const keys = derivedKeys(row.storageKey);
    if (!keys || !row.storageKey.startsWith(`incoming/${row.kind}/`)) {
      logger?.warn({ event: 'assets.processing_failed', assetId: row.id, stage: 'unexpected_key' });
      return { result: 'skipped', asset: null, reason: 'unexpected_key' };
    }

    // 1. The original, exactly as uploaded.
    let original: Uint8Array;
    try {
      const o = await storage.get(keys.original);
      if (!o) return reject(row, keys, 'missing_original');
      original = o.body;
    } catch (e) {
      if (e instanceof StorageError && e.code === 'too_large') return reject(row, keys, 'too_large');
      return { result: 'pending', asset: null, reason: 'storage_unavailable' };
    }
    if (row.bytes !== original.byteLength || row.sha256 !== sha256(original)) return reject(row, keys, 'integrity');

    // 2. Processing (CPU and memory bound, outside any database transaction).
    let out;
    try {
      out = await processImage(original, codec);
    } catch (e) {
      return reject(row, keys, e instanceof ImageRejected ? e.reason : 'invalid_image');
    }

    // 3. Store both, then read both back and verify.
    try {
      await storage.put(keys.main, out.main.data, { contentType: 'image/webp' });
      await storage.put(keys.thumb, out.thumb.data, { contentType: 'image/webp' });
      if (!(await verifyStored(keys.main, out.main)) || !(await verifyStored(keys.thumb, out.thumb))) throw new Error('verification failed');
    } catch (e) {
      const clean = await quietDelete([keys.main, keys.thumb]);
      const reason = e instanceof StorageError ? 'storage_unavailable' : 'verification_failed';
      logger?.warn({ event: 'assets.processing_failed', assetId: row.id, stage: 'store', reason, cleanedUp: clean });
      return { result: 'pending', asset: null, reason };
    }

    // 4. Ready, only now.
    let ready: AssetRow | null;
    try {
      ready = await repo.markReady({ id: row.id, originalKey: keys.original, mainKey: keys.main, thumbKey: keys.thumb, bytes: out.main.data.byteLength, width: out.main.width, height: out.main.height, sha256: out.main.sha256 });
    } catch {
      // Unknown outcome of the update: re-read before deciding whether the outputs are in use.
      const now = await repo.findForProcessing(row.id, null).catch(() => undefined);
      if (now && now.status === 'ready' && now.storageKey === keys.main) return { result: 'ready', asset: null, reason: 'confirmed_after_error' };
      if (now !== undefined) await quietDelete([keys.main, keys.thumb]);
      logger?.warn({ event: 'assets.processing_failed', assetId: row.id, stage: 'mark_ready' });
      return { result: 'pending', asset: null, reason: 'database_unavailable' };
    }
    if (!ready) {
      const now = await repo.findForProcessing(row.id, null).catch(() => undefined);
      if (!(now && now.status === 'ready' && now.storageKey === keys.main)) await quietDelete([keys.main, keys.thumb]);
      return { result: 'skipped', asset: null, reason: 'changed' };
    }

    // 5. The original is no longer needed (and never served). Best effort: it stays findable from the row's key otherwise.
    const originalGone = await quietDelete([keys.original]);
    logger?.info({ event: 'assets.processed', assetId: row.id, result: 'ready', originalDeleted: originalGone });
    return { result: 'ready', asset: ready };
  }

  return {
    async process(assetId, ownerId) {
      if (inFlight.has(assetId)) return { result: 'skipped', asset: null, reason: 'in_progress' };
      inFlight.add(assetId);
      try {
        return await gate.run(() => run(assetId, ownerId));
      } catch {
        // Defensive: run() handles its failures; anything else leaves the asset pending.
        return { result: 'pending', asset: null, reason: 'unexpected' };
      } finally {
        inFlight.delete(assetId);
      }
    },
  };
}

// The image codec seam (Phase 11.6.3). Everything that decodes or encodes pixels sits behind this small interface, so the
// processing rules (limits, output validation, storage, database states) are codec-independent and testable, and the native codec
// (sharp/libvips in production) stays replaceable. Every implementation must:
//  - refuse an image above maxInputPixels BEFORE decoding pixels, and give up after timeoutMs;
//  - decode ONE frame only; apply the EXIF orientation; convert to sRGB;
//  - output WebP with NO metadata (EXIF, GPS, XMP, ICC), fitting inside maxSide x maxSide, never enlarged;
//  - report failures as CodecError (never echoing the input).
// A shared contract test (test/unit/assets-codec-contract.test.ts) holds every implementation to these rules.

export type CodecErrorCode = 'invalid_image' | 'unsupported' | 'too_large' | 'timeout';
export class CodecError extends Error {
  readonly code: CodecErrorCode;
  constructor(code: CodecErrorCode) {
    super(`image codec: ${code}`);
    this.name = 'CodecError';
    this.code = code;
  }
}

export interface ProbeResult {
  format: 'jpeg' | 'png' | 'webp';
  /** As stored in the file (before applying the EXIF orientation). */
  width: number;
  height: number;
  /** Number of frames/pages; anything but 1 is refused by the processor. */
  pages: number;
}

export interface RenderOptions {
  maxSide: number;
  quality: number;
  maxInputPixels: number;
  timeoutMs: number;
}

export interface Rendered {
  data: Uint8Array;
  width: number;
  height: number;
}

export interface ImageCodec {
  readonly name: string;
  /** Reads the header through the decoder (no pixel decoding). */
  probe(input: Uint8Array, opts: { maxInputPixels: number }): Promise<ProbeResult>;
  /** Decodes, orients, strips metadata, fits inside maxSide and encodes WebP. */
  render(input: Uint8Array, opts: RenderOptions): Promise<Rendered>;
}

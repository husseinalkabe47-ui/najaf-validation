// A dealer's showroom cover image (Phase 11.6.4): attach one of the dealer's own READY showroom_cover assets, or remove it.
//
// Decisions (each is covered by tests):
//  - WHO: an active dealer acting on THEIR OWN showroom (found by owner_id = the verified actor; never an id from the request), via
//    the existing policy (showroom 'update' = the owner, whatever the showroom's status). A guest, a member, an administrator, a
//    pending or suspended dealer, a dealer without a showroom: the same 404. No new role or permission.
//  - WHAT: the asset must be the dealer's own (another user's asset is 404, identical to an unknown one), of kind showroom_cover,
//    'ready' (processed: a pending or rejected upload is never attached, so an original upload is never exposed) and servable (its
//    keys are processed outputs, not originals). Otherwise 409 invalid_state. The database guard (showrooms_cover_guard) is the
//    backstop: a violation it reports is also invalid_state.
//  - HOW: one transaction: the acting account re-checked and SHARE-locked, the showroom locked FOR UPDATE, then a single UPDATE of
//    cover_asset_id. Setting the current cover again writes nothing. Removing a cover that is not set writes nothing (204 anyway).
//  - The previous cover asset is NOT deleted: it stays the dealer's ready asset. (Ready, unattached assets are not removed by the
//    cleanup job of this step; see README.)
//  - No audit row: the audit action vocabulary belongs to the Phase 11.5 audit writer and is not changed by this step.
import { DbError } from '../errors.ts';
import { authorize, notFound, showroomResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError, Parsed } from '../auth/validation.ts';
import type { CoverStore } from './cover-repository.ts';
import { parseAssetId } from './validation.ts';

export type CoverErrorCode = 'validation_failed' | 'invalid_state';
const MESSAGES: Record<CoverErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  invalid_state: 'The image cannot be used as a cover in its current state',
};
export class CoverError extends Error {
  readonly code: CoverErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: CoverErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'CoverError';
    this.code = code;
    this.fields = fields;
  }
}

/** What the dealer sees of the cover: the asset id and its size. No key, checksum or owner. */
export interface CoverView {
  assetId: string;
  width: number | null;
  height: number | null;
}

export interface ShowroomCoverApi {
  getCover(actor: Actor | null): Promise<{ cover: CoverView | null }>;
  setCover(actor: Actor | null, body: unknown): Promise<{ cover: CoverView }>;
  clearCover(actor: Actor | null): Promise<void>;
}

const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

/** {assetId: <uuid>} and nothing else. */
export function parseSetCoverInput(body: unknown): Parsed<{ assetId: string }> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = Object.keys(body).filter((k) => k !== 'assetId').map((k) => ({ field: SAFE_FIELD.test(k) ? k : 'unknown', code: 'unknown_field' }));
  const raw = body['assetId'];
  let assetId: string | null = null;
  if (raw === undefined || raw === null) errors.push({ field: 'assetId', code: 'required' });
  else if (typeof raw !== 'string') errors.push({ field: 'assetId', code: 'invalid_type' });
  else if ((assetId = parseAssetId(raw)) === null) errors.push({ field: 'assetId', code: 'invalid_format' });
  if (errors.length > 0 || assetId === null) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { assetId } };
}

const isDealer = (actor: Actor | null): actor is Actor => actor !== null && actor.role === 'dealer';

export function createShowroomCoverService(deps: { store: CoverStore }): ShowroomCoverApi {
  const { store } = deps;

  return {
    async getCover(actor) {
      if (!isDealer(actor)) throw notFound();
      const row = await store.covers.findOwnCover(actor.id);
      if (!row) throw notFound();
      authorize(actor, 'read', showroomResource({ ownerId: row.showroom.ownerId, status: row.showroom.status, ownerActive: true }));
      return { cover: row.cover };
    },

    async setCover(actor, body) {
      if (!isDealer(actor)) throw notFound();
      const input = parseSetCoverInput(body);
      if (!input.ok) throw new CoverError('validation_failed', input.errors);
      const { assetId } = input.value;
      try {
        return await store.transaction(async ({ covers }) => {
          if (!(await covers.lockActingUser(actor.id))) throw notFound();
          const showroom = await covers.lockOwnShowroom(actor.id);
          if (!showroom) throw notFound();
          authorize(actor, 'update', showroomResource({ ownerId: showroom.ownerId, status: showroom.status, ownerActive: true }));
          const asset = await covers.findOwnAsset(assetId, actor.id);
          if (!asset) throw notFound();
          if (asset.kind !== 'showroom_cover' || asset.status !== 'ready' || !asset.servable) throw new CoverError('invalid_state');
          const cover = { assetId: asset.id, width: asset.width, height: asset.height };
          if (showroom.coverAssetId === asset.id) return { cover };
          if (!(await covers.setCover(showroom.id, actor.id, asset.id))) throw notFound();
          return { cover };
        });
      } catch (e) {
        // The database guard disagreed (e.g. the asset changed between the read and the write): never a 500, never a detail.
        if (e instanceof DbError && (e.kind === 'check' || e.kind === 'forbidden' || e.kind === 'foreign_key')) throw new CoverError('invalid_state');
        throw e;
      }
    },

    async clearCover(actor) {
      if (!isDealer(actor)) throw notFound();
      await store.transaction(async ({ covers }) => {
        if (!(await covers.lockActingUser(actor.id))) throw notFound();
        const showroom = await covers.lockOwnShowroom(actor.id);
        if (!showroom) throw notFound();
        authorize(actor, 'update', showroomResource({ ownerId: showroom.ownerId, status: showroom.status, ownerActive: true }));
        if (showroom.coverAssetId !== null && !(await covers.setCover(showroom.id, actor.id, null))) throw notFound();
      });
    },
  };
}

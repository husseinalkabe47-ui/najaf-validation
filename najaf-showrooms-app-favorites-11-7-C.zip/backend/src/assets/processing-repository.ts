// PostgreSQL access for image processing (Phase 11.6.3), on the existing `assets` table (no migration):
//  - the asset is read by id (and by owner when the caller knows it); this module, unlike the upload repository, reads the
//    storage key and checksum, because processing needs them. They never leave the server (see processing-service.ts);
//  - marking READY and marking REJECTED are compare-and-swap updates on (status = 'pending' AND storage_key = the original key),
//    so a row that changed in the meantime (deleted, already processed) is never overwritten. READY fills exactly the columns the
//    assets_ready_shape CHECK requires (storage_key, thumb_key, mime = 'image/webp', bytes, width, height, sha256, ready_at);
//  - REJECTED keeps the original key (so whatever is left in storage stays findable) and a machine reason only.
import type { Tx } from '../db.ts';
import type { AssetRow } from './repository.ts';

export interface ProcessingRow {
  id: string;
  ownerId: string;
  kind: string;
  status: string;
  storageKey: string | null;
  bytes: number | null;
  sha256: string | null;
}

export interface ReadyInput {
  id: string;
  originalKey: string;
  mainKey: string;
  thumbKey: string;
  bytes: number;
  width: number;
  height: number;
  sha256: string;
}

export interface ProcessingRepository {
  findForProcessing(id: string, ownerId: string | null): Promise<ProcessingRow | null>;
  markReady(input: ReadyInput): Promise<AssetRow | null>;
  markRejected(input: { id: string; originalKey: string; reason: string }): Promise<AssetRow | null>;
}

const PUBLIC = 'a.id, a.kind, a.status, a.bytes, a.width, a.height, a.created_at';
interface PublicSql {
  id: string;
  kind: string;
  status: string;
  bytes: number | null;
  width: number | null;
  height: number | null;
  created_at: Date;
}
const toAsset = (r: PublicSql): AssetRow => ({
  id: String(r.id),
  kind: r.kind,
  status: r.status,
  bytes: r.bytes === null ? null : Number(r.bytes),
  width: r.width === null ? null : Number(r.width),
  height: r.height === null ? null : Number(r.height),
  createdAt: r.created_at,
});

export function buildFindForProcessing(id: string, ownerId: string | null): { text: string; values: unknown[] } {
  return ownerId === null
    ? { text: `SELECT a.id, a.owner_id, a.kind, a.status, a.storage_key, a.bytes, a.sha256 FROM assets a WHERE a.id = $1::uuid`, values: [id] }
    : { text: `SELECT a.id, a.owner_id, a.kind, a.status, a.storage_key, a.bytes, a.sha256 FROM assets a WHERE a.id = $1::uuid AND a.owner_id = $2::bigint`, values: [id, ownerId] };
}

export function buildMarkReady(i: ReadyInput): { text: string; values: unknown[] } {
  return {
    text: `UPDATE assets a SET status = 'ready', storage_key = $3, thumb_key = $4, mime = 'image/webp', bytes = $5, width = $6, height = $7, sha256 = $8, ready_at = now()
            WHERE a.id = $1::uuid AND a.status = 'pending' AND a.storage_key = $2
        RETURNING ${PUBLIC}`,
    values: [i.id, i.originalKey, i.mainKey, i.thumbKey, i.bytes, i.width, i.height, i.sha256],
  };
}

export function buildMarkRejected(i: { id: string; originalKey: string; reason: string }): { text: string; values: unknown[] } {
  return {
    text: `UPDATE assets a SET status = 'rejected', reject_reason = $3
            WHERE a.id = $1::uuid AND a.status = 'pending' AND a.storage_key = $2
        RETURNING ${PUBLIC}`,
    values: [i.id, i.originalKey, i.reason],
  };
}

export function createPgProcessingRepository(q: Tx): ProcessingRepository {
  return {
    async findForProcessing(id, ownerId) {
      const s = buildFindForProcessing(id, ownerId);
      const r = (await q.query<{ id: string; owner_id: string; kind: string; status: string; storage_key: string | null; bytes: number | null; sha256: string | null }>(s.text, s.values)).rows[0];
      return r ? { id: String(r.id), ownerId: String(r.owner_id), kind: r.kind, status: r.status, storageKey: r.storage_key, bytes: r.bytes === null ? null : Number(r.bytes), sha256: r.sha256 === null ? null : String(r.sha256).trim() } : null;
    },
    async markReady(input) {
      const s = buildMarkReady(input);
      const r = (await q.query<PublicSql>(s.text, s.values)).rows[0];
      return r ? toAsset(r) : null;
    },
    async markRejected(input) {
      const s = buildMarkRejected(input);
      const r = (await q.query<PublicSql>(s.text, s.values)).rows[0];
      return r ? toAsset(r) : null;
    },
  };
}

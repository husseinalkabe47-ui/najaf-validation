// HTTP contract for a dealer's showroom cover (Phase 11.6.4). Thin: decisions live in assets/cover.ts. Imports Fastify TYPES only.
//
//   GET    /v1/dealer/showroom/cover   Bearer                       -> 200 {cover: {assetId, width, height} | null}
//   PUT    /v1/dealer/showroom/cover   Bearer, JSON {assetId}       -> 200 {cover}
//   DELETE /v1/dealer/showroom/cover   Bearer, no body              -> 204
//
// Errors: 401 no/invalid token; 404 not an active dealer with a showroom, or an asset that is not the caller's (identical to an
// unknown asset); 400 invalid body, a malformed asset id included (field names and codes only); 409 invalid_state (not a ready,
// processed showroom_cover); 415 a non-JSON body. Responses never carry a storage key, a checksum or an owner.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { CoverError } from './cover.ts';
import type { ShowroomCoverApi } from './cover.ts';

/** PROPOSED, per client address and per instance. */
export const COVER_RATE_LIMITS = {
  read: { limit: 240, windowSeconds: 10 * 60 },
  write: { limit: 60, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type CoverRateLimitedRoute = keyof typeof COVER_RATE_LIMITS;

const STATUS: Record<CoverError['code'], number> = { validation_failed: 400, invalid_state: 409 };

export function toCoverHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof CoverError) return { status: STATUS[e.code], code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };
const PATH = '/v1/dealer/showroom/cover';

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

export function registerShowroomCoverRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; covers: ShowroomCoverApi; rateLimiter?: RateLimiter }): void {
  const { auth, covers, rateLimiter } = deps;

  const limited = (route: CoverRateLimitedRoute): Hook[] =>
    rateLimiter
      ? [
          async (request, reply) => {
            const decision = rateLimiter.consume(`showroom_cover.${route}:${request.ip}`, COVER_RATE_LIMITS[route]);
            if (decision.allowed) return undefined;
            request.log.warn({ event: 'showroom_cover.rate_limited', route });
            reply.header('retry-after', String(decision.retryAfterSeconds));
            return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
          },
        ]
      : [];

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toCoverHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  app.get(PATH, { onRequest: limited('read') }, async (request, reply) => {
    try {
      return reply.code(200).send(await covers.getCover(await identify(request)));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.put(PATH, { bodyLimit: 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const result = await covers.setCover(actor, request.body);
      request.log.info({ event: 'showroom_cover.set', assetId: result.cover.assetId });
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.delete(PATH, { bodyLimit: 1024, onRequest: limited('write') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      if (request.body !== undefined && request.body !== null) throw new CoverError('validation_failed', [{ field: 'body', code: 'unknown_field' }]);
      await covers.clearCover(actor);
      request.log.info({ event: 'showroom_cover.cleared' });
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

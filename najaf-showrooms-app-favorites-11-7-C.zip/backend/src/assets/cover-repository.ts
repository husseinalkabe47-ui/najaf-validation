// PostgreSQL access for a dealer's showroom COVER (Phase 11.6.4), on the existing tables (no migration). Rules:
//  - the showroom is found ONLY by owner_id = the verified actor (showrooms.owner_id is UNIQUE), and locked FOR UPDATE while the
//    cover changes; the asset is found ONLY by owner_id = the verified actor: another user's asset is simply not found;
//  - the only column written is showrooms.cover_asset_id (the application role's column grant, migration 0013); the database's
//    showrooms_cover_guard trigger (a ready showroom_cover of the showroom owner) remains the backstop;
//  - whether an asset is servable (its main and thumbnail keys exist and are not original uploads under incoming/) is computed in
//    SQL: the keys themselves are never read into the application here.
import type { Db, Tx } from '../db.ts';
import { LOCK_ACTING_USER_SQL } from './repository.ts';

export interface CoverShowroomRow {
  id: string;
  ownerId: string;
  status: string;
  coverAssetId: string | null;
}
export interface CoverAssetRow {
  id: string;
  kind: string;
  status: string;
  servable: boolean;
  width: number | null;
  height: number | null;
}
export interface OwnCoverRow {
  showroom: CoverShowroomRow;
  cover: { assetId: string; width: number | null; height: number | null } | null;
}

export interface CoverRepository {
  /** The acting account is still active and not deleted (SHARE-locked until commit). */
  lockActingUser(userId: string): Promise<boolean>;
  /** The actor's own showroom, locked FOR UPDATE; null if none. */
  lockOwnShowroom(ownerId: string): Promise<CoverShowroomRow | null>;
  /** One of the actor's assets; null for anyone else's or unknown. */
  findOwnAsset(assetId: string, ownerId: string): Promise<CoverAssetRow | null>;
  /** Sets (or clears, with null) the cover of the actor's showroom. false = no such showroom of this owner. */
  setCover(showroomId: string, ownerId: string, assetId: string | null): Promise<boolean>;
  /** Autocommit read of the actor's showroom and its cover. */
  findOwnCover(ownerId: string): Promise<OwnCoverRow | null>;
}
export interface CoverStore {
  covers: CoverRepository;
  transaction<T>(fn: (repos: { covers: CoverRepository }) => Promise<T>): Promise<T>;
}

export const LOCK_OWN_SHOWROOM_SQL = `SELECT s.id, s.owner_id, s.status, s.cover_asset_id FROM showrooms s WHERE s.owner_id = $1::bigint FOR UPDATE`;
export const FIND_OWN_COVER_ASSET_SQL = `SELECT a.id, a.kind, a.status, a.width, a.height,
       (a.storage_key IS NOT NULL AND a.thumb_key IS NOT NULL AND a.storage_key NOT LIKE 'incoming/%' AND a.thumb_key NOT LIKE 'incoming/%') AS servable
  FROM assets a WHERE a.id = $1::uuid AND a.owner_id = $2::bigint`;
export const SET_COVER_SQL = `UPDATE showrooms SET cover_asset_id = $3::uuid WHERE id = $1::bigint AND owner_id = $2::bigint`;
export const FIND_OWN_COVER_SQL = `SELECT s.id, s.owner_id, s.status, s.cover_asset_id, a.width, a.height
  FROM showrooms s LEFT JOIN assets a ON a.id = s.cover_asset_id WHERE s.owner_id = $1::bigint`;

interface ShowroomSql {
  id: string;
  owner_id: string;
  status: string;
  cover_asset_id: string | null;
}
const toShowroom = (r: ShowroomSql): CoverShowroomRow => ({ id: String(r.id), ownerId: String(r.owner_id), status: r.status, coverAssetId: r.cover_asset_id === null ? null : String(r.cover_asset_id) });
const num = (v: number | null): number | null => (v === null ? null : Number(v));

export function createPgCoverRepository(q: Tx): CoverRepository {
  return {
    async lockActingUser(userId) {
      return (await q.query(LOCK_ACTING_USER_SQL, [userId])).rows.length === 1;
    },
    async lockOwnShowroom(ownerId) {
      const r = (await q.query<ShowroomSql>(LOCK_OWN_SHOWROOM_SQL, [ownerId])).rows[0];
      return r ? toShowroom(r) : null;
    },
    async findOwnAsset(assetId, ownerId) {
      const r = (await q.query<{ id: string; kind: string; status: string; servable: boolean; width: number | null; height: number | null }>(FIND_OWN_COVER_ASSET_SQL, [assetId, ownerId])).rows[0];
      return r ? { id: String(r.id), kind: r.kind, status: r.status, servable: r.servable === true, width: num(r.width), height: num(r.height) } : null;
    },
    async setCover(showroomId, ownerId, assetId) {
      return ((await q.query(SET_COVER_SQL, [showroomId, ownerId, assetId])).rowCount ?? 0) === 1;
    },
    async findOwnCover(ownerId) {
      const r = (await q.query<ShowroomSql & { width: number | null; height: number | null }>(FIND_OWN_COVER_SQL, [ownerId])).rows[0];
      if (!r) return null;
      const showroom = toShowroom(r);
      return { showroom, cover: showroom.coverAssetId === null ? null : { assetId: showroom.coverAssetId, width: num(r.width), height: num(r.height) } };
    },
  };
}

export function createPgCoverStore(db: Db): CoverStore {
  return {
    covers: createPgCoverRepository(db),
    transaction: (fn) => db.tx((t) => fn({ covers: createPgCoverRepository(t) })),
  };
}

// Request validation for asset upload (Phase 11.6.2). The ONLY client inputs are: the asset kind (query string), the declared
// Content-Type (header) and the raw bytes (body). There is no filename, storage key, owner, status or size field anywhere:
// those are decided by the server. Errors carry a field name and a code only, never the submitted value.
import type { FieldError, Parsed } from '../auth/validation.ts';
import { IMAGE_TYPES } from './image-sniff.ts';
import type { ImageType } from './image-sniff.ts';

export const ASSET_KINDS = ['car_image', 'showroom_cover'] as const;
export type AssetKind = (typeof ASSET_KINDS)[number];

const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

export function parseUploadQuery(query: unknown): Parsed<{ kind: AssetKind }> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  for (const k of Object.keys(q)) if (k !== 'kind') errors.push({ field: SAFE_FIELD.test(k) ? k : 'unknown', code: 'unknown_field' });
  const raw = q['kind'];
  let kind: AssetKind | undefined;
  if (raw === undefined) errors.push({ field: 'kind', code: 'required' });
  else if (typeof raw !== 'string') errors.push({ field: 'kind', code: 'invalid_type' });
  else if (!(ASSET_KINDS as readonly string[]).includes(raw)) errors.push({ field: 'kind', code: 'invalid_format' });
  else kind = raw as AssetKind;
  if (errors.length > 0 || kind === undefined) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { kind } };
}

/** The declared media type: exactly one of the accepted image types (case-insensitive), no parameters. null otherwise. */
export function parseDeclaredType(header: unknown): ImageType | null {
  if (typeof header !== 'string') return null;
  const t = header.trim().toLowerCase();
  return (IMAGE_TYPES as readonly string[]).includes(t) ? (t as ImageType) : null;
}

/** An asset id from the path: a canonical UUID (lower-cased), else null (answered 404, never 400). */
export function parseAssetId(raw: unknown): string | null {
  return typeof raw === 'string' && UUID.test(raw) ? raw.toLowerCase() : null;
}

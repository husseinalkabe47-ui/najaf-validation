// Image type detection from the BYTES (Phase 11.6.2). The client's declared Content-Type is only a claim; a filename is never read.
// Only three formats are accepted, each parsed just far enough to prove its structure and read the dimensions:
//  - PNG:  signature, a first IHDR chunk of length 13 with a valid CRC, a legal bit depth/colour type pair, and IEND as the very
//          last chunk (so nothing can be appended after the image);
//  - JPEG: SOI, then a bounds-checked walk over the marker segments to a baseline, extended or progressive frame header (SOF0-SOF2),
//          and an EOI marker after it;
//  - WebP: a RIFF container whose declared size matches the upload exactly, holding a still VP8, VP8L or VP8X image (animated
//          WebP is refused).
// Anything else (GIF, BMP, TIFF, SVG, HTML, a truncated or malformed file) is null. No pixel is decoded here: decoding, resizing and
// re-encoding are the processing step (11.6.3), which is also where the content is fully validated.
import { crc32 } from 'node:zlib';

export type ImageType = 'image/jpeg' | 'image/png' | 'image/webp';
export const IMAGE_TYPES: readonly ImageType[] = ['image/jpeg', 'image/png', 'image/webp'];

export interface SniffedImage {
  type: ImageType;
  width: number;
  height: number;
}

const be16 = (b: Uint8Array, i: number) => (b[i]! << 8) | b[i + 1]!;
const be32 = (b: Uint8Array, i: number) => ((b[i]! << 24) >>> 0) + (b[i + 1]! << 16) + (b[i + 2]! << 8) + b[i + 3]!;
const le16 = (b: Uint8Array, i: number) => b[i]! | (b[i + 1]! << 8);
const le24 = (b: Uint8Array, i: number) => b[i]! | (b[i + 1]! << 8) | (b[i + 2]! << 16);
const le32 = (b: Uint8Array, i: number) => (b[i]! | (b[i + 1]! << 8) | (b[i + 2]! << 16) | (b[i + 3]! << 24)) >>> 0;
const ascii = (b: Uint8Array, i: number, s: string) => s.split('').every((c, k) => b[i + k] === c.charCodeAt(0));

const PNG_SIGNATURE = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
const PNG_DEPTHS: Record<number, number[]> = { 0: [1, 2, 4, 8, 16], 2: [8, 16], 3: [1, 2, 4, 8], 4: [8, 16], 6: [8, 16] };
const PNG_IEND = [0, 0, 0, 0, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82];

function png(b: Uint8Array): SniffedImage | null {
  if (b.length < 8 + 25 + 12 || !PNG_SIGNATURE.every((v, i) => b[i] === v)) return null;
  if (be32(b, 8) !== 13 || !ascii(b, 12, 'IHDR')) return null;
  if (crc32(b.subarray(12, 29)) !== be32(b, 29)) return null;
  const width = be32(b, 16);
  const height = be32(b, 20);
  const depth = b[24]!;
  const colour = b[25]!;
  if (width === 0 || height === 0 || width > 0x7fffffff || height > 0x7fffffff) return null;
  if (!(PNG_DEPTHS[colour] ?? []).includes(depth) || b[26] !== 0 || b[27] !== 0 || (b[28] !== 0 && b[28] !== 1)) return null;
  if (!PNG_IEND.every((v, i) => b[b.length - 12 + i] === v)) return null;
  return { type: 'image/png', width, height };
}

const JPEG_FRAMES = new Set([0xc0, 0xc1, 0xc2]); // baseline, extended sequential, progressive (Huffman)
const JPEG_OTHER_FRAMES = new Set([0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);

function jpeg(b: Uint8Array): SniffedImage | null {
  if (b.length < 4 || b[0] !== 0xff || b[1] !== 0xd8 || b[2] !== 0xff) return null;
  let i = 2;
  while (i < b.length) {
    if (b[i] !== 0xff) return null;
    while (i < b.length && b[i] === 0xff) i++; // fill bytes
    if (i >= b.length) return null;
    const marker = b[i]!;
    i++;
    if (marker === 0xd8 || marker === 0xd9 || marker === 0xda || marker === 0x00) return null; // SOI again, EOI/SOS before a frame
    if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue; // standalone markers
    if (i + 2 > b.length) return null;
    const len = be16(b, i);
    if (len < 2 || i + len > b.length) return null;
    if (JPEG_OTHER_FRAMES.has(marker)) return null; // lossless / arithmetic / hierarchical: refused
    if (JPEG_FRAMES.has(marker)) {
      if (len < 8) return null;
      const height = be16(b, i + 3);
      const width = be16(b, i + 5);
      const components = b[i + 7]!;
      if (width === 0 || height === 0 || (components !== 1 && components !== 3 && components !== 4) || len !== 8 + 3 * components) return null;
      // The image data must be complete: an EOI marker after the frame header.
      for (let k = b.length - 2; k >= i + len; k--) if (b[k] === 0xff && b[k + 1] === 0xd9) return { type: 'image/jpeg', width, height };
      return null;
    }
    i += len;
  }
  return null;
}

function webp(b: Uint8Array): SniffedImage | null {
  if (b.length < 30 || !ascii(b, 0, 'RIFF') || !ascii(b, 8, 'WEBP')) return null;
  if (le32(b, 4) + 8 !== b.length) return null;
  const chunkSize = le32(b, 16);
  if (20 + chunkSize > b.length) return null;
  if (ascii(b, 12, 'VP8 ')) {
    if (chunkSize < 10 || (b[20]! & 0x01) !== 0) return null; // must be a key frame
    if (b[23] !== 0x9d || b[24] !== 0x01 || b[25] !== 0x2a) return null;
    const width = le16(b, 26) & 0x3fff;
    const height = le16(b, 28) & 0x3fff;
    return width > 0 && height > 0 ? { type: 'image/webp', width, height } : null;
  }
  if (ascii(b, 12, 'VP8L')) {
    if (chunkSize < 5 || b[20] !== 0x2f) return null;
    const bits = le32(b, 21);
    if (bits >>> 29 !== 0) return null; // version must be 0
    return { type: 'image/webp', width: (bits & 0x3fff) + 1, height: ((bits >>> 14) & 0x3fff) + 1 };
  }
  if (ascii(b, 12, 'VP8X')) {
    if (chunkSize < 10) return null;
    if ((b[20]! & 0x02) !== 0) return null; // animation flag: animated WebP refused
    return { type: 'image/webp', width: le24(b, 24) + 1, height: le24(b, 27) + 1 };
  }
  return null;
}

/** The image type and dimensions proven by the bytes, or null when the bytes are not an accepted image. */
export function sniffImage(bytes: Uint8Array): SniffedImage | null {
  if (!(bytes instanceof Uint8Array) || bytes.length === 0) return null;
  return png(bytes) ?? jpeg(bytes) ?? webp(bytes);
}

// Asset INTEGRITY AUDIT (Phase 11.6.6): compares the database records of images with the stored objects, in both directions, and
// reports. Run by an operator or a scheduler through scripts/assets-audit.ts; never by an HTTP route. DRY-RUN unless told otherwise.
//
// Direction 1, records -> objects. Every 'ready' asset (keyset-paged, bounded) has a main image and a thumbnail. Each is read and
// checked: missing; unreadable (too large for the storage limit, unsafe key); not a clean still WebP (inspectWebp, the same rule
// the processor applies to what it stores); and, for the main image, where the record makes it verifiable, the byte size, the
// SHA-256 and the dimensions. (The thumbnail has no recorded checksum or size: it is checked as a WebP and for not being larger
// than the main image.) Verdict per asset: missing > corrupt > failed (could not be verified) > healthy.
//   An asset that is referenced by a car or a showroom (a car image or a cover) and is missing or corrupt is REPORT-ONLY: no
//   code path of this module deletes a referenced asset, an object it references or a database record because of its health.
// Direction 2, objects -> records. The three areas the backend writes (incoming/, processed/, thumbs/) are listed page by page
// and every object is looked up in the database (any row's storage_key or thumb_key; a processed image or thumbnail is also
// referenced by the row of its original/main image). The lookup is the same one the cleanup job uses.
//
// What may be DELETED (only with an explicit `dryRun: false`), and nothing else:
//   - an UNLINKED asset: 'ready', referenced by nothing (decided by the database in the same statement that lists it), older than
//     the grace period since it became ready, whose keys have exactly the shape this backend generates. The row is removed first by
//     a locked compare-and-swap that re-checks all of that (audit-repository.ts), then its objects (the original, the main image
//     and the thumbnail, all derived from the row's key). If removing the objects fails they become orphans for a later run.
//   - an ORPHANED object: its key has a shape this backend generates, it is older than the grace period (by the storage's
//     last-modified time), and a database lookup that SUCCEEDED found no row referencing it, confirmed by a second lookup right
//     before the delete.
//   The grace period defaults to 24 hours and is never less (a shorter one could delete an upload that is about to be attached).
//
// Safety rule: the run has two passes. Pass 1 only READS (and collects what could be deleted). Pass 2 deletes, and runs only if
// pass 1 finished with NO failed or uncertain check: a database error, a storage error that survived its retries, an unexpected
// error or an unverifiable asset blocks every deletion of this run ("blocked" in the report). A failed query is never read as
// "nothing references this". Within pass 2, the first database or storage failure stops the deletions.
// Bounds: at most `maxBatches` pages of `batchSize` records and at most `maxBatches` pages of `batchSize` object keys per run
// ("complete": false when a limit was reached; a uuid shard narrows the object listing). Reads are retried (database and storage
// are idempotent to read; storage deletes are idempotent too); the delete of a row is never retried.
// The report has counts and (for referenced problems) asset ids only: never a storage key, bucket, endpoint, signed URL or secret.
import { createHash } from 'node:crypto';
import { DbError } from '../errors.ts';
import { StorageError } from '../storage/index.ts';
import type { ListableStorage } from '../storage/index.ts';
import type { AuditAssetRow, AuditRepository } from './audit-repository.ts';
import { classifyObjectKey, referenceCandidates } from './cleanup.ts';
import type { ObjectKeyInfo } from './cleanup.ts';
import { derivedKeys } from './processing-service.ts';
import { inspectWebp } from './webp-inspect.ts';

export const AUDIT_DEFAULTS = Object.freeze({ batchSize: 100, maxBatches: 10, graceHours: 24 });
export const AUDIT_LIMITS = Object.freeze({ batchSizeMax: 1000, maxBatchesMax: 100, graceHoursMin: 24, graceHoursMax: 720 });
/** Failed checks tolerated before the run gives up (storage or database clearly unavailable). */
export const AUDIT_MAX_FAILURES = 5;
const READ_RETRIES = 2;
const MAX_LISTED_PROBLEMS = 50;
const AREAS = ['incoming', 'processed', 'thumbs'] as const;
const KINDS = ['car_image', 'showroom_cover'] as const;
const SHARD = /^[0-9a-f]{0,2}$/;

export interface AuditOptions {
  /** true (the default) = delete nothing. Only an explicit false deletes. */
  dryRun: boolean;
  batchSize: number;
  maxBatches: number;
  /** Unlinked assets and orphan objects must be older than this (hours). */
  graceHours: number;
  /** '' or 1-2 lower-case hex digits: list only object keys whose uuid starts with it. */
  shard: string;
  /** Direction 1 (records -> objects) and its unlinked assets. */
  assets: boolean;
  /** Direction 2 (objects -> records). */
  orphans: boolean;
}

export type CorruptReason = 'invalid_image' | 'size_mismatch' | 'hash_mismatch' | 'dimension_mismatch' | 'unreadable';
export interface AssetAuditReport {
  batches: number;
  /** Ready assets examined. */
  scanned: number;
  healthy: number;
  /** At least one of its objects does not exist. */
  missing: number;
  /** All objects exist but at least one is not what the record says (see corruptReasons). */
  corrupt: number;
  /** Could not be verified (storage trouble that survived the retries): uncertain, so it blocks deletion. */
  failed: number;
  corruptReasons: Record<CorruptReason, number>;
  referenced: number;
  /** Of the referenced ones: report-only problems (never deleted). */
  referencedMissing: number;
  referencedCorrupt: number;
  /** Ready, referenced by nothing (any age). */
  unlinked: number;
  /** Unlinked and older than the grace period (a deletion candidate if its keys are recognized). */
  unlinkedEligible: number;
  unlinkedWithinGrace: number;
  /** Unlinked, old, but with a key this backend did not generate: never deleted. */
  unlinkedUnrecognized: number;
  /** Referenced assets with a problem, for the operator (ids only, at most 50). */
  referencedProblems: Array<{ assetId: string; problem: 'missing' | 'corrupt' }>;
  referencedProblemsTruncated: boolean;
  complete: boolean;
}
export interface OrphanAuditReport {
  pages: number;
  /** Objects listed (including entries with an unsafe key). */
  scanned: number;
  /** Listed entries that are not safe keys (never touched). */
  unsafe: number;
  tooRecent: number;
  unrecognized: number;
  /** Has a database record. */
  referenced: number;
  /** No record, recognized shape, older than the grace period: the objects the execute pass may delete. */
  orphaned: number;
  complete: boolean;
}
export interface DeletionReport {
  /** dry_run: nothing deleted by design. executed: pass 2 ran. blocked: a failed or uncertain check stopped it. none: nothing to delete. */
  mode: 'dry_run' | 'executed' | 'blocked' | 'none';
  blockedBy: AuditErrorCode | 'unverified_assets' | null;
  assetsDeleted: number;
  /** The row was changed or attached between the audit and the delete (the compare-and-swap refused): left alone. */
  assetsChanged: number;
  /** Objects removed together with a deleted record (original, main image, thumbnail; deleting a missing object succeeds). */
  assetObjectsDeleted: number;
  /** Orphan objects deleted (the objects of a deleted record are counted above, not here). */
  objectsDeleted: number;
  /** An orphan found referenced by the second lookup, right before the delete: left alone. */
  objectsReferencedOnRecheck: number;
  failed: number;
  /** Candidates not deleted because the run was blocked or stopped. */
  notAttempted: number;
}
export type AuditErrorCode = 'database_unavailable' | 'storage_unavailable' | 'unexpected';
export interface AuditSummary {
  scanned: number;
  healthy: number;
  missing: number;
  corrupt: number;
  unlinked: number;
  orphaned: number;
  deleted: number;
  skipped: number;
  failed: number;
}
export interface AuditReport {
  dryRun: boolean;
  options: { batchSize: number; maxBatches: number; graceHours: number; shard: string };
  assets: AssetAuditReport | null;
  orphans: OrphanAuditReport | null;
  deletion: DeletionReport;
  summary: AuditSummary;
  /** Referenced assets that are missing or corrupt: needs a person (the audit never changes them). */
  findings: boolean;
  /** The audit could not finish reading (a database/storage/unexpected error): the report is partial. */
  error: AuditErrorCode | null;
}

export interface AuditLogger {
  info(obj: Record<string, unknown>, msg?: string): void;
  warn(obj: Record<string, unknown>, msg?: string): void;
}

export class AuditOptionsError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`invalid audit options: ${problems.join(', ')}`);
    this.name = 'AuditOptionsError';
    this.problems = problems;
  }
}

const intIn = (v: unknown, min: number, max: number): v is number => typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max;

/** Fills the defaults and validates every bound. Dry-run unless dryRun is explicitly false. */
export function resolveAuditOptions(input: Partial<AuditOptions> = {}): AuditOptions {
  const o: AuditOptions = {
    dryRun: input.dryRun !== false,
    batchSize: input.batchSize ?? AUDIT_DEFAULTS.batchSize,
    maxBatches: input.maxBatches ?? AUDIT_DEFAULTS.maxBatches,
    graceHours: input.graceHours ?? AUDIT_DEFAULTS.graceHours,
    shard: input.shard ?? '',
    assets: input.assets !== false,
    orphans: input.orphans !== false,
  };
  const problems: string[] = [];
  if (!intIn(o.batchSize, 1, AUDIT_LIMITS.batchSizeMax)) problems.push('batchSize');
  if (!intIn(o.maxBatches, 1, AUDIT_LIMITS.maxBatchesMax)) problems.push('maxBatches');
  if (!intIn(o.graceHours, AUDIT_LIMITS.graceHoursMin, AUDIT_LIMITS.graceHoursMax)) problems.push('graceHours');
  if (typeof o.shard !== 'string' || !SHARD.test(o.shard)) problems.push('shard');
  if (!o.assets && !o.orphans) problems.push('nothingToAudit');
  if (problems.length > 0) throw new AuditOptionsError(problems);
  return o;
}

class Stop extends Error {
  readonly code: AuditErrorCode;
  constructor(code: AuditErrorCode) {
    super(code);
    this.code = code;
  }
}

const sha256 = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');

type ObjectState = { state: 'ok' } | { state: 'missing' } | { state: 'corrupt'; reason: CorruptReason } | { state: 'failed' };

const emptyReasons = (): Record<CorruptReason, number> => ({ invalid_image: 0, size_mismatch: 0, hash_mismatch: 0, dimension_mismatch: 0, unreadable: 0 });

export async function runAssetAudit(
  deps: { repo: AuditRepository; storage: ListableStorage; now?: () => Date; sleep?: (ms: number) => Promise<void>; logger?: AuditLogger },
  input: Partial<AuditOptions> = {},
): Promise<AuditReport> {
  const opts = resolveAuditOptions(input);
  const { repo, storage, logger } = deps;
  const now = deps.now ?? (() => new Date());
  const sleep = deps.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const graceSeconds = opts.graceHours * 3600;

  const assets: AssetAuditReport | null = opts.assets
    ? { batches: 0, scanned: 0, healthy: 0, missing: 0, corrupt: 0, failed: 0, corruptReasons: emptyReasons(), referenced: 0, referencedMissing: 0, referencedCorrupt: 0, unlinked: 0, unlinkedEligible: 0, unlinkedWithinGrace: 0, unlinkedUnrecognized: 0, referencedProblems: [], referencedProblemsTruncated: false, complete: false }
    : null;
  const orphans: OrphanAuditReport | null = opts.orphans ? { pages: 0, scanned: 0, unsafe: 0, tooRecent: 0, unrecognized: 0, referenced: 0, orphaned: 0, complete: false } : null;
  const deletion: DeletionReport = { mode: opts.dryRun ? 'dry_run' : 'none', blockedBy: null, assetsDeleted: 0, assetsChanged: 0, assetObjectsDeleted: 0, objectsDeleted: 0, objectsReferencedOnRecheck: 0, failed: 0, notAttempted: 0 };
  let error: AuditErrorCode | null = null;
  let failedChecks = 0; // reads that could not be verified (uncertain): any of them blocks every deletion

  // Deletion candidates, collected by pass 1 (bounded by the same limits as the scans).
  const unlinkedCandidates: Array<{ id: string; storageKey: string; thumbKey: string; keys: { original: string; main: string; thumb: string } }> = [];
  const orphanCandidates: Array<{ key: string; info: ObjectKeyInfo }> = [];

  // Every database call and storage call goes through these: a failure becomes a Stop with a code (never a message).
  const db = async <T>(fn: () => Promise<T>, retries = READ_RETRIES): Promise<T> => {
    for (let attempt = 0; ; attempt++) {
      try {
        return await fn();
      } catch (e) {
        if (!(e instanceof DbError)) throw new Stop('unexpected');
        if (attempt >= retries) throw new Stop('database_unavailable');
        await sleep(200 * (attempt + 1));
      }
    }
  };
  const store = async <T>(fn: () => Promise<T>, retries = READ_RETRIES): Promise<T> => {
    for (let attempt = 0; ; attempt++) {
      try {
        return await fn();
      } catch (e) {
        if (!(e instanceof StorageError)) throw new Stop('unexpected');
        if (e.code !== 'unavailable' && e.code !== 'integrity') throw e; // deterministic answers are for the caller (too_large, invalid_key)
        if (attempt >= retries) throw new Stop('storage_unavailable');
        await sleep(200 * (attempt + 1));
      }
    }
  };

  /** Reads one object and compares it with the record. Never throws except Stop for a run-ending condition. */
  async function check(key: string | null, verify: (bytes: Uint8Array) => CorruptReason | null): Promise<ObjectState> {
    if (key === null) return { state: 'corrupt', reason: 'unreadable' };
    let obj;
    try {
      obj = await store(() => storage.get(key));
    } catch (e) {
      if (e instanceof StorageError && (e.code === 'too_large' || e.code === 'invalid_key')) return { state: 'corrupt', reason: 'unreadable' };
      if (e instanceof Stop && e.code === 'storage_unavailable') {
        failedChecks++;
        if (failedChecks >= AUDIT_MAX_FAILURES) throw e;
        return { state: 'failed' };
      }
      throw e;
    }
    if (obj === null) return { state: 'missing' };
    const reason = verify(obj.body);
    return reason === null ? { state: 'ok' } : { state: 'corrupt', reason };
  }

  function auditAsset(row: AuditAssetRow, main: ObjectState, thumb: ObjectState, a: AssetAuditReport): void {
    const states = [main, thumb];
    const verdict = states.some((s) => s.state === 'missing') ? 'missing' : states.some((s) => s.state === 'corrupt') ? 'corrupt' : states.some((s) => s.state === 'failed') ? 'failed' : 'healthy';
    if (verdict === 'healthy') a.healthy++;
    else if (verdict === 'failed') a.failed++;
    else if (verdict === 'missing') a.missing++;
    else {
      a.corrupt++;
      const first = states.find((s): s is { state: 'corrupt'; reason: CorruptReason } => s.state === 'corrupt')!;
      a.corruptReasons[first.reason]++;
    }
    if (row.referenced && (verdict === 'missing' || verdict === 'corrupt')) {
      if (verdict === 'missing') a.referencedMissing++;
      else a.referencedCorrupt++;
      if (a.referencedProblems.length < MAX_LISTED_PROBLEMS) a.referencedProblems.push({ assetId: row.id, problem: verdict });
      else a.referencedProblemsTruncated = true;
    }
  }

  async function auditAssets(a: AssetAuditReport): Promise<void> {
    let afterId: string | null = null;
    for (;;) {
      if (a.batches >= opts.maxBatches) return;
      const rows = await db(() => repo.listReady({ afterId, limit: opts.batchSize }));
      a.batches++;
      for (const row of rows) {
        a.scanned++;
        const mainDims: { v: { width: number; height: number } | null } = { v: null };
        const main = await check(row.storageKey, (b) => {
          const info = inspectWebp(b);
          if (!info) return 'invalid_image';
          mainDims.v = { width: info.width, height: info.height };
          if (row.bytes === null || b.byteLength !== row.bytes) return 'size_mismatch';
          if (row.sha256 === null || sha256(b) !== row.sha256) return 'hash_mismatch';
          if (row.width !== info.width || row.height !== info.height) return 'dimension_mismatch';
          return null;
        });
        const thumb = await check(row.thumbKey, (b) => {
          const info = inspectWebp(b);
          if (!info) return 'invalid_image';
          // Verifiable without a recorded checksum: a thumbnail is never larger than the main image it was made from.
          const m = mainDims.v ?? (row.width !== null && row.height !== null ? { width: row.width, height: row.height } : null);
          if (m && (info.width > m.width || info.height > m.height)) return 'dimension_mismatch';
          return null;
        });
        auditAsset(row, main, thumb, a);

        if (row.referenced) {
          a.referenced++;
          continue;
        }
        a.unlinked++;
        if (!(row.ageSeconds > graceSeconds)) {
          a.unlinkedWithinGrace++;
          continue;
        }
        const keys = row.storageKey === null ? null : classifyObjectKey(row.storageKey);
        if (!keys || keys.area !== 'processed' || keys.kind !== row.kind || row.thumbKey !== keys.thumb) {
          a.unlinkedUnrecognized++;
          continue;
        }
        a.unlinkedEligible++;
        unlinkedCandidates.push({ id: row.id, storageKey: row.storageKey!, thumbKey: row.thumbKey!, keys: { original: keys.original, main: keys.main, thumb: keys.thumb } });
      }
      if (rows.length < opts.batchSize) {
        a.complete = true;
        return;
      }
      afterId = rows[rows.length - 1]!.id;
    }
  }

  async function auditObjects(o: OrphanAuditReport): Promise<void> {
    const cutoff = now().getTime() - graceSeconds * 1000;
    for (const area of AREAS) {
      for (const kind of KINDS) {
        const prefix = `${area}/${kind}/${opts.shard}`;
        let token: string | null = null;
        do {
          if (o.pages >= opts.maxBatches) return;
          const page = await store(() => storage.list(prefix, { maxKeys: opts.batchSize, token })).catch((e: unknown) => {
            throw e instanceof StorageError ? new Stop('storage_unavailable') : e;
          });
          o.pages++;
          o.scanned += page.objects.length + page.skipped;
          o.unsafe += page.skipped;
          const candidates: Array<{ key: string; info: ObjectKeyInfo }> = [];
          for (const obj of page.objects) {
            const info = classifyObjectKey(obj.key);
            if (!info) o.unrecognized++;
            else if (!(obj.lastModified.getTime() < cutoff)) o.tooRecent++;
            else candidates.push({ key: obj.key, info });
          }
          const lookup = [...new Set(candidates.flatMap((c) => referenceCandidates(c.key, c.info)))];
          const refs = await db(() => repo.findReferencedKeys(lookup));
          for (const c of candidates) {
            if (referenceCandidates(c.key, c.info).some((k) => refs.has(k))) {
              o.referenced++;
              continue;
            }
            o.orphaned++;
            orphanCandidates.push(c);
          }
          token = page.nextToken;
        } while (token !== null);
      }
    }
    o.complete = true;
  }

  try {
    if (assets) await auditAssets(assets);
    if (orphans) await auditObjects(orphans);
  } catch (e) {
    error = e instanceof Stop ? e.code : 'unexpected';
  }

  // ---- Pass 2: deletion. Only after a complete, certain pass 1, and only on request. ----
  const candidatesTotal = unlinkedCandidates.length + orphanCandidates.length;
  const unverified = (assets?.failed ?? 0) > 0 || failedChecks > 0;
  if (!opts.dryRun && candidatesTotal > 0) {
    if (error !== null || unverified) {
      deletion.mode = 'blocked';
      deletion.blockedBy = error ?? 'unverified_assets';
      deletion.notAttempted = candidatesTotal;
    } else {
      deletion.mode = 'executed';
      let stopped: AuditErrorCode | null = null;
      let processed = 0;
      const handled = new Set<string>(); // objects already removed together with their record (an orphan candidate may be one of them)
      try {
        for (const c of unlinkedCandidates) {
          processed++;
          let removed: boolean;
          try {
            removed = await db(() => repo.deleteUnlinked({ id: c.id, storageKey: c.storageKey, thumbKey: c.thumbKey, graceSeconds }), 0);
          } catch (e) {
            deletion.failed++;
            throw e;
          }
          if (!removed) {
            deletion.assetsChanged++;
            continue;
          }
          deletion.assetsDeleted++;
          for (const k of [c.keys.original, c.keys.main, c.keys.thumb]) {
            try {
              await store(() => storage.delete(k));
              handled.add(k);
              deletion.assetObjectsDeleted++;
            } catch (e) {
              deletion.failed++; // the row is gone: the remaining objects are orphans now, found by a later run
              throw e instanceof StorageError ? new Stop('storage_unavailable') : e;
            }
          }
        }
        for (let i = 0; i < orphanCandidates.length; i += opts.batchSize) {
          const chunk = orphanCandidates.slice(i, i + opts.batchSize);
          const lookup = [...new Set(chunk.flatMap((c) => referenceCandidates(c.key, c.info)))];
          const refs = await db(() => repo.findReferencedKeys(lookup)); // second, independent lookup right before deleting
          for (const c of chunk) {
            processed++;
            if (handled.has(c.key)) continue;
            if (referenceCandidates(c.key, c.info).some((k) => refs.has(k))) {
              deletion.objectsReferencedOnRecheck++;
              continue;
            }
            try {
              await store(() => storage.delete(c.key));
              deletion.objectsDeleted++;
            } catch (e) {
              deletion.failed++;
              throw e instanceof StorageError ? new Stop('storage_unavailable') : e;
            }
          }
        }
      } catch (e) {
        stopped = e instanceof Stop ? e.code : 'unexpected';
      }
      if (stopped !== null) {
        error = error ?? stopped;
        deletion.blockedBy = stopped;
        deletion.notAttempted = Math.max(0, candidatesTotal - processed);
      }
    }
  }

  const a = assets;
  const o = orphans;
  const summary: AuditSummary = {
    scanned: (a?.scanned ?? 0) + (o?.scanned ?? 0),
    healthy: a?.healthy ?? 0,
    missing: a?.missing ?? 0,
    corrupt: a?.corrupt ?? 0,
    unlinked: a?.unlinked ?? 0,
    orphaned: o?.orphaned ?? 0,
    deleted: deletion.assetsDeleted + deletion.objectsDeleted,
    // Not examined or not acted on: inside the grace period, key shape not recognized, unsafe listing entries, changed or
    // re-referenced at the last moment, or not attempted because the run was blocked or stopped.
    skipped:
      (a?.unlinkedWithinGrace ?? 0) + (a?.unlinkedUnrecognized ?? 0) + (o?.tooRecent ?? 0) + (o?.unrecognized ?? 0) + (o?.unsafe ?? 0) + deletion.assetsChanged + deletion.objectsReferencedOnRecheck + deletion.notAttempted,
    failed: (a?.failed ?? 0) + deletion.failed + (error !== null && (a?.failed ?? 0) + deletion.failed === 0 ? 1 : 0),
  };
  const report: AuditReport = {
    dryRun: opts.dryRun,
    options: { batchSize: opts.batchSize, maxBatches: opts.maxBatches, graceHours: opts.graceHours, shard: opts.shard },
    assets,
    orphans,
    deletion,
    summary,
    findings: (a?.referencedMissing ?? 0) + (a?.referencedCorrupt ?? 0) > 0,
    error,
  };
  const log = error || summary.failed > 0 ? logger?.warn.bind(logger) : logger?.info.bind(logger);
  log?.({ event: 'assets.audit', dryRun: report.dryRun, error, summary, deletion: { mode: deletion.mode, blockedBy: deletion.blockedBy } });
  return report;
}

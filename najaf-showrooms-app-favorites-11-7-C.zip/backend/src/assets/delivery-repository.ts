// PostgreSQL access for image DELIVERY (Phase 11.6.4), on the existing tables and views (no migration).
//
// Who may see an image is decided HERE, in SQL, by the same views every public read already uses (never re-implemented):
//  - PUBLIC: the asset is 'ready' AND (a car_image attached through car_images to a car that is in the public_cars view, OR a
//    showroom_cover that is the cover of a showroom in the public_showrooms view). Anything else (pending, rejected, unattached,
//    attached to a hidden/deleted/suspended car, the cover of a pending/suspended showroom or of a suspended/deleted dealer) is
//    simply not found;
//  - OWNER: the caller's own asset (owner_id = the verified actor), 'ready' only. Nobody else's, not even an administrator's view.
// Unlike the upload repository, these statements read storage_key/thumb_key and sha256: delivery needs them. They never leave the
// server: the service turns them into bytes and an ETag only.
import type { Tx } from '../db.ts';

export interface DeliverableAsset {
  id: string;
  kind: string;
  storageKey: string;
  thumbKey: string;
  sha256: string;
  width: number;
  height: number;
}

/** What anyone may know about a public image: its id, layout and size. No key, checksum, owner or status. */
export interface PublicImageRef {
  assetId: string;
  width: number;
  height: number;
}
export interface PublicCarImageRef extends PublicImageRef {
  isMain: boolean;
  sortOrder: number;
}

export interface DeliveryRepository {
  /** A ready asset visible to everyone (see above); null otherwise. */
  findPublic(assetId: string): Promise<DeliverableAsset | null>;
  /** One of the owner's ready assets; null otherwise. */
  findOwnReady(assetId: string, ownerId: string): Promise<DeliverableAsset | null>;
  /** The ready images of a car in public_cars, in display order; null when the car is not public (or unknown). */
  listPublicCarImages(carId: string): Promise<PublicCarImageRef[] | null>;
  /** The ready cover of a showroom in public_showrooms; undefined when the showroom is not public, null when it has no cover. */
  findPublicShowroomCover(showroomId: string): Promise<PublicImageRef | null | undefined>;
}

const DELIVERABLE = 'a.id, a.kind, a.storage_key, a.thumb_key, a.sha256, a.width, a.height';
interface DeliverableSql {
  id: string;
  kind: string;
  storage_key: string | null;
  thumb_key: string | null;
  sha256: string | null;
  width: number | null;
  height: number | null;
}
/** A row is deliverable only with every column a ready asset must have (the CHECK guarantees it; this is defense in depth). */
export function toDeliverable(r: DeliverableSql | undefined): DeliverableAsset | null {
  if (!r || r.storage_key === null || r.thumb_key === null || r.sha256 === null || r.width === null || r.height === null) return null;
  return { id: String(r.id), kind: r.kind, storageKey: r.storage_key, thumbKey: r.thumb_key, sha256: String(r.sha256).trim(), width: Number(r.width), height: Number(r.height) };
}

export function buildFindPublic(assetId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT ${DELIVERABLE} FROM assets a
            WHERE a.id = $1::uuid AND a.status = 'ready'
              AND ( (a.kind = 'car_image' AND EXISTS (SELECT 1 FROM car_images ci JOIN public_cars pc ON pc.id = ci.car_id WHERE ci.asset_id = a.id))
                 OR (a.kind = 'showroom_cover' AND EXISTS (SELECT 1 FROM public_showrooms ps WHERE ps.cover_asset_id = a.id)) )`,
    values: [assetId],
  };
}

export function buildFindOwnReady(assetId: string, ownerId: string): { text: string; values: unknown[] } {
  return { text: `SELECT ${DELIVERABLE} FROM assets a WHERE a.id = $1::uuid AND a.owner_id = $2::bigint AND a.status = 'ready'`, values: [assetId, ownerId] };
}

export function buildListPublicCarImages(carId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT pc.id AS car_id, ci.asset_id, ci.is_main, ci.sort_order, a.width, a.height
             FROM public_cars pc
             LEFT JOIN (car_images ci JOIN assets a ON a.id = ci.asset_id AND a.status = 'ready' AND a.kind = 'car_image') ON ci.car_id = pc.id
            WHERE pc.id = $1::bigint
            ORDER BY ci.sort_order, ci.id`,
    values: [carId],
  };
}

export function buildFindPublicShowroomCover(showroomId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT ps.id AS showroom_id, a.id AS asset_id, a.width, a.height
             FROM public_showrooms ps
             LEFT JOIN assets a ON a.id = ps.cover_asset_id AND a.status = 'ready' AND a.kind = 'showroom_cover'
            WHERE ps.id = $1::bigint`,
    values: [showroomId],
  };
}

export function createPgDeliveryRepository(q: Tx): DeliveryRepository {
  return {
    async findPublic(assetId) {
      const s = buildFindPublic(assetId);
      return toDeliverable((await q.query<DeliverableSql>(s.text, s.values)).rows[0]);
    },
    async findOwnReady(assetId, ownerId) {
      const s = buildFindOwnReady(assetId, ownerId);
      return toDeliverable((await q.query<DeliverableSql>(s.text, s.values)).rows[0]);
    },
    async listPublicCarImages(carId) {
      const s = buildListPublicCarImages(carId);
      const rows = (await q.query<{ car_id: string; asset_id: string | null; is_main: boolean | null; sort_order: number | null; width: number | null; height: number | null }>(s.text, s.values)).rows;
      if (rows.length === 0) return null;
      return rows
        .filter((r) => r.asset_id !== null && r.width !== null && r.height !== null)
        .map((r) => ({ assetId: String(r.asset_id), isMain: r.is_main === true, sortOrder: Number(r.sort_order), width: Number(r.width), height: Number(r.height) }));
    },
    async findPublicShowroomCover(showroomId) {
      const s = buildFindPublicShowroomCover(showroomId);
      const r = (await q.query<{ showroom_id: string; asset_id: string | null; width: number | null; height: number | null }>(s.text, s.values)).rows[0];
      if (!r) return undefined;
      if (r.asset_id === null || r.width === null || r.height === null) return null;
      return { assetId: String(r.asset_id), width: Number(r.width), height: Number(r.height) };
    },
  };
}

// Image delivery (Phase 11.6.4): the processed WebP image and its thumbnail, served by asset id, never by storage key.
//
// Decisions (each is covered by tests):
//  - WHO may see what is decided by the database (delivery-repository.ts): PUBLIC images are ready assets attached to a car in the
//    public_cars view or the cover of a showroom in the public_showrooms view; an OWNER sees their own ready assets (nobody else's,
//    an administrator included: there is no moderation view here). Everything else, a malformed id included, is the same 404.
//  - WHAT is served is only ever the PROCESSED output: the row's storage_key (main) or thumb_key (thumbnail) of a READY asset, and
//    never a key under incoming/ (where originals live). The bytes must be a clean, still WebP (webp-inspect.ts: no EXIF/XMP/ICC,
//    no animation); the main image must also match the row's SHA-256 and dimensions. A missing object or bytes that fail these
//    checks are 404 and a log line (asset id + reason only); a storage failure is 503. Never the key, the provider or its error.
//  - Caching: the ETag is derived from the row's SHA-256 (assets never change once ready), so a matching If-None-Match is answered
//    304 after the visibility check and without reading storage. The Cache-Control decision is the route's (public vs private).
import { createHash } from 'node:crypto';
import { isValidId, notFound } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { StorageError, isSafeKey } from '../storage/index.ts';
import type { StorageProvider } from '../storage/index.ts';
import type { DeliverableAsset, DeliveryRepository, PublicCarImageRef, PublicImageRef } from './delivery-repository.ts';
import { parseAssetId } from './validation.ts';
import { inspectWebp } from './webp-inspect.ts';

export type ImageVariant = 'main' | 'thumb';
export const IMAGE_VARIANTS: readonly ImageVariant[] = ['main', 'thumb'];
const IF_NONE_MATCH_MAX = 2048;

export type DeliveryErrorCode = 'storage_unavailable';
export class DeliveryError extends Error {
  readonly code: DeliveryErrorCode;
  constructor(code: DeliveryErrorCode) {
    super('The image is temporarily unavailable; try again later');
    this.name = 'DeliveryError';
    this.code = code;
  }
}

export interface DeliveredImage {
  /** null when notModified. */
  body: Uint8Array | null;
  etag: string;
  notModified: boolean;
}

export interface DeliveryContext {
  requestId?: string | undefined;
  ifNoneMatch?: unknown;
}

export interface DeliveryLogger {
  warn(obj: Record<string, unknown>, msg?: string): void;
}

export interface AssetDeliveryApi {
  publicImage(rawId: unknown, variant: ImageVariant, ctx?: DeliveryContext): Promise<DeliveredImage>;
  ownImage(actor: Actor | null, rawId: unknown, variant: ImageVariant, ctx?: DeliveryContext): Promise<DeliveredImage>;
  publicCarImages(rawCarId: unknown): Promise<{ images: PublicCarImageRef[] }>;
  publicShowroomCover(rawShowroomId: unknown): Promise<{ cover: PublicImageRef | null }>;
}

/** A key that may be served: a safe key that is NOT an original upload. */
export function isServableKey(key: unknown): key is string {
  return isSafeKey(key) && !key.startsWith('incoming/');
}

export function etagOf(a: Pick<DeliverableAsset, 'sha256'>, variant: ImageVariant): string {
  return variant === 'main' ? `"${a.sha256}"` : `"${a.sha256}-thumb"`;
}

/** RFC 9110 If-None-Match (weak comparison): "*" or a list of entity tags. Anything malformed or oversized matches nothing. */
export function ifNoneMatchMatches(header: unknown, etag: string): boolean {
  if (typeof header !== 'string' || header.length === 0 || header.length > IF_NONE_MATCH_MAX) return false;
  if (header.trim() === '*') return true;
  const strip = (t: string) => (t.startsWith('W/') ? t.slice(2) : t);
  return header.split(',').some((t) => strip(t.trim()) === strip(etag));
}

const sha256 = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');

export function createAssetDelivery(deps: { repo: DeliveryRepository; storage: StorageProvider; logger?: DeliveryLogger }): AssetDeliveryApi {
  const { repo, storage, logger } = deps;

  const failed = (asset: DeliverableAsset, variant: ImageVariant, reason: string, ctx: DeliveryContext): void => {
    logger?.warn({ event: 'assets.delivery_failed', assetId: asset.id, variant, reason, requestId: ctx.requestId });
  };

  async function deliver(asset: DeliverableAsset | null, variant: ImageVariant, ctx: DeliveryContext): Promise<DeliveredImage> {
    if (!asset) throw notFound();
    const key = variant === 'main' ? asset.storageKey : asset.thumbKey;
    if (!isServableKey(key)) {
      failed(asset, variant, 'unservable_key', ctx);
      throw notFound();
    }
    const etag = etagOf(asset, variant);
    if (ifNoneMatchMatches(ctx.ifNoneMatch, etag)) return { body: null, etag, notModified: true };

    let body: Uint8Array;
    try {
      const o = await storage.get(key);
      if (!o) {
        failed(asset, variant, 'missing_object', ctx);
        throw notFound();
      }
      body = o.body;
    } catch (e) {
      if (!(e instanceof StorageError)) throw e;
      if (e.code === 'too_large') {
        failed(asset, variant, 'invalid_object', ctx);
        throw notFound();
      }
      failed(asset, variant, 'storage_unavailable', ctx);
      throw new DeliveryError('storage_unavailable');
    }
    const info = inspectWebp(body);
    if (!info) {
      failed(asset, variant, 'invalid_object', ctx);
      throw notFound();
    }
    const consistent =
      variant === 'main'
        ? info.width === asset.width && info.height === asset.height && sha256(body) === asset.sha256
        : info.width <= asset.width && info.height <= asset.height;
    if (!consistent) {
      failed(asset, variant, 'integrity', ctx);
      throw notFound();
    }
    return { body, etag, notModified: false };
  }

  const variantOf = (v: unknown): ImageVariant => {
    if (!(IMAGE_VARIANTS as readonly unknown[]).includes(v)) throw notFound();
    return v as ImageVariant;
  };

  return {
    async publicImage(rawId, variant, ctx = {}) {
      const v = variantOf(variant);
      const id = parseAssetId(rawId);
      if (id === null) throw notFound();
      return deliver(await repo.findPublic(id), v, ctx);
    },

    async ownImage(actor, rawId, variant, ctx = {}) {
      const v = variantOf(variant);
      const id = parseAssetId(rawId);
      if (!actor || id === null) throw notFound();
      return deliver(await repo.findOwnReady(id, actor.id), v, ctx);
    },

    async publicCarImages(rawCarId) {
      if (!isValidId(rawCarId)) throw notFound();
      const images = await repo.listPublicCarImages(rawCarId);
      if (images === null) throw notFound();
      return { images: images.map((i) => ({ assetId: i.assetId, isMain: i.isMain, sortOrder: i.sortOrder, width: i.width, height: i.height })) };
    },

    async publicShowroomCover(rawShowroomId) {
      if (!isValidId(rawShowroomId)) throw notFound();
      const cover = await repo.findPublicShowroomCover(rawShowroomId);
      if (cover === undefined) throw notFound();
      return { cover: cover === null ? null : { assetId: cover.assetId, width: cover.width, height: cover.height } };
    },
  };
}

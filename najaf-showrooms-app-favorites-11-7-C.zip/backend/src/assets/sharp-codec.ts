// Production image codec (Phase 11.6.3): sharp (libvips). Installed by `npm install` (package.json); in an environment without it,
// importing this module fails, which is why only the startup wiring imports it.
//  - limitInputPixels refuses oversized images from the header, before pixels are decoded (decompression bombs);
//  - failOn 'warning' refuses truncated or corrupt data instead of rendering garbage; sequentialRead keeps memory low;
//  - only JPEG, PNG and WebP are decoded (the format is checked before every pipeline: libvips knows SVG, GIF, TIFF, HEIF, PDF...);
//  - pages: 1 / animated: false decode one frame; .rotate() applies the EXIF orientation;
//  - output metadata is NOT kept (sharp strips EXIF/XMP/ICC unless keepMetadata/withMetadata is called, which never happens here),
//    and the colour space is converted to sRGB;
//  - the libvips operation cache is disabled and each pipeline uses one thread; .timeout() bounds the work per image.
import sharp from 'sharp';
import { CodecError } from './codec.ts';
import type { ImageCodec, ProbeResult } from './codec.ts';

sharp.cache(false);
sharp.concurrency(1);

const FORMATS: Record<string, ProbeResult['format']> = { jpeg: 'jpeg', png: 'png', webp: 'webp' };

function toCodecError(e: unknown): CodecError {
  if (e instanceof CodecError) return e;
  const msg = e instanceof Error ? e.message : '';
  if (/pixel limit|exceeds pixel/i.test(msg)) return new CodecError('too_large');
  if (/timeout/i.test(msg)) return new CodecError('timeout');
  if (/unsupported image format/i.test(msg)) return new CodecError('unsupported');
  return new CodecError('invalid_image');
}

export function createSharpCodec(): ImageCodec {
  return {
    name: 'sharp',
    async probe(input, opts) {
      try {
        const m = await sharp(input, { limitInputPixels: opts.maxInputPixels, failOn: 'warning', sequentialRead: true }).metadata();
        const format = m.format ? FORMATS[m.format] : undefined;
        if (!format) throw new CodecError('unsupported');
        if (!m.width || !m.height) throw new CodecError('invalid_image');
        return { format, width: m.width, height: m.height, pages: m.pages ?? 1 };
      } catch (e) {
        throw toCodecError(e);
      }
    },
    async render(input, opts) {
      try {
        // libvips can decode many more formats (SVG, GIF, TIFF, HEIF, PDF...): refuse anything but the three accepted ones and
        // anything multi-frame BEFORE the pipeline runs, whatever the caller checked.
        const m = await sharp(input, { limitInputPixels: opts.maxInputPixels, failOn: 'warning', sequentialRead: true }).metadata();
        if (!m.format || !FORMATS[m.format]) throw new CodecError('unsupported');
        if ((m.pages ?? 1) !== 1) throw new CodecError('unsupported');
        const { data, info } = await sharp(input, { limitInputPixels: opts.maxInputPixels, failOn: 'warning', sequentialRead: true, animated: false, pages: 1 })
          .rotate()
          .resize({ width: opts.maxSide, height: opts.maxSide, fit: 'inside', withoutEnlargement: true })
          .webp({ quality: opts.quality, effort: 4 })
          .timeout({ seconds: Math.max(1, Math.ceil(opts.timeoutMs / 1000)) })
          .toBuffer({ resolveWithObject: true });
        return { data: new Uint8Array(data), width: info.width, height: info.height };
      } catch (e) {
        throw toCodecError(e);
      }
    },
  };
}

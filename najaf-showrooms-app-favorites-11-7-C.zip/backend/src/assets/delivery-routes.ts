// HTTP contract for image delivery (Phase 11.6.4). Thin: decisions live in assets/delivery.ts. Imports Fastify TYPES only.
//
//   GET /v1/public/assets/:id/image      no auth   -> 200 image/webp (the processed image) | 304 | 404 | 503
//   GET /v1/public/assets/:id/thumb      no auth   -> 200 image/webp (the thumbnail)       | 304 | 404 | 503
//   GET /v1/me/assets/:id/image          Bearer    -> the caller's own ready asset         | 304 | 401 | 404 | 503
//   GET /v1/me/assets/:id/thumb          Bearer    -> the caller's own ready thumbnail     | 304 | 401 | 404 | 503
//   GET /v1/public/cars/:id/images       no auth   -> 200 {images: [{assetId, isMain, sortOrder, width, height}]} | 404
//   GET /v1/public/showrooms/:id/cover   no auth   -> 200 {cover: {assetId, width, height} | null}               | 404
//
// Image responses: Content-Type image/webp, Content-Length, an ETag, X-Content-Type-Options nosniff (server-wide),
// Content-Security-Policy "default-src 'none'; sandbox" and Content-Disposition inline (the bytes can never act as a document).
// Cache-Control: "public, max-age=300" for public images (short, so that hiding a car or a showroom takes effect quickly) and
// "private, no-store" for the owner's routes. Every other answer keeps the server-wide "no-store". No response, header or log line
// carries a storage key, a checksum other than the ETag, an owner or a provider detail.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { DeliveryError } from './delivery.ts';
import type { AssetDeliveryApi, DeliveredImage, ImageVariant } from './delivery.ts';

/** PROPOSED, per client address and per instance. A public page shows many thumbnails, hence the higher image limit. */
export const DELIVERY_RATE_LIMITS = {
  publicImage: { limit: 1200, windowSeconds: 10 * 60 },
  ownImage: { limit: 600, windowSeconds: 10 * 60 },
  discovery: { limit: 480, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type DeliveryRateLimitedRoute = keyof typeof DELIVERY_RATE_LIMITS;

export const PUBLIC_IMAGE_CACHE_CONTROL = 'public, max-age=300';
export const PRIVATE_IMAGE_CACHE_CONTROL = 'private, no-store';
export const IMAGE_CSP = "default-src 'none'; sandbox";

export function toDeliveryHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof DeliveryError) return { status: 503, code: e.code, message: e.message };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

export function registerAssetDeliveryRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; delivery: AssetDeliveryApi; rateLimiter?: RateLimiter }): void {
  const { auth, delivery, rateLimiter } = deps;

  const limited = (route: DeliveryRateLimitedRoute): Hook[] =>
    rateLimiter
      ? [
          async (request, reply) => {
            const decision = rateLimiter.consume(`assets.delivery.${route}:${request.ip}`, DELIVERY_RATE_LIMITS[route]);
            if (decision.allowed) return undefined;
            request.log.warn({ event: 'assets.rate_limited', route });
            reply.header('retry-after', String(decision.retryAfterSeconds));
            return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
          },
        ]
      : [];

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toDeliveryHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, requestId: request.id } });
  };

  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  const sendImage = (reply: Reply, img: DeliveredImage, cacheControl: string): Reply => {
    reply.header('etag', img.etag);
    reply.header('cache-control', cacheControl);
    reply.header('content-security-policy', IMAGE_CSP);
    reply.header('content-disposition', 'inline');
    if (img.notModified || img.body === null) return reply.code(304).send();
    reply.header('content-type', 'image/webp');
    reply.header('content-length', String(img.body.byteLength));
    return reply.code(200).send(Buffer.from(img.body.buffer, img.body.byteOffset, img.body.byteLength));
  };

  const id = (request: FastifyRequest): unknown => (request.params as Record<string, unknown> | undefined)?.['id'];
  const ctx = (request: FastifyRequest) => ({ requestId: request.id, ifNoneMatch: request.headers['if-none-match'] });

  const variants: Array<[string, ImageVariant]> = [
    ['image', 'main'],
    ['thumb', 'thumb'],
  ];
  for (const [segment, variant] of variants) {
    app.get(`/v1/public/assets/:id/${segment}`, { onRequest: limited('publicImage') }, async (request, reply) => {
      try {
        return sendImage(reply as unknown as Reply, await delivery.publicImage(id(request), variant, ctx(request)), PUBLIC_IMAGE_CACHE_CONTROL);
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });

    app.get(`/v1/me/assets/:id/${segment}`, { onRequest: limited('ownImage') }, async (request, reply) => {
      try {
        const actor = await identify(request);
        return sendImage(reply as unknown as Reply, await delivery.ownImage(actor, id(request), variant, ctx(request)), PRIVATE_IMAGE_CACHE_CONTROL);
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });
  }

  app.get('/v1/public/cars/:id/images', { onRequest: limited('discovery') }, async (request, reply) => {
    try {
      return reply.code(200).send(await delivery.publicCarImages(id(request)));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/public/showrooms/:id/cover', { onRequest: limited('discovery') }, async (request, reply) => {
    try {
      return reply.code(200).send(await delivery.publicShowroomCover(id(request)));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

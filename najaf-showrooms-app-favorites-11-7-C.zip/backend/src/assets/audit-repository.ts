// PostgreSQL access for the asset INTEGRITY AUDIT (Phase 11.6.6), on the existing tables (no migration).
//  - listReady: the 'ready' assets in primary-key order (keyset paging, exact, bounded by the caller), each with the facts the
//    audit compares to the stored objects (keys, size, checksum, dimensions) and two facts decided by the DATABASE, in the same
//    statement: whether anything references the asset (a car image or a showroom cover) and its age since it became ready (the
//    database clock, so the grace period never depends on the clock of the machine running the audit).
//  - deleteUnlinked: the only statement that removes a ready asset. A transaction first LOCKS the row (FOR UPDATE), which waits for
//    any concurrent attach (a car image or cover insert/update holds a key-share lock on the asset through its foreign key) to
//    finish; the conditional DELETE that follows is a NEW statement, so it sees that attach, and refuses: it deletes only a row
//    that is still ready, has the keys the audit read, is older than the grace period and is referenced by nothing. Without the
//    lock, a cover set between the check and the delete would be silently cleared by the foreign key (ON DELETE SET NULL).
//    After the delete commits, a later attach fails on the foreign key (the cover endpoint answers 409 invalid_state).
//  - findReferencedKeys: the same statement the cleanup job uses (11.6.4): which of the given keys are the storage_key or the
//    thumb_key of ANY row. A failed query is an error, never "nothing is referenced".
import type { Db } from '../db.ts';
import { FIND_REFERENCED_KEYS_SQL } from './cleanup-repository.ts';

export interface AuditAssetRow {
  id: string;
  kind: string;
  /** Internal. Used to read and (for unlinked assets) delete the objects; never printed, logged or returned. */
  storageKey: string | null;
  thumbKey: string | null;
  bytes: number | null;
  width: number | null;
  height: number | null;
  sha256: string | null;
  /** Attached to a car or used as a showroom cover (decided by the database in the listing statement). */
  referenced: boolean;
  /** Seconds since the asset became ready, by the database clock. */
  ageSeconds: number;
}

export interface AuditRepository {
  listReady(input: { afterId: string | null; limit: number }): Promise<AuditAssetRow[]>;
  deleteUnlinked(input: { id: string; storageKey: string | null; thumbKey: string | null; graceSeconds: number }): Promise<boolean>;
  findReferencedKeys(keys: string[]): Promise<Set<string>>;
}

const REFERENCED = `(EXISTS (SELECT 1 FROM car_images ci WHERE ci.asset_id = a.id)
              OR EXISTS (SELECT 1 FROM showrooms s WHERE s.cover_asset_id = a.id))`;

export function buildListReady(i: { afterId: string | null; limit: number }): { text: string; values: unknown[] } {
  return {
    text: `SELECT a.id, a.kind, a.storage_key, a.thumb_key, a.bytes, a.width, a.height, a.sha256,
                  ${REFERENCED} AS referenced,
                  EXTRACT(EPOCH FROM (now() - a.ready_at))::double precision AS age_seconds
             FROM assets a
            WHERE a.status = 'ready'
              AND ($1::uuid IS NULL OR a.id > $1::uuid)
            ORDER BY a.id
            LIMIT $2::int`,
    values: [i.afterId, i.limit],
  };
}

export const LOCK_READY_SQL = `SELECT a.id FROM assets a WHERE a.id = $1::uuid AND a.status = 'ready' FOR UPDATE`;

export function buildDeleteUnlinked(i: { id: string; storageKey: string | null; thumbKey: string | null; graceSeconds: number }): { text: string; values: unknown[] } {
  return {
    text: `DELETE FROM assets a
            WHERE a.id = $1::uuid
              AND a.status = 'ready'
              AND a.storage_key IS NOT DISTINCT FROM $2::text
              AND a.thumb_key IS NOT DISTINCT FROM $3::text
              AND a.ready_at < now() - make_interval(secs => $4::double precision)
              AND NOT EXISTS (SELECT 1 FROM car_images ci WHERE ci.asset_id = a.id)
              AND NOT EXISTS (SELECT 1 FROM showrooms s WHERE s.cover_asset_id = a.id)
        RETURNING a.id`,
    values: [i.id, i.storageKey, i.thumbKey, i.graceSeconds],
  };
}

interface ReadySql {
  id: string;
  kind: string;
  storage_key: string | null;
  thumb_key: string | null;
  bytes: number | null;
  width: number | null;
  height: number | null;
  sha256: string | null;
  referenced: boolean;
  age_seconds: number | string | null;
}

export function createPgAuditRepository(db: Db): AuditRepository {
  return {
    async listReady(input) {
      const s = buildListReady(input);
      return (await db.query<ReadySql>(s.text, s.values)).rows.map((r) => ({
        id: String(r.id),
        kind: r.kind,
        storageKey: r.storage_key,
        thumbKey: r.thumb_key,
        bytes: r.bytes === null ? null : Number(r.bytes),
        width: r.width === null ? null : Number(r.width),
        height: r.height === null ? null : Number(r.height),
        sha256: r.sha256 === null ? null : String(r.sha256).trim(),
        referenced: r.referenced !== false, // anything but a definite false counts as referenced (never delete on doubt)
        ageSeconds: r.age_seconds === null ? 0 : Number(r.age_seconds),
      }));
    },
    async deleteUnlinked(input) {
      const s = buildDeleteUnlinked(input);
      return db.tx(async (t) => {
        await t.query(`SET LOCAL lock_timeout = '3s'`);
        if ((await t.query(LOCK_READY_SQL, [input.id])).rows.length !== 1) return false;
        return (await t.query(s.text, s.values)).rows.length === 1;
      });
    },
    async findReferencedKeys(keys) {
      if (keys.length === 0) return new Set();
      const rows = (await db.query<{ k: string | null }>(FIND_REFERENCED_KEYS_SQL, [keys])).rows;
      return new Set(rows.map((r) => r.k).filter((k): k is string => typeof k === 'string'));
    },
  };
}

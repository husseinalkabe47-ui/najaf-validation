// HTTP contract for asset upload (Phase 11.6.2). Thin: decisions live in assets/service.ts. Imports Fastify TYPES only.
//
//   POST /v1/me/assets?kind=car_image|showroom_cover   Bearer, Content-Type: image/jpeg|image/png|image/webp, body = the raw image
//                                                      -> 201 {asset: {id, kind, status: 'pending', bytes, width, height, createdAt}}
//   GET  /v1/me/assets/:id                             Bearer -> 200 {asset}   (the caller's own asset only)
//
// The upload route authenticates and checks the declared type in an onRequest hook, i.e. BEFORE any body byte is read: an
// anonymous or wrong-type request is refused without buffering the upload. The image parsers are registered inside an encapsulated
// plugin, so no other route accepts image bodies. Errors: 401 no/invalid token; 403 an account or role that may not upload this
// kind; 400 invalid query or bytes that are not the declared image; 413 too large; 415 type not accepted; 409 upload_limit;
// 503 storage_unavailable; 404 an asset that is not the caller's (or a malformed id). Responses and logs never contain a storage
// key, a credential or the provider's details.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { IMAGE_TYPES } from './image-sniff.ts';
import { ASSET_UPLOAD_MAX_BYTES, AssetError } from './service.ts';
import type { AssetApi } from './service.ts';
import { parseDeclaredType } from './validation.ts';

/** PROPOSED, per client address and per instance. */
export const ASSET_RATE_LIMITS = {
  upload: { limit: 30, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type AssetRateLimitedRoute = keyof typeof ASSET_RATE_LIMITS;

const STATUS: Record<AssetError['code'], number> = { validation_failed: 400, unsupported_media_type: 415, too_large: 413, upload_limit: 409, storage_unavailable: 503 };

export function toAssetHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof AssetError) return { status: STATUS[e.code], code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

export function registerAssetRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; assets: AssetApi; rateLimiter?: RateLimiter }): void {
  const { auth, assets, rateLimiter } = deps;

  const limited = (route: AssetRateLimitedRoute): Hook[] =>
    rateLimiter
      ? [
          async (request, reply) => {
            const decision = rateLimiter.consume(`assets.${route}:${request.ip}`, ASSET_RATE_LIMITS[route]);
            if (decision.allowed) return undefined;
            request.log.warn({ event: 'assets.rate_limited', route });
            reply.header('retry-after', String(decision.retryAfterSeconds));
            return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
          },
        ]
      : [];

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toAssetHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling" (and so of the owner): the verified access token, re-read from the database.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  // Upload: who and what type are settled before the body is read.
  const actors = new WeakMap<FastifyRequest, Actor | null>();
  const beforeBody: Hook = async (request, reply) => {
    try {
      actors.set(request, await identify(request));
      if (parseDeclaredType(request.headers['content-type']) === null) throw new AssetError('unsupported_media_type');
      return undefined;
    } catch (e) {
      return fail(request, reply as unknown as Reply, e) as unknown as FastifyReply;
    }
  };

  app.register(async (scope: FastifyInstance) => {
    scope.addContentTypeParser([...IMAGE_TYPES], { parseAs: 'buffer', bodyLimit: ASSET_UPLOAD_MAX_BYTES }, (_request, body, done) => done(null, body));

    scope.post('/v1/me/assets', { bodyLimit: ASSET_UPLOAD_MAX_BYTES, onRequest: [...limited('upload'), beforeBody] }, async (request, reply) => {
      try {
        const actor = actors.has(request) ? actors.get(request)! : await identify(request);
        const asset = await assets.upload(actor, { query: request.query, contentType: request.headers['content-type'], body: request.body }, { requestId: request.id });
        request.log.info({ event: 'assets.uploaded', assetId: asset.id, kind: asset.kind, bytes: asset.bytes });
        return reply.code(201).send({ asset });
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });

    scope.get('/v1/me/assets/:id', { onRequest: limited('read') }, async (request, reply) => {
      try {
        const actor = await identify(request);
        const asset = await assets.getOwn(actor, (request.params as Record<string, unknown> | undefined)?.['id']);
        return reply.code(200).send({ asset });
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });
  });
}

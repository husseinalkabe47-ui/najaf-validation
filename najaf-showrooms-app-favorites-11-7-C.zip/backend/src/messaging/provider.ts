// The delivery channel for one-time codes. Only the interface and a "not configured" implementation live here: production
// SMS/WhatsApp integration is a later step. The code is passed to `send` because it must be delivered; it is never logged,
// stored in clear, or included in any error by this codebase. Implementations must not log it either.
import type { OtpPurpose } from '../auth/otp.ts';

export interface OtpMessage {
  /** Canonical E.164. */
  phone: string;
  purpose: OtpPurpose;
  code: string;
  ttlSeconds: number;
}

export interface MessagingProvider {
  send(message: OtpMessage): Promise<void>;
  /**
   * false = this provider can NEVER deliver (nothing is wired in). Undefined/true = it can try. Lets the password-recovery request
   * say so honestly (503 delivery_unavailable) instead of answering "accepted" for a code nobody will ever receive. It describes
   * the SERVER's configuration, not any account, so it reveals nothing about who is registered.
   */
  readonly configured?: boolean;
}

export class ProviderNotConfiguredError extends Error {
  constructor() {
    super('no messaging provider is configured');
    this.name = 'ProviderNotConfiguredError';
  }
}

/** Fails every send. The OTP flows still work end to end; nothing is delivered until a real provider is wired in. */
export function createUnconfiguredMessagingProvider(): MessagingProvider {
  return {
    configured: false,
    async send() {
      throw new ProviderNotConfiguredError();
    },
  };
}

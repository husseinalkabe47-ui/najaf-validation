// Phase 11.8-C: AdMob server-side verification. No network: Google's key list is replaced by a fetcher over keys generated here, and
// callbacks are signed exactly the way AdMob signs them (ECDSA P-256 / SHA-256 over the query before "&signature=", DER, web-safe base64).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import {
  AdmobConfigError, AdmobKeysUnavailableError, KEY_HARD_MAX_AGE_MS, KEY_REFRESH_MS, UNKNOWN_KEY_REFETCH_COOLDOWN_MS,
  createAdmobCallbackHandler, createAdmobKeyStore, createAdmobRewardVerifier, loadAdmobConfig, parseSsvQuery, ssvTimestampMs,
} from '../../src/rewards/admob.ts';
import { ADMOB_CALLBACK_RATE_LIMIT, registerAdmobCallbackRoutes } from '../../src/rewards/admob-routes.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createRewardService } from '../../src/rewards/service.ts';
import { makeFakeRewards } from '../helpers/fake-rewards.ts';

const AD_UNIT = '1234567890';
const T0 = Date.UTC(2026, 5, 1, 12, 0, 0);
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) => readFileSync(join(ROOT, rel), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').split('\n').map((l) => l.replace(/^\s*\/\/.*$/, '')).join('\n');

const pair = () => generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
type Pair = ReturnType<typeof pair>;
const pem = (k: Pair) => k.publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

interface Cb { ad_network?: string; ad_unit?: string; custom_data?: string; reward_amount?: string; reward_item?: string; timestamp?: string; transaction_id?: string; user_id?: string }
/** A callback as AdMob would send it: parameters in alphabetical order, then signature, then key_id. */
function signed(k: Pair, over: Cb & { keyId?: string } = {}, grant?: { id: string; userId: string }): string {
  const base: Record<string, string | undefined> = {
    ad_network: '5450213213286189855', ad_unit: AD_UNIT, custom_data: grant?.id, reward_amount: '1', reward_item: 'publish',
    timestamp: String(T0 - 5000), transaction_id: 'ABCDEF0123456789ABCDEF0123456789', user_id: grant?.userId,
  };
  for (const [name, v] of Object.entries(over)) if (name !== 'keyId') base[name] = v as string | undefined;
  const content = Object.keys(base).sort().filter((n) => base[n] !== undefined).map((n) => `${n}=${encodeURIComponent(base[n]!)}`).join('&');
  const sig = sign('sha256', Buffer.from(content, 'utf8'), { key: k.privateKey, dsaEncoding: 'der' });
  return `${content}&signature=${b64url(sig)}&key_id=${over.keyId ?? '3335741209'}`;
}

function keyStore(k: Pair, o: { keyId?: string; fail?: () => boolean; clock?: { t: number } } = {}) {
  const clock = o.clock ?? { t: T0 };
  const calls = { n: 0 };
  const store = createAdmobKeyStore({
    now: () => clock.t,
    fetchKeys: async () => {
      calls.n++;
      if (o.fail?.()) throw new Error('network down');
      return [{ keyId: o.keyId ?? '3335741209', pem: pem(k) }];
    },
  });
  return { store, calls, clock };
}

function world(o: { k?: Pair; failKeys?: { v: boolean } } = {}) {
  const k = o.k ?? pair();
  const clock = { t: T0, now: () => clock.t };
  const keys = keyStore(k, { clock, fail: () => o.failKeys?.v === true });
  const fr = makeFakeRewards(clock);
  const verifier = createAdmobRewardVerifier({ config: { adUnitId: AD_UNIT }, keys: keys.store, now: () => clock.t });
  const svc = createRewardService({ store: fr.store, verifier });
  const handler = createAdmobCallbackHandler({ rewards: svc, keys: keys.store });
  fr.addUser('7');
  fr.addUser('8');
  fr.addCar('100', '7');
  const member = { id: '7', role: 'member' as const };
  const open = async (actor: { id: string; role: 'member' | 'dealer' | 'admin' } = member) => {
    const r = await svc.requestReward(actor);
    return { id: r.id, userId: actor.id };
  };
  return { k, clock, keys, fr, svc, handler, member, open, verifier };
}

describe('configuration', () => {
  it('without REWARD_PROVIDER the provider is off (null): the unconfigured verifier stays', () => {
    assert.equal(loadAdmobConfig({}), null);
    assert.equal(loadAdmobConfig({ REWARD_PROVIDER: ' ' }), null);
  });
  it('admob needs a numeric ad unit id; anything else stops the process with problems only (no values)', () => {
    assert.deepEqual(loadAdmobConfig({ REWARD_PROVIDER: 'admob', ADMOB_SSV_AD_UNIT_ID: ' 1234567890 ' }), { adUnitId: '1234567890' });
    for (const env of [{ REWARD_PROVIDER: 'admob' }, { REWARD_PROVIDER: 'admob', ADMOB_SSV_AD_UNIT_ID: 'ca-app-pub-1/2' }, { REWARD_PROVIDER: 'other', ADMOB_SSV_AD_UNIT_ID: '123456' }]) {
      assert.throws(() => loadAdmobConfig(env), (e: unknown) => e instanceof AdmobConfigError && e.problems.length >= 1 && !JSON.stringify(e.problems).includes('ca-app-pub-1'));
    }
  });
});

describe('parseSsvQuery', () => {
  const k = pair();
  const g = { id: '00000000-0000-4000-8000-000000000001', userId: '7' };
  it('accepts a well-formed callback and exposes the exact signed bytes', () => {
    const q = signed(k, {}, g);
    const p = parseSsvQuery(q)!;
    assert.equal(q.startsWith(p.signedContent + '&signature='), true);
    assert.deepEqual([p.params.get('custom_data'), p.params.get('user_id'), p.keyId], [g.id, '7', '3335741209']);
  });
  it('refuses: not a string, empty, too long, signature/key_id not last and in that order, missing, repeated names, bad escapes, bad key id', () => {
    const q = signed(k, {}, g);
    const [content, sig, key] = [q.slice(0, q.indexOf('&signature=')), q.slice(q.indexOf('&signature=') + 1, q.indexOf('&key_id=')), q.slice(q.indexOf('&key_id=') + 1)];
    const bad: unknown[] = [undefined, null, 5, '', 'a=b', `${content}&${key}&${sig}`, `${content}&${sig}`, `${content}&${key}`, `${content}&${sig}&${key}&x=1`, `${content}&user_id=8&${sig}&${key}`,
      `${content}&bad=%E0%A4%A&${sig}&${key}`, `${content}&${sig}&key_id=abc`, `${content}&${sig}&key_id=`, `&${sig}&${key}`, `${content}&signature=!!!&${key}`, `${content}&signature=AAAA&${key}`, 'x'.repeat(3000)];
    for (const input of bad) assert.equal(parseSsvQuery(input), null, String(input).slice(0, 60));
  });
  it('timestamps in seconds, milliseconds and microseconds are all read as the same instant; junk is null', () => {
    assert.deepEqual([ssvTimestampMs('1780315200'), ssvTimestampMs('1780315200000'), ssvTimestampMs('1780315200000000')], [1780315200000, 1780315200000, 1780315200000]);
    for (const t of ['', 'abc', '12', '-1', '1.5', '99999999999999999999']) assert.equal(ssvTimestampMs(t), null, t);
  });
});

describe('the key store (Google\'s verifier keys)', () => {
  it('fetches once and serves from cache; shares one fetch between concurrent callers', async () => {
    const { store, calls } = keyStore(pair());
    const [a, b] = await Promise.all([store.get('3335741209'), store.get('3335741209')]);
    assert.ok(a && b);
    await store.get('3335741209');
    assert.equal(calls.n, 1);
  });
  it('refreshes after the refresh age, and never trusts a key older than 24 hours when Google cannot be reached', async () => {
    const down = { v: false };
    const { store, calls, clock } = keyStore(pair(), { fail: () => down.v });
    await store.get('3335741209');
    clock.t += KEY_REFRESH_MS + 1;
    await store.get('3335741209');
    assert.equal(calls.n, 2);
    down.v = true;
    clock.t += KEY_REFRESH_MS + 1; // refresh fails, the cached key is younger than 24 h: still usable
    assert.ok(await store.get('3335741209'));
    clock.t += KEY_HARD_MAX_AGE_MS; // now older than 24 h and Google unreachable: fail closed
    await assert.rejects(store.get('3335741209'), AdmobKeysUnavailableError);
  });
  it('an unknown key id is null and triggers at most one refetch per cooldown; a rotated-in key is then found', async () => {
    const k1 = pair();
    const k2 = pair();
    let current = { id: '1', k: k1 };
    const clock = { t: T0 };
    let n = 0;
    const store = createAdmobKeyStore({ now: () => clock.t, fetchKeys: async () => { n++; return [{ keyId: current.id, pem: pem(current.k) }]; } });
    assert.ok(await store.get('1'));
    assert.equal(await store.get('2'), null);
    assert.equal(await store.get('2'), null);
    assert.equal(n, 1, 'inside the cooldown (counted from the last fetch) an unknown id does not hit Google again');
    current = { id: '2', k: k2 };
    clock.t += UNKNOWN_KEY_REFETCH_COOLDOWN_MS + 1;
    assert.ok(await store.get('2'));
    assert.equal(n, 2);
    assert.equal(await store.get('3'), null);
    assert.equal(n, 2, 'and again within the new cooldown');
  });
  it('an unusable or empty key list is "unavailable", never a pass', async () => {
    const store = createAdmobKeyStore({ now: () => T0, fetchKeys: async () => [{ keyId: '1', pem: 'not a pem' }] });
    await assert.rejects(store.get('1'), AdmobKeysUnavailableError);
    const rsa = generateKeyPairSync('rsa', { modulusLength: 2048 }).publicKey.export({ type: 'spki', format: 'pem' }).toString();
    await assert.rejects(createAdmobKeyStore({ now: () => T0, fetchKeys: async () => [{ keyId: '1', pem: rsa }] }).get('1'), AdmobKeysUnavailableError);
  });
});

describe('the verifier: a signed callback is necessary, and bound to THIS grant, THIS user and OUR ad unit', () => {
  const verifyWith = async (w: ReturnType<typeof world>, query: unknown, g: { id: string; userId: string }) => w.verifier.verify({ grantId: g.id, userId: g.userId, evidence: { query } });

  it('a valid callback verifies and yields the transaction id', async () => {
    const w = world();
    const g = await w.open();
    assert.deepEqual(await verifyWith(w, signed(w.k, {}, g), g), { ok: true, transactionId: 'ABCDEF0123456789ABCDEF0123456789' });
  });
  it('fails closed on every deviation', async () => {
    const w = world();
    const g = await w.open();
    const other = pair();
    const good = signed(w.k, {}, g);
    const cases: Array<[string, unknown]> = [
      ['signed by another key', signed(other, {}, g)],
      ['a parameter changed after signing', good.replace('reward_amount=1', 'reward_amount=9')],
      ['parameters reordered', good.replace(/^(ad_network=[^&]*)&(ad_unit=[^&]*)/, '$2&$1')],
      ['another ad unit (a different AdMob account)', signed(w.k, { ad_unit: '999999' }, g)],
      ['another user', signed(w.k, { user_id: '8' }, g)],
      ['another grant (custom_data)', signed(w.k, { custom_data: '00000000-0000-4000-8000-0000000000aa' }, g)],
      ['no custom_data', signed(w.k, { custom_data: undefined }, g)],
      ['no user_id', signed(w.k, { user_id: undefined }, g)],
      ['no transaction_id', signed(w.k, { transaction_id: undefined }, g)],
      ['transaction_id with odd characters', signed(w.k, { transaction_id: 'a b;c' }, g)],
      ['too old', signed(w.k, { timestamp: String(T0 - 2 * 3600 * 1000) }, g)],
      ['in the future', signed(w.k, { timestamp: String(T0 + 3600 * 1000) }, g)],
      ['no timestamp', signed(w.k, { timestamp: undefined }, g)],
      ['unknown key id', signed(w.k, { keyId: '42' }, g)],
      ['not a string', 12345],
      ['empty', ''],
    ];
    for (const [name, q] of cases) assert.deepEqual(await verifyWith(w, q, g), { ok: false }, name);
  });
  it('evidence of any other shape is refused (what a client could invent: flags, ids, receipts)', async () => {
    const w = world();
    const g = await w.open();
    for (const evidence of [null, undefined, 'x', 1, {}, { success: true }, { transactionId: 'abc', status: 'verified' }, { query: { a: 1 } }]) {
      assert.deepEqual(await w.verifier.verify({ grantId: g.id, userId: g.userId, evidence }), { ok: false });
    }
  });
});

describe('the callback handler, over the real reward service', () => {
  it('a valid callback verifies the grant (provider admob, receipt stored); it consumes and publishes NOTHING', async () => {
    const w = world();
    const g = await w.open();
    assert.deepEqual(await w.handler.handle(signed(w.k, {}, g)), { status: 200, code: 'ok' });
    const row = w.fr.grants()[0]!;
    assert.deepEqual([row.status, row.provider, row.ssvTransactionId, row.carId], ['verified', 'admob', 'ABCDEF0123456789ABCDEF0123456789', null]);
    assert.equal(w.fr.car('100')!.status, 'pending');
    assert.equal(w.fr.audits().length, 0);
  });
  it('then the member\'s own consume request publishes the ad directly (verified AND consumed); before the callback it does not', async () => {
    const w = world();
    const g = await w.open();
    await assert.rejects(w.svc.consumeReward(w.member, g.id, '100'), { code: 'invalid_state' });
    assert.equal(w.fr.car('100')!.status, 'pending');
    await w.handler.handle(signed(w.k, {}, g));
    const out = await w.svc.consumeReward(w.member, g.id, '100');
    assert.deepEqual([out.published, w.fr.car('100')!.status], [true, 'active']);
  });
  it('the same callback again (Google retries) is 200 and changes nothing; the same receipt for another grant is refused', async () => {
    const w = world();
    const g = await w.open();
    const q = signed(w.k, {}, g);
    assert.equal((await w.handler.handle(q)).status, 200);
    assert.equal((await w.handler.handle(q)).status, 200);
    const g2 = await w.open();
    assert.deepEqual(await w.handler.handle(signed(w.k, {}, g2)), { status: 400, code: 'rejected' }); // same transaction_id: the receipt is spent
    assert.deepEqual(w.fr.grants().map((r) => r.status), ['verified', 'requested']);
  });
  it('untrustworthy callbacks are ONE uniform 400 and leave the grant requested: bad signature, wrong user, wrong ad unit, unknown grant, malformed', async () => {
    const w = world();
    const g = await w.open();
    const answers = [
      await w.handler.handle(signed(pair(), {}, g)),
      await w.handler.handle(signed(w.k, { user_id: '8' }, g)),
      await w.handler.handle(signed(w.k, { ad_unit: '555555' }, g)),
      await w.handler.handle(signed(w.k, { custom_data: '00000000-0000-4000-8000-0000000000aa' }, g)),
      await w.handler.handle(signed(w.k, { custom_data: 'not-a-uuid' }, g)),
      await w.handler.handle('garbage'),
      await w.handler.handle(undefined),
    ];
    for (const a of answers) assert.deepEqual(a, { status: 400, code: 'rejected' });
    assert.equal(w.fr.grants()[0]!.status, 'requested');
  });
  it('an expired grant is not verified', async () => {
    const w = world();
    const g = await w.open();
    w.clock.t += 31 * 60 * 1000;
    assert.equal((await w.handler.handle(signed(w.k, { timestamp: String(w.clock.t - 1000) }, g))).status, 400);
    assert.equal(w.fr.grants()[0]!.status, 'requested');
  });
  it('Google\'s keys unreachable: 503 (Google retries), nothing verified; once they are back the retry verifies', async () => {
    const failKeys = { v: true };
    const w = world({ failKeys });
    const g = await w.open();
    const q = signed(w.k, {}, g);
    assert.deepEqual(await w.handler.handle(q), { status: 503, code: 'unavailable' });
    assert.equal(w.fr.grants()[0]!.status, 'requested');
    failKeys.v = false;
    assert.equal((await w.handler.handle(q)).status, 200);
    assert.equal(w.fr.grants()[0]!.status, 'verified');
  });
  it('a database failure while verifying is NOT swallowed into success (it propagates: 5xx, Google retries)', async () => {
    const w = world();
    const g = await w.open();
    w.fr.faults.beforeMarkVerified = () => { throw new Error('db down'); };
    await assert.rejects(w.handler.handle(signed(w.k, {}, g)));
    assert.equal(w.fr.grants()[0]!.status, 'requested');
  });
  it('a showroom owner\'s or administrator\'s verified reward still does NOT publish (admin approval path unchanged)', async () => {
    for (const role of ['dealer', 'admin'] as const) {
      const w = world();
      const actor = { id: '7', role };
      const g = await w.open(actor);
      await w.handler.handle(signed(w.k, {}, g));
      const out = await w.svc.consumeReward(actor, g.id, '100');
      assert.deepEqual([out.published, w.fr.car('100')!.status], [false, 'pending'], role);
    }
  });
});

describe('the callback route', () => {
  function register(withLimiter = false) {
    const routes: Array<{ path: string; opts: { onRequest?: Array<(r: unknown, p: unknown) => Promise<unknown>> }; handler: (r: unknown, p: unknown) => Promise<unknown> }> = [];
    const w = world();
    const limiter = createMemoryRateLimiter({ now: () => T0 });
    registerAdmobCallbackRoutes({ get: (path: string, opts: never, handler: never) => routes.push({ path, opts, handler }) } as never, { callbacks: w.handler, ...(withLimiter ? { rateLimiter: limiter } : {}) });
    const call = async (url: string) => {
      const sent: { status?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
      const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
      const req = { id: 'req-abcdef01', ip: '66.249.0.1', url, headers: {}, log: { warn() {} } };
      for (const hook of routes[0]!.opts.onRequest ?? []) {
        await hook(req, reply);
        if (sent.status !== undefined) return sent;
      }
      await routes[0]!.handler(req, reply);
      return sent;
    };
    return { w, routes, call };
  }

  it('is exactly one GET route with no bearer requirement, and it hands the RAW query string to the handler', async () => {
    const { w, routes, call } = register();
    assert.deepEqual(routes.map((r) => r.path), ['/v1/rewards/admob/ssv']);
    const g = await w.open();
    const sent = await call(`/v1/rewards/admob/ssv?${signed(w.k, {}, g)}`);
    assert.deepEqual([sent.status, sent.body], [200, { status: 'ok' }]);
    assert.equal(w.fr.grants()[0]!.status, 'verified');
  });
  it('bad callbacks are 400 and 503 as specified, with no detail about the reason', async () => {
    const { w, call } = register();
    const g = await w.open();
    const bad = await call(`/v1/rewards/admob/ssv?${signed(pair(), {}, g)}`);
    assert.equal(bad.status, 400);
    assert.deepEqual(Object.keys((bad.body as { error: object }).error).sort(), ['code', 'message', 'requestId']);
    assert.equal(((bad.body as { error: { code: string } }).error).code, 'rejected');
    assert.equal((await call('/v1/rewards/admob/ssv')).status, 400);
  });
  it('is rate limited per address and the limited response verifies nothing', async () => {
    const { w, call } = register(true);
    const g = await w.open();
    for (let i = 0; i < ADMOB_CALLBACK_RATE_LIMIT.limit; i++) await call('/v1/rewards/admob/ssv?x=1');
    const sent = await call(`/v1/rewards/admob/ssv?${signed(w.k, {}, g)}`);
    assert.equal(sent.status, 429);
    assert.ok(Number(sent.headers['retry-after']) >= 1);
    assert.equal(w.fr.grants()[0]!.status, 'requested');
  });
});

describe('boundaries and static guards', () => {
  it('website submissions stay under admin approval: creating a member ad is still pending, and no reward is involved', () => {
    const src = code('src/member-cars/service.ts');
    assert.ok(typeof createMemberCarService === 'function');
    assert.ok(!/reward/i.test(src), 'member-car creation knows nothing about rewards: every new ad is stored pending');
  });
  it('the AdMob code cannot write the database, consume or publish, and the callback route needs no member identity', () => {
    for (const f of ['src/rewards/admob.ts', 'src/rewards/admob-routes.ts']) {
      const src = code(f);
      assert.ok(!/INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|consumeReward|publishOwnCar|requestReward/i.test(src), f);
      assert.ok(!/console\.|logger\.\w+\([^)]*(query|rawQuery|signature)/i.test(src), `${f} never logs the evidence`);
    }
    assert.ok(!/authenticate|bearer/i.test(code('src/rewards/admob-routes.ts')));
  });
  it('the key fetch goes to Google over HTTPS only and nothing else in src calls the network', () => {
    const src = code('src/rewards/admob.ts');
    assert.match(src, /ADMOB_KEYS_URL = 'https:\/\/gstatic\.com\/admob\/reward\/verifier-keys\.json'/);
    assert.ok(!/http:\/\//.test(src));
  });
  it('production wiring: provider off unless REWARD_PROVIDER is set; the callback route exists only with a configured provider; the member routes are unchanged', () => {
    const index = code('src/index.ts');
    assert.match(index, /admobConfig \? createAdmobRewardVerifier\(/);
    assert.match(index, /: createUnconfiguredRewardVerifier\(\)/);
    assert.match(index, /const rewardCallbacks = admobConfig \?/);
    assert.match(code('src/server.ts'), /if \(deps\.rewardCallbacks\) registerAdmobCallbackRoutes/);
  });
});

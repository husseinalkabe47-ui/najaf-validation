// Phase 11.8-B: the reward HTTP layer, run WITHOUT Fastify (the same method as member-cars-http.test.ts). Routes are registered on a
// recording stand-in; handlers are called with plain request objects, wired to the REAL authentication service (tokens, account
// re-read), the REAL reward service over the in-memory store, and the FAKE verifier (tests only). Plus static guards on the sources.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { DbError } from '../../src/errors.ts';
import { createUnconfiguredRewardVerifier } from '../../src/rewards/provider.ts';
import { REWARD_RATE_LIMITS, registerRewardRoutes, toRewardHttp } from '../../src/rewards/routes.ts';
import { RewardError, createRewardService } from '../../src/rewards/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeRewards, makeFakeVerifier } from '../helpers/fake-rewards.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrorBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JSON_HEADERS = { 'content-type': 'application/json' };
const PATH_REQUEST = '/v1/me/rewards';
const PATH_CONSUME = '/v1/me/rewards/:id/consume';

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(o: { withLimiter?: boolean; unconfigured?: boolean; policy?: { maxOpen?: number } } = {}) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const fr = makeFakeRewards(clock);
  const verifier = makeFakeVerifier();
  const svc = createRewardService({ store: fr.store, verifier: o.unconfigured ? createUnconfiguredRewardVerifier() : verifier, ...(o.policy ? { policy: o.policy } : {}) });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  // The routes get ONLY the two methods they may use; `svc` (with verifyReward) stays on the server side of this test.
  registerRewardRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, {
    auth,
    rewards: { requestReward: svc.requestReward, consumeReward: svc.consumeReward },
    ...(o.withLimiter ? { rateLimiter: limiter } : {}),
  });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  let nextCar = 100;
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    fr.addUser(r.user.id);
    const who = { id: r.user.id, headers: bearer(r.session.accessToken), json: { ...bearer(r.session.accessToken), ...JSON_HEADERS } };
    return { ...who, ad: () => { const id = String(nextCar++); fr.addCar(id, who.id); return id; } };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    fr.addUser(r.user.id);
    return { id: r.user.id, json: { ...bearer(r.session.accessToken), ...JSON_HEADERS } };
  }
  const evidence = (g: { id: string; userId: string }) => ({ grantId: g.id, userId: g.userId, tx: `tx-${g.id}` });
  /** What provider-side server code will do in a later step: verify (never reachable from the routes). */
  async function verify(id: string) {
    const g = fr.grants().find((x) => x.id === id)!;
    await svc.verifyReward(id, evidence(g));
  }
  async function requestVia(who: { json: Record<string, string> }) {
    const sent = await call('POST', PATH_REQUEST, { headers: who.json });
    assert.equal(sent.status, 201, JSON.stringify(sent.body));
    return (sent.body as { reward: { id: string; expiresAt: string } }).reward;
  }
  return { routes, call, member, pendingDealer, requestVia, verify, fr, verifier, clock, db };
}

const errOf = (s: Sent) => (s.body as ErrorBody).error;

describe('reward routes: registration', () => {
  it('registers exactly the two member routes and nothing that verifies', () => {
    const { routes } = setup();
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`POST ${PATH_REQUEST}`, `POST ${PATH_CONSUME}`].sort());
    assert.ok(routes.every((r) => !/verif|ssv|callback|receipt|transaction/i.test(r.path)));
  });

  it('every route is rate limited when a limiter is supplied; bodies are tiny', () => {
    const { routes } = setup({ withLimiter: true });
    for (const r of routes) {
      assert.ok((r.opts?.onRequest ?? []).length >= 1, `${r.method} ${r.path}`);
      assert.equal(r.opts?.bodyLimit, 1024);
    }
  });
});

describe('reward routes: authentication and authorization', () => {
  it('no token, a bad token and a non-Bearer header are 401 with WWW-Authenticate on both routes', async () => {
    const { call } = setup();
    for (const [method, path] of [['POST', PATH_REQUEST], ['POST', '/v1/me/rewards/:id/consume']] as const) {
      for (const headers of [{}, { authorization: 'Bearer not-a-token' }, { authorization: 'Basic abc' }]) {
        const s = await call(method, path, { headers: { ...JSON_HEADERS, ...headers }, params: { id: '00000000-0000-4000-8000-000000000001' }, body: { carId: '1' } });
        assert.equal(s.status, 401, `${path} ${JSON.stringify(headers)}`);
        assert.equal(s.headers['www-authenticate'], 'Bearer');
        assert.equal(errOf(s).code, 'unauthorized');
      }
    }
  });

  it('authentication comes before body validation: an anonymous caller learns nothing about the body rules', async () => {
    const { call } = setup();
    const s = await call('POST', PATH_CONSUME, { headers: JSON_HEADERS, params: { id: 'x' }, body: { status: 'consumed' } });
    assert.equal(s.status, 401);
  });

  it('a pending showroom owner (activation not approved) has no actor: 403 on both routes, nothing created', async () => {
    const { call, pendingDealer, fr } = setup();
    const d = await pendingDealer();
    assert.equal((await call('POST', PATH_REQUEST, { headers: d.json })).status, 403);
    fr.addCar('900', d.id);
    assert.equal((await call('POST', PATH_CONSUME, { headers: d.json, params: { id: '00000000-0000-4000-8000-000000000001' }, body: { carId: '900' } })).status, 403);
    assert.equal(fr.grants().length, 0);
    assert.equal(fr.car('900')!.status, 'pending');
  });

  it('a suspended member is 403 (the account is re-read on every request)', async () => {
    const { call, member, db } = setup();
    const m = await member();
    const row = db.users().find((u) => u.id === m.id)!;
    (row as { status: string }).status = 'suspended';
    const s = await call('POST', PATH_REQUEST, { headers: m.json });
    assert.ok(s.status === 401 || s.status === 403, String(s.status));
  });
});

describe('reward routes: POST /v1/me/rewards', () => {
  it('opens a grant for the TOKEN\'s account: 201 {reward:{id, expiresAt}} and nothing else', async () => {
    const { requestVia, member, fr } = setup();
    const m = await member();
    const reward = await requestVia(m);
    assert.deepEqual(Object.keys(reward).sort(), ['expiresAt', 'id']);
    const g = fr.grants()[0]!;
    assert.deepEqual([g.userId, g.status, g.carId, g.ssvTransactionId], [m.id, 'requested', null, null]);
  });

  it('verification is unavailable (the production verifier): 503 unavailable and nothing is opened', async () => {
    const { call, member, fr } = setup({ unconfigured: true });
    const m = await member();
    const s = await call('POST', PATH_REQUEST, { headers: m.json });
    assert.equal(s.status, 503);
    assert.equal(errOf(s).code, 'unavailable');
    assert.equal(fr.grants().length, 0);
  });

  it('a body is refused: nothing a client sends can influence the grant (userId, status, transaction id, flags)', async () => {
    const { call, member, fr } = setup();
    const m = await member();
    for (const body of [{ userId: '1' }, { status: 'verified' }, { transactionId: 't' }, { success: true }, [1], 'x']) {
      const s = await call('POST', PATH_REQUEST, { headers: m.json, body });
      assert.equal(s.status, 400, JSON.stringify(body));
      assert.equal(errOf(s).code, 'validation_failed');
    }
    assert.equal(fr.grants().length, 0);
    assert.equal((await call('POST', PATH_REQUEST, { headers: m.json, body: {} })).status, 201, 'an empty object is the same as no body');
  });

  it('too many open requests: 429 rate_limited (the service\'s limit), per account', async () => {
    const { call, member, requestVia } = setup({ policy: { maxOpen: 2 } });
    const m = await member();
    const other = await member();
    await requestVia(m);
    await requestVia(m);
    const s = await call('POST', PATH_REQUEST, { headers: m.json });
    assert.equal(s.status, 429);
    assert.equal(errOf(s).code, 'rate_limited');
    await requestVia(other);
  });

  it('the HTTP rate limit answers 429 with Retry-After once the window is used up, and that response opens nothing', async () => {
    const { call, member, fr } = setup({ withLimiter: true, policy: { maxOpen: 1000 } });
    const m = await member();
    for (let i = 0; i < REWARD_RATE_LIMITS.request.limit; i++) assert.equal((await call('POST', PATH_REQUEST, { headers: m.json })).status, 201);
    const s = await call('POST', PATH_REQUEST, { headers: m.json });
    assert.equal(s.status, 429);
    assert.ok(Number(s.headers['retry-after']) >= 1);
    assert.equal(fr.grants().length, REWARD_RATE_LIMITS.request.limit);
  });
});

describe('reward routes: POST /v1/me/rewards/:id/consume', () => {
  const consume = (call: ReturnType<typeof setup>['call'], who: { json: Record<string, string> }, id: string, body: unknown) => call('POST', PATH_CONSUME, { headers: who.json, params: { id }, body });

  it('a verified, unexpired grant publishes the member\'s own ad: 200, status active, audit row, nothing else touched', async () => {
    const { call, member, requestVia, verify, fr } = setup();
    const m = await member();
    const ad = m.ad();
    const other = m.ad();
    const r = await requestVia(m);
    await verify(r.id);
    const s = await consume(call, m, r.id, { carId: ad });
    assert.equal(s.status, 200, JSON.stringify(s.body));
    assert.deepEqual(s.body, { reward: { id: r.id, carId: ad, status: 'consumed', published: true } });
    assert.deepEqual([fr.car(ad)!.status, fr.car(other)!.status], ['active', 'pending']);
    assert.equal(fr.audits().length, 1);
  });

  it('a grant the server has NOT verified publishes nothing: 409 invalid_state (the client has no way to verify it)', async () => {
    const { call, member, requestVia, fr } = setup();
    const m = await member();
    const ad = m.ad();
    const r = await requestVia(m);
    const s = await consume(call, m, r.id, { carId: ad });
    assert.equal(s.status, 409);
    assert.equal(errOf(s).code, 'invalid_state');
    assert.deepEqual([fr.car(ad)!.status, fr.grants()[0]!.status, fr.audits().length], ['pending', 'requested', 0]);
  });

  it('client-supplied proof is refused, not ignored: status, transaction id, user id and success flags are 400 and change nothing', async () => {
    const { call, member, requestVia, fr } = setup();
    const m = await member();
    const ad = m.ad();
    const r = await requestVia(m);
    for (const extra of [{ status: 'verified' }, { transactionId: 'abc' }, { ssvTransactionId: 'abc' }, { userId: m.id }, { success: true }, { verified: true }, { published: true }]) {
      const s = await consume(call, m, r.id, { carId: ad, ...extra });
      assert.equal(s.status, 400, JSON.stringify(extra));
      assert.deepEqual(errOf(s).fields, [{ field: Object.keys(extra)[0], code: 'unknown_field' }]);
    }
    assert.deepEqual([fr.car(ad)!.status, fr.grants()[0]!.status, fr.grants()[0]!.ssvTransactionId], ['pending', 'requested', null]);
  });

  it('invalid bodies are 400 with field names only: missing, wrong type, not an object', async () => {
    const { call, member, requestVia } = setup();
    const m = await member();
    const r = await requestVia(m);
    const cases: Array<[unknown, Array<{ field: string; code: string }>]> = [
      [{}, [{ field: 'carId', code: 'required' }]],
      [{ carId: 5 }, [{ field: 'carId', code: 'invalid_type' }]],
      [{ carId: null }, [{ field: 'carId', code: 'invalid_type' }]],
      [[], [{ field: 'body', code: 'invalid_type' }]],
      ['x', [{ field: 'body', code: 'invalid_type' }]],
      [undefined, [{ field: 'body', code: 'invalid_type' }]],
    ];
    for (const [body, fields] of cases) {
      const s = await consume(call, m, r.id, body);
      assert.equal(s.status, 400, JSON.stringify(body));
      assert.deepEqual(errOf(s).fields, fields);
    }
  });

  it('a non-JSON content type is 415', async () => {
    const { call, member, requestVia } = setup({ withLimiter: true });
    const m = await member();
    const r = await requestVia(m);
    const s = await call('POST', PATH_CONSUME, { headers: { ...m.headers, 'content-type': 'text/plain' }, params: { id: r.id }, body: '{"carId":"1"}' });
    assert.equal(s.status, 415);
  });

  it('the same answer for an unknown grant, a malformed id, someone else\'s grant and someone else\'s ad: 404 not_found', async () => {
    const { call, member, requestVia, verify, fr } = setup();
    const a = await member();
    const b = await member();
    const mine = a.ad();
    const theirs = b.ad();
    const r = await requestVia(a);
    await verify(r.id);
    const answers = [
      await consume(call, a, '00000000-0000-4000-8000-0000000000ff', { carId: mine }),
      await consume(call, a, 'not-a-uuid', { carId: mine }),
      await consume(call, b, r.id, { carId: theirs }),
      await consume(call, a, r.id, { carId: theirs }),
      await consume(call, a, r.id, { carId: '999999' }),
      await consume(call, a, r.id, { carId: 'abc' }),
    ];
    for (const s of answers) {
      assert.equal(s.status, 404);
      assert.equal(errOf(s).code, 'not_found');
    }
    assert.deepEqual([fr.car(mine)!.status, fr.car(theirs)!.status, fr.grants()[0]!.status], ['pending', 'pending', 'verified']);
  });

  it('replay: the same request again is idempotent (200, nothing changes); the spent grant cannot publish a second ad (409); a second grant cannot take the same ad', async () => {
    const { call, member, requestVia, verify, fr } = setup();
    const m = await member();
    const ad = m.ad();
    const second = m.ad();
    const r = await requestVia(m);
    await verify(r.id);
    assert.equal((await consume(call, m, r.id, { carId: ad })).status, 200);
    const again = await consume(call, m, r.id, { carId: ad });
    assert.equal(again.status, 200);
    assert.deepEqual(again.body, { reward: { id: r.id, carId: ad, status: 'consumed', published: true } });
    assert.equal(fr.audits().length, 1, 'repeating publishes and audits nothing more');
    const reuse = await consume(call, m, r.id, { carId: second });
    assert.equal(reuse.status, 409);
    assert.equal(errOf(reuse).code, 'invalid_state');
    const r2 = await requestVia(m);
    await verify(r2.id);
    const taken = await consume(call, m, r2.id, { carId: ad });
    assert.equal(taken.status, 409);
    assert.deepEqual([fr.car(second)!.status, fr.audits().length], ['pending', 1]);
  });

  it('an expired grant is 409 expired and publishes nothing (time is the injected database clock)', async () => {
    const { call, member, fr, clock } = setup();
    const m = await member();
    const ad = m.ad();
    const g = fr.seed({ userId: m.id, status: 'verified', ssvTransactionId: 'tx-old', verifiedAt: new Date(clock.now() - 2000), expiresAt: new Date(clock.now() - 1000) });
    const s = await consume(call, m, g.id, { carId: ad });
    assert.equal(s.status, 409);
    assert.equal(errOf(s).code, 'expired');
    assert.deepEqual([fr.car(ad)!.status, fr.grants()[0]!.status], ['pending', 'verified']);
  });

  it('an ad that is not pending (already public, rejected or sold) is 409 and is never changed by a reward', async () => {
    const { call, member, requestVia, verify, fr } = setup();
    const m = await member();
    const r = await requestVia(m);
    await verify(r.id);
    for (const status of ['active', 'rejected', 'suspended', 'sold']) {
      const ad = m.ad();
      fr.setCarStatus(ad, status);
      const s = await consume(call, m, r.id, { carId: ad });
      assert.equal(s.status, 409, status);
      assert.equal(fr.car(ad)!.status, status);
    }
    assert.equal(fr.grants()[0]!.status, 'verified');
  });

  it('safe failure: a database failure while consuming is NOT turned into success; the grant stays verified, the ad pending, nothing audited', async () => {
    const { call, member, requestVia, verify, fr } = setup();
    const m = await member();
    const ad = m.ad();
    const r = await requestVia(m);
    await verify(r.id);
    fr.faults.beforeConsume = () => { throw new DbError('unavailable', { sqlstate: '08006' }); };
    await assert.rejects(consume(call, m, r.id, { carId: ad }), DbError); // unmapped here: the global error handler answers 5xx
    assert.deepEqual([fr.grants()[0]!.status, fr.grants()[0]!.carId, fr.car(ad)!.status, fr.audits().length], ['verified', null, 'pending', 0]);
    fr.faults.beforeConsume = null;
    assert.equal((await consume(call, m, r.id, { carId: ad })).status, 200, 'and a retry then succeeds exactly once');
    assert.equal(fr.audits().length, 1);
  });

  it('two concurrent consumptions of one grant publish at most one ad', async () => {
    const { call, member, requestVia, verify, fr } = setup();
    const m = await member();
    const a = m.ad();
    const b = m.ad();
    const r = await requestVia(m);
    await verify(r.id);
    const results = await Promise.all([consume(call, m, r.id, { carId: a }), consume(call, m, r.id, { carId: b })]);
    assert.deepEqual(results.map((s) => s.status).sort(), [200, 409]);
    assert.equal([a, b].filter((id) => fr.car(id)!.status === 'active').length, 1);
    assert.equal(fr.audits().length, 1);
  });

  it('the HTTP rate limit answers 429 with Retry-After and consumes nothing', async () => {
    const { call, member, requestVia, verify, fr } = setup({ withLimiter: true });
    const m = await member();
    const ad = m.ad();
    const r = await requestVia(m);
    await verify(r.id);
    for (let i = 0; i < REWARD_RATE_LIMITS.consume.limit; i++) assert.equal((await consume(call, m, r.id, { carId: 'abc' })).status, 404);
    const s = await consume(call, m, r.id, { carId: ad });
    assert.equal(s.status, 429);
    assert.ok(Number(s.headers['retry-after']) >= 1);
    assert.deepEqual([fr.car(ad)!.status, fr.grants()[0]!.status], ['pending', 'verified']);
  });
});

describe('reward routes: error mapping and static guards', () => {
  it('every RewardError code has a status; others are not ours', () => {
    const expected: Record<string, number> = { not_found: 404, invalid_state: 409, expired: 409, replayed: 409, verification_failed: 409, rate_limited: 429, unavailable: 503 };
    for (const [c, status] of Object.entries(expected)) assert.equal(toRewardHttp(new RewardError(c as never))?.status, status, c);
    assert.equal(toRewardHttp(new Error('x')), undefined);
    assert.equal(toRewardHttp(new DbError('unavailable', {})), undefined);
  });

  it('routes.ts cannot verify: it never mentions verifyReward, the verifier, transaction ids or receipts, and it is typed with the two methods only', () => {
    const src = code('src/rewards/routes.ts');
    assert.ok(!/verifyReward|\.verify\(|createUnconfigured|makeFake|ssv|receipt|signature/i.test(src));
    assert.ok(/Pick<RewardApi, 'requestReward' \| 'consumeReward'>/.test(src));
  });

  it('the owner never comes from the request: the only identity source is auth.authenticate', () => {
    const src = code('src/rewards/routes.ts');
    assert.equal((src.match(/auth\.authenticate\(/g) ?? []).length, 1);
    assert.ok(!/request\.(params|query|body)\??\.(user|owner)/i.test(src));
  });

  it('production wiring uses the UNCONFIGURED verifier and registers the routes only through buildServer with auth', () => {
    const index = code('src/index.ts');
    // 11.8-C: the verifier is AdMob's only when REWARD_PROVIDER configures it; otherwise it is still the unconfigured one.
    assert.ok(/createRewardService\(\{ store: createPgRewardStore\(db\), verifier: admobConfig \? createAdmobRewardVerifier\([^)]*\) : createUnconfiguredRewardVerifier\(\)/.test(index));
    assert.ok(!/makeFakeVerifier|test\/helpers/.test(index));
    const server = code('src/server.ts');
    assert.ok(/deps\.auth && deps\.rewards\) registerRewardRoutes/.test(server));
  });

  it('this step adds no schema, no frontend and no provider: no migration file mentions the new routes and src has no provider SDK', () => {
    const files = ['src/rewards/provider.ts', 'src/rewards/routes.ts'].map(code).join('\n');
    assert.ok(!/admob|ironsource|applovin|unity ?ads|fetch\(|https?:\/\//i.test(files));
  });
});

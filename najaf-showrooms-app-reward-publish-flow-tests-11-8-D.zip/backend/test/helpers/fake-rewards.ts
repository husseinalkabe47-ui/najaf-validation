// In-memory RewardStore (Phase 11.8, Step 1) plus a FAKE verifier. Both are for tests only: nothing under src/ may import this file
// (a static guard in rewards.test.ts enforces it). The store mirrors, independently of src, what the SQL does: the expected-state
// compare-and-swaps, the two unique indexes (reward_ssv_uq, reward_grants_car_id_key), expiry by an injected "database clock", and
// transactions that are serialised (the stand-in for row locks) and rolled back when the function throws.
import type { AuditEvent, AuditRepository } from '../../src/auth/repository.ts';
import { DbError } from '../../src/errors.ts';
import type { RewardVerifier } from '../../src/rewards/provider.ts';
import type { CarForReward, GrantRow, RewardRepository, RewardStore } from '../../src/rewards/repository.ts';

export function makeFakeRewards(clock: { now(): number }) {
  let grants: GrantRow[] = [];
  const users = new Map<string, { status: string; deleted: boolean }>();
  const cars = new Map<string, { ownerId: string; status: string; source: string; deleted: boolean; version: number }>();
  let nextId = 1;
  let open = 0;
  let audits: AuditEvent[] = [];
  const calls: string[] = [];
  const faults: { beforeMarkVerified: (() => void) | null; beforeConsume: (() => void) | null; beforePublish: (() => void) | null; failAudit: boolean } = { beforeMarkVerified: null, beforeConsume: null, beforePublish: null, failAudit: false };
  const uuid = () => `00000000-0000-4000-8000-${String(nextId++).padStart(12, '0')}`;
  const withExpiry = (g: GrantRow): GrantRow => ({ ...g, expired: g.expiresAt.getTime() <= clock.now() });
  const put = (g: GrantRow) => {
    grants = grants.map((x) => (x.id === g.id ? g : x));
    return withExpiry(g);
  };

  const repo: RewardRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      const u = users.get(userId);
      return !!u && u.status === 'active' && !u.deleted;
    },
    async lockRequests() {
      calls.push('lockRequests');
    },
    async countOpen(userId) {
      calls.push('countOpen');
      return grants.filter((g) => g.userId === userId && g.status === 'requested' && g.expiresAt.getTime() > clock.now()).length;
    },
    async insertRequest(i) {
      calls.push('insertRequest');
      const now = new Date(clock.now());
      const g: GrantRow = { id: uuid(), userId: i.userId, provider: i.provider, status: 'requested', ssvTransactionId: null, carId: null, createdAt: now, verifiedAt: null, consumedAt: null, expiresAt: new Date(clock.now() + i.ttlSeconds * 1000), expired: false };
      grants.push(g);
      return withExpiry(g);
    },
    async find(id) {
      const g = grants.find((x) => x.id === id);
      return g ? withExpiry(g) : null;
    },
    async lock(id) {
      calls.push('lock');
      const g = grants.find((x) => x.id === id);
      return g ? withExpiry(g) : null;
    },
    async findByTransaction(provider, tx) {
      const g = grants.find((x) => x.provider === provider && x.ssvTransactionId === tx);
      return g ? withExpiry(g) : null;
    },
    async markVerified(i) {
      calls.push('markVerified');
      faults.beforeMarkVerified?.();
      const g = grants.find((x) => x.id === i.id);
      if (!g || g.userId !== i.userId || g.provider !== i.provider || g.status !== 'requested' || g.carId !== null || g.expiresAt.getTime() <= clock.now()) return null;
      if (grants.some((x) => x.provider === i.provider && x.ssvTransactionId === i.transactionId)) throw new DbError('unique', { sqlstate: '23505', constraint: 'reward_ssv_uq' });
      return put({ ...g, status: 'verified', ssvTransactionId: i.transactionId, verifiedAt: new Date(clock.now()) });
    },
    async lockOwnCar(carId, userId): Promise<CarForReward | null> {
      calls.push('lockOwnCar');
      const c = cars.get(carId);
      return c && c.ownerId === userId && c.source === 'member' && !c.deleted ? { id: carId, status: c.status } : null;
    },
    async carHasGrant(carId) {
      return grants.some((g) => g.carId === carId);
    },
    async consume(i) {
      calls.push('consume');
      faults.beforeConsume?.();
      const g = grants.find((x) => x.id === i.id);
      if (!g || g.userId !== i.userId || g.status !== 'verified' || g.carId !== null || g.expiresAt.getTime() <= clock.now()) return null;
      if (grants.some((x) => x.carId === i.carId)) throw new DbError('unique', { sqlstate: '23505', constraint: 'reward_grants_car_id_key' });
      return put({ ...g, status: 'consumed', carId: i.carId, consumedAt: new Date(clock.now()) });
    },
    async publishOwnCar(i) {
      calls.push('publishOwnCar');
      faults.beforePublish?.();
      const c = cars.get(i.carId);
      if (!c || c.ownerId !== i.userId || c.source !== 'member' || c.deleted || c.status !== 'pending') return null;
      c.status = 'active';
      c.version += 1;
      return c.version;
    },
  };
  const auditRepo: AuditRepository = {
    async record(e) {
      calls.push('audit.record');
      if (faults.failAudit) throw new DbError('unavailable', { sqlstate: '08006' });
      audits.push(e);
    },
  };

  // Transactions run one at a time (a coarse stand-in for row locks) and roll back everything when the function throws.
  let tail: Promise<unknown> = Promise.resolve();
  const store: RewardStore = {
    grants: repo,
    transaction<T>(fn: (r: { grants: RewardRepository; audit: AuditRepository }) => Promise<T>): Promise<T> {
      const run = async (): Promise<T> => {
        const snapshot = grants.slice();
        const carSnapshot = new Map([...cars].map(([k, v]) => [k, { ...v }]));
        const auditSnapshot = audits.slice();
        open++;
        try {
          return await fn({ grants: repo, audit: auditRepo });
        } catch (e) {
          grants = snapshot;
          cars.clear();
          for (const [k, v] of carSnapshot) cars.set(k, v);
          audits = auditSnapshot;
          throw e;
        } finally {
          open--;
        }
      };
      const result = tail.then(run, run);
      tail = result.catch(() => undefined);
      return result;
    },
  };

  return {
    store,
    calls,
    faults,
    openTransactions: () => open,
    grants: () => grants.map(withExpiry),
    audits: () => audits,
    car: (id: string) => {
      const c = cars.get(id);
      return c ? { status: c.status, version: c.version } : undefined;
    },
    addUser: (id: string, state: { status?: string; deleted?: boolean } = {}) => void users.set(id, { status: state.status ?? 'active', deleted: state.deleted ?? false }),
    setUserStatus: (id: string, status: string) => {
      const u = users.get(id);
      if (u) u.status = status;
    },
    addCar: (id: string, ownerId: string, o: { status?: string; source?: string; deleted?: boolean } = {}) => void cars.set(id, { ownerId, status: o.status ?? 'pending', source: o.source ?? 'member', deleted: o.deleted ?? false, version: 1 }),
    setCarStatus: (id: string, status: string) => {
      const c = cars.get(id);
      if (c) c.status = status;
    },
    /** Fixture: a grant in any state (what a provider callback or time would have produced). */
    seed: (g: Partial<GrantRow> & { userId: string }): GrantRow => {
      const now = clock.now();
      const row: GrantRow = { id: uuid(), provider: 'fake', status: 'requested', ssvTransactionId: null, carId: null, createdAt: new Date(now), verifiedAt: null, consumedAt: null, expiresAt: new Date(now + 600_000), expired: false, ...g };
      grants.push(row);
      return withExpiry(row);
    },
  };
}

/**
 * The FAKE verifier. Its "evidence" is { grantId, userId, tx }: it verifies only evidence that names exactly the grant and the user
 * the server holds for the request, like a real provider receipt must. `calls` records how often it was consulted.
 */
export function makeFakeVerifier(opts: { provider?: string; throws?: boolean } = {}): RewardVerifier & { calls: number } {
  const v = {
    provider: opts.provider ?? 'fake',
    calls: 0,
    async verify(input: { grantId: string; userId: string; evidence: unknown }) {
      v.calls++;
      if (opts.throws) throw new Error('provider down');
      const e = input.evidence as { grantId?: unknown; userId?: unknown; tx?: unknown } | null;
      if (!e || typeof e !== 'object' || e.grantId !== input.grantId || e.userId !== input.userId || typeof e.tx !== 'string') return { ok: false as const };
      return { ok: true as const, transactionId: e.tx };
    },
  };
  return v;
}

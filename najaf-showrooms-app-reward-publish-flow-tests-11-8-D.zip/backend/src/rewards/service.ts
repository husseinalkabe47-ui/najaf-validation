// Rewarded-ad grants for member car ads (Phase 11.8, Step 1): the shared, provider-independent backend. No HTTP route, no frontend
// and no real ad provider use it yet; it is not wired into the running server, so nothing changes in production.
//
// The life of a grant (each rule is covered by tests, and the statements that enforce it are in repository.ts):
//   requestReward  an ACTIVE account opens a 'requested' grant (unbound to any ad, short-lived, a few at a time).
//   verifyReward   ONLY the verifier (the ad provider's own evidence, checked by server-side code) moves it to 'verified', storing the
//                  provider's transaction id (unique per provider: one receipt verifies one request). Nothing a client says counts.
//   consumeReward  the owner attaches a 'verified', unexpired grant to ONE of their own PENDING ads: a single compare-and-swap that
//                  also sets car_id (UNIQUE) and consumed_at. A consumed grant never changes again.
// Publishing still needs the administrator: moderation approves only an ad that has a consumed grant bound to it and its owner
// (member-cars/moderation.ts, unchanged); a reward alone never publishes anything.
//
// Uniform answers: a grant that does not exist, belongs to someone else, or has a malformed id is the same 404 (no existence oracle).
// Lock order is always grant, then ad, so two consumptions cannot deadlock; a taken receipt or a taken ad surfaces as the database's
// unique violation, which rolls the transaction back and is reported as 'replayed' / 'invalid_state'.
import { AuthzError } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { DbError } from '../errors.ts';
import { parseCarId } from '../member-cars/validation.ts';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import { PROVIDER_MAX_LENGTH, TRANSACTION_ID_MAX_LENGTH } from './provider.ts';
import type { RewardVerifier } from './provider.ts';
import type { GrantRow, RewardStatus, RewardStore } from './repository.ts';

/** PROPOSED (needs approval): how long a request lives (it also bounds a verified grant that was never consumed) and how many may be open. */
export const REWARD_POLICY = Object.freeze({ ttlSeconds: 30 * 60, maxOpen: 3 });

export type RewardErrorCode = 'not_found' | 'invalid_state' | 'expired' | 'rate_limited' | 'unavailable' | 'verification_failed' | 'replayed';
const MESSAGES: Record<RewardErrorCode, string> = {
  not_found: 'The reward or the ad was not found',
  invalid_state: 'The reward or the ad is not in a state that allows this',
  expired: 'The reward request has expired',
  rate_limited: 'Too many reward requests are open',
  unavailable: 'Reward verification is not available',
  verification_failed: 'The reward could not be verified',
  replayed: 'This reward evidence was already used',
};
export class RewardError extends Error {
  readonly code: RewardErrorCode;
  constructor(code: RewardErrorCode) {
    super(MESSAGES[code]);
    this.name = 'RewardError';
    this.code = code;
  }
}

export interface RewardRequested {
  id: string;
  expiresAt: string;
}
export interface RewardVerified {
  id: string;
  status: RewardStatus;
}
export interface RewardConsumed {
  id: string;
  carId: string;
  status: 'consumed';
  /** The ad is public (active) as a result of this reward (a regular member) or already was. false = it waits for administrator approval. */
  published: boolean;
}

export interface RewardApi {
  requestReward(actor: Actor | null): Promise<RewardRequested>;
  /** Called by provider-facing code (never by an end user's request): `evidence` is what the provider signed. */
  verifyReward(grantId: unknown, evidence: unknown): Promise<RewardVerified>;
  consumeReward(actor: Actor | null, grantId: unknown, carId: unknown): Promise<RewardConsumed>;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const parseGrantId = (raw: unknown): string | null => (typeof raw === 'string' && UUID.test(raw) ? raw.toLowerCase() : null);
const isUnique = (e: unknown, constraint: string): boolean => e instanceof DbError && e.kind === 'unique' && e.constraint === constraint;

export function createRewardService(deps: {
  store: RewardStore;
  verifier: RewardVerifier;
  logger?: Logger;
  policy?: Partial<{ ttlSeconds: number; maxOpen: number }>;
}): RewardApi {
  const { store, verifier } = deps;
  const logger = deps.logger ?? nullLogger;
  const ttlSeconds = deps.policy?.ttlSeconds ?? REWARD_POLICY.ttlSeconds;
  const maxOpen = deps.policy?.maxOpen ?? REWARD_POLICY.maxOpen;
  if (typeof verifier.provider !== 'string' || verifier.provider.length < 1 || verifier.provider.length > PROVIDER_MAX_LENGTH) throw new Error('the reward verifier needs a provider name of 1..40 characters');
  if (!Number.isInteger(ttlSeconds) || ttlSeconds < 1 || !Number.isInteger(maxOpen) || maxOpen < 1) throw new Error('invalid reward policy');

  async function requestReward(actor: Actor | null): Promise<RewardRequested> {
    if (!actor) throw new AuthzError('forbidden');
    // A verifier that can never verify: opening requests nobody can complete would only burn the user's open-request slots.
    if (verifier.configured === false) throw new RewardError('unavailable');
    const row = await store.transaction(async ({ grants }) => {
      if (!(await grants.lockActingUser(actor.id))) throw new AuthzError('forbidden');
      await grants.lockRequests(actor.id);
      if ((await grants.countOpen(actor.id)) >= maxOpen) throw new RewardError('rate_limited');
      return grants.insertRequest({ userId: actor.id, provider: verifier.provider, ttlSeconds });
    });
    logger.info({ event: 'reward.requested', userId: row.userId, grantId: row.id });
    return { id: row.id, expiresAt: row.expiresAt.toISOString() };
  }

  // The same evidence for a grant that is already past 'requested': success only if it is THE evidence that verified it.
  function alreadyVerified(g: GrantRow, transactionId: string): RewardVerified {
    if ((g.status === 'verified' || g.status === 'consumed') && g.ssvTransactionId === transactionId) return { id: g.id, status: g.status };
    throw new RewardError('invalid_state');
  }

  async function verifyReward(rawGrantId: unknown, evidence: unknown): Promise<RewardVerified> {
    const id = parseGrantId(rawGrantId);
    if (!id) throw new RewardError('not_found');
    if (verifier.configured === false) throw new RewardError('unavailable');
    const g = await store.grants.find(id);
    if (!g || g.provider !== verifier.provider) throw new RewardError('not_found');
    if (g.status === 'requested' && g.expired) throw new RewardError('expired');
    if (g.status === 'failed' || g.status === 'expired') throw new RewardError('invalid_state');

    // The provider's check runs OUTSIDE any transaction (it may be slow); the transition below re-checks everything under the row lock.
    let transactionId: string;
    try {
      const verdict = await verifier.verify({ grantId: g.id, userId: g.userId, evidence });
      if (!verdict || verdict.ok !== true || typeof verdict.transactionId !== 'string' || verdict.transactionId === '' || verdict.transactionId.length > TRANSACTION_ID_MAX_LENGTH) throw new Error('rejected');
      transactionId = verdict.transactionId;
    } catch {
      logger.warn({ event: 'reward.verification_failed', userId: g.userId, grantId: g.id });
      throw new RewardError('verification_failed');
    }
    if (g.status !== 'requested') return alreadyVerified(g, transactionId);

    let out: RewardVerified;
    try {
      out = await store.transaction(async ({ grants }) => {
        const cur = await grants.lock(id);
        if (!cur) throw new RewardError('not_found');
        if (cur.status !== 'requested') return alreadyVerified(cur, transactionId);
        if (cur.expired) throw new RewardError('expired');
        const holder = await grants.findByTransaction(verifier.provider, transactionId);
        if (holder && holder.id !== cur.id) throw new RewardError('replayed');
        const done = await grants.markVerified({ id: cur.id, userId: cur.userId, provider: cur.provider, transactionId });
        if (!done) throw new RewardError('invalid_state');
        return { id: done.id, status: done.status };
      });
    } catch (e) {
      if (isUnique(e, 'reward_ssv_uq')) throw new RewardError('replayed'); // another request took this receipt between the check and the write
      throw e;
    }
    logger.info({ event: 'reward.verified', grantId: id });
    return out;
  }

  async function consumeReward(actor: Actor | null, rawGrantId: unknown, rawCarId: unknown): Promise<RewardConsumed> {
    if (!actor) throw new AuthzError('forbidden');
    const grantId = parseGrantId(rawGrantId);
    const carId = parseCarId(rawCarId);
    if (!grantId || !carId) throw new RewardError('not_found');
    let out: RewardConsumed;
    try {
      out = await store.transaction(async ({ grants, audit }) => {
        if (!(await grants.lockActingUser(actor.id))) throw new AuthzError('forbidden');
        const g = await grants.lock(grantId); // grant first, then the ad: always this order
        if (!g || g.userId !== actor.id) throw new RewardError('not_found');
        const car = await grants.lockOwnCar(carId, actor.id);
        if (!car) throw new RewardError('not_found');
        if (g.status === 'consumed') {
          if (g.carId === carId) return { id: g.id, carId, status: 'consumed' as const, published: car.status === 'active' }; // the same request again: nothing changes
          throw new RewardError('invalid_state');
        }
        if (g.status !== 'verified') throw new RewardError('invalid_state');
        if (g.expired) throw new RewardError('expired');
        if (car.status !== 'pending') throw new RewardError('invalid_state');
        if (await grants.carHasGrant(carId)) throw new RewardError('invalid_state');
        const done = await grants.consume({ id: g.id, userId: actor.id, carId });
        if (!done) throw new RewardError('invalid_state');
        // A regular member's ad goes public in the same transaction (any failure below rolls the consumption back too).
        let published = false;
        if (actor.role === 'member') {
          const version = await grants.publishOwnCar({ carId, userId: actor.id });
          if (version === null) throw new RewardError('invalid_state');
          await audit.record({ action: 'member_car.reward_publish', actorUserId: actor.id, actorRole: 'user', entityType: 'car', entityId: carId, afterData: { version } });
          published = true;
        }
        return { id: done.id, carId, status: 'consumed' as const, published };
      });
    } catch (e) {
      if (isUnique(e, 'reward_grants_car_id_key')) throw new RewardError('invalid_state'); // the ad got a grant first
      throw e;
    }
    logger.info({ event: 'reward.consumed', userId: actor.id, grantId, carId });
    return out;
  }

  return { requestReward, verifyReward, consumeReward };
}

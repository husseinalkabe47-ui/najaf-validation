// HTTP contract for a member's rewarded-ad grants (Phase 11.8-B). Thin: every decision lives in rewards/service.ts. Imports Fastify
// TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   POST /v1/me/rewards                  Bearer, no body                 -> 201 {reward: {id, expiresAt}}
//   POST /v1/me/rewards/:id/consume      Bearer, JSON {carId}            -> 200 {reward: {id, carId, status:'consumed', published}}
//
// What is deliberately NOT here: any route that marks a grant verified or accepts a provider transaction id / receipt. Verification
// belongs to server-side provider code (a later step) and this file is typed with `Pick<RewardApi, 'requestReward' | 'consumeReward'>`,
// so it cannot even call `verifyReward`. The consume body accepts ONE field, `carId`: a client cannot send a user id, a status, a
// "success" flag or a transaction id (any other field is a 400). The owner is the verified access token's account, never a request field.
// Publication is the service's decision (a regular member's ad goes public in the consuming transaction), never the client's.
//
// Errors: 401 no/invalid token; 403 an account that may not act; 404 unknown / malformed / someone else's grant or ad (uniform);
// 400 invalid body (field names and codes only); 409 invalid_state / expired / replayed; 415 non-JSON body; 429 too many open
// requests or too many HTTP requests; 503 reward verification is not available (the production default until a provider exists).
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import type { FieldError } from '../auth/validation.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { RewardError } from './service.ts';
import type { RewardApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same in-process limiter as the other routes). */
export const REWARD_RATE_LIMITS = {
  request: { limit: 10, windowSeconds: 60 * 60 },
  consume: { limit: 30, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type RewardRateLimitedRoute = keyof typeof REWARD_RATE_LIMITS;

/** The only methods the HTTP layer may use. `verifyReward` is intentionally absent. */
export type RewardRoutesApi = Pick<RewardApi, 'requestReward' | 'consumeReward'>;

type BodyField = FieldError;
class RewardBodyError extends Error {
  readonly fields: BodyField[];
  constructor(fields: BodyField[]) {
    super('Invalid request body');
    this.name = 'RewardBodyError';
    this.fields = fields;
  }
}

const STATUS: Record<RewardError['code'], number> = {
  not_found: 404,
  invalid_state: 409,
  expired: 409,
  replayed: 409,
  verification_failed: 409,
  rate_limited: 429,
  unavailable: 503,
};

/** Maps every error this layer may see to the project's HTTP contract; undefined = not ours (the global handler maps it). */
export function toRewardHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof RewardBodyError) return { status: 400, code: 'validation_failed', message: e.message, fields: e.fields };
  if (e instanceof RewardError) return { status: STATUS[e.code], code: e.code, message: e.message };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rewardRateLimitHook(limiter: RateLimiter, route: RewardRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`rewards.${route}:${request.ip}`, REWARD_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'rewards.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** The request route carries nothing: whatever a client sends cannot influence the grant. */
function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  throw new RewardBodyError([{ field: 'body', code: 'invalid_type' }]);
}

/** Exactly `{carId: string}`. Anything else (including status, userId, transactionId, success flags) is refused, never ignored. */
function parseConsumeBody(body: unknown): string {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) throw new RewardBodyError([{ field: 'body', code: 'invalid_type' }]);
  const record = body as Record<string, unknown>;
  const problems: BodyField[] = [];
  for (const key of Object.keys(record)) if (key !== 'carId') problems.push({ field: key, code: 'unknown_field' });
  if (!('carId' in record) || record['carId'] === undefined) problems.push({ field: 'carId', code: 'required' });
  else if (typeof record['carId'] !== 'string') problems.push({ field: 'carId', code: 'invalid_type' });
  if (problems.length > 0) throw new RewardBodyError(problems);
  return record['carId'] as string;
}

export function registerRewardRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; rewards: RewardRoutesApi; rateLimiter?: RateLimiter }): void {
  const { auth, rewards, rateLimiter } = deps;
  const limited = (route: RewardRateLimitedRoute): Hook[] => (rateLimiter ? [rewardRateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toRewardHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling": the verified access token, re-read from the database, then the account-state rules.
  // No/invalid token -> 401. An authenticated account that may not act (pending dealer, suspended) -> null actor -> 403 from the service.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };
  const idParam = (request: FastifyRequest): unknown => (request.params as Record<string, unknown> | undefined)?.['id'];

  app.post('/v1/me/rewards', { bodyLimit: 1024, onRequest: limited('request') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      assertNoBody(request.body);
      const reward = await rewards.requestReward(actor);
      return reply.code(201).send({ reward });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/me/rewards/:id/consume', { bodyLimit: 1024, onRequest: [...limited('consume'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const carId = parseConsumeBody(request.body);
      const reward = await rewards.consumeReward(actor, idParam(request), carId);
      return reply.code(200).send({ reward });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

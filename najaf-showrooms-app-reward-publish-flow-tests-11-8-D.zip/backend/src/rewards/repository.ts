// Reward grants (Phase 11.8, Step 1): the ONLY code that writes reward_grants. Moderation (member-cars/moderation.ts) still only reads
// it, through its own statement, and still requires a 'consumed' grant bound to the ad and its owner. The schema is unchanged
// (database/migrations/0009_rewards.sql); every rule below is enforced by a statement, not by a comment:
//  - requested  -> verified   only by markVerified: same user, same provider, still 'requested', not expired, not yet bound to a car;
//                             the provider's transaction id is stored and is unique per provider (reward_ssv_uq).
//  - verified   -> consumed   only by consume: same user, still 'verified', not expired, car_id still NULL; it sets car_id (UNIQUE,
//                             one grant per ad) and consumed_at in the same statement. A consumed grant is never touched again.
//  - A failed or expired grant never holds a car_id, so the ad can request a new reward.
// Expiry is judged by the DATABASE clock (now()), the same one that stamps created_at/verified_at/consumed_at.
// The ONE write outside reward_grants is publishOwnCar: a regular member's own PENDING ad becomes 'active' in the same transaction that
// consumed its grant (see service.ts), so a reward is consumed if and only if the ad it paid for is public.
// Every method must run inside RewardStore.transaction (the row locks last until its end).
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';
import type { Db, Tx } from '../db.ts';

export type RewardStatus = 'requested' | 'verified' | 'consumed' | 'expired' | 'failed';

export interface GrantRow {
  id: string;
  userId: string;
  provider: string;
  status: RewardStatus;
  ssvTransactionId: string | null;
  carId: string | null;
  createdAt: Date;
  verifiedAt: Date | null;
  consumedAt: Date | null;
  expiresAt: Date;
  /** expires_at <= now() by the database clock, at the moment of the read. */
  expired: boolean;
}

/** The ad a reward may be attached to: a live member ad of this user. */
export interface CarForReward {
  id: string;
  status: string;
}

export interface RewardRepository {
  /** Re-checks INSIDE the transaction that the acting account is active and not deleted, and SHARE-locks it. */
  lockActingUser(userId: string): Promise<boolean>;
  /** Serialises the reward requests of one user (a transaction-scoped advisory lock), so the open-request limit cannot be raced. */
  lockRequests(userId: string): Promise<void>;
  /** Requests of this user that are 'requested' and not yet expired. */
  countOpen(userId: string): Promise<number>;
  insertRequest(input: { userId: string; provider: string; ttlSeconds: number }): Promise<GrantRow>;
  /** The grant, or null. Autocommit when called on the store; locked FOR UPDATE when called through `lock`. */
  find(id: string): Promise<GrantRow | null>;
  lock(id: string): Promise<GrantRow | null>;
  /** The grant that holds this provider transaction id, or null. */
  findByTransaction(provider: string, transactionId: string): Promise<GrantRow | null>;
  /** requested -> verified (CAS). null = the grant was not in the expected state. A taken transaction id throws DbError 'unique'. */
  markVerified(input: { id: string; userId: string; provider: string; transactionId: string }): Promise<GrantRow | null>;
  /** The user's own live member ad, locked FOR UPDATE (so moderation cannot change it meanwhile); null for anything else. */
  lockOwnCar(carId: string, userId: string): Promise<CarForReward | null>;
  /** A grant already holds this ad. */
  carHasGrant(carId: string): Promise<boolean>;
  /** verified -> consumed, binding the ad (CAS). null = the grant was not in the expected state. */
  consume(input: { id: string; userId: string; carId: string }): Promise<GrantRow | null>;
  /**
   * pending -> active for the owner's own live MEMBER ad (CAS on the status and the owner; the stale review reasons are cleared, as an
   * approval does). Returns the new version, or null when the ad was not a pending member ad of this user.
   */
  publishOwnCar(input: { carId: string; userId: string }): Promise<number | null>;
}

export interface RewardStore {
  /** Autocommit reads. */
  grants: RewardRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { grants: RewardRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

const COLUMNS = `id, user_id, provider, status, ssv_transaction_id, car_id, created_at, verified_at, consumed_at, expires_at, (expires_at <= now()) AS expired`;

interface SqlRow {
  id: string;
  user_id: string;
  provider: string;
  status: RewardStatus;
  ssv_transaction_id: string | null;
  car_id: string | null;
  created_at: Date;
  verified_at: Date | null;
  consumed_at: Date | null;
  expires_at: Date;
  expired: boolean;
}
const toRow = (r: SqlRow): GrantRow => ({
  id: String(r.id),
  userId: String(r.user_id),
  provider: r.provider,
  status: r.status,
  ssvTransactionId: r.ssv_transaction_id,
  carId: r.car_id === null ? null : String(r.car_id),
  createdAt: r.created_at,
  verifiedAt: r.verified_at,
  consumedAt: r.consumed_at,
  expiresAt: r.expires_at,
  expired: r.expired === true,
});

type Sql = { text: string; values: unknown[] };

export function buildCountOpen(userId: string): Sql {
  return { text: `SELECT count(*)::int AS n FROM reward_grants WHERE user_id = $1::bigint AND status = 'requested' AND expires_at > now()`, values: [userId] };
}
export function buildInsertRequest(i: { userId: string; provider: string; ttlSeconds: number }): Sql {
  // status, car_id and every verification field are NOT parameters: a request is always a fresh, unbound 'requested' row.
  return {
    text: `INSERT INTO reward_grants (user_id, provider, status, expires_at)
           VALUES ($1::bigint, $2::varchar, 'requested', now() + make_interval(secs => $3::int))
        RETURNING ${COLUMNS}`,
    values: [i.userId, i.provider, i.ttlSeconds],
  };
}
export function buildFind(id: string, lock: boolean): Sql {
  return { text: `SELECT ${COLUMNS} FROM reward_grants WHERE id = $1::uuid${lock ? ' FOR UPDATE' : ''}`, values: [id] };
}
export function buildFindByTransaction(provider: string, transactionId: string): Sql {
  return { text: `SELECT ${COLUMNS} FROM reward_grants WHERE provider = $1::varchar AND ssv_transaction_id = $2::text`, values: [provider, transactionId] };
}
export function buildMarkVerified(i: { id: string; userId: string; provider: string; transactionId: string }): Sql {
  return {
    text: `UPDATE reward_grants SET status = 'verified', ssv_transaction_id = $4::text, verified_at = now()
            WHERE id = $1::uuid AND user_id = $2::bigint AND provider = $3::varchar
              AND status = 'requested' AND car_id IS NULL AND expires_at > now()
        RETURNING ${COLUMNS}`,
    values: [i.id, i.userId, i.provider, i.transactionId],
  };
}
export function buildLockOwnCar(carId: string, userId: string): Sql {
  return {
    text: `SELECT id, status FROM cars WHERE id = $1::bigint AND owner_id = $2::bigint AND source_type = 'member' AND deleted_at IS NULL FOR UPDATE`,
    values: [carId, userId],
  };
}
export function buildCarHasGrant(carId: string): Sql {
  return { text: `SELECT 1 FROM reward_grants WHERE car_id = $1::bigint LIMIT 1`, values: [carId] };
}
export function buildConsume(i: { id: string; userId: string; carId: string }): Sql {
  return {
    text: `UPDATE reward_grants SET status = 'consumed', car_id = $3::bigint, consumed_at = now()
            WHERE id = $1::uuid AND user_id = $2::bigint
              AND status = 'verified' AND car_id IS NULL AND expires_at > now()
        RETURNING ${COLUMNS}`,
    values: [i.id, i.userId, i.carId],
  };
}

export function buildPublishOwnCar(i: { carId: string; userId: string }): Sql {
  // The new status is a literal; nothing a client sends reaches this statement. The review stamp is left alone: no administrator
  // reviewed this ad, and the audit row written with it says it was published by a reward.
  return {
    text: `UPDATE cars SET status = 'active', rejection_reason = NULL, suspension_reason = NULL
            WHERE id = $1::bigint AND owner_id = $2::bigint AND source_type = 'member' AND deleted_at IS NULL AND status = 'pending'
        RETURNING version`,
    values: [i.carId, i.userId],
  };
}

export function createPgRewardRepository(q: Tx): RewardRepository {
  const one = async (s: Sql): Promise<GrantRow | null> => {
    const r = (await q.query<SqlRow>(s.text, s.values)).rows[0];
    return r ? toRow(r) : null;
  };
  return {
    async lockActingUser(userId) {
      const r = await q.query(`SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`, [userId]);
      return r.rows.length === 1;
    },
    async lockRequests(userId) {
      await q.query(`SELECT pg_advisory_xact_lock(hashtextextended($1, 0))`, [`najaf.reward:${userId}`]);
    },
    async countOpen(userId) {
      const s = buildCountOpen(userId);
      return Number((await q.query<{ n: number }>(s.text, s.values)).rows[0]?.n ?? 0);
    },
    async insertRequest(i) {
      const row = await one(buildInsertRequest(i));
      if (!row) throw new Error('reward request was not stored');
      return row;
    },
    find: (id) => one(buildFind(id, false)),
    lock: (id) => one(buildFind(id, true)),
    findByTransaction: (provider, transactionId) => one(buildFindByTransaction(provider, transactionId)),
    markVerified: (i) => one(buildMarkVerified(i)),
    async lockOwnCar(carId, userId) {
      const s = buildLockOwnCar(carId, userId);
      const r = (await q.query<{ id: string; status: string }>(s.text, s.values)).rows[0];
      return r ? { id: String(r.id), status: r.status } : null;
    },
    async carHasGrant(carId) {
      const s = buildCarHasGrant(carId);
      return (await q.query(s.text, s.values)).rows.length > 0;
    },
    consume: (i) => one(buildConsume(i)),
    async publishOwnCar(i) {
      const s = buildPublishOwnCar(i);
      const r = (await q.query<{ version: number }>(s.text, s.values)).rows[0];
      return r ? Number(r.version) : null;
    },
  };
}

export function createPgRewardStore(db: Db): RewardStore {
  return {
    grants: createPgRewardRepository(db),
    transaction: (fn) => db.tx((t) => fn({ grants: createPgRewardRepository(t), audit: createPgAuditRepository(t) })),
  };
}

// The AdMob server-side-verification callback (Phase 11.8-C). Google's servers call it; it is NOT a member endpoint.
//
//   GET /v1/rewards/admob/ssv?ad_network=..&ad_unit=..&custom_data=<grant id>&reward_amount=..&reward_item=..&timestamp=..
//                             &transaction_id=..&user_id=<user id>&signature=..&key_id=..
//        -> 200 {status:'ok'} | 400 {error:{code:'rejected'}} | 503 {error:{code:'unavailable'}}
//
// No bearer token (Google has none): trust comes ONLY from the ECDSA signature and the checks in rewards/admob.ts. The raw query string
// is passed on untouched (it is what was signed). This route can only move a grant to 'verified'; it never consumes one and never
// publishes an ad. It is rate limited per address (generous: Google's callers share addresses). Imports Fastify TYPES only.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import type { AdmobCallbackApi } from './admob.ts';

export const ADMOB_CALLBACK_RATE_LIMIT: RateRule = { limit: 600, windowSeconds: 10 * 60 };

type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

export function registerAdmobCallbackRoutes(app: FastifyInstance, deps: { callbacks: AdmobCallbackApi; rateLimiter?: RateLimiter }): void {
  const { callbacks, rateLimiter } = deps;
  const onRequest = rateLimiter
    ? [
        async (request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> => {
          const decision = rateLimiter.consume(`rewards.admob_ssv:${request.ip}`, ADMOB_CALLBACK_RATE_LIMIT);
          if (decision.allowed) return undefined;
          request.log.warn({ event: 'rewards.rate_limited', route: 'admob_ssv' });
          reply.header('retry-after', String(decision.retryAfterSeconds));
          return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
        },
      ]
    : [];

  app.get('/v1/rewards/admob/ssv', { onRequest }, async (request, reply) => {
    const url = request.url;
    const at = url.indexOf('?');
    const raw = at < 0 ? '' : url.slice(at + 1);
    const out = await callbacks.handle(raw);
    const r = reply as unknown as Reply;
    if (out.status === 200) return r.code(200).send({ status: 'ok' });
    return r.code(out.status).send({ error: { code: out.code, message: out.status === 400 ? 'The callback was not accepted' : 'Verification is temporarily unavailable', requestId: request.id } });
  });
}

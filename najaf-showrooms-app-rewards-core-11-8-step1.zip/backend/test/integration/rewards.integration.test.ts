// Phase 11.8, Step 1 against a real PostgreSQL 16 (migrations 0001-0013 applied), through the least-privilege application role.
// Runs in CI only (needs DATABASE_URL and ADMIN_DATABASE_URL; skipped visibly otherwise). Proves what the in-memory tests cannot: the SQL
// of rewards/repository.ts is accepted (placeholder types, privileges on reward_grants), the compare-and-swaps and the two unique
// indexes hold under real concurrency, expiry follows the DATABASE clock, the reward lock and moderation's lock on an ad exclude each
// other, and a grant consumed here is exactly what the moderation reward gate needs (approve passes; without it, 409 reward_required).
// The verifier is the FAKE one from test/helpers (never part of src). Fixtures use the admin handle and are removed afterwards.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { createModerationService, createPgModerationStore, ModerationError } from '../../src/member-cars/moderation.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import { createPgRewardRepository, createPgRewardStore } from '../../src/rewards/repository.ts';
import { RewardError, createRewardService } from '../../src/rewards/service.ts';
import type { RewardErrorCode } from '../../src/rewards/service.ts';
import { makeFakeVerifier } from '../helpers/fake-rewards.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';
import { makeGate, waitForLockWaiters } from '../helpers/pg-race.ts';

const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };
const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const isReward = (code: RewardErrorCode) => (e: unknown) => e instanceof RewardError && e.code === code;

describe('rewards on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  const verifier = makeFakeVerifier();
  let svc: ReturnType<typeof createRewardService>;
  let svc2: ReturnType<typeof createRewardService>;
  let cars: ReturnType<typeof createMemberCarService>;
  let mod: ReturnType<typeof createModerationService>;
  let adm: Actor;

  const newUser = async (role: 'user' | 'admin' = 'user'): Promise<Actor> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return { id, role: role === 'admin' ? 'admin' : 'member' };
  };
  const pendingAd = async (owner: Actor) => (await cars.create(owner, VALID)).id;
  const grant = async (id: string) => (await admin.query<Record<string, unknown>>('SELECT status, car_id, ssv_transaction_id, verified_at, consumed_at, provider, user_id, expires_at, created_at FROM reward_grants WHERE id = $1::uuid', [id])).rows[0]!;
  const evidence = (id: string, userId: string, tx: string) => ({ grantId: id, userId, tx });
  /** request + verify (fake provider evidence), returns the grant id */
  async function verifiedFor(u: Actor, tx = `it-tx-${randomInt(0, 1e9)}-${Math.random()}`): Promise<string> {
    const r = await svc.requestReward(u);
    await svc.verifyReward(r.id, evidence(r.id, u.id, tx));
    return r.id;
  }

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    svc = createRewardService({ store: createPgRewardStore(app), verifier });
    svc2 = createRewardService({ store: createPgRewardStore(app2), verifier });
    cars = createMemberCarService({ store: createPgMemberCarStore(app) });
    mod = createModerationService({ store: createPgModerationStore(app) });
    adm = await newUser('admin');
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM reward_grants WHERE user_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('the whole life through the application role: request -> verify -> consume; the grant is what the moderation gate needs, and approve then publishes', async () => {
    const u = await newUser();
    const ad = await pendingAd(u);
    const other = await pendingAd(u);

    const r = await svc.requestReward(u);
    let g = await grant(r.id);
    assert.deepEqual([g.status, g.car_id, g.ssv_transaction_id, g.verified_at, g.consumed_at, g.provider, String(g.user_id)], ['requested', null, null, null, null, 'fake', u.id]);
    assert.equal(Math.round(((g.expires_at as Date).getTime() - (g.created_at as Date).getTime()) / 1000), 30 * 60, 'the lifetime is stamped by the database clock');

    assert.deepEqual(await svc.verifyReward(r.id, evidence(r.id, u.id, `life-${r.id}`)), { id: r.id, status: 'verified' });
    g = await grant(r.id);
    assert.deepEqual([g.status, g.ssv_transaction_id, g.car_id], ['verified', `life-${r.id}`, null]);
    assert.ok(g.verified_at instanceof Date);

    await assert.rejects(mod.act(adm, 'approve', ad, { version: 1 }), (e: unknown) => e instanceof ModerationError && e.code === 'reward_required', 'verified but not consumed: still not publishable');

    assert.deepEqual(await svc.consumeReward(u, r.id, ad), { id: r.id, carId: ad, status: 'consumed' });
    g = await grant(r.id);
    assert.deepEqual([g.status, String(g.car_id)], ['consumed', ad]);
    assert.ok(g.consumed_at instanceof Date);

    await assert.rejects(mod.act(adm, 'approve', other, { version: 1 }), (e: unknown) => e instanceof ModerationError && e.code === 'reward_required', 'a reward is bound to ONE ad');
    const approved = await mod.act(adm, 'approve', ad, { version: 1 });
    assert.equal(approved.status, 'active', 'administrator approval is still what publishes');
  });

  it('request limits: at most maxOpen open per account, expired ones do not count; concurrent requests from two connections cannot exceed it', async () => {
    const u = await newUser();
    const a = createRewardService({ store: createPgRewardStore(app), verifier, policy: { maxOpen: 2 } });
    const b = createRewardService({ store: createPgRewardStore(app2), verifier, policy: { maxOpen: 2 } });
    const results = await Promise.allSettled([a.requestReward(u), b.requestReward(u), a.requestReward(u), b.requestReward(u), a.requestReward(u), b.requestReward(u)]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 2);
    assert.ok(results.filter((x) => x.status === 'rejected').every((x) => isReward('rate_limited')((x as PromiseRejectedResult).reason)));
    assert.equal((await admin.query('SELECT 1 FROM reward_grants WHERE user_id = $1::bigint', [u.id])).rows.length, 2);
    await admin.query(`UPDATE reward_grants SET created_at = now() - interval '2 hours', expires_at = now() - interval '1 hour' WHERE user_id = $1::bigint`, [u.id]);
    await a.requestReward(u); // the two expired ones no longer count
  });

  it('a guest, a suspended account and an account without a user row are refused; nothing is stored', async () => {
    const u = await newUser();
    await assert.rejects(svc.requestReward(null), (e: unknown) => e instanceof AuthzError && e.code === 'forbidden');
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1::bigint`, [u.id]);
    await assert.rejects(svc.requestReward(u), (e: unknown) => e instanceof AuthzError && e.code === 'forbidden');
    await assert.rejects(svc.requestReward({ id: '999999999999', role: 'member' }), (e: unknown) => e instanceof AuthzError && e.code === 'forbidden');
    assert.equal((await admin.query('SELECT 1 FROM reward_grants WHERE user_id = $1::bigint', [u.id])).rows.length, 0);
  });

  it('verification: evidence for another request, user or nothing is refused; an expired request cannot be verified by the database clock', async () => {
    const u = await newUser();
    const v = await newUser();
    const r = await svc.requestReward(u);
    const rv = await svc.requestReward(v);
    for (const e of [undefined, {}, { verified: true }, evidence(rv.id, u.id, 'x'), evidence(r.id, v.id, 'x')]) await assert.rejects(svc.verifyReward(r.id, e), isReward('verification_failed'));
    assert.equal((await grant(r.id)).status, 'requested');
    await admin.query(`UPDATE reward_grants SET created_at = now() - interval '2 hours', expires_at = now() - interval '1 hour' WHERE id = $1::uuid`, [r.id]);
    await assert.rejects(svc.verifyReward(r.id, evidence(r.id, u.id, 'late')), isReward('expired'));
    assert.equal((await grant(r.id)).ssv_transaction_id, null);
    await assert.rejects(svc.verifyReward('not-a-uuid', {}), isReward('not_found'));
  });

  it('one receipt verifies one request: the same transaction id for another request is replayed; repeating the same evidence is idempotent', async () => {
    const u = await newUser();
    const v = await newUser();
    const a = await svc.requestReward(u);
    const b = await svc.requestReward(v);
    await svc.verifyReward(a.id, evidence(a.id, u.id, `once-${a.id}`));
    await assert.rejects(svc.verifyReward(b.id, evidence(b.id, v.id, `once-${a.id}`)), isReward('replayed'));
    assert.equal((await grant(b.id)).status, 'requested');
    const stamp = (await grant(a.id)).verified_at as Date;
    assert.deepEqual(await svc.verifyReward(a.id, evidence(a.id, u.id, `once-${a.id}`)), { id: a.id, status: 'verified' });
    assert.equal(((await grant(a.id)).verified_at as Date).getTime(), stamp.getTime());
    await assert.rejects(svc.verifyReward(a.id, evidence(a.id, u.id, 'another-receipt')), isReward('invalid_state'));
  });

  it('two requests racing for one receipt on two connections: the unique index lets exactly one win', async () => {
    const u = await newUser();
    const v = await newUser();
    const a = await svc.requestReward(u);
    const b = await svc.requestReward(v);
    const tx = `race-${a.id}`;
    const results = await Promise.allSettled([svc.verifyReward(a.id, evidence(a.id, u.id, tx)), svc2.verifyReward(b.id, evidence(b.id, v.id, tx))]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.ok(results.some((x) => x.status === 'rejected' && isReward('replayed')((x as PromiseRejectedResult).reason)));
    const statuses = [(await grant(a.id)).status, (await grant(b.id)).status].sort();
    assert.deepEqual(statuses, ['requested', 'verified']);
  });

  it('the database itself names the two unique indexes (the constraint names the service maps)', async () => {
    const u = await newUser();
    const v = await newUser();
    const ad = await pendingAd(u);
    const a = await svc.requestReward(u);
    const b = await svc.requestReward(v);
    const repo = <T>(fn: (r: ReturnType<typeof createPgRewardRepository>) => Promise<T>) => app.tx((t) => fn(createPgRewardRepository(t)));
    await repo((r) => r.markVerified({ id: a.id, userId: u.id, provider: 'fake', transactionId: `idx-${a.id}` }));
    await assert.rejects(repo((r) => r.markVerified({ id: b.id, userId: v.id, provider: 'fake', transactionId: `idx-${a.id}` })), (e: unknown) => e instanceof DbError && e.kind === 'unique' && e.constraint === 'reward_ssv_uq');
    await repo((r) => r.consume({ id: a.id, userId: u.id, carId: ad }));
    const c = await svc.requestReward(u);
    await repo((r) => r.markVerified({ id: c.id, userId: u.id, provider: 'fake', transactionId: `idx-${c.id}` }));
    await assert.rejects(repo((r) => r.consume({ id: c.id, userId: u.id, carId: ad })), (e: unknown) => e instanceof DbError && e.kind === 'unique' && e.constraint === 'reward_grants_car_id_key');
    assert.equal((await grant(c.id)).status, 'verified', 'the failed statement rolled back');
  });

  it('consume: owner only, pending ad only, one ad per grant and one grant per ad; the same request again is idempotent', async () => {
    const u = await newUser();
    const v = await newUser();
    const mine = await pendingAd(u);
    const mine2 = await pendingAd(u);
    const theirs = await pendingAd(v);
    const g = await verifiedFor(u);

    await assert.rejects(svc.consumeReward(v, g, theirs), isReward('not_found'), "another account's grant");
    await assert.rejects(svc.consumeReward(u, g, theirs), isReward('not_found'), "another account's ad");
    await assert.rejects(svc.consumeReward(u, g, '999999999999'), isReward('not_found'));
    await assert.rejects(svc.consumeReward(u, 'not-a-uuid', mine), isReward('not_found'));
    await assert.rejects(svc.consumeReward(null, g, mine), (e: unknown) => e instanceof AuthzError && e.code === 'forbidden');

    await admin.query(`UPDATE cars SET status = 'active' WHERE id = $1::bigint`, [mine2]);
    await assert.rejects(svc.consumeReward(u, g, mine2), isReward('invalid_state'), 'an ad that is not pending');
    const deleted = await pendingAd(u);
    await admin.query(`UPDATE cars SET deleted_at = now() WHERE id = $1::bigint`, [deleted]);
    await assert.rejects(svc.consumeReward(u, g, deleted), isReward('not_found'), 'a deleted ad');
    assert.equal((await grant(g)).status, 'verified');

    await svc.consumeReward(u, g, mine);
    const stamp = (await grant(g)).consumed_at as Date;
    assert.deepEqual(await svc.consumeReward(u, g, mine), { id: g, carId: mine, status: 'consumed' });
    assert.equal(((await grant(g)).consumed_at as Date).getTime(), stamp.getTime());
    const g2 = await verifiedFor(u);
    await assert.rejects(svc.consumeReward(u, g2, mine), isReward('invalid_state'), 'the ad already has a grant');
    await assert.rejects(svc.consumeReward(u, g, mine2), isReward('invalid_state'), 'the grant is already used');
    const requested = await svc.requestReward(u);
    await assert.rejects(svc.consumeReward(u, requested.id, theirs), isReward('not_found'));
  });

  it('an expired grant, a requested one and a failed one cannot be consumed (the database clock decides expiry)', async () => {
    const u = await newUser();
    const ad = await pendingAd(u);
    const requested = await svc.requestReward(u);
    await assert.rejects(svc.consumeReward(u, requested.id, ad), isReward('invalid_state'));
    const failed = await verifiedFor(u);
    await admin.query(`UPDATE reward_grants SET status = 'failed', verified_at = NULL, ssv_transaction_id = NULL WHERE id = $1::uuid`, [failed]);
    await assert.rejects(svc.consumeReward(u, failed, ad), isReward('invalid_state'));
    const old = await verifiedFor(u);
    await admin.query(`UPDATE reward_grants SET created_at = now() - interval '2 hours', expires_at = now() - interval '1 hour' WHERE id = $1::uuid`, [old]);
    await assert.rejects(svc.consumeReward(u, old, ad), isReward('expired'));
    const row = await grant(old);
    assert.deepEqual([row.status, row.car_id], ['verified', null]);
  });

  it('two consumptions of one grant for two ads, on two connections: exactly one succeeds', async () => {
    const u = await newUser();
    const a = await pendingAd(u);
    const b = await pendingAd(u);
    const g = await verifiedFor(u);
    const results = await Promise.allSettled([svc.consumeReward(u, g, a), svc2.consumeReward(u, g, b)]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.ok(results.some((x) => x.status === 'rejected' && isReward('invalid_state')((x as PromiseRejectedResult).reason)));
    assert.equal((await admin.query('SELECT 1 FROM reward_grants WHERE id = $1::uuid AND car_id IS NOT NULL', [g])).rows.length, 1);
  });

  it('two grants for one ad, on two connections: exactly one succeeds and the ad holds exactly one grant', async () => {
    const u = await newUser();
    const ad = await pendingAd(u);
    const g1 = await verifiedFor(u);
    const g2 = await verifiedFor(u);
    const results = await Promise.allSettled([svc.consumeReward(u, g1, ad), svc2.consumeReward(u, g2, ad)]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.equal((await admin.query('SELECT 1 FROM reward_grants WHERE car_id = $1::bigint', [ad])).rows.length, 1);
  });

  it('the reward and moderation exclude each other on the ad: a reject that holds the ad lock is waited for, and the reward is then refused (the ad is no longer pending)', async () => {
    const u = await newUser();
    const ad = await pendingAd(u);
    const g = await verifiedFor(u);
    const held = makeGate();
    const holding = makeGate();
    // A transaction that has locked the ad (what moderation's reject does) and is still open.
    const blocker = app2.tx(async (t) => {
      await t.query(`SELECT id FROM cars WHERE id = $1::bigint FOR UPDATE`, [ad]);
      await t.query(`UPDATE cars SET status = 'rejected' WHERE id = $1::bigint`, [ad]);
      holding.release();
      await held.open;
    });
    await holding.open;
    const pendingConsume = svc.consumeReward(u, g, ad);
    await waitForLockWaiters(admin, 1);
    held.release();
    await blocker;
    await assert.rejects(pendingConsume, isReward('invalid_state'));
    const row = await grant(g);
    assert.deepEqual([row.status, row.car_id], ['verified', null]);
  });

  it('a delete of the ad row keeps a consumed grant but never lets it be consumed again', async () => {
    const u = await newUser();
    const ad = await pendingAd(u);
    const g = await verifiedFor(u);
    await svc.consumeReward(u, g, ad);
    await admin.query('DELETE FROM cars WHERE id = $1::bigint', [ad]);
    const row = await grant(g);
    assert.deepEqual([row.status, row.car_id], ['consumed', null]);
    const next = await pendingAd(u);
    await assert.rejects(svc.consumeReward(u, g, next), isReward('invalid_state'));
  });
});

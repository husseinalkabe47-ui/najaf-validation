// Phase 11.6.1: static guards for the storage module: nothing hardcoded, nothing logged, no new dependency, not wired to any route.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const STORAGE = readdirSync(join(ROOT, 'src', 'storage')).filter((f) => f.endsWith('.ts')).map((f) => `src/storage/${f}`);

describe('storage module guards', () => {
  it('hardcodes no endpoint, host, bucket or credential', () => {
    assert.deepEqual(STORAGE.sort(), ['src/storage/config.ts', 'src/storage/index.ts', 'src/storage/keys.ts', 'src/storage/memory.ts', 'src/storage/provider.ts', 'src/storage/s3.ts', 'src/storage/sigv4.ts']);
    for (const f of STORAGE) {
      const src = code(f);
      assert.ok(!/https?:\/\/[a-z0-9]/i.test(src), `${f}: a URL literal`);
      assert.ok(!/cloudflarestorage|amazonaws|r2\.dev/i.test(src), `${f}: a provider host`);
      assert.ok(!/\bAKIA[0-9A-Z]{12,}|['"][0-9a-f]{32,}['"]/.test(src.replace(/'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'/, '')), `${f}: a credential-like literal`);
      assert.ok(!/najaf-media|['"]auto['"]/.test(src), `${f}: a bucket or region default`);
    }
  });

  it('never logs, never sends an unsigned payload, never follows redirects, always has a timeout', () => {
    for (const f of STORAGE) assert.ok(!/console\.|\.log\(|\.warn\(|\.info\(|\.error\(/.test(code(f)), `${f} logs`);
    const s3 = code('src/storage/s3.ts');
    assert.ok(!/UNSIGNED-PAYLOAD/.test(s3 + code('src/storage/sigv4.ts')));
    assert.match(s3, /redirect: 'error'/);
    assert.match(s3, /signal: AbortSignal\.timeout\(timeoutMs\)/);
    // The secret reaches exactly one place: the signer.
    assert.equal((s3.match(/s3\.secretAccessKey/g) ?? []).length, 1);
    assert.match(s3, /secretAccessKey: s3\.secretAccessKey, region: s3\.region, service: 's3'/);
    // Errors are created without a cause (an underlying fetch error can contain the URL).
    assert.ok(!/cause/.test(s3));
  });

  it('every operation checks the key before any I/O', () => {
    const s3 = code('src/storage/s3.ts');
    for (const op of ['put', 'get', 'delete', 'exists']) assert.match(s3, new RegExp(`async ${op}\\(key[^)]*\\)[^{]*\\{\\s*pathOf\\(key\\);`), op);
    assert.match(s3, /const full = keyPrefix === '' \? assertSafeKey\(key\) : `\$\{keyPrefix\}\/\$\{assertSafeKey\(key\)\}`;/);
  });

  it('is used only by the startup wiring, the asset upload service (11.6.2) and the image processor (11.6.3)', () => {
    const walk = (dir: string): string[] => readdirSync(join(ROOT, dir), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(`${dir}/${e.name}`) : e.name.endsWith('.ts') ? [`${dir}/${e.name}`] : []));
    const importers = walk('src').filter((f) => !f.startsWith('src/storage/') && /from '\.{1,2}\/(\.\.\/)*storage\//.test(code(f)));
    assert.deepEqual(importers.sort(), ['src/assets/processing-service.ts', 'src/assets/service.ts', 'src/index.ts']);
  });

  it('the storage provider adds no dependency (node:crypto and the built-in fetch only); the one runtime dependency added since is the image codec (sharp, 11.6.3)', () => {
    const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8')) as { dependencies: Record<string, string>; devDependencies: Record<string, string> };
    assert.deepEqual(Object.keys(pkg.dependencies).sort(), ['argon2', 'fastify', 'node-pg-migrate', 'pg', 'sharp']);
    assert.equal(pkg.dependencies['sharp'], '>=0.33.5 <0.35.0');
    assert.deepEqual(Object.keys(pkg.devDependencies).sort(), ['@types/node', '@types/pg', 'typescript']);
    for (const f of STORAGE) for (const m of code(f).matchAll(/from '([^']+)'/g)) assert.ok(m[1]!.startsWith('./') || m[1]!.startsWith('node:'), `${f} imports ${m[1]}`);
  });
});

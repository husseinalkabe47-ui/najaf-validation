// Phase 11.6.3: static guards for image processing (SQL shape, where the native codec is used, what is never done).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { buildFindForProcessing, buildMarkReady, buildMarkRejected } from '../../src/assets/processing-repository.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const walk = (dir: string): string[] => readdirSync(join(ROOT, dir), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(`${dir}/${e.name}`) : e.name.endsWith('.ts') ? [`${dir}/${e.name}`] : []));

describe('image processing: SQL', () => {
  it('ready is a compare-and-swap on the pending original that fills exactly the columns the ready CHECK requires', () => {
    const s = buildMarkReady({ id: 'u', originalKey: 'incoming/car_image/x', mainKey: 'processed/car_image/x.webp', thumbKey: 'thumbs/car_image/x.webp', bytes: 9, width: 3, height: 2, sha256: 'a'.repeat(64) });
    assert.match(s.text, /SET status = 'ready', storage_key = \$3, thumb_key = \$4, mime = 'image\/webp', bytes = \$5, width = \$6, height = \$7, sha256 = \$8, ready_at = now\(\)\s+WHERE a\.id = \$1::uuid AND a\.status = 'pending' AND a\.storage_key = \$2/);
    assert.deepEqual(s.values, ['u', 'incoming/car_image/x', 'processed/car_image/x.webp', 'thumbs/car_image/x.webp', 9, 3, 2, 'a'.repeat(64)]);
    assert.ok(!/RETURNING[^`]*(storage_key|thumb_key|sha256|mime|owner_id)/.test(s.text), 'nothing internal is returned');
  });

  it('rejected is a compare-and-swap that keeps the original key and stores a reason code only', () => {
    const s = buildMarkRejected({ id: 'u', originalKey: 'incoming/car_image/x', reason: 'invalid_image' });
    assert.match(s.text, /SET status = 'rejected', reject_reason = \$3\s+WHERE a\.id = \$1::uuid AND a\.status = 'pending' AND a\.storage_key = \$2/);
    assert.ok(!/storage_key =\s*\$3|thumb_key/.test(s.text));
  });

  it('the asset is read by id, and by owner when the caller is an owner', () => {
    assert.match(buildFindForProcessing('u', '7').text, /WHERE a\.id = \$1::uuid AND a\.owner_id = \$2::bigint$/);
    assert.match(buildFindForProcessing('u', null).text, /WHERE a\.id = \$1::uuid$/);
  });
});

describe('image processing: sources', () => {
  it('sharp is imported only by the sharp codec, which only the startup wiring loads (dynamically, when storage is configured)', () => {
    const importers = walk('src').filter((f) => /from 'sharp'/.test(code(f)));
    assert.deepEqual(importers, ['src/assets/sharp-codec.ts']);
    const idx = walk('src').filter((f) => /sharp-codec\.ts'/.test(code(f)));
    assert.deepEqual(idx, ['src/index.ts']);
  });

  it('the sharp codec never keeps metadata, always limits input pixels, refuses warnings, decodes one page, applies orientation, times out', () => {
    const src = code('src/assets/sharp-codec.ts');
    assert.ok(!/keepMetadata|withMetadata|keepExif|withExif|keepIccProfile|withIccProfile|keepXmp|withXmp/.test(src));
    assert.equal((src.match(/limitInputPixels: opts\.maxInputPixels/g) ?? []).length, 3, 'every sharp() call is limited');
    assert.equal((src.match(/failOn: 'warning'/g) ?? []).length, 3);
    assert.match(src, /animated: false, pages: 1/);
    assert.match(src, /\.rotate\(\)/);
    assert.match(src, /\.timeout\(\{ seconds:/);
    assert.match(src, /withoutEnlargement: true/);
    assert.match(src, /sharp\.cache\(false\);/);
    assert.match(src, /if \(!m\.format \|\| !FORMATS\[m\.format\]\) throw new CodecError\('unsupported'\);/);
  });

  it('originals are never served: no route reads storage, and only the processor reads objects back', () => {
    const readers = walk('src').filter((f) => !f.startsWith('src/storage/') && /storage\.get\(/.test(code(f)));
    assert.deepEqual(readers, ['src/assets/processing-service.ts']);
    assert.ok(!/from '\.\.\/storage|storage\.\w+\(/.test(code('src/assets/routes.ts')), 'routes have no storage access');
  });

  it('processing logs never name a key; the processor never throws to its caller', () => {
    const src = code('src/assets/processing-service.ts');
    const logs = [...src.matchAll(/logger\?\.(?:info|warn)\(\{([^}]*)\}/g)].map((m) => m[1]!);
    assert.ok(logs.length >= 5);
    for (const l of logs) assert.ok(!/keys\.|storageKey|originalKey|mainKey|thumbKey|row\.storage/.test(l), l);
    assert.match(src, /return await gate\.run\(\(\) => run\(assetId, ownerId\)\);\s+\} catch \{\s+return \{ result: 'pending', asset: null, reason: 'unexpected' \};/);
  });
});

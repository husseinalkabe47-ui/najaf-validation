#!/usr/bin/env python3
"""فاحص ثابت لملفات اختبار SQL (لا يشغّل PostgreSQL). الاستعمال: lint_tests.py SCHEMA.sql sql_dir [migration0013.sql]"""
import re,sys,glob,os,collections
schema=open(sys.argv[1],encoding='utf-8').read(); sqldir=sys.argv[2]
extra=open(sys.argv[3],encoding='utf-8').read() if len(sys.argv)>3 else ''
S=re.sub(r'--[^\n]*','',schema)
def top_split(body):
    parts=[];d=0;cur='';sq=False
    for ch in body:
        if ch=="'": sq=not sq
        if not sq:
            if ch=='(': d+=1
            elif ch==')': d-=1
            elif ch==',' and d==0: parts.append(cur.strip()); cur=''; continue
        cur+=ch
    if cur.strip(): parts.append(cur.strip())
    return parts
tables={}
for m in re.finditer(r'CREATE TABLE (\w+)\s*\((.*?)\n\);',S,re.S):
    cols=set()
    for it in top_split(m.group(2)):
        f=it.split()[0]
        if f.upper() not in ('CONSTRAINT','UNIQUE','PRIMARY','CHECK'): cols.add(f)
    tables[m.group(1)]=cols
views={'public_cars','public_showrooms'}
cn=set(re.findall(r'CONSTRAINT\s+(\w+)\s+(?:CHECK|UNIQUE)',S))|set(re.findall(r'CREATE\s+(?:UNIQUE\s+)?INDEX\s+(\w+)\s+ON',S))
fk_auto=set()
for t,cols in tables.items():
    for c in cols: fk_auto.add(f'{t}_{c}_fkey'); fk_auto.add(f'{t}_{c}_key')
known=cn|fk_auto|{'e164_iq_format','e164_any_format'}
errors=[];warns=[];used=set();defined=set(); stats={}

def scan(t):
    """يعيد قائمة (نوع، بداية، نهاية) للقطع: 'code' أو 'str' أو 'dollar' أو 'comment' — يحاكي مُحلِّل psql."""
    out=[];i=0;n=len(t);start=0
    def push(kind,a,b): out.append((kind,a,b))
    while i<n:
        c=t[i]
        if t.startswith('--',i):
            j=t.find('\n',i); j=n if j<0 else j; push('code',start,i); push('comment',i,j); i=j; start=i; continue
        if c=="'":
            j=i+1
            while j<n:
                if t[j]=="'":
                    if j+1<n and t[j+1]=="'": j+=2; continue
                    break
                j+=1
            if j>=n: raise ValueError(f"اقتباس مفرد غير مغلق (سطر {t.count(chr(10),0,i)+1})")
            push('code',start,i); push('str',i,j+1); i=j+1; start=i; continue
        if c=='$' and (i==0 or not (t[i-1].isalnum() or t[i-1]=='_')):
            m=re.match(r'\$([A-Za-z_]\w*)?\$',t[i:])
            if m:
                tag=m.group(0); j=t.find(tag,i+len(tag))
                if j<0: raise ValueError(f"اقتباس دولاري {tag} غير مغلق (سطر {t.count(chr(10),0,i)+1})")
                push('code',start,i); push('dollar',i,j+len(tag)); i=j+len(tag); start=i; continue
        i+=1
    push('code',start,n); return out
def statements(t):
    segs=scan(t); stmts=[];cur=''
    for kind,a,b in segs:
        if kind=='comment': continue
        if kind in ('str','dollar'): cur+=t[a:b]; continue
        for ch in t[a:b]:
            if ch==';': stmts.append(cur.strip()); cur=''
            else: cur+=ch
    if cur.strip(): stmts.append(cur.strip())
    return [x for x in stmts if x]
ALLOWED=('SELECT','DO','CREATE','INSERT','UPDATE','DELETE','GRANT','DROP','SET','REVOKE','ALTER','\\','COMMENT','WITH','BEGIN','COMMIT','RESET','ANALYZE','VACUUM','SHOW','EXPLAIN','TRUNCATE','PERFORM')
def call_args(t,start):
    """وسائط استدعاء يبدأ عند فتحة القوس t[start]=='(' : قائمة نصوص الوسائط"""
    segs=scan(t); depth=0;args=[];cur='';i=start
    # نمشي على القطع بدءًا من start
    for kind,a,b in segs:
        if b<=start: continue
        a=max(a,start)
        if kind in('str','dollar'): cur+=t[a:b]; continue
        if kind=='comment': continue
        for ch in t[a:b]:
            if ch=='(':
                depth+=1
                if depth==1: continue
            elif ch==')':
                depth-=1
                if depth==0: args.append(cur.strip()); return args
            elif ch==',' and depth==1: args.append(cur.strip()); cur=''; continue
            cur+=ch
    return args

def strip_sql_strings(x): return re.sub(r"'(?:[^']|'')*'","''",x)
files=sorted(glob.glob(os.path.join(sqldir,'*.sql')))
alltext={}
for f in files:
    t=open(f,encoding='utf-8').read(); alltext[f]=t; b=os.path.basename(f)
    try:
        for kind,a_,b_ in scan(t):
            if kind=='dollar':
                rest=t[b_:].lstrip()
                nxt=rest[:1]
                if rest and nxt not in (',',')',';') and not rest.upper().startswith('LANGUAGE'):
                    errors.append(f"{b}: بعد اقتباس دولاري (سطر {t.count(chr(10),0,a_)+1}) يأتي نص ملتصق {rest[:25]!r} (وسم إغلاق مفقود/مُزاح غالبًا)")
        sts=statements(t)
        for st in sts:
            first=re.split(r'\s+',st.lstrip('(').strip(),1)[0].upper()
            if not first.startswith(ALLOWED): errors.append(f"{b}: جملة تبدأ بنص غير مألوف (اقتران اقتباس مُزاح غالبًا): {st[:70]!r}")
    except ValueError as e:
        errors.append(f'{b}: {e}')
    for m in re.finditer(r'vt\.viol\(',t):
        try: args=call_args(t,m.end()-1)
        except ValueError: continue
        if len(args)>=4 and args[3].startswith("'") and args[3]!="NULL":
            hint=args[3].strip("'")
            for h in hint.split('|'):
                if re.fullmatch(r'[a-z][a-z0-9_]*',h) and '_' in h and h not in known:
                    errors.append(f'{b}: اسم قيد/فهرس غير معروف في المخطط: {h}')
    for k in re.findall(r"vt\.fu?\('(\w+)'\)",t): used.add(k)
    for k in re.findall(r"vt\.setfxu?\('(\w+)'",t): defined.add(k)
    # UPDATE t SET cols
    for m in re.finditer(r'UPDATE\s+(\w+)\s+SET\s+(.*?)(?:\s+WHERE\b|\$q\$|\$s\$|;|$)',t,re.S):
        tb=m.group(1)
        if tb not in tables: continue
        body=strip_sql_strings(m.group(2).split('WHERE')[0])
        for part in top_split(body):
            mm=re.match(r'(\w+)\s*=',part.strip())
            if mm and mm.group(1) not in tables[tb]: errors.append(f'{b}: UPDATE {tb} SET {mm.group(1)} — عمود غير موجود')
    for m in re.finditer(r'INSERT INTO\s+(\w+)\s*\(([^)]*)\)',t):
        tb=m.group(1)
        if tb in tables:
            for c in [x.strip() for x in m.group(2).split(',')]:
                if c and c not in tables[tb]: errors.append(f'{b}: INSERT INTO {tb} ({c}) — عمود غير موجود')
    n=len(re.findall(r'^\s*SELECT vt\.(viol|allow|scenario|ok|eq)\(',t,re.M))+len(re.findall(r'^\s*PERFORM vt\.(viol|allow|scenario|ok|eq|record)\(',t,re.M))
    n+=13*len(re.findall(r"SELECT vt\.app_flows\(",t))
    n+=len(re.findall(r'^\s*SELECT vt\.run_visibility_matrix\(',t,re.M))
    m=re.search(r'^-- EXPECT_MIN: (\d+)',t,re.M); mn=int(m.group(1)) if m else None
    stats[b]=(n,mn)
for k in sorted(used-defined) if os.path.exists(os.path.join(sqldir,'10_fixtures.sql')) else []: errors.append(f'مفتاح تثبيت مستعمل بلا تعريف: {k}')
# مفاتيح build_fixtures
fxp=os.path.join(sqldir,'10_fixtures.sql')
if os.path.exists(fxp):
    fx=open(fxp,encoding='utf-8').read()
    bf=re.search(r'CREATE FUNCTION vt\.build_fixtures.*?END \$\$;',fx,re.S).group(0)
    fxkeys=set(re.findall(r"vt\.setfxu?\('(\w+)'",bf))
print('أعمدة/جداول: تم فحص',len(tables),'جدولًا')
print('إحصاء الاختبارات الثابت (أدنى تقدير) مقابل EXPECT_MIN:')
for b,(n,mn) in stats.items():
    flag='' if (mn is None or n>=mn) else '  ✗ أقل من EXPECT_MIN'
    if flag: errors.append(f'{b}: العدد الثابت {n} < EXPECT_MIN {mn}')
    print(f'  {b}: {n} (EXPECT_MIN={mn}){flag}')
print('أخطاء:',len(errors)); [print('  ✗',e) for e in errors]
print('تحذيرات:',len(warns)); [print('  ~',w) for w in warns]

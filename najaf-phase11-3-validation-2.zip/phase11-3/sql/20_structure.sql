-- SUITE: structure
-- EXPECT_MIN: 21
SELECT vt.suite('structure');

SELECT vt.eq('extensions: citext + pg_trgm مثبَّتتان',
  (SELECT string_agg(extname, ',' ORDER BY extname COLLATE "C") FROM pg_extension WHERE extname IN ('citext', 'pg_trgm')), 'citext,pg_trgm');

SELECT vt.eq('الجداول: لا ناقص ولا زائد',
  (SELECT COALESCE(string_agg(x, ','), '') FROM (
     (SELECT 'missing:' || name AS x FROM vt.expected WHERE kind = 'table' EXCEPT SELECT 'missing:' || tablename FROM pg_tables WHERE schemaname = 'public')
     UNION ALL
     (SELECT 'extra:' || tablename FROM pg_tables WHERE schemaname = 'public' EXCEPT SELECT 'extra:' || name FROM vt.expected WHERE kind = 'table')) s), '');

SELECT vt.eq('الفهارس الصريحة موجودة كلها',
  (SELECT COALESCE(string_agg(name, ','), '') FROM vt.expected e WHERE kind = 'index'
     AND NOT EXISTS (SELECT 1 FROM pg_indexes i WHERE i.schemaname = 'public' AND i.indexname = e.name)), '');

SELECT vt.eq('الدوال موجودة كلها',
  (SELECT COALESCE(string_agg(name, ','), '') FROM vt.expected e WHERE kind = 'function'
     AND NOT EXISTS (SELECT 1 FROM pg_proc p WHERE p.pronamespace = 'public'::regnamespace AND p.proname = e.name)), '');

SELECT vt.eq('المشغّلات: لا ناقص ولا زائد (غير الداخلية)',
  (SELECT COALESCE(string_agg(x, ','), '') FROM (
     (SELECT 'missing:' || name AS x FROM vt.expected WHERE kind = 'trigger'
        EXCEPT SELECT 'missing:' || tgname FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid WHERE NOT t.tgisinternal AND c.relnamespace = 'public'::regnamespace)
     UNION ALL
     (SELECT 'extra:' || tgname FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid WHERE NOT t.tgisinternal AND c.relnamespace = 'public'::regnamespace
        EXCEPT SELECT 'extra:' || name FROM vt.expected WHERE kind = 'trigger')) s), '');

SELECT vt.eq('الـviews موجودة', (SELECT string_agg(name, ',' ORDER BY name COLLATE "C") FROM vt.expected WHERE kind = 'view'),
  (SELECT string_agg(viewname, ',' ORDER BY viewname COLLATE "C") FROM pg_views WHERE schemaname = 'public'));

SELECT vt.eq('قيود CHECK المسمّاة موجودة كلها',
  (SELECT COALESCE(string_agg(name, ','), '') FROM vt.expected e WHERE kind = 'check'
     AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.contype = 'c' AND c.conname = e.name AND (c.conrelid <> 0 OR c.contypid <> 0))), '');

SELECT vt.eq('قيود UNIQUE المسمّاة موجودة كلها',
  (SELECT COALESCE(string_agg(name, ','), '') FROM vt.expected e WHERE kind = 'unique'
     AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.contype = 'u' AND c.conname = e.name)), '');

SELECT vt.eq('قيود النطاقات (domains) موجودة',
  (SELECT COALESCE(string_agg(name, ','), '') FROM vt.expected e WHERE kind = 'domain_check'
     AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.contype = 'c' AND c.conname = e.name AND c.contypid <> 0)), '');

SELECT vt.eq('عدد المفاتيح الأجنبية', (SELECT count(*)::text FROM pg_constraint WHERE contype = 'f' AND connamespace = 'public'::regnamespace),
  (SELECT n::text FROM vt.expected_counts WHERE kind = 'fk'));

SELECT vt.eq('لكل جدول مفتاح أساسي',
  (SELECT COALESCE(string_agg(tablename, ','), '') FROM pg_tables t WHERE schemaname = 'public'
     AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.conrelid = (quote_ident(t.schemaname) || '.' || quote_ident(t.tablename))::regclass AND c.contype = 'p')), '');

SELECT vt.eq('لا أعمدة timestamp بلا منطقة زمنية',
  (SELECT COALESCE(string_agg(table_name || '.' || column_name, ','), '') FROM information_schema.columns
     WHERE table_schema = 'public' AND data_type = 'timestamp without time zone'), '');

SELECT vt.eq('المعرّفات BY DEFAULT (للاستيراد): users, showrooms, cars, car_images, favorites',
  (SELECT string_agg(c.relname, ',' ORDER BY c.relname COLLATE "C") FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid
     WHERE c.relnamespace = 'public'::regnamespace AND a.attname = 'id' AND a.attidentity = 'd'),
  'car_images,cars,favorites,showrooms,users');

SELECT vt.eq('المعرّفات ALWAYS: الجداول الجديدة بلا استيراد',
  (SELECT string_agg(c.relname, ',' ORDER BY c.relname COLLATE "C") FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid
     WHERE c.relnamespace = 'public'::regnamespace AND a.attname = 'id' AND a.attidentity = 'a'),
  'audit_logs,exchange_rates,message_deliveries,payments,subscriptions');

SELECT vt.eq('الأدوار: najaf_app و najaf_report بلا تسجيل دخول ولا إشراف',
  (SELECT string_agg(rolname || ':' || rolcanlogin || ':' || rolsuper, ',' ORDER BY rolname COLLATE "C") FROM pg_roles WHERE rolname IN ('najaf_app', 'najaf_report')),
  'najaf_app:false:false,najaf_report:false:false');

SELECT vt.ok('الـviews بخيار security_barrier',
  (SELECT count(*) FROM pg_class WHERE relname IN ('public_showrooms', 'public_cars') AND reloptions @> ARRAY['security_barrier=true']) = 2);

SELECT vt.eq('بيانات أساسية: الخطة المجانية', (SELECT count(*)::text FROM subscription_plans WHERE code = 'free' AND price = 0 AND entitlements = '{}'::jsonb), '1');
SELECT vt.eq('بيانات أساسية: إعدادات التطبيق الأربعة',
  (SELECT string_agg(key, ',' ORDER BY key COLLATE "C") FROM app_settings), 'images.max_per_car,images.upload,limits.text,otp.policy');
SELECT vt.eq('app_settings: سقف الصور 4 للعضو و5 للمعرض',
  (SELECT (value ->> 'member') || '/' || (value ->> 'showroom') FROM app_settings WHERE key = 'images.max_per_car'), '4/5');
SELECT vt.eq('لا حسابات ولا سعر صرف في المخطط الخالي (الإنتاج): users وexchange_rates فارغان قبل البذرة',
  (SELECT (SELECT count(*) FROM users)::text || '/' || (SELECT count(*) FROM exchange_rates)::text), '0/0');

SELECT vt.eq('أعلام النسخة (معلوماتية)', (SELECT string_agg(key || '=' || val, ',' ORDER BY key COLLATE "C") FROM vt.flags),
  (SELECT string_agg(key || '=' || val, ',' ORDER BY key COLLATE "C") FROM vt.flags));

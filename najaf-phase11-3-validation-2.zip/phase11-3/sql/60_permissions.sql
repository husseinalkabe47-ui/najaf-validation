-- SUITE: permissions
-- EXPECT_MIN: 60
SELECT vt.suite('permissions');

-- منح اختباري فقط: الدوال المساعدة في schema vt (لا علاقة له بصلاحيات مخطط التطبيق)
GRANT USAGE ON SCHEMA vt TO najaf_app, najaf_report, vt_nobody, vt_app_login;
GRANT SELECT ON vt.fx TO najaf_app, najaf_report, vt_nobody, vt_app_login;
GRANT EXECUTE ON FUNCTION vt.f(text), vt.fu(text) TO najaf_app, najaf_report, vt_nobody, vt_app_login;

-- مصفوفة الصلاحيات المتوقعة لـ najaf_app (قبل التشديد 0013 = pre، وبعده = post)
CREATE FUNCTION vt.exp_app(rel text, priv text, phase text) RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN rel IN ('public_showrooms', 'public_cars') THEN priv = 'SELECT'
    WHEN rel IN ('users', 'audit_logs', 'exchange_rates') THEN priv IN ('SELECT', 'INSERT')
    WHEN rel = 'showrooms' THEN priv IN ('SELECT', 'INSERT') OR (priv = 'UPDATE' AND phase = 'pre')
    WHEN rel IN ('cars', 'car_images', 'favorites') THEN priv IN ('SELECT', 'INSERT', 'DELETE') OR (priv = 'UPDATE' AND phase = 'pre')
    WHEN rel IN ('assets', 'sessions', 'verification_codes', 'reward_grants') THEN priv IN ('SELECT', 'INSERT', 'UPDATE', 'DELETE')
    WHEN rel IN ('message_deliveries', 'subscription_plans', 'subscriptions', 'payments', 'app_settings') THEN priv IN ('SELECT', 'INSERT', 'UPDATE')
    ELSE false END
$$;
CREATE FUNCTION vt.exp_report(rel text, priv text) RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
  SELECT rel IN ('public_showrooms', 'public_cars', 'audit_logs') AND priv = 'SELECT'
$$;
CREATE VIEW vt.rels AS
  SELECT c.relname::text AS rel FROM pg_class c WHERE c.relnamespace = 'public'::regnamespace AND c.relkind IN ('r', 'v');
CREATE VIEW vt.privs AS SELECT unnest(ARRAY['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'TRUNCATE', 'REFERENCES', 'TRIGGER']) AS priv;

SELECT vt.eq('najaf_app: مصفوفة صلاحيات الجداول والـviews مطابقة (قبل 0013) — الفروق إن وُجدت',
  (SELECT COALESCE(string_agg(r.rel || '.' || p.priv || '=' || has_table_privilege('najaf_app', quote_ident(r.rel), p.priv), ',' ORDER BY r.rel, p.priv), '')
     FROM vt.rels r CROSS JOIN vt.privs p WHERE has_table_privilege('najaf_app', quote_ident(r.rel), p.priv) <> vt.exp_app(r.rel, p.priv, 'pre')), '');
SELECT vt.eq('najaf_report: SELECT على public_showrooms وpublic_cars وaudit_logs فقط — الفروق',
  (SELECT COALESCE(string_agg(r.rel || '.' || p.priv, ',' ORDER BY r.rel, p.priv), '')
     FROM vt.rels r CROSS JOIN vt.privs p WHERE has_table_privilege('najaf_report', quote_ident(r.rel), p.priv) <> vt.exp_report(r.rel, p.priv)), '');
SELECT vt.eq('PUBLIC (دور بلا منح): لا صلاحية على أي جدول أو view — الفروق',
  (SELECT COALESCE(string_agg(r.rel || '.' || p.priv, ',' ORDER BY r.rel, p.priv), '')
     FROM vt.rels r CROSS JOIN vt.privs p WHERE has_table_privilege('vt_nobody', quote_ident(r.rel), p.priv)), '');
SELECT vt.eq('najaf_app: صلاحيات الأعمدة على users (UPDATE) = الأعمدة المتفق عليها فقط',
  (SELECT string_agg(column_name, ',' ORDER BY column_name COLLATE "C") FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'users' AND has_column_privilege('najaf_app', 'users', column_name, 'UPDATE')),
  'deleted_at,email,failed_logins,last_login_at,locked_until,name,password_changed_at,password_hash,phone_e164,phone_verified_at,status');
SELECT vt.ok('najaf_app: لا UPDATE على users.role/id/created_at/updated_at/version',
  NOT (has_column_privilege('najaf_app', 'users', 'role', 'UPDATE') OR has_column_privilege('najaf_app', 'users', 'id', 'UPDATE')
    OR has_column_privilege('najaf_app', 'users', 'created_at', 'UPDATE') OR has_column_privilege('najaf_app', 'users', 'updated_at', 'UPDATE')
    OR has_column_privilege('najaf_app', 'users', 'version', 'UPDATE')));
SELECT vt.eq('الدوال: EXECUTE على to_iqd لـvt_nobody (النسخة المعدّلة تسحبه من PUBLIC؛ المُسلَّمة تتركه)',
  has_function_privilege('vt_nobody', 'to_iqd(numeric, text)', 'EXECUTE')::text, (NOT vt.flag('cover_guard'))::text);
SELECT vt.ok('الدوال: najaf_app ينفّذ current_usd_to_iqd وto_iqd وentitlements_for_showroom',
  has_function_privilege('najaf_app', 'current_usd_to_iqd()', 'EXECUTE') AND has_function_privilege('najaf_app', 'to_iqd(numeric, text)', 'EXECUTE')
  AND has_function_privilege('najaf_app', 'entitlements_for_showroom(bigint)', 'EXECUTE'));
SELECT vt.ok('najaf_app لا يملك أي كائن (ليس مالكًا لأي جدول)', NOT EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tableowner = 'najaf_app'));
SELECT vt.ok('أسماء najaf_app وnajaf_report لا تملك CREATE على schema public',
  NOT has_schema_privilege('najaf_app', 'public', 'CREATE') AND NOT has_schema_privilege('najaf_report', 'public', 'CREATE'));

-- ===================== najaf_app: ما يُرفض =====================
SELECT vt.viol('najaf_app: CREATE TABLE', $q$CREATE TABLE vt_forbidden (a int)$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: DROP TABLE users', $q$DROP TABLE users$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: ALTER TABLE cars', $q$ALTER TABLE cars ADD COLUMN x int$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: DROP VIEW public_cars', $q$DROP VIEW public_cars$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: CREATE FUNCTION في public', $q$CREATE FUNCTION public.vt_f() RETURNS int LANGUAGE sql AS 'SELECT 1'$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: TRUNCATE cars', $q$TRUNCATE cars$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: TRUNCATE audit_logs', $q$TRUNCATE audit_logs$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: DELETE FROM users', $q$DELETE FROM users WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: DELETE FROM showrooms', $q$DELETE FROM showrooms WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: DELETE FROM audit_logs', $q$DELETE FROM audit_logs WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: UPDATE audit_logs', $q$UPDATE audit_logs SET reason = 'x' WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: UPDATE exchange_rates', $q$UPDATE exchange_rates SET usd_to_iqd = 1 WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: DELETE FROM exchange_rates', $q$DELETE FROM exchange_rates WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: UPDATE users.id', $q$UPDATE users SET id = id WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: UPDATE users.created_at', $q$UPDATE users SET created_at = created_at WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: UPDATE users.updated_at', $q$UPDATE users SET updated_at = updated_at WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: UPDATE users.version', $q$UPDATE users SET version = 5 WHERE false$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: قراءة pg_authid', $q$SELECT * FROM pg_authid$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: CREATE ROLE', $q$CREATE ROLE vt_forbidden_role$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: SET ROLE إلى دور ليس عضوًا فيه', $q$SET ROLE vt_ops$q$, '42501', 'permission denied to set role', 'najaf_app');
SELECT vt.viol('najaf_app: GRANT على جدول ليس له', $q$GRANT SELECT ON users TO vt_nobody$q$, '42501', NULL, 'najaf_app');
SELECT vt.viol('najaf_app: ينشئ مديرًا', format($q$INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير اختبار', %L, 'admin', %L)$q$, vt.phone(), vt.hash()), '42501', 'admin accounts can only be created', 'najaf_app');
SELECT vt.viol('najaf_app: دور الدخول العضو ينشئ مديرًا', format($q$INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير اختبار', %L, 'admin', %L)$q$, vt.phone(), vt.hash()), '42501', 'admin accounts can only be created', 'vt_app_login');
SELECT vt.viol('najaf_app: UPDATE audit_logs من دور الدخول العضو', $q$UPDATE audit_logs SET reason = 'x' WHERE false$q$, '42501', NULL, 'vt_app_login');
SELECT vt.viol('najaf_app: TRUNCATE من دور الدخول العضو', $q$TRUNCATE sessions$q$, '42501', NULL, 'vt_app_login');

-- ===================== najaf_app: ما يُسمح =====================
SELECT vt.allow('najaf_app: SELECT على users (بما فيه password_hash للدخول)', $q$SELECT id, password_hash FROM users LIMIT 1$q$, 'najaf_app');
SELECT vt.allow('najaf_app: SELECT على public_cars وpublic_showrooms', $q$SELECT count(*) FROM public_cars; SELECT count(*) FROM public_showrooms$q$, 'najaf_app');
SELECT vt.allow('najaf_app: UPDATE users.name', $q$UPDATE users SET name = name WHERE false$q$, 'najaf_app');
SELECT vt.allow('najaf_app: تنفيذ to_iqd', $q$SELECT to_iqd(1, 'IQD')$q$, 'najaf_app');
SELECT vt.allow('دور الدخول العضو في najaf_app يرث الصلاحيات: SELECT على public_cars', $q$SELECT count(*) FROM public_cars$q$, 'vt_app_login');

-- ===================== najaf_report =====================
SELECT vt.allow('najaf_report: SELECT على الـviews', $q$SELECT count(*) FROM public_cars; SELECT count(*) FROM public_showrooms$q$, 'najaf_report');
SELECT vt.allow('najaf_report: SELECT على audit_logs', $q$SELECT count(*) FROM audit_logs$q$, 'najaf_report');
SELECT vt.viol('najaf_report: SELECT على users', $q$SELECT count(*) FROM users$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: SELECT على cars', $q$SELECT count(*) FROM cars$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: SELECT على showrooms', $q$SELECT count(*) FROM showrooms$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: SELECT على sessions', $q$SELECT count(*) FROM sessions$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: INSERT في audit_logs', $q$INSERT INTO audit_logs (action, entity_type) VALUES ('x', 'y')$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: UPDATE على cars', $q$UPDATE cars SET price = 1 WHERE false$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: DELETE من favorites', $q$DELETE FROM favorites WHERE false$q$, '42501', NULL, 'najaf_report');
SELECT vt.viol('najaf_report: to_iqd (تعتمد على exchange_rates غير المقروء له)', $q$SELECT to_iqd(1, 'USD')$q$, '42501', NULL, 'najaf_report');

-- ===================== دور بلا منح (PUBLIC) =====================
SELECT vt.viol('PUBLIC: SELECT على public_cars', $q$SELECT count(*) FROM public_cars$q$, '42501', NULL, 'vt_nobody');
SELECT vt.viol('PUBLIC: SELECT على users', $q$SELECT count(*) FROM users$q$, '42501', NULL, 'vt_nobody');
SELECT vt.viol('PUBLIC: INSERT على cars', $q$INSERT INTO cars (source_type) VALUES ('showroom')$q$, '42501', NULL, 'vt_nobody');

-- ===================== تدفقات التطبيق الحقيقية تحت najaf_app (انحدار التشديد) =====================
-- كل تدفق: تُبنى بياناته بالمشرف، ثم تُنفَّذ عمليات التطبيق بدور najaf_app، ثم يُفحص الأثر بالمشرف.
CREATE FUNCTION vt.app_flows(p_label text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE pre text := $p$
  SELECT vt.setfx('fu', vt.mk_user()); SELECT vt.setfx('fd', vt.mk_user('dealer')); SELECT vt.setfx('fd2', vt.mk_user('dealer'));
  SELECT vt.setfx('fsr', vt.mk_showroom(vt.f('fd'))); SELECT vt.setfx('fc', vt.mk_mcar(vt.f('fu')));
  SELECT vt.setfxu('fa', vt.mk_asset(vt.f('fu'))); SELECT vt.setfxu('fs', vt.mk_session(vt.f('fu')));
$p$;
BEGIN
  PERFORM vt.scenario(p_label || ' | نشر إعلان وإرفاق صورة (حارس الصور يقرأ ويقفل cars)',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO cars (source_type, owner_id, brand, model, year, price, status, phone) VALUES ('member', vt.f('fu'), 'Kia', 'Rio', 2021, 9000000, 'pending', '+9647700000099');
      INSERT INTO car_images (car_id, asset_id, sort_order, is_main) SELECT id, vt.fu('fa'), 0, true FROM cars WHERE owner_id = vt.f('fu') AND status = 'pending';
      RESET ROLE$s$,
    $c$SELECT EXISTS (SELECT 1 FROM car_images i JOIN cars c ON c.id = i.car_id WHERE i.asset_id = vt.fu('fa') AND c.status = 'pending' AND i.is_main)$c$);
  PERFORM vt.scenario(p_label || ' | تعديل السعر والحالة يزيد version',
    pre || $s$SET LOCAL ROLE najaf_app; UPDATE cars SET price = price + 1, status = 'sold' WHERE id = vt.f('fc'); RESET ROLE$s$,
    $c$SELECT version = 2 AND status = 'sold' FROM cars WHERE id = vt.f('fc')$c$);
  PERFORM vt.scenario(p_label || ' | الحذف الناعم يزيل المفضلة (مشغّل يحذف من favorites بدور التطبيق)',
    pre || $s$INSERT INTO favorites (user_id, car_id) VALUES (vt.f('fu'), vt.f('fc')); SET LOCAL ROLE najaf_app; UPDATE cars SET deleted_at = now() WHERE id = vt.f('fc'); RESET ROLE$s$,
    $c$SELECT NOT EXISTS (SELECT 1 FROM favorites WHERE car_id = vt.f('fc')) AND (SELECT deleted_at IS NOT NULL FROM cars WHERE id = vt.f('fc'))$c$);
  PERFORM vt.scenario(p_label || ' | إيقاف المستخدم يلغي جلساته (مشغّل يعدّل sessions بدور التطبيق)',
    pre || $s$SET LOCAL ROLE najaf_app; UPDATE users SET status = 'suspended' WHERE id = vt.f('fu'); RESET ROLE$s$,
    $c$SELECT revoked_reason = 'user_suspended' FROM sessions WHERE id = vt.fu('fs')$c$);
  PERFORM vt.scenario(p_label || ' | تدوير الجلسة (إدخال جديدة وإلغاء القديمة مع replaced_by)',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO sessions (user_id, family_id, token_hash, expires_at) VALUES (vt.f('fu'), gen_random_uuid(), sha256(convert_to('tok-' || gen_random_uuid()::text, 'UTF8')), now() + interval '30 days');
      UPDATE sessions SET revoked_at = now(), revoked_reason = 'rotated', replaced_by = (SELECT id FROM sessions WHERE user_id = vt.f('fu') AND revoked_at IS NULL AND id <> vt.fu('fs') LIMIT 1) WHERE id = vt.fu('fs');
      RESET ROLE$s$,
    $c$SELECT replaced_by IS NOT NULL AND revoked_reason = 'rotated' FROM sessions WHERE id = vt.fu('fs')$c$);
  PERFORM vt.scenario(p_label || ' | رمز تحقق: إصدار ومحاولة واستهلاك',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO verification_codes (purpose, user_id, target_phone, code_hash, expires_at) VALUES ('password_reset', vt.f('fu'), '+9647700000098', sha256(convert_to('c', 'UTF8')), now() + interval '10 minutes');
      UPDATE verification_codes SET attempts = attempts + 1 WHERE user_id = vt.f('fu') AND purpose = 'password_reset';
      UPDATE verification_codes SET consumed_at = now() WHERE user_id = vt.f('fu') AND purpose = 'password_reset';
      RESET ROLE$s$,
    $c$SELECT attempts = 1 AND consumed_at IS NOT NULL FROM verification_codes WHERE user_id = vt.f('fu') AND purpose = 'password_reset'$c$);
  PERFORM vt.scenario(p_label || ' | سجل التدقيق وسعر الصرف (إضافة فقط) ثم قراءة السعر',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO audit_logs (actor_id, actor_role, action, entity_type, entity_id, after_data) VALUES (vt.f('fu'), 'user', 'test.flow', 'cars', '1', '{"a":1}'::jsonb);
      INSERT INTO exchange_rates (usd_to_iqd, kind, set_by) VALUES (1310, 'manual', vt.f('fu'));
      RESET ROLE$s$,
    $c$SELECT EXISTS (SELECT 1 FROM audit_logs WHERE action = 'test.flow') AND current_usd_to_iqd() = 1310$c$);
  PERFORM vt.scenario(p_label || ' | إنشاء معرض وتحديثه (INSERT/UPDATE على showrooms)',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO showrooms (owner_id, name, status) VALUES (vt.f('fd2'), 'معرض جديد', 'pending');
      UPDATE showrooms SET status = 'active', name = 'معرض مُعتمد', working_hours = '9-9', reviewed_by = vt.f('fd'), reviewed_at = now() WHERE owner_id = vt.f('fd2');
      RESET ROLE$s$,
    $c$SELECT status = 'active' AND name = 'معرض مُعتمد' FROM showrooms WHERE owner_id = vt.f('fd2')$c$);
  PERFORM vt.scenario(p_label || ' | مفضلة: إضافة وإزالة',
    pre || $s$SET LOCAL ROLE najaf_app; INSERT INTO favorites (user_id, car_id) VALUES (vt.f('fu'), vt.f('fc')); DELETE FROM favorites WHERE user_id = vt.f('fu') AND car_id = vt.f('fc'); INSERT INTO favorites (user_id, car_id) VALUES (vt.f('fu'), vt.f('fc')); RESET ROLE$s$,
    $c$SELECT count(*) = 1 FROM favorites WHERE user_id = vt.f('fu') AND car_id = vt.f('fc')$c$);
  PERFORM vt.scenario(p_label || ' | دورة المكافأة: طلب ثم تحقق ثم استهلاك مع ربط السيارة',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO reward_grants (id, user_id, expires_at) VALUES ('11111111-1111-4111-8111-111111111111', vt.f('fu'), now() + interval '1 hour');
      UPDATE reward_grants SET status = 'verified', ssv_transaction_id = 'tx-flow', verified_at = now() WHERE id = '11111111-1111-4111-8111-111111111111';
      UPDATE reward_grants SET status = 'consumed', consumed_at = now(), car_id = vt.f('fc') WHERE id = '11111111-1111-4111-8111-111111111111';
      RESET ROLE$s$,
    $c$SELECT status = 'consumed' AND car_id = vt.f('fc') FROM reward_grants WHERE id = '11111111-1111-4111-8111-111111111111'$c$);
  PERFORM vt.scenario(p_label || ' | سجل تسليم الرسالة: إدخال وتحديث الحالة والتكلفة',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO message_deliveries (channel, provider, to_phone, provider_message_id) VALUES ('whatsapp', 'twilio', '+9647700000097', 'flow-msg');
      UPDATE message_deliveries SET status = 'delivered', delivered_at = now(), cost_micros = 9100, error_code = NULL WHERE provider_message_id = 'flow-msg';
      RESET ROLE$s$,
    $c$SELECT status = 'delivered' AND cost_micros = 9100 FROM message_deliveries WHERE provider_message_id = 'flow-msg'$c$);
  PERFORM vt.scenario(p_label || ' | اشتراك ودفعة: إدخال وتحديث إلى مدفوعة',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (vt.f('fsr'), (SELECT id FROM subscription_plans WHERE code = 'free'), 'active', now(), now() + interval '30 days');
      INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref) SELECT id, 0, 'IQD', 'manual', 'flow-pay' FROM subscriptions WHERE showroom_id = vt.f('fsr');
      UPDATE payments SET status = 'paid', paid_at = now() WHERE provider_ref = 'flow-pay';
      RESET ROLE$s$,
    $c$SELECT status = 'paid' FROM payments WHERE provider_ref = 'flow-pay'$c$);
  PERFORM vt.scenario(p_label || ' | أصول: إدخال معالجة ثم تحديث إلى جاهز',
    pre || $s$SET LOCAL ROLE najaf_app;
      INSERT INTO assets (owner_id, kind, status) VALUES (vt.f('fu'), 'car_image', 'pending');
      UPDATE assets SET status = 'ready', storage_key = 'flow/k', thumb_key = 'flow/t', mime = 'image/webp', bytes = 10, width = 1, height = 1, sha256 = repeat('a', 64), ready_at = now() WHERE owner_id = vt.f('fu') AND status = 'pending' AND storage_key IS NULL;
      RESET ROLE$s$,
    $c$SELECT EXISTS (SELECT 1 FROM assets WHERE storage_key = 'flow/k' AND status = 'ready')$c$);
END $$;
SELECT vt.app_flows('قبل 0013');

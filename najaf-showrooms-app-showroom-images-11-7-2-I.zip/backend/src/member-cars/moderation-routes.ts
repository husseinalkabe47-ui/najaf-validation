// HTTP contract for the administrator's moderation of member ads (Phase 11.7.2-G). Thin: decisions live in member-cars/moderation.ts.
// Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   GET  /v1/admin/member-cars?status=&after=&limit=     Bearer (admin)                      -> 200 {items, nextAfter}
//   GET  /v1/admin/member-cars/:id                       Bearer (admin)                      -> 200 {car}
//   POST /v1/admin/member-cars/:id/approve               Bearer (admin), JSON {version}      -> 200 {car}   (409 reward_required today)
//   POST /v1/admin/member-cars/:id/reject                Bearer (admin), JSON {version, reason?}   -> 200 {car}
//   POST /v1/admin/member-cars/:id/suspend               Bearer (admin), JSON {version, reason}    -> 200 {car}
//   POST /v1/admin/member-cars/:id/restore               Bearer (admin), JSON {version}      -> 200 {car}
//
// Errors: 401 no/invalid token; 404 for any non-administrator and for an unknown or malformed id (identical); 400 invalid input
// (field names and codes only); 409 version_conflict / invalid_state / reward_required; 415 non-JSON body; 429 rate limited.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { ModerationError, MODERATION_ACTIONS } from './moderation.ts';
import type { ModerationApi } from './moderation.ts';

/** PROPOSED, per client address and per instance. */
export const MODERATION_RATE_LIMITS = {
  write: { limit: 120, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type ModerationRateLimitedRoute = keyof typeof MODERATION_RATE_LIMITS;

export function toModerationHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof ModerationError) {
    if (e.code === 'validation_failed') return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    return { status: 409, code: e.code, message: e.message };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateHook(limiter: RateLimiter, route: ModerationRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`memberCarModeration.${route}:${request.ip}`, MODERATION_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'member_car_moderation.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

export function registerModerationRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; moderation: ModerationApi; rateLimiter?: RateLimiter }): void {
  const { auth, moderation, rateLimiter } = deps;
  const limited = (route: ModerationRateLimitedRoute): Hook[] => (rateLimiter ? [rateHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toModerationHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };
  const idParam = (request: FastifyRequest): unknown => (request.params as Record<string, unknown> | undefined)?.['id'];

  app.get('/v1/admin/member-cars', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await moderation.list(actor, request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/admin/member-cars/:id', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send({ car: await moderation.get(actor, idParam(request)) });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  for (const action of MODERATION_ACTIONS) {
    app.post(`/v1/admin/member-cars/:id/${action}`, { bodyLimit: 4 * 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
      try {
        const actor = await identify(request);
        const car = await moderation.act(actor, action, idParam(request), request.body, { requestId: request.id });
        return reply.code(200).send({ car });
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });
  }
}

// PostgreSQL access for the images of a SHOWROOM car (Phase 11.7.2-I). Same rules as car-images/repository.ts, with the showroom as
// the scope instead of the member:
//  - the dealer's showroom is found ONLY by `showrooms.owner_id = <the verified actor's id>` (never from the request);
//  - the CAR is always found by `showroom_id = <that showroom>` AND `source_type = 'showroom'` AND not deleted, and is locked FOR
//    UPDATE for every write (this also serializes with the database trigger car_images_guard, which locks the same row);
//  - the ASSET is found by `owner_id = <the actor's id>` (the trigger additionally requires asset owner = showroom owner);
//  - an image is found by (image id AND the id of the already-authorized car): an image of another car is not found;
//  - the per-car cap is app_settings 'images.max_per_car' -> 'showroom' (5), the very value the database trigger enforces;
//  - only privileges of migrations 0012/0013: INSERT/DELETE on car_images, UPDATE of sort_order/is_main. No migration is needed.
// The image/asset statements are the ones of car-images/repository.ts (car-scoped, not owner-kind scoped), reused unchanged.
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';
import { createPgCarImageRepository } from '../car-images/repository.ts';
import type { CarImageRepository } from '../car-images/repository.ts';
import { FIND_SHOWROOM_OF_OWNER_SQL } from '../showroom-cars/repository.ts';
import type { OwnShowroomRow } from '../showroom-cars/repository.ts';

export const SHOWROOM_IMAGE_CAP_DEFAULT = 5;

export interface ShowroomImageCarRow {
  id: string;
  showroomId: string;
  status: string;
}

export interface ShowroomImageRepository extends Pick<CarImageRepository, 'lockActingUser' | 'listImages' | 'findOwnAsset' | 'countImages' | 'insertImage' | 'deleteImage' | 'repairLayout'> {
  /** The showroom owned by this account (at most one), whatever its status; null if none. */
  findShowroomOfOwner(ownerId: string): Promise<OwnShowroomRow | null>;
  /** One car of this showroom (source 'showroom', not deleted); null for anything else. `lock` = FOR UPDATE until the end of the transaction. */
  findShowroomCar(carId: string, showroomId: string, lock: boolean): Promise<ShowroomImageCarRow | null>;
  /** The per-car image limit for showroom cars (app_settings 'images.max_per_car', the same value the database trigger enforces). */
  showroomImageCap(): Promise<number>;
}

export interface ShowroomImageStore {
  /** Autocommit reads. */
  images: ShowroomImageRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { images: ShowroomImageRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

/** SQL builders, exported so tests can pin their text (and run it on a real database). */
export function buildFindShowroomCar(carId: string, showroomId: string, lock: boolean): { text: string; values: unknown[] } {
  return {
    text: `SELECT c.id, c.showroom_id, c.status
             FROM cars c
            WHERE c.id = $1::bigint AND c.showroom_id = $2::bigint AND c.source_type = 'showroom' AND c.deleted_at IS NULL${lock ? '\n              FOR UPDATE OF c' : ''}`,
    values: [carId, showroomId],
  };
}
export const SHOWROOM_IMAGE_CAP_SQL = `SELECT (value ->> 'showroom')::integer AS cap FROM app_settings WHERE key = 'images.max_per_car'`;

export function createPgShowroomImageRepository(q: Tx): ShowroomImageRepository {
  const base = createPgCarImageRepository(q);
  const find = async (carId: string, showroomId: string, lock: boolean): Promise<ShowroomImageCarRow | null> => {
    const s = buildFindShowroomCar(carId, showroomId, lock);
    const r = (await q.query<{ id: string; showroom_id: string; status: string }>(s.text, s.values)).rows[0];
    return r ? { id: String(r.id), showroomId: String(r.showroom_id), status: r.status } : null;
  };
  return {
    lockActingUser: base.lockActingUser,
    listImages: base.listImages,
    findOwnAsset: base.findOwnAsset,
    countImages: base.countImages,
    insertImage: base.insertImage,
    deleteImage: base.deleteImage,
    repairLayout: base.repairLayout,
    async findShowroomOfOwner(ownerId) {
      const r = (await q.query<{ id: string; owner_id: string; status: string }>(FIND_SHOWROOM_OF_OWNER_SQL, [ownerId])).rows[0];
      return r ? { id: String(r.id), ownerId: String(r.owner_id), status: r.status } : null;
    },
    findShowroomCar: find,
    async showroomImageCap() {
      const cap = (await q.query<{ cap: number | null }>(SHOWROOM_IMAGE_CAP_SQL)).rows[0]?.cap;
      return typeof cap === 'number' && cap >= 0 ? cap : SHOWROOM_IMAGE_CAP_DEFAULT;
    },
  };
}

export function createPgShowroomImageStore(db: Db): ShowroomImageStore {
  return {
    images: createPgShowroomImageRepository(db),
    transaction: (fn) => db.tx((t) => fn({ images: createPgShowroomImageRepository(t), audit: createPgAuditRepository(t) })),
  };
}

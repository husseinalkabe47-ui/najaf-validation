// Images of a SHOWROOM car (Phase 11.7.2-I): list, attach and remove, for the showroom's own dealer only.
//
// Decisions (each is covered by tests):
//  - WHO acts is an Actor from src/authz. The dealer area is for an ACTIVE dealer only; anyone else (a member, an administrator, a
//    pending dealer = no actor) gets 404, as on every other dealer route. The showroom is ALWAYS the one owned by the actor; no
//    input carries a showroom, owner or car source.
//  - Ownership is enforced three times, for every operation: the SQL finds the car only as a car of that showroom (source
//    'showroom', not deleted), the service re-checks row.showroomId === showroom.id, and the existing policy (authorize on a
//    showroomCarResource built from the server-loaded showroom) must allow read (list) or update (attach, remove). A car of another
//    showroom, a member ad, a deleted or malformed car id: the same 404.
//  - The asset is found only as the CALLER's own (another user's asset is 404, identical to unknown). It must be a READY car_image
//    not yet attached anywhere, else 409 invalid_state. The database trigger independently requires asset owner = showroom owner.
//  - The cap is app_settings 'images.max_per_car' -> 'showroom' (5, the value the trigger enforces); reaching it is 409 image_limit.
//    The check runs under the car's row lock, so concurrent attaches cannot exceed it.
//  - Layout is decided by the server exactly as for member cars (a new image goes last and is main if first; deleting the main image
//    promotes the first remaining one; positions stay contiguous). Choosing the main image and reordering are NOT part of this phase.
//  - Delete removes the LINK only; the asset stays for the cleanup job. The car row (and its version) is never written here.
//  - Everything that writes runs in ONE transaction with the acting account re-checked and the audit row.
import { authorize, notFound, showroomCarResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { CarImageError, toOwnCarImage } from '../car-images/service.ts';
import type { OwnCarImage, OwnCarImages, RequestContext } from '../car-images/service.ts';
import { parseAddImageInput, parseImageId } from '../car-images/validation.ts';
import { DbError } from '../errors.ts';
import { parseCarId } from '../member-cars/validation.ts';
import type { OwnShowroomRow } from '../showroom-cars/repository.ts';
import type { ShowroomImageCarRow, ShowroomImageRepository, ShowroomImageStore } from './repository.ts';

export interface ShowroomCarImageApi {
  add(actor: Actor | null, rawCarId: unknown, body: unknown, ctx?: RequestContext): Promise<OwnCarImage>;
  list(actor: Actor | null, rawCarId: unknown): Promise<OwnCarImages>;
  remove(actor: Actor | null, rawCarId: unknown, rawImageId: unknown, ctx?: RequestContext): Promise<void>;
}

/** Only an acting dealer has a dealer area. Everyone else: 404. */
function requireDealer(actor: Actor | null): Actor {
  if (!actor || actor.role !== 'dealer') throw notFound();
  return actor;
}

async function ownShowroom(images: ShowroomImageRepository, actor: Actor): Promise<OwnShowroomRow> {
  const s = await images.findShowroomOfOwner(actor.id);
  if (!s || s.ownerId !== actor.id) throw notFound();
  return s;
}

/** The single ownership gate for a loaded car: a car of the actor's showroom, AND allowed by the policy. Anything else is 404. */
function ownCar(actor: Actor, showroom: OwnShowroomRow, car: ShowroomImageCarRow | null, action: 'read' | 'update'): ShowroomImageCarRow {
  if (!car || car.showroomId !== showroom.id) throw notFound();
  authorize(actor, action, showroomCarResource({ showroomOwnerId: showroom.ownerId, showroomStatus: showroom.status, ownerActive: true, deleted: false }));
  return car;
}

async function lockedCar(images: ShowroomImageRepository, actor: Actor, carId: string): Promise<ShowroomImageCarRow> {
  if (!(await images.lockActingUser(actor.id))) throw notFound();
  const showroom = await ownShowroom(images, actor);
  return ownCar(actor, showroom, await images.findShowroomCar(carId, showroom.id, true), 'update');
}

export function createShowroomCarImageService(deps: { store: ShowroomImageStore }): ShowroomCarImageApi {
  const { store } = deps;

  return {
    async add(actor, rawCarId, body, ctx = {}) {
      const carId = parseCarId(rawCarId);
      if (carId === null) throw notFound();
      const dealer = requireDealer(actor);
      const parsed = parseAddImageInput(body);
      if (!parsed.ok) throw new CarImageError('validation_failed', parsed.errors);
      const { assetId } = parsed.value;
      try {
        return await store.transaction(async ({ images, audit }) => {
          const car = await lockedCar(images, dealer, carId);
          const asset = await images.findOwnAsset(assetId, dealer.id);
          if (!asset) throw notFound();
          if (asset.kind !== 'car_image' || asset.status !== 'ready' || asset.attachedCarId !== null) throw new CarImageError('invalid_state');
          const [count, cap] = [await images.countImages(car.id), await images.showroomImageCap()];
          if (count >= cap) throw new CarImageError('image_limit');
          const row = await images.insertImage(car.id, assetId);
          await audit.record({
            action: 'showroom_car.image_add',
            actorUserId: dealer.id,
            actorRole: 'dealer',
            entityType: 'car',
            entityId: car.id,
            afterData: { imageId: Number(row.id), images: count + 1 },
            requestId: ctx.requestId,
          });
          return toOwnCarImage(row);
        });
      } catch (e) {
        // A concurrent attach of the same asset (the UNIQUE asset_id decides): the asset is no longer free.
        if (e instanceof DbError && e.kind === 'unique') throw new CarImageError('invalid_state');
        throw e;
      }
    },

    async list(actor, rawCarId) {
      const carId = parseCarId(rawCarId);
      if (carId === null) throw notFound();
      const dealer = requireDealer(actor);
      const showroom = await ownShowroom(store.images, dealer);
      const car = ownCar(dealer, showroom, await store.images.findShowroomCar(carId, showroom.id, false), 'read');
      const [rows, cap] = [await store.images.listImages(car.id), await store.images.showroomImageCap()];
      return { images: rows.map(toOwnCarImage), maxImages: cap };
    },

    async remove(actor, rawCarId, rawImageId, ctx = {}) {
      const carId = parseCarId(rawCarId);
      const imageId = parseImageId(rawImageId);
      if (carId === null || imageId === null) throw notFound();
      const dealer = requireDealer(actor);
      await store.transaction(async ({ images, audit }) => {
        const car = await lockedCar(images, dealer, carId);
        // Scoped by the authorized car: an image of any other car (even the dealer's own) is simply not found.
        const removed = await images.deleteImage(imageId, car.id);
        if (!removed) throw notFound();
        await images.repairLayout(car.id);
        await audit.record({
          action: 'showroom_car.image_delete',
          actorUserId: dealer.id,
          actorRole: 'dealer',
          entityType: 'car',
          entityId: car.id,
          afterData: { imageId: Number(imageId), images: await images.countImages(car.id) },
          requestId: ctx.requestId,
        });
      });
    },
  };
}

// HTTP contract for the images of a SHOWROOM car (Phase 11.7.2-I). Thin: decisions live in showroom-car-images/service.ts and
// src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   GET    /v1/dealer/cars/:id/images              Bearer (active dealer)   -> 200 {images, maxImages}
//   POST   /v1/dealer/cars/:id/images              Bearer, JSON {assetId}   -> 201 {image}   attaches the dealer's own READY asset
//   DELETE /v1/dealer/cars/:id/images/:imageId     Bearer, no body          -> 204           removes the link (the asset is kept)
//
// Errors: as GET/POST/DELETE /v1/me/cars/:id/images. 401 no/invalid token; 404 for anyone who is not an acting dealer with a
// showroom, any car that is not that showroom's, any image that is not on that car, any asset that is not the caller's, and
// malformed ids (all identical to an unknown id); 400 invalid input; 409 image_limit / invalid_state; 415 non-JSON body.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { toCarImageHttp } from '../car-images/routes.ts';
import { CarImageError } from '../car-images/service.ts';
import type { ShowroomCarImageApi } from './service.ts';

/** PROPOSED, per client address and per instance (same budget as the member image routes). */
export const SHOWROOM_CAR_IMAGE_RATE_LIMITS = {
  write: { limit: 60, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type ShowroomCarImageRateLimitedRoute = keyof typeof SHOWROOM_CAR_IMAGE_RATE_LIMITS;

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateLimitHook(limiter: RateLimiter, route: ShowroomCarImageRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`showroomCarImages.${route}:${request.ip}`, SHOWROOM_CAR_IMAGE_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'showroom_car_images.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** DELETE carries no body: the targets are in the path. */
function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  throw new CarImageError('validation_failed', [{ field: 'body', code: 'invalid_type' }]);
}

export function registerShowroomCarImageRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; showroomCarImages: ShowroomCarImageApi; rateLimiter?: RateLimiter }): void {
  const { auth, showroomCarImages, rateLimiter } = deps;
  const limited = (route: ShowroomCarImageRateLimitedRoute): Hook[] => (rateLimiter ? [rateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toCarImageHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling" (and so of the showroom): the verified access token, re-read from the database.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };
  const param = (request: FastifyRequest, name: string): unknown => (request.params as Record<string, unknown> | undefined)?.[name];

  app.get('/v1/dealer/cars/:id/images', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await showroomCarImages.list(actor, param(request, 'id')));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/dealer/cars/:id/images', { bodyLimit: 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const image = await showroomCarImages.add(actor, param(request, 'id'), request.body, { requestId: request.id });
      return reply.code(201).send({ image });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.delete('/v1/dealer/cars/:id/images/:imageId', { bodyLimit: 1024, onRequest: limited('write') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      assertNoBody(request.body);
      await showroomCarImages.remove(actor, param(request, 'id'), param(request, 'imageId'), { requestId: request.id });
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

// Phase 11.7.2-I: the showroom-car image HTTP layer, run WITHOUT Fastify (routes on a recording stand-in, handlers called with plain
// request objects), wired to the REAL authentication service, policy layer and image service over the in-memory store. Plus SQL,
// source and public-display guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { buildListPublicCarImages } from '../../src/assets/delivery-repository.ts';
import { registerShowroomCarImageRoutes, SHOWROOM_CAR_IMAGE_RATE_LIMITS } from '../../src/showroom-car-images/routes.ts';
import { buildFindShowroomCar, createPgShowroomImageRepository, SHOWROOM_IMAGE_CAP_SQL } from '../../src/showroom-car-images/repository.ts';
import { createShowroomCarImageService } from '../../src/showroom-car-images/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeShowroomImageStore } from '../helpers/fake-showroom-car-images.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JSON_HEADERS = { 'content-type': 'application/json' };
const IMAGES = '/v1/dealer/cars/:id/images';
const ONE = '/v1/dealer/cars/:id/images/:imageId';

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const imgs = makeFakeShowroomImageStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
  });
  const showroomCarImages = createShowroomCarImageService({ store: imgs.store });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerShowroomCarImageRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, showroomCarImages, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  const who = (id: string, token: string) => ({ id, headers: bearer(token), json: { ...bearer(token), ...JSON_HEADERS } });
  /** An APPROVED dealer (account active + one showroom) with one showroom car. */
  async function dealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    db.users().find((u) => u.id === r.user.id)!.status = 'active';
    const showroom = imgs.addShowroom({ ownerId: r.user.id });
    const car = imgs.addShowroomCar({ showroomId: showroom.id });
    return { ...who(r.user.id, r.session.accessToken), showroom, car };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    return who(r.user.id, r.session.accessToken);
  }
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    return who(r.user.id, r.session.accessToken);
  }
  async function admin() {
    const r = await auth.register({ name: 'مدير', phone: phone(), password: PW });
    db.users().find((u) => u.id === r.user.id)!.role = 'admin';
    return who(r.user.id, r.session.accessToken);
  }
  async function attach(d: { id: string; json: Record<string, string> }, carId: string) {
    const asset = imgs.addAsset({ ownerId: d.id });
    const sent = await call('POST', IMAGES, { headers: d.json, params: { id: carId }, body: { assetId: asset.id } });
    assert.equal(sent.status, 201, JSON.stringify(sent.body));
    return { asset, image: (sent.body as { image: { id: string } }).image };
  }
  return { routes, call, dealer, pendingDealer, member, admin, attach, imgs };
}

describe('showroom-car image routes: registration and authentication', () => {
  it('registers exactly the three dealer routes; every one is rate limited when a limiter is supplied', () => {
    const { routes } = setup(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`DELETE ${ONE}`, `GET ${IMAGES}`, `POST ${IMAGES}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts?.bodyLimit, 1024);
  });

  it('no token or a bad token is 401 with WWW-Authenticate on every route', async () => {
    const s = setup();
    for (const [method, path] of [['GET', IMAGES], ['POST', IMAGES], ['DELETE', ONE]] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const sent = await s.call(method, path, { headers: { ...headers, ...JSON_HEADERS }, params: { id: '8000', imageId: '1' }, body: { assetId: '00000000-0000-4000-8000-000000000001' } });
        assert.equal(sent.status, 401, `${method} ${path}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
      }
    }
  });

  it('a pending dealer, a member and an administrator get 404 everywhere (the dealer area does not exist for them)', async () => {
    const s = setup();
    const d = await s.dealer();
    for (const who of [await s.pendingDealer(), await s.member(), await s.admin()]) {
      assert.equal((await s.call('GET', IMAGES, { headers: who.headers, params: { id: d.car.id } })).status, 404);
      assert.equal((await s.call('POST', IMAGES, { headers: who.json, params: { id: d.car.id }, body: { assetId: '00000000-0000-4000-8000-000000000001' } })).status, 404);
      assert.equal((await s.call('DELETE', ONE, { headers: who.headers, params: { id: d.car.id, imageId: '1' } })).status, 404);
    }
  });
});

describe('showroom-car image routes: behavior', () => {
  it('POST is 201 {image}, GET lists it with maxImages 5, DELETE is 204 with no body; the whole flow works for the owner', async () => {
    const s = setup();
    const d = await s.dealer();
    const { image } = await s.attach(d, d.car.id);
    const list = await s.call('GET', IMAGES, { headers: d.headers, params: { id: d.car.id } });
    assert.equal(list.status, 200);
    assert.equal((list.body as { maxImages: number }).maxImages, 5);
    assert.equal((list.body as { images: Array<{ id: string }> }).images[0]!.id, image.id);
    const del = await s.call('DELETE', ONE, { headers: d.headers, params: { id: d.car.id, imageId: image.id } });
    assert.equal(del.status, 204);
    assert.equal(del.body, undefined);
    assert.equal((await s.call('DELETE', ONE, { headers: d.headers, params: { id: d.car.id, imageId: image.id } })).status, 404);
  });

  it("another dealer gets 404 identical to an unknown car for list, add and delete; a cross-car delete is 404", async () => {
    const s = setup();
    const a = await s.dealer();
    const b = await s.dealer();
    const other = s.imgs.addShowroomCar({ showroomId: a.showroom.id });
    const { image } = await s.attach(a, a.car.id);
    const unknown = await s.call('GET', IMAGES, { headers: b.headers, params: { id: '999999' } });
    const asset = s.imgs.addAsset({ ownerId: b.id });
    for (const r of [
      await s.call('GET', IMAGES, { headers: b.headers, params: { id: a.car.id } }),
      await s.call('POST', IMAGES, { headers: b.json, params: { id: a.car.id }, body: { assetId: asset.id } }),
      await s.call('DELETE', ONE, { headers: b.headers, params: { id: a.car.id, imageId: image.id } }),
      await s.call('DELETE', ONE, { headers: a.headers, params: { id: other.id, imageId: image.id } }),
    ]) {
      assert.equal(r.status, 404);
      assert.deepEqual(r.body, unknown.body);
    }
    assert.equal(s.imgs.imagesOf(a.car.id).length, 1);
  });

  it("another user's asset is 404 (like an unknown asset); an unready or attached asset is 409; the sixth is image_limit", async () => {
    const s = setup();
    const a = await s.dealer();
    const b = await s.dealer();
    const post = (assetId: string) => s.call('POST', IMAGES, { headers: a.json, params: { id: a.car.id }, body: { assetId } });
    const foreign = await post(s.imgs.addAsset({ ownerId: b.id }).id);
    const unknown = await post('00000000-0000-4000-8000-0000000fffff');
    assert.equal(foreign.status, 404);
    assert.deepEqual(foreign.body, unknown.body);
    assert.equal((await post(s.imgs.addAsset({ ownerId: a.id, status: 'pending' }).id)).status, 409);
    const { asset } = await s.attach(a, a.car.id);
    assert.equal((await post(asset.id)).status, 409);
    for (let i = 0; i < 4; i++) await s.attach(a, a.car.id);
    const full = await post(s.imgs.addAsset({ ownerId: a.id }).id);
    assert.equal(full.status, 409);
    assert.equal((full.body as ErrBody).error.code, 'image_limit');
    assert.equal(s.imgs.imagesOf(a.car.id).length, 5);
  });

  it('validation errors are 400 with field names and codes only; a showroom, owner or main flag in the body is refused', async () => {
    const s = setup();
    const d = await s.dealer();
    const bad = await s.call('POST', IMAGES, { headers: d.json, params: { id: d.car.id }, body: { assetId: 'SECRET-nope', showroomId: '1', isMain: true } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as ErrBody).error.fields, [{ field: 'showroomId', code: 'unknown_field' }, { field: 'isMain', code: 'unknown_field' }, { field: 'assetId', code: 'invalid_format' }]);
    assert.ok(!JSON.stringify(bad.body).includes('SECRET'));
  });

  it('a non-JSON POST is 415; a body on DELETE is refused', async () => {
    const s = setup();
    const d = await s.dealer();
    const { image } = await s.attach(d, d.car.id);
    assert.equal((await s.call('POST', IMAGES, { headers: { ...d.headers, 'content-type': 'text/plain' }, params: { id: d.car.id }, body: 'x' })).status, 415);
    assert.equal((await s.call('DELETE', ONE, { headers: d.headers, params: { id: d.car.id, imageId: image.id }, body: { force: true } })).status, 400);
    assert.equal(s.imgs.imagesOf(d.car.id).length, 1);
  });

  it('writes have their own budget per address; reads are not blocked by it', async () => {
    const s = setup(true);
    const d = await s.dealer();
    for (let i = 0; i < SHOWROOM_CAR_IMAGE_RATE_LIMITS.write.limit; i++) {
      assert.equal((await s.call('POST', IMAGES, { headers: d.json, params: { id: d.car.id }, body: { assetId: '00000000-0000-4000-8000-0000000fffff' } })).status, 404);
    }
    const denied = await s.call('POST', IMAGES, { headers: d.json, params: { id: d.car.id }, body: { assetId: '00000000-0000-4000-8000-0000000fffff' } });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal((await s.call('GET', IMAGES, { headers: d.headers, params: { id: d.car.id } })).status, 200);
  });
});

describe('showroom-car image SQL and source guards', () => {
  it('the car is found only by showroom, showroom source and not deleted; the write path locks it', () => {
    for (const lock of [false, true]) {
      const s = buildFindShowroomCar('1', '9', lock);
      assert.match(s.text, /c\.showroom_id = \$2::bigint AND c\.source_type = 'showroom' AND c\.deleted_at IS NULL/);
      assert.deepEqual(s.values, ['1', '9']);
      assert.equal(/FOR UPDATE OF c/.test(s.text), lock);
    }
  });

  it('the showroom cap is read from the very setting the database trigger enforces', () => {
    assert.match(SHOWROOM_IMAGE_CAP_SQL, /value ->> 'showroom'.*app_settings WHERE key = 'images\.max_per_car'/);
  });

  it("the showroom is found by the actor's id only, and the cap falls back to 5", async () => {
    const seen: Array<{ text: string; values: readonly unknown[] | undefined }> = [];
    const repo = createPgShowroomImageRepository({ query: async (text: string, values?: readonly unknown[]) => { seen.push({ text, values }); return { rows: [], rowCount: 0 } as never; } });
    assert.equal(await repo.findShowroomOfOwner('7'), null);
    assert.match(seen[0]!.text, /FROM showrooms s WHERE s\.owner_id = \$1::bigint/);
    assert.deepEqual(seen[0]!.values, ['7']);
    assert.equal(await repo.showroomImageCap(), 5);
  });

  it('the repository adds no write of its own and never reads storage keys; the image statements are the car-scoped ones', () => {
    const src = code('src/showroom-car-images/repository.ts');
    assert.ok(!/SELECT\s+\*/i.test(src));
    assert.ok(!/\b(storage_key|thumb_key|sha256)\b/.test(src));
    assert.ok(!/\b(INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/i.test(src), 'every write is the reused, car-scoped car-images statement');
  });

  it('the service and routes never take an owner, showroom or car source from the request, and never see a storage key', () => {
    const svc = code('src/showroom-car-images/service.ts');
    const routes = code('src/showroom-car-images/routes.ts');
    assert.ok(!/request\.|headers|\.query\b/.test(svc), 'the service sees no HTTP object');
    assert.ok(!/storage|thumb_key|sha256/i.test(svc + routes));
    assert.ok(!/ownerId|owner_id|showroomId|showroom_id/.test(routes));
    assert.match(routes, /return toActor\(found\.user\);/);
    assert.match(svc, /findOwnAsset\(assetId, dealer\.id\)/);
    assert.match(svc, /deleteImage\(imageId, car\.id\)/);
    assert.match(svc, /findShowroomOfOwner\(actor\.id\)/);
    assert.match(svc, /car\.showroomId !== showroom\.id/);
    assert.match(svc, /authorize\(actor, action, showroomCarResource\(/);
  });

  it('the routes are wired only together with authentication, and the process supplies the Postgres-backed service', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.showroomCarImages\) registerShowroomCarImageRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createShowroomCarImageService\(\{ store: createPgShowroomImageStore\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\bshowroomCarImages\b/);
  });

  it('PUBLIC DISPLAY: the existing public images query serves any car of the public_cars view (member or showroom) with no source filter, and only ready car_image assets', () => {
    const s = buildListPublicCarImages('8000');
    assert.match(s.text, /FROM public_cars pc/);
    assert.match(s.text, /a\.status = 'ready' AND a\.kind = 'car_image'/);
    assert.ok(!/source_type/.test(s.text), 'no member-only filter');
    assert.deepEqual(s.values, ['8000']);
  });

  it('an audit event for the new actions is accepted by the single audit writer type (numbers only)', () => {
    const src = code('src/auth/repository.ts');
    assert.match(src, /ShowroomCarImageAuditAction = 'showroom_car\.image_add' \| 'showroom_car\.image_delete'/);
  });
});

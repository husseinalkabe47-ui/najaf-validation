// Phase 11.7.2-G: administrator moderation of member ads (approve / reject / suspend / restore), the owner's resubmission after a
// rejection, and the HTTP contract. Real service + real policy over the in-memory store (mirrors the SQL CAS and triggers).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { TRANSITIONS, ModerationError, buildHasVerifiedReward, buildTransition, createModerationService, parseActionInput, parseAdminListQuery } from '../../src/member-cars/moderation.ts';
import { MODERATION_RATE_LIMITS, registerModerationRoutes, toModerationHttp } from '../../src/member-cars/moderation-routes.ts';
import { MemberCarError, createMemberCarService } from '../../src/member-cars/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeMemberCarStore } from '../helpers/fake-member-cars.ts';

const OWNER: Actor = Object.freeze({ id: '1', role: 'member' });
const OTHER: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ADMIN: Actor = Object.freeze({ id: '4', role: 'admin' });
const ROOT = join(import.meta.dirname, '..', '..');
const VALID = Object.freeze({ brand: 'Toyota', model: 'Camry', year: 2015, price: 12000, currency: 'USD', phone: '07701234567' });
const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isMod = (code: string) => (e: unknown) => e instanceof ModerationError && e.code === code;

function setup() {
  const f = makeFakeMemberCarStore();
  for (const a of [OWNER, OTHER, DEALER, ADMIN]) f.addUser(a.id);
  f.setOwnerName(OWNER.id, 'صاحب الإعلان');
  const mod = createModerationService({ store: f.moderationStore });
  const cars = createMemberCarService({ store: f.store });
  const car = (status: string, extra: Record<string, unknown> = {}) => f.addCar({ ownerId: OWNER.id, status, ...extra } as never);
  return { f, mod, cars, car };
}

describe('moderation: transitions are fixed by the server', () => {
  it('the table is exactly approve/reject from pending, suspend from active, restore from suspended', () => {
    assert.deepEqual(TRANSITIONS, {
      approve: { from: 'pending', to: 'active' }, reject: { from: 'pending', to: 'rejected' },
      suspend: { from: 'active', to: 'suspended' }, restore: { from: 'suspended', to: 'active' },
    });
  });

  it('reject, suspend and restore follow the table and stamp the review; the version increases', async () => {
    const { f, mod, car } = setup();
    const p = car('pending');
    const r = await mod.act(ADMIN, 'reject', p.id, { version: 1, reason: '  صور غير واضحة ' });
    assert.equal(r.status, 'rejected');
    assert.equal(r.rejectionReason, 'صور غير واضحة');
    assert.equal(r.version, 2);
    assert.equal(r.ownerName, 'صاحب الإعلان');
    assert.ok(r.reviewedAt);
    assert.equal(f.car(p.id)!.reviewedBy, ADMIN.id);
    assert.ok(!JSON.stringify(r).includes('reviewedBy'));

    const a = car('active');
    const s = await mod.act(ADMIN, 'suspend', a.id, { version: 1, reason: 'مخالفة' });
    assert.equal(s.status, 'suspended');
    assert.equal(s.suspensionReason, 'مخالفة');
    const back = await mod.act(ADMIN, 'restore', a.id, { version: 2 });
    assert.equal(back.status, 'active');
    assert.equal(back.suspensionReason, null);
    assert.equal(back.version, 3);
  });

  it('rejection reason is optional (absent or blank = null); suspension reason is REQUIRED', async () => {
    const { mod, car } = setup();
    const a = car('pending');
    assert.equal((await mod.act(ADMIN, 'reject', a.id, { version: 1 })).rejectionReason, null);
    const b = car('pending');
    assert.equal((await mod.act(ADMIN, 'reject', b.id, { version: 1, reason: '   ' })).rejectionReason, null);
    const c = car('active');
    for (const body of [{ version: 1 }, { version: 1, reason: '' }, { version: 1, reason: '   ' }, { version: 1, reason: null }]) {
      await assert.rejects(mod.act(ADMIN, 'suspend', c.id, body), (e) => e instanceof ModerationError && e.code === 'validation_failed' && e.fields![0]!.field === 'reason');
    }
  });

  it('every other source status is 409 invalid_state, in particular: a REJECTED ad cannot be approved or restored by an admin', async () => {
    const { mod, car } = setup();
    const matrix: Array<[string, string[]]> = [
      ['approve', ['active', 'sold', 'rejected', 'suspended']],
      ['reject', ['active', 'sold', 'rejected', 'suspended']],
      ['suspend', ['pending', 'sold', 'rejected', 'suspended']],
      ['restore', ['pending', 'active', 'sold', 'rejected']],
    ];
    for (const [action, froms] of matrix) {
      for (const from of froms) {
        const c = car(from);
        const body = action === 'suspend' ? { version: 1, reason: 'x' } : { version: 1 };
        await assert.rejects(mod.act(ADMIN, action as never, c.id, body), isMod('invalid_state'), `${action} from ${from}`);
      }
    }
  });

  it('an admin can never mark an ad sold or edit it (no such action; the policy has no admin update)', async () => {
    const { mod, cars, car } = setup();
    const c = car('active');
    await assert.rejects(mod.act(ADMIN, 'sold' as never, c.id, { version: 1 }), isAuthz('not_found'));
    await assert.rejects(cars.update(ADMIN, c.id, { version: 1, status: 'sold' }), isAuthz('not_found'));
    await assert.rejects(cars.update(ADMIN, c.id, { version: 1, price: 1 }), isAuthz('not_found'));
  });
});

describe('moderation: the reward gate (publishing)', () => {
  it('approve is refused with reward_required while no server-verified grant exists, and nothing changes', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    await assert.rejects(mod.act(ADMIN, 'approve', c.id, { version: 1 }), isMod('reward_required'));
    assert.equal(f.car(c.id)!.status, 'pending');
    assert.equal(f.car(c.id)!.version, 1);
    assert.equal(f.audits().length, 0);
  });

  it('a client-supplied success flag cannot stand in for a grant', async () => {
    const { mod, car } = setup();
    const c = car('pending');
    for (const extra of [{ rewardVerified: true }, { reward: 'ok' }, { ssv: 'x' }, { status: 'active' }]) {
      await assert.rejects(mod.act(ADMIN, 'approve', c.id, { version: 1, ...extra }), (e) => e instanceof ModerationError && e.code === 'validation_failed');
    }
  });

  it('only a consumed, SSV-verified grant bound to THIS ad and THIS owner publishes it', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    const bad = [
      { carId: '999999', userId: OWNER.id },
      { carId: c.id, userId: OTHER.id },
      { carId: c.id, userId: OWNER.id, status: 'requested' },
      { carId: c.id, userId: OWNER.id, status: 'verified' },
      { carId: c.id, userId: OWNER.id, ssv: null },
      { carId: c.id, userId: OWNER.id, verified: false },
      { carId: c.id, userId: OWNER.id, consumed: false },
    ];
    for (const g of bad) f.addReward(g);
    await assert.rejects(mod.act(ADMIN, 'approve', c.id, { version: 1 }), isMod('reward_required'));
    f.addReward({ carId: c.id, userId: OWNER.id });
    const out = await mod.act(ADMIN, 'approve', c.id, { version: 1 });
    assert.equal(out.status, 'active');
    assert.equal(f.audits().at(-1)!.action, 'member_car.admin_approve');
  });

  it('reject, suspend and restore do not need a grant', async () => {
    const { mod, car } = setup();
    const p = car('pending');
    await mod.act(ADMIN, 'reject', p.id, { version: 1 });
    const a = car('active');
    await mod.act(ADMIN, 'suspend', a.id, { version: 1, reason: 'x' });
    await mod.act(ADMIN, 'restore', a.id, { version: 2 });
  });

  it('SQL pins: the reward query is read only and fully bound; transition is a CAS on version AND source status', () => {
    const q = buildHasVerifiedReward('5', '1');
    assert.match(q.text, /status = 'consumed'/);
    assert.match(q.text, /ssv_transaction_id IS NOT NULL/);
    assert.match(q.text, /verified_at IS NOT NULL/);
    assert.match(q.text, /^\s*SELECT/);
    assert.deepEqual(q.values, ['5', '1']);
    const t = buildTransition({ id: '5', expectedVersion: 3, action: 'suspend', reason: 'why', reviewerId: '4' });
    assert.match(t.text, /c\.version = \$2/);
    assert.match(t.text, /c\.status = 'active'/);
    assert.match(t.text, /SET status = 'suspended'/);
    assert.match(t.text, /suspension_reason = \$3::varchar/);
    assert.match(t.text, /rejection_reason = NULL/);
    assert.deepEqual(t.values, ['5', 3, 'why', '4']);
    for (let i = 1; i <= t.values.length; i++) assert.ok(t.text.includes(`$${i}`), `$${i} is used`);
    assert.ok(!t.text.includes('$5'));
    // approve/restore bind no reason: no unused parameter (42P18) — every placeholder 1..n is used and the reviewer is $3.
    for (const action of ['approve', 'restore'] as const) {
      const n = buildTransition({ id: '5', expectedVersion: 3, action, reason: null, reviewerId: '4' });
      assert.deepEqual(n.values, ['5', 3, '4']);
      assert.match(n.text, /reviewed_by = \$3::bigint/);
      assert.ok(!n.text.includes('$4'));
    }
    const rj = buildTransition({ id: '5', expectedVersion: 3, action: 'reject', reason: null, reviewerId: '4' });
    assert.deepEqual(rj.values, ['5', 3, null, '4']);
    assert.match(rj.text, /rejection_reason = \$3::varchar/);
    assert.throws(() => buildTransition({ id: '5', expectedVersion: 1, action: 'sold' as never, reason: null, reviewerId: '4' }));
  });
});

describe('moderation: authorization (non-admins learn nothing)', () => {
  it('members, dealers and anonymous callers get not_found on every operation, before any read', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    for (const who of [OWNER, OTHER, DEALER, null]) {
      await assert.rejects(mod.list(who, {}), isAuthz('not_found'));
      await assert.rejects(mod.get(who, c.id), isAuthz('not_found'));
      for (const action of ['approve', 'reject', 'suspend', 'restore'] as const) await assert.rejects(mod.act(who, action, c.id, { version: 1, reason: 'x' }), isAuthz('not_found'));
    }
    assert.equal(f.calls.filter((x) => x.startsWith('m.')).length, 0);
    assert.equal(f.car(c.id)!.status, 'pending');
  });

  it('unknown, malformed, deleted and showroom ids are the same not_found', async () => {
    const { f, mod, car } = setup();
    const gone = car('pending', { deletedAt: new Date() });
    const showroom = car('pending', { sourceType: 'showroom' });
    for (const id of ['999999', 'abc', '0', '-1', '1.5', '', null, undefined, {}, gone.id, showroom.id]) {
      await assert.rejects(mod.get(ADMIN, id), isAuthz('not_found'));
      await assert.rejects(mod.act(ADMIN, 'reject', id, { version: 1 }), isAuthz('not_found'));
    }
    assert.equal(f.audits().length, 0);
  });

  it('an admin whose account was deactivated meanwhile is refused inside the transaction', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    f.setUser(ADMIN.id, 'suspended');
    await assert.rejects(mod.act(ADMIN, 'reject', c.id, { version: 1 }), isAuthz('not_found'));
    assert.equal(f.car(c.id)!.status, 'pending');
  });
});

describe('moderation: concurrency, audit, atomicity', () => {
  it('a stale version is 409 version_conflict and changes nothing', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    await assert.rejects(mod.act(ADMIN, 'reject', c.id, { version: 7 }), isMod('version_conflict'));
    assert.equal(f.car(c.id)!.version, 1);
  });

  it('two administrators racing: exactly one wins, the other gets a conflict; one audit row', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    const results = await Promise.allSettled([mod.act(ADMIN, 'reject', c.id, { version: 1, reason: 'a' }), mod.act(ADMIN, 'reject', c.id, { version: 1, reason: 'b' })]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    const lost = results.find((r) => r.status === 'rejected') as PromiseRejectedResult;
    assert.ok(lost.reason instanceof ModerationError);
    assert.equal(f.audits().filter((a) => a.action === 'member_car.admin_reject').length, 1);
  });

  it('a lost race between the lock and the swap is a conflict and writes no audit row', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    f.faults.beforeUpdate = () => { f.car(c.id)!.version += 1; };
    await assert.rejects(mod.act(ADMIN, 'reject', c.id, { version: 1 }), isMod('version_conflict'));
    assert.equal(f.audits().length, 0);
  });

  it('an audit failure rolls the transition back', async () => {
    const { f, mod, car } = setup();
    const c = car('pending');
    f.faults.failNextAudit = true;
    await assert.rejects(mod.act(ADMIN, 'reject', c.id, { version: 1 }));
    assert.equal(f.car(c.id)!.status, 'pending');
    assert.equal(f.car(c.id)!.version, 1);
  });

  it('the audit row carries numbers only: no reason text, no names', async () => {
    const { f, mod, car } = setup();
    const c = car('active');
    await mod.act(ADMIN, 'suspend', c.id, { version: 1, reason: 'نص سري للسبب' });
    const row = f.audits().at(-1)!;
    assert.equal(row.action, 'member_car.admin_suspend');
    assert.equal(row.actorUserId, ADMIN.id);
    assert.equal(row.entityId, c.id);
    assert.ok(!JSON.stringify(row).includes('سري'));
  });
});

describe('moderation: validation', () => {
  it('body is a strict whitelist; version is required; reasons are bounded and clean', () => {
    const bad = (a: never, b: unknown) => assert.equal(parseActionInput(a, b).ok, false, JSON.stringify(b));
    for (const b of [null, undefined, 'x', [], {}, { version: 0 }, { version: '1' }, { version: 1.5 }, { version: -1 }, { version: 1, extra: 1 }, { version: 1, id: '5' }, { version: 1, status: 'active' }]) bad('approve' as never, b);
    bad('restore' as never, { version: 1, reason: 'x' });
    bad('reject' as never, { version: 1, reason: 5 });
    bad('reject' as never, { version: 1, reason: 'x'.repeat(501) });
    bad('reject' as never, { version: 1, reason: 'a\u0000b' });
    bad('reject' as never, { version: 1, reason: 'a\nb' });
    assert.equal(parseActionInput('reject', { version: 1, reason: 'x'.repeat(500) }).ok, true);
  });

  it('list query: status default pending, unknown keys and bad values rejected', () => {
    assert.deepEqual(parseAdminListQuery({}), { ok: true, value: { status: 'pending', afterId: null, limit: 50 } });
    assert.equal(parseAdminListQuery({ status: 'suspended', limit: '100', after: '12' }).ok, true);
    for (const q of [{ status: 'deleted' }, { status: 1 }, { limit: '0' }, { limit: '101' }, { limit: 'x' }, { after: 'x' }, { owner: '1' }, 'x', []]) assert.equal(parseAdminListQuery(q).ok, false, JSON.stringify(q));
  });

  it('list pages by id and reports nextAfter only for a full page; shows only member, live ads of the status', async () => {
    const { mod, car } = setup();
    for (let i = 0; i < 3; i++) car('pending');
    car('active');
    car('pending', { sourceType: 'showroom' });
    car('pending', { deletedAt: new Date() });
    const p1 = await mod.list(ADMIN, { limit: '2' });
    assert.equal(p1.items.length, 2);
    assert.ok(p1.nextAfter);
    const p2 = await mod.list(ADMIN, { limit: '2', after: p1.nextAfter! });
    assert.equal(p2.items.length, 1);
    assert.equal(p2.nextAfter, null);
    assert.ok(p1.items.every((x) => x.status === 'pending' && x.ownerName === 'صاحب الإعلان'));
  });
});

describe('owner resubmission after a rejection', () => {
  it('editing a rejected ad with a real change returns it to pending, clears the reason; then admin can review again', async () => {
    const { f, mod, cars, car } = setup();
    const c = car('rejected', { rejectionReason: 'صور', reviewedBy: ADMIN.id, reviewedAt: new Date() });
    const out = await cars.update(OWNER, c.id, { version: 1, price: 9000 });
    assert.equal(out.status, 'pending');
    assert.equal(out.rejectionReason, null);
    assert.equal(f.car(c.id)!.rejectionReason, null);
    assert.equal(f.audits().at(-1)!.action, 'member_car.resubmit');
    const again = await mod.act(ADMIN, 'reject', c.id, { version: out.version, reason: 'ثانية' });
    assert.equal(again.status, 'rejected');
  });

  it('an edit that changes nothing does not resubmit (validation error, still rejected)', async () => {
    const { f, cars, car } = setup();
    const c = car('rejected', { rejectionReason: 'x' });
    await assert.rejects(cars.update(OWNER, c.id, { version: 1, price: 12000 }), (e) => e instanceof MemberCarError && e.code === 'validation_failed');
    assert.equal(f.car(c.id)!.status, 'rejected');
  });

  it('only the owner can resubmit; admin cannot; a rejected ad cannot be marked sold', async () => {
    const { f, cars, car } = setup();
    const c = car('rejected');
    await assert.rejects(cars.update(OTHER, c.id, { version: 1, price: 1 }), isAuthz('not_found'));
    await assert.rejects(cars.update(ADMIN, c.id, { version: 1, price: 1 }), isAuthz('not_found'));
    await assert.rejects(cars.update(OWNER, c.id, { version: 1, status: 'sold' }));
    assert.equal(f.car(c.id)!.status, 'rejected');
  });

  it('only owners mark sold, and only from active', async () => {
    const { cars, car } = setup();
    const a = car('active');
    assert.equal((await cars.update(OWNER, a.id, { version: 1, status: 'sold' })).status, 'sold');
    const p = car('pending');
    await assert.rejects(cars.update(OWNER, p.id, { version: 1, status: 'sold' }));
  });
});

// ------------------------------------------------------------------ HTTP

type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Array<(r: unknown, p: unknown) => Promise<unknown>> };

function httpSetup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: 'unit-test-access-secret-0123456789abcdef-XYZ', logger: recordingLogger().logger, now: clock.now });
  const f = makeFakeMemberCarStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
    now: clock.now,
  });
  const moderation = createModerationService({ store: f.moderationStore });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  registerModerationRoutes({ get: add('GET'), post: add('POST') } as never, { auth, moderation, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const sent: Sent = { headers: {} };
    const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  let n = 0;
  async function account(role: 'user' | 'admin') {
    const r = await auth.register({ name: 'حساب', phone: `0771${String(1000000 + ++n).slice(-7)}`, password: 'Corr3ct-Horse-Battery' });
    if (role === 'admin') db.users().find((u) => u.id === r.user.id)!.role = 'admin';
    return { id: r.user.id, h: { authorization: `Bearer ${r.session.accessToken}`, 'content-type': 'application/json' } };
  }
  return { routes, call, account, f, db };
}

describe('moderation routes', () => {
  it('registers exactly the six admin routes; writes are rate limited and bounded', () => {
    const s = httpSetup(true);
    assert.deepEqual(s.routes.map((r) => `${r.method} ${r.path}`).sort(), [
      'GET /v1/admin/member-cars', 'GET /v1/admin/member-cars/:id',
      'POST /v1/admin/member-cars/:id/approve', 'POST /v1/admin/member-cars/:id/reject', 'POST /v1/admin/member-cars/:id/restore', 'POST /v1/admin/member-cars/:id/suspend',
    ]);
    for (const r of s.routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    for (const r of s.routes.filter((x) => x.method === 'POST')) assert.equal(r.opts?.bodyLimit, 4 * 1024);
    assert.ok(MODERATION_RATE_LIMITS.write.limit > 0);
  });

  it('401 without a token; 404 for a signed-in non-admin; the admin flow works end to end', async () => {
    const s = httpSetup();
    const admin = await s.account('admin');
    const member = await s.account('user');
    const car = s.f.addCar({ ownerId: member.id, status: 'pending' });
    s.f.addUser(member.id);
    s.f.addUser(admin.id);
    assert.equal((await s.call('GET', '/v1/admin/member-cars', { headers: {} })).status, 401);
    assert.equal((await s.call('GET', '/v1/admin/member-cars', { headers: member.h })).status, 404);
    assert.equal((await s.call('POST', '/v1/admin/member-cars/:id/reject', { headers: member.h, params: { id: car.id }, body: { version: 1 } })).status, 404);
    const list = await s.call('GET', '/v1/admin/member-cars', { headers: admin.h });
    assert.equal(list.status, 200);
    assert.equal((list.body as { items: unknown[] }).items.length, 1);
    const got = await s.call('GET', '/v1/admin/member-cars/:id', { headers: admin.h, params: { id: car.id } });
    assert.equal(got.status, 200);
    const r = await s.call('POST', '/v1/admin/member-cars/:id/reject', { headers: admin.h, params: { id: car.id }, body: { version: 1, reason: 'سبب' } });
    assert.equal(r.status, 200);
    assert.equal((r.body as { car: { status: string } }).car.status, 'rejected');
    const stale = await s.call('POST', '/v1/admin/member-cars/:id/reject', { headers: admin.h, params: { id: car.id }, body: { version: 1 } });
    assert.equal(stale.status, 409);
    assert.equal((stale.body as { error: { code: string } }).error.code, 'version_conflict');
  });

  it('approve without a verified grant is 409 reward_required; invalid body is 400 with field names only; non-JSON is 415', async () => {
    const s = httpSetup();
    const admin = await s.account('admin');
    const owner = await s.account('user');
    s.f.addUser(owner.id);
    s.f.addUser(admin.id);
    const car = s.f.addCar({ ownerId: owner.id, status: 'pending' });
    const a = await s.call('POST', '/v1/admin/member-cars/:id/approve', { headers: admin.h, params: { id: car.id }, body: { version: 1 } });
    assert.equal(a.status, 409);
    assert.equal((a.body as { error: { code: string } }).error.code, 'reward_required');
    const bad = await s.call('POST', '/v1/admin/member-cars/:id/suspend', { headers: admin.h, params: { id: car.id }, body: { version: 1 } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as { error: { fields: unknown } }).error.fields, [{ field: 'reason', code: 'required' }]);
    const t = await s.call('POST', '/v1/admin/member-cars/:id/reject', { headers: { ...admin.h, 'content-type': 'text/plain' }, params: { id: car.id }, body: 'x' });
    // no limiter => the 415 hook is the only hook; it must refuse
    assert.equal(t.status, 415);
  });

  it('error mapping: unknown errors are not ours', () => {
    assert.equal(toModerationHttp(new Error('x')), undefined);
    assert.equal(toModerationHttp(new ModerationError('invalid_state'))!.status, 409);
    assert.equal(toModerationHttp(new ModerationError('validation_failed', [{ field: 'a', code: 'required' }]))!.status, 400);
  });
});

describe('moderation: source guards', () => {
  const code = (rel: string) => readFileSync(join(ROOT, rel), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').split('\n').map((l) => l.replace(/^\s*\/\/.*$/, '')).join('\n');
  it('moderation.ts never writes reward_grants and never takes a status or id of the admin from a request', () => {
    const src = code('src/member-cars/moderation.ts');
    assert.ok(!/(INSERT\s+INTO|UPDATE|DELETE\s+FROM)\s+reward_grants/i.test(src));
    assert.ok(!/console\./.test(src));
    assert.ok(!/body\[['"](status|reviewedBy|reviewed_by|ownerId)['"]\]/.test(src));
  });
  it('routes import Fastify types only', () => {
    assert.ok(!/from 'fastify'/.test(code('src/member-cars/moderation-routes.ts').replace(/import type[^\n]*\n/g, '')));
  });
});

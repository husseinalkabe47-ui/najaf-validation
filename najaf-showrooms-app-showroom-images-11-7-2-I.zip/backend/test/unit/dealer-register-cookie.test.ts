// Phase 11.7-H: POST /v1/dealers/register over the opt-in cookie session transport, with the REAL authentication service and the
// in-memory store (no Fastify). The pending showroom-owner account is created by the server (role/status never from the client),
// the refresh token goes to the HttpOnly cookie only, and Origin/CSRF checks, rate limiting and the existing sign-in rules hold.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { loadSessionCookieConfig } from '../../src/auth/session-cookie.ts';
import type { SessionCookieConfig } from '../../src/auth/session-cookie.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { registerDealerRoutes } from '../../src/dealers/routes.ts';
import { createDealerService } from '../../src/dealers/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const ORIGIN = 'https://najaf.example.com';
const COOKIE_REQ = { 'x-session-transport': 'cookie', origin: ORIGIN, 'sec-fetch-site': 'same-origin', 'content-type': 'application/json' };
const PW = 'Corr3ct-Horse-Battery';
const cfg = (): SessionCookieConfig => loadSessionCookieConfig({ AUTH_COOKIE_ORIGINS: ORIGIN }) as SessionCookieConfig;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { onRequest?: Array<(r: unknown, p: unknown) => Promise<unknown>> };

function setup(opts: { cookie?: SessionCookieConfig | null; limiter?: boolean } = {}) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: 'unit-test-access-secret-0123456789abcdef-XYZ', logger: log.logger, now: clock.now });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => { routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler }); };
  const cookie = opts.cookie === undefined ? cfg() : opts.cookie;
  registerDealerRoutes({ get: add('GET'), post: add('POST') } as never, {
    auth, registration: auth, dealers: createDealerService({ store: db.dealerStore, logger: log.logger }),
    ...(opts.limiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}), ...(cookie ? { sessionCookie: cookie } : {}), now: clock.now,
  });
  async function post(headers: Record<string, string>, body: unknown): Promise<Sent> {
    const route = routes.find((r) => r.method === 'POST' && r.path === '/v1/dealers/register')!;
    const sent: Sent = { headers: {} };
    const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers, body, query: {}, params: {}, log: { warn() {} } };
    for (const hook of route.opts?.onRequest ?? []) { await hook(req, reply); if (sent.status !== undefined) return sent; }
    await route.handler(req, reply);
    return sent;
  }
  return { post, db, auth, clock };
}
const reg = (n = 1) => ({ name: 'حسين التاجر', phone: `0771000000${n}`, password: PW });

describe('dealer registration over the cookie transport (11.7-H)', () => {
  it('201: pending dealer, HttpOnly cookie set, NO refresh token in the body', async () => {
    const t = setup();
    const sent = await t.post(COOKIE_REQ, reg());
    assert.equal(sent.status, 201);
    const cookie = sent.headers['set-cookie'] as string;
    assert.match(cookie, /^__Secure-najaf_rt=nsj_[A-Za-z0-9_-]{43}; Path=\/v1\/auth; HttpOnly; SameSite=Strict; Secure; Max-Age=/);
    const body = sent.body as { user: { role: string; status: string }; session: Record<string, unknown> };
    assert.equal(body.user.role, 'dealer');
    assert.equal(body.user.status, 'pending');
    assert.deepEqual(Object.keys(body.session).sort(), ['accessExpiresAt', 'accessToken', 'refreshExpiresAt']);
    const rt = /=(nsj_[A-Za-z0-9_-]{43});/.exec(cookie)![1]!;
    assert.ok(!JSON.stringify(sent.body).includes(rt));
    assert.equal(t.db.users().filter((u) => u.role === 'dealer' && u.status === 'pending').length, 1);
  });

  it('the cookie is the real refresh token: it rotates once (session rotation), the old one is then rejected', async () => {
    const t = setup();
    const rt = /=(nsj_[A-Za-z0-9_-]{43});/.exec((await t.post(COOKIE_REQ, reg())).headers['set-cookie'] as string)![1]!;
    const next = await t.auth.refresh({ refreshToken: rt });
    assert.equal(next.user.role, 'dealer');
    assert.notEqual(next.session.refreshToken, rt);
    await assert.rejects(t.auth.refresh({ refreshToken: rt }));
  });

  it('a pending dealer signs in by the existing rules: login works, status stays pending', async () => {
    const t = setup();
    const r = reg();
    await t.post(COOKIE_REQ, r);
    const login = await t.auth.login({ phone: r.phone, password: PW });
    assert.equal(login.user.role, 'dealer');
    assert.equal(login.user.status, 'pending');
  });

  it('role, status and any extra field from the client are rejected; nothing is created and no cookie is set', async () => {
    const t = setup();
    for (const extra of [{ role: 'admin' }, { role: 'dealer' }, { status: 'active' }, { userId: '1' }, { showroomId: '1' }]) {
      const sent = await t.post(COOKIE_REQ, { ...reg(), ...extra });
      assert.equal(sent.status, 400, JSON.stringify(extra));
      assert.equal(sent.headers['set-cookie'], undefined);
    }
    assert.equal(t.db.users().length, 0);
  });

  it('a hostile or missing Origin / cross-site fetch never reaches the service (no account, no cookie)', async () => {
    const t = setup();
    for (const headers of [{ 'x-session-transport': 'cookie', 'content-type': 'application/json' }, { ...COOKIE_REQ, origin: 'https://evil.example' }, { ...COOKIE_REQ, 'sec-fetch-site': 'cross-site' }]) {
      const sent = await t.post(headers, reg());
      assert.equal(sent.status, 403);
      assert.equal(sent.headers['set-cookie'], undefined);
    }
    assert.equal(t.db.users().length, 0);
  });

  it('an unsupported transport value is 400; the header on a server without cookie transport is 400 (never a token in the body)', async () => {
    assert.equal((await setup().post({ ...COOKIE_REQ, 'x-session-transport': 'weird' }, reg())).status, 400);
    const t = setup({ cookie: null });
    const sent = await t.post(COOKIE_REQ, reg());
    assert.equal(sent.status, 400);
    assert.equal(t.db.users().length, 0);
  });

  it('a duplicate phone is 409 and sets no cookie; without the header the body transport is unchanged', async () => {
    const t = setup();
    await t.post({ 'content-type': 'application/json' }, reg());
    const dup = await t.post(COOKIE_REQ, reg());
    assert.equal(dup.status, 409);
    assert.equal(dup.headers['set-cookie'], undefined);
    const plain = await t.post({ 'content-type': 'application/json' }, reg(2));
    assert.equal(plain.status, 201);
    assert.equal(plain.headers['set-cookie'], undefined);
    assert.match((plain.body as { session: { refreshToken: string } }).session.refreshToken, /^nsj_/);
  });

  it('rate limiting (shared registration budget) and the JSON-only check still run before the body is read', async () => {
    const t = setup({ limiter: true });
    assert.equal((await t.post({ ...COOKIE_REQ, 'content-type': 'text/plain' }, 'x')).status, 415);
    let last = 0;
    for (let i = 0; i < 40 && last !== 429; i++) last = (await t.post(COOKIE_REQ, reg((i % 9) + 1))).status ?? 0;
    assert.equal(last, 429);
  });

  it('static guard: dealer routes reuse makeCookieTransport and never read a role, or write Set-Cookie themselves', () => {
    const src = readFileSync(join(import.meta.dirname, '..', '..', 'src/dealers/routes.ts'), 'utf8').replace(/\/\/.*$/gm, '');
    assert.match(src, /makeCookieTransport\(/);
    assert.ok(!/set-cookie/i.test(src));
    assert.ok(!/request\.body\)?\.role|body\.role/.test(src));
  });
});

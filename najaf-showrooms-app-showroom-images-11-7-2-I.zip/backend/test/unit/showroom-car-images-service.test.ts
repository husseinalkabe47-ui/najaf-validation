// Phase 11.7.2-I: images of a showroom owner's own showroom cars, through the real service and the real policy (src/authz), over an
// in-memory store that mirrors the SQL scoping and the database triggers (which THROW if the service lets a violation through).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { CarImageError } from '../../src/car-images/service.ts';
import { createShowroomCarImageService } from '../../src/showroom-car-images/service.ts';
import { makeFakeShowroomImageStore } from '../helpers/fake-showroom-car-images.ts';

const D1: Actor = Object.freeze({ id: '11', role: 'dealer' });
const D2: Actor = Object.freeze({ id: '12', role: 'dealer' });
const MEMBER: Actor = Object.freeze({ id: '13', role: 'member' });
const ADMIN: Actor = Object.freeze({ id: '14', role: 'admin' });

function setup(showroomStatus = 'active') {
  const f = makeFakeShowroomImageStore();
  for (const a of [D1, D2, MEMBER, ADMIN]) f.addUser(a.id);
  const s1 = f.addShowroom({ ownerId: D1.id, status: showroomStatus });
  const s2 = f.addShowroom({ ownerId: D2.id });
  const car1 = f.addShowroomCar({ showroomId: s1.id });
  const car1b = f.addShowroomCar({ showroomId: s1.id });
  const car2 = f.addShowroomCar({ showroomId: s2.id });
  const svc = createShowroomCarImageService({ store: f.store });
  const asset = (owner = D1.id) => f.addAsset({ ownerId: owner }).id;
  return { f, svc, s1, s2, car1, car1b, car2, asset };
}

const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isImgErr = (code: string) => (e: unknown) => e instanceof CarImageError && e.code === code;

describe('showroom car images: attach and list', () => {
  it("attaches the dealer's own ready asset to a car of its own showroom; the first image is main; audit row is numbers only", async () => {
    const { f, svc, car1, asset } = setup();
    const first = await svc.add(D1, car1.id, { assetId: asset() }, { requestId: 'req-1' });
    const second = await svc.add(D1, car1.id, { assetId: asset() });
    assert.deepEqual([first.sortOrder, first.isMain, second.sortOrder, second.isMain], [0, true, 1, false]);
    assert.deepEqual(Object.keys(first).sort(), ['assetId', 'createdAt', 'height', 'id', 'isMain', 'sortOrder', 'width']);
    assert.deepEqual(f.audits()[0], { action: 'showroom_car.image_add', actorUserId: D1.id, actorRole: 'dealer', entityType: 'car', entityId: car1.id, afterData: { imageId: Number(first.id), images: 1 }, requestId: 'req-1' });
  });

  it('lists the images of the car in order with the showroom limit (5)', async () => {
    const { svc, car1, asset } = setup();
    await svc.add(D1, car1.id, { assetId: asset() });
    await svc.add(D1, car1.id, { assetId: asset() });
    const out = await svc.list(D1, car1.id);
    assert.equal(out.maxImages, 5);
    assert.deepEqual(out.images.map((i) => i.sortOrder), [0, 1]);
  });

  it('works for a car of a pending or suspended showroom too (the owner manages it; the existing policy)', async () => {
    for (const st of ['pending', 'suspended']) {
      const { svc, car1, asset } = setup(st);
      assert.equal((await svc.add(D1, car1.id, { assetId: asset() })).isMain, true, st);
    }
  });

  it('unknown fields (car, showroom, owner, main flag, position) and bad ids are refused with field codes only', async () => {
    const { svc, car1, asset } = setup();
    for (const body of [{ assetId: asset(), isMain: true }, { assetId: asset(), showroomId: '900' }, { assetId: asset(), ownerId: '11' }, { assetId: asset(), sortOrder: 0 }, { assetId: 'x' }, {}, null, 'x']) {
      await assert.rejects(svc.add(D1, car1.id, body), isImgErr('validation_failed'));
    }
  });
});

describe('showroom car images: ownership and non-disclosure (IDOR/BOLA)', () => {
  it('another dealer, a member, an administrator and no actor all get 404 on list, add and delete, and nothing changes', async () => {
    const { f, svc, car1, asset } = setup();
    const img = await svc.add(D1, car1.id, { assetId: asset() });
    const before = JSON.stringify(f.images());
    const audits = f.audits().length;
    for (const other of [D2, MEMBER, ADMIN, null]) {
      await assert.rejects(svc.list(other, car1.id), isAuthz('not_found'));
      await assert.rejects(svc.add(other, car1.id, { assetId: asset(other?.id ?? D1.id) }), isAuthz('not_found'));
      await assert.rejects(svc.remove(other, car1.id, img.id), isAuthz('not_found'));
    }
    assert.equal(JSON.stringify(f.images()), before);
    assert.equal(f.audits().length, audits);
  });

  it("another showroom's car, a member ad, a deleted car, an unknown car and malformed ids are the same 404", async () => {
    const { f, svc, car2, asset } = setup();
    const member = f.addMemberCar(MEMBER.id);
    const deleted = f.addShowroomCar({ showroomId: '900', deleted: true });
    const outcome = (carId: unknown) => svc.list(D1, carId).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome('999999');
    assert.ok(reference.startsWith('not_found|'));
    for (const id of [car2.id, member.id, deleted.id]) assert.equal(await outcome(id), reference, id);
    f.calls.length = 0;
    for (const id of ['abc', '0', '-1', '01', ' 1', undefined, null, 1, {}, ['1']]) assert.equal(await outcome(id), reference, JSON.stringify(id));
    assert.deepEqual(f.calls, [], 'a malformed id never reaches the store');
    for (const id of [car2.id, member.id, deleted.id]) await assert.rejects(svc.add(D1, id, { assetId: asset() }), isAuthz('not_found'));
    assert.equal(f.images().length, 0);
  });

  it("CROSS-SHOWROOM: an image of another showroom's car is 404 and is not deleted", async () => {
    const { f, svc, car1, car2, asset } = setup();
    const theirs = await svc.add(D2, car2.id, { assetId: asset(D2.id) });
    await assert.rejects(svc.remove(D1, car1.id, theirs.id), isAuthz('not_found'));
    await assert.rejects(svc.remove(D1, car2.id, theirs.id), isAuthz('not_found'));
    assert.equal(f.imagesOf(car2.id).length, 1);
  });

  it("CROSS-CAR: an image of another car is 404 even when the dealer owns both cars, and is not deleted", async () => {
    const { f, svc, car1, car1b, asset } = setup();
    const onOne = await svc.add(D1, car1.id, { assetId: asset() });
    await svc.add(D1, car1b.id, { assetId: asset() });
    await assert.rejects(svc.remove(D1, car1b.id, onOne.id), isAuthz('not_found'));
    assert.equal(f.imagesOf(car1.id).length, 1);
    assert.equal(f.imagesOf(car1b.id).length, 1);
  });

  it("ASSET OWNERSHIP: another user's asset (even another dealer's) is the same 404 as an unknown asset and is not attached", async () => {
    const { f, svc, car1, asset } = setup();
    const other = asset(D2.id);
    const memberAsset = asset(MEMBER.id);
    const unknown = '00000000-0000-4000-8000-0000000000ff';
    const outcome = (assetId: string) => svc.add(D1, car1.id, { assetId }).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome(unknown);
    assert.ok(reference.startsWith('not_found|'));
    assert.equal(await outcome(other), reference);
    assert.equal(await outcome(memberAsset), reference);
    assert.equal(f.images().length, 0);
  });

  it('a dealer suspended after authentication cannot add or delete (re-checked inside the transaction)', async () => {
    const { f, svc, car1, asset } = setup();
    const img = await svc.add(D1, car1.id, { assetId: asset() });
    f.setUser(D1.id, 'suspended');
    await assert.rejects(svc.add(D1, car1.id, { assetId: asset() }), isAuthz('not_found'));
    await assert.rejects(svc.remove(D1, car1.id, img.id), isAuthz('not_found'));
    assert.equal(f.imagesOf(car1.id).length, 1);
  });

  it("defense in depth: if the SQL scoping were broken, the service still refuses another showroom's car", async () => {
    const { f, car2, asset } = setup();
    const leaky = {
      ...f.store,
      images: { ...f.store.images, findShowroomCar: async (id: string) => f.store.images.findShowroomCar(id, '901', false) },
      transaction: <T,>(fn: Parameters<typeof f.store.transaction<T>>[0]) =>
        f.store.transaction((repos) => fn({ ...repos, images: { ...repos.images, findShowroomCar: async (id: string) => repos.images.findShowroomCar(id, '901', true) } })),
    };
    const svc = createShowroomCarImageService({ store: leaky });
    await assert.rejects(svc.list(D1, car2.id), isAuthz('not_found'));
    await assert.rejects(svc.add(D1, car2.id, { assetId: asset() }), isAuthz('not_found'));
    assert.equal(f.images().length, 0);
  });
});

describe('showroom car images: asset state and limit', () => {
  it('only a READY car_image asset can be attached (pending, rejected, showroom_cover: 409 invalid_state)', async () => {
    const { f, svc, car1 } = setup();
    for (const over of [{ status: 'pending' }, { status: 'rejected' }, { kind: 'showroom_cover' }]) {
      await assert.rejects(svc.add(D1, car1.id, { assetId: f.addAsset({ ownerId: D1.id, ...over }).id }), isImgErr('invalid_state'));
    }
    assert.equal(f.images().length, 0);
  });

  it("an asset already attached (to this car or another of the dealer's) is 409 and stays where it is", async () => {
    const { f, svc, car1, car1b, asset } = setup();
    const id = asset();
    await svc.add(D1, car1.id, { assetId: id });
    await assert.rejects(svc.add(D1, car1.id, { assetId: id }), isImgErr('invalid_state'));
    await assert.rejects(svc.add(D1, car1b.id, { assetId: id }), isImgErr('invalid_state'));
    assert.equal(f.imagesOf(car1b.id).length, 0);
  });

  it('the showroom cap (5) is enforced: the sixth image is 409 image_limit, nothing changes, and a deleted image frees a slot', async () => {
    const { f, svc, car1, asset } = setup();
    const ids: string[] = [];
    for (let i = 0; i < 5; i++) ids.push((await svc.add(D1, car1.id, { assetId: asset() })).id);
    const audits = f.audits().length;
    await assert.rejects(svc.add(D1, car1.id, { assetId: asset() }), isImgErr('image_limit'));
    assert.equal(f.imagesOf(car1.id).length, 5);
    assert.equal(f.audits().length, audits);
    await svc.remove(D1, car1.id, ids[4]!);
    await svc.add(D1, car1.id, { assetId: asset() });
    assert.equal(f.imagesOf(car1.id).length, 5);
  });

  it('the cap is per car, and eight concurrent adds on one car: exactly 5 succeed, one main image', async () => {
    const { f, svc, car1, car1b, asset } = setup();
    await svc.add(D1, car1b.id, { assetId: asset() });
    const results = await Promise.allSettled(Array.from({ length: 8 }, () => svc.add(D1, car1.id, { assetId: asset() })));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 5);
    for (const r of results) if (r.status === 'rejected') assert.ok(isImgErr('image_limit')(r.reason));
    assert.equal(f.imagesOf(car1.id).filter((i) => i.isMain).length, 1);
    assert.equal(f.imagesOf(car1b.id).length, 1);
  });

  it('two requests racing for the SAME asset: exactly one wins', async () => {
    const { f, svc, car1, car1b, asset } = setup();
    const id = asset();
    const out = await Promise.allSettled([svc.add(D1, car1.id, { assetId: id }), svc.add(D1, car1b.id, { assetId: id })]);
    assert.equal(out.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(f.images().length, 1);
  });
});

describe('showroom car images: delete', () => {
  it('removes the link only: the asset stays, owned by the dealer and free to attach again; audit row written', async () => {
    const { f, svc, car1, asset } = setup();
    const id = asset();
    const img = await svc.add(D1, car1.id, { assetId: id });
    await svc.remove(D1, car1.id, img.id, { requestId: 'req-2' });
    assert.equal(f.images().length, 0);
    assert.ok(f.assets().some((a) => a.id === id && a.ownerId === D1.id));
    assert.deepEqual(f.audits()[1], { action: 'showroom_car.image_delete', actorUserId: D1.id, actorRole: 'dealer', entityType: 'car', entityId: car1.id, afterData: { imageId: Number(img.id), images: 0 }, requestId: 'req-2' });
    await svc.add(D1, car1.id, { assetId: id });
  });

  it('deleting the MAIN image promotes the first remaining one and keeps positions contiguous', async () => {
    const { f, svc, car1, asset } = setup();
    const a = await svc.add(D1, car1.id, { assetId: asset() });
    await svc.add(D1, car1.id, { assetId: asset() });
    await svc.add(D1, car1.id, { assetId: asset() });
    await svc.remove(D1, car1.id, a.id);
    assert.deepEqual(f.imagesOf(car1.id).map((i) => [i.sortOrder, i.isMain]), [[0, true], [1, false]]);
  });

  it('an audit failure rolls the deletion back (and the same for an add)', async () => {
    const { f, svc, car1, asset } = setup();
    const img = await svc.add(D1, car1.id, { assetId: asset() });
    f.faults.failNextAudit = true;
    await assert.rejects(svc.remove(D1, car1.id, img.id));
    assert.equal(f.imagesOf(car1.id).length, 1);
    f.faults.failNextAudit = true;
    await assert.rejects(svc.add(D1, car1.id, { assetId: asset() }));
    assert.equal(f.imagesOf(car1.id).length, 1);
  });

  it('a malformed or unknown image id is the same 404 and a malformed one never reaches the store', async () => {
    const { f, svc, car1, asset } = setup();
    await svc.add(D1, car1.id, { assetId: asset() });
    const outcome = (imageId: unknown) => svc.remove(D1, car1.id, imageId).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome('999999');
    assert.ok(reference.startsWith('not_found|'));
    f.calls.length = 0;
    for (const id of ['abc', '0', '-1', '01', ' 1', '1;DROP', undefined, null, 1, {}]) assert.equal(await outcome(id), reference, JSON.stringify(id));
    assert.deepEqual(f.calls, []);
    assert.equal(f.imagesOf(car1.id).length, 1);
  });
});

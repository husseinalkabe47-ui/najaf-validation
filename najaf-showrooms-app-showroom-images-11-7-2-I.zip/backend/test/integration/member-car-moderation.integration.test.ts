// Phase 11.7.2-G against a real PostgreSQL 16 (migrations applied), through the least-privilege application role. Runs in CI only
// (needs DATABASE_URL / ADMIN_DATABASE_URL; skipped visibly otherwise). Proves what the in-memory tests cannot: the SQL of
// moderation.ts is accepted (placeholder types, column privileges of 0013), the CAS and the row lock hold under real concurrency,
// public_cars follows the status, and the reward gate reads real reward_grants rows.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createModerationService, createPgModerationStore, ModerationError } from '../../src/member-cars/moderation.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };

describe('member-car moderation on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  let owner: Actor;
  let adm: Actor;
  let mod: ReturnType<typeof createModerationService>;
  let mod2: ReturnType<typeof createModerationService>;
  let cars: ReturnType<typeof createMemberCarService>;

  const newUser = async (role: 'user' | 'admin'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone, role],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const row = async (id: string) => (await admin.query<Record<string, unknown>>('SELECT status, version, rejection_reason, suspension_reason, reviewed_by, reviewed_at FROM cars WHERE id = $1', [id])).rows[0]!;
  const isPublic = async (id: string) => (await app.query('SELECT 1 FROM public_cars WHERE id = $1', [id])).rows.length === 1;
  const pending = async () => (await cars.create(owner, VALID)).id;

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    owner = { id: await newUser('user'), role: 'member' };
    adm = { id: await newUser('admin'), role: 'admin' };
    mod = createModerationService({ store: createPgModerationStore(app) });
    mod2 = createModerationService({ store: createPgModerationStore(app2) });
    cars = createMemberCarService({ store: createPgMemberCarStore(app) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM reward_grants WHERE user_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('lists pending ads with the owner name; a non-admin gets 404', async () => {
    const id = await pending();
    const page = await mod.list(adm, { status: 'pending', limit: '100' });
    assert.ok(page.items.some((c) => c.id === id && c.ownerName === 'حساب اختبار'));
    await assert.rejects(mod.list(owner, {}), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
  });

  it('approve without a verified grant is reward_required and the ad stays hidden', async () => {
    const id = await pending();
    await assert.rejects(mod.act(adm, 'approve', id, { version: 1 }), (e: unknown) => e instanceof ModerationError && e.code === 'reward_required');
    assert.equal((await row(id))['status'], 'pending');
    assert.equal(await isPublic(id), false);
  });

  it('reject writes the reason and the review stamp; the owner edit resubmits it as pending', async () => {
    const id = await pending();
    const r = await mod.act(adm, 'reject', id, { version: 1, reason: 'صور غير واضحة' }, { requestId: 'it-mod-reject' });
    assert.equal(r.status, 'rejected');
    const db = await row(id);
    assert.equal(String(db['reviewed_by']), adm.id);
    assert.ok(db['reviewed_at']);
    await assert.rejects(mod.act(adm, 'restore', id, { version: 2 }), (e: unknown) => e instanceof ModerationError && e.code === 'invalid_state');
    await assert.rejects(mod.act(adm, 'approve', id, { version: 2 }), (e: unknown) => e instanceof ModerationError && e.code === 'invalid_state');
    const re = await cars.update(owner, id, { version: 2, price: 8500 });
    assert.equal(re.status, 'pending');
    assert.equal((await row(id))['rejection_reason'], null);
    const audit = await admin.query<{ action: string }>(`SELECT action FROM audit_logs WHERE request_id = 'it-mod-reject'`);
    assert.deepEqual(audit.rows.map((a) => a.action), ['member_car.admin_reject']);
  });

  it('with a verified consumed grant the ad is published; suspend hides it, restore shows it again', async () => {
    const id = await pending();
    await admin.query(
      `INSERT INTO reward_grants (user_id, car_id, status, ssv_transaction_id, verified_at, consumed_at, expires_at)
       VALUES ($1, $2, 'consumed', $3, now(), now(), now() + interval '1 day')`,
      [owner.id, id, `it-tx-${id}`],
    );
    const a = await mod.act(adm, 'approve', id, { version: 1 });
    assert.equal(a.status, 'active');
    assert.equal(await isPublic(id), true);
    const s = await mod.act(adm, 'suspend', id, { version: 2, reason: 'مخالفة' });
    assert.equal(s.suspensionReason, 'مخالفة');
    assert.equal(await isPublic(id), false);
    const r = await mod.act(adm, 'restore', id, { version: 3 });
    assert.equal(r.status, 'active');
    assert.equal(await isPublic(id), true);
  });

  it('two concurrent decisions on the SAME version: exactly one wins', async () => {
    const id = await pending();
    const res = await Promise.allSettled([mod.act(adm, 'reject', id, { version: 1, reason: 'a' }), mod2.act(adm, 'reject', id, { version: 1, reason: 'b' })]);
    assert.equal(res.filter((x) => x.status === 'fulfilled').length, 1);
    assert.ok((res.find((x) => x.status === 'rejected') as PromiseRejectedResult).reason instanceof ModerationError);
  });
});

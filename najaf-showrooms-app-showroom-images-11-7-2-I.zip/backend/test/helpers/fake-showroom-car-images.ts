// In-memory stand-in for the showroom-car image store (Phase 11.7.2-I). It reuses the car-image fake for everything about images
// and assets (so the same database-trigger BACKSTOPS THROW if the service ever lets a violation through: ready car_image, asset
// owner = car owner, per-car cap, UNIQUE asset, one main image at COMMIT) and adds, independently of src, what the showroom SQL does:
//  - the dealer's showroom is found by owner_id; a car is found only by (id AND showroom_id AND source_type = 'showroom' AND not deleted);
//  - a showroom car's trigger owner is the showroom's owner (the fake car carries the dealer id as ownerId, as the trigger derives it);
//  - the showroom cap is 5 (app_settings images.max_per_car -> showroom); transactions and audit rows are the inner fake's.
import type { ShowroomImageRepository, ShowroomImageStore } from '../../src/showroom-car-images/repository.ts';
import { makeFakeCarImageStore } from './fake-car-images.ts';
import type { FakeImgCar } from './fake-car-images.ts';

export function makeFakeShowroomImageStore(opts: { userState?: (id: string) => { status: string; deleted: boolean } | undefined } = {}) {
  const inner = makeFakeCarImageStore(opts);
  inner.setCap(5);
  const showrooms: Array<{ id: string; ownerId: string; status: string }> = [];
  const carShowroom = new Map<string, string>();
  const carsById = new Map<string, FakeImgCar>();
  const calls: string[] = [];

  const base = inner.store.images;
  const repo: ShowroomImageRepository = {
    lockActingUser: (id) => base.lockActingUser(id),
    listImages: (id) => base.listImages(id),
    findOwnAsset: (a, o) => base.findOwnAsset(a, o),
    countImages: (id) => base.countImages(id),
    insertImage: (c, a) => base.insertImage(c, a),
    deleteImage: (i, c) => base.deleteImage(i, c),
    repairLayout: (c) => base.repairLayout(c),
    async findShowroomOfOwner(ownerId) {
      calls.push('findShowroomOfOwner');
      const s = showrooms.find((x) => x.ownerId === ownerId);
      return s ? { ...s } : null;
    },
    async findShowroomCar(carId, showroomId, lock) {
      calls.push(lock ? 'lockShowroomCar' : 'findShowroomCar');
      const c = carsById.get(carId);
      if (!c || c.sourceType !== 'showroom' || c.deleted || carShowroom.get(carId) !== showroomId) return null;
      return { id: c.id, showroomId, status: c.status };
    },
    async showroomImageCap() {
      calls.push('showroomImageCap');
      return base.memberImageCap();
    },
  };
  const store: ShowroomImageStore = {
    images: repo,
    transaction: (fn) => inner.store.transaction(({ audit }) => fn({ images: repo, audit })),
  };

  return {
    store,
    calls,
    faults: inner.faults,
    images: inner.images,
    imagesOf: inner.imagesOf,
    audits: inner.audits,
    assets: inner.assets,
    setCap: inner.setCap,
    addUser: inner.addUser,
    setUser: inner.setUser,
    addAsset: inner.addAsset,
    attach: inner.attach,
    addShowroom(f: { id?: string; ownerId: string; status?: string }) {
      const s = { id: f.id ?? String(900 + showrooms.length), ownerId: f.ownerId, status: f.status ?? 'active' };
      showrooms.push(s);
      return s;
    },
    /** A showroom car (owner = the showroom's owner, as the trigger derives it). */
    addShowroomCar(f: { showroomId: string; id?: string; deleted?: boolean }) {
      const s = showrooms.find((x) => x.id === f.showroomId)!;
      const c = inner.addCar({ ownerId: s.ownerId, sourceType: 'showroom', status: 'available', ...(f.id ? { id: f.id } : { id: String(8000 + carsById.size) }), ...(f.deleted ? { deleted: true } : {}) });
      carShowroom.set(c.id, s.id);
      carsById.set(c.id, c);
      return c;
    },
    /** A member ad (never reachable through the dealer routes). */
    addMemberCar(ownerId: string, id?: string) {
      const c = inner.addCar({ ownerId, ...(id ? { id } : { id: String(8500 + carsById.size) }) });
      carsById.set(c.id, c);
      return c;
    },
  };
}
export type FakeShowroomImageStore = ReturnType<typeof makeFakeShowroomImageStore>;

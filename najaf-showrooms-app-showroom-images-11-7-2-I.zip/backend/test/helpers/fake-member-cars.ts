// In-memory stand-in for the member-car store (Phase 11.5, Step 5.4). It mirrors, independently of src, what the SQL and the
// database do:
//  - every lookup is scoped by owner_id AND source_type = 'member' AND deleted_at IS NULL (another owner's row is not found);
//  - the touch_versioned trigger: every UPDATE (including the soft delete) increments version and sets updated_at;
//  - updates and the soft delete are compare-and-swap on version (and on status 'active' when marking sold);
//  - the soft-delete trigger removes the ad's favorites;
//  - transactions are all-or-nothing (snapshot / restore) and SERIALIZED (a stand-in for the row lock FOR UPDATE);
//  - audit rows go through the real assertAuditSafe (numbers only), as the real writer does.
// Fault injection: failNextAudit, and beforeUpdate (runs between the lock and the compare-and-swap, to simulate a lost race).
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import type { MemberCarRepository, MemberCarRow, MemberCarStore } from '../../src/member-cars/repository.ts';
import type { MemberCarFields } from '../../src/member-cars/validation.ts';
import type { ModeratedRow, ModerationRepository, ModerationStore } from '../../src/member-cars/moderation.ts';
import { TRANSITIONS } from '../../src/member-cars/moderation.ts';

export interface FakeCar extends Omit<MemberCarRow, 'ownerActive'> {
  sourceType: 'member' | 'showroom';
  deletedAt: Date | null;
  searchText: string;
  reviewedBy: string | null;
  reviewedAt?: Date | null;
}
export type UserState = { status: string; deleted: boolean } | undefined;

const COLUMN_FIELDS: readonly (keyof MemberCarFields)[] = [
  'brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description', 'phone', 'whatsapp', 'location', 'latitude', 'longitude',
];

export function makeFakeMemberCarStore(opts: { userState?: (id: string) => UserState; now?: () => number } = {}) {
  const ownUsers = new Map<string, { status: string; deleted: boolean }>();
  const userState = opts.userState ?? ((id: string) => ownUsers.get(id));
  const now = opts.now ?? (() => Date.UTC(2026, 0, 1));
  let cars: FakeCar[] = [];
  let favorites: Array<{ userId: string; carId: string }> = [];
  let audits: AuditEvent[] = [];
  let nextId = 5000;
  const calls: string[] = [];
  const faults: { failNextAudit: boolean; beforeUpdate: (() => void) | null } = { failNextAudit: false, beforeUpdate: null };

  const live = (id: string) => {
    const u = userState(id);
    return u !== undefined && u.status === 'active' && !u.deleted;
  };
  const own = (c: FakeCar, ownerId: string) => c.ownerId === ownerId && c.sourceType === 'member' && c.deletedAt === null;
  const view = (c: FakeCar): MemberCarRow => {
    const { sourceType: _s, deletedAt: _d, searchText: _t, reviewedBy: _r, ...rest } = c;
    return { ...rest, ownerActive: live(c.ownerId) };
  };
  const touch = (c: FakeCar) => {
    c.version += 1;
    c.updatedAt = new Date(now());
  };

  const repo: MemberCarRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      return live(userId);
    },
    async insert(ownerId, f, searchText) {
      calls.push('insert');
      // The CHECKs the service must never violate (a violation here is a bug in the service, as it would be a 500 in production).
      if (!f.phone) throw new Error('cars_member_phone_required');
      if ((f.latitude === null) !== (f.longitude === null)) throw new Error('cars_geo_pair');
      const c: FakeCar = {
        id: String(nextId++), ownerId, sourceType: 'member', status: 'pending', version: 1, createdAt: new Date(now()), updatedAt: new Date(now()),
        deletedAt: null, searchText, reviewedBy: null, rejectionReason: null, suspensionReason: null,
        brand: f.brand, model: f.model, year: f.year, price: String(f.price), currency: f.currency, mileage: f.mileage, transmission: f.transmission,
        fuelType: f.fuelType, color: f.color, description: f.description, phone: f.phone, whatsapp: f.whatsapp, location: f.location,
        latitude: f.latitude, longitude: f.longitude,
      };
      cars.push(c);
      return view(c);
    },
    async listOwn(ownerId, q) {
      calls.push('listOwn');
      return cars
        .filter((c) => own(c, ownerId))
        .filter((c) => q.before === null || BigInt(c.id) < BigInt(q.before))
        .filter((c) => q.status === null || c.status === q.status)
        .sort((a, b) => (BigInt(b.id) > BigInt(a.id) ? 1 : -1))
        .slice(0, q.limit)
        .map(view);
    },
    async findOwn(id, ownerId) {
      calls.push('findOwn');
      const c = cars.find((x) => x.id === id && own(x, ownerId));
      return c ? view(c) : null;
    },
    async lockOwn(id, ownerId) {
      calls.push('lockOwn');
      const c = cars.find((x) => x.id === id && own(x, ownerId));
      return c ? view(c) : null;
    },
    async update(input) {
      calls.push('update');
      if (faults.beforeUpdate) {
        const f = faults.beforeUpdate;
        faults.beforeUpdate = null;
        f();
      }
      const c = cars.find((x) => x.id === input.id && own(x, input.ownerId) && x.version === input.expectedVersion && (!input.markSold || x.status === 'active') && (input.resubmit !== true || x.status === 'rejected'));
      if (!c) return null;
      for (const [k, v] of Object.entries(input.changes)) {
        if (!COLUMN_FIELDS.includes(k as keyof MemberCarFields)) throw new Error(`column privilege: ${k}`);
        (c as unknown as Record<string, unknown>)[k] = k === 'price' ? String(v) : v;
      }
      if (input.markSold) c.status = 'sold';
      if (input.resubmit === true) {
        c.status = 'pending';
        c.rejectionReason = null; // the review stamp is left as the last review
      }
      c.searchText = input.searchText;
      touch(c);
      return view(c);
    },
    async softDelete(input) {
      calls.push('softDelete');
      const c = cars.find((x) => x.id === input.id && own(x, input.ownerId) && x.version === input.expectedVersion);
      if (!c) return false;
      c.deletedAt = new Date(now());
      touch(c);
      favorites = favorites.filter((f) => f.carId !== c.id); // cars_soft_delete_au
      return true;
    },
  };

  // Transactions run one at a time (the row lock), and roll back on any throw.
  let chain: Promise<unknown> = Promise.resolve();
  const store: MemberCarStore = {
    cars: repo,
    transaction(fn) {
      const run = async () => {
        const snap = JSON.stringify({ cars, favorites, audits, nextId });
        const audit = {
          async record(event: AuditEvent) {
            if (faults.failNextAudit) {
              faults.failNextAudit = false;
              throw new Error('audit insert failed');
            }
            assertAuditSafe(event);
            audits.push(event);
          },
        };
        try {
          return await fn({ cars: repo, audit });
        } catch (e) {
          const s = JSON.parse(snap) as { cars: FakeCar[]; favorites: typeof favorites; audits: AuditEvent[]; nextId: number };
          cars = s.cars.map((c) => ({ ...c, createdAt: new Date(c.createdAt), updatedAt: new Date(c.updatedAt), deletedAt: c.deletedAt ? new Date(c.deletedAt) : null, ...(c.reviewedAt ? { reviewedAt: new Date(c.reviewedAt) } : {}) }));
          favorites = s.favorites;
          audits = s.audits;
          nextId = s.nextId;
          throw e;
        }
      };
      const result = chain.then(run, run);
      chain = result.catch(() => undefined);
      return result;
    },
  };

  // ---- Phase 11.7.2-G: the moderation store over the SAME cars. Mirrors buildTransition's CAS (version AND source status), the
  // touch_versioned trigger, and reward_grants (read only).
  const names = new Map<string, string>();
  const rewards: Array<{ carId: string; userId: string; status: string; ssv: string | null; verifiedAt: Date | null; consumedAt: Date | null }> = [];
  const mview = (c: FakeCar): ModeratedRow => ({ ...view(c), ownerName: names.get(c.ownerId) ?? '', reviewedAt: c.reviewedAt ?? null });
  const mlive = (c: FakeCar) => c.sourceType === 'member' && c.deletedAt === null;
  const mrepo: ModerationRepository = {
    async lockActingUser(userId) {
      calls.push('m.lockActingUser');
      return live(userId);
    },
    async list(q) {
      calls.push('m.list');
      return cars
        .filter((c) => mlive(c) && c.status === q.status && (q.afterId === null || BigInt(c.id) > BigInt(q.afterId)))
        .sort((a, b) => (BigInt(a.id) > BigInt(b.id) ? 1 : -1))
        .slice(0, q.limit)
        .map(mview);
    },
    async find(id) {
      calls.push('m.find');
      const c = cars.find((x) => x.id === id && mlive(x));
      return c ? mview(c) : null;
    },
    async lock(id) {
      calls.push('m.lock');
      const c = cars.find((x) => x.id === id && mlive(x));
      return c ? mview(c) : null;
    },
    async hasVerifiedReward(carId, ownerId) {
      calls.push('m.hasVerifiedReward');
      return rewards.some((r) => r.carId === carId && r.userId === ownerId && r.status === 'consumed' && r.ssv !== null && r.verifiedAt !== null && r.consumedAt !== null);
    },
    async transition(input) {
      calls.push('m.transition');
      if (faults.beforeUpdate) {
        const f = faults.beforeUpdate;
        faults.beforeUpdate = null;
        f();
      }
      const t = TRANSITIONS[input.action];
      const c = cars.find((x) => x.id === input.id && mlive(x) && x.version === input.expectedVersion && x.status === t.from);
      if (!c) return null;
      c.status = t.to;
      c.rejectionReason = input.action === 'reject' ? input.reason : null;
      c.suspensionReason = input.action === 'suspend' ? input.reason : null;
      c.reviewedAt = new Date(now());
      c.reviewedBy = input.reviewerId;
      touch(c);
      return mview(c);
    },
  };
  const moderationStore: ModerationStore = {
    cars: mrepo,
    transaction: (fn) => store.transaction(async ({ audit }) => fn({ cars: mrepo, audit })),
  };

  return {
    store,
    moderationStore,
    setOwnerName(id: string, name: string) {
      names.set(id, name);
    },
    /** Fixture: a rewarded-ad grant row (what a future server-side verification would write). */
    addReward(r: { carId: string; userId: string; status?: string; ssv?: string | null; verified?: boolean; consumed?: boolean }) {
      rewards.push({ carId: r.carId, userId: r.userId, status: r.status ?? 'consumed', ssv: r.ssv === undefined ? 'tx-1' : r.ssv, verifiedAt: r.verified === false ? null : new Date(now()), consumedAt: r.consumed === false ? null : new Date(now()) });
    },
    calls,
    faults,
    cars: () => cars,
    audits: () => audits,
    favorites: () => favorites,
    car: (id: string) => cars.find((c) => c.id === id),
    addUser(id: string, status = 'active', deleted = false) {
      ownUsers.set(id, { status, deleted });
    },
    setUser(id: string, status: string, deleted = false) {
      ownUsers.set(id, { status, deleted });
    },
    addFavorite(userId: string, carId: string) {
      favorites.push({ userId, carId });
    },
    /** Fixture: a row written by someone else (another owner, a showroom car, an admin decision). */
    addCar(fields: Partial<FakeCar> & { ownerId: string }): FakeCar {
      const c: FakeCar = {
        id: String(nextId++), sourceType: 'member', status: 'active', version: 1, createdAt: new Date(now()), updatedAt: new Date(now()),
        deletedAt: null, searchText: '', reviewedBy: null, rejectionReason: null, suspensionReason: null,
        brand: 'Toyota', model: 'Camry', year: 2015, price: '12000', currency: 'USD', mileage: null, transmission: 'أوتوماتيك', fuelType: 'بنزين',
        color: '', description: '', phone: '+9647701234567', whatsapp: '+9647701234567', location: '', latitude: null, longitude: null,
        ...fields,
      };
      cars.push(c);
      return c;
    },
  };
}
export type FakeMemberCarStore = ReturnType<typeof makeFakeMemberCarStore>;

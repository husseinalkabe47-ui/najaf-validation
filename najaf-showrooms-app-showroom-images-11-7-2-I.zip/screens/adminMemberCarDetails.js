/* AdminMemberCarDetailsScreen — مراجعة إعلان عضو، مع أزرار إجراء تُخفى حسب
   الحالة الحالية (لا تسمح بعمليات غير منطقية)، والتحقق الفعلي في adminService. */
/* (11.7.2-G) وضع الخادم: تفاصيل إعلان محمَّل في قائمة المراجعة (لا طلب إضافي). تُفتح من القائمة؛ بدونها يُطلب فتحها من القائمة.
   الأزرار حسب الحالة الحالية فقط (الخادم يتحقق ثانيةً): pending→موافقة/رفض، active→إيقاف، suspended→استعادة. المرفوض يعدّله مالكه ولا يعيده المدير. */
let _adminModMsg = '';
function _AdminMemberCarDetailsRemote(id) {
  const c = BackendModeration.get(id);
  if (!c) return _AdminMemberCarsUnavailable('🚗 مراجعة إعلان', 'يُفتح الإعلان من قائمة المراجعة (حسب الحالة)؛ لا تُعرض بيانات تجريبية بدلًا منه.');
  const v = BackendModeration.view();
  const note = c.status === 'rejected' ? 'لا يعيد المدير الإعلان المرفوض: يعدّله صاحبه فيعود «قيد المراجعة».'
    : c.status === 'sold' ? 'الإعلان مباع؛ تحديد «مباعة» لصاحب الإعلان وحده.'
    : c.status === 'pending' ? 'النشر يتطلب تحققًا مؤكدًا من الخادم لمشاهدة إعلان المكافأة؛ إن لم يوجد يُرفض النشر ولا يتغير شيء.' : '';
  return `
  <div class="back-btn"><button class="back-circle" aria-label="رجوع" onclick="goBack('adminMemberCars')">→</button></div>
  <div class="detail-hero">🚘</div>
  <div class="detail-body">
    <h1>${esc(c.brand)} ${esc(c.model)}</h1>
    <p class="price" style="font-size:18px;">💰 ${carPriceOrDash(c)}</p>
    ${memberCarStatusBadge(c.status)}
    <div class="spec-grid">
      <div class="spec-item"><div class="l">السنة</div><div class="v">${val(c.year)}</div></div>
      <div class="spec-item"><div class="l">الممشى</div><div class="v">${km(c.mileage)}</div></div>
      <div class="spec-item"><div class="l">القير</div><div class="v">${val(c.transmission)}</div></div>
      <div class="spec-item"><div class="l">الوقود</div><div class="v">${val(c.fuelType)}</div></div>
      <div class="spec-item"><div class="l">اللون</div><div class="v">${val(c.color)}</div></div>
      <div class="spec-item"><div class="l">الموقع</div><div class="v">📍 ${val(c.location)}</div></div>
    </div>
    <p class="sub" style="line-height:1.7;">${esc(c.description)}</p>
    <div class="info-row">🧑 صاحب الإعلان: ${esc(c.ownerName)}</div>
    ${c.phone ? `<div class="info-row">📞 <span dir="ltr">${esc(c.phone)}</span></div>` : ''}
    ${c.whatsapp ? `<div class="info-row">💬 واتساب: <span dir="ltr">${esc(c.whatsapp)}</span></div>` : ''}
    ${c.createdAt ? `<div class="info-row">🗓️ تاريخ الإرسال: ${val(createdDateText(c.createdAt))}</div>` : ''}
    ${c.reviewedAt ? `<div class="info-row">🛡️ آخر مراجعة: ${val(createdDateText(c.reviewedAt))}</div>` : ''}
    ${c.status === 'rejected' && c.rejectionReason ? `<div class="reason-box">سبب الرفض: ${esc(c.rejectionReason)}</div>` : ''}
    ${c.status === 'suspended' && c.suspensionReason ? `<div class="reason-box">سبب الإيقاف: ${esc(c.suspensionReason)}</div>` : ''}
    ${note ? `<p class="sub">${esc(note)}</p>` : ''}
    ${_adminModMsg ? `<div class="form-error" role="alert">${esc(_adminModMsg)}</div>` : ''}
    ${v.busy ? '<div class="img-busy" role="status">جارٍ تنفيذ الإجراء…</div>' : ''}
    <div class="admin-actions">
      ${c.actions.map(a => `<button class="${a.kind}" ${v.busy ? 'disabled' : ''} onclick="handleModerationAction('${a.action}','${esc(c.id)}')">${esc(a.label)}</button>`).join('')}
    </div>
  </div>`;
}
function AdminMemberCarDetailsScreen(id) {
  if (BackendModeration.isEnabled()) return _AdminMemberCarDetailsRemote(String(id));   // 11.7.2-G
  const c = getMemberCarById(id);
  if (!c) return `<div class="placeholder">الإعلان غير موجود</div>`;
  const owner = UserService.getPublicById(c.ownerId);
  const reviewer = c.reviewedBy ? UserService.getPublicById(c.reviewedBy) : null;
  return `
  <div class="back-btn"><button class="back-circle" aria-label="رجوع" onclick="goBack('adminMemberCars')">→</button></div>
  <div class="detail-hero">🚘</div>
  <div class="detail-body">
    <h1>${esc(c.brand)} ${esc(c.model)}</h1>
    <p class="price" style="font-size:18px;">💰 ${carPriceOrDash(c)}</p>
    ${memberCarStatusBadge(c.status)}
    <div class="spec-grid">
      <div class="spec-item"><div class="l">السنة</div><div class="v">${val(c.year)}</div></div>
      <div class="spec-item"><div class="l">الممشى</div><div class="v">${km(c.mileage)}</div></div>
      <div class="spec-item"><div class="l">القير</div><div class="v">${val(c.transmission)}</div></div>
      <div class="spec-item"><div class="l">الوقود</div><div class="v">${val(c.fuelType)}</div></div>
      <div class="spec-item"><div class="l">اللون</div><div class="v">${val(c.color)}</div></div>
      <div class="spec-item"><div class="l">الموقع</div><div class="v">📍 ${val(c.location)}</div></div>
    </div>
    <p class="sub" style="line-height:1.7;">${esc(c.description)}</p>
    <div class="info-row">🧑 صاحب الإعلان: ${owner ? esc(owner.name) : 'غير معروف'}</div>
    ${c.phone ? `<div class="info-row">📞 ${esc(c.phone)}</div>` : ''}
    ${c.whatsapp ? `<div class="info-row">💬 واتساب: ${esc(c.whatsapp)}</div>` : ''}
    <div class="info-row">🗓️ تاريخ النشر: ${val(createdDateText(c.createdAt))}</div>
    ${reviewer ? `<div class="info-row">🛡️ آخر مراجعة بواسطة: ${esc(reviewer.name)}</div>` : ''}
    ${c.status === 'rejected' && c.rejectionReason ? `<div class="reason-box">سبب الرفض: ${esc(c.rejectionReason)}</div>` : ''}
    ${c.status === 'suspended' && c.suspensionReason ? `<div class="reason-box">سبب الإيقاف: ${esc(c.suspensionReason)}</div>` : ''}
    <div class="admin-actions">
      ${c.status !== 'active' ? `<button class="approve" onclick="handleApproveMemberCar(${c.id})">✅ موافقة ونشر</button>` : ''}
      ${c.status !== 'rejected' ? `<button class="danger" onclick="handleRejectMemberCar(${c.id})">❌ رفض الإعلان</button>` : ''}
      ${c.status !== 'suspended' ? `<button onclick="handleSuspendMemberCarAdmin(${c.id})">⏸️ إيقاف الإعلان</button>` : ''}
      ${c.status !== 'pending' ? `<button onclick="handleRestoreMemberCarAdmin(${c.id})">↩️ إرجاع للمراجعة</button>` : ''}
    </div>
  </div>`;
}

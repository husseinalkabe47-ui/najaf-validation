/* «لوحة الإدارة» — واجهة أولية فقط؛ لا تُبنى لوحة الإدارة في هذه المرحلة. */
function AdminHomeScreen() {
  const user = SessionService.getCurrentUser();
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1></div>
  <div class="section">
    ${AccountCard(user)}
    <div class="placeholder" style="margin:0"><span class="ic">🛠️</span>إدارة المستخدمين والمعارض والسيارات والموافقة على أصحاب المعارض ستُضاف في مرحلة لاحقة.</div>
  </div>`;
}

/* (11.7-E) وضع الخادم: شاشة إدارية لا يوجد لها مسار إداري في الخلفية الموجودة. تُوضَّح صراحةً ولا تُعرض بيانات تجريبية محلية بدلًا منها. */
function AdminUnavailableScreen(title, what) {
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>${esc(title)}</h1></div>
  <div class="section">${EmptyState({ icon: 'ℹ️', title: 'غير متاح بعد مع الخادم', hint: what + ' لا يوجد له مسار إداري في الخلفية الحالية، ولذلك لا تُعرض بيانات تجريبية بدلًا منه.',
    actions: [{ label: 'أصحاب المعارض', onclick: "go('adminDealerRequests')" }, { label: 'لوحة الإدارة', onclick: "go('adminHome')", primary: false }] })}</div>`;
}

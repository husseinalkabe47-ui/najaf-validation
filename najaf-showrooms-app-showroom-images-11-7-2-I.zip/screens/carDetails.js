/* تفاصيل سيارة معرض: صور، مواصفات، وصف، معلومات المعرض، وأزرار تواصل تعمل فقط عند توفر البيانات */
/* (11.7-A) وضع الخادم: GET /v1/public/cars/:id (+ GET /v1/public/showrooms/:showroomId لكتلة المعرض وأزرار التواصل). 404 = «غير موجودة» (الخادم لا يفرّق بينها وبين غير العامة).
   بلا مفضلة ولا صور بعد (غير مربوطتين بالخادم). */
function _detailsDone(route) { return () => { if (currentRoute === route) render(); }; }
function _CarDetailsRemote(id) {
  const done = _detailsDone('carDetails');
  const st = BackendCatalog.detail('car', id, done);
  const back = DetailBackButton('cars', true);
  if (st.status === 'missing') return `${back}${EmptyState({ icon: '🚘', heading: true, title: 'السيارة غير موجودة أو غير متاحة حاليًا', actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }] })}`;
  if (st.status !== 'ready') return back + RemoteState(st, { loading: 'جارٍ تحميل السيارة…', retry: "BackendCatalog.reloadDetail('car', currentParam, _detailsDone('carDetails'));render()" });
  const c = st.item, isMember = c.sourceType === 'member';
  let sh = null, showroomBlock = '';
  if (!isMember && c.showroomId) {
    const ss = BackendCatalog.detail('showroom', c.showroomId, done);
    if (ss.status === 'ready') sh = ss.item;
    else if (ss.status === 'loading') showroomBlock = '<div class="info-block" role="status" aria-busy="true"><h3>🏢 المعرض</h3><div class="info-row">جارٍ التحميل…</div></div>';
  }
  if (sh) {
    const name = plainText(sh.name), addr = plainText(sh.address), hours = plainText(sh.workingHours);
    showroomBlock = `
    <div class="info-block">
      <h3>🏢 المعرض</h3>
      ${name ? `<div class="info-row strong">${esc(name)}</div>` : ''}
      ${addr ? `<div class="info-row">📍 ${esc(addr)}</div>` : ''}
      ${hours ? `<div class="info-row">🕐 ${esc(hours)}</div>` : ''}
      <button class="link-btn" onclick="go('showroomDetails','${sh.id}')">عرض صفحة المعرض</button>
    </div>`;
  }
  const gal = RemoteCarGallery(BackendImages.publicCar(c.id, done), carTitle(c), "BackendImages.retryPublicCar(currentParam, _detailsDone('carDetails'));render()");   // 11.7-D
  const contact = isMember ? ContactButtons({ phone: c.phone, whatsapp: c.whatsapp, lat: c.latitude, lng: c.longitude })
    : (sh ? ContactButtons({ phone: sh.phone, whatsapp: sh.whatsapp, lat: sh.latitude, lng: sh.longitude }) : '');
  return `
  ${DetailBackButton('cars')}
  <div class="detail-hero">${gal.hero}</div>
  ${gal.strip}
  <div class="detail-body">
    <div class="detail-head"><div class="detail-id"><h1>${esc(carTitle(c))}</h1>${isMember ? sourceBadge('member') : ''}</div>${RemoteFavButton(c.id, true)}</div>
    ${DetailPrice(c)}
    ${DetailStatusRow(isMember ? memberCarStatusBadge(c.status) : carStatusBadge(c.status))}
    ${DetailSpecs(CarCoreSpecs(c))}
    ${DetailDescription(c)}
    ${showroomBlock}
    ${AdSlot('car_details')}
    ${contact}
  </div>`;
}
function CarDetailsScreen(id) {
  if (BackendCatalog.isEnabled()) return _CarDetailsRemote(String(id));
  const access = getCarAccess(id);   // المسار العام: ok | hidden (معرض موقوف/إعلان عضو غير نشط لغير مالكه) | missing
  if (access.status === 'missing') return `${DetailBackButton('cars', true)}${EmptyState({ icon: '🚘', heading: true, title: 'السيارة غير موجودة', actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }] })}`;
  if (access.status === 'hidden') return `${DetailBackButton('cars', true)}${EmptyState({ icon: '🚘', heading: true, title: 'هذه السيارة غير متاحة حاليًا', actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }] })}`;
  const c = access.car;
  const isMember = c.sourceType === 'member';
  const sh = isMember ? null : getVisibleShowroomById(c.showroomId);
  // كتلة المعرض: من بيانات المعرض الفعلية فقط (الاسم، العنوان، الدوام، عدد سياراته، شارة حالته إن لم يكن نشطًا)
  const showroomBlock = sh ? (() => {
    const name = plainText(sh.name), addr = plainText(sh.address), hours = plainText(sh.workingHours);
    return `
    <div class="info-block">
      <h3>🏢 المعرض</h3>
      ${name ? `<div class="info-row strong">${esc(name)}</div>` : ''}
      ${addr ? `<div class="info-row">📍 ${esc(addr)}</div>` : ''}
      ${hours ? `<div class="info-row">🕐 ${esc(hours)}</div>` : ''}
      <div class="info-row">🚘 ${getVisibleCarsByShowroom(sh.id).length} سيارة</div>
      ${sh.status !== 'active' ? showroomStatusBadge(sh.status) : ''}
      <button class="link-btn" onclick="go('showroomDetails',${sh.id})">عرض صفحة المعرض</button>
    </div>`;
  })() : '';
  const contact = isMember ? ContactButtons({ phone: c.phone, whatsapp: c.whatsapp, lat: c.latitude, lng: c.longitude })
    : (sh ? ContactButtons({ phone: sh.phone, whatsapp: sh.whatsapp, lat: sh.latitude, lng: sh.longitude }) : '');
  return `
  ${DetailBackButton('cars')}
  <div class="detail-hero">${CarImageInner(c)}</div>
  ${CarImageStrip(c)}
  <div class="detail-body">
    ${DetailIdentity(c, isMember ? sourceBadge('member') : '')}
    ${DetailPrice(c)}
    ${DetailStatusRow(isMember ? memberCarStatusBadge(c.status) : carStatusBadge(c.status))}
    ${DetailSpecs(CarCoreSpecs(c))}
    ${DetailDescription(c)}
    ${showroomBlock}
    ${AdSlot('car_details')}
    ${contact}
  </div>`;
}

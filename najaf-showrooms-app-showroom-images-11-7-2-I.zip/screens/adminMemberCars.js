/* AdminMemberCarsScreen — كل سيارات الأعضاء (بكل الحالات)، بحث + تبويب حالة. */
let adminMemberCarsQuery = '';
let adminMemberCarsStatus = 'all';

function _adminMemberCarMatches(c, q) {
  const owner = UserService.getPublicById(c.ownerId);
  return textLower(c.brand).includes(q) || textLower(c.model).includes(q) ||
    textLower(`${c.brand} ${c.model}`).includes(q) || (owner && textLower(owner.name).includes(q));
}
function renderAdminMemberCarsList() {
  let list = getMemberCars();
  if (adminMemberCarsStatus !== 'all') list = list.filter(c => c.status === adminMemberCarsStatus);
  if (adminMemberCarsQuery.trim()) { const q = adminMemberCarsQuery.trim().toLowerCase(); list = list.filter(c => _adminMemberCarMatches(c, q)); }
  if (list.length === 0) return `<div class="placeholder"><span class="ic">🔍</span>لا توجد نتائج.</div>`;
  return `<div class="list-grid">${list.map(c => {
    const owner = UserService.getPublicById(c.ownerId);
    return `
    <div class="card car-card" role="button" tabindex="0" onclick="go('adminMemberCarDetails', ${c.id})">
      <div class="card-img">🚘</div>
      <div class="card-body">
        <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
        <p class="card-row">${val(c.year)} — ${carPriceOrDash(c)}</p>
        ${memberCarStatusBadge(c.status)}
        <p class="card-row">🧑 ${owner ? esc(owner.name) : 'غير معروف'}</p>
        ${c.phone ? `<p class="card-row">📞 ${esc(c.phone)}</p>` : ''}
        <p class="card-row">🗓️ ${createdDateText(c.createdAt)}</p>
      </div>
    </div>`;
  }).join('')}</div>`;
}
function onAdminMemberCarsSearch(v) { adminMemberCarsQuery = v; const l = document.getElementById('adminMemberCarsList'); if (l) l.innerHTML = renderAdminMemberCarsList(); }
function onAdminMemberCarsStatus(status) {
  adminMemberCarsStatus = status;
  const tabs = document.getElementById('adminMemberCarsTabs');
  if (tabs) tabs.innerHTML = _adminMemberCarsTabsHtml();
  const l = document.getElementById('adminMemberCarsList');
  if (l) l.innerHTML = renderAdminMemberCarsList();
}
function _adminMemberCarsTabsHtml() {
  const tabs = [['all', 'الكل'], ['pending', 'قيد المراجعة'], ['active', 'نشط'], ['sold', 'مباعة'], ['rejected', 'مرفوض'], ['suspended', 'موقوف']];
  return tabs.map(([v, l]) => `<button type="button" class="${adminMemberCarsStatus === v ? 'active' : ''}" aria-pressed="${adminMemberCarsStatus === v}" onclick="onAdminMemberCarsStatus('${v}')">${l}</button>`).join('');
}

/* (11.7.2-G) وضع الخادم: مراجعة إعلانات الأعضاء حسب الحالة (GET /v1/admin/member-cars) بأزرار الإجراء المسموحة لكل حالة.
   «الكل» غير مدعوم في الخادم (يعرض حالة واحدة في كل مرة)، فيُعرض بيان صريح بدل بيانات محلية. لا بيانات تجريبية في وضع الخادم. */
const _MOD_EMPTY = { pending: 'لا توجد إعلانات بانتظار المراجعة.', active: 'لا توجد إعلانات نشطة.', rejected: 'لا توجد إعلانات مرفوضة.', suspended: 'لا توجد إعلانات موقوفة.', sold: 'لا توجد إعلانات مباعة.' };
function _AdminMemberCarsUnavailable(title, hint) {
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>${esc(title)}</h1></div>
  <div class="section">${EmptyState({ icon: 'ℹ️', title: 'غير متاح بعد مع الخادم', hint: hint,
    actions: [{ label: 'إعلانات قيد المراجعة', onclick: "go('adminMemberCars','pending')" }, { label: 'أصحاب المعارض', onclick: "go('adminDealerRequests')", primary: false }, { label: 'لوحة الإدارة', onclick: "go('adminHome')", primary: false }] })}</div>`;
}
function _AdminMemberCarsRemote(initialStatus) {
  if (BackendModeration.statuses.indexOf(initialStatus) < 0) return _AdminMemberCarsUnavailable('🚗 سيارات الأعضاء', 'عرض «الكل» غير متاح: يعرض الخادم إعلانات حالة واحدة في كل مرة، ولا تُعرض بيانات تجريبية بدلًا منه. اختر حالة.');
  if (_adminModSeen !== initialStatus) { _adminModSeen = initialStatus; BackendModeration.setFilter(initialStatus); }
  const v = BackendModeration.view(_rerenderIf('adminMemberCars'));
  const tabs = `<div class="status-tabs" role="group" aria-label="حالة الإعلان">${v.tabs.map(t => `<button type="button" class="${t.active ? 'active' : ''}" aria-pressed="${t.active}" onclick="handleModerationTab('${t.key}')">${esc(t.label)}</button>`).join('')}</div>`;
  const row = c => `
    <div class="card car-card" role="button" tabindex="0" onclick="go('adminMemberCarDetails', '${esc(c.id)}')">
      <div class="card-img">🚘</div>
      <div class="card-body">
        <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
        <p class="card-row">${val(c.year)} — ${carPriceOrDash(c)}</p>
        ${memberCarStatusBadge(c.status)}
        <p class="card-row">🧑 ${esc(c.ownerName)}</p>
        ${c.phone ? `<p class="card-row">📞 <span dir="ltr">${esc(c.phone)}</span></p>` : ''}
        ${c.createdAt ? `<p class="card-row">🗓️ ${createdDateText(c.createdAt)}</p>` : ''}
      </div>
    </div>`;
  let body;
  if (v.status === 'ready') {
    body = `<div class="list-grid">${v.items.map(row).join('')}</div>`
      + (v.error ? `<div class="form-error" role="alert">${esc(v.error)}</div>` : '')
      + (v.hasMore ? `<button class="btn-primary" style="margin-top:12px" ${v.more ? 'disabled' : ''} onclick="handleModerationMore()">${v.more ? 'جارٍ التحميل…' : 'عرض المزيد'}</button>` : '');
  } else {
    body = RemoteState(v, { loading: 'جارٍ تحميل إعلانات الأعضاء…', retry: 'handleModerationRetry()', empty: { icon: '✅', title: _MOD_EMPTY[v.filter] } });
  }
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🚗 مراجعة إعلانات الأعضاء</h1></div>
  <div class="section">
    ${tabs}
    ${v.busy ? '<div class="img-busy" role="status">جارٍ تنفيذ الإجراء…</div>' : ''}
    ${body}
  </div>`;
}
let _adminModSeen = null;

function AdminMemberCarsScreen(initialStatus) {
  if (BackendModeration.isEnabled()) return _AdminMemberCarsRemote(initialStatus);   // 11.7.2-G (كان «غير متاح» في 11.7-E)
  if (initialStatus) adminMemberCarsStatus = initialStatus;
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🚗 سيارات الأعضاء</h1>${SearchBox('ابحث بالاسم أو الماركة أو الموديل', 'onAdminMemberCarsSearch', adminMemberCarsQuery)}</div>
  <div class="section">
    <div class="status-tabs" id="adminMemberCarsTabs">${_adminMemberCarsTabsHtml()}</div>
    <div id="adminMemberCarsList">${renderAdminMemberCarsList()}</div>
  </div>`;
}

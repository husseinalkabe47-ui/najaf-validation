/* AdminDealerRequestsScreen — طلبات أصحاب المعارض بحالة pending فقط. */
/* (11.7-E) وضع الخادم: GET /v1/admin/dealers (حسب الحالة) + approve/reject/suspend/reactivate. لا بيانات محلية. */
const _ADMIN_DEALERS_EMPTY = { pending: 'لا توجد طلبات بانتظار المراجعة.', active: 'لا يوجد أصحاب معارض فعّالون.', suspended: 'لا يوجد أصحاب معارض موقوفون.' };
function _AdminDealersRemote() {
  const v = BackendAdmin.view(_rerenderIf('adminDealerRequests'));
  const tabs = `<div class="status-tabs" role="group" aria-label="حالة الحساب">${v.tabs.map(t => `<button type="button" class="${t.active ? 'active' : ''}" aria-pressed="${t.active}" onclick="handleAdminDealersTab('${t.key}')">${esc(t.label)}</button>`).join('')}</div>`;
  const row = d => `
      <div class="ad-row">
        <div class="card-img">👤</div>
        <div class="ad-info">
          <p class="card-title">${esc(d.name)}</p>
          <p class="card-row">📞 <span dir="ltr">${esc(d.phone)}</span></p>
          ${d.createdAt ? `<p class="card-row">🗓️ ${createdDateText(d.createdAt)}</p>` : ''}
          ${d.showroomStatus ? showroomStatusBadge(d.showroomStatus) : ''}
          <div class="admin-actions">${d.actions.map(a => `<button class="${a.kind}" ${v.busy ? 'disabled' : ''} onclick="handleAdminDealerAction('${a.action}','${esc(d.id)}')">${esc(a.label)}</button>`).join('')}</div>
        </div>
      </div>`;
  let body;
  if (v.status === 'ready') {
    body = v.items.map(row).join('')
      + (v.error ? `<div class="form-error" role="alert">${esc(v.error)}</div>` : '')
      + (v.hasMore ? `<button class="btn-primary" style="margin-top:12px" ${v.more ? 'disabled' : ''} onclick="handleAdminDealersMore()">${v.more ? 'جارٍ التحميل…' : 'عرض المزيد'}</button>` : '');
  } else {
    body = RemoteState(v, { loading: 'جارٍ تحميل أصحاب المعارض…', retry: 'handleAdminDealersRetry()', empty: { icon: '✅', title: _ADMIN_DEALERS_EMPTY[v.filter] } });
  }
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🏪 أصحاب المعارض</h1></div>
  <div class="section">
    ${tabs}
    ${v.busy ? '<div class="img-busy" role="status">جارٍ تنفيذ الإجراء…</div>' : ''}
    ${body}
  </div>`;
}
function AdminDealerRequestsScreen() {
  if (BackendAdmin.isEnabled()) return _AdminDealersRemote();
  const pending = adminGetAllUsers().filter(u => u.role === 'dealer' && u.status === 'pending');
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🏪 طلبات أصحاب المعارض</h1></div>
  <div class="section">
    ${pending.length === 0 ? `<div class="placeholder"><span class="ic">✅</span>لا توجد طلبات بانتظار المراجعة.</div>` :
      pending.map(u => `
      <div class="ad-row">
        <div class="card-img">👤</div>
        <div class="ad-info">
          <p class="card-title">${esc(u.name)}</p>
          <p class="card-row">📞 ${esc(u.phone)}</p>
          <p class="card-row">🗓️ ${createdDateText(u.createdAt)}</p>
          <div class="admin-actions">
            <button class="approve" onclick="handleApproveDealer(${u.id})">✅ موافقة</button>
            <button class="danger" onclick="handleRejectDealer(${u.id})">❌ رفض</button>
          </div>
        </div>
      </div>`).join('')}
  </div>`;
}

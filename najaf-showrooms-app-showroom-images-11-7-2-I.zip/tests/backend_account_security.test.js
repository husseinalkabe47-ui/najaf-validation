/* Phase 11.7-F — إكمال المصادقة: أمان الحساب عبر الخادم داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/auth/routes.ts): password/change {currentPassword,newPassword} → 200 وينهي كل الجلسات،
   logout/all بلا جسم → 204 وينهي كل الجلسات، phone/verify/request بلا جسم → 202 sent | 200 already_verified، phone/verify/confirm {code} → 200 {user}.
   لا خادم حقيقي ولا مزوّد رسائل: النتائج لا تُثبت وصول أي رمز ولا التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const root = path.join(__dirname, '..');
const OLD = 'Pa55w0rd-1';
const NEW = 'N3w-Passw0rd-9';
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: Object.assign({ 'content-type': 'application/json' }) });
const err = (status, code, fields, headers) => new Response(JSON.stringify({ error: { code, message: 'm', requestId: 'r', fields } }), { status, headers: Object.assign({ 'content-type': 'application/json' }, headers) });
const ACCOUNT = /^\/v1\/auth\/(password\/change|logout\/all|phone\/verify\/(request|confirm))$/;

function secWorld() {
  const w = world();
  const a = { password: OLD, verified: false, code: '123456', fail: null, gate: null, delivery: true, foreignUser: false };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (!ACCOUNT.test(u.pathname)) {
      if (u.pathname === '/v1/auth/login' && a.verified) { const r = await base(url, init); const b = await r.json(); b.user.phoneVerified = true; return json(r.status, b); }
      return base(url, init);
    }
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, method: init.method, headers: h, rawBody: init.body, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    w.srv.calls.push(call);
    if (a.gate) await a.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (a.fail) { const f = a.fail(call); if (f) return f; }
    const endAll = () => w.srv.families.forEach(f => { if (f.userId === rec.fam.userId) f.revoked = true; });
    if (call.path === '/v1/auth/password/change') {
      const b = call.body || {};
      const extra = Object.keys(b).filter(k => !['currentPassword', 'newPassword'].includes(k));
      if (extra.length) return err(400, 'validation_failed', extra.map(k => ({ field: k, code: 'unknown_field' })));
      if (typeof b.newPassword !== 'string' || b.newPassword.length < 6) return err(400, 'validation_failed', [{ field: 'newPassword', code: 'too_short' }]);
      if (b.currentPassword !== a.password) return err(400, 'invalid_current_password');
      if (b.newPassword === b.currentPassword) return err(400, 'validation_failed', [{ field: 'newPassword', code: 'same_as_current' }]);
      a.password = b.newPassword; endAll();
      return json(200, { status: 'password_changed' });
    }
    if (call.path === '/v1/auth/logout/all') {
      if (call.rawBody !== undefined) return err(400, 'validation_failed');
      endAll(); return new Response(null, { status: 204 });
    }
    if (call.path === '/v1/auth/phone/verify/request') {
      if (call.rawBody !== undefined) return err(400, 'validation_failed');
      if (a.verified) return json(200, { status: 'already_verified' });
      if (!a.delivery) return err(503, 'delivery_unavailable');
      return json(202, { status: 'sent' });
    }
    const b = call.body || {};
    if (Object.keys(b).join() !== 'code' || !/^[0-9]{6}$/.test(b.code)) return err(400, 'validation_failed', [{ field: 'code', code: 'invalid_format' }]);
    if (b.code !== a.code) return err(400, 'invalid_code');
    a.verified = true;
    const id = a.foreignUser ? '999' : String(rec.fam.userId);
    return json(200, { user: { id, name: 'مستخدم ' + id, phone: '+9647700000' + rec.fam.userId, role: 'user', status: 'active', phoneVerified: true, createdAt: '2030-01-01T00:00:00.000Z' } });
  };
  return { w, a };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  return {
    env, set, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    val: id => env.run(`document.getElementById('${id}').value`),
    text: id => env.els[id] && env.els[id].textContent,
    user: () => env.run('SessionService.getCurrentUser()'),
    calls: re => w.srv.calls.filter(c => re.test(c.path)),
    toast: () => env.els.toast && env.els.toast.textContent,
    login: () => env.run(`BackendAuth.login('07700000003', '${OLD}')`),
    fillChange(o) { o = Object.assign({ current: OLD, next: NEW, confirm: NEW }, o); set('cpCurrent', o.current); set('cpNew', o.next); set('cpConfirm', o.confirm); },
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p) { await p.login(); p.run("go('account')"); await settle(); }
const yes = p => p.run('askConfirm = (spec, ok) => ok()');
const no = p => p.run('askConfirm = (spec, ok, cancel) => { if (typeof cancel === "function") cancel(); }');
const CHANGE = /^\/v1\/auth\/password\/change$/, ALL = /^\/v1\/auth\/logout\/all$/, VREQ = /^\/v1\/auth\/phone\/verify\/request$/, VCONF = /^\/v1\/auth\/phone\/verify\/confirm$/;

/* ====================== الوضع المحلي ====================== */

test('الوضع المحلي دون تغيير: «حسابي» بلا قسم «أمان الحساب»، ودوال الجسر ترفض بلا أي اتصال', async () => {
  const env = makeEnv();
  assert.equal(env.run("AuthService.login('07700000001','user123')").ok, true);
  env.run("go('account')"); assert.equal(env.run('currentRoute'), 'account');
  assert.ok(!/accountSecurity|أمان الحساب|cpCurrent|handleLogoutAll|handleVerifyPhone/.test(env.screen()));
  assert.equal(env.run('BackendAuth.isEnabled()'), false);
  for (const c of ['changeCredential({currentPassword:"a",newPassword:"bbbbbb"})', 'logoutAll()', 'requestPhoneVerification()', 'confirmPhoneVerification("123456")']) {
    const r = await env.run('BackendAuth.' + c); assert.equal(r.ok, false, c);
  }
  assert.deepEqual(env.errors, []);
});

/* ====================== الشاشة ====================== */

test('وضع الخادم: «حسابي» فيه قسم أمان الحساب (التوثيق، تغيير كلمة المرور، الخروج من كل الأجهزة) دون أي طلب عند الفتح؛ والضيف يُحوَّل للدخول', async () => {
  const { w } = secWorld(); const p = page(w);
  p.run("go('account')"); assert.equal(p.route(), 'login');
  await p.login(); p.run("go('account')"); await settle();
  const h = p.screen();
  assert.match(h, /أمان الحساب/); assert.match(h, /سياراتي/, 'محتوى «حسابي» القديم باقٍ');
  for (const id of ['cpCurrent', 'cpNew', 'cpConfirm', 'cpError', 'verifyError', 'logoutAllError']) assert.match(h, new RegExp('id="' + id + '"'), id);
  assert.match(h, /غير موثّق/); assert.match(h, /handleVerifyPhoneRequest/); assert.ok(!/id="verifyCode"/.test(h), 'خانة الرمز تظهر بعد الطلب فقط');
  assert.match(h, /handleLogoutAll/); assert.match(h, /بما فيها هذا الجهاز/);
  assert.equal(p.calls(/^\/v1\/auth\/(password|logout\/all|phone)/).length, 0, 'فتح الشاشة لا يرسل شيئًا');
  assert.deepEqual(p.env.errors, []);
});

/* ====================== تغيير كلمة المرور ====================== */

test('تغيير كلمة المرور: الجسم {currentPassword,newPassword} فقط مع Bearer؛ النجاح يُنهي الجلسة محليًا ويمسح الملف والتلميح وينقل للدخول برسالة؛ والحقول تُفرَّغ', async () => {
  const { w, a } = secWorld(); const p = page(w); await open(p);
  p.fillChange(); await p.run('handleChangePasswordSubmit()'); await settle();
  const c = p.calls(CHANGE); assert.equal(c.length, 1);
  assert.deepEqual(Object.keys(c[0].body).sort(), ['currentPassword', 'newPassword']);
  assert.equal(c[0].body.currentPassword, OLD); assert.equal(c[0].body.newPassword, NEW); assert.match(c[0].headers.authorization, /^Bearer AT-/);
  assert.equal(a.password, NEW);
  assert.equal(p.user(), null); assert.equal(p.run('BackendAuth.api().hasSession()'), false);
  assert.equal(w.jar.rt, null, 'خروج عادي بعده مسح ملف الارتباط'); assert.equal(p.calls(/^\/v1\/auth\/logout$/).length, 1);
  assert.equal(p.route(), 'login'); assert.equal(p.text('loginNote'), p.run('BackendAuth.messages.passwordChanged'));
  for (const id of ['cpCurrent', 'cpNew', 'cpConfirm']) assert.equal(p.val(id), '', id);
  // الدخول بالكلمة الجديدة ممكن (الخادم الوهمي يقبل أي كلمة للدخول، لكن الواجهة لم تبقِ جلسة قديمة)
  p.run("go('account')"); assert.equal(p.route(), 'login');
});

test('تغيير كلمة المرور — تحقق العميل قبل الشبكة: الحالية فارغة، الجديدة قصيرة، عدم التطابق، الجديدة = الحالية → رسالة ولا طلب', async () => {
  const { w } = secWorld(); const p = page(w); await open(p);
  const cases = [[{ current: '' }, 'currentRequired'], [{ next: '123', confirm: '123' }, 'passwordShort'], [{ confirm: 'other-1234' }, 'mismatch'], [{ next: OLD, confirm: OLD }, 'samePassword']];
  for (const [o, key] of cases) {
    p.fillChange(o); await p.run('handleChangePasswordSubmit()'); await settle();
    assert.equal(p.text('cpError'), p.run('BackendAuth.messages.' + key), key);
    assert.equal(p.val('cpCurrent'), '', 'الحقول تُفرَّغ دائمًا');
  }
  assert.equal(p.calls(CHANGE).length, 0); assert.ok(p.user(), 'ما زال مسجَّل الدخول');
});

test('تغيير كلمة المرور — أخطاء الخادم: الحالية خاطئة، same_as_current، 429 بالدقائق، 500، الشبكة → رسالة عربية والجلسة تبقى كما هي', async () => {
  const { w, a } = secWorld(); const p = page(w); await open(p);
  p.fillChange({ current: 'wrong-pass' }); await p.run('handleChangePasswordSubmit()'); await settle();
  assert.equal(p.text('cpError'), 'كلمة المرور الحالية غير صحيحة.'); assert.ok(p.user()); assert.equal(a.password, OLD);
  const errs = [[() => err(400, 'validation_failed', [{ field: 'newPassword', code: 'same_as_current' }]), /يجب أن تختلف/], [() => err(429, 'rate_limited', undefined, { 'retry-after': '120' }), /حاول بعد 2 دقيقة/], [() => err(500, 'internal'), /خطأ في الخادم/]];
  for (const [f, re] of errs) { a.fail = f; p.fillChange(); await p.run('handleChangePasswordSubmit()'); await settle(); assert.match(p.text('cpError'), re); assert.ok(p.user()); assert.equal(p.route(), 'account'); }
  a.fail = null; w.srv.down = true; p.fillChange(); await p.run('handleChangePasswordSubmit()'); await settle(); w.srv.down = false;
  assert.match(p.text('cpError'), /تعذّر الاتصال/); assert.ok(p.user()); assert.equal(a.password, OLD);
  assert.ok(!/Pa55w0rd|N3w-Passw0rd/.test(p.screen()), 'لا كلمة مرور في الصفحة');
});

test('منع التكرار: نقرتان متتاليتان (وطلبا حساب متزامنان) = طلب واحد فقط', async () => {
  const { w, a } = secWorld(); const p = page(w); await open(p);
  let release; a.gate = () => new Promise(r => { release = r; });
  p.fillChange(); const x = p.run('handleChangePasswordSubmit()'); await settle();
  p.fillChange(); await p.run('handleChangePasswordSubmit()');
  const y = await p.run('BackendAuth.logoutAll()'); assert.equal(y.ok, false); assert.equal(y.error, p.run('BackendAuth.messages.accountBusy'));
  a.gate = null; release(); await x; await settle();
  assert.equal(p.calls(CHANGE).length, 1); assert.equal(p.calls(ALL).length, 0); assert.equal(p.route(), 'login');
});

/* ====================== الخروج من كل الأجهزة ====================== */

test('الخروج من كل الأجهزة: الإلغاء لا يرسل شيئًا؛ التأكيد = POST بلا جسم مع Bearer، ثم تُمسح الجلسة وينتقل للدخول برسالة', async () => {
  const { w } = secWorld(); const p = page(w); await open(p);
  no(p); await p.run('handleLogoutAll()'); await settle();
  assert.equal(p.calls(ALL).length, 0); assert.ok(p.user()); assert.equal(p.route(), 'account');
  yes(p); await p.run('handleLogoutAll()'); await settle();
  const c = p.calls(ALL); assert.equal(c.length, 1); assert.equal(c[0].method, 'POST'); assert.equal(c[0].rawBody, undefined); assert.match(c[0].headers.authorization, /^Bearer /);
  assert.equal(p.user(), null); assert.equal(w.jar.rt, null); assert.equal(p.route(), 'login'); assert.equal(p.text('loginNote'), p.run('BackendAuth.messages.logoutAllDone'));
  assert.ok([...w.srv.families.values()].every(f => f.revoked), 'كل الجلسات منتهية في الخادم الوهمي');
});

test('الخروج من كل الأجهزة — الفشل (500/429/شبكة) لا يُخرج المستخدم ولا يدّعي نجاحًا', async () => {
  const { w, a } = secWorld(); const p = page(w); await open(p); yes(p);
  a.fail = () => err(500, 'internal'); await p.run('handleLogoutAll()'); await settle();
  assert.match(p.text('logoutAllError'), /خطأ في الخادم/); assert.ok(p.user()); assert.equal(p.route(), 'account');
  a.fail = () => err(429, 'rate_limited', undefined, { 'retry-after': '30' }); await p.run('handleLogoutAll()'); await settle();
  assert.match(p.text('logoutAllError'), /حاول بعد 1 دقيقة/); assert.ok(p.user());
  a.fail = null; w.srv.down = true; await p.run('handleLogoutAll()'); await settle(); w.srv.down = false;
  assert.match(p.text('logoutAllError'), /تعذّر الاتصال/); assert.ok(p.user()); assert.ok(w.jar.rt, 'ملف الارتباط باقٍ');
});

/* ====================== توثيق الهاتف ====================== */

test('توثيق الهاتف — الطلب: POST بلا جسم؛ «sent» يُظهر خانة الرمز برسالة صادقة (طُلب، لا «وصل»)؛ 503 delivery_unavailable يُقال صراحةً', async () => {
  { const { w } = secWorld(); const p = page(w); await open(p);
    await p.run('handleVerifyPhoneRequest()'); await settle();
    const c = p.calls(VREQ); assert.equal(c.length, 1); assert.equal(c[0].rawBody, undefined); assert.match(c[0].headers.authorization, /^Bearer /);
    assert.match(p.screen(), /id="verifyCode"/); assert.match(p.screen(), /طُلب إرسال رمز التوثيق/); assert.ok(!/تم إرسال|وصلك الرمز/.test(p.screen())); assert.equal(p.route(), 'account'); }
  { const { w, a } = secWorld(); a.delivery = false; const p = page(w); await open(p);
    await p.run('handleVerifyPhoneRequest()'); await settle();
    assert.equal(p.text('verifyError'), p.run('BackendAuth.messages.phoneUnavailable')); assert.ok(!/id="verifyCode"/.test(p.screen())); }
});

test('توثيق الهاتف — already_verified يحدّث حالة المستخدم دون أي رمز؛ والمستخدم الموثّق لا يرسل طلبًا أصلًا', async () => {
  const { w, a } = secWorld(); const p = page(w); await open(p);
  a.verified = true; await p.run('handleVerifyPhoneRequest()'); await settle();
  assert.equal(p.run('BackendAuth.isPhoneVerified()'), true); assert.match(p.screen(), /رقم هاتفك موثّق/); assert.ok(!/handleVerifyPhoneRequest/.test(p.screen()));
  const r = await p.run('BackendAuth.requestPhoneVerification()'); assert.equal(r.ok, true); assert.equal(r.already, true);
  assert.equal(p.calls(VREQ).length, 1, 'لا طلب ثانٍ');
  const { w: w2, a: a2 } = secWorld(); a2.verified = true; const q = page(w2); await open(q);
  assert.equal(q.run('BackendAuth.isPhoneVerified()'), true); assert.match(q.screen(), /رقم هاتفك موثّق/);
});

test('توثيق الهاتف — التأكيد: صيغة خاطئة بلا طلب، الأرقام العربية تُقبل، invalid_code برسالة، والنجاح يجعل المستخدم موثّقًا؛ والحقل يُفرَّغ', async () => {
  const { w } = secWorld(); const p = page(w); await open(p);
  await p.run('handleVerifyPhoneRequest()'); await settle();
  p.set('verifyCode', '12a'); await p.run('handleVerifyPhoneConfirm()'); await settle();
  assert.equal(p.text('verifyError'), p.run('BackendAuth.messages.codeFormat')); assert.equal(p.calls(VCONF).length, 0);
  p.set('verifyCode', '654321'); await p.run('handleVerifyPhoneConfirm()'); await settle();
  assert.match(p.text('verifyError'), /الرمز غير صحيح/); assert.equal(p.val('verifyCode'), ''); assert.equal(p.run('BackendAuth.isPhoneVerified()'), false);
  p.set('verifyCode', '١٢٣٤٥٦'); await p.run('handleVerifyPhoneConfirm()'); await settle();
  const c = p.calls(VCONF); assert.equal(c.length, 2); assert.deepEqual(c[1].body, { code: '123456' });
  assert.equal(p.run('BackendAuth.isPhoneVerified()'), true); assert.match(p.screen(), /رقم هاتفك موثّق/); assert.equal(p.text('verifyNote'), p.run('BackendAuth.messages.phoneVerified'));
  assert.equal(p.user().id, 'srv:3', 'الهوية نفسها');
});

test('توثيق الهاتف — ردّ لمستخدم آخر أو بشكل غير صالح يُرفض ولا يُطبَّق', async () => {
  const { w, a } = secWorld(); a.foreignUser = true; const p = page(w); await open(p);
  const r = await p.run("BackendAuth.confirmPhoneVerification('123456')");
  assert.equal(r.ok, false); assert.equal(r.error, p.run('BackendAuth.messages.invalid')); assert.equal(p.user().id, 'srv:3'); assert.equal(p.run('BackendAuth.isPhoneVerified()'), false);
  a.foreignUser = false; a.fail = c => (c.path.endsWith('/confirm') ? json(200, { user: { id: '3' } }) : null);
  const r2 = await p.run("BackendAuth.confirmPhoneVerification('123456')"); assert.equal(r2.ok, false); assert.equal(p.run('BackendAuth.isPhoneVerified()'), false);
});

/* ====================== الجلسة ====================== */

test('انتهاء الجلسة أثناء أي إجراء: إعادة للدخول برسالة الانتهاء، بلا ادّعاء نجاح؛ والخروج أثناء طلب جارٍ لا يُحيي الحالة', async () => {
  for (const fire of [p => { p.fillChange(); return p.run('handleChangePasswordSubmit()'); }, p => { yes(p); return p.run('handleLogoutAll()'); }, p => p.run('handleVerifyPhoneRequest()')]) {
    const { w } = secWorld(); const p = page(w); await open(p);
    w.srv.families.forEach(f => { f.revoked = true; });
    await fire(p); await settle();
    assert.equal(p.route(), 'login'); assert.equal(p.user(), null); assert.equal(p.toast(), p.run('BackendAuth.messages.expired'));
    assert.ok(!/تم تغيير كلمة المرور|تم تسجيل الخروج من كل/.test(p.text('loginNote') || ''));
  }
  { const { w, a } = secWorld(); const p = page(w); await open(p);
    let release; a.gate = c => (c.path.endsWith('/confirm') ? new Promise(r => { release = r; }) : null);
    const x = p.run("BackendAuth.confirmPhoneVerification('123456')"); await settle();
    p.run('handleLogout()'); await settle(); a.gate = null; release();
    const r = await x; assert.equal(r.ok, false); assert.equal(p.user(), null, 'الرد المتأخر لا يُحيي المستخدم'); }
});

/* ====================== حارس المصدر ====================== */

test('حارس المصدر: مسارات 11.7-F الأربعة فقط في الجسر، بلا تخزين/console/fetch؛ لا دور ولا userId في الأجسام؛ و87 سكربتًا', () => {
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('(11.7-F) أمان الحساب ----'), b = all.indexOf('(11.7.2.2) استعادة الجلسة عند الإقلاع');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|\beval\(|new Function|Repository|AppStorage|innerHTML/.test(src));
  const paths = [...src.matchAll(/'(\/v1\/[^']*)'/g)].map(m => m[1]);
  assert.deepEqual([...new Set(paths)].sort(), ['/v1/auth/logout/all', '/v1/auth/password/change', '/v1/auth/phone/verify/confirm', '/v1/auth/phone/verify/request']);
  assert.ok(!/\buserId\b|role\s*:|phone\s*:/.test(src), 'المعرّف والدور والهاتف من رمز الوصول في الخادم، لا من الطلب');
  const scr = fs.readFileSync(path.join(root, 'screens/account.js'), 'utf8') + fs.readFileSync(path.join(root, 'navigation/actions.js'), 'utf8');
  assert.ok(!/localStorage|sessionStorage|console\.log/.test(scr));
  assert.equal((fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/<script src=/g) || []).length, 87);
});

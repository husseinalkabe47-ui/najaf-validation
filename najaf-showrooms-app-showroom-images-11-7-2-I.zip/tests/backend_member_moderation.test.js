/* Phase 11.7.2-G — مراجعة إعلانات الأعضاء (المدير) عبر /v1/admin/member-cars داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/member-cars/moderation-routes.ts): GET بحالة/after/limit، وPOST approve|reject|suspend|restore بجسم {version[,reason]}،
   404 لغير المدير، 409 version_conflict/invalid_state/reward_required، سبب الإيقاف إلزامي، وحقول مجهولة = 400. لا خادم ولا قاعدة بيانات حقيقية: النتائج لا تُثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const root = path.join(__dirname, '..');
const iso = '2026-01-01T00:00:00.000Z';
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const TRANS = { approve: ['pending', 'active'], reject: ['pending', 'rejected'], suspend: ['active', 'suspended'], restore: ['suspended', 'active'] };

function modWorld(role) {
  const w = world();
  const d = { role: role || 'admin', seq: 500, cars: [], reward: false, gate: null, fail: null };
  d.car = o => { const x = Object.assign({ id: String(++d.seq), brand: 'Kia', model: 'Rio ' + d.seq, year: 2018, price: 9000, currency: 'USD', mileage: null, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: 'وصف', phone: '+9647701234567', whatsapp: '+9647701234567', location: 'النجف', latitude: null, longitude: null, status: 'pending', rejectionReason: null, suspensionReason: null, version: 1, createdAt: iso, updatedAt: iso, ownerId: '9', ownerName: 'مالك ' + d.seq, reviewedAt: null }, o); d.cars.push(x); return x; };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    if (!u.pathname.startsWith('/v1/admin/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, rawBody: init.body, body: init.body ? JSON.parse(init.body) : undefined };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (d.role !== 'admin') return err(404, 'not_found');
    if (call.method === 'GET' && u.pathname === '/v1/admin/member-cars') {
      const q = call.query, bad = Object.keys(q).filter(k => !['status', 'after', 'limit'].includes(k)).map(f => ({ field: f, code: 'unknown_field' }));
      const status = q.status === undefined ? 'pending' : q.status;
      if (!['pending', 'active', 'sold', 'rejected', 'suspended'].includes(status)) bad.push({ field: 'status', code: 'invalid_format' });
      const limit = q.limit === undefined ? 50 : Number(q.limit); if (!(limit >= 1 && limit <= 100)) bad.push({ field: 'limit', code: 'invalid_format' });
      if (q.after !== undefined && !/^[1-9][0-9]{0,18}$/.test(q.after)) bad.push({ field: 'after', code: 'invalid_format' });
      if (bad.length) return err(400, 'validation_failed', bad);
      let rows = d.cars.filter(x => x.status === status).sort((a, b) => Number(a.id) - Number(b.id));
      if (q.after) rows = rows.filter(x => Number(x.id) > Number(q.after));
      const pg = rows.slice(0, limit);
      return json(200, { items: pg.map(x => Object.assign({}, x)), nextAfter: pg.length === limit ? pg[pg.length - 1].id : null });
    }
    const m = /^\/v1\/admin\/member-cars\/([^/]+)\/(approve|reject|suspend|restore)$/.exec(u.pathname);
    if (call.method === 'POST' && m) {
      const b = call.body, allowed = (m[2] === 'reject' || m[2] === 'suspend') ? ['version', 'reason'] : ['version'];
      if (!b || typeof b !== 'object' || Object.keys(b).some(k => !allowed.includes(k)) || !Number.isInteger(b.version)) return err(400, 'validation_failed', [{ field: 'body', code: 'invalid_type' }]);
      if (m[2] === 'suspend' && !(typeof b.reason === 'string' && b.reason.trim())) return err(400, 'validation_failed', [{ field: 'reason', code: 'required' }]);
      const x = d.cars.find(y => y.id === m[1]); if (!x) return err(404, 'not_found');
      if (x.version !== b.version) return err(409, 'version_conflict');
      const [from, to] = TRANS[m[2]]; if (x.status !== from) return err(409, 'invalid_state');
      if (m[2] === 'approve' && !d.reward) return err(409, 'reward_required');
      x.status = to; x.version++; x.reviewedAt = iso;
      x.rejectionReason = m[2] === 'reject' ? (b.reason || null) : null; x.suspensionReason = m[2] === 'suspend' ? b.reason : null;
      return json(200, { car: Object.assign({}, x) });
    }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  return {
    env, run: c => env.run(c), screen: () => env.screen(),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    adminCalls: () => w.srv.calls.filter(c => c.path.startsWith('/v1/admin/')),
    toast: () => env.els.toast && env.els.toast.textContent,
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p, param) { await p.login(); p.run(`go('adminMemberCars', '${param || 'pending'}')`); await settle(); }
const yes = p => p.run('askConfirm = (spec, ok) => ok()');
const no = p => p.run('askConfirm = (spec, ok, cancel) => { if (typeof cancel === "function") cancel(); }');
const reasonIs = (p, v) => p.run(`askText = (spec, ok) => ok(${JSON.stringify(v)})`);
const LIST = /^\/v1\/admin\/member-cars$/;
const act = a => new RegExp(`^/v1/admin/member-cars/\\d+/${a}$`);

test('القائمة: الافتراضي pending بحدّ 50، صفوف بالمالك، تبويبات الحالات الخمس، وخطأ مع إعادة محاولة', async () => {
  const { w, d } = modWorld(); const a = d.car({}); d.car({ status: 'active' }); d.car({ status: 'rejected', rejectionReason: 'x' });
  const p = page(w); await open(p); let h = p.screen();
  assert.deepEqual(p.calls('GET', LIST).map(c => c.query), [{ status: 'pending', limit: '50' }]);
  assert.match(h, new RegExp(a.ownerName)); assert.match(h, /مراجعة إعلانات الأعضاء/); assert.match(h, /قيد المراجعة/);
  for (const k of ['pending', 'active', 'rejected', 'suspended', 'sold']) assert.match(h, new RegExp(`handleModerationTab\\('${k}'\\)`));
  p.run("handleModerationTab('active')"); await settle(); assert.equal(p.calls('GET', LIST).pop().query.status, 'active'); assert.match(p.screen(), /Rio 50[0-9]/);
  p.run("handleModerationTab('suspended')"); await settle(); assert.match(p.screen(), /لا توجد إعلانات موقوفة/);
  d.fail = c => (c.method === 'GET' ? err(500, 'internal') : null);
  p.run("handleModerationTab('sold')"); await settle(); assert.match(p.screen(), /role="alert"/); assert.match(p.screen(), /handleModerationRetry/);
  d.fail = null; p.run('handleModerationRetry()'); await settle(); assert.match(p.screen(), /لا توجد إعلانات مباعة/);
  assert.deepEqual(p.env.errors, []);
});

test('الصفحات: «عرض المزيد» يمرّر after من الخادم ولا يكرر عنصرًا', async () => {
  const { w, d } = modWorld(); for (let i = 0; i < 51; i++) d.car({});
  const p = page(w); await open(p); assert.match(p.screen(), /handleModerationMore/);
  p.run('handleModerationMore()'); await settle();
  const g = p.calls('GET', LIST); assert.equal(g.length, 2); assert.ok(g[1].query.after);
  const ids = [...p.screen().matchAll(/go\('adminMemberCarDetails', '(\d+)'\)/g)].map(m => m[1]); assert.equal(ids.length, 51); assert.equal(new Set(ids).size, 51);
});

test('الأزرار حسب الحالة: pending موافقة/رفض، active إيقاف، suspended استعادة، rejected وsold بلا إجراء مدير', async () => {
  const { w, d } = modWorld(); const c = {}; for (const s of ['pending', 'active', 'suspended', 'rejected', 'sold']) c[s] = d.car({ status: s });
  const p = page(w); await p.login();
  const expect = { pending: ['approve', 'reject'], active: ['suspend'], suspended: ['restore'], rejected: [], sold: [] };
  for (const s of Object.keys(expect)) {
    p.run(`go('adminMemberCars', '${s}')`); await settle(); p.run(`go('adminMemberCarDetails', '${c[s].id}')`); await settle();
    const got = [...p.screen().matchAll(/handleModerationAction\('(\w+)'/g)].map(m => m[1]); assert.deepEqual(got, expect[s], s);
  }
  p.run(`go('adminMemberCars', 'rejected')`); await settle(); p.run(`go('adminMemberCarDetails', '${c.rejected.id}')`); await settle();
  assert.match(p.screen(), /يعدّله صاحبه/);
});

test('رفض: جسم {version, reason}؛ بلا سبب = {version} فقط؛ تأكيد/إلغاء؛ تُحدَّث القائمة من الخادم', async () => {
  const { w, d } = modWorld(); const a = d.car({}), b = d.car({});
  const p = page(w); await open(p); p.run(`go('adminMemberCarDetails', '${a.id}')`); await settle();
  reasonIs(p, 'صور غير واضحة'); await p.run(`handleModerationAction('reject', '${a.id}')`); await settle();
  const c1 = p.calls('POST', act('reject')); assert.equal(c1.length, 1); assert.deepEqual(c1[0].body, { version: 1, reason: 'صور غير واضحة' });
  assert.equal(a.status, 'rejected'); assert.equal(p.run('currentRoute'), 'adminMemberCars'); assert.match(p.toast(), /تم رفض الإعلان/);
  assert.ok(!new RegExp(`'${a.id}'`).test(p.screen()), 'خرج من قائمة قيد المراجعة'); assert.match(p.screen(), new RegExp(`'${b.id}'`));
  p.run(`go('adminMemberCarDetails', '${b.id}')`); await settle();
  p.run('askText = (spec, ok, cancel) => cancel()'); await p.run(`handleModerationAction('reject', '${b.id}')`); await settle(); assert.equal(p.calls('POST', act('reject')).length, 1, 'إلغاء = لا طلب');
  reasonIs(p, ''); await p.run(`handleModerationAction('reject', '${b.id}')`); await settle();
  assert.deepEqual(p.calls('POST', act('reject'))[1].body, { version: 1 });
  p.run("handleModerationTab('rejected')"); await settle(); assert.match(p.screen(), new RegExp(`'${a.id}'`));
  assert.deepEqual(p.env.errors, []);
});

test('إيقاف: السبب إلزامي (لا طلب بدونه)، ثم استعادة بتأكيد؛ لا إجراء بلا تأكيد', async () => {
  const { w, d } = modWorld(); const a = d.car({ status: 'active' });
  const p = page(w); await open(p, 'active'); p.run(`go('adminMemberCarDetails', '${a.id}')`); await settle();
  reasonIs(p, '   '); await p.run(`handleModerationAction('suspend', '${a.id}')`); await settle();
  assert.equal(p.calls('POST', act('suspend')).length, 0); assert.match(p.toast(), /سبب الإيقاف مطلوب/); assert.equal(a.status, 'active');
  reasonIs(p, 'x'.repeat(501)); await p.run(`handleModerationAction('suspend', '${a.id}')`); await settle(); assert.equal(p.calls('POST', act('suspend')).length, 0); assert.match(p.toast(), /طويل/);
  reasonIs(p, 'مخالفة'); await p.run(`handleModerationAction('suspend', '${a.id}')`); await settle();
  assert.deepEqual(p.calls('POST', act('suspend'))[0].body, { version: 1, reason: 'مخالفة' }); assert.equal(a.status, 'suspended');
  p.run("handleModerationTab('suspended')"); await settle(); p.run(`go('adminMemberCarDetails', '${a.id}')`); await settle();
  assert.match(p.screen(), /سبب الإيقاف: مخالفة/);
  no(p); await p.run(`handleModerationAction('restore', '${a.id}')`); await settle(); assert.equal(p.calls('POST', act('restore')).length, 0);
  yes(p); await p.run(`handleModerationAction('restore', '${a.id}')`); await settle();
  assert.deepEqual(p.calls('POST', act('restore'))[0].body, { version: 2 }); assert.equal(a.status, 'active');
});

test('النشر: بلا تحقق مؤكد من الخادم = 409 reward_required برسالة صريحة، لا تغيير ولا نجاح مزيّف؛ ومع تحقق الخادم ينجح', async () => {
  const { w, d } = modWorld(); const a = d.car({});
  const p = page(w); await open(p); p.run(`go('adminMemberCarDetails', '${a.id}')`); await settle(); yes(p);
  await p.run(`handleModerationAction('approve', '${a.id}')`); await settle();
  const posts = p.calls('POST', act('approve')); assert.equal(posts.length, 1); assert.deepEqual(posts[0].body, { version: 1 }, 'لا علم نجاح من الواجهة');
  assert.match(p.toast(), /لا يوجد تحقق مؤكد من الخادم/); assert.match(p.screen(), /لا يوجد تحقق مؤكد من الخادم/); assert.equal(a.status, 'pending'); assert.equal(p.run('currentRoute'), 'adminMemberCarDetails');
  assert.equal(p.run('BackendModeration.get("' + a.id + '").status'), 'pending');
  d.reward = true; await p.run(`handleModerationAction('approve', '${a.id}')`); await settle();
  assert.equal(a.status, 'active'); assert.match(p.toast(), /نُشر الإعلان/); assert.deepEqual(p.env.errors, []);
});

test('تعارض الإصدار/الحالة: 409 يعيد تحميل القائمة من الخادم برسالة عربية؛ 404 يُزيل العنصر؛ 403/400 رسائل', async () => {
  const { w, d } = modWorld(); const a = d.car({}), b = d.car({}), c = d.car({});
  const p = page(w); await open(p); p.run(`go('adminMemberCarDetails', '${a.id}')`); await settle(); reasonIs(p, 'س');
  a.version = 5;   // قرار مدير آخر/تعديل المالك بعد القراءة
  await p.run(`handleModerationAction('reject', '${a.id}')`); await settle();
  assert.match(p.toast(), /تغيّرت حالة هذا الإعلان/); assert.equal(p.run('currentRoute'), 'adminMemberCars'); assert.equal(a.status, 'pending');
  assert.equal(p.calls('GET', LIST).length, 2, 'أُعيد الجلب'); assert.match(p.screen(), new RegExp(`'${a.id}'`));
  p.run(`go('adminMemberCarDetails', '${b.id}')`); await settle(); d.cars.splice(d.cars.indexOf(b), 1);
  await p.run(`handleModerationAction('reject', '${b.id}')`); await settle(); assert.match(p.toast(), /غير موجود/);
  p.run(`go('adminMemberCarDetails', '${c.id}')`); await settle(); d.fail = x => (x.method === 'POST' ? err(403, 'forbidden') : null);
  await p.run(`handleModerationAction('reject', '${c.id}')`); await settle(); assert.match(p.toast(), /ليس لديك صلاحية/); assert.match(p.screen(), /ليس لديك صلاحية/);
  d.fail = x => (x.method === 'POST' ? err(400, 'validation_failed') : null);
  await p.run(`handleModerationAction('reject', '${c.id}')`); await settle(); assert.match(p.toast(), /تعذّر تنفيذ الإجراء/);
  assert.deepEqual(p.env.errors, []);
});

test('منع التكرار: نقرتان متزامنتان = طلب واحد؛ والقفل يُحرَّر بعد الانتهاء', async () => {
  const { w, d } = modWorld(); const a = d.car({}), b = d.car({}); let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
  const p = page(w); await open(p); p.run(`go('adminMemberCarDetails', '${a.id}')`); await settle(); reasonIs(p, 'س');
  const first = p.run(`handleModerationAction('reject', '${a.id}')`); const second = p.run(`handleModerationAction('reject', '${a.id}')`); await settle();
  assert.equal(p.calls('POST', act('reject')).length, 1); assert.match(p.screen(), /جارٍ تنفيذ الإجراء/); assert.match(p.screen(), /disabled/);
  release(); await first; await second; await settle(); assert.equal(a.version, 2, 'نُفِّذ مرة واحدة');
  d.gate = null; p.run(`go('adminMemberCarDetails', '${b.id}')`); await settle(); await p.run(`handleModerationAction('reject', '${b.id}')`); await settle(); assert.equal(b.status, 'rejected');
});

test('غير المدير: 404 = «للمدير فقط» بلا بيانات؛ استجابة خاطئة = خطأ لا عرض؛ تغيّر الهوية يمسح الحالة', async () => {
  const x = modWorld('user'); const p1 = page(x.w); x.d.car({}); await open(p1);
  assert.match(p1.screen(), /غير مصرّح/); assert.equal(p1.adminCalls().length, 0, 'حارس المسار: غير المدير لا يطلب شيئًا'); assert.ok(!/Rio/.test(p1.screen()));
  const y = modWorld(); y.d.car({}); y.d.fail = c => (c.method === 'GET' ? err(404, 'not_found') : null); const p2 = page(y.w); await open(p2);
  assert.match(p2.screen(), /هذه الصفحة للمدير فقط/); assert.ok(!/Rio/.test(p2.screen()));
  const { w, d } = modWorld(); const a = d.car({}); d.car({ status: 'active' });
  let corrupt = true; const bad = w.fetchImpl; w.fetchImpl = async (url, init) => { const r = await bad(url, init); if (corrupt && /\/v1\/admin\/member-cars\?/.test(String(url))) { const j = await r.json(); j.items.push(Object.assign({}, j.items[0], { status: 'active' })); return json(200, j); } return r; };
  const p = page(w); await open(p); assert.match(p.screen(), /role="alert"/); assert.ok(!new RegExp(a.brand + ' ' + a.model).test(p.screen()));
  corrupt = false; p.run('handleModerationRetry()'); await settle(); assert.match(p.screen(), new RegExp(`'${a.id}'`));
  assert.equal(p.run(`BackendModeration.has('${a.id}')`), true);
  await p.run('BackendAuth.logout()'); await settle(); assert.equal(p.run(`BackendModeration.has('${a.id}')`), false, 'خروج = لا بقايا');
});

test('«الكل» وتفاصيل بلا قائمة محمَّلة: بيان صريح «غير متاح بعد مع الخادم» بلا بيانات محلية وبلا طلب؛ والوضع المحلي لم يتغير', async () => {
  const { w, d } = modWorld(); d.car({});
  const p = page(w); await p.login();
  for (const [route, param] of [['adminMemberCars', 'all'], ['adminMemberCarDetails', '1']]) {
    p.run(`go('${route}', '${param}')`); await settle(); assert.match(p.screen(), /غير متاح بعد مع الخادم/); assert.match(p.screen(), /go\('adminDealerRequests'\)/); assert.ok(!/Toyota|تويوتا/.test(p.screen()));
  }
  assert.equal(p.adminCalls().length, 0);
  const env = makeEnv({}); assert.equal(env.run('BackendModeration.isEnabled()'), false);
  env.run("SessionService.login && 0"); assert.match(env.run("AdminMemberCarsScreen('all')"), /سيارات الأعضاء/); assert.ok(!/غير متاح بعد مع الخادم/.test(env.run("AdminMemberCarsScreen('all')")));
});

test('حارس المصدر: BackendModeration مساراته /v1/admin/member-cars فقط، POST واحد بجسم {version[,reason]}، بلا تخزين/console/fetch/رموز/حالة مُرسَلة؛ و87 سكربتًا', () => {
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendModeration'), b = all.indexOf('const BackendAdmin');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|\beval\(|new Function|Repository|AppStorage|innerHTML/.test(src));
  const paths = [...src.matchAll(/'(\/v1\/[^']*)'/g)].map(m => m[1].replace(/\/$/, '')); assert.deepEqual([...new Set(paths)].sort(), ['/v1/admin/member-cars']);
  const writes = [...src.matchAll(/api\.(post|put|patch|delete)\(([^)]*)\)/g)].map(m => m[1] + ' ' + m[2]); assert.deepEqual(writes, ["post '/v1/admin/member-cars/' + id + '/' + action, body"]);
  assert.ok(!/body\.(status|reward|rewardVerified|ownerId|reviewedBy)|body = \{[^}]*(status|reward)/.test(src), 'لا حالة ولا علم مكافأة في الجسم');
  assert.ok(!/Authorization|accessToken|refreshToken/.test(src));
  const adminSrc = all.slice(b, all.indexOf('const BackendImages')).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/member-cars/.test(adminSrc), 'BackendAdmin لم يتغير');
  assert.equal((fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/<script src=/g) || []).length, 87);
});

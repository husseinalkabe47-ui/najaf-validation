/* Phase 11.7-H — تسجيل صاحب معرض عبر POST /v1/dealers/register بنقل الجلسة الآمن (ملف ارتباط HttpOnly) داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يغلّف session_world.js ويحاكي العقد الموجود فقط (الجسم {name, phone, password}؛ الردّ 201 {user: dealer/pending, session} + الملف). لا خادم ولا متصفح حقيقي:
   لا شيء هنا يثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const PASSWORD = 'Pa$$w0rd-SECRET-123';
const NAME = 'حسين التاجر';
const PHONE = '07711112222';
const root = path.join(__dirname, '..');
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

function dealerWorld(opts) {
  opts = opts || {};
  const w = world(); const dcalls = [];
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname !== '/v1/dealers/register') return base(url, init);
    dcalls.push({ path: u.pathname, method: init.method, headers: Object.fromEntries(Object.entries(init.headers || {}).map(([k, v]) => [k.toLowerCase(), v])), credentials: init.credentials, rawBody: init.body, body: init.body ? JSON.parse(init.body) : undefined });
    if (opts.gate) await opts.gate();
    const b = JSON.parse(init.body || '{}');
    const extra = Object.keys(b).filter(k => !['name', 'phone', 'password'].includes(k));
    if (extra.length) return json(400, { error: { code: 'validation_failed', message: 'x', fields: extra.map(k => ({ field: k, code: 'unknown_field' })), requestId: 'r' } });
    const r = await base(new URL('/v1/auth/register', u).href, init);
    if (r.status !== 201) return r;
    const data = await r.json();
    data.user = Object.assign({}, data.user, opts.userOverride || { role: 'dealer', status: 'pending' });
    return new Response(JSON.stringify(data), { status: 201, headers: r.headers });
  };
  return { w, dcalls };
}
function page(w, store) {
  const env = makeEnv(store || {});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  return {
    env, run: c => env.run(c), set, store: env.store,
    text: id => env.els[id] && env.els[id].textContent,
    user: () => env.run('SessionService.getCurrentUser()'),
    toast: () => env.els.toast && env.els.toast.textContent,
    fill(o) { o = Object.assign({ name: NAME, phone: PHONE, password: PASSWORD, confirm: PASSWORD }, o); env.run("go('register')"); set('regName', o.name); set('regPhone', o.phone); set('regPassword', o.password); set('regConfirm', o.confirm); },
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };

test('شاشة التسجيل: زر «تسجيل كصاحب معرض» في وضع الخادم فقط؛ الوضع المحلي دون تغيير', () => {
  const { w } = dealerWorld(); const p = page(w); p.run("go('register')");
  assert.match(p.env.screen(), /handleRemoteDealerRegister\(\)/); assert.match(p.env.screen(), /بانتظار موافقة الإدارة/);
  assert.ok(!/name="accountType"|id="regEmail"/.test(p.env.screen()));
  const env = makeEnv(); env.run("go('register')");
  assert.ok(!/handleRemoteDealerRegister/.test(env.screen()), 'لا زر في الوضع المحلي'); assert.match(env.screen(), /name="accountType"/);
  env.run('handleRemoteDealerRegister()'); assert.equal(env.run('SessionService.isLoggedIn()'), false, 'لا أثر في الوضع المحلي');
});

test('نجاح: طلب واحد بجسم {name, phone, password} فقط ونقل الملف؛ حساب dealer/pending يدخل به صاحبه؛ لا refreshToken في الواجهة؛ كلمة المرور تُمسح', async () => {
  const { w, dcalls } = dealerWorld(); const p = page(w); p.fill();
  await p.run('handleRemoteDealerRegister()'); await settle();
  assert.equal(dcalls.length, 1); const c = dcalls[0];
  assert.deepEqual(c.body, { name: NAME, phone: PHONE, password: PASSWORD }, 'لا دور ولا حالة ولا تأكيد في الجسم');
  assert.equal(c.headers['x-session-transport'], 'cookie'); assert.equal(c.credentials, 'same-origin');
  assert.ok(!/role|status|accountType|dealer/i.test(c.rawBody.replace(NAME, '')));
  const u = p.user(); assert.equal(u.role, 'dealer'); assert.equal(u.status, 'pending'); assert.equal(u.name, NAME);
  assert.equal(p.run('currentRoute'), 'account'); assert.match(p.toast(), /بانتظار موافقة الإدارة/);
  assert.equal(p.run("document.getElementById('regPassword').value"), '', 'كلمة المرور لا تبقى في الحقل');
  assert.ok(!/refreshToken|nsj_/.test(JSON.stringify(Array.from(Object.values(p.store || {})))), 'لا رمز تجديد في تخزين الواجهة');
  assert.equal(p.run('JSON.stringify(Object.keys(BackendAuth))').includes('refreshToken'), false);
});

test('الجلسة تُستعاد بعد إعادة التحميل بالملف (الدور dealer والحالة pending من الخادم)', async () => {
  const { w } = dealerWorld(); const p = page(w); p.fill(); await p.run('handleRemoteDealerRegister()'); await settle();
  const p2 = page(w, p.store); const r = await p2.run('restoreBackendSession()');
  assert.equal(r.status, 'restored'); assert.equal(w.srv.reuse || 0, 0);
  assert.equal(p2.user().name, NAME);
});

test('ردّ لا يطابق العقد (دور غير dealer أو حالة غير pending) يُرفض: لا جلسة محلية ولا تسجيل دخول', async () => {
  for (const ov of [{ role: 'user', status: 'active' }, { role: 'admin', status: 'active' }, { role: 'dealer', status: 'active' }]) {
    const { w } = dealerWorld({ userOverride: ov }); const p = page(w); p.fill();
    await p.run('handleRemoteDealerRegister()'); await settle();
    assert.equal(p.user(), null, JSON.stringify(ov)); assert.equal(p.run('currentRoute'), 'register'); assert.ok(p.text('registerError'));
  }
});

test('التحقق قبل الشبكة: اسم/هاتف/كلمة مرور/تطابق — بلا أي طلب', async () => {
  const { w, dcalls } = dealerWorld(); const p = page(w);
  for (const o of [{ name: 'ab' }, { phone: '123' }, { password: 'short', confirm: 'short' }, { confirm: 'different-One-1' }]) {
    p.fill(o); await p.run('handleRemoteDealerRegister()'); await settle(); assert.ok(p.text('registerError'), JSON.stringify(o));
  }
  assert.equal(dcalls.length, 0); assert.equal(w.srv.calls.length, 0); assert.equal(p.user(), null);
});

test('رقم مسجَّل: 409 برسالة عربية بلا جلسة؛ وانقطاع الشبكة رسالة عربية مع إعادة المحاولة', async () => {
  const { w, dcalls } = dealerWorld(); const p = page(w); p.fill(); await p.run('handleRemoteDealerRegister()'); await settle();
  await p.run('BackendAuth.logout()'); await settle();
  p.fill(); await p.run('handleRemoteDealerRegister()'); await settle();
  assert.equal(dcalls.length, 2); assert.equal(p.user(), null); assert.ok(p.text('registerError')); assert.ok(!/conflict|Error|undefined/.test(p.text('registerError')));
  w.srv.down = true; p.fill({ phone: '07733334444' }); await p.run('handleRemoteDealerRegister()'); await settle();
  assert.ok(p.text('registerError')); assert.equal(p.user(), null);
  w.srv.down = false; p.fill({ phone: '07733334444' }); await p.run('handleRemoteDealerRegister()'); await settle(); assert.equal(p.user() && p.user().role, 'dealer');
});

test('نقرتان متزامنتان = طلب واحد (قفل)', async () => {
  let release; const { w, dcalls } = dealerWorld({ gate: () => new Promise(r => { release = r; }) }); const p = page(w); p.fill();
  const a = p.run('handleRemoteDealerRegister()'); const b = p.run('handleRemoteDealerRegister()'); await settle();
  assert.equal(dcalls.length, 1); release(); await a; await b; await settle(); assert.equal(dcalls.length, 1); assert.equal(p.user().role, 'dealer');
});

test('المسار الدفاعي القديم محفوظ: اختيار «صاحب معرض» عبر الحقل المخفي برسالة عربية بلا شبكة', async () => {
  const { w, dcalls } = dealerWorld(); const p = page(w); p.fill(); p.env.radios.accountType = 'dealer';
  await p.run('handleRegisterSubmit()'); assert.equal(p.text('registerError'), p.run('BackendAuth.messages.dealerLater')); assert.equal(dcalls.length, 0);
});

test('حارس المصدر: الجسر والعميل يرسلان {name, phone, password} فقط؛ لا دور/حالة في التسجيل؛ لا تخزين/console؛ و87 سكربتًا', () => {
  const strip = f => fs.readFileSync(path.join(root, f), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '').replace(/\/\/[^\n]*$/gm, '');
  const bridge = strip('api/authBridge.js');
  const fn = bridge.slice(bridge.indexOf('async function registerDealer('), bridge.indexOf('async function completeRecovery('));
  assert.match(fn, /client\.registerDealer\(\{ name: name, phone: phone, password: pw \}/);
  assert.ok(!/accountType|role:|status:|confirmPassword:/.test(fn.replace(/mapped\.role|mapped\.status|ROLES\.|USER_STATUS\./g, '')));
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\./.test(fn));
  const client = strip('api/apiClient.js');
  assert.match(client, /DEALER_REGISTER_PATH = '\/v1\/dealers\/register'/); assert.match(client, /registerDealer: function \(body, validate\) \{ return authenticate\(DEALER_REGISTER_PATH, body, validate\); \}/);
  const actions = strip('navigation/actions.js'); const h = actions.slice(actions.indexOf('async function handleRemoteDealerRegister'), actions.indexOf('function handleRegisterSubmit'));
  assert.ok(!/accountType|regEmail|role/.test(h));
  assert.equal((fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/<script src=/g) || []).length, 87);
});

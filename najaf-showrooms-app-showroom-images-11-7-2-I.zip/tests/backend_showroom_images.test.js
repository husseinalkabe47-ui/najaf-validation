/* Phase 11.7.2-I — صور سيارات المعرض لصاحب المعرض عبر الخادم داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/showroom-car-images + assets): GET/POST/DELETE على /v1/dealer/cars/:id/images (الحد 5، أصل المتصل وحده)،
   POST /v1/me/assets?kind=car_image، GET /v1/me/assets/:id[/thumb|/image]، و/v1/public/cars/:id/images العام. لا خادم ولا قاعدة بيانات ولا متصفح حقيقي:
   النتائج لا تُثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const root = path.join(__dirname, '..');
const iso = '2026-01-01T00:00:00.000Z';
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const U = n => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const webp = n => new Response(new Blob([new Uint8Array(n)], { type: 'image/webp' }), { status: 200, headers: { 'content-type': 'image/webp' } });
const KEYS = ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description'];

function shWorld(role) {
  const w = world();
  const d = { role: role || 'dealer', seq: 100, aseq: 0, iseq: 0, max: 5, cars: [], images: {}, assets: {}, uploadStatus: 'ready', gate: null, fail: null, pubCars: {}, pubImages: {}, pubShowrooms: {} };
  d.car = o => { const c = Object.assign({ id: String(++d.seq), showroomId: '7', brand: 'Kia', model: 'Sportage', year: 2022, price: 18000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', status: 'available', version: 1, createdAt: iso, updatedAt: iso }, o); d.cars.unshift(c); d.images[c.id] = []; return c; };
  d.asset = (kind, status, owner) => { const a = { id: U(++d.aseq), kind, status: status || 'ready', bytes: 1000, width: 1600, height: 1200, createdAt: iso, owner: owner || 'me' }; d.assets[a.id] = a; return a; };
  d.attach = (carId, o) => { const a = d.asset('car_image'); a.attached = carId; const im = Object.assign({ id: 'i' + (++d.iseq), assetId: a.id, sortOrder: d.images[carId].length, isMain: d.images[carId].length === 0, width: 1600, height: 1200, createdAt: iso }, o); d.images[carId].push(im); return im; };
  d.pubCar = o => { const c = Object.assign({ id: String(++d.seq), sourceType: 'showroom', showroomId: '77', brand: 'Kia', model: 'Sportage', year: 2022, price: 18000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', status: 'available', phone: null, whatsapp: null, location: '', latitude: null, longitude: null, ownerName: null, createdAt: iso, updatedAt: iso }, o); d.pubCars[c.id] = c; return c; };
  d.pubShowroom = o => { const s = Object.assign({ id: '77', name: 'معرض الفرات', description: 'وصف', phone: '+9647801111111', whatsapp: null, address: 'النجف - الكوفة', latitude: 32.0, longitude: 44.3, workingHours: '9-5', services: ['صيانة'], createdAt: iso, updatedAt: iso }, o); d.pubShowrooms[s.id] = s; return s; };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    const mine = u.pathname.startsWith('/v1/me/') || u.pathname.startsWith('/v1/dealer/'), pub = u.pathname.startsWith('/v1/public/');
    if (!mine && !pub) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const raw = init.body instanceof Blob;
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, raw, size: raw ? init.body.size : undefined, body: init.body === undefined || raw ? undefined : JSON.parse(init.body) };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    let m;
    if (pub) {
      if (d.fail) { const f = d.fail(call); if (f) return f; }
      if ((m = /^\/v1\/public\/cars\/([^/]+)\/images$/.exec(u.pathname))) { const a = d.pubImages[m[1]]; return a === undefined ? err(404, 'not_found') : json(200, { images: a }); }
      if ((m = /^\/v1\/public\/cars\/([^/]+)$/.exec(u.pathname))) { const c = d.pubCars[m[1]]; return c ? json(200, { car: c }) : err(404, 'not_found'); }
      if ((m = /^\/v1\/public\/showrooms\/([^/]+)$/.exec(u.pathname))) { const s = d.pubShowrooms[m[1]]; return s ? json(200, { showroom: s }) : err(404, 'not_found'); }
      if (u.pathname === '/v1/public/cars') return json(200, { items: [], nextBefore: null });
      return err(404, 'not_found');
    }
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (call.method === 'POST' && u.pathname === '/v1/me/assets') {
      if (!call.raw || !['image/jpeg', 'image/png', 'image/webp'].includes(h['content-type'])) return err(415, 'unsupported_media_type');
      if (call.query.kind !== 'car_image') return err(400, 'validation_failed', [{ field: 'kind', code: 'invalid_format' }]);
      const a = d.asset('car_image', d.uploadStatus); a.bytes = call.size;
      return json(201, { asset: Object.assign({}, a, { owner: undefined }) });
    }
    if (call.method === 'GET' && (m = /^\/v1\/me\/assets\/([^/]+)(?:\/(thumb|image))?$/.exec(u.pathname))) {
      const a = d.assets[m[1]]; if (!a || a.owner !== 'me') return err(404, 'not_found');
      if (m[2]) return a.status === 'ready' ? webp(m[2] === 'thumb' ? 100 : 500) : err(404, 'not_found');
      return json(200, { asset: Object.assign({}, a, { owner: undefined }) });
    }
    if (d.role !== 'dealer') return err(404, 'not_found');   // الخادم: لا منطقة معرض لغير صاحب معرض فعّال
    if ((m = /^\/v1\/dealer\/cars\/([^/]+)\/images(?:\/([^/]+))?$/.exec(u.pathname))) {
      const c = d.cars.find(x => x.id === m[1]); if (!c) return err(404, 'not_found');
      const list = d.images[c.id];
      if (call.method === 'GET' && !m[2]) return json(200, { images: list.map(x => Object.assign({}, x)), maxImages: d.max });
      if (call.method === 'POST' && !m[2]) {
        const b = call.body, bad = Object.keys(b || {}).filter(k => k !== 'assetId').map(k => ({ field: k, code: 'unknown_field' }));
        if (!b || typeof b.assetId !== 'string') bad.push({ field: 'assetId', code: 'required' });
        if (bad.length) return err(400, 'validation_failed', bad);
        const a = d.assets[b.assetId]; if (!a || a.owner !== 'me') return err(404, 'not_found');
        if (a.kind !== 'car_image' || a.status !== 'ready' || a.attached) return err(409, 'invalid_state');
        if (list.length >= d.max) return err(409, 'image_limit');
        a.attached = c.id;
        const im = { id: 'i' + (++d.iseq), assetId: a.id, sortOrder: list.length, isMain: list.length === 0, width: 1600, height: 1200, createdAt: iso };
        list.push(im); return json(201, { image: Object.assign({}, im) });
      }
      if (call.method === 'DELETE' && m[2]) {
        const i = list.findIndex(x => x.id === m[2]); if (i < 0) return err(404, 'not_found');
        const was = list[i]; list.splice(i, 1); if (was.isMain && list[0]) list[0].isMain = true; list.forEach((x, n) => { x.sortOrder = n; }); return new Response(null, { status: 204 });
      }
      return err(405, 'method_not_allowed');
    }
    if ((m = /^\/v1\/dealer\/cars(?:\/([^/]+))?$/.exec(u.pathname))) {
      if (!m[1]) {
        if (call.method === 'GET') return json(200, { items: d.cars.map(x => Object.assign({}, x)), nextBefore: null });
        if (call.method === 'POST') { const c = d.car(Object.assign({}, call.body, { status: 'available', version: 1 })); return json(201, { car: Object.assign({}, c) }); }
      }
      const c = d.cars.find(x => x.id === m[1]); if (!c) return err(404, 'not_found');
      if (call.method === 'GET') return json(200, { car: Object.assign({}, c) });
    }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  const revoked = [], made = [];
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.ctx.Blob = Blob; env.ctx.__blob = (n, type) => new Blob([new Uint8Array(n)], { type });
  env.ctx.URL = class extends URL {
    static createObjectURL(b) { const u = 'blob:test/' + (made.length + 1); made.push({ u, type: b.type, size: b.size }); return u; }
    static revokeObjectURL(u) { revoked.push(u); }
  };
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  env.ctx.__enc = { n: 40000, calls: 0 };
  env.run("ImageService.setCodec({ decode: async f => ({ width: 3200, height: 2400, source: {}, close() {} }), encode: async (dec, w, h, mime, q) => { __enc.calls++; return __blob(__enc.n, mime); } })");
  return {
    env, revoked, made, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    toast: () => env.els.toast && env.els.toast.textContent,
    section: () => env.run('RemoteImagesInner()'),
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
    pick(type) { env.ctx.__in = { files: [{ type: type === undefined ? 'image/png' : type, name: 'car.png' }], value: 'C:\\fake\\car.png' }; return env.run('handleRemoteImagePick(__in)'); },
    set: (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`),
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p, route, param) { await p.login(); p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle(); }
const yes = p => p.run('askConfirm = (spec, ok) => ok()');
const no = p => p.run('askConfirm = (spec, ok, cancel) => { if (typeof cancel === "function") cancel(); }');
const DIMGS = /^\/v1\/dealer\/cars\/[^/]+\/images/, MIMGS = /^\/v1\/me\/cars\/[^/]+\/images/;

test('شاشة تعديل سيارة المعرض: الصور تُجلب من /v1/dealer/cars/:id/images (لا /v1/me)، الحد 5 من الخادم، وبلا اختيار رئيسية ولا ترتيب', async () => {
  const { w, d } = shWorld(); const c = d.car({}); d.attach(c.id); d.attach(c.id);
  const p = page(w); await open(p, 'editShowroomCar', c.id);
  const g = p.calls('GET', DIMGS); assert.equal(g.length, 1); assert.equal(g[0].path, `/v1/dealer/cars/${c.id}/images`); assert.match(g[0].headers.authorization, /^Bearer AT-/);
  assert.equal(p.calls('GET', MIMGS).length, 0, 'لا مسار صور العضو');
  assert.match(p.section(), /الصور 2 \/ 5/); assert.match(p.section(), /رئيسية/); assert.match(p.section(), /type="file"/);
  assert.match(p.screen(), /id="showroomImgLabel"/); assert.ok(!/imgPickerLabel|handlePickImages/.test(p.screen()), 'لا منتقي الوضع المحلي');
  assert.ok(!/تعيين|اجعلها رئيسية|setMain|moveUp|moveDown|ترتيب/.test(p.section()), 'لا اختيار للرئيسية ولا إعادة ترتيب');
  assert.equal(p.calls('GET', /\/thumb$/).length, 2); assert.deepEqual(p.env.errors, []);
});

test('الإضافة: ضغط ثم رفع kind=car_image ثم POST /v1/dealer/cars/:id/images {assetId} فقط، يتحدّث القسم وحده ولا يضيع ما كُتب في الحقول', async () => {
  const { w, d } = shWorld(); const c = d.car({});
  const p = page(w); await open(p, 'editShowroomCar', c.id);
  const formBefore = p.screen();
  w.srv.calls.length = 0;
  await p.pick('image/png'); await settle();
  assert.equal(p.screen(), formBefore, 'النموذج لا يُعاد رسمه'); assert.equal(p.env.els.remoteImages.innerHTML, p.section());
  const up = p.calls('POST', /^\/v1\/me\/assets$/)[0]; assert.equal(up.query.kind, 'car_image'); assert.equal(up.raw, true); assert.equal(up.headers['content-type'], 'image/webp'); assert.equal(up.size, 40000);
  const at = p.calls('POST', DIMGS); assert.equal(at.length, 1); assert.equal(at[0].path, `/v1/dealer/cars/${c.id}/images`); assert.deepEqual(Object.keys(at[0].body), ['assetId']);
  assert.equal(p.calls('POST', MIMGS).length, 0);
  assert.equal(d.images[c.id].length, 1); assert.equal(d.images[c.id][0].isMain, true); assert.match(p.section(), /الصور 1 \/ 5/); assert.match(p.toast(), /تمت إضافة الصورة/);
  assert.equal(p.calls('GET', DIMGS).length >= 1, true, 'تحديث هادئ من الخادم');
  assert.ok(!/blob:|image|webp/i.test(JSON.stringify(p.env.store)), 'لا شيء من الصور في التخزين المحلي');
  assert.deepEqual(p.env.errors, []);
});

test('منع الرفع المكرر أثناء رفع جارٍ = رفع واحد', async () => {
  const { w, d } = shWorld(); const c = d.car({});
  const p = page(w); await open(p, 'editShowroomCar', c.id);
  let release; d.gate = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? new Promise(r => { release = r; }) : null);
  const a = p.pick(); await settle();
  assert.match(p.section(), /جارٍ رفع الصورة/); assert.ok(!/type="file"/.test(p.section()));
  await p.pick();
  assert.equal(p.calls('POST', /^\/v1\/me\/assets$/).length, 1);
  release(); await a; await settle();
  assert.equal(d.images[c.id].length, 1); assert.equal(p.calls('POST', DIMGS).length, 1);
});

test('الحد الأقصى 5: عند الخامسة لا زر إضافة وتظهر رسالة الحد؛ الإضافة المباشرة بلا أي POST؛ وسباق الحد (409 image_limit) يُحدَّث من الخادم', async () => {
  const { w, d } = shWorld(); const c = d.car({}); for (let i = 0; i < 5; i++) d.attach(c.id);
  const p = page(w); await open(p, 'editShowroomCar', c.id);
  assert.match(p.section(), /الصور 5 \/ 5/); assert.match(p.section(), /الحد الأقصى من الصور/); assert.ok(!/type="file"/.test(p.section()));
  w.srv.calls.length = 0; await p.pick(); await settle();
  assert.equal(p.calls('POST', /^\/v1\//).length, 0); assert.equal(p.run('__enc.calls'), 0);
  const e = shWorld(); const c2 = e.d.car({}); for (let i = 0; i < 4; i++) e.d.attach(c2.id);
  const q = page(e.w); await open(q, 'editShowroomCar', c2.id);
  assert.match(q.section(), /الصور 4 \/ 5/); assert.match(q.section(), /type="file"/);
  e.d.attach(c2.id);   // صورة أضافها طلب آخر بعد قراءة القائمة
  await q.pick(); await settle();
  assert.match(q.section(), /الحد الأقصى/); assert.match(q.section(), /الصور 5 \/ 5/); assert.equal(e.d.images[c2.id].length, 5);
});

test('الحذف: تأكيد ثم DELETE /v1/dealer/cars/:id/images/:imageId؛ الرئيسية تنتقل؛ رفض التأكيد = لا طلب؛ 404 من الخادم = رسالة بلا تغيير وهمي', async () => {
  const { w, d } = shWorld(); const c = d.car({}); const i1 = d.attach(c.id); const i2 = d.attach(c.id);
  const p = page(w); await open(p, 'editShowroomCar', c.id); no(p);
  await p.run(`handleRemoteImageRemove('${i1.id}')`); await settle(); assert.equal(p.calls('DELETE', DIMGS).length, 0);
  yes(p); await p.run(`handleRemoteImageRemove('${i1.id}')`); await settle();
  const dc = p.calls('DELETE', DIMGS); assert.equal(dc.length, 1); assert.equal(dc[0].path, `/v1/dealer/cars/${c.id}/images/${i1.id}`); assert.match(dc[0].headers.authorization, /^Bearer AT-/);
  assert.equal(p.calls('DELETE', MIMGS).length, 0);
  assert.equal(d.images[c.id].length, 1); assert.match(p.section(), /الصور 1 \/ 5/); assert.match(p.section(), /رئيسية/); assert.match(p.toast(), /تم حذف الصورة/); assert.ok(p.revoked.length >= 1);
  d.fail = call => (call.method === 'DELETE' ? err(404, 'not_found') : null);
  await p.run(`handleRemoteImageRemove('${i2.id}')`); await settle(); assert.ok(!/تم حذف الصورة الأخيرة/.test(p.toast() || '')); assert.equal(d.images[c.id].length, 1);
});

test('مخالفات الملكية من الخادم: سيارة ليست لك/أصل ليس لك = 404، حساب غير صاحب معرض = 404 على القراءة، 409 invalid_state — رسائل عربية، لا صورة وهمية، لا رجوع لبيانات محلية', async () => {
  { const { w, d } = shWorld(); const c = d.car({}); const p = page(w); await open(p, 'editShowroomCar', c.id);
    d.fail = call => (call.method === 'POST' && DIMGS.test(call.path) ? err(404, 'not_found') : null);
    await p.pick(); await settle(); assert.match(p.section(), /غير موجود أو لم يعد لك/); assert.equal(d.images[c.id].length, 0); assert.ok(!/<img/.test(p.section())); }
  { const { w, d } = shWorld(); const c = d.car({}); const p = page(w); await open(p, 'editShowroomCar', c.id);
    const foreign = d.asset('car_image', 'ready', 'other');   // أصل غير ملك المتصل: الخادم يرد 404 ولا يُرفق
    d.fail = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? json(201, { asset: { id: foreign.id, kind: 'car_image', status: 'ready', bytes: 1, width: 1, height: 1, createdAt: iso } }) : null);
    await p.pick(); await settle(); assert.equal(d.images[c.id].length, 0); assert.equal(foreign.attached, undefined); assert.match(p.section(), /غير موجود أو لم يعد لك/); }
  { const { w, d } = shWorld(); const c = d.car({}); const p = page(w); await open(p, 'editShowroomCar', c.id);
    d.fail = call => (call.method === 'POST' && DIMGS.test(call.path) ? err(409, 'invalid_state') : null);
    await p.pick(); await settle(); assert.match(p.section(), /لا يمكن استخدام هذه الصورة الآن/); assert.equal(d.images[c.id].length, 0); }
  { const { w, d } = shWorld(); const c = d.car({}); d.attach(c.id); const p = page(w); await open(p, 'editShowroomCar', c.id);
    d.fail = call => (DIMGS.test(call.path) && call.method === 'GET' ? err(403, 'forbidden') : null);
    await p.run('BackendImages.retryGallery(currentParam, refreshRemoteImages, "showroom")'); await settle(); assert.match(p.section(), /لا يملك صلاحية إدارة الصور|غير موجود/); assert.ok(!/type="file"/.test(p.section())); }
  { const { w, d } = shWorld(); const c = d.car({}); const p = page(w); await open(p, 'editShowroomCar', c.id);
    d.fail = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? err(503, 'storage_unavailable') : null);
    await p.pick(); await settle(); assert.match(p.section(), /خدمة تخزين الصور غير متاحة/); assert.equal(p.calls('POST', DIMGS).length, 0); }
});

test('فشل تحميل الصور = رسالة عربية + إعادة المحاولة بالنطاق نفسه (/v1/dealer) ثم نجاح؛ بلا صور محلية', async () => {
  const { w, d } = shWorld(); const c = d.car({}); d.attach(c.id);
  d.fail = call => (DIMGS.test(call.path) && call.method === 'GET' ? err(500, 'internal') : null);
  const p = page(w); await open(p, 'editShowroomCar', c.id);
  assert.match(p.section(), /إعادة المحاولة/); assert.ok(!/<img/.test(p.section()));
  d.fail = null; w.srv.calls.length = 0; p.run('handleRemoteImagesRetry()'); await settle();
  assert.equal(p.calls('GET', DIMGS).length >= 1, true); assert.equal(p.calls('GET', MIMGS).length, 0); assert.match(p.section(), /الصور 1 \/ 5/);
});

test('الإضافة (إنشاء): لا منتقي صور ولا طلبات صور؛ ملاحظة تقول إن الصور تُضاف من «تعديل السيارة»، والرسالة بعد النشر تذكر ذلك', async () => {
  const { w, d } = shWorld(); const p = page(w); await open(p, 'addShowroomCar');
  assert.match(p.screen(), /scBrand/); assert.ok(!/imgPickerLabel|handlePickImages|showroomImgLabel|type="file"/.test(p.screen()));
  assert.match(p.screen(), /من «تعديل السيارة»/);
  p.set('scBrand', 'Kia'); p.set('scModel', 'Sportage'); p.set('scYear', '2022'); p.set('scPrice', '18000000'); p.set('scCurrency', 'IQD'); p.set('scMileage', ''); p.set('scTransmission', 'يدوي'); p.set('scFuelType', 'ديزل'); p.set('scColor', 'أسود'); p.set('scDescription', 'وصف');
  await p.run('handleAddShowroomCarSubmit()'); await settle();
  assert.equal(d.cars.length, 1); assert.equal(p.route(), 'myShowroomCars'); assert.match(p.toast(), /تعديل السيارة/);
  assert.equal(p.calls('GET', DIMGS).length + p.calls('POST', DIMGS).length, 0);
  Object.keys(d.cars[0]).forEach(k => assert.ok(!['images', 'imageIds', 'assetId'].includes(k)));
});

test('الصور بعد الإنشاء: من شاشة تعديل السيارة المنشأة حتى 5، وتصل إلى الحالة 5/5', async () => {
  const { w, d } = shWorld(); const p = page(w); await open(p, 'addShowroomCar');
  const c = d.car({}); p.run(`go('editShowroomCar', '${c.id}')`); await settle();
  for (let i = 0; i < 5; i++) { await p.pick(); await settle(); }
  assert.equal(d.images[c.id].length, 5); assert.match(p.section(), /الصور 5 \/ 5/); assert.equal(d.images[c.id].filter(x => x.isMain).length, 1); assert.ok(!/type="file"/.test(p.section()));
});

test('العرض العام: تفاصيل سيارة معرض تعرض صورها من /v1/public/cars/:id/images بروابط عامة مباشرة (بلا Bearer)، الرئيسية أولًا، وشريط للمتعدد؛ بلا صور = 🚘', async () => {
  const { w, d } = shWorld(); d.pubShowroom({});
  const c = d.pubCar({}); d.pubImages[c.id] = [{ assetId: U(82), isMain: false, sortOrder: 1, width: 1600, height: 1200 }, { assetId: U(81), isMain: true, sortOrder: 0, width: 1600, height: 1200 }];
  const p = page(w); p.run(`go('carDetails', '${c.id}')`); await settle();
  const h = p.screen();
  assert.equal(p.calls('GET', /^\/v1\/public\/cars\/[^/]+\/images$/).length, 1); assert.ok(!p.calls('GET', /^\/v1\/public\/cars\/[^/]+\/images$/)[0].headers.authorization, 'بلا Bearer');
  assert.match(h, /معرض الفرات/);
  assert.match(h, new RegExp(`detail-hero"><img src="[^"]*/v1/public/assets/${U(81)}/image"`)); assert.match(h, /img-strip/); assert.match(h, new RegExp(U(82)));
  assert.ok(h.indexOf(U(81)) < h.indexOf(U(82)), 'الرئيسية أولًا');
  const c2 = d.pubCar({}); d.pubImages[c2.id] = []; p.run(`go('carDetails', '${c2.id}')`); await settle(); assert.match(p.screen(), /🚘/); assert.ok(!/img-strip/.test(p.screen()));
  assert.deepEqual(p.env.errors, []);
});

test('حراس: النطاق showroom يمر بمسار الصور وحده؛ الشاشة والإجراءات تمرّره؛ الوضع المحلي لم يُمسّ؛ 87 سكربتًا', () => {
  const rd = f => fs.readFileSync(path.join(root, f), 'utf8');
  const strip = f => rd(f).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.match(rd('screens/addShowroomCar.js'), /RemoteImagesHtml\(c\.id, 'editShowroomCar', 'showroom'\)/);
  assert.match(rd('components/imagePicker.js'), /BackendImages\.gallery\(_riCar, refreshRemoteImages, false, _riScope\)/);
  const act = rd('navigation/actions.js');
  assert.match(act, /BackendImages\.addToCar\(_riCar, file, refreshRemoteImages, _riScope\)/); assert.match(act, /BackendImages\.removeFromCar\(_riCar, String\(imageId\), refreshRemoteImages, _riScope\)/);
  assert.match(strip('screens/editShowroomCar.js'), /initImageCtxCar\(id\);[\s\S]*ImagePickerHtml\(\)/, 'فرع الوضع المحلي ما زال بمنتقي الصور المحلي');
  assert.match(strip('screens/addShowroomCar.js'), /initImageCtxDraft\(IMAGE_LIMITS\.SHOWROOM_MAX_IMAGES\)/);
  const all = rd('api/authBridge.js'); const a = all.indexOf('const BackendImages'), b = all.indexOf('const BackendFavorites');
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/api\.(post|put|patch|delete)\(\s*'\/v1\/dealer\/cars/.test(src), 'لا إنشاء/تعديل سيارات من جسر الصور');
  assert.ok(!/setMain|isMain\s*:\s*true.*api\.(patch|put)|sortOrder.*api\.(patch|put)|reorder/i.test(src), 'لا اختيار رئيسية ولا ترتيب');
  assert.equal((rd('index.html').match(/<script src=/g) || []).length, 87);
});

/* Phase 11.7-E — إدارة أصحاب المعارض (المدير) عبر /v1/admin/dealers داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/dealers/routes.ts): GET بحالة/after/limit (الافتراضي pending)، وPOST approve|reject|suspend|reactivate
   بلا جسم، 404 لغير المدير، 409 invalid_state، وحقول مجهولة = 400. لا خادم ولا قاعدة بيانات حقيقية: النتائج لا تُثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const root = path.join(__dirname, '..');
const iso = '2026-01-01T00:00:00.000Z';
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const TRANS = { approve: ['pending', 'active'], reject: ['pending', 'suspended'], suspend: ['active', 'suspended'], reactivate: ['suspended', 'active'] };

function adminWorld(role) {
  const w = world();
  const d = { role: role || 'admin', seq: 200, dealers: [], fail: null, gate: null };
  d.dealer = o => { const x = Object.assign({ id: String(++d.seq), name: 'تاجر ' + d.seq, phone: '+9647801' + String(d.seq).padStart(6, '0'), status: 'pending', phoneVerified: false, createdAt: iso, showroom: null }, o); d.dealers.push(x); return x; };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    if (!u.pathname.startsWith('/v1/admin/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, rawBody: init.body };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (d.role !== 'admin') return err(404, 'not_found');
    if (call.method === 'GET' && u.pathname === '/v1/admin/dealers') {
      const q = call.query, bad = Object.keys(q).filter(k => !['status', 'after', 'limit'].includes(k)).map(f => ({ field: f, code: 'unknown_field' }));
      const status = q.status === undefined ? 'pending' : q.status;
      if (!['pending', 'active', 'suspended'].includes(status)) bad.push({ field: 'status', code: 'invalid_format' });
      const limit = q.limit === undefined ? 50 : Number(q.limit); if (!(limit >= 1 && limit <= 100)) bad.push({ field: 'limit', code: 'invalid_format' });
      if (q.after !== undefined && !/^[1-9][0-9]{0,18}$/.test(q.after)) bad.push({ field: 'after', code: 'invalid_format' });
      if (bad.length) return err(400, 'validation_failed', bad);
      let rows = d.dealers.filter(x => x.status === status).sort((a, b) => Number(a.id) - Number(b.id));
      if (q.after) rows = rows.filter(x => Number(x.id) > Number(q.after));
      const page = rows.slice(0, limit);
      return json(200, { dealers: page.map(x => Object.assign({}, x)), nextAfter: page.length === limit ? page[page.length - 1].id : null });
    }
    const m = /^\/v1\/admin\/dealers\/([^/]+)\/(approve|reject|suspend|reactivate)$/.exec(u.pathname);
    if (call.method === 'POST' && m) {
      if (call.rawBody !== undefined) return err(400, 'validation_failed', [{ field: 'body', code: 'invalid_type' }]);
      const x = d.dealers.find(y => y.id === m[1]); if (!x) return err(404, 'not_found');
      const [from, to] = TRANS[m[2]]; if (x.status !== from) return err(409, 'invalid_state');
      x.status = to; if (to === 'active' && !x.showroom) x.showroom = { id: String(++d.seq), status: 'active' }; else if (x.showroom) x.showroom.status = to === 'active' ? 'active' : 'suspended';
      return json(200, { dealer: Object.assign({}, x) });
    }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  return {
    env, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    adminCalls: () => w.srv.calls.filter(c => c.path.startsWith('/v1/admin/')),
    toast: () => env.els.toast && env.els.toast.textContent,
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p, route, param) { await p.login(); p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle(); }
const yes = p => p.run('askConfirm = (spec, ok) => ok()');
const no = p => p.run('askConfirm = (spec, ok, cancel) => { if (typeof cancel === "function") cancel(); }');
const LIST = /^\/v1\/admin\/dealers$/;
const act = a => new RegExp(`^/v1/admin/dealers/\\d+/${a}$`);

test('الوضع المحلي دون تغيير: BackendAdmin معطّل، لوحة الإدارة وطلبات التجار محلية بإحصاءاتها وأزرارها، وبلا اتصال', async () => {
  const env = makeEnv();
  assert.equal(env.run('BackendAdmin.isEnabled()'), false);
  env.run("AuthService.login('07700000000', 'admin123')");
  env.run("go('adminHome')");
  assert.match(env.screen(), /إجمالي المستخدمين/); assert.match(env.screen(), /stat-card/);
  env.run("go('adminDealerRequests')"); assert.match(env.screen(), /طلبات أصحاب المعارض/);
  env.run("go('adminUsers')"); assert.match(env.screen(), /المستخدمون/); assert.ok(!/غير متاح بعد مع الخادم/.test(env.screen()));
  env.run("go('adminShowrooms')"); assert.match(env.screen(), /إدارة المعارض/); assert.ok(!/غير متاح بعد مع الخادم/.test(env.screen()));
  assert.deepEqual(env.errors, []);
});

test('الحراسة: الزائر = تسجيل دخول، وغير المدير = رفض بلا أي طلب إداري', async () => {
  { const { w } = adminWorld(); const p = page(w); p.run("go('adminDealerRequests')"); assert.equal(p.route(), 'login'); assert.equal(p.adminCalls().length, 0); }
  for (const role of ['user', 'dealer']) {
    const { w } = adminWorld(role); const p = page(w); await open(p, 'adminDealerRequests');
    assert.notEqual(p.route(), 'adminDealerRequests', role); assert.equal(p.adminCalls().length, 0, role);
  }
});

test('اللوحة: بلا إحصاءات محلية؛ قسم أصحاب المعارض مع عدّاد المنتظرين من الخادم؛ وما لا تدعمه الخلفية مذكور صراحةً', async () => {
  const { w, d } = adminWorld(); d.dealer({}); d.dealer({}); d.dealer({ status: 'active' });
  const p = page(w); await open(p, 'adminHome');
  const h = p.screen();
  assert.ok(!/إجمالي المستخدمين|stat-card|سيارات الأعضاء<|قيد المراجعة/.test(h), 'لا إحصاءات محلية');
  assert.match(h, /أصحاب المعارض[^<]*<span class="badge-count">2<\/span>/); assert.match(h, /غير متاح بعد مع الخادم/);
  const g = p.calls('GET', LIST); assert.equal(g.length, 1); assert.deepEqual(g[0].query, { status: 'pending', limit: '50' }); assert.match(g[0].headers.authorization, /^Bearer AT-/);
  assert.deepEqual(p.env.errors, []);
});

test('طلبات التجار: «جارٍ التحميل…» ثم الصفوف بالاسم والهاتف وأزرار موافقة/رفض؛ وتبويبات فعّالون/موقوفون تطلب حالتها مرة واحدة بأزرارها', async () => {
  const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); d.dealer({ name: 'علي', status: 'active', showroom: { id: '9', status: 'active' } }); d.dealer({ name: 'زين', status: 'suspended' });
  let release; d.gate = c => (LIST.test(c.path) && !release ? new Promise(r => { release = r; }) : null);
  const p = page(w); await p.login(); p.run("go('adminDealerRequests')"); await settle();
  assert.match(p.screen(), /جارٍ تحميل أصحاب المعارض/); release(); await settle();
  let h = p.screen();
  assert.match(h, /حيدر/); assert.match(h, new RegExp(`handleAdminDealerAction\\('approve','${a.id}'\\)`)); assert.match(h, new RegExp(`handleAdminDealerAction\\('reject','${a.id}'\\)`)); assert.ok(!/علي|زين/.test(h));
  p.run("handleAdminDealersTab('active')"); await settle(); h = p.screen();
  assert.match(h, /علي/); assert.match(h, /handleAdminDealerAction\('suspend'/); assert.ok(!/approve'/.test(h));
  p.run("handleAdminDealersTab('suspended')"); await settle(); h = p.screen();
  assert.match(h, /زين/); assert.match(h, /handleAdminDealerAction\('reactivate'/);
  p.run("handleAdminDealersTab('pending')"); await settle();
  assert.deepEqual(p.calls('GET', LIST).map(c => c.query.status), ['pending', 'active', 'suspended'], 'كل تبويب يُجلب مرة واحدة');
});

test('الموافقة: POST /approve بلا جسم وبالرمز، يختفي الطلب، تظهر رسالة النجاح، ويظهر في «فعّالون» من الخادم (مع حالة معرضه)', async () => {
  const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); d.dealer({ name: 'كاظم' });
  const p = page(w); await open(p, 'adminDealerRequests');
  await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
  const c = p.calls('POST', act('approve')); assert.equal(c.length, 1); assert.equal(c[0].path, `/v1/admin/dealers/${a.id}/approve`); assert.equal(c[0].rawBody, undefined); assert.equal(c[0].headers['content-type'], undefined); assert.match(c[0].headers.authorization, /^Bearer AT-/);
  assert.equal(d.dealers[0].status, 'active'); assert.match(p.toast(), /تمت الموافقة على صاحب المعرض/);
  assert.ok(!/حيدر/.test(p.screen())); assert.match(p.screen(), /كاظم/);
  p.run("handleAdminDealersTab('active')"); await settle(); assert.match(p.screen(), /حيدر/); assert.match(p.screen(), /handleAdminDealerAction\('suspend'/);
});

test('الرفض والإيقاف: يطلبان تأكيدًا (رفض التأكيد = لا طلب)؛ ثم POST بلا جسم؛ والموقوف يظهر بزر «إعادة تفعيل» فيعود فعّالًا', async () => {
  const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' });
  const p = page(w); await open(p, 'adminDealerRequests');
  no(p); await p.run(`handleAdminDealerAction('reject','${a.id}')`); await settle(); assert.equal(p.calls('POST', /dealers/).length, 0); assert.equal(a.status, 'pending');
  yes(p); await p.run(`handleAdminDealerAction('reject','${a.id}')`); await settle();
  assert.equal(p.calls('POST', act('reject')).length, 1); assert.equal(a.status, 'suspended'); assert.match(p.toast(), /تم رفض الطلب/); assert.match(p.screen(), /لا توجد طلبات بانتظار المراجعة/);
  p.run("handleAdminDealersTab('suspended')"); await settle(); assert.match(p.screen(), /حيدر/); assert.match(p.screen(), /handleAdminDealerAction\('reactivate'/);
  await p.run(`handleAdminDealerAction('reactivate','${a.id}')`); await settle();
  assert.equal(a.status, 'active'); assert.match(p.toast(), /إعادة تفعيل/);
  p.run("handleAdminDealersTab('active')"); await settle();
  no(p); await p.run(`handleAdminDealerAction('suspend','${a.id}')`); await settle(); assert.equal(a.status, 'active');
  yes(p); await p.run(`handleAdminDealerAction('suspend','${a.id}')`); await settle(); assert.equal(a.status, 'suspended'); assert.match(p.toast(), /إيقاف الحساب/);
});

test('منع التكرار: نقرتان/استدعاءان متزامنان = طلب POST واحد، والأزرار معطّلة أثناء التنفيذ، ثم يُحرَّر القفل', async () => {
  const { w, d } = adminWorld(); const a = d.dealer({}), b = d.dealer({});
  const p = page(w); await open(p, 'adminDealerRequests');
  let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
  const x = p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
  assert.match(p.screen(), /جارٍ تنفيذ الإجراء/); assert.match(p.screen(), /<button class="approve" disabled/);
  const y = p.run(`handleAdminDealerAction('approve','${a.id}')`), z = p.run(`handleAdminDealerAction('approve','${b.id}')`); await y; await z;
  const direct = await p.run(`BackendAdmin.act('approve','${b.id}')`); assert.equal(direct.busy, true);
  assert.equal(p.calls('POST', /dealers/).length, 1, 'طلب كتابة واحد'); assert.equal(b.status, 'pending');
  d.gate = null; release(); await x; await settle();
  assert.equal(a.status, 'active'); assert.ok(!/ disabled/.test(p.screen()));
  await p.run(`handleAdminDealerAction('approve','${b.id}')`); await settle(); assert.equal(b.status, 'active', 'القفل حُرِّر');
});

test('الأخطاء: 409 (قرار مدير آخر) / 404 تعيدان التحميل برسالة؛ 403 / 400 / 500 / انقطاع شبكة = رسائل عربية وتبقى القائمة؛ لا رجوع لبيانات محلية', async () => {
  { const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); const p = page(w); await open(p, 'adminDealerRequests');
    a.status = 'active';   // مدير آخر وافق
    await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
    assert.match(p.toast(), /تغيّرت حالة هذا الحساب/); assert.ok(!/حيدر/.test(p.screen()), 'القائمة أُعيد جلبها من الخادم'); assert.equal(p.calls('GET', LIST).length, 2); }
  { const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); const p = page(w); await open(p, 'adminDealerRequests');
    d.dealers = []; await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle(); assert.match(p.toast(), /غير موجود أو لم يعد متاحًا/); assert.match(p.screen(), /لا توجد طلبات/); }
  for (const [status, code, re] of [[403, 'forbidden', /ليس لديك صلاحية/], [400, 'validation_failed', /تعذّر تنفيذ الإجراء/], [500, 'internal', /خطأ في الخادم/]]) {
    const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); const p = page(w); await open(p, 'adminDealerRequests');
    d.fail = c => (c.method === 'POST' ? err(status, code) : null);
    await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
    assert.match(p.toast(), re, String(status)); assert.match(p.screen(), /حيدر/, 'الصف يبقى'); assert.equal(a.status, 'pending');
    d.fail = null; await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle(); assert.equal(a.status, 'active', 'القفل حُرِّر');
  }
  { const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); const p = page(w); await open(p, 'adminDealerRequests');
    w.srv.down = true; await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
    assert.match(p.toast(), /تعذّر الاتصال/); assert.match(p.screen(), /حيدر/); assert.equal(a.status, 'pending'); }
});

test('أخطاء القراءة: 500 = رسالة + إعادة المحاولة ثم نجاح؛ 404/403 (غير مدير) = «للمدير فقط»؛ ولا قائمة محلية', async () => {
  { const { w, d } = adminWorld(); d.dealer({ name: 'حيدر' }); d.fail = c => (LIST.test(c.path) ? err(500, 'internal') : null);
    const p = page(w); await open(p, 'adminDealerRequests');
    assert.match(p.screen(), /خطأ في الخادم/); assert.match(p.screen(), /handleAdminDealersRetry/); assert.ok(!/حيدر/.test(p.screen()));
    d.fail = null; await p.run('handleAdminDealersRetry()'); await settle(); assert.match(p.screen(), /حيدر/); }
  for (const status of [404, 403]) {
    const { w, d } = adminWorld(); d.fail = c => (LIST.test(c.path) ? err(status, 'not_found') : null);
    const p = page(w); await open(p, 'adminDealerRequests'); assert.match(p.screen(), /للمدير فقط/); assert.ok(!/approve'/.test(p.screen())); }
});

test('الترقيم: nextAfter ← «عرض المزيد» (after=آخر معرّف)، الصفحة الثانية تُضاف، وفشلها يعرض رسالة ويُبقي الصفوف', async () => {
  const { w, d } = adminWorld(); for (let i = 0; i < 53; i++) d.dealer({ name: 'تاجر-' + (1000 + i) });
  const p = page(w); await open(p, 'adminDealerRequests');
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 50); assert.match(p.screen(), /handleAdminDealersMore/);
  d.fail = c => (c.query.after ? err(500, 'internal') : null);
  await p.run('handleAdminDealersMore()'); await settle(); assert.match(p.screen(), /خطأ في الخادم/); assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 50);
  d.fail = null; await p.run('handleAdminDealersMore()'); await settle();
  const g = p.calls('GET', LIST); assert.equal(g[g.length - 1].query.after, d.dealers[49].id);
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 53); assert.ok(!/handleAdminDealersMore/.test(p.screen()));
});

test('الجلسة: انتهاؤها أثناء الإجراء يعيد للدخول برسالة الانتهاء بلا تغيير؛ والخروج/تبديل المستخدم أثناء إجراء جارٍ لا يلوّث الحالة', async () => {
  { const { w, d } = adminWorld(); const a = d.dealer({}); const p = page(w); await open(p, 'adminDealerRequests');
    w.srv.families.forEach(f => { f.revoked = true; });
    await p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
    assert.equal(p.route(), 'login'); assert.equal(a.status, 'pending'); assert.equal(p.toast(), p.run('BackendAuth.messages.expired')); }
  { const { w, d } = adminWorld(); const a = d.dealer({ name: 'حيدر' }); const p = page(w); await open(p, 'adminDealerRequests');
    let release; d.gate = c => (c.method === 'POST' ? new Promise(r => { release = r; }) : null);
    const x = p.run(`handleAdminDealerAction('approve','${a.id}')`); await settle();
    p.run('handleLogout()'); await settle();
    await p.run("BackendAuth.login('07700000004', 'Pa55w0rd-1')"); d.gate = null; release(); await x; await settle();
    p.run("go('adminDealerRequests')"); await settle();
    assert.match(p.screen(), /تاجر|لا توجد طلبات|حيدر/); assert.equal(p.run("BackendAdmin.view().busy"), false, 'القفل حُرِّر للمستخدم الجديد'); }
});

test('الشاشات غير المدعومة في الخلفية: ملاحظة صريحة «غير متاح بعد مع الخادم»، بلا بيانات محلية، وبلا أي طلب لمسار مُختلَق', async () => {
  const { w, d } = adminWorld(); const p = page(w); await p.login();
  for (const [route, param] of [['adminUsers'], ['adminUserDetails', '1'], ['adminMemberCars', 'all'], ['adminMemberCarDetails', '1'], ['adminShowrooms'], ['adminShowroomCars']]) {
    p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle();
    assert.match(p.screen(), /غير متاح بعد مع الخادم/, route); assert.ok(!/حيدر عبد الكاظم|Toyota|تويوتا|معرض الكوفة|مدير المنصة/.test(p.screen()), 'لا بيانات تجريبية في ' + route);
    assert.match(p.screen(), /go\('adminDealerRequests'\)/);
  }
  assert.equal(p.adminCalls().length, 0, 'لا طلب إداري من الشاشات غير المدعومة'); assert.deepEqual(p.env.errors, []);
});

test('حارس المصدر: BackendAdmin مساراته /v1/admin/dealers فقط، POST بلا جسم، بلا تخزين/console/fetch؛ لا استدعاء لـ showroom-cars؛ و87 سكربتًا', () => {
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendAdmin'), b = all.indexOf('const BackendImages');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|\beval\(|new Function|Repository|AppStorage|innerHTML/.test(src));
  const paths = [...src.matchAll(/'(\/v1\/[^']*)'/g)].map(m => m[1].replace(/\/$/, ''));
  assert.deepEqual([...new Set(paths)].sort(), ['/v1/admin/dealers']);
  assert.ok(!/showroom-cars|\/v1\/dealer|\/v1\/me|\/v1\/public/.test(src));
  const writes = [...src.matchAll(/api\.(post|put|patch|delete)\(([^)]*)\)/g)].map(m => m[1] + ' ' + m[2]);
  assert.deepEqual(writes, ["post '/v1/admin/dealers/' + id + '/' + action"], 'POST واحد بلا جسم');
  assert.ok(!/Authorization|accessToken|refreshToken|role\b/.test(src.replace(/ROLES?/g, '')), 'لا رموز ولا دور في الجسر');
  assert.equal((fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/<script src=/g) || []).length, 87);
});

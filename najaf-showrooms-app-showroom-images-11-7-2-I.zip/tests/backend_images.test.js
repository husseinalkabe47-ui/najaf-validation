/* Phase 11.7-D — صور السيارات وغلاف المعرض عبر الخادم داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/assets + car-images): POST /v1/me/assets?kind (جسم خام)، GET /v1/me/assets/:id[/thumb|/image]،
   /v1/me/cars/:id/images (GET/POST/DELETE)، /v1/dealer/showroom/cover (GET/PUT/DELETE)، /v1/public/cars/:id/images، /v1/public/showrooms/:id/cover.
   لا خادم ولا قاعدة بيانات ولا تخزين كائنات حقيقي ولا متصفح حقيقي (الترميز بـ codec وهمي): النتائج لا تُثبت التكامل مع الخادم الفعلي. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');
const ApiClient = require('../api/apiClient.js');

const root = path.join(__dirname, '..');
const iso = '2026-01-01T00:00:00.000Z';
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const U = n => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const webp = n => new Response(new Blob([new Uint8Array(n)], { type: 'image/webp' }), { status: 200, headers: { 'content-type': 'image/webp' } });
const SHOWROOM = { id: '7', name: 'معرض الكوفة الحديث', status: 'active', phone: '+9647801234567', whatsapp: null, address: 'النجف - شارع الكوفة', createdAt: iso };

function imgWorld(role) {
  const w = world();
  const d = {
    role: role || 'user', seq: 100, aseq: 0, iseq: 0, max: 4, cars: [], images: {}, assets: {}, uploadStatus: 'ready', gate: null, fail: null,
    cover: null, showroom: SHOWROOM, coverGate: null, pubCars: {}, pubImages: {}, pubShowrooms: {}, pubCovers: {},
  };
  d.car = (o) => { const c = Object.assign({ id: String(++d.seq), brand: 'Kia', model: 'Rio', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', phone: '+9647709999999', whatsapp: '+9647709999999', location: 'النجف', latitude: null, longitude: null, status: 'active', rejectionReason: null, suspensionReason: null, version: 1, createdAt: iso, updatedAt: iso }, o); d.cars.push(c); d.images[c.id] = []; return c; };
  d.asset = (kind, status) => { const a = { id: U(++d.aseq), kind, status: status || 'ready', bytes: 1000, width: 1600, height: 1200, createdAt: iso }; d.assets[a.id] = a; return a; };
  d.attach = (carId, o) => { const a = d.asset('car_image'); const im = Object.assign({ id: 'i' + (++d.iseq), assetId: a.id, sortOrder: d.images[carId].length, isMain: d.images[carId].length === 0, width: 1600, height: 1200, createdAt: iso }, o); d.images[carId].push(im); return im; };
  d.pubCar = (o) => { const c = Object.assign({ id: String(++d.seq), sourceType: 'member', showroomId: null, brand: 'Toyota', model: 'Camry', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', status: 'active', phone: '+9647709999999', whatsapp: null, location: '', latitude: null, longitude: null, ownerName: null, createdAt: iso, updatedAt: iso }, o); d.pubCars[c.id] = c; return c; };
  d.pubShowroom = (o) => { const s = Object.assign({ id: String(++d.seq), name: 'معرض الفرات', description: 'وصف', phone: '+9647801111111', whatsapp: null, address: 'النجف - الكوفة', latitude: 32.0, longitude: 44.3, workingHours: '9-5', services: ['صيانة'], createdAt: iso, updatedAt: iso }, o); d.pubShowrooms[s.id] = s; return s; };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    const mine = u.pathname.startsWith('/v1/me/') || u.pathname.startsWith('/v1/dealer/'), pub = u.pathname.startsWith('/v1/public/');
    if (!mine && !pub) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const raw = init.body instanceof Blob;
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, raw, size: raw ? init.body.size : undefined, body: init.body === undefined || raw ? undefined : JSON.parse(init.body) };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    if (pub) {
      if (d.fail) { const f = d.fail(call); if (f) return f; }
      let m;
      if ((m = /^\/v1\/public\/cars\/([^/]+)\/images$/.exec(u.pathname))) { const a = d.pubImages[m[1]]; return a === undefined ? err(404, 'not_found') : json(200, { images: a }); }
      if ((m = /^\/v1\/public\/showrooms\/([^/]+)\/cover$/.exec(u.pathname))) { const c = d.pubCovers[m[1]]; return c === undefined ? err(404, 'not_found') : json(200, { cover: c }); }
      if ((m = /^\/v1\/public\/cars\/([^/]+)$/.exec(u.pathname))) { const c = d.pubCars[m[1]]; return c ? json(200, { car: c }) : err(404, 'not_found'); }
      if ((m = /^\/v1\/public\/showrooms\/([^/]+)$/.exec(u.pathname))) { const s = d.pubShowrooms[m[1]]; return s ? json(200, { showroom: s }) : err(404, 'not_found'); }
      if (u.pathname === '/v1/public/cars') return json(200, { items: [], nextBefore: null });
      return err(404, 'not_found');
    }
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    let m;
    if (call.method === 'POST' && u.pathname === '/v1/me/assets') {
      if (!call.raw) return err(415, 'unsupported_media_type');
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(h['content-type'])) return err(415, 'unsupported_media_type');
      if (!['car_image', 'showroom_cover'].includes(call.query.kind)) return err(400, 'validation_failed', [{ field: 'kind', code: 'invalid_format' }]);
      if (call.query.kind === 'showroom_cover' && d.role !== 'dealer') return err(403, 'forbidden');
      if (call.size > 8 * 1024 * 1024) return err(413, 'too_large');
      const a = d.asset(call.query.kind, d.uploadStatus); a.bytes = call.size;
      return json(201, { asset: Object.assign({}, a) });
    }
    if (call.method === 'GET' && (m = /^\/v1\/me\/assets\/([^/]+)(?:\/(thumb|image))?$/.exec(u.pathname))) {
      const a = d.assets[m[1]]; if (!a) return err(404, 'not_found');
      if (m[2]) return a.status === 'ready' ? webp(m[2] === 'thumb' ? 100 : 500) : err(404, 'not_found');
      if (a.status === 'pending' && d.pendingBecomes) a.status = d.pendingBecomes;
      return json(200, { asset: Object.assign({}, a) });
    }
    if ((m = /^\/v1\/me\/cars\/([^/]+)\/images(?:\/([^/]+))?$/.exec(u.pathname))) {
      const c = d.cars.find(x => x.id === m[1]); if (!c) return err(404, 'not_found');
      const list = d.images[c.id];
      if (call.method === 'GET' && !m[2]) return json(200, { images: list.map(x => Object.assign({}, x)), maxImages: d.max });
      if (call.method === 'POST' && !m[2]) {
        const b = call.body, bad = Object.keys(b || {}).filter(k => k !== 'assetId').map(k => ({ field: k, code: 'unknown_field' }));
        if (!b || typeof b.assetId !== 'string') bad.push({ field: 'assetId', code: 'required' });
        if (bad.length) return err(400, 'validation_failed', bad);
        const a = d.assets[b.assetId]; if (!a) return err(404, 'not_found');
        if (a.kind !== 'car_image' || a.status !== 'ready' || a.attached) return err(409, 'invalid_state');
        if (list.length >= d.max) return err(409, 'image_limit');
        a.attached = c.id;
        const im = { id: 'i' + (++d.iseq), assetId: a.id, sortOrder: list.length, isMain: list.length === 0, width: 1600, height: 1200, createdAt: iso };
        list.push(im); return json(201, { image: Object.assign({}, im) });
      }
      if (call.method === 'DELETE' && m[2]) {
        const i = list.findIndex(x => x.id === m[2]); if (i < 0) return err(404, 'not_found');
        const was = list[i]; list.splice(i, 1); if (was.isMain && list[0]) list[0].isMain = true; return new Response(null, { status: 204 });
      }
    }
    if ((m = /^\/v1\/me\/cars\/([^/]+)$/.exec(u.pathname)) && call.method === 'GET') { const c = d.cars.find(x => x.id === m[1]); return c ? json(200, { car: Object.assign({}, c) }) : err(404, 'not_found'); }
    if (u.pathname === '/v1/dealer/showroom' && call.method === 'GET') return d.role === 'dealer' && d.showroom ? json(200, { showroom: d.showroom }) : err(404, 'not_found');
    if (u.pathname === '/v1/dealer/showroom/cover') {
      if (d.coverGate) await d.coverGate(call);
      if (d.role !== 'dealer' || !d.showroom) return err(404, 'not_found');
      if (call.method === 'GET') return json(200, { cover: d.cover });
      if (call.method === 'PUT') {
        const a = d.assets[call.body && call.body.assetId]; if (!a) return err(404, 'not_found');
        if (a.kind !== 'showroom_cover' || a.status !== 'ready') return err(409, 'invalid_state');
        d.cover = { assetId: a.id, width: a.width, height: a.height }; return json(200, { cover: d.cover });
      }
      if (call.method === 'DELETE') { d.cover = null; return new Response(null, { status: 204 }); }
    }
    if (u.pathname === '/v1/dealer/cars') return json(200, { items: [], nextBefore: null });
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w, o) {
  o = o || {};
  const env = makeEnv({});
  const revoked = [], made = [];
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.ctx.Blob = Blob; env.ctx.__blob = (n, type) => new Blob([new Uint8Array(n)], { type });
  env.ctx.URL = class extends URL {   // URL حقيقي (ApiClient يحتاجه للعناوين المطلقة) + createObjectURL/revokeObjectURL وهميان نعدّهما
    static createObjectURL(b) { const u = 'blob:test/' + (made.length + 1); made.push({ u, type: b.type, size: b.size }); return u; }
    static revokeObjectURL(u) { revoked.push(u); }
  };
  const cfg = o.baseUrl ? `baseUrl: '${o.baseUrl}', sessionTransport: 'body'` : "baseUrl: '/', sessionTransport: 'cookie'";
  env.run(`BackendAuth.init({ ${cfg}, fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })`);
  env.run('BackendAuth.onLost(handleAuthLost)');
  // codec وهمي: يقرأ الأبعاد ويعيد Blob بالنوع المطلوب (لا متصفح حقيقي هنا)
  env.ctx.__enc = { n: 40000, calls: 0, failDecode: false };
  env.run("ImageService.setCodec({ decode: async f => { if (__enc.failDecode) throw new Error('x'); return { width: 3200, height: 2400, source: {}, close() {} }; }, encode: async (dec, w, h, mime, q) => { __enc.calls++; __enc.last = { w, h, mime, q }; return __blob(__enc.n, mime); } })");
  return {
    env, revoked, made, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (method, re) => w.srv.calls.filter(c => c.method === method && re.test(c.path)),
    toast: () => env.els.toast && env.els.toast.textContent,
    section: () => env.run('RemoteImagesInner()'),   // ما يعرضه القسم الآن (يُقارَن بالـDOM في اختبار التحديث الجزئي)
    cover: () => env.run('RemoteCoverInner()'),
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
    pick(type) { env.ctx.__in = { files: [{ type: type === undefined ? 'image/png' : type, name: 'car.png' }], value: 'C:\\fake\\car.png' }; return env.run('handleRemoteImagePick(__in)'); },
    pickCover(type) { env.ctx.__in = { files: [{ type: type === undefined ? 'image/png' : type, name: 'c.png' }], value: 'C:\\fake\\c.png' }; return env.run('handleRemoteCoverPick(__in)'); },
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p, route, param) { await p.login(); p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle(); }
const yes = p => p.run('askConfirm = (spec, ok) => ok()');
const no = p => p.run('askConfirm = (spec, ok, cancel) => { if (typeof cancel === "function") cancel(); }');
const IMGS = /^\/v1\/me\/cars\/[^/]+\/images/, ASSETS = /^\/v1\/me\/assets/;

/* ============================== العميل: رفع/تنزيل ثنائي ============================== */
function clientWith(fetchImpl) {
  return ApiClient.create({ baseUrl: 'https://api.test', fetch: fetchImpl, setTimeout: () => 0, clearTimeout: () => {}, AbortController, sessionTransport: 'body' });
}
test('ApiClient.upload: جسم خام بنوع صورة فقط (بلا JSON)، بترويسة الدخول، ورفض نوع غير صورة قبل أي اتصال', async () => {
  const seen = [];
  const c = clientWith(async (url, init) => { seen.push({ url, init }); if (/login/.test(url)) return json(200, { user: { id: '1' }, session: { accessToken: 'AT', accessExpiresAt: new Date(Date.now() + 9e5).toISOString(), refreshToken: 'RT', refreshExpiresAt: new Date(Date.now() + 9e8).toISOString() } }); return json(201, { asset: { id: U(1) } }); });
  await c.login({ phone: '07700000003', password: 'x' });
  const blob = new Blob([new Uint8Array(10)], { type: 'image/webp' });
  const out = await c.upload('/v1/me/assets', blob, 'image/webp', { query: { kind: 'car_image' } });
  assert.equal(out.asset.id, U(1));
  const up = seen[seen.length - 1];
  assert.equal(up.url, 'https://api.test/v1/me/assets?kind=car_image'); assert.equal(up.init.method, 'POST'); assert.ok(up.init.body === blob, 'الجسم هو الـBlob نفسه');
  assert.equal(up.init.headers['Content-Type'], 'image/webp'); assert.equal(up.init.headers.Authorization, 'Bearer AT');
  const n = seen.length;
  for (const bad of ['text/html', 'image/svg+xml', 'application/json', 'image/gif', '']) {
    await assert.rejects(() => c.upload('/v1/me/assets', blob, bad, {}), e => e.kind === 'config');
  }
  await assert.rejects(() => c.upload('/v1/me/assets', null, 'image/png', {}), e => e.kind === 'config');
  assert.equal(seen.length, n, 'لا اتصال بنوع غير صالح');
});

test('ApiClient.getBlob: يقبل image/webp 200 فقط؛ JSON أو نوع آخر = invalid_response؛ والأخطاء JSON تبقى ApiError بحالتها', async () => {
  const mk = res => clientWith(async (url) => (/login/.test(url) ? json(200, { user: { id: '1' }, session: { accessToken: 'AT', accessExpiresAt: new Date(Date.now() + 9e5).toISOString(), refreshToken: 'RT', refreshExpiresAt: new Date(Date.now() + 9e8).toISOString() } }) : res()));
  let c = mk(() => webp(5)); await c.login({ phone: '1', password: 'x' });
  const b = await c.getBlob('/v1/me/assets/' + U(1) + '/thumb'); assert.equal(b.size, 5); assert.equal(b.type, 'image/webp');
  c = mk(() => new Response(new Blob([new Uint8Array(3)], { type: 'image/png' }), { status: 200, headers: { 'content-type': 'image/png' } })); await c.login({ phone: '1', password: 'x' });
  await assert.rejects(() => c.getBlob('/v1/me/assets/' + U(1) + '/image'), e => e.kind === 'invalid_response');
  c = mk(() => json(200, { ok: true })); await c.login({ phone: '1', password: 'x' });
  await assert.rejects(() => c.getBlob('/v1/me/assets/' + U(1) + '/image'), e => e.kind === 'invalid_response');
  c = mk(() => err(404, 'not_found')); await c.login({ phone: '1', password: 'x' });
  await assert.rejects(() => c.getBlob('/v1/me/assets/' + U(1) + '/image'), e => e.kind === 'http' && e.status === 404 && e.code === 'not_found');
});

/* ============================== الوضع المحلي ============================== */
test('الوضع المحلي دون تغيير: BackendImages معطّل، شاشات التفاصيل والتعديل المحلية كما هي، وبلا أي اتصال', async () => {
  const env = makeEnv();
  assert.equal(env.run('BackendImages.isEnabled()'), false);
  const id = env.run('getCars()[0].id');
  const html = env.run(`CarDetailsScreen(${id})`);
  assert.match(html, /detail-hero/); assert.ok(!/aria-busy|img-note/.test(html), 'لا حالة خادم في الوضع المحلي');
  const sid = env.run('getShowrooms()[0].id');
  assert.match(env.run(`ShowroomDetailsScreen(${sid})`), /detail-hero/);
  env.run("AuthService.login('07701234567', 'dealer123')");
  assert.match(env.run('DealerHomeScreen()'), /إدارة معرضي/); assert.ok(!/remoteCover|غلاف المعرض/.test(env.run('DealerHomeScreen()')));
  const mc = env.run('getMemberCars()[0] ? getMemberCars()[0].id : null');
  if (mc !== null && mc !== undefined) { env.run(`initImageCtxCar(${mc})`); assert.match(env.run('ImagePickerHtml()'), /imagePicker/); }
  assert.deepEqual(env.errors, []);
});

/* ============================== صور إعلاني: عرض ============================== */
test('تعديل الإعلان: «جارٍ تحميل الصور…» ثم الصور من GET /images (بالرمز) وصورها المصغّرة تُجلب بـBearer كـBlob فتظهر بروابط blob:، والعدّاد من maxImages', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id); d.attach(c.id);
  let release; d.gate = call => (IMGS.test(call.path) && call.method === 'GET' ? new Promise(r => { release = r; }) : null);
  const p = page(w); await p.login(); p.run(`go('editMemberCar', '${c.id}')`); await settle();
  assert.match(p.section(), /جارٍ تحميل الصور/);
  release(); await settle();
  const g = p.calls('GET', IMGS); assert.equal(g.length >= 1, true); assert.match(g[0].headers.authorization, /^Bearer AT-/); assert.equal(g[0].path, `/v1/me/cars/${c.id}/images`);
  const th = p.calls('GET', /\/thumb$/); assert.equal(th.length, 2); th.forEach(t => assert.match(t.headers.authorization, /^Bearer AT-/)); assert.equal(th[0].headers.accept, 'image/webp');
  const h = p.section();
  assert.match(h, /الصور 2 \/ 4/); assert.equal((h.match(/<img src="blob:test\/\d+"/g) || []).length, 2); assert.match(h, /رئيسية/); assert.match(h, /type="file"/);
  assert.ok(!/\/v1\/public\//.test(h), 'الخاصة لا تمر بروابط عامة');
  assert.deepEqual(p.env.errors, []);
});

test('الحالة الفارغة: لا صور بعد + زر الإضافة؛ خطأ تحميل = رسالة عربية + إعادة المحاولة (بلا صور محلية/تجريبية)؛ ثم نجاح الإعادة', async () => {
  const { w, d } = imgWorld(); const c = d.car({});
  const p = page(w); await open(p, 'editMemberCar', c.id);
  assert.match(p.section(), /لا توجد صور بعد/); assert.match(p.section(), /الصور 0 \/ 4/); assert.match(p.section(), /type="file"/);
  const e = imgWorld(); const c2 = e.d.car({}); e.d.attach(c2.id);
  e.d.fail = call => (IMGS.test(call.path) && call.method === 'GET' ? err(500, 'internal') : null);
  const q = page(e.w); await open(q, 'editMemberCar', c2.id);
  assert.match(q.section(), /خطأ في الخادم/); assert.match(q.section(), /handleRemoteImagesRetry/); assert.ok(!/<img/.test(q.section()) && !/type="file"/.test(q.section()));
  e.d.fail = null; await q.run('handleRemoteImagesRetry()'); await settle();
  assert.match(q.section(), /الصور 1 \/ 4/); assert.match(q.section(), /<img src="blob:/);
});

test('403/404 عند قراءة المعرض: رسالة آمنة بلا زر إضافة؛ صور أصل تعذّر تنزيله تظهر ببديل لا بأيقونة مكسورة', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id);
  d.fail = call => (IMGS.test(call.path) && call.method === 'GET' ? err(403, 'forbidden') : null);
  const p = page(w); await open(p, 'editMemberCar', c.id);
  assert.match(p.section(), /لا يملك صلاحية إدارة الصور/); assert.ok(!/type="file"/.test(p.section()));
  const e = imgWorld(); const c2 = e.d.car({}); e.d.attach(c2.id);
  e.d.fail = call => (/\/thumb$/.test(call.path) ? err(404, 'not_found') : null);
  const q = page(e.w); await open(q, 'editMemberCar', c2.id);
  assert.match(q.section(), /الصور 1 \/ 4/); assert.ok(!/<img/.test(q.section()), 'لا <img> بلا رابط'); assert.match(q.section(), /🚘/);
});

/* ============================== الرفع ============================== */
test('الإضافة: ضغط ثم POST /v1/me/assets?kind=car_image بجسم خام WebP وبالرمز، ثم POST /images {assetId} فقط، ثم تحديث القائمة؛ وبلا أي تخزين محلي', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id);
  const p = page(w); await open(p, 'editMemberCar', c.id);
  w.srv.calls.length = 0;
  const formBefore = p.screen();
  await p.pick('image/png'); await settle();
  assert.equal(p.screen(), formBefore, 'النموذج لا يُعاد رسمه (الحقول المكتوبة لا تضيع): يتحدّث قسم الصور وحده');
  assert.equal(p.env.els.remoteImages.innerHTML, p.section(), 'قسم الصور في الصفحة يعرض الحالة الحالية');
  assert.equal(p.run('__enc.calls'), 1); assert.deepEqual(JSON.parse(JSON.stringify(p.run('__enc.last'))), { w: 1600, h: 1200, mime: 'image/webp', q: 0.8 });
  const order = w.srv.calls.filter(x => ASSETS.test(x.path) || IMGS.test(x.path)).map(x => x.method + ' ' + x.path.replace(U(0).slice(0, 24), '').replace(/\/[0-9a-f-]{36}/, '/<id>'));
  assert.deepEqual(order.slice(0, 2), ['POST /v1/me/assets', `POST /v1/me/cars/${c.id}/images`]);
  const up = p.calls('POST', /^\/v1\/me\/assets$/)[0];
  assert.equal(up.query.kind, 'car_image'); assert.equal(up.raw, true); assert.equal(up.headers['content-type'], 'image/webp'); assert.match(up.headers.authorization, /^Bearer AT-/); assert.equal(up.size, 40000);
  const at = p.calls('POST', IMGS)[0]; assert.deepEqual(Object.keys(at.body), ['assetId']); assert.equal(at.body.assetId, Object.keys(d.assets)[1]);
  assert.equal(d.images[c.id].length, 2); assert.match(p.section(), /الصور 2 \/ 4/); assert.match(p.toast(), /تمت إضافة الصورة/);
  assert.equal(p.calls('GET', IMGS).length >= 1, true, 'تحديث هادئ من الخادم');
  const stored = JSON.stringify(p.env.store); assert.ok(!/blob:|image|webp/i.test(stored), 'لا شيء من الصور في التخزين المحلي');
  assert.deepEqual(p.env.errors, []);
});

test('منع الرفع المكرر: اختياران متتاليان أثناء رفع جارٍ = رفع واحد فقط، ويختفي زر الاختيار ويظهر «جارٍ رفع الصورة…»', async () => {
  const { w, d } = imgWorld(); const c = d.car({});
  const p = page(w); await open(p, 'editMemberCar', c.id);
  let release; d.gate = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? new Promise(r => { release = r; }) : null);
  const a = p.pick(); await settle();
  assert.match(p.section(), /جارٍ رفع الصورة/); assert.ok(!/type="file"/.test(p.section()));
  const b = p.pick(); await b;
  assert.equal(p.calls('POST', /^\/v1\/me\/assets$/).length, 1, 'طلب رفع واحد');
  release(); await a; await settle();
  assert.equal(Object.keys(d.assets).length, 1); assert.equal(d.images[c.id].length, 1); assert.equal(p.calls('POST', IMGS).length, 1);
  assert.match(p.section(), /type="file"/);
});

test('الحد الأقصى: عند maxImages لا زر إضافة وتظهر رسالة الحد؛ والإضافة المباشرة ترفض بلا أي POST', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); for (let i = 0; i < 4; i++) d.attach(c.id);
  const p = page(w); await open(p, 'editMemberCar', c.id);
  assert.match(p.section(), /الصور 4 \/ 4/); assert.match(p.section(), /الحد الأقصى من الصور/); assert.ok(!/type="file"/.test(p.section()));
  w.srv.calls.length = 0;
  await p.pick(); await settle();
  assert.equal(p.calls('POST', /^\/v1\/me\//).length, 0); assert.match(p.section(), /الحد الأقصى/); assert.equal(p.run('__enc.calls'), 0, 'لا ضغط قبل التحقق');
});

test('سباق الحد: الخادم يرد 409 image_limit بعد الرفع فتظهر رسالة الحد وتُحدَّث القائمة من الخادم (الأصل المرفوع لا يُعرض)', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id);
  const p = page(w); await open(p, 'editMemberCar', c.id);
  d.attach(c.id); d.attach(c.id); d.attach(c.id);   // جهاز آخر ملأ الإعلان
  await p.pick(); await settle();
  assert.match(p.section(), /الحد الأقصى من الصور/); assert.match(p.section(), /الصور 4 \/ 4/); assert.equal(d.images[c.id].length, 4);
});

test('أخطاء الرفع: 413/415/409 upload_limit/503/403/400 = رسائل عربية، لا إرفاق، لا تغيير في القائمة، والقفل يُحرَّر للمحاولة التالية', async () => {
  const cases = [[413, 'too_large', /كبير جدًا/], [415, 'unsupported_media_type', /نوع الصورة غير مدعوم/], [409, 'upload_limit', /الحد المسموح من الرفع/], [503, 'storage_unavailable', /خدمة تخزين الصور غير متاحة/], [403, 'forbidden', /لا يملك صلاحية إدارة الصور/], [400, 'validation_failed', /ليس صورة صالحة/]];
  for (const [status, code, re] of cases) {
    const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id);
    const p = page(w); await open(p, 'editMemberCar', c.id);
    d.fail = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? err(status, code) : null);
    await p.pick(); await settle();
    assert.match(p.section(), re, String(status)); assert.equal(p.calls('POST', IMGS).length, 0, 'لا إرفاق بعد فشل الرفع'); assert.equal(d.images[c.id].length, 1); assert.match(p.section(), /الصور 1 \/ 4/);
    d.fail = null; await p.pick(); await settle(); assert.equal(d.images[c.id].length, 2, 'القفل حُرِّر');
  }
});

test('أصل مرفوض/قيد المعالجة: rejected = رسالة ولا إرفاق؛ pending يُعاد فحصه مرة (GET /assets/:id) ثم ready فيُرفق، أو يبقى pending فتظهر رسالة', async () => {
  { const { w, d } = imgWorld(); const c = d.car({}); d.uploadStatus = 'rejected';
    const p = page(w); await open(p, 'editMemberCar', c.id); await p.pick(); await settle();
    assert.match(p.section(), /رفض الخادم هذه الصورة/); assert.equal(p.calls('POST', IMGS).length, 0); assert.equal(d.images[c.id].length, 0); }
  { const { w, d } = imgWorld(); const c = d.car({}); d.uploadStatus = 'pending'; d.pendingBecomes = 'ready';
    const p = page(w); await open(p, 'editMemberCar', c.id); await p.pick(); await settle();
    assert.equal(p.calls('GET', /^\/v1\/me\/assets\/[0-9a-f-]{36}$/).length, 1); assert.equal(d.images[c.id].length, 1); assert.match(p.section(), /الصور 1 \/ 4/); }
  { const { w, d } = imgWorld(); const c = d.car({}); d.uploadStatus = 'pending'; d.pendingBecomes = null;
    const p = page(w); await open(p, 'editMemberCar', c.id); await p.pick(); await settle();
    assert.match(p.section(), /قيد المعالجة/); assert.equal(p.calls('POST', IMGS).length, 0); }
});

test('إرفاق مرفوض بعد رفع ناجح (409 invalid_state / 404): رسالة آمنة وتحديث من الخادم؛ لا صورة وهمية في الواجهة', async () => {
  { const { w, d } = imgWorld(); const c = d.car({});
    const p = page(w); await open(p, 'editMemberCar', c.id);
    d.fail = call => (call.method === 'POST' && IMGS.test(call.path) ? err(409, 'invalid_state') : null);
    await p.pick(); await settle(); assert.match(p.section(), /لا يمكن استخدام هذه الصورة الآن/); assert.match(p.section(), /الصور 0 \/ 4/); }
  { const { w, d } = imgWorld(); const c = d.car({});
    const p = page(w); await open(p, 'editMemberCar', c.id);
    d.cars = []; await p.pick(); await settle(); assert.match(p.section(), /الإعلان غير موجود أو لم يعد لك/); assert.ok(!/type="file"/.test(p.section())); }
});

test('الضغط والتحقق المحلي قبل الرفع: ملف غير صورة، فشل فك الترميز، وناتج أكبر من 8MB = رسالة عربية وبلا أي طلب رفع', async () => {
  const { w, d } = imgWorld(); const c = d.car({});
  const p = page(w); await open(p, 'editMemberCar', c.id); w.srv.calls.length = 0;
  await p.pick('application/pdf'); await settle(); assert.match(p.section(), /ليس صورة صالحة/);
  p.env.ctx.__enc.failDecode = true; await p.pick(); await settle(); assert.match(p.section(), /تعذر قراءة الصورة/);
  p.env.ctx.__enc.failDecode = false; p.env.ctx.__enc.n = 9 * 1024 * 1024; await p.pick(); await settle(); assert.match(p.section(), /كبير جدًا حتى بعد الضغط/);
  assert.equal(p.calls('POST', /^\/v1\/me\//).length, 0); assert.equal(d.images[c.id].length, 0);
});

/* ============================== الحذف ============================== */
test('الحذف: تأكيد ثم DELETE /images/:imageId، تختفي الصورة ويُلغى رابطها، وتُعاد الرئيسية؛ رفض التأكيد = لا طلب؛ نقرتان = حذف واحد', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); const i1 = d.attach(c.id), i2 = d.attach(c.id);
  const p = page(w); await open(p, 'editMemberCar', c.id);
  no(p); await p.run(`handleRemoteImageRemove('${i1.id}')`); await settle(); assert.equal(p.calls('DELETE', IMGS).length, 0); assert.equal(d.images[c.id].length, 2);
  yes(p); const before = p.made.length;
  const a = p.run(`handleRemoteImageRemove('${i1.id}')`), b = p.run(`handleRemoteImageRemove('${i1.id}')`); await a; await b; await settle();
  const dc = p.calls('DELETE', IMGS); assert.equal(dc.length, 1); assert.equal(dc[0].path, `/v1/me/cars/${c.id}/images/${i1.id}`); assert.match(dc[0].headers.authorization, /^Bearer AT-/);
  assert.equal(d.images[c.id].length, 1); assert.match(p.section(), /الصور 1 \/ 4/); assert.match(p.section(), /رئيسية/); assert.match(p.toast(), /تم حذف الصورة/);
  assert.equal(p.revoked.length >= 1, true, 'رابط الصورة المحذوفة أُلغي'); assert.ok(before >= 2);
  d.fail = call => (call.method === 'DELETE' ? err(404, 'not_found') : null); yes(p);
  await p.run(`handleRemoteImageRemove('${i2.id}')`); await settle(); assert.match(p.section(), /الإعلان غير موجود|الصور/);
});

/* ============================== الجلسة ============================== */
test('انتهاء الجلسة أثناء الرفع: يعود المستخدم لتسجيل الدخول برسالة الانتهاء، بلا إرفاق وبلا أثر محلي؛ والخروج يُلغي روابط Blob ويصفّر الحالة', async () => {
  { const { w, d } = imgWorld(); const c = d.car({}); const p = page(w); await open(p, 'editMemberCar', c.id);
    w.srv.families.forEach(f => { f.revoked = true; });
    await p.pick(); await settle();
    assert.equal(p.route(), 'login'); assert.equal(d.images[c.id].length, 0); assert.equal(p.calls('POST', IMGS).length, 0); }
  { const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id); d.attach(c.id); const p = page(w); await open(p, 'editMemberCar', c.id);
    assert.equal(p.made.length, 2); assert.equal(p.revoked.length, 0);
    p.run('handleLogout()'); await settle();
    assert.equal(p.revoked.length, 2, 'كل روابط Blob الخاصة أُلغيت عند الخروج');
    assert.equal(p.run("BackendImages.gallery('x').status"), 'idle'); }
});

test('تبديل المستخدم: لا تتسرب صور مستخدم سابق (القائمة تُجلب من جديد، وروابطه ملغاة)', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id);
  const p = page(w); await open(p, 'editMemberCar', c.id);
  assert.match(p.section(), /الصور 1 \/ 4/);
  await p.run('BackendAuth.logout()'); await settle();
  d.images[c.id] = []; await p.run("BackendAuth.login('07700000004', 'Pa55w0rd-1')"); p.run(`go('editMemberCar', '${c.id}')`); await settle();
  assert.match(p.section(), /الصور 0 \/ 4/); assert.equal(p.revoked.length >= 1, true);
});

/* ============================== تفاصيل إعلاني ============================== */
test('تفاصيل إعلاني: الصورة الرئيسية بحجم العرض الكامل (/image) والشريط من الصور المصغّرة؛ عند فشل التحميل = بديل 🚘 + رسالة + إعادة محاولة ناجحة', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); d.attach(c.id); d.attach(c.id);
  const p = page(w); await open(p, 'memberCarDetails', c.id);
  assert.equal(p.calls('GET', /\/image$/).length, 1); assert.equal(p.calls('GET', /\/thumb$/).length, 2);
  const h = p.screen(); assert.match(h, /detail-hero"><img src="blob:/); assert.match(h, /img-strip/);
  const e = imgWorld(); const c2 = e.d.car({}); e.d.attach(c2.id); e.d.fail = call => (IMGS.test(call.path) && call.method === 'GET' ? err(500, 'internal') : null);
  const q = page(e.w); await open(q, 'memberCarDetails', c2.id);
  assert.match(q.screen(), /img-note[^>]*>حدث خطأ في الخادم/); assert.match(q.screen(), /🚘/); assert.ok(!/img-strip/.test(q.screen()));
  e.d.fail = null; q.run("BackendImages.retryGallery(currentParam, _rerenderIf('memberCarDetails'));render()"); await settle();
  assert.match(q.screen(), /detail-hero"><img src="blob:/);
});

/* ============================== العرض العام ============================== */
test('تفاصيل السيارة العامة: صور الخادم بروابط عامة مباشرة (<img>) بلا Bearer، الرئيسية أولًا، شريط للصور المتعددة، وللزائر أيضًا', async () => {
  const { w, d } = imgWorld(); const c = d.pubCar({}); d.pubImages[c.id] = [{ assetId: U(51), isMain: false, sortOrder: 1, width: 1, height: 1 }, { assetId: U(50), isMain: true, sortOrder: 0, width: 1, height: 1 }];
  const p = page(w); p.run(`go('carDetails', '${c.id}')`); await settle();
  const gc = p.calls('GET', /\/images$/); assert.equal(gc.length, 1); assert.equal(gc[0].path, `/v1/public/cars/${c.id}/images`); assert.equal(gc[0].headers.authorization, undefined);
  const h = p.screen();
  assert.ok(h.includes(`<div class="detail-hero"><img src="/v1/public/assets/${U(50)}/image"`), 'الرئيسية أولًا بحجم كامل');
  assert.ok(h.includes(`/v1/public/assets/${U(51)}/thumb`) && h.includes(`/v1/public/assets/${U(50)}/thumb`), 'الشريط بالمصغّرات'); assert.match(h, /img-strip/);
  assert.equal(p.calls('GET', /\/v1\/public\/assets\//).length, 0, 'الصور <img> مباشرة لا عبر fetch'); assert.equal(p.made.length, 0);
});

test('تفاصيل السيارة العامة: بلا صور/404 = بديل 🚘؛ فشل الخادم = بديل + رسالة + إعادة المحاولة؛ تحميل = بديل ⏳؛ ولا رجوع لصور محلية', async () => {
  const { w, d } = imgWorld(); const c = d.pubCar({}); d.pubImages[c.id] = [];
  const p = page(w); p.run(`go('carDetails', '${c.id}')`); await settle();
  assert.match(p.screen(), /🚘/); assert.ok(!/img-strip|img-note/.test(p.screen()));
  const c3 = d.pubCar({}); p.run(`go('carDetails', '${c3.id}')`); await settle(); assert.match(p.screen(), /🚘/); assert.ok(!/img-note/.test(p.screen()), '404 = لا صور');
  const c2 = d.pubCar({}); d.pubImages[c2.id] = [{ assetId: U(60), isMain: true, sortOrder: 0, width: 1, height: 1 }];
  let release; d.gate = call => (/\/images$/.test(call.path) ? new Promise(r => { release = r; }) : null);
  p.run(`go('carDetails', '${c2.id}')`); await settle(); assert.match(p.screen(), /جارٍ تحميل الصور/);
  d.gate = null; release(); await settle(); assert.match(p.screen(), new RegExp(U(60)));
  const c4 = d.pubCar({}); d.pubImages[c4.id] = [{ assetId: U(61), isMain: true, sortOrder: 0, width: 1, height: 1 }];
  d.fail = call => (/\/images$/.test(call.path) ? err(500, 'internal') : null);
  p.run(`go('carDetails', '${c4.id}')`); await settle(); assert.match(p.screen(), /تعذّر تحميل الصور/); assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!new RegExp(U(61)).test(p.screen()));
  d.fail = null; p.run("BackendImages.retryPublicCar(currentParam, _detailsDone('carDetails'));render()"); await settle(); assert.match(p.screen(), new RegExp(U(61)));
});

test('الرابط العام مطلق عند عنوان خلفية مطلق (https://api.test)، والغلاف العام: صورة / لا غلاف 🏢 / خطأ + إعادة المحاولة', async () => {
  const { w, d } = imgWorld(); const s = d.pubShowroom({}); d.pubCovers[s.id] = { assetId: U(70), width: 1600, height: 900 };
  const p = page(w, { baseUrl: 'https://api.test' }); p.run(`go('showroomDetails', '${s.id}')`); await settle();
  assert.ok(p.screen().includes(`<div class="detail-hero"><img src="https://api.test/v1/public/assets/${U(70)}/image"`));
  assert.equal(p.calls('GET', /\/cover$/)[0].headers.authorization, undefined);
  const s2 = d.pubShowroom({}); d.pubCovers[s2.id] = null; p.run(`go('showroomDetails', '${s2.id}')`); await settle(); assert.match(p.screen(), /🏢/); assert.ok(!/img-note/.test(p.screen()));
  const s3 = d.pubShowroom({}); d.pubCovers[s3.id] = { assetId: U(71), width: 1, height: 1 }; d.fail = call => (/\/cover$/.test(call.path) ? err(500, 'internal') : null);
  p.run(`go('showroomDetails', '${s3.id}')`); await settle(); assert.match(p.screen(), /تعذّر تحميل غلاف المعرض/); assert.match(p.screen(), /🏢/);
  d.fail = null; p.run("BackendImages.retryPublicShowroom(currentParam, _detailsDone('showroomDetails'));render()"); await settle(); assert.match(p.screen(), new RegExp(U(71)));
});

/* ============================== غلاف المعرض (صاحب المعرض) ============================== */
test('لوحة التاجر: غلاف المعرض يُحمَّل (GET /dealer/showroom/cover)، لا غلاف = رسالة + زر اختيار؛ الاختيار: رفع showroom_cover ثم PUT {assetId} فقط، والمعاينة عبر Bearer', async () => {
  const { w, d } = imgWorld('dealer');
  const p = page(w); await open(p, 'dealerHome');
  assert.match(p.cover(), /لا يوجد غلاف للمعرض بعد/); assert.match(p.cover(), /اختيار غلاف/);
  w.srv.calls.length = 0; await p.pickCover(); await settle();
  const up = p.calls('POST', /^\/v1\/me\/assets$/)[0]; assert.equal(up.query.kind, 'showroom_cover'); assert.equal(up.headers['content-type'], 'image/webp');
  const put = p.calls('PUT', /cover$/)[0]; assert.equal(put.path, '/v1/dealer/showroom/cover'); assert.deepEqual(Object.keys(put.body), ['assetId']); assert.match(put.headers.authorization, /^Bearer AT-/);
  assert.equal(d.cover.assetId, put.body.assetId); assert.match(p.toast(), /تم تعيين غلاف المعرض/);
  const img = p.calls('GET', /^\/v1\/me\/assets\/[0-9a-f-]{36}\/image$/); assert.equal(img.length, 1); assert.match(img[0].headers.authorization, /^Bearer AT-/);
  assert.match(p.cover(), /<img src="blob:test\/\d+" alt="غلاف المعرض"/); assert.match(p.cover(), /تغيير الغلاف/); assert.match(p.cover(), /حذف الغلاف/);
  assert.ok(!/localStorage|blob:/.test(JSON.stringify(p.env.store)));
});

test('الغلاف: استبدال (يُلغى رابط القديم)، حذف بتأكيد (DELETE بلا جسم)، رفض التأكيد = لا طلب، ومنع التكرار أثناء الرفع', async () => {
  const { w, d } = imgWorld('dealer'); const a0 = d.asset('showroom_cover'); d.cover = { assetId: a0.id, width: 1600, height: 900 };
  const p = page(w); await open(p, 'dealerHome');
  assert.equal(p.calls('GET', /\/image$/).length, 1); assert.match(p.cover(), /<img src="blob:test\/1"/);
  let release; d.gate = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? new Promise(r => { release = r; }) : null);
  const x = p.pickCover(); await settle(); assert.match(p.cover(), /جارٍ رفع الصورة/); assert.ok(!/type="file"/.test(p.cover()));
  await p.pickCover(); assert.equal(p.calls('POST', /^\/v1\/me\/assets$/).length, 1);
  d.gate = null; release(); await x; await settle();
  assert.notEqual(d.cover.assetId, a0.id); assert.ok(p.revoked.includes('blob:test/1'), 'رابط الغلاف القديم أُلغي');
  no(p); await p.run('handleRemoteCoverClear()'); await settle(); assert.equal(p.calls('DELETE', /cover$/).length, 0); assert.ok(d.cover);
  yes(p); const c1 = p.run('handleRemoteCoverClear()'), c2 = p.run('handleRemoteCoverClear()'); await c1; await c2; await settle();
  assert.equal(p.calls('DELETE', /cover$/).length, 1); assert.equal(d.cover, null); assert.match(p.cover(), /لا يوجد غلاف للمعرض بعد/); assert.match(p.toast(), /تم حذف غلاف المعرض/);
});

test('أخطاء الغلاف: 404 (لا معرض فعّال)/403 عند القراءة = رسالة بلا أزرار؛ 409 invalid_state / 403 / 404 / 503 عند الكتابة = رسائل عربية بلا تغيير؛ فشل التحميل + إعادة محاولة', async () => {
  { const { w, d } = imgWorld('dealer'); d.fail = c => (/cover$/.test(c.path) && c.method === 'GET' ? err(404, 'not_found') : null);
    const p = page(w); await open(p, 'dealerHome'); assert.match(p.cover(), /لا يوجد معرض فعّال مرتبط بحسابك/); assert.ok(!/type="file"/.test(p.cover())); }
  { const { w, d } = imgWorld('dealer'); d.fail = c => (/cover$/.test(c.path) && c.method === 'GET' ? err(503, 'unavailable') : null);
    const p = page(w); await open(p, 'dealerHome'); assert.match(p.cover(), /handleRemoteCoverRetry/); d.fail = null; await p.run('handleRemoteCoverRetry()'); await settle(); assert.match(p.cover(), /اختيار غلاف/); }
  for (const [call, status, code, re] of [['PUT', 409, 'invalid_state', /لا يمكن استخدام هذه الصورة الآن/], ['PUT', 404, 'not_found', /لا يوجد معرض فعّال/], ['PUT', 403, 'forbidden', /لصاحب معرض فعّال فقط/], ['POST', 503, 'storage_unavailable', /خدمة تخزين الصور غير متاحة/]]) {
    const { w, d } = imgWorld('dealer'); const p = page(w); await open(p, 'dealerHome');
    d.fail = c => (c.method === call && (call === 'PUT' ? /cover$/.test(c.path) : c.path === '/v1/me/assets') ? err(status, code) : null);
    await p.pickCover(); await settle(); assert.match(p.cover(), re, call + status); assert.equal(d.cover, null); assert.match(p.cover(), /لا يوجد غلاف للمعرض بعد/);
  }
});

test('الغلاف لمن ليس صاحب معرض: الرفع 403 يعرض رسالة الصلاحية، ولا يُنشأ غلاف', async () => {
  const { w, d } = imgWorld('dealer'); const p = page(w); await open(p, 'dealerHome');
  d.role = 'user'; d.fail = c => (c.method === 'POST' && c.path === '/v1/me/assets' ? err(403, 'forbidden') : null);
  await p.pickCover(); await settle(); assert.match(p.cover(), /لصاحب معرض فعّال فقط/); assert.equal(d.cover, null);
});

test('خروج/تبديل المستخدم أثناء رفع جارٍ: لا إرفاق ولا تلويث للمستخدم التالي، ويُحرَّر القفل', async () => {
  const { w, d } = imgWorld(); const c = d.car({}); const p = page(w); await open(p, 'editMemberCar', c.id);
  let release; d.gate = call => (call.method === 'POST' && call.path === '/v1/me/assets' ? new Promise(r => { release = r; }) : null);
  const a = p.pick(); await settle();
  p.run('handleLogout()'); await settle();
  await p.run("BackendAuth.login('07700000004', 'Pa55w0rd-1')");
  d.gate = null; release(); const r = await a; await settle();
  assert.equal(p.calls('POST', IMGS).length, 0, 'لا إرفاق بعد تغيّر الهوية'); assert.equal(d.images[c.id].length, 0);
  p.run(`go('editMemberCar', '${c.id}')`); await settle();
  assert.match(p.section(), /الصور 0 \/ 4/); assert.match(p.section(), /type="file"/, 'القفل حُرِّر للمستخدم الجديد'); assert.equal(r, undefined);
});

/* ============================== حراس المصدر ============================== */
test('حارس المصدر: لا console ولا تخزين ولا fetch ولا eval في الجسر؛ مسارات الصور من القائمة المسموحة فقط؛ 87 سكربتًا؛ الرفع الثنائي بأنواع الصور فقط', () => {
  const strip = f => fs.readFileSync(path.join(root, f), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendImages'), b = all.indexOf('const BackendFavorites');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|\beval\(|new Function|Repository|AppStorage|innerHTML/.test(src));
  const paths = [...src.matchAll(/'(\/v1\/[^']*)'/g)].map(m => m[1].replace(/\/$/, ''));
  assert.ok(paths.length >= 11);   // 11.7.2-I: ثلاثة مسارات /v1/me/cars صارت carImagesPath (حرفان) فنزل الحد الأدنى من 12 إلى 11
  paths.forEach(x => assert.ok(/^\/v1\/(me\/assets|me\/cars|public\/(assets|cars|showrooms)|dealer\/showroom\/cover|dealer\/cars)$/.test(x), x));   // 11.7.2-I: dealer/cars للصور فقط (التالي)
  assert.ok(!/\/v1\/me\/favorites|\/v1\/admin/.test(src), 'لا مسار مُختلَق ولا مسار خارج النطاق');
  /* 11.7.2-I: /v1/dealer/cars يظهر في الجسر لمسار الصور وحده (carImagesPath)، لا لإنشاء/تعديل سيارات */
  assert.equal((src.match(/\/v1\/dealer\/cars/g) || []).length, 1);
  assert.match(src, /const carImagesPath = \(carId, scope\) => \(scope === 'showroom' \? '\/v1\/dealer\/cars\/' : '\/v1\/me\/cars\/'\) \+ carId \+ '\/images';/);
  assert.ok(!/api\.(post|put|patch|delete)\(\s*'\/v1\/public/.test(src), 'العام للقراءة فقط');
  assert.ok(!/Authorization|accessToken|refreshToken/.test(src), 'الرموز لا تظهر في الجسر');
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.equal((html.match(/<script src=/g) || []).length, 87);
  const client = strip('api/apiClient.js');
  assert.match(client, /RAW_TYPE = \/\^image\\\/\(\?:jpeg\|png\|webp\)\$\//);
  const bridge = strip('api/authBridge.js');
  for (const bad of [/\bconsole\./, /localStorage|sessionStorage|indexedDB|document\.cookie|AppStorage|Repository/, /\bfetch\s*\(/, /\beval\(|new Function/]) assert.ok(!bad.test(bridge), String(bad));
});

/* عرض الصور (المرحلة 10 / الجزء 3): صورة السيارة/المعرض بنسبتها دون تشويه، وبديل آمن عند الغياب أو التعطّل.
   نظام التخزين والضغط (ImageStore/imageService/carImagesService) لم يتغيّر: هذا الملف يعرض فقط ما تعيده resolveImageSrc.
   - الصورة المكسورة (onerror) تُستبدل ببديل فلا تظهر أيقونة صورة مكسورة، وصور الشريط المصغّرة المكسورة تُزال.
   - رابط الصورة يُهرَّب داخل الخاصية، وروابط غير صالحة/غير نصية تُعامَل كغياب صورة (لا استثناء). */
const CAR_PLACEHOLDER = '<span class="img-ph" role="img" aria-label="لا توجد صورة">🚘</span>';
const SHOWROOM_PLACEHOLDER = '<span class="img-ph" role="img" aria-label="لا توجد صورة">🏢</span>';

/** رابط عرض آمن لـ imageUrl مخزَّن أو null (النص فقط؛ وأي خطأ ← null) */
function _safeImgSrc(imageUrl) {
  try { return typeof imageUrl === 'string' ? (resolveImageSrc(imageUrl) || null) : null; } catch (e) { return null; }
}
/** أول رابط صالح لصور السيارة: الرئيسية أولًا ثم بقية الصور (تعطّل الأولى لا يخفي الباقي) */
function _carImageSrcs(car) {
  try {
    if (!car || typeof car !== 'object' || !Number.isFinite(car.id)) return [];
    const imgs = getCarImages(car.id);
    const main = imgs.find(i => i && i.isMain) || imgs[0];
    const ordered = (main ? [main] : []).concat(imgs.filter(i => i !== main));
    return ordered.map(i => _safeImgSrc(i && i.imageUrl)).filter(Boolean);
  } catch (e) { return []; }
}

/** محتوى مربع صورة السيارة: الصورة الرئيسية الحقيقية إن وُجدت (مضغوطة)، وإلا بديل 🚘 */
function CarImageInner(car) {
  const src = _carImageSrcs(car)[0];
  return src ? `<img src="${esc(src)}" alt="${esc(carTitle(car))}" loading="lazy" decoding="async" onerror="imgFallback(this)">` : CAR_PLACEHOLDER;
}
/** محتوى مربع صورة المعرض: صورته الحقيقية إن وُجدت، وإلا بديل 🏢 */
function ShowroomImageInner(s) {
  const src = _safeImgSrc(s && s.image);
  const name = plainText(s && s.name) || 'معرض';
  return src ? `<img src="${esc(src)}" alt="${esc(name)}" loading="lazy" decoding="async" data-ph="🏢" onerror="imgFallback(this)">` : SHOWROOM_PLACEHOLDER;
}
/** شريط صور مصغّر في شاشات التفاصيل (لا يظهر إلا إن وُجدت صورتان حقيقيتان فأكثر) */
function CarImageStrip(car) {
  const srcs = _carImageSrcs(car);
  if (srcs.length < 2) return '';
  const t = carTitle(car);
  return `<div class="img-strip">${srcs.map((s, i) => `<img src="${esc(s)}" alt="${esc(t)} — صورة ${i + 1}" loading="lazy" decoding="async" onerror="imgThumbFallback(this)">`).join('')}</div>`;
}

/** صورة مكسورة ← بديل (🚘 أو الرمز في data-ph). لا ترمي استثناءً أبدًا. */
function imgFallback(img) {
  try {
    if (!img || typeof img !== 'object') return;
    img.onerror = null;                                   // لا حلقة إن فشل البديل نفسه
    const icon = (typeof img.getAttribute === 'function' && img.getAttribute('data-ph')) || '🚘';
    if (typeof img.replaceWith !== 'function' || typeof document === 'undefined' || typeof document.createElement !== 'function') {
      if (img.style) img.style.display = 'none';          // لا يمكن الاستبدال: نُخفي المكسورة على الأقل
      return;
    }
    const ph = document.createElement('span');
    ph.className = 'img-ph'; ph.setAttribute('role', 'img'); ph.setAttribute('aria-label', 'تعذّر تحميل الصورة'); ph.textContent = icon;
    img.replaceWith(ph);
  } catch (e) { /* بقاء الصورة المكسورة أهون من استثناء في الواجهة */ }
}
/** صورة مصغّرة مكسورة ← تُزال من الشريط */
function imgThumbFallback(img) {
  try { if (img && typeof img === 'object') { img.onerror = null; if (typeof img.remove === 'function') img.remove(); } } catch (e) { /* تجاهل */ }
}

/* ==========================================================================
   (11.7-D) وضع الخادم: عرض صور السيارة والغلاف القادمة من الخادم (BackendImages في api/authBridge.js).
   جاري التحميل ← بديل مع حالة؛ لا صور ← البديل؛ فشل ← البديل مع رسالة وزر إعادة المحاولة؛ صورة مكسورة ← البديل (imgFallback).
   لا رجوع إلى صور محلية/تجريبية أبدًا. st: حالة من BackendImages.publicCar أو gallery (عناصرها {url, thumb?, full?}).
   ========================================================================== */
const _IMG_NOTE_ERR = 'تعذّر تحميل الصور من الخادم.';
function _remoteImgNote(msg, retry) {
  return `<div class="img-note" role="alert">${esc(msg)}${retry ? ` <button type="button" class="link-btn" onclick="${retry}">إعادة المحاولة</button>` : ''}</div>`;
}
/** يعيد { hero, strip } لقائمة صور خادم. title نص السيارة؛ retry نص onclick أو ''. */
function RemoteCarGallery(st, title, retry) {
  const busy = st.status === 'idle' || st.status === 'loading';
  if (busy) return { hero: '<span class="img-ph" role="status" aria-busy="true" aria-label="جارٍ تحميل الصور">⏳</span>', strip: '' };
  if (st.status === 'error' || st.status === 'denied' || st.status === 'gone') return { hero: CAR_PLACEHOLDER, strip: _remoteImgNote(st.error || _IMG_NOTE_ERR, st.status === 'error' ? retry : '') };
  const shown = (st.items || []).map(i => ({ big: i.full || i.url || '', small: i.thumb || i.url || '' }));
  if (!shown.length) return { hero: CAR_PLACEHOLDER, strip: '' };
  const first = shown[0].big;
  const hero = first ? `<img src="${esc(first)}" alt="${esc(title)}" decoding="async" onerror="imgFallback(this)">` : CAR_PLACEHOLDER;
  const strip = shown.length < 2 ? '' : `<div class="img-strip">${shown.map((x, i) => x.small ? `<img src="${esc(x.small)}" alt="${esc(title)} — صورة ${i + 1}" loading="lazy" decoding="async" onerror="imgThumbFallback(this)">` : '').join('')}</div>`;
  return { hero, strip };
}
/** غلاف المعرض العام لوضع الخادم: { hero, note } */
function RemoteShowroomCover(st, name, retry) {
  if (st.status === 'ready' && st.cover && st.cover.url) return { hero: `<img src="${esc(st.cover.url)}" alt="${esc(name)}" decoding="async" data-ph="🏢" onerror="imgFallback(this)">`, note: '' };
  if (st.status === 'idle' || st.status === 'loading') return { hero: '<span class="img-ph" role="status" aria-busy="true" aria-label="جارٍ تحميل الغلاف">⏳</span>', note: '' };
  if (st.status === 'error') return { hero: SHOWROOM_PLACEHOLDER, note: _remoteImgNote('تعذّر تحميل غلاف المعرض.', retry) };
  return { hero: SHOWROOM_PLACEHOLDER, note: '' };
}

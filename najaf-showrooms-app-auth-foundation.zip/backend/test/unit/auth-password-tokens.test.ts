import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import type { Argon2ModuleLike } from '../../src/auth/password.ts';
import { ARGON2 } from '../../src/auth/policy.ts';
import { TOKEN_PREFIX, generateSessionToken, hashSessionToken, isWellFormedToken } from '../../src/auth/tokens.ts';

// A stand-in for the `argon2` package that records how it is called and produces PHC-shaped strings.
function fakeArgon2(overrides: Partial<Argon2ModuleLike> = {}) {
  const calls: Array<{ plain: string; options: Record<string, number> }> = [];
  const mod: Argon2ModuleLike = {
    argon2id: 2,
    async hash(plain, options) {
      calls.push({ plain, options });
      return `$argon2id$v=19$m=${options.memoryCost},t=${options.timeCost},p=${options.parallelism}$c2FsdA$${createHash('sha256').update(plain).digest('base64').replace(/=+$/, '')}`;
    },
    async verify(hash, plain) {
      if (!hash.startsWith('$argon2id$')) throw new Error('pchstr must contain a $ as first char');
      return hash.endsWith('$' + createHash('sha256').update(plain).digest('base64').replace(/=+$/, ''));
    },
    ...overrides,
  };
  return { mod, calls };
}

describe('argon2id hasher', () => {
  it('hashes with argon2id and the policy parameters (m=19456, t=2, p=1)', async () => {
    const { mod, calls } = fakeArgon2();
    const hash = await createArgon2idHasher({ importArgon2: async () => mod }).hash('pw-123456');
    assert.deepEqual(calls[0]?.options, { type: 2, memoryCost: ARGON2.memoryCost, timeCost: ARGON2.timeCost, parallelism: ARGON2.parallelism });
    assert.equal(calls[0]?.options['memoryCost'], 19456);
    assert.match(hash, /^\$argon2id\$v=19\$m=19456,t=2,p=1\$/);
  });

  it('verifies the right password and rejects the wrong one', async () => {
    const h = createArgon2idHasher({ importArgon2: async () => fakeArgon2().mod });
    const hash = await h.hash('right-password');
    assert.equal(await h.verify(hash, 'right-password'), true);
    assert.equal(await h.verify(hash, 'wrong-password'), false);
  });

  it('a malformed or foreign hash is a plain false, never an exception (and never a different error to the caller)', async () => {
    const h = createArgon2idHasher({ importArgon2: async () => fakeArgon2().mod });
    for (const bad of ['', 'not-a-hash', '$2b$10$abcdefghijklmnopqrstuv', 'mock$abc123']) assert.equal(await h.verify(bad, 'x'), false, bad);
  });

  it('a verification error inside the library is a plain false', async () => {
    const h = createArgon2idHasher({ importArgon2: async () => fakeArgon2({ verify: async () => { throw new Error('native failure'); } }).mod });
    assert.equal(await h.verify('$argon2id$v=19$m=1,t=1,p=1$a$b', 'x'), false);
  });

  it('refuses a hash that is not argon2id (the database CHECK would reject it anyway)', async () => {
    const h = createArgon2idHasher({ importArgon2: async () => fakeArgon2({ hash: async () => '$2b$10$notargon' }).mod });
    await assert.rejects(h.hash('x'), /unexpected password hash format/);
  });

  it('loads the library lazily and only once', async () => {
    let loads = 0;
    const { mod } = fakeArgon2();
    const h = createArgon2idHasher({ importArgon2: async () => (loads++, mod) });
    assert.equal(loads, 0);
    await h.hash('a');
    await h.hash('b');
    await h.verify('x', 'y');
    assert.equal(loads, 1);
  });

  it('ready() proves a hash/verify round trip, and fails fast when the library is unusable or wrong', async () => {
    await createArgon2idHasher({ importArgon2: async () => fakeArgon2().mod }).ready();
    await assert.rejects(createArgon2idHasher({ importArgon2: async () => { throw new Error('Cannot find package argon2'); } }).ready(), /Cannot find package/);
    await assert.rejects(createArgon2idHasher({ importArgon2: async () => fakeArgon2({ verify: async () => true }).mod }).ready(), /self-test failed/);
    await assert.rejects(createArgon2idHasher({ importArgon2: async () => fakeArgon2({ verify: async () => false }).mod }).ready(), /self-test failed/);
  });
});

describe('session tokens', () => {
  it('are prefixed, 47 characters, URL-safe and unique', () => {
    const seen = new Set<string>();
    for (let i = 0; i < 500; i++) {
      const t = generateSessionToken();
      assert.ok(t.startsWith(TOKEN_PREFIX) && t.length === 47 && isWellFormedToken(t));
      assert.ok(/^[A-Za-z0-9_-]+$/.test(t));
      seen.add(t);
    }
    assert.equal(seen.size, 500);
  });

  it('request exactly 256 bits (32 bytes) from the random source, and the real source fills all of them', () => {
    let requested = 0;
    const t = generateSessionToken((n) => {
      requested = n;
      return Buffer.alloc(n, 0xcd);
    });
    assert.equal(requested, 32);
    assert.deepEqual(Buffer.from(t.slice(TOKEN_PREFIX.length), 'base64url'), Buffer.alloc(32, 0xcd));
    // with real randomness the LAST bytes are random too: a token padded from a shorter source would end in zero bytes
    let allZeroTail = 0;
    for (let i = 0; i < 200; i++) {
      const raw = Buffer.from(generateSessionToken().slice(TOKEN_PREFIX.length), 'base64url');
      assert.equal(raw.length, 32);
      if (raw.subarray(16).every((b) => b === 0)) allZeroTail += 1;
    }
    assert.equal(allZeroTail, 0);
  });

  it('carry 256 bits from the injected random source and nothing else', () => {
    const t = generateSessionToken(() => Buffer.alloc(32, 0xab));
    assert.equal(t, TOKEN_PREFIX + Buffer.alloc(32, 0xab).toString('base64url'));
    assert.equal(Buffer.from(t.slice(TOKEN_PREFIX.length), 'base64url').length, 32);
  });

  it('are stored only as a 32-byte SHA-256: deterministic, and not derivable into the token', () => {
    const t = generateSessionToken();
    const h = hashSessionToken(t);
    assert.equal(h.length, 32);
    assert.ok(h.equals(hashSessionToken(t)));
    assert.ok(h.equals(createHash('sha256').update(t).digest()));
    assert.ok(!h.equals(hashSessionToken(generateSessionToken())));
    assert.ok(!h.toString('base64url').includes(t.slice(4, 20)));
  });

  it('well-formedness rejects everything that is not exactly nsj_ + 43 base64url characters', () => {
    const ok = TOKEN_PREFIX + 'a'.repeat(43);
    assert.equal(isWellFormedToken(ok), true);
    for (const bad of [undefined, null, 5, '', ok + 'a', ok.slice(1), 'nsj_' + 'a'.repeat(42), 'nsj_' + 'a'.repeat(42) + '=', 'NSJ_' + 'a'.repeat(43), ' ' + ok, ok + '\n', 'nsj_' + 'a'.repeat(42) + '+']) {
      assert.equal(isWellFormedToken(bad), false, String(bad));
    }
  });
});

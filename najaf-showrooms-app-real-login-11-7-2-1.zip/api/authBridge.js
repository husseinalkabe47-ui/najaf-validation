/* ==========================================================================
   BACKEND AUTH — جسر المصادقة الحقيقية (المرحلة 11.7.2.1)
   يربط تسجيل الدخول والخروج بالخادم عبر ApiClient وفق العقد الموجود (backend/src/auth/routes.ts):
     POST /v1/auth/login  { phone, password } → 200 { user, session }
     POST /v1/auth/logout { refreshToken }     → 204
   (التجديد عند انتهاء رمز الوصول يتم داخل ApiClient بعقد POST /v1/auth/refresh نفسه.)

   الوضعان (يُحدَّدان عند التشغيل من وسم <meta name="najaf-api-base-url">، انظر api/README.md):
     • العنوان فارغ (الافتراضي) = وضع التجربة المحلي: لا يُنشئ هذا الملف أي عميل ولا يتصل بشيء، والتطبيق يعمل كما كان.
     • العنوان مضبوط = وضع الخادم: الدخول والخروج من الخادم فقط. لا رجوع إلى الحسابات التجريبية المحلية، ولا تُقرأ
       الجلسة المحلية القديمة ولا تُكتب جلسة محلية. بيانات السيارات/المعارض/المفضلة ما زالت محلية تجريبية (لم تُربط بعد).

   الأمان:
     • الرموز تبقى داخل ApiClient في الذاكرة فقط؛ هذا الملف لا يراها ولا يخزّنها ولا يسجّلها.
     • كلمة المرور تُمرَّر لطلب الدخول فقط، ولا تُخزَّن ولا تُسجَّل ولا تبقى في أي متغير بعد الطلب.
     • لا شيء يُكتب في localStorage/AppStorage هنا. إعادة تحميل الصفحة تُنهي الجلسة في الواجهة (انظر القيود في api/README.md).
     • مستخدم الخادم يحمل معرّفًا ببادئة «srv:» كي لا يتطابق أبدًا مع معرّف مستخدم تجريبي محلي (فلا يرث ملكية بيانات تجريبية).
   ========================================================================== */
const BackendAuth = (function () {
  const MSG = {
    badInput: 'أدخل رقم الهاتف وكلمة المرور.',
    badPhone: 'رقم الهاتف غير صحيح. مثال: 07701234567',
    email: 'تسجيل الدخول عبر الخادم يتم برقم الهاتف فقط.',
    credentials: 'بيانات الدخول غير صحيحة.',
    validation: 'تحقق من رقم الهاتف وكلمة المرور.',
    network: 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.',
    timeout: 'انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.',
    server: 'حدث خطأ في الخادم. حاول لاحقًا.',
    invalid: 'ردّ الخادم غير صالح. حاول لاحقًا.',
    config: 'إعداد الاتصال بالخادم غير صحيح.',
    expired: 'انتهت الجلسة. سجّل الدخول من جديد.',
    busy: 'جارٍ تسجيل الدخول…',
    register: 'إنشاء الحساب عبر الخادم سيتوفر في خطوة لاحقة.',
    generic: 'تعذّر تسجيل الدخول. حاول مرة أخرى.',
  };
  let enabled = false;
  let misconfigured = false;
  let client = null;
  let user = null;
  let busy = false;
  let lostListener = null;

  /** الخادم فقد الجلسة نهائيًا (تجديد مرفوض/منتهٍ): تُمسح الحالة هنا أولًا ثم يُبلَّغ مستمع الواجهة. */
  function handleLost(reason) {
    user = null;
    if (lostListener) { try { lostListener(reason); } catch (e) { /* مستمع الواجهة لا يكسر العميل */ } }
  }

  /**
   * يُستدعى عند التشغيل. opts (للاختبار): baseUrl وخيارات ApiClient.create (fetch، now، ...). بلا opts يُقرأ العنوان من الصفحة.
   * يعيد true إن كان وضع الخادم مفعّلًا. عنوان مضبوط لكنه غير صالح = وضع الخادم «معطّل الإعداد» (الدخول يفشل برسالة، ولا رجوع للوضع المحلي).
   */
  function init(opts) {
    opts = opts || {};
    enabled = false; misconfigured = false; client = null; user = null; busy = false;
    let raw = '';
    try { raw = opts.baseUrl !== undefined ? String(opts.baseUrl || '').trim() : ApiClient.readConfiguredBaseUrl(); } catch (e) { raw = ''; }
    if (!raw) return false;
    enabled = true;
    try { client = ApiClient.create(Object.assign({}, opts, { baseUrl: raw, onAuthLost: handleLost })); } catch (e) { misconfigured = true; }
    return true;
  }

  function messageFor(err, context) {
    if (!err || err.name !== 'ApiError') return MSG.generic;
    if (err.kind === 'network') return MSG.network;
    if (err.kind === 'timeout') return MSG.timeout;
    if (err.kind === 'aborted') return 'أُلغي الطلب.';
    if (err.kind === 'config') return MSG.config;
    if (err.kind === 'invalid_response') return MSG.invalid;
    if (err.kind === 'auth') return MSG.expired;
    if (err.kind === 'http') {
      if (err.status === 401) return context === 'session' ? MSG.expired : MSG.credentials;
      if (err.status === 400) return MSG.validation;
      if (err.status === 429) {
        const m = Number.isFinite(err.retryAfterSeconds) ? Math.max(1, Math.ceil(err.retryAfterSeconds / 60)) : 0;
        return 'محاولات كثيرة. ' + (m ? 'حاول بعد ' + m + ' دقيقة.' : 'انتظر قليلًا ثم حاول مرة أخرى.');
      }
      if (err.status >= 500) return MSG.server;
    }
    return MSG.generic;
  }

  /** مستخدم الخادم بالشكل الذي تفهمه الواجهة (نفس حقول UserService.toPublic). null إن كان الشكل أو الدور أو الحالة غير معروف. */
  function toLocalShape(u) {
    if (!u || typeof u !== 'object') return null;
    const roles = Object.keys(ROLES).map(function (k) { return ROLES[k]; });
    const statuses = Object.keys(USER_STATUS).map(function (k) { return USER_STATUS[k]; });
    if (typeof u.id !== 'string' || !/^[0-9]{1,20}$/.test(u.id)) return null;
    if (typeof u.name !== 'string' || !u.name || typeof u.phone !== 'string') return null;
    if (roles.indexOf(u.role) < 0 || statuses.indexOf(u.status) < 0) return null;
    return { id: 'srv:' + u.id, name: u.name, phone: normalizePhone(u.phone) || u.phone, email: null, role: u.role, status: u.status, createdAt: typeof u.createdAt === 'string' ? u.createdAt : null };
  }

  /** تسجيل الدخول. يعيد دائمًا { ok:true, user } أو { ok:false, error: نص عربي آمن }. لا يرمي. */
  async function login(identifier, password) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (busy) return { ok: false, error: MSG.busy };
    const id = String(identifier == null ? '' : identifier).trim();
    const pw = password == null ? '' : String(password);
    if (!id || !pw) return { ok: false, error: MSG.badInput };
    if (id.indexOf('@') >= 0) return { ok: false, error: MSG.email };       // العقد: الدخول بالهاتف فقط
    const phone = normalizePhone(id);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const tooLong = textLimitError({ password: pw }, ['password']);
    if (tooLong) return { ok: false, error: tooLong };
    busy = true;
    try {
      const data = await client.post('/v1/auth/login', { phone: phone, password: pw }, { auth: 'none' });
      const mapped = data && toLocalShape(data.user);
      if (!mapped) throw new ApiClient.ApiError('invalid_response', { message: 'invalid user in login response' });
      try { client.setSession(data.session); }   // يرفض شكلًا غير صالح فلا تبقى جلسة جزئية
      catch (se) { throw new ApiClient.ApiError('invalid_response', { message: 'invalid session in login response' }); }
      user = mapped;
      return { ok: true, user: Object.assign({}, mapped) };
    } catch (e) {
      client.clearSession();             // لا جلسة نصف مكتملة بعد أي فشل
      user = null;
      return { ok: false, error: messageFor(e, 'login') };
    } finally {
      busy = false;
    }
  }

  /**
   * تسجيل الخروج: حالة الواجهة تُمسح فورًا (متزامنًا)، ثم يُبطَل رمز الجلسة في الخادم.
   * الوعد لا يُرفض أبدًا: { hadSession, revoked, error? }. revoked=false مع hadSession=true = خرج المستخدم محليًا لكن تعذّر إبلاغ الخادم.
   */
  function logout() {
    user = null;
    if (!client) return Promise.resolve({ hadSession: false, revoked: false });
    return client.logout().catch(function () { return { hadSession: true, revoked: false }; });
  }

  return {
    init: init,
    isEnabled: function () { return enabled; },
    currentUser: function () { return user ? Object.assign({}, user) : null; },
    /** يمسح مستخدم الواجهة فقط (دون اتصال) — تستعمله SessionService.logout. */
    forgetUser: function () { user = null; },
    login: login,
    logout: logout,
    /** عميل الـAPI لخطوات لاحقة (لا يكشف الرموز). null في الوضع المحلي. */
    api: function () { return client; },
    onLost: function (fn) { lostListener = typeof fn === 'function' ? fn : null; },
    messageFor: messageFor,
    messages: MSG,
  };
})();

/* Phase 11.7.2.4 — لوحة التاجر من الخادم (قراءة فقط) داخل التطبيق الفعلي (vm بسكربتات index.html) مقابل «الخادم» الوهمي في session_world.js.
   الخادم الوهمي هنا يحاكي العقد الموجود فقط: GET /v1/dealer/showroom → { showroom } و GET /v1/dealer/cars → { items, nextBefore } (404 بلا معرض).
   لا خادم ولا قاعدة بيانات حقيقية. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const SHOWROOM = { id: '7', name: 'معرض الكوفة الحديث', status: 'active', phone: '+9647801234567', whatsapp: null, address: 'النجف - شارع الكوفة', createdAt: '2026-01-01T00:00:00.000Z' };
const car = (id, o) => Object.assign({ id: String(id), showroomId: '7', brand: 'تويوتا', model: 'كامري', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000,
  transmission: 'automatic', fuelType: 'petrol', color: 'أبيض', description: '', status: 'available', version: 1, createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-01T00:00:00.000Z' }, o);
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code) => json(status, { error: { code, message: 'm', requestId: 'r' } });

/** «خادم» العالم + دور تاجر عند الدخول + مسارا لوحة التاجر. dealer.showroom/cars/handler قابلة للتغيير في كل اختبار. */
function dealerWorld(role) {
  const w = world();
  const d = { role: role || 'dealer', showroom: SHOWROOM, pages: [{ items: [car(12), car(11, { status: 'sold', brand: 'كيا', model: 'سبورتاج', currency: 'USD', price: 18000 })], nextBefore: null }], handler: null, gate: null };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') {
      const r = await base(url, init);
      const body = await r.json(); body.user.role = d.role;
      return json(r.status, body);
    }
    if (!u.pathname.startsWith('/v1/dealer/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, body: init.body };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const m = /^Bearer (.+)$/.exec(h.authorization || '');
    const rec = m && w.srv.access.get(m[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.handler) { const r = d.handler(call); if (r) return r; }
    if (d.role !== 'dealer' || !d.showroom) return err(404, 'not_found');
    if (u.pathname === '/v1/dealer/showroom') return json(200, { showroom: d.showroom });
    if (u.pathname === '/v1/dealer/cars') {
      const i = call.query.before ? d.pages.findIndex((p, k) => k > 0 && d.pages[k - 1].nextBefore === call.query.before) : 0;
      return json(200, d.pages[i < 0 ? 0 : i]);
    }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController;
  env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  return {
    env, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: p => w.srv.calls.filter(c => c.path === p),
    async login() { await env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"); },
  };
}
const settle = async () => { for (let i = 0; i < 20; i++) await tick(); };

/* ====================== الوضع المحلي ====================== */

test('الوضع المحلي دون تغيير: لوحة التاجر وسيارات معرضي من البيانات المحلية، بأزرار الإضافة/التعديل/الحذف، ولا اتصال', () => {
  const env = makeEnv();
  env.run("AuthService.login('07701234567', 'dealer123')");
  assert.equal(env.run('BackendDealer.isEnabled()'), false);
  env.run("go('dealerHome')");
  assert.equal(env.run('currentRoute'), 'dealerHome');
  assert.match(env.screen(), /سيارات معرضي \(إضافة \/ تعديل \/ حذف\)/);
  assert.match(env.screen(), /showroom-card/);
  env.run("go('myShowroomCars')");
  assert.match(env.screen(), /\+ إضافة سيارة/);
  assert.match(env.screen(), /handleDeleteShowroomCar/);
  assert.equal(env.run("BackendDealer.showroom().status"), 'idle', 'لا طلب في الوضع المحلي');
  assert.deepEqual(env.errors, []);
});

/* ====================== لوحة التاجر ====================== */

test('وضع الخادم: لوحة التاجر تعرض «جارٍ التحميل» ثم المعرض من GET /v1/dealer/showroom بالرمز، دون أي معرض محلي', async () => {
  const { w } = dealerWorld(); const p = page(w);
  await p.login();
  p.run("go('dealerHome')");
  assert.equal(p.route(), 'dealerHome');
  assert.match(p.screen(), /جارٍ تحميل بيانات معرضك/);
  assert.match(p.screen(), /aria-busy="true"/);
  await settle();
  const c = p.calls('/v1/dealer/showroom');
  assert.equal(c.length, 1);
  assert.equal(c[0].method, 'GET');
  assert.match(c[0].headers.authorization, /^Bearer AT-\d+$/);
  const html = p.screen();
  assert.match(html, /معرض الكوفة الحديث/); assert.match(html, /النجف - شارع الكوفة/); assert.match(html, /نشط/);
  assert.ok(!/showroom-card|إضافة \/ تعديل \/ حذف/.test(html), 'لا بطاقة معرض محلي ولا وعود بإضافة/حذف');
  assert.match(html, /go\('myShowroomCars'\)/);
  p.run('render()'); await settle();
  assert.equal(p.calls('/v1/dealer/showroom').length, 1, 'إعادة الرسم لا تكرر الطلب');
});

test('لوحة التاجر: 404 (لا معرض مرتبط) = حالة فارغة لا خطأ، ولا رجوع لبيانات محلية', async () => {
  const { w, d } = dealerWorld(); d.showroom = null; const p = page(w);
  await p.login(); p.run("go('dealerHome')"); await settle();
  assert.match(p.screen(), /لا يوجد معرض مرتبط بحسابك بعد/);
  assert.ok(!/go\('myShowroomCars'\)|role="alert"/.test(p.screen()));
});

test('لوحة التاجر: خطأ شبكة/خادم = رسالة عربية وزر إعادة المحاولة؛ إعادة المحاولة تنجح', async () => {
  const { w } = dealerWorld(); const p = page(w);
  await p.login();
  w.srv.down = true;
  p.run("go('dealerHome')"); await settle();
  assert.match(p.screen(), /role="alert"/); assert.match(p.screen(), /تعذّر الاتصال بالخادم/); assert.match(p.screen(), /إعادة المحاولة/);
  assert.ok(!/معرض الكوفة/.test(p.screen()));
  w.srv.down = false;
  p.run("BackendDealer.loadShowroom(_rerenderIf('dealerHome'));render()");
  assert.match(p.screen(), /جارٍ تحميل بيانات معرضك/);
  await settle();
  assert.match(p.screen(), /معرض الكوفة الحديث/);
});

test('لوحة التاجر: 500 ورد غير صالح = خطأ (لا عرض لبيانات ناقصة)، و403 = غير مصرّح', async () => {
  for (const [resp, re] of [[err(500, 'internal'), /خطأ في الخادم/], [json(200, { showroom: { id: 7 } }), /ردّ الخادم غير صالح/], [err(403, 'forbidden'), /لا تملك صلاحية/]]) {
    const { w, d } = dealerWorld(); d.handler = () => resp.clone(); const p = page(w);
    await p.login(); p.run("go('dealerHome')"); await settle();
    assert.match(p.screen(), re);
    assert.ok(!/معرض الكوفة/.test(p.screen()));
  }
});

test('غير مصرّح: مستخدم عادي في وضع الخادم لا يصل إلى لوحة التاجر ولا يُرسل أي طلب للتاجر', async () => {
  const { w } = dealerWorld('user'); const p = page(w);
  await p.login();
  p.run("go('dealerHome')"); assert.equal(p.route(), 'accessDenied');
  p.run("go('myShowroomCars')"); assert.equal(p.route(), 'accessDenied');
  await settle();
  assert.equal(w.srv.calls.filter(c => c.path.startsWith('/v1/dealer/')).length, 0);
});

test('انتهاء الجلسة أثناء الطلب (401 ثم رفض التجديد) يعيد إلى شاشة الدخول برسالة انتهاء الجلسة', async () => {
  const { w, d } = dealerWorld(); const p = page(w);
  await p.login();
  w.srv.families.forEach(f => { f.revoked = true; });
  p.run("go('dealerHome')"); await settle();
  assert.equal(p.route(), 'login');
  assert.match(p.env.els.toast.textContent, /انتهت الجلسة/);
  void d;
});

test('خروج أثناء الطلب: نتيجة الطلب القديم لا تُطبَّق على المستخدم التالي', async () => {
  const { w, d } = dealerWorld(); const p = page(w);
  let release; d.gate = () => new Promise(r => { release = r; });
  await p.login(); p.run("go('dealerHome')"); await tick();
  p.run('handleLogout()');
  d.gate = null; release(); await settle();
  assert.equal(p.run('BackendDealer.showroom().status'), 'idle');
  assert.equal(p.route(), 'home');
});

/* ====================== سيارات معرضي ====================== */

test('سيارات معرضي: GET /v1/dealer/cars?limit=50 ثم القائمة (السعر والعملة والحالة)', async () => {
  const { w } = dealerWorld(); const p = page(w);
  await p.login(); p.run("go('myShowroomCars')");
  assert.match(p.screen(), /جارٍ تحميل سيارات معرضك/);
  await settle();
  const c = p.calls('/v1/dealer/cars');
  assert.equal(c.length, 1); assert.deepEqual(c[0].query, { limit: '50' }); assert.match(c[0].headers.authorization, /^Bearer /);
  const html = p.screen();
  assert.match(html, /تويوتا كامري/); assert.match(html, /كيا سبورتاج/);
  assert.match(html, /متاحة للبيع/); assert.match(html, /مباعة/);
  assert.match(html, /25,000,000|٢٥/); assert.match(html, /\$|دولار/);
  assert.ok(!/ستتوفر في خطوة لاحقة/.test(html), '11.7.2.5: عمليات الكتابة رُبطت (انظر backend_dealer_cars_write.test.js)');
  assert.ok(!/عرض المزيد/.test(html));
  assert.deepEqual(p.env.errors, []);
});

test('سيارات معرضي: صفر سيارات = «لا توجد سيارات»، و404 = «لا يوجد معرض مرتبط»', async () => {
  { const { w, d } = dealerWorld(); d.pages = [{ items: [], nextBefore: null }]; const p = page(w);
    await p.login(); p.run("go('myShowroomCars')"); await settle();
    assert.match(p.screen(), /لا توجد سيارات في معرضك بعد/); }
  { const { w, d } = dealerWorld(); d.showroom = null; const p = page(w);
    await p.login(); p.run("go('myShowroomCars')"); await settle();
    assert.match(p.screen(), /لا يوجد معرض مرتبط بحسابك بعد/); }
});

test('سيارات معرضي: الخطأ لا يعرض بيانات محلية، وإعادة المحاولة تعيد الطلب', async () => {
  const { w, d } = dealerWorld(); let n = 0; d.handler = c => (c.path === '/v1/dealer/cars' && ++n === 1 ? err(503, 'unavailable') : null);
  const p = page(w);
  await p.login(); p.run("go('myShowroomCars')"); await settle();
  assert.match(p.screen(), /خطأ في الخادم/); assert.match(p.screen(), /إعادة المحاولة/);
  assert.ok(!/ad-row/.test(p.screen()));
  p.run("BackendDealer.loadCars(_rerenderIf('myShowroomCars'));render()"); await settle();
  assert.match(p.screen(), /تويوتا كامري/);
  assert.equal(p.calls('/v1/dealer/cars').length, 2);
});

test('سيارات معرضي: عنصر غير صالح في الردّ = خطأ «ردّ غير صالح» (لا عرض جزئي صامت)', async () => {
  const { w, d } = dealerWorld(); d.pages = [{ items: [car(1), { id: 2, brand: 'x' }], nextBefore: null }]; const p = page(w);
  await p.login(); p.run("go('myShowroomCars')"); await settle();
  assert.match(p.screen(), /ردّ الخادم غير صالح/); assert.ok(!/تويوتا/.test(p.screen()));
});

test('سيارات معرضي: «عرض المزيد» بـ before=nextBefore يُلحق الصفحة التالية', async () => {
  const { w, d } = dealerWorld();
  d.pages = [{ items: [car(30), car(29)], nextBefore: '29' }, { items: [car(28, { brand: 'هوندا', model: 'أكورد' })], nextBefore: null }];
  const p = page(w);
  await p.login(); p.run("go('myShowroomCars')"); await settle();
  assert.match(p.screen(), /عرض المزيد/);
  p.run("BackendDealer.loadCars(_rerenderIf('myShowroomCars'), true);render()");
  assert.match(p.screen(), /جارٍ تحميل المزيد/);
  await settle();
  const c = p.calls('/v1/dealer/cars');
  assert.equal(c.length, 2); assert.deepEqual(c[1].query, { limit: '50', before: '29' });
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 3);
  assert.match(p.screen(), /هوندا أكورد/); assert.ok(!/عرض المزيد/.test(p.screen()));
});

test('عزل: الجسر لا يلمس التخزين ولا Console ولا fetch، ولا يذكر مسارات كتابة أو بيانات محلية؛ ولا سكربت جديد (87)', () => {
  const all = fs.readFileSync(path.join(__dirname, '..', 'api/authBridge.js'), 'utf8');
  const src = all.slice(all.indexOf('const BackendDealer')).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(src.length > 1000);
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(/.test(src));
  assert.ok(!/Repository|getMyShowroomCars|getManagedShowrooms|SHOWROOMS|CARS\b/.test(src));
  assert.ok(!/\/v1\/(?!dealer\/)/.test(src.replace(/\/v1\/dealer\//g, '')), 'مسارات لوحة التاجر فقط');
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert.equal((html.match(/<script src=/g) || []).length, 87);
});

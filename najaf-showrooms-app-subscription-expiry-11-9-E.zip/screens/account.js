function AccountScreen() {
  const user = SessionService.getCurrentUser();
  const pendingDealer = user && user.role === ROLES.DEALER && user.status === USER_STATUS.PENDING;
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>👤 حسابي</h1></div>
  <div class="section">
    ${AccountCard(user)}
    ${pendingDealer ? `<div class="form-note" style="margin:0 0 14px">طلبك كصاحب معرض قيد المراجعة. ستظهر «إدارة معرضي» بعد موافقة الإدارة.</div>` : ''}
    <div class="owner-actions">
      <button onclick="go('myMemberCars')">📋 سياراتي (إعلاناتي)</button>
      ${AuthorizationService.canCreateMemberCar() ? `<button onclick="go('addMemberCar')">➕ إضافة سيارة</button>` : ''}
      <button onclick="go('favorites')">❤️ المفضلة</button>
    </div>
  </div>
  ${AuthService.isRemote() ? AccountSecurityHtml(user) : ''}`;
}

/* (11.7-F) أمان الحساب — قسم داخل «حسابي» في وضع الخادم فقط (الوضع المحلي لا يعرضه: لا خادم). عرض فقط؛ المنطق في navigation/actions.js و BackendAuth. */
function AccountSecurityHtml(user) {
  const verified = !!(user && user.id && BackendAuth.isPhoneVerified());
  const sent = !!(typeof currentParam === 'object' && currentParam && currentParam.codeSent);
  return `
  <div class="section" id="accountSecurity">
    <h2>🔒 أمان الحساب</h2>
    <div class="form-card">
      <h3>توثيق رقم الهاتف</h3>
      ${verified
        ? `<div class="form-note" role="status">✅ رقم هاتفك موثّق.</div>`
        : `<div class="form-note">رقم هاتفك غير موثّق بعد.</div>
      ${sent ? `<div class="form-note" role="status">${esc(BackendAuth.messages.phoneCodeSent)}</div>
      <div class="field"><label for="verifyCode">رمز التوثيق (6 أرقام)</label>
        <input id="verifyCode" type="text" inputmode="numeric" dir="ltr" autocomplete="one-time-code" maxlength="12" placeholder="••••••"
               onkeydown="if(event.key==='Enter')handleVerifyPhoneConfirm()"></div>
      <button class="btn-primary" onclick="handleVerifyPhoneConfirm()">تأكيد التوثيق</button>` : ''}
      <button class="${sent ? 'link-btn' : 'btn-primary'}" onclick="handleVerifyPhoneRequest()">${sent ? 'إرسال رمز جديد' : 'إرسال رمز التوثيق'}</button>`}
      <div id="verifyError" class="form-error" role="alert" style="display:none"></div>
      <div id="verifyNote" class="form-note" role="status" style="display:none"></div>
    </div>
    <div class="form-card">
      <h3>تغيير كلمة المرور</h3>
      <div class="field"><label for="cpCurrent">كلمة المرور الحالية</label>
        <input id="cpCurrent" type="password" dir="ltr" autocomplete="current-password"></div>
      <div class="field"><label for="cpNew">كلمة المرور الجديدة</label>
        <input id="cpNew" type="password" dir="ltr" autocomplete="new-password"></div>
      <div class="field"><label for="cpConfirm">تأكيد كلمة المرور الجديدة</label>
        <input id="cpConfirm" type="password" dir="ltr" autocomplete="new-password"
               onkeydown="if(event.key==='Enter')handleChangePasswordSubmit()"></div>
      <div class="form-note">بعد التغيير تنتهي جلساتك على كل الأجهزة، بما فيها هذا الجهاز.</div>
      <div id="cpError" class="form-error" role="alert" style="display:none"></div>
      <div id="cpNote" class="form-note" role="status" style="display:none"></div>
      <button class="btn-primary" onclick="handleChangePasswordSubmit()">تغيير كلمة المرور</button>
    </div>
    <div class="form-card">
      <h3>الجلسات</h3>
      <div class="form-note">ينهي جلساتك على كل الأجهزة، بما فيها هذا الجهاز.</div>
      <div id="logoutAllError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleLogoutAll()">تسجيل الخروج من كل الأجهزة</button>
    </div>
  </div>`;
}

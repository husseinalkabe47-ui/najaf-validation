function AdminUserDetailsScreen(id) {
  if (BackendUserDirectory.isEnabled()) return _AdminUserDetailsRemote(id);   // 11.7.2-J: GET /v1/admin/users/:id
  const u = UserService.getPublicById(id);
  if (!u) return `<div class="placeholder"><b role="heading" aria-level="1">المستخدم غير موجود</b></div>`;
  const managed = AuthorizationService.getManagedShowrooms(u); // معارضه إن كان تاجرًا
  return `
  <div class="back-btn"><button class="back-circle" aria-label="رجوع" onclick="goBack('adminUsers')">→</button></div>
  <div class="section">
    <div class="account-card">
      <h1>👤 ${esc(u.name)}</h1>
      <div class="info-row">📞 ${esc(u.phone)}</div>
      ${u.email ? `<div class="info-row">✉️ ${esc(u.email)}</div>` : ''}
      <div class="info-row">🏷️ ${ROLE_LABEL[u.role] || u.role} — ${USER_STATUS_LABEL[u.status] || u.status}</div>
      <div class="info-row">🗓️ تاريخ إنشاء الحساب: ${createdDateText(u.createdAt)}</div>
    </div>
    ${u.role === 'dealer' ? `
    <h2>معارضه</h2>
    <div class="list-grid">${managed.map(ShowroomCard).join('') || '<div class="placeholder">لا يوجد معرض بعد.</div>'}</div>` : ''}
    ${u.role === 'user' || u.role === 'dealer' ? `
    <h2 style="margin-top:14px">إعلانات سيارات الأعضاء</h2>
    <div class="list-grid">${getMemberCarsByOwner(u.id).map(c => `<div class="ad-row"><div class="card-img">🚘</div><div class="ad-info"><p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>${memberCarStatusBadge(c.status)}</div></div>`).join('') || '<div class="placeholder">لا توجد إعلانات.</div>'}</div>` : ''}
    <div class="placeholder" style="margin-top:14px"><span class="ic">🔒</span>حذف المدير الحالي وتغيير كلمة المرور من هنا غير متاحين في هذا النموذج التجريبي.</div>
  </div>`;
}

/* (11.7.2-J) وضع الخادم: الحساب من GET /v1/admin/users/:id بالحقول نفسها (الاسم، الهاتف، البريد، الدور والحالة، تاريخ الإنشاء)، ومعرض صاحب
   المعرض (الاسم والحالة)، وإعلانات سيارات الأعضاء (الماركة والموديل والحالة، حتى 100 مع العدد الكلي). قراءة فقط. */
function _AdminUserDetailsRemote(id) {
  const st = BackendUserDirectory.user(id, _rerenderIf('adminUserDetails'));
  const back = `<div class="back-btn"><button class="back-circle" aria-label="رجوع" onclick="goBack('adminUsers')">→</button></div>`;
  if (st.status === 'gone') return back + EmptyState({ icon: '👤', title: 'المستخدم غير موجود', heading: true, actions: [{ label: 'المستخدمون', onclick: "go('adminUsers')" }] });
  if (st.status !== 'ready') return back + RemoteState(st, { loading: 'جارٍ تحميل بيانات الحساب…', retry: "BackendUserDirectory.retryUser(currentParam, _rerenderIf('adminUserDetails'));render()", empty: { icon: '👤', title: '' } });
  const { user: u, showroom: sh, memberCars, memberCarsTotal } = st.data;
  return `
  ${back}
  <div class="section">
    <div class="account-card">
      <h1>👤 ${esc(u.name)}</h1>
      <div class="info-row">📞 <span dir="ltr">${esc(u.phone)}</span></div>
      ${u.email ? `<div class="info-row">✉️ ${esc(u.email)}</div>` : ''}
      <div class="info-row">🏷️ ${esc(ROLE_LABEL[u.role] || u.role)} — ${esc(USER_STATUS_LABEL[u.status] || u.status)}</div>
      <div class="info-row">🗓️ تاريخ إنشاء الحساب: ${createdDateText(u.createdAt)}</div>
    </div>
    ${u.role === 'dealer' ? `
    <h2>معارضه</h2>
    <div class="list-grid">${sh ? `<div class="ad-row"><div class="card-img">🏢</div><div class="ad-info"><p class="card-title">${esc(sh.name)}</p>${showroomStatusBadge(sh.status)}</div></div>` : '<div class="placeholder">لا يوجد معرض بعد.</div>'}</div>` : ''}
    ${u.role === 'user' || u.role === 'dealer' ? `
    <h2 style="margin-top:14px">إعلانات سيارات الأعضاء</h2>
    <div class="list-grid">${memberCars.map(c => `<div class="ad-row"><div class="card-img">🚘</div><div class="ad-info"><p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>${memberCarStatusBadge(c.status)}</div></div>`).join('') || '<div class="placeholder">لا توجد إعلانات.</div>'}</div>
    ${memberCarsTotal > memberCars.length ? `<div class="sub" role="note">يُعرض أحدث ${esc(memberCars.length)} من ${esc(memberCarsTotal)} إعلانًا.</div>` : ''}` : ''}
  </div>`;
}

/* AdminUsersScreen — كل المستخدمين مع فلتر بالدور. بلا كلمات مرور أبدًا
   (adminGetAllUsers تمر عبر UserService.toPublic). */
let adminUsersRoleFilter = 'all';
function renderAdminUsersList() {
  let list = adminGetAllUsers();
  if (adminUsersRoleFilter !== 'all') list = list.filter(u => u.role === adminUsersRoleFilter);
  if (list.length === 0) return `<div class="placeholder"><span class="ic">🔍</span>لا يوجد مستخدمون.</div>`;
  return `<div class="list-grid">${list.map(u => `
    <div class="ad-row" role="button" tabindex="0" onclick="go('adminUserDetails', ${u.id})">
      <div class="card-img">👤</div>
      <div class="ad-info">
        <p class="card-title">${esc(u.name)}</p>
        <p class="card-row">📞 ${esc(u.phone)}</p>
        <p class="card-row">🏷️ ${ROLE_LABEL[u.role] || u.role} — ${USER_STATUS_LABEL[u.status] || u.status}</p>
      </div>
    </div>`).join('')}</div>`;
}
function onAdminUsersFilter(role) {
  adminUsersRoleFilter = role;
  const tabs = document.getElementById('adminUsersTabs'); if (tabs) tabs.innerHTML = _adminUsersTabsHtml();
  const l = document.getElementById('adminUsersList'); if (l) l.innerHTML = renderAdminUsersList();
}
function _adminUsersTabsHtml() {
  const tabs = [['all', 'الكل'], ['user', 'مستخدم'], ['dealer', 'صاحب معرض'], ['admin', 'مدير']];
  return tabs.map(([v, l]) => `<button type="button" class="${adminUsersRoleFilter === v ? 'active' : ''}" aria-pressed="${adminUsersRoleFilter === v}" onclick="onAdminUsersFilter('${v}')">${l}</button>`).join('');
}
function AdminUsersScreen() {
  if (BackendUserDirectory.isEnabled()) return _AdminUsersRemote();   // 11.7.2-J: GET /v1/admin/users
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>👥 المستخدمون</h1></div>
  <div class="section">
    <div class="status-tabs" id="adminUsersTabs">${_adminUsersTabsHtml()}</div>
    <div id="adminUsersList">${renderAdminUsersList()}</div>
  </div>`;
}

/* (11.7.2-J) وضع الخادم: الحسابات من GET /v1/admin/users (BackendUserDirectory) بالتبويبات والحقول نفسها؛ «عرض المزيد» بالمؤشر nextAfter.
   قراءة فقط: لا إجراء على الحساب. لا بيانات محلية. */
function _AdminUsersRemote() {
  const v = BackendUserDirectory.users(_rerenderIf('adminUsers'));
  const tabs = [['all', 'الكل'], ['user', 'مستخدم'], ['dealer', 'صاحب معرض'], ['admin', 'مدير']]
    .map(([k, l]) => `<button type="button" class="${v.role === k ? 'active' : ''}" aria-pressed="${v.role === k}" onclick="handleAdminUsersRole('${k}')">${l}</button>`).join('');
  const row = u => `
    <div class="ad-row" role="button" tabindex="0" onclick="go('adminUserDetails', '${esc(u.id)}')">
      <div class="card-img">👤</div>
      <div class="ad-info">
        <p class="card-title">${esc(u.name)}</p>
        <p class="card-row">📞 <span dir="ltr">${esc(u.phone)}</span></p>
        <p class="card-row">🏷️ ${esc(ROLE_LABEL[u.role] || u.role)} — ${esc(USER_STATUS_LABEL[u.status] || u.status)}</p>
      </div>
    </div>`;
  const body = v.status === 'ready'
    ? `<div class="list-grid">${v.items.map(row).join('')}</div>`
      + (v.error ? `<div class="form-error" role="alert">${esc(v.error)}</div>` : '')
      + (v.hasMore ? `<button class="btn-primary" style="margin-top:12px" ${v.more ? 'disabled' : ''} onclick="handleAdminUsersMore()">${v.more ? 'جارٍ التحميل…' : 'عرض المزيد'}</button>` : '')
    : RemoteState(v, { loading: 'جارٍ تحميل المستخدمين…', retry: "BackendUserDirectory.retryUsers(_rerenderIf('adminUsers'));render()", empty: { icon: '🔍', title: 'لا يوجد مستخدمون.' } });
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>👥 المستخدمون</h1></div>
  <div class="section">
    <div class="status-tabs" id="adminUsersTabs" role="group" aria-label="الدور">${tabs}</div>
    <div id="adminUsersList">${body}</div>
  </div>`;
}
function handleAdminUsersRole(role) { BackendUserDirectory.setRole(role, _rerenderIf('adminUsers')); render(); }
function handleAdminUsersMore() { BackendUserDirectory.moreUsers(_rerenderIf('adminUsers')); render(); }

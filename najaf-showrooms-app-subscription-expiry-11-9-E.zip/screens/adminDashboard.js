/* AdminDashboardScreen — الشاشة الرئيسية للوحة الإدارة. بطاقات إحصائية قابلة
   للضغط + قائمة تنقل لبقية شاشات الإدارة. القراءة فقط عبر adminService.
   إصلاح (الإحصائيات): معامل التنقل كان يُكتب JSON.stringify(param) أي "pending" بعلامتي اقتباس مزدوجتين داخل سمة
   onclick المحاطة بمزدوجتين، فتنقطع السمة (go('adminMemberCars',) وتنتهي بـ SyntaxError: Unexpected end of input
   بدل الانتقال (بطاقات قيد المراجعة/نشطة/مباعة/مرفوضة). الآن يمرّ المعامل عبر esc() كباقي الشاشات.
   «قيد المراجعة» (pending) لا ينتجها النشر الجديد أبدًا (النشر بعد المكافأة = active مباشرة)؛ تمثل اليوم سجلات قديمة
   أو سجلات أعادتها الإدارة للمراجعة (restoreMemberCar)، فالبطاقة تذكر ذلك صراحةً. */
/* (11.7-E) وضع الخادم: أقسام الإدارة المدعومة (أصحاب المعارض، مراجعة الإعلانات). (11.7.2-J) الإحصاءات من GET /v1/admin/stats
   (BackendUserDirectory) بالبطاقات والتسميات نفسها للوضع المحلي؛ تحميل/خطأ + إعادة المحاولة بلا أرقام محلية. وما لا مسار له يُذكر صراحةً. */
function _AdminStatsRemote() {
  const st = BackendUserDirectory.stats(_rerenderIf(currentRoute));
  if (st.status === 'loading') return '<div class="placeholder" role="status" aria-busy="true"><span class="ic" aria-hidden="true">⏳</span><b>جارٍ تحميل الإحصاءات…</b></div>';
  if (st.status !== 'ready') return `<div role="alert" class="form-error">${esc(st.error || BackendUserDirectory.messages.stats)} <button type="button" class="link-btn" onclick="BackendUserDirectory.retryStats(_rerenderIf(currentRoute));render()">إعادة المحاولة</button></div>`;
  const s = st.data;
  const card = (num, label, route, param, hint) =>
    `<div class="stat-card" role="button" tabindex="0" onclick="go('${route}'${param !== undefined ? `,${esc(JSON.stringify(param))}` : ''})"><div class="num">${esc(num)}</div><div class="lbl">${label}</div>${hint ? `<div class="lbl">${hint}</div>` : ''}</div>`;
  return `
    <div class="stats-grid">
      ${card(s.totalUsers, 'إجمالي المستخدمين', 'adminUsers')}
      ${card(s.totalShowrooms, 'إجمالي المعارض', 'adminShowrooms')}
      ${card(s.totalShowroomCars, 'سيارات المعارض', 'adminShowroomCars')}
      ${card(s.totalMemberCars, 'سيارات الأعضاء', 'adminMemberCars', 'all')}
      ${card(s.pendingMemberCars, 'قيد المراجعة', 'adminMemberCars', 'pending')}
      ${card(s.activeMemberCars, 'إعلانات نشطة', 'adminMemberCars', 'active')}
      ${card(s.soldMemberCars, 'إعلانات مباعة', 'adminMemberCars', 'sold')}
      ${card(s.rejectedMemberCars, 'إعلانات مرفوضة', 'adminMemberCars', 'rejected')}
    </div>`;
}
function _AdminDashboardRemote() {
  const badge = BackendAdmin.pendingBadge(_rerenderIf(currentRoute));
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1><p class="sub">مرحبًا ${esc((SessionService.getCurrentUser() || {}).name || '')}</p></div>
  <div class="section">
    <h2>📊 الإحصائيات</h2>
    ${_AdminStatsRemote()}
    <div class="admin-menu">
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminDealerRequests')">🏪 أصحاب المعارض (طلبات وحالة الحساب)${badge === null ? '' : ` <span class="badge-count">${esc(badge)}</span>`}</div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminMemberCars','pending')">🚗 مراجعة إعلانات الأعضاء (موافقة/رفض/إيقاف/استعادة)</div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminUsers')">👥 المستخدمون</div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminAssetIntegrity')">🧹 سلامة الصور والملفات (فحص يدوي وحذف بتأكيدك)</div>
    </div>
    <div class="placeholder" style="margin-top:14px"><span class="ic" aria-hidden="true">ℹ️</span>غير متاح بعد مع الخادم (لا مسار إداري له في الخلفية): قائمة المعارض، وسيارات المعارض.</div>
  </div>`;
}
function AdminDashboardScreen() {
  if (BackendAdmin.isEnabled()) return _AdminDashboardRemote();
  const s = getDashboardStats();
  const card = (num, label, route, param, hint) =>
    `<div class="stat-card" role="button" tabindex="0" onclick="go('${route}'${param !== undefined ? `,${esc(JSON.stringify(param))}` : ''})"><div class="num">${num}</div><div class="lbl">${label}</div>${hint ? `<div class="lbl">${hint}</div>` : ''}</div>`;
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1><p class="sub">مرحبًا ${(SessionService.getCurrentUser() || {}).name || ''}</p></div>
  <div class="section">
    <h2>📊 الإحصائيات</h2>
    <div class="stats-grid">
      ${card(s.totalUsers, 'إجمالي المستخدمين', 'adminUsers')}
      ${card(s.totalShowrooms, 'إجمالي المعارض', 'adminShowrooms')}
      ${card(s.totalShowroomCars, 'سيارات المعارض', 'adminShowroomCars')}
      ${card(s.totalMemberCars, 'سيارات الأعضاء', 'adminMemberCars', 'all')}
      ${card(s.pendingMemberCars, 'قيد المراجعة', 'adminMemberCars', 'pending', 'سجلات قديمة أو أعادتها الإدارة')}
      ${card(s.activeMemberCars, 'إعلانات نشطة', 'adminMemberCars', 'active')}
      ${card(s.soldMemberCars, 'إعلانات مباعة', 'adminMemberCars', 'sold')}
      ${card(s.rejectedMemberCars, 'إعلانات مرفوضة', 'adminMemberCars', 'rejected')}
    </div>
    <div class="admin-menu">
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminMemberCars','pending')">🚗 سجلات الأعضاء بانتظار قرار الإدارة <span class="badge-count">${s.pendingMemberCars}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminShowrooms')">🏢 المعارض <span class="badge-count">${s.totalShowrooms}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminShowroomCars')">🚘 سيارات المعارض <span class="badge-count">${s.totalShowroomCars}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminUsers')">👥 المستخدمون <span class="badge-count">${s.totalUsers}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminDealerRequests')">🏪 طلبات أصحاب المعارض <span class="badge-count">${s.pendingDealers}</span></div>
    </div>
  </div>`;
}

/* ==========================================================================
   (11.7.2-K) فحص سلامة الصور والملفات المخزَّنة — للمدير، وضع الخادم فقط (BackendAssetIntegrity). الشاشة هنا (لا ملف سكربت جديد: عدد
   سكربتات index.html ثابت 87). الفحص يدوي وللقراءة فقط: لا يُحذف شيء أثناءه. أربع فئات لا تختلط: «تالف» (الملف موجود لكنه لا يطابق السجل)،
   «مفقود» (السجل موجود والملف غير موجود)، «يتيم» (مخزَّن ولا أحد يستخدمه)، «تعذّر التحقق منه». الحذف: يحدّد المدير عناصر قابلة للحذف فقط
   (وصفها الخادم)، ثم يؤكّد صراحةً؛ والخادم يعيد فحص كل عنصر قبل حذفه ويحمي المرتبط بإعلان/غلاف، وما قيد الرفع أو المعالجة، وما لم يثبت أمانه.
   ========================================================================== */
const _AI_CAT = {
  corrupt: { icon: '🧩', title: 'تالف أو غير قابل للقراءة', hint: 'الملف موجود لكنه لا يطابق السجل (صورة غير صالحة، أو حجم/بصمة/أبعاد مختلفة).' },
  missing: { icon: '❓', title: 'مفقود', hint: 'السجل موجود لكن ملفًا واحدًا على الأقل غير موجود في التخزين.' },
  orphaned: { icon: '🗑️', title: 'يتيم (غير مستخدم)', hint: 'مخزَّن ولا أحد يستخدمه: ملف بلا سجل، أو صورة غير مرتبطة بأي إعلان أو غلاف.' },
  unverified: { icon: '⚠️', title: 'تعذّر التحقق منه', hint: 'مشكلة مؤقتة في التخزين منعت الفحص. لا يُحذف أبدًا؛ أعد الفحص لاحقًا.' },
};
const _AI_REASON = {
  invalid_image: 'الصورة غير صالحة', size_mismatch: 'الحجم لا يطابق السجل', hash_mismatch: 'البصمة لا تطابق السجل', dimension_mismatch: 'الأبعاد لا تطابق السجل',
  unreadable: 'لا يمكن قراءته', object_missing: 'ملف مفقود في التخزين', unlinked_record: 'سليم لكنه غير مرتبط بأي إعلان أو غلاف', no_record: 'ملف بلا سجل في قاعدة البيانات', unverifiable: 'تعذّر التحقق',
};
const _AI_PROTECT = {
  referenced: 'مستخدم في إعلان أو غلاف معرض — للعرض فقط ولا يُحذف',
  within_grace: 'أحدث من 24 ساعة (قد يكون رفعًا جاريًا)',
  unrecognized_key: 'مسار غير معتاد — لا يُحذف',
  unverified: 'لم يُتحقق منه — لا يُحذف',
  not_ready: 'قيد الرفع أو المعالجة',
  invalid_reference: 'مرجع غير صالح',
  changed: 'تغيّرت حالته أثناء التنفيذ — أعد الفحص',
};
const _AI_OUTCOME = { deleted: 'حُذف', protected: 'محمي ولم يُحذف', gone: 'لم يعد موجودًا', changed: 'تغيّر أثناء التنفيذ ولم يُحذف', failed: 'فشل', not_attempted: 'لم يُنفَّذ (توقّف التنفيذ)' };
const _AI_KIND = { car_image: 'صورة سيارة', showroom_cover: 'غلاف معرض' };
function _aiBytes(n) {
  if (!Number.isFinite(n) || n <= 0) return '0 بايت';
  if (n < 1024) return n + ' بايت';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' ك.ب';
  return (n / 1048576).toFixed(2) + ' م.ب';
}
function _aiTime(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function _aiItem(it, v) {
  const key = it.ref.type + ':' + it.ref.id;
  const box = it.deletable
    ? `<input type="checkbox" ${v.selected[key] ? 'checked' : ''} ${v.busy ? 'disabled' : ''} aria-label="تحديد للحذف" onchange="handleAssetIntegrityToggle('${esc(it.ref.type)}','${esc(it.ref.id)}')">`
    : '<span aria-hidden="true">🔒</span>';
  const size = it.sizeBytes === null ? 'الحجم غير متاح' : _aiBytes(it.sizeBytes);
  const status = it.deletable
    ? '<span class="sub">قابل للحذف بعد تأكيدك</span>'
    : `<span class="sub">${esc(_AI_PROTECT[it.protectedReason] || 'محمي')}</span>`;
  return `
    <div class="ad-row" data-ai-item="${esc(key)}">
      <div class="card-img">${box}</div>
      <div class="ad-info">
        <p class="card-title">${esc(it.ref.type === 'asset' ? 'سجل صورة' : 'ملف مخزَّن بلا سجل')} — ${esc(_AI_KIND[it.kind] || it.kind)}</p>
        <p class="card-row">${esc(_AI_REASON[it.reason] || it.reason)}</p>
        <p class="card-row">📦 ${esc(size)} — ⏱️ ${esc(it.ageHours)} ساعة</p>
        <p class="card-row">${it.referenced ? '🔗 مرتبط بإعلان أو غلاف' : '🔓 غير مرتبط'} — ${status}</p>
      </div>
    </div>`;
}
function _aiResult(r) {
  if (!r) return '';
  const s = r.summary;
  const rows = r.results.map(x => `<li>${esc(_AI_OUTCOME[x.outcome] || x.outcome)}${x.reason && x.outcome !== 'deleted' ? ` — ${esc(_AI_PROTECT[x.reason] || x.reason)}` : ''}${x.objectsRemaining ? ` — بقي ${esc(x.objectsRemaining)} ملف سيظهر يتيمًا في الفحص القادم` : ''}</li>`).join('');
  return `
    <div class="section" role="status" data-ai-result>
      <h2>نتيجة الحذف</h2>
      <p>حُذف ${esc(s.deleted)} من ${esc(s.requested)} — مساحة مُستعادة ${esc(_aiBytes(s.bytes))}${s.protected + s.gone + s.changed ? ` — محمي/غير موجود/متغيّر: ${esc(s.protected + s.gone + s.changed)}` : ''}${s.failed + s.notAttempted ? ` — فشل/لم يُنفَّذ: ${esc(s.failed + s.notAttempted)}` : ''}.</p>
      ${r.stopped ? '<div class="form-error" role="alert">توقّف التنفيذ بسبب مشكلة في الخادم؛ لم يُحذف شيء بلا إثبات. أعد الفحص قبل المتابعة.</div>' : ''}
      <ul>${rows}</ul>
      <p class="sub">سُجّلت العملية في سجل التدقيق. أعد الفحص للتحقق من الحالة الحالية.</p>
    </div>`;
}
function AdminAssetIntegrityScreen() {
  if (!BackendAssetIntegrity.isEnabled()) {
    return `${BackBar('adminDashboard')}
    <div class="topbar"><h1>🧹 سلامة الصور والملفات</h1></div>
    <div class="section"><div class="placeholder"><span class="ic" aria-hidden="true">ℹ️</span>هذه الأداة تعمل مع الخادم فقط (لا تخزين للصور في الوضع المحلي).</div></div>`;
  }
  const v = BackendAssetIntegrity.view();
  const head = `${BackBar('adminDashboard')}
    <div class="topbar"><h1>🧹 سلامة الصور والملفات</h1><p class="sub">فحص يدوي للقراءة فقط — لا يُحذف شيء أثناء الفحص.</p></div>`;
  const scanBtn = `<button type="button" class="btn-primary" ${v.busy ? 'disabled' : ''} onclick="handleAssetIntegrityScan()">${v.status === 'ready' ? 'إعادة الفحص' : 'ابدأ الفحص'}</button>`;
  if (v.status === 'idle') return `${head}<div class="section">${scanBtn}</div>`;
  if (v.status === 'loading') return `${head}<div class="section"><div class="placeholder" role="status" aria-busy="true"><span class="ic" aria-hidden="true">⏳</span><b>جارٍ فحص الصور والملفات… قد يستغرق ذلك دقيقة.</b></div></div>`;
  if (v.status === 'unavailable') return `${head}<div class="section">${EmptyState({ icon: '⛔', title: v.error, actions: [{ label: 'رجوع', onclick: "goBack('adminDashboard')", primary: false }] })}</div>`;
  if (v.status === 'error') return `${head}<div class="section"><div role="alert" class="form-error">${esc(v.error)}</div>${scanBtn}</div>`;
  const d = v.data, s = d.summary;
  const card = (n, label) => `<div class="stat-card"><div class="num">${esc(n)}</div><div class="lbl">${label}</div></div>`;
  const groups = ['corrupt', 'missing', 'orphaned', 'unverified'].map(cat => {
    const list = d.items.reduce((acc, it) => (it.category === cat ? acc.concat([it]) : acc), []);
    if (list.length === 0) return '';
    return `<div class="section" data-ai-cat="${cat}"><h2>${_AI_CAT[cat].icon} ${esc(_AI_CAT[cat].title)} (${esc(s[cat])})</h2><p class="sub">${esc(_AI_CAT[cat].hint)}</p><div class="list-grid">${list.map(it => _aiItem(it, v)).join('')}</div></div>`;
  }).join('');
  const nothing = d.items.length === 0 && d.complete && !d.error
    ? '<div class="placeholder"><span class="ic" aria-hidden="true">✅</span>لا توجد مشكلات في الجزء الذي شمله الفحص.</div>' : '';
  const warn = [
    d.error ? `<div class="form-error" role="alert">توقّف الفحص مبكرًا بسبب مشكلة في الخادم؛ النتائج جزئية.</div>` : '',
    (!d.complete && !d.error) ? '<div class="form-error" role="status">الفحص جزئي: بلغ حدّ الدفعة. ما لم يُفحص لا يُعدّ سليمًا.</div>' : '',
    d.truncated ? '<div class="form-error" role="status">وُجدت عناصر أكثر مما يُعرض؛ الأرقام أعلاه تشمل الجميع.</div>' : '',
    v.error ? `<div class="form-error" role="alert">${esc(v.error)}</div>` : '',
  ].join('');
  const moreBtn = d.nextAfter ? `<button type="button" class="btn-primary" ${v.busy ? 'disabled' : ''} onclick="handleAssetIntegrityMore()">${v.more ? 'جارٍ المتابعة…' : 'متابعة فحص المزيد من السجلات'}</button>` : '';
  const actions = s.deletable > 0 ? `
    <div class="section">
      <p>قابل للحذف: <b>${esc(s.deletable)}</b> — مساحة قابلة للاسترجاع (تقدير): <b>${esc(_aiBytes(s.recoverableBytes))}</b></p>
      <p class="sub">المحدَّد الآن: ${esc(v.selectedCount)} من ${esc(v.maxSelect)} كحدٍّ أقصى — ${esc(_aiBytes(v.selectedBytes))}</p>
      <button type="button" class="link-btn" ${v.busy ? 'disabled' : ''} onclick="handleAssetIntegritySelectAll()">تحديد كل القابل للحذف</button>
      <button type="button" class="link-btn" ${v.busy || v.selectedCount === 0 ? 'disabled' : ''} onclick="handleAssetIntegrityClear()">إلغاء التحديد</button>
      <button type="button" class="btn-primary" ${v.busy || v.selectedCount === 0 ? 'disabled' : ''} onclick="handleAssetIntegrityCleanup()">حذف المحدَّد (${esc(v.selectedCount)})</button>
    </div>` : '';
  return `${head}
  <div class="section">
    <p class="sub">وقت الفحص: <span dir="ltr">${esc(_aiTime(d.scannedAt))}</span> — سجلات مفحوصة: ${esc(s.scannedAssets)} — ملفات مفحوصة: ${esc(s.scannedObjects)} — مهلة الحماية ${esc(d.graceHours)} ساعة</p>
    <div class="stats-grid">
      ${card(s.corrupt, 'تالف')}${card(s.missing, 'مفقود')}${card(s.orphaned, 'يتيم')}${card(s.unverified, 'تعذّر التحقق')}
    </div>
    ${warn}${scanBtn} ${moreBtn}
  </div>
  ${actions}
  ${_aiResult(v.result)}
  ${nothing}${groups}`;
}
function handleAssetIntegrityScan() { BackendAssetIntegrity.start(_rerenderIf('adminAssetIntegrity')); render(); }
function handleAssetIntegrityMore() { BackendAssetIntegrity.more(_rerenderIf('adminAssetIntegrity')); render(); }
function handleAssetIntegrityToggle(type, id) { BackendAssetIntegrity.toggle(type, id, _rerenderIf('adminAssetIntegrity')); }
function handleAssetIntegritySelectAll() { BackendAssetIntegrity.selectAll(_rerenderIf('adminAssetIntegrity')); }
function handleAssetIntegrityClear() { BackendAssetIntegrity.clearSelection(_rerenderIf('adminAssetIntegrity')); }
/** الحذف لا يبدأ إلا من هنا وبعد تأكيد صريح من المدير بعدد العناصر والمساحة. */
function handleAssetIntegrityCleanup() {
  const v = BackendAssetIntegrity.view();
  if (v.busy || v.selectedCount === 0) return;
  askConfirm({
    title: 'حذف الصور والملفات المحدَّدة',
    message: `سيُحذف ${v.selectedCount} عنصرًا نهائيًا (مساحة تقديرية ${_aiBytes(v.selectedBytes)}). لا يمكن التراجع. سيعيد الخادم فحص كل عنصر قبل حذفه، ويحمي أي عنصر صار مستخدمًا أو قيد المعالجة أو لم يثبت أمانه.`,
    confirmLabel: 'حذف نهائي', danger: true,
  }, () => { BackendAssetIntegrity.cleanup(_rerenderIf('adminAssetIntegrity')); render(); });
}

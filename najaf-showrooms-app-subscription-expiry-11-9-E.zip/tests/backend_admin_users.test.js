/* Phase 11.7.2-J — قائمة المستخدمين وتفاصيل الحساب وإحصاءات لوحة الإدارة عبر الخادم داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الجديد فقط (backend/src/admin-users/routes.ts): GET /v1/admin/users?role&after&limit، GET /v1/admin/users/:id،
   GET /v1/admin/stats؛ 404 لغير المدير؛ وحقول سرية زائدة في الرد لإثبات أنها لا تصل إلى الواجهة. لا خادم ولا قاعدة بيانات حقيقية. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const root = path.join(__dirname, '..');
const iso = '2026-01-01T00:00:00.000Z';
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const STATS = { totalUsers: 41, totalShowrooms: 7, totalShowroomCars: 63, totalMemberCars: 29, pendingMemberCars: 3, activeMemberCars: 17, soldMemberCars: 5, rejectedMemberCars: 2, suspendedMemberCars: 2, pendingDealers: 4 };

function adminUsersWorld(role) {
  const w = world();
  const d = { role: role || 'admin', seq: 300, users: [], details: {}, stats: Object.assign({}, STATS), fail: null, gate: null, leak: true };
  d.user = o => { const u = Object.assign({ id: String(++d.seq), name: 'حساب ' + d.seq, phone: '+9647801' + String(d.seq).padStart(6, '0'), email: null, role: 'user', status: 'active', createdAt: iso }, o); d.users.push(u); return u; };
  const leak = o => (d.leak ? Object.assign({ passwordHash: '$argon2id$SECRET', failedLogins: 2, lockedUntil: null, refreshToken: 'RT-SECRET' }, o) : o);
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    if (!u.pathname.startsWith('/v1/admin/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, rawBody: init.body };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (d.role !== 'admin') return err(404, 'not_found');
    if (call.method !== 'GET') return err(404, 'not_found');
    if (u.pathname === '/v1/admin/dealers') return json(200, { dealers: [], nextAfter: null });
    if (u.pathname === '/v1/admin/stats') return json(200, { stats: Object.assign({ secretSum: 999 }, d.stats) });
    if (u.pathname === '/v1/admin/users') {
      const q = call.query, bad = Object.keys(q).filter(k => !['role', 'after', 'limit'].includes(k)).map(f => ({ field: f, code: 'unknown_field' }));
      if (q.role !== undefined && !['user', 'dealer', 'admin'].includes(q.role)) bad.push({ field: 'role', code: 'invalid_format' });
      const limit = q.limit === undefined ? 50 : Number(q.limit); if (!(limit >= 1 && limit <= 100)) bad.push({ field: 'limit', code: 'invalid_format' });
      if (bad.length) return err(400, 'validation_failed', bad);
      let rows = d.users.filter(x => q.role === undefined || x.role === q.role).sort((a, b) => Number(a.id) - Number(b.id));
      if (q.after) rows = rows.filter(x => Number(x.id) > Number(q.after));
      const page = rows.slice(0, limit);
      return json(200, { users: page.map(x => leak(Object.assign({}, x))), nextAfter: page.length === limit ? page[page.length - 1].id : null });
    }
    const m = /^\/v1\/admin\/users\/([^/]+)$/.exec(u.pathname);
    if (m) {
      const x = d.users.find(y => y.id === m[1]); if (!x) return err(404, 'not_found');
      const extra = d.details[x.id] || { showroom: null, memberCars: [], memberCarsTotal: 0 };
      return json(200, Object.assign({ user: leak(Object.assign({}, x)) }, JSON.parse(JSON.stringify(extra))));
    }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  return {
    env, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: (re) => w.srv.calls.filter(c => re.test(c.path)),
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p, route, param) { await p.login(); p.run(param === undefined ? `go('${route}')` : `go('${route}', '${param}')`); await settle(); }
const USERS = /^\/v1\/admin\/users$/, ONE = /^\/v1\/admin\/users\/[^/]+$/, STATS_RE = /^\/v1\/admin\/stats$/;
const cards = h => [...h.matchAll(/<div class="stat-card"[^>]*onclick="([^"]*)"><div class="num">([^<]*)<\/div><div class="lbl">([^<]*)<\/div>/g)].map(m => ({ onclick: m[1], num: m[2], label: m[3] }));
const SECRET = /argon2|SECRET|passwordHash|failedLogins|lockedUntil|refreshToken|secretSum/;

test('لوحة الإدارة: الإحصاءات من GET /v1/admin/stats (مرة واحدة، بالرمز) بالبطاقات والتسميات المحلية نفسها، والأرقام من الخادم لا من البيانات المحلية', async () => {
  const { w } = adminUsersWorld(); const p = page(w); await open(p, 'adminHome');
  const st = p.calls(STATS_RE); assert.equal(st.length, 1); assert.equal(st[0].method, 'GET'); assert.match(st[0].headers.authorization, /^Bearer AT-/); assert.deepEqual(st[0].query, {});
  const cs = cards(p.screen());
  assert.deepEqual(cs.map(c => [c.label, c.num]), [['إجمالي المستخدمين', '41'], ['إجمالي المعارض', '7'], ['سيارات المعارض', '63'], ['سيارات الأعضاء', '29'], ['قيد المراجعة', '3'], ['إعلانات نشطة', '17'], ['إعلانات مباعة', '5'], ['إعلانات مرفوضة', '2']]);
  assert.match(p.screen(), /go\('adminUsers'\)">👥 المستخدمون/); assert.match(p.screen(), /غير متاح بعد مع الخادم/); assert.match(p.screen(), /قائمة المعارض، وسيارات المعارض/);
  assert.ok(!SECRET.test(p.screen()) && !SECRET.test(JSON.stringify(p.run('BackendUserDirectory.stats()'))), 'حقل زائد في الرد لا يصل');
  p.run(cs[0].onclick.replace(/&quot;/g, '"')); await settle(); assert.equal(p.route(), 'adminUsers');
  p.run("go('adminHome')"); await settle(); p.run(cs[4].onclick.replace(/&quot;/g, '"')); await settle(); assert.equal(p.route(), 'adminMemberCars');
  assert.deepEqual(p.env.errors, []);
});

test('الإحصاءات: تحميل ثم فشل الخادم = رسالة عربية + إعادة المحاولة بلا أي بطاقة أو رقم؛ رد غير صالح يُرفض؛ ثم نجاح الإعادة', async () => {
  const { w, d } = adminUsersWorld();
  let release; d.gate = c => (STATS_RE.test(c.path) && !release ? new Promise(r => { release = r; }) : null);
  const p = page(w); await open(p, 'adminHome');
  assert.match(p.screen(), /جارٍ تحميل الإحصاءات/); assert.ok(!/stat-card/.test(p.screen()));
  d.fail = c => (STATS_RE.test(c.path) ? err(500, 'internal') : null); release(); await settle();
  assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!/stat-card|إجمالي المستخدمين/.test(p.screen()));
  d.fail = c => (STATS_RE.test(c.path) ? json(200, { stats: Object.assign({}, STATS, { totalUsers: -1 }) }) : null);
  p.run('BackendUserDirectory.retryStats(_rerenderIf(currentRoute));render()'); await settle();
  assert.ok(!/stat-card/.test(p.screen())); assert.match(p.screen(), /إعادة المحاولة/);
  d.fail = null; p.run('BackendUserDirectory.retryStats(_rerenderIf(currentRoute));render()'); await settle();
  assert.equal(cards(p.screen()).length, 8); assert.equal(p.calls(STATS_RE).length, 3);
});

test('غير المدير: لا شاشات إدارية بالتنقل المباشر ولا أي طلب /v1/admin/users|stats؛ والخادم يرد 404 على المسارات للجسر نفسه بلا بيانات', async () => {
  for (const role of ['user', 'dealer']) {
    const { w } = adminUsersWorld(role); const p = page(w); await p.login();
    for (const [r, prm] of [['adminHome'], ['adminUsers'], ['adminUserDetails', '301']]) { p.run(prm ? `go('${r}', '${prm}')` : `go('${r}')`); await settle(); assert.notEqual(p.route(), r, role + ' ' + r); }
    assert.equal(p.calls(/^\/v1\/admin\/(users|stats)/).length, 0, role);
    p.run('BackendUserDirectory.stats(() => {})'); await settle();
    const st = p.run('BackendUserDirectory.stats()'); assert.equal(st.status, 'error'); assert.equal(st.data, null);
  }
});

test('المستخدمون: «الكل» بلا role ثم تبويبات الدور تطلب role مرة لكل تبويب؛ الصفوف بالاسم والهاتف والدور والحالة؛ لا حقل سري في الصفحة ولا في الحالة', async () => {
  const { w, d } = adminUsersWorld();
  d.user({ name: 'مدير المنصة', role: 'admin' }); d.user({ name: 'حيدر', role: 'dealer', status: 'pending' }); d.user({ name: 'علي' });
  const p = page(w); await open(p, 'adminUsers');
  const c = p.calls(USERS); assert.equal(c.length, 1); assert.deepEqual(c[0].query, { limit: '50' }); assert.match(c[0].headers.authorization, /^Bearer AT-/);
  const h = p.screen();
  assert.match(h, /مدير المنصة/); assert.match(h, /حيدر/); assert.match(h, /صاحب معرض — بانتظار موافقة الإدارة/); assert.match(h, /\+9647801000302/);
  assert.match(h, /go\('adminUserDetails', '302'\)/);
  assert.ok(!SECRET.test(h)); assert.ok(!SECRET.test(JSON.stringify(p.run('BackendUserDirectory.users()'))));
  p.run("handleAdminUsersRole('dealer')"); await settle();
  assert.deepEqual(p.calls(USERS)[1].query, { limit: '50', role: 'dealer' }); assert.match(p.screen(), /حيدر/); assert.ok(!/علي|مدير المنصة/.test(p.screen()));
  p.run("handleAdminUsersRole('dealer')"); p.run("handleAdminUsersRole('all')"); await settle();
  assert.equal(p.calls(USERS).length, 2, 'التبويب المحمَّل لا يُعاد طلبه');
  p.run("handleAdminUsersRole('admin')"); await settle(); assert.deepEqual(p.calls(USERS)[2].query, { limit: '50', role: 'admin' });
  p.run("handleAdminUsersRole('user')"); await settle(); assert.match(p.screen(), /علي/);
  assert.deepEqual(p.env.errors, []);
});

test('ترقيم الصفحات: «عرض المزيد» يرسل after=nextAfter ويُلحق الصفحة التالية؛ يختفي في الصفحة الأخيرة', async () => {
  const { w, d } = adminUsersWorld(); for (let i = 0; i < 53; i++) d.user({});
  const p = page(w); await open(p, 'adminUsers');
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 50); assert.match(p.screen(), /عرض المزيد/);
  p.run('handleAdminUsersMore()'); await settle();
  const c = p.calls(USERS); assert.equal(c.length, 2); assert.deepEqual(c[1].query, { limit: '50', after: '350' });
  assert.equal((p.screen().match(/class="ad-row"/g) || []).length, 53); assert.ok(!/عرض المزيد/.test(p.screen()));
});

test('المستخدمون: فارغ = «لا يوجد مستخدمون.»؛ فشل = رسالة + إعادة المحاولة بلا بيانات محلية؛ رد يخالف الدور المطلوب يُرفض', async () => {
  { const { w } = adminUsersWorld(); const p = page(w); await open(p, 'adminUsers'); assert.match(p.screen(), /لا يوجد مستخدمون/); }
  { const { w, d } = adminUsersWorld(); d.user({ name: 'زينب' }); d.fail = c => (USERS.test(c.path) ? err(500, 'internal') : null);
    const p = page(w); await open(p, 'adminUsers'); assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!/زينب|حيدر عبد الكاظم|مدير المنصة/.test(p.screen()));
    d.fail = null; p.run("BackendUserDirectory.retryUsers(_rerenderIf('adminUsers'));render()"); await settle(); assert.match(p.screen(), /زينب/); }
  { const { w, d } = adminUsersWorld(); d.user({ name: 'مندس', role: 'user' });
    d.fail = c => (USERS.test(c.path) && c.query.role === 'dealer' ? json(200, { users: [Object.assign({}, d.users[0])], nextAfter: null }) : null);
    const p = page(w); await open(p, 'adminUsers'); p.run("handleAdminUsersRole('dealer')"); await settle(); assert.ok(!/مندس/.test(p.screen())); assert.match(p.screen(), /إعادة المحاولة/); }
});

test('تفاصيل الحساب: الحقول (الاسم، الهاتف، البريد، الدور والحالة، التاريخ)، ومعرض صاحب المعرض، وإعلاناته بحالتها، وملاحظة عند تجاوز 100؛ بلا أسرار', async () => {
  const { w, d } = adminUsersWorld();
  const dl = d.user({ name: 'حيدر', role: 'dealer', email: 'h@example.com' });
  d.details[dl.id] = { showroom: { id: '901', name: 'معرض الكوفة', status: 'pending' }, memberCars: [{ id: '77', brand: 'Toyota', model: 'Camry', status: 'rejected' }], memberCarsTotal: 120 };
  const p = page(w); await open(p, 'adminUserDetails', dl.id);
  const c = p.calls(ONE); assert.equal(c.length, 1); assert.equal(c[0].path, `/v1/admin/users/${dl.id}`);
  const h = p.screen();
  assert.match(h, /👤 حيدر/); assert.match(h, /h@example\.com/); assert.match(h, /صاحب معرض — فعّال/); assert.match(h, /تاريخ إنشاء الحساب/);
  assert.match(h, /معارضه/); assert.match(h, /معرض الكوفة/); assert.match(h, /Toyota Camry/); assert.match(h, /يُعرض أحدث 1 من 120/);
  assert.ok(!SECRET.test(h)); assert.ok(!SECRET.test(JSON.stringify(p.run(`BackendUserDirectory.user('${dl.id}')`))));
  const adm = d.user({ name: 'مدير آخر', role: 'admin' }); p.run(`go('adminUserDetails', '${adm.id}')`); await settle();
  assert.match(p.screen(), /مدير آخر/); assert.ok(!/معارضه|إعلانات سيارات الأعضاء/.test(p.screen()));
  const m = d.user({ name: 'عضو' }); p.run(`go('adminUserDetails', '${m.id}')`); await settle();
  assert.match(p.screen(), /لا توجد إعلانات/); assert.ok(!/معارضه/.test(p.screen()));
  assert.deepEqual(p.env.errors, []);
});

test('تفاصيل الحساب: غير موجود (404) = «المستخدم غير موجود»؛ فشل = رسالة + إعادة المحاولة؛ معرّف غير صالح لا يرسل طلبًا', async () => {
  const { w, d } = adminUsersWorld(); const p = page(w); await open(p, 'adminUserDetails', '999');
  assert.match(p.screen(), /المستخدم غير موجود/);
  const u = d.user({ name: 'سجاد' }); d.fail = c => (ONE.test(c.path) ? err(503, 'unavailable') : null);
  p.run(`go('adminUserDetails', '${u.id}')`); await settle(); assert.match(p.screen(), /إعادة المحاولة/); assert.ok(!/سجاد/.test(p.screen()));
  d.fail = null; p.run("BackendUserDirectory.retryUser(currentParam, _rerenderIf('adminUserDetails'));render()"); await settle(); assert.match(p.screen(), /سجاد/);
  const n = p.calls(ONE).length; p.run("BackendUserDirectory.user('1;DROP')"); await settle(); assert.equal(p.calls(ONE).length, n);
});

test('الرجوع: في وضع الخادم تُعاد adminUserDetails من السجل (لا تُتخطّى)؛ معرّف غير صالح يُتخطّى؛ والرجوع من التفاصيل إلى القائمة', async () => {
  const { w, d } = adminUsersWorld(); const u = d.user({ name: 'سجاد' });
  const p = page(w); await open(p, 'adminUsers');
  p.run(`go('adminUserDetails', '${u.id}')`); await settle();
  assert.equal(p.route(), 'adminUserDetails');
  p.run("goBack('adminUsers')"); await settle(); assert.equal(p.route(), 'adminUsers');
  p.run(`go('adminUserDetails', '${u.id}')`); await settle();
  p.run("go('adminDashboard')"); await settle();
  p.run("goBack('adminUsers')"); await settle();
  assert.equal(p.route(), 'adminUserDetails'); assert.match(p.screen(), /سجاد/);
  p.run("_navStack.push({ route: 'adminUserDetails', param: '1;DROP' })");
  p.run("goBack('adminUsers')"); await settle();
  assert.notEqual(p.run('currentParam'), '1;DROP');
  assert.deepEqual(p.env.errors, []);
});

test('تبديل المستخدم: الخروج يُسقط الحالة فلا تتسرب قائمة/إحصاءات مدير سابق', async () => {
  const { w, d } = adminUsersWorld(); d.user({ name: 'رقية' }); const p = page(w); await open(p, 'adminUsers');
  assert.match(p.screen(), /رقية/);
  p.run('handleLogout()'); await settle();
  assert.equal(p.run('BackendUserDirectory.users().items.length'), 0); assert.equal(p.run('BackendUserDirectory.stats().data'), null);
});

test('حارس المصدر: الجسر قراءة فقط (GET) إلى /v1/admin/users و/v1/admin/stats فقط، بلا تخزين/console/fetch/رموز؛ الوضع المحلي باقٍ؛ 87 سكربتًا', () => {
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendUserDirectory'), b = all.indexOf('/* ==========================================================================\n   BACKEND MODERATION');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|\beval\(|new Function|Repository|AppStorage|innerHTML/.test(src));
  assert.deepEqual([...new Set([...src.matchAll(/'(\/v1\/[^']*)'/g)].map(m => m[1].replace(/\/$/, '')))].sort(), ['/v1/admin/stats', '/v1/admin/users']);
  assert.ok(!/api\.(post|put|patch|delete)\(/.test(src), 'لا كتابة');
  assert.ok(!/Authorization|accessToken|refreshToken|passwordHash/.test(src));
  const rd = f => fs.readFileSync(path.join(root, f), 'utf8');
  assert.match(rd('screens/adminUsers.js'), /let list = adminGetAllUsers\(\);[\s\S]*if \(BackendUserDirectory\.isEnabled\(\)\) return _AdminUsersRemote\(\);[^\n]*\n  return `/);
  assert.match(rd('screens/adminUserDetails.js'), /if \(BackendUserDirectory\.isEnabled\(\)\) return _AdminUserDetailsRemote\(id\);[^\n]*\n  const u = UserService\.getPublicById\(id\);/);
  assert.match(rd('screens/adminDashboard.js'), /if \(BackendAdmin\.isEnabled\(\)\) return _AdminDashboardRemote\(\);\n  const s = getDashboardStats\(\);/);
  assert.ok(!/suspend|activate|approve|reject/i.test(rd('screens/adminUsers.js').slice(rd('screens/adminUsers.js').indexOf('_AdminUsersRemote'))), 'لا إجراء على الحساب في وضع الخادم');
  assert.equal((rd('index.html').match(/<script src=/g) || []).length, 87);
});

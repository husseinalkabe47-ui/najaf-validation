// صاحب معرض معلّق (pending) لا يفتح نموذج نشر السيارة الشخصية ولا ينشر؛ بقية الأدوار كما كانت.
// الخادم يرفضه أصلًا (POST /v1/me/cars = 403 لحساب غير نشط)؛ هذا يطابق الواجهة معه.
const { makeEnv } = require('./harness');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra || ''); } };
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], pending: ['07733445566', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  if (role) { const c = CRED[role]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); }
  return { E, R };
}
const BODY = `{brand:'Kia',model:'Pend',year:2020,price:1000,phone:'07733445566'}`;

const p = mk('pending');
t('1) الجلسة فعلًا لتاجر معلّق', p.R(`SessionService.getCurrentUser().role`) === 'dealer' && p.R(`SessionService.getCurrentUser().status`) === 'pending');
t('2) canCreateMemberCar = false لصاحب المعرض المعلّق', p.R('AuthorizationService.canCreateMemberCar()') === false);
p.R(`go('addMemberCar')`);
t('3) فتح نموذج النشر → «غير مصرّح» (لا نموذج)', p.R('currentRoute') === 'accessDenied' && !p.E.screen().includes('addMemberCarBtn'));
const before = p.R('MEMBER_CARS.length');
const d = p.R(`createDraftMemberCar(${BODY})`);
t('4) إنشاء مسودة نشر مرفوض ولا يُضاف شيء', d && d.ok === false && p.R('MEMBER_CARS.length') === before);
p.R(`go('account')`);
t('5) شاشة حسابي لا تعرض زر «إضافة سيارة» له (وتبقى بقية الأزرار)', !p.E.screen().includes(`go('addMemberCar')`) && p.E.screen().includes(`go('myMemberCars')`));

for (const role of ['user', 'dealer1', 'admin']) {
  const x = mk(role);
  x.R(`go('addMemberCar')`);
  t(`6-${role}) ${role}: يبقى قادرًا على فتح نموذج النشر`, x.R('AuthorizationService.canCreateMemberCar()') === true && x.R('currentRoute') === 'addMemberCar');
  x.R(`go('account')`);
  t(`7-${role}) ${role}: زر «إضافة سيارة» ظاهر`, x.E.screen().includes(`go('addMemberCar')`));
}

const g = mk(null);
g.R(`go('addMemberCar')`);
t('8) الزائر: تحويل إلى تسجيل الدخول (لم يتغير)', g.R('currentRoute') === 'login' && g.R('AuthorizationService.canCreateMemberCar()') === false);

const s = mk('user');
s.R(`UserService._findById(${s.R('UserService._findByIdentifier("07700000001").id')}).status='suspended'`);
t('9) المستخدم الموقوف: لا يستطيع (القاعدة القائمة)', s.R('AuthorizationService.canCreateMemberCar()') === false);

const a = mk('user');
a.R(`UserService._findByIdentifier("07700000001").status='pending'`);
t('10) الحالة المعلّقة وحدها كافية للمنع (لا يعتمد على الدور)', a.R('AuthorizationService.canCreateMemberCar()') === false);

t('11) لا أخطاء JavaScript', [p, g, s, a].every(x => x.E.errors.length === 0), [p, g, s, a].map(x => x.E.errors.join('|')).join(' ; '));
console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
process.exit(fail ? 1 : 0);

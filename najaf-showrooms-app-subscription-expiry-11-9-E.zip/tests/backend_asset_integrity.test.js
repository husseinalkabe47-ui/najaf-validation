/* Phase 11.7.2-K — فحص سلامة الصور والملفات المخزَّنة وحذفها بتأكيد المدير، داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الجديد فقط (backend/src/assets/integrity-routes.ts): GET /v1/admin/asset-integrity/scan، POST .../cleanup؛ 404 لغير
   المدير. لا خادم ولا قاعدة بيانات ولا تخزين حقيقي: القرار الأمني الفعلي (إعادة الفحص قبل الحذف) في اختبارات الخلفية؛ هنا نثبت أن الواجهة
   لا تحذف شيئًا أثناء الفحص، ولا ترسل إلا ما حدّده المدير مما وصفه الخادم «قابلًا للحذف» وبعد تأكيد صريح، وتعرض الفئات الأربع منفصلة. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const root = path.join(__dirname, '..');
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const U = n => `d0000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const REF = (n, area = 'processed', kind = 'car_image') => `${area}.${kind}.${U(n)}`;
const SCAN = /^\/v1\/admin\/asset-integrity\/scan$/, CLEAN = /^\/v1\/admin\/asset-integrity\/cleanup$/, ANY = /^\/v1\/admin\/asset-integrity\//;
const item = o => Object.assign({ ref: { type: 'asset', id: U(1) }, category: 'orphaned', reason: 'unlinked_record', kind: 'car_image', hasRecord: true, referenced: false, sizeBytes: 2048, ageHours: 100, deletable: true, protectedReason: null }, o);
const key = it => it.ref.type + ':' + it.ref.id;

function defaultItems() {
  return [
    item({ ref: { type: 'asset', id: U(2) }, category: 'corrupt', reason: 'invalid_image', referenced: true, deletable: false, protectedReason: 'referenced', sizeBytes: 4096 }),
    item({ ref: { type: 'asset', id: U(3) }, category: 'missing', reason: 'object_missing', referenced: true, deletable: false, protectedReason: 'referenced', sizeBytes: 1024 }),
    item({ ref: { type: 'asset', id: U(4) }, category: 'orphaned', reason: 'unlinked_record', sizeBytes: 3072 }),
    item({ ref: { type: 'asset', id: U(5) }, category: 'corrupt', reason: 'hash_mismatch', sizeBytes: 5120 }),
    item({ ref: { type: 'asset', id: U(6) }, category: 'orphaned', reason: 'unlinked_record', deletable: false, protectedReason: 'within_grace', ageHours: 5 }),
    item({ ref: { type: 'object', id: REF(77) }, category: 'orphaned', reason: 'no_record', hasRecord: false, sizeBytes: 1048576 }),
    item({ ref: { type: 'asset', id: U(8) }, category: 'unverified', reason: 'unverifiable', deletable: false, protectedReason: 'unverified', sizeBytes: null }),
  ];
}

function integrityWorld(role) {
  const w = world();
  const d = { role: role || 'admin', items: defaultItems(), nextAfter: null, more: null, complete: true, error: null, truncated: false, fail: null, gate: null, outcome: {}, cleanupBody: null, now: '2026-10-10T09:30:00.000Z' };
  const summaryOf = items => {
    const s = { scannedAssets: 120, scannedObjects: 340, corrupt: 0, missing: 0, orphaned: 0, unverified: 0, referencedProblems: items.filter(x => x.referenced).length, deletable: 0, protected: 0, recoverableBytes: 0 };
    items.forEach(x => { s[x.category]++; if (x.deletable) { s.deletable++; s.recoverableBytes += x.sizeBytes || 0; } else s.protected++; });
    return s;
  };
  const scanBody = (items, scope, nextAfter) => ({ scannedAt: d.now, scope, graceHours: 24, complete: d.complete, nextAfter, error: d.error, summary: summaryOf(items), items: JSON.parse(JSON.stringify(items)), truncated: d.truncated });
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (u.pathname === '/v1/auth/login') { const r = await base(url, init); const b = await r.json(); b.user.role = d.role; return json(r.status, b); }
    if (!u.pathname.startsWith('/v1/admin/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), method: init.method, headers: h, rawBody: init.body };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    const t = /^Bearer (.+)$/.exec(h.authorization || ''); const rec = t && w.srv.access.get(t[1]);
    if (!rec || rec.exp <= w.clock.t || rec.fam.revoked) return err(401, 'unauthorized');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    if (d.role !== 'admin') return err(404, 'not_found');
    if (SCAN.test(u.pathname)) {
      if (call.method !== 'GET') return err(404, 'not_found');
      if (call.query.after && d.more) return json(200, scanBody(d.more, 'assets', null));
      return json(200, scanBody(d.items, call.query.scope || 'all', d.nextAfter));
    }
    if (CLEAN.test(u.pathname)) {
      if (call.method !== 'POST') return err(404, 'not_found');
      const b = JSON.parse(call.rawBody); d.cleanupBody = b;
      if (b.confirm !== true || !Array.isArray(b.items) || b.items.length < 1 || b.items.length > 50) return err(400, 'validation_failed', [{ field: 'items', code: 'invalid_format' }]);
      const results = b.items.map(i => {
        const it = d.items.find(x => key(x) === i.type + ':' + i.id);
        const o = d.outcome[i.type + ':' + i.id] || { outcome: 'deleted', reason: null, bytes: it ? it.sizeBytes || 0 : 0 };
        return { ref: { type: i.type, id: i.id }, outcome: o.outcome, reason: o.reason || null, bytes: o.outcome === 'deleted' ? o.bytes : 0, objectsRemaining: o.objectsRemaining || 0 };
      });
      const n = k => results.filter(r => r.outcome === k).length;
      return json(200, { finishedAt: d.now, stopped: null, summary: { requested: results.length, deleted: n('deleted'), protected: n('protected'), gone: n('gone'), changed: n('changed'), failed: n('failed'), notAttempted: n('not_attempted'), bytes: results.reduce((a, r) => a + r.bytes, 0) }, results });
    }
    return err(404, 'not_found');
  };
  return { w, d };
}

function page(w) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  return {
    env, run: c => env.run(c), screen: () => env.screen(), route: () => env.run('currentRoute'),
    calls: re => w.srv.calls.filter(c => re.test(c.path)),
    login: () => env.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')"),
  };
}
const settle = async () => { for (let i = 0; i < 40; i++) await tick(); };
async function open(p) { await p.login(); p.run("go('adminAssetIntegrity')"); await settle(); }
async function scanned(p) { await open(p); p.run('handleAssetIntegrityScan()'); await settle(); }
const view = p => p.run('BackendAssetIntegrity.view()');
/* التأكيد: يلتقط المواصفة ولا ينفّذ إلا عند استدعاء yes() صراحةً */
function holdConfirm(p) { p.run("window.__ask = null; askConfirm = (spec, yes, no) => { window.__ask = { spec, yes, no }; }"); }

test('الشاشة تفتح بلا أي طلب: الفحص يدوي فقط (لا فحص تلقائي ولا حذف)', async () => {
  const { w } = integrityWorld(); const p = page(w); await open(p);
  assert.equal(p.route(), 'adminAssetIntegrity');
  assert.match(p.screen(), /ابدأ الفحص/); assert.match(p.screen(), /للقراءة فقط/);
  assert.equal(p.calls(ANY).length, 0);
  assert.ok(!/type="checkbox"/.test(p.screen()));
  assert.deepEqual(p.env.errors, []);
});

test('الفحص: طلب GET واحد بالرمز (scope=all) ولا يرسل شيئًا آخر؛ أربع فئات منفصلة بأعدادها، ووقت الفحص، والمساحة التقديرية قبل الحذف', async () => {
  const { w, d } = integrityWorld(); const p = page(w); await scanned(p);
  const c = p.calls(ANY); assert.equal(c.length, 1); assert.equal(c[0].method, 'GET'); assert.equal(c[0].query.scope, 'all');
  assert.match(c[0].headers.authorization, /^Bearer /);
  const h = p.screen();
  for (const t of ['تالف أو غير قابل للقراءة (2)', 'مفقود (1)', 'يتيم (غير مستخدم) (3)', 'تعذّر التحقق منه (1)']) assert.ok(h.includes(t), t);
  const cat = n => (new RegExp(`data-ai-cat="${n}"[\\s\\S]*?(?=data-ai-cat=|$)`).exec(h) || [''])[0];
  assert.match(cat('corrupt'), /الصورة غير صالحة|البصمة لا تطابق السجل/); assert.ok(!/ملف مفقود في التخزين/.test(cat('corrupt')), 'التالف لا يختلط بالمفقود');
  assert.match(cat('missing'), /ملف مفقود في التخزين/); assert.ok(!/البصمة|الصورة غير صالحة/.test(cat('missing')));
  assert.match(cat('orphaned'), /ملف بلا سجل في قاعدة البيانات/); assert.match(cat('orphaned'), /سليم لكنه غير مرتبط/);
  assert.match(cat('unverified'), /لم يُتحقق منه/);
  assert.match(h, /وقت الفحص: <span dir="ltr">2026-10-10 \d\d:\d\d<\/span>/);
  const rec = d.items.filter(x => x.deletable).reduce((a, x) => a + x.sizeBytes, 0);   // 3072 + 5120 + 1048576
  assert.equal(rec, 1056768); assert.match(h, /مساحة قابلة للاسترجاع \(تقدير\): <b>1\.01 م\.ب<\/b>/);
  assert.match(h, /قابل للحذف: <b>3<\/b>/);
  assert.match(h, /3\.0 ك\.ب/); assert.match(h, /الحجم غير متاح/); assert.match(h, /مهلة الحماية 24 ساعة/);
  assert.equal(p.calls(CLEAN).length, 0, 'لا حذف أثناء الفحص');
  assert.ok(!/passwordHash|storageKey|incoming\/|processed\/|thumbs\//.test(h));
  assert.deepEqual(p.env.errors, []);
});

test('الحماية ظاهرة: المرتبط بإعلان/غلاف والأحدث من 24 ساعة وغير المتحقَّق منه بلا خانة اختيار وبسبب مقروء؛ والقابل للحذف فقط بخانة', async () => {
  const { w } = integrityWorld(); const p = page(w); await scanned(p);
  const h = p.screen(); const row = id => (new RegExp(`data-ai-item="${id}"[\\s\\S]*?(?=data-ai-item=|<\\/div>\\s*<\\/div>\\s*<div class="section"|$)`).exec(h) || [''])[0];
  assert.match(row('asset:' + U(2)), /🔒/); assert.match(row('asset:' + U(2)), /للعرض فقط ولا يُحذف/); assert.ok(!/checkbox/.test(row('asset:' + U(2))));
  assert.match(row('asset:' + U(6)), /أحدث من 24 ساعة/); assert.ok(!/checkbox/.test(row('asset:' + U(6))));
  assert.match(row('asset:' + U(8)), /لم يُتحقق منه — لا يُحذف/);
  for (const k of ['asset:' + U(4), 'asset:' + U(5), 'object:' + REF(77)]) assert.match(row(k), /type="checkbox"/, k);
  assert.equal((h.match(/type="checkbox"/g) || []).length, 3);
});

test('الاختيار: القابل للحذف فقط؛ المحمي لا يُحدَّد حتى بالاستدعاء المباشر؛ «تحديد الكل» يختار القابل للحذف فقط؛ العدّاد والمساحة المحدَّدة', async () => {
  const { w } = integrityWorld(); const p = page(w); await scanned(p);
  assert.equal(p.run(`BackendAssetIntegrity.toggle('asset', '${U(2)}')`), false, 'مرتبط بإعلان');
  assert.equal(p.run(`BackendAssetIntegrity.toggle('asset', '${U(6)}')`), false, 'ضمن مهلة الحماية');
  assert.equal(p.run(`BackendAssetIntegrity.toggle('asset', '${U(8)}')`), false, 'غير متحقَّق منه');
  assert.equal(p.run(`BackendAssetIntegrity.toggle('asset', '${U(99)}')`), false, 'غير موجود في نتيجة الفحص');
  assert.equal(p.run(`BackendAssetIntegrity.toggle('object', '${U(4)}')`), false, 'نوع خاطئ');
  p.run(`handleAssetIntegrityToggle('asset', '${U(4)}')`);
  assert.equal(view(p).selectedCount, 1); assert.equal(view(p).selectedBytes, 3072);
  assert.match(p.screen(), /المحدَّد الآن: 1 من 50/);
  p.run(`handleAssetIntegrityToggle('asset', '${U(4)}')`); assert.equal(view(p).selectedCount, 0);
  p.run('handleAssetIntegritySelectAll()');
  assert.deepEqual(Object.keys(view(p).selected).sort(), ['asset:' + U(4), 'asset:' + U(5), 'object:' + REF(77)].sort());
  p.run('handleAssetIntegrityClear()'); assert.equal(view(p).selectedCount, 0);
  assert.equal(p.calls(CLEAN).length, 0);
});

test('الحذف لا يبدأ بلا تأكيد صريح: الرفض = لا طلب؛ والتأكيد يعرض العدد والمساحة ثم يرسل المحدَّد فقط {confirm:true, items}', async () => {
  const { w, d } = integrityWorld(); const p = page(w); await scanned(p); holdConfirm(p);
  p.run('handleAssetIntegrityCleanup()'); assert.equal(p.run('window.__ask'), null, 'بلا تحديد لا يُسأل ولا يُرسل');
  p.run(`handleAssetIntegrityToggle('asset', '${U(4)}')`); p.run(`handleAssetIntegrityToggle('object', '${REF(77)}')`);
  p.run('handleAssetIntegrityCleanup()');
  const spec = p.run('window.__ask.spec');
  assert.match(spec.message, /2 عنصرًا نهائيًا/); assert.match(spec.message, /1\.00 م\.ب|1\.0\d م\.ب/); assert.equal(spec.danger, true);
  await settle(); assert.equal(p.calls(CLEAN).length, 0, 'قبل التأكيد لا طلب');
  p.run('window.__ask.no && window.__ask.no()'); await settle(); assert.equal(p.calls(CLEAN).length, 0, 'الرفض لا يرسل');
  p.run('window.__ask.yes()'); await settle();
  const c = p.calls(CLEAN); assert.equal(c.length, 1); assert.equal(c[0].method, 'POST');
  assert.deepEqual(d.cleanupBody, { confirm: true, items: [{ type: 'asset', id: U(4) }, { type: 'object', id: REF(77) }] });
  assert.ok(!/U\(2\)|referenced|deletable/.test(c[0].rawBody));
  assert.deepEqual(p.env.errors, []);
});

test('بعد الحذف: النتيجة والمساحة المُستعادة، ويُزال المحذوف من القوائم والأعداد، ولا يُعاد الفحص تلقائيًا، وتُفرَّغ الاختيارات', async () => {
  const { w } = integrityWorld(); const p = page(w); await scanned(p); holdConfirm(p);
  p.run(`handleAssetIntegrityToggle('asset', '${U(4)}')`); p.run(`handleAssetIntegrityToggle('asset', '${U(5)}')`);
  p.run('handleAssetIntegrityCleanup()'); p.run('window.__ask.yes()'); await settle();
  const v = view(p), h = p.screen();
  assert.deepEqual(v.data.items.map(x => x.ref.id), [U(2), U(3), U(6), REF(77), U(8)]);
  assert.equal(v.data.summary.corrupt, 1); assert.equal(v.data.summary.orphaned, 2); assert.equal(v.data.summary.deletable, 1); assert.equal(v.data.summary.recoverableBytes, 1048576);
  assert.equal(v.selectedCount, 0);
  assert.match(h, /data-ai-result/); assert.match(h, /حُذف 2 من 2 — مساحة مُستعادة 8\.0 ك\.ب/); assert.match(h, /سُجّلت العملية في سجل التدقيق/);
  assert.equal(p.calls(SCAN).length, 1, 'لا إعادة فحص تلقائية');
  assert.deepEqual(p.env.errors, []);
});

test('الخادم يرفض أو يحمي ما تغيّر: «محمي/تغيّر» يُقفل محليًا ولا يُحذف ولا يُعاد تحديده؛ «فشل» يبقى قابلًا للمحاولة بعد إعادة الفحص', async () => {
  const { w, d } = integrityWorld(); const p = page(w); await scanned(p); holdConfirm(p);
  d.outcome['asset:' + U(4)] = { outcome: 'protected', reason: 'referenced' };
  d.outcome['asset:' + U(5)] = { outcome: 'changed', reason: null };
  d.outcome['object:' + REF(77)] = { outcome: 'deleted', bytes: 1048576, objectsRemaining: 0 };
  p.run('handleAssetIntegritySelectAll()'); p.run('handleAssetIntegrityCleanup()'); p.run('window.__ask.yes()'); await settle();
  const v = view(p); const by = id => v.data.items.find(x => x.ref.id === id);
  assert.deepEqual([by(U(4)).deletable, by(U(4)).protectedReason], [false, 'referenced']);
  assert.deepEqual([by(U(5)).deletable, by(U(5)).protectedReason], [false, 'changed']);
  assert.equal(by(REF(77)), undefined);
  assert.equal(p.run(`BackendAssetIntegrity.toggle('asset', '${U(4)}')`), false);
  assert.match(p.screen(), /محمي ولم يُحذف — مستخدم في إعلان أو غلاف/); assert.match(p.screen(), /تغيّر أثناء التنفيذ ولم يُحذف/); assert.match(p.screen(), /تغيّرت حالته أثناء التنفيذ — أعد الفحص/);
  assert.equal(v.data.summary.deletable, 0);
});

test('أخطاء الخادم: 404 = غير متاح؛ 409 مشغول؛ 503 = رسالة بلا ادّعاء حذف؛ ردّ غير صالح (قابل للحذف وهو مرتبط) يُرفض كاملًا', async () => {
  const a = integrityWorld(); a.d.fail = c => (SCAN.test(c.path) ? err(404, 'not_found') : null);
  let p = page(a.w); await scanned(p); assert.match(p.screen(), /الفحص غير متاح على هذا الخادم/); assert.ok(!/ابدأ الفحص|إعادة الفحص/.test(p.screen()));
  const b = integrityWorld(); b.d.fail = c => (SCAN.test(c.path) ? err(409, 'busy') : null);
  p = page(b.w); await scanned(p); assert.match(p.screen(), /فحص أو حذف آخر قيد التنفيذ/); assert.match(p.screen(), /ابدأ الفحص/);
  const c = integrityWorld(); c.d.fail = x => (SCAN.test(x.path) ? err(503, 'unavailable') : null);
  p = page(c.w); await scanned(p); assert.equal(view(p).status, 'error'); assert.ok(!/data-ai-cat/.test(p.screen()));
  c.d.fail = null; p.run('handleAssetIntegrityScan()'); await settle(); assert.equal(view(p).status, 'ready');
  const e = integrityWorld(); e.d.items = [item({ ref: { type: 'asset', id: U(2) }, referenced: true, deletable: true, protectedReason: null })];
  p = page(e.w); await scanned(p); assert.equal(view(p).status, 'error'); assert.ok(!/type="checkbox"/.test(p.screen()), 'ادّعاء خادم متناقض لا يُعرض قابلًا للحذف');
  const f = integrityWorld(); f.d.items = [item({ ref: { type: 'object', id: 'processed/car_image/x.webp' } })];
  p = page(f.w); await scanned(p); assert.equal(view(p).status, 'error', 'مرجع غير صالح (مسار) يُرفض');
});

test('فشل الحذف (503): رسالة، لا ادّعاء بالحذف، العناصر باقية، والاختيار يُفرَّغ', async () => {
  const { w, d } = integrityWorld(); const p = page(w); await scanned(p); holdConfirm(p);
  d.fail = c => (CLEAN.test(c.path) ? err(503, 'unavailable') : null);
  p.run(`handleAssetIntegrityToggle('asset', '${U(4)}')`); p.run('handleAssetIntegrityCleanup()'); p.run('window.__ask.yes()'); await settle();
  assert.match(p.screen(), /<div class="form-error" role="alert">[^<]+<\/div>/); assert.ok(!/data-ai-result/.test(p.screen())); assert.ok(!/حُذف \d/.test(p.screen()));
  assert.equal(view(p).data.items.length, 7); assert.equal(view(p).selectedCount, 0);
});

test('متابعة الفحص: nextAfter يُرسل after؛ تُضاف النتائج بلا تكرار وتُجمع الأعداد؛ ولا يُدَّعى الاكتمال إن لم يكتمل الأول', async () => {
  const { w, d } = integrityWorld(); d.nextAfter = U(8); d.complete = false;
  d.more = [item({ ref: { type: 'asset', id: U(9) }, category: 'missing', reason: 'object_missing', deletable: true, sizeBytes: 100 }), d.items[0]];
  const p = page(w); await scanned(p);
  assert.match(p.screen(), /الفحص جزئي/); assert.match(p.screen(), /متابعة فحص المزيد/);
  p.run('handleAssetIntegrityMore()'); await settle();
  const c = p.calls(SCAN); assert.equal(c.length, 2); assert.deepEqual(c[1].query, { scope: 'assets', after: U(8) });
  const v = view(p); assert.equal(v.data.items.length, 8); assert.equal(v.data.items.filter(x => x.ref.id === U(2)).length, 1);
  assert.equal(v.data.nextAfter, null); assert.equal(v.data.complete, false, 'لا يُدَّعى الاكتمال');
  assert.ok(!/متابعة فحص المزيد/.test(p.screen()));
});

test('غير المدير: الشاشة محجوبة بلا أي طلب؛ وعضو يستدعي الجسر مباشرة يتلقى 404 بلا عرض بيانات', async () => {
  const { w } = integrityWorld('user'); const p = page(w); await p.login();
  p.run("go('adminAssetIntegrity')"); await settle(); assert.notEqual(p.route(), 'adminAssetIntegrity');
  assert.equal(p.calls(ANY).length, 0);
  p.run('BackendAssetIntegrity.start()'); await settle();
  assert.equal(view(p).status, 'unavailable'); assert.equal(view(p).data, null);
  assert.equal(p.calls(CLEAN).length, 0);
});

test('تبديل المستخدم: الخروج يُسقط النتيجة والاختيار؛ وردّ فحص متأخر لا يُطبَّق على مستخدم آخر', async () => {
  const { w, d } = integrityWorld(); const p = page(w); await scanned(p);
  p.run(`handleAssetIntegrityToggle('asset', '${U(4)}')`); assert.equal(view(p).selectedCount, 1);
  p.run('handleLogout()'); await settle();
  assert.equal(view(p).data, null); assert.equal(view(p).selectedCount, 0); assert.equal(view(p).status, 'idle');
  let release; d.gate = c => (SCAN.test(c.path) ? new Promise(r => { release = r; }) : null);
  await p.login(); p.run("go('adminAssetIntegrity')"); await settle();
  p.run('handleAssetIntegrityScan()'); await tick();
  p.run('handleLogout()'); await settle(); release(); await settle();
  assert.equal(view(p).data, null, 'الرد المتأخر لا يُطبَّق');
});

test('حارس المصدر: الجسر يطلب مسارين فقط (GET scan، POST cleanup)، بلا تخزين/console/fetch/مفاتيح؛ الحذف يُستدعى من مكان واحد خلف askConfirm؛ المسار محميّ؛ 87 سكربتًا', () => {
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendAssetIntegrity'), b = all.indexOf('/* ==========================================================================\n   BACKEND USER DIRECTORY');
  assert.ok(a > 0 && b > a);
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.deepEqual([...new Set((src.match(/api\.(get|post|put|patch|delete)\(\s*'[^']*'/g) || []).map(s => s.replace(/\s+/g, '')))].sort(), ["api.get('/v1/admin/asset-integrity/scan'", "api.post('/v1/admin/asset-integrity/cleanup'"]);
  assert.ok(!/\bfetch\s*\(|localStorage|sessionStorage|indexedDB|console\.|XMLHttpRequest|document\.|window\./.test(src));
  assert.ok(!/storageKey|thumbKey|accessToken|refreshToken|Authorization|password/i.test(src));
  const dash = fs.readFileSync(path.join(root, 'screens/adminDashboard.js'), 'utf8');
  assert.equal((dash.match(/BackendAssetIntegrity\.cleanup\(/g) || []).length, 1);
  assert.match(dash, /askConfirm\(\{[\s\S]*?danger: true,\s*\}, \(\) => \{ BackendAssetIntegrity\.cleanup\(/);
  for (const f of fs.readdirSync(root, { recursive: true }).filter(x => /\.js$/.test(x) && !/^(tests|backend|node_modules)/.test(x) && x !== 'screens/adminDashboard.js' && x !== 'api/authBridge.js')) {
    assert.ok(!/BackendAssetIntegrity\.cleanup\(/.test(fs.readFileSync(path.join(root, f), 'utf8')), f + ' لا يستدعي الحذف');
  }
  assert.match(fs.readFileSync(path.join(root, 'navigation/router.js'), 'utf8'), /adminAssetIntegrity: \{ render: AdminAssetIntegrityScreen, nav: null, guard: _adminGuard \}/);
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.equal((html.match(/<script\b/g) || []).length, 87);
});

test('الوضع المحلي: الشاشة تقول إنها للخادم فقط بلا أي طلب، وقائمة لوحة الإدارة المحلية بلا بند الفحص', async () => {
  const env = makeEnv({});
  env.run("SessionService.login ? 0 : 0");
  assert.equal(env.run('BackendAssetIntegrity.isEnabled()'), false);
  env.run("currentRoute = 'adminAssetIntegrity'");
  assert.match(env.run('AdminAssetIntegrityScreen()'), /تعمل مع الخادم فقط/);
  const dash = fs.readFileSync(path.join(root, 'screens/adminDashboard.js'), 'utf8');
  const local = dash.slice(dash.indexOf('function AdminDashboardScreen()'), dash.indexOf('(11.7.2-K) فحص سلامة'));
  assert.ok(!/adminAssetIntegrity/.test(local), 'الوضع المحلي بلا بند الفحص');
  assert.match(dash.slice(dash.indexOf('function _AdminDashboardRemote()'), dash.indexOf('function AdminDashboardScreen()')), /go\('adminAssetIntegrity'\)/);
});

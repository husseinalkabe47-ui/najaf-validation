-- ===== MIGRATION 0014 — مدد خطط الاشتراك (3 و6 و12 شهرًا) — المرحلة 11.9-B =======
-- ترحيل أمامي فقط يضيف ولا يعدّل ترحيلًا سابقًا: يُضاف عمود duration_months، وتُزرع ثلاث خطط بالدينار العراقي بسعر ابتدائي 0.
-- الأسعار تُحدَّد لاحقًا من المدير (ليس هنا). لا اشتراكات ولا دفع ولا تغيير في الاستحقاقات: الخطة المجانية ودالة entitlements_for_showroom كما هما.
-- billing_interval (month|year) لا يعبّر عن 3 و6 أشهر، لذا تحمل الخطط الجديدة مدتها في duration_months، وتبقى billing_interval فارغة لها.
ALTER TABLE subscription_plans ADD COLUMN duration_months smallint;
ALTER TABLE subscription_plans ADD CONSTRAINT plans_duration_vocab CHECK (duration_months IS NULL OR duration_months IN (3, 6, 12));
-- خطة واحدة لكل مدة (الخطة المجانية وأي خطة قديمة بلا مدة لا تدخل في هذا القيد)
CREATE UNIQUE INDEX plans_duration_uq ON subscription_plans (duration_months) WHERE duration_months IS NOT NULL;
-- القيد القديم يشترط billing_interval لأي سعر > 0؛ الخطة ذات المدة تكفيها المدة. التوسيع لا يرفض صفًا كان مقبولًا.
ALTER TABLE subscription_plans DROP CONSTRAINT plans_priced_needs_interval;
ALTER TABLE subscription_plans ADD CONSTRAINT plans_priced_needs_interval CHECK (price = 0 OR billing_interval IS NOT NULL OR duration_months IS NOT NULL);

INSERT INTO subscription_plans (code, name, billing_interval, duration_months, price, currency, entitlements)
VALUES ('plan_3m',  'اشتراك 3 أشهر',  NULL, 3,  0, 'IQD', '{}'::jsonb),
       ('plan_6m',  'اشتراك 6 أشهر',  NULL, 6,  0, 'IQD', '{}'::jsonb),
       ('plan_12m', 'اشتراك 12 شهرًا', NULL, 12, 0, 'IQD', '{}'::jsonb)
ON CONFLICT (code) DO NOTHING;

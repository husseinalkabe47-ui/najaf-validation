// Phase 11.9-D: manual subscription activation / renewal with payment recording. Unit level: policy, validation, the date rules, the
// service with an in-memory transactional repository (rollback, duplicates, audit), the HTTP handlers and source guards. The real SQL
// runs in test/integration/subscriptions.integration.test.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import { AuthzError, can, isPublic, subscriptionResource } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { DbError } from '../../src/errors.ts';
import { registerSubscriptionsRoutes, SUBSCRIPTIONS_RATE_LIMITS, toSubscriptionsHttp } from '../../src/subscriptions/routes.ts';
import type { PaymentRow, SubscriptionRow, SubscriptionsRepository, SubscriptionTx } from '../../src/subscriptions/repository.ts';
import { addMonthsUtc, createSubscriptionsService, parseGrantBody, planGrant, SubscriptionsError } from '../../src/subscriptions/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const ADMIN: Actor = Object.freeze({ id: '1', role: 'admin' });
const MEMBER: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) => readFileSync(join(ROOT, rel), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').split('\n').map((l) => l.replace(/^\s*\/\/.*$/, '')).join('\n');
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const isValidation = (e: unknown) => e instanceof SubscriptionsError && e.code === 'validation_failed';
const isDuplicate = (e: unknown) => e instanceof SubscriptionsError && e.code === 'duplicate_payment';
const iso = (s: string) => new Date(s);
const NOW = iso('2026-10-14T12:00:00Z');

/** In-memory transactional stand-in: state is snapshotted at BEGIN and restored when the callback throws (a rollback). */
function fakeRepo(opts: { failAudit?: () => boolean } = {}) {
  const st = {
    showrooms: new Set(['10', '11']),
    plans: [{ id: '4', code: 'plan_3m', durationMonths: 3, price: 0, currency: 'IQD' }, { id: '5', code: 'plan_6m', durationMonths: 6, price: 0, currency: 'IQD' }, { id: '6', code: 'plan_12m', durationMonths: 12, price: 0, currency: 'IQD' }],
    subs: [] as SubscriptionRow[],
    pays: [] as PaymentRow[],
    audits: [] as AuditEvent[],
    seq: 100,
  };
  const planOf = (id: string) => st.plans.find((p) => p.id === id)!;
  const clone = () => structuredClone({ subs: st.subs, pays: st.pays, audits: st.audits, seq: st.seq });
  const repo: SubscriptionsRepository = {
    async transaction<T>(fn: (t: SubscriptionTx) => Promise<T>): Promise<T> {
      const snap = clone();
      const t: SubscriptionTx = {
        async lockShowroom(id) { return st.showrooms.has(id) ? { id, status: 'active' } : null; },
        async findPlan(c) { const p = st.plans.find((x) => x.code === c); return p ? { ...p } : null; },
        async findLive(sid) { const s = st.subs.find((x) => x.showroomId === sid && ['trialing', 'active', 'past_due'].includes(x.status)); return s ? { ...s } : null; },
        async paymentExists(provider, ref) { return st.pays.some((p) => p.provider === provider && p.providerRef === ref); },
        async insertSubscription(i) {
          const p = planOf(i.planId);
          const row: SubscriptionRow = { id: String(++st.seq), showroomId: i.showroomId, planId: i.planId, planCode: p.code, durationMonths: p.durationMonths, status: 'active', periodStart: i.start, periodEnd: i.end, version: 1 };
          st.subs.push(row);
          return { ...row };
        },
        async extendSubscription(i) { const s = st.subs.find((x) => x.id === i.id)!; s.periodEnd = i.end; s.status = 'active'; s.version++; return { ...s }; },
        async closeLapsed(id) { st.subs.find((x) => x.id === id)!.status = 'expired'; },
        async insertPayment(i) {
          if (st.pays.some((p) => p.provider === i.provider && p.providerRef === i.ref)) throw new DbError('unique', { constraint: 'payments_provider_ref_uq' });
          const row: PaymentRow = { id: String(++st.seq), subscriptionId: i.subscriptionId, amount: i.amount, currency: 'IQD', provider: i.provider, providerRef: i.ref, paidAt: i.paidAt };
          st.pays.push(row);
          return { ...row };
        },
        audit: { async record(e) { if (opts.failAudit?.()) throw new Error('audit write failed'); assertAuditSafe(e); st.audits.push(e); } },
      };
      try { return await fn(t); } catch (e) { Object.assign(st, snap); throw e; }
    },
    async showroomExists(id) { return st.showrooms.has(id); },
    async history(sid) { return st.subs.filter((s) => s.showroomId === sid).reverse().map((s) => ({ ...s, payments: st.pays.filter((p) => p.subscriptionId === s.id).reverse() })); },
  };
  return { repo, st };
}
const body = (over: Record<string, unknown> = {}) => ({ showroomId: '10', planCode: 'plan_3m', method: 'cash', reference: 'RCPT-001', amount: 75000, paidAt: '2026-10-14T09:30:00Z', ...over });
function world(now = NOW, opts?: Parameters<typeof fakeRepo>[0]) {
  const f = fakeRepo(opts);
  let clock = now;
  const svc = createSubscriptionsService({ repo: f.repo, now: () => clock });
  return { f, svc, setNow: (d: Date) => { clock = d; } };
}

describe('subscriptions: policy', () => {
  it('only an administrator may read or update; no other action; never public', () => {
    const r = subscriptionResource();
    for (const a of ['read', 'update'] as const) {
      assert.equal(can(ADMIN, a, r), true);
      for (const who of [MEMBER, DEALER, null]) assert.equal(can(who, a, r), false);
    }
    for (const a of ['delete', 'moderate'] as const) assert.equal(can(ADMIN, a, r), false);
    assert.equal(isPublic(r), false);
  });
});

describe('subscriptions: date rules', () => {
  it('adds calendar months in UTC, clamped to the last day of the month', () => {
    assert.equal(addMonthsUtc(iso('2026-01-31T10:00:00Z'), 1).toISOString(), '2026-02-28T10:00:00.000Z');
    assert.equal(addMonthsUtc(iso('2028-01-31T10:00:00Z'), 1).toISOString(), '2028-02-29T10:00:00.000Z');
    assert.equal(addMonthsUtc(iso('2026-10-14T12:00:00Z'), 3).toISOString(), '2027-01-14T12:00:00.000Z');
    assert.equal(addMonthsUtc(iso('2026-08-31T00:00:00Z'), 6).toISOString(), '2027-02-28T00:00:00.000Z');
    assert.equal(addMonthsUtc(iso('2026-10-14T12:00:00Z'), 12).toISOString(), '2027-10-14T12:00:00.000Z');
    assert.equal(addMonthsUtc(iso('2024-02-29T00:00:00Z'), 12).toISOString(), '2025-02-28T00:00:00.000Z');
  });
  it('no live subscription: starts now; renewal before expiry: extends from the CURRENT END; renewal after expiry: starts now', () => {
    const a = planGrant(null, '4', 3, NOW);
    assert.deepEqual([a.kind, (a as { start: Date }).start.toISOString(), (a as { end: Date }).end.toISOString()], ['activated', NOW.toISOString(), '2027-01-14T12:00:00.000Z']);
    const live = { periodEnd: iso('2026-11-30T00:00:00Z'), planId: '4' };
    const r = planGrant(live, '4', 3, NOW);
    assert.deepEqual([r.kind, (r as { end: Date }).end.toISOString()], ['renewed', '2027-02-28T00:00:00.000Z']);
    const lapsed = planGrant({ periodEnd: iso('2026-09-01T00:00:00Z'), planId: '4' }, '6', 6, NOW);
    assert.deepEqual([lapsed.kind, (lapsed as { start: Date }).start.toISOString(), (lapsed as { end: Date }).end.toISOString()], ['renewed_after_expiry', NOW.toISOString(), '2027-04-14T12:00:00.000Z']);
    assert.equal(planGrant({ periodEnd: iso('2026-10-14T12:00:00Z'), planId: '4' }, '4', 3, NOW).kind, 'renewed_after_expiry'); // ends exactly now = expired
    assert.equal(planGrant(live, '5', 6, NOW).kind, 'plan_mismatch');
  });
});

describe('subscriptions: input validation', () => {
  it('accepts a valid body and trims the reference; date-only means midnight UTC', () => {
    const r = parseGrantBody(body({ reference: '  RCPT-001  ', paidAt: '2026-10-13' }), NOW);
    if (!r.ok) throw new Error('expected a valid body');
    assert.equal(r.value.reference, 'RCPT-001'); assert.equal(r.value.paidAt.toISOString(), '2026-10-13T00:00:00.000Z');
    assert.ok(parseGrantBody(body({ amount: 0, method: 'bank_transfer', paidAt: '2026-10-14T15:00:00+03:00' }), NOW).ok);
  });
  it('rejects bad showroom ids, plans, methods, references, amounts and dates (field names and codes only)', () => {
    const bad: Array<[Record<string, unknown>, string, string]> = [
      [{ showroomId: '0' }, 'showroomId', 'invalid_format'], [{ showroomId: 10 }, 'showroomId', 'invalid_type'], [{ showroomId: '1 OR 1=1' }, 'showroomId', 'invalid_format'],
      [{ planCode: 'free' }, 'planCode', 'invalid_format'], [{ planCode: 'plan_1m' }, 'planCode', 'invalid_format'], [{ planCode: 3 }, 'planCode', 'invalid_type'],
      [{ method: 'bitcoin' }, 'method', 'invalid_format'], [{ method: undefined }, 'method', 'required'],
      [{ reference: '' }, 'reference', 'required'], [{ reference: '   ' }, 'reference', 'required'], [{ reference: 'a'.repeat(65) }, 'reference', 'too_long'], [{ reference: "x'; DROP" }, 'reference', 'invalid_format'], [{ reference: 5 }, 'reference', 'invalid_type'],
      [{ amount: -1 }, 'amount', 'invalid_format'], [{ amount: 1.5 }, 'amount', 'invalid_format'], [{ amount: '5' }, 'amount', 'invalid_type'], [{ amount: Number.NaN }, 'amount', 'invalid_type'], [{ amount: 1e14 }, 'amount', 'invalid_format'], [{ amount: undefined }, 'amount', 'required'],
      [{ paidAt: '2026-02-31' }, 'paidAt', 'invalid_format'], [{ paidAt: 'yesterday' }, 'paidAt', 'invalid_format'], [{ paidAt: '2026-10-14T25:00:00Z' }, 'paidAt', 'invalid_format'],
      [{ paidAt: '2026-10-15T12:00:00Z' }, 'paidAt', 'invalid_format'], [{ paidAt: '2019-12-31' }, 'paidAt', 'invalid_format'], [{ paidAt: 20261014 }, 'paidAt', 'invalid_type'],
    ];
    for (const [over, field, c] of bad) {
      const r = parseGrantBody(body(over), NOW);
      assert.equal(r.ok, false, JSON.stringify(over));
      if (!r.ok) assert.deepEqual(r.errors, [{ field, code: c }], JSON.stringify(over));
    }
  });
  it('rejects a non-object body and unknown fields (a currency cannot be sent)', () => {
    for (const b of [undefined, null, 5, 'x', [1]]) assert.deepEqual(parseGrantBody(b, NOW), { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] });
    assert.deepEqual(parseGrantBody(body({ currency: 'USD' }), NOW), { ok: false, errors: [{ field: 'currency', code: 'unknown_field' }] });
  });
});

describe('subscriptions: service', () => {
  it('activates: new row starting now, payment recorded, one audit row with actor, plan, amount and period end', async () => {
    const { svc, f } = world();
    const r = await svc.grant(ADMIN, body(), { requestId: 'req-1' });
    assert.equal(r.outcome, 'activated');
    assert.deepEqual([r.subscription.status, r.subscription.periodStart, r.subscription.periodEnd, r.subscription.plan.code], ['active', NOW.toISOString(), '2027-01-14T12:00:00.000Z', 'plan_3m']);
    assert.deepEqual([r.payment.amount, r.payment.currency, r.payment.method, r.payment.reference, r.payment.paidAt], [75000, 'IQD', 'cash', 'RCPT-001', '2026-10-14T09:30:00.000Z']);
    assert.equal(f.st.subs.length, 1); assert.equal(f.st.pays.length, 1);
    assert.equal(f.st.audits.length, 1);
    const a = f.st.audits[0]!;
    assert.deepEqual([a.action, a.actorUserId, a.actorRole, a.entityType, a.entityId, a.requestId], ['subscription.activate', '1', 'admin', 'subscription', r.subscription.id, 'req-1']);
    assert.deepEqual(a.afterData, { showroomId: 10, planId: 4, months: 3, amount: 75000, planPrice: 0, paymentId: Number(r.payment.id), newPeriodEnd: Math.floor(iso('2027-01-14T12:00:00Z').getTime() / 1000) });
  });

  it('renews before expiry from the current end (same row, history kept in payments and audit), recording old and new details', async () => {
    const { svc, f } = world();
    const first = await svc.grant(ADMIN, body());
    const r = await svc.grant(ADMIN, body({ reference: 'RCPT-002', amount: 80000 }));
    assert.equal(r.outcome, 'renewed');
    assert.equal(r.subscription.id, first.subscription.id);
    assert.equal(r.subscription.periodStart, first.subscription.periodStart);
    assert.equal(r.subscription.periodEnd, '2027-04-14T12:00:00.000Z'); // 14 Jan 2027 + 3 months, NOT now + 3 months
    assert.equal(r.subscription.version, 2);
    assert.equal(f.st.subs.length, 1); assert.equal(f.st.pays.length, 2);
    assert.equal(f.st.audits.length, 2);
    const a = f.st.audits[1]!;
    assert.equal(a.action, 'subscription.renew');
    assert.deepEqual([a.afterData['oldPeriodEnd'], a.afterData['newPeriodEnd'], a.afterData['oldSubscriptionId'], a.afterData['oldPlanId'], a.afterData['amount']],
      [Math.floor(iso('2027-01-14T12:00:00Z').getTime() / 1000), Math.floor(iso('2027-04-14T12:00:00Z').getTime() / 1000), Number(first.subscription.id), 4, 80000]);
  });

  it('renews after expiry from the renewal date: the old row is closed and kept, a new row starts now (any plan)', async () => {
    const { svc, f, setNow } = world();
    const first = await svc.grant(ADMIN, body());
    setNow(iso('2027-03-01T08:00:00Z')); // the 3-month plan ended on 14 Jan 2027
    const r = await svc.grant(ADMIN, body({ planCode: 'plan_6m', reference: 'RCPT-003' }));
    assert.equal(r.outcome, 'renewed_after_expiry');
    assert.notEqual(r.subscription.id, first.subscription.id);
    assert.deepEqual([r.subscription.periodStart, r.subscription.periodEnd], ['2027-03-01T08:00:00.000Z', '2027-09-01T08:00:00.000Z']);
    assert.deepEqual(f.st.subs.map((s) => s.status), ['expired', 'active']);
    assert.equal(f.st.subs[0]!.periodEnd.toISOString(), '2027-01-14T12:00:00.000Z'); // history untouched
    assert.deepEqual(f.st.audits.map((a) => a.action), ['subscription.activate', 'subscription.close_lapsed', 'subscription.renew']);
    assert.equal(f.st.audits[1]!.entityId, first.subscription.id);
    assert.equal(f.st.audits[2]!.afterData['oldPeriodEnd'], Math.floor(iso('2027-01-14T12:00:00Z').getTime() / 1000));
  });

  it('refuses a different plan while a live subscription is still running (409 plan_mismatch) and writes nothing', async () => {
    const { svc, f } = world();
    await svc.grant(ADMIN, body());
    const before = JSON.stringify([f.st.subs, f.st.pays, f.st.audits]);
    await assert.rejects(() => svc.grant(ADMIN, body({ planCode: 'plan_12m', reference: 'RCPT-9' })), (e) => e instanceof SubscriptionsError && e.code === 'plan_mismatch');
    assert.equal(JSON.stringify([f.st.subs, f.st.pays, f.st.audits]), before);
  });

  it('the same method + reference is never processed twice (409, nothing changes), even for another showroom or plan; another method with the same reference is a different payment', async () => {
    const { svc, f } = world();
    await svc.grant(ADMIN, body());
    const snapshot = JSON.stringify([f.st.subs, f.st.pays, f.st.audits]);
    await assert.rejects(() => svc.grant(ADMIN, body()), isDuplicate);
    await assert.rejects(() => svc.grant(ADMIN, body({ showroomId: '11', planCode: 'plan_6m', reference: '  RCPT-001 ' })), isDuplicate);
    assert.equal(JSON.stringify([f.st.subs, f.st.pays, f.st.audits]), snapshot);
    assert.equal((await svc.grant(ADMIN, body({ method: 'bank_transfer' }))).outcome, 'renewed');
  });

  it('a duplicate that slips past the check (race) is stopped by the UNIQUE constraint and also answered as duplicate', async () => {
    const f = fakeRepo();
    const svc = createSubscriptionsService({ repo: { ...f.repo, transaction: (fn) => f.repo.transaction((t) => fn({ ...t, paymentExists: async () => false })) }, now: () => NOW });
    await svc.grant(ADMIN, body());
    await assert.rejects(() => svc.grant(ADMIN, body()), isDuplicate);
    assert.equal(f.st.pays.length, 1); assert.equal(f.st.subs.length, 1);
  });

  it('is atomic: when the audit write fails, the subscription AND the payment are rolled back', async () => {
    let fail = false;
    const { svc, f } = world(NOW, { failAudit: () => fail });
    await svc.grant(ADMIN, body());
    const snapshot = JSON.stringify([f.st.subs, f.st.pays, f.st.audits]);
    fail = true;
    await assert.rejects(() => svc.grant(ADMIN, body({ reference: 'RCPT-2' })), /audit write failed/);
    assert.equal(JSON.stringify([f.st.subs, f.st.pays, f.st.audits]), snapshot); // the renewal's extension and its payment are gone
    fail = false;
    assert.equal((await svc.grant(ADMIN, body({ reference: 'RCPT-2' }))).outcome, 'renewed'); // the reference was not burned
  });

  it('a payment failure after the subscription change also rolls the change back', async () => {
    const f = fakeRepo();
    const svc = createSubscriptionsService({ repo: { ...f.repo, transaction: (fn) => f.repo.transaction((t) => fn({ ...t, insertPayment: async () => { throw new Error('payment insert failed'); } })) }, now: () => NOW });
    await assert.rejects(() => svc.grant(ADMIN, body()), /payment insert failed/);
    assert.deepEqual([f.st.subs.length, f.st.pays.length, f.st.audits.length], [0, 0, 0]);
  });

  it('an unknown showroom or a plan that is not available is 404; invalid input is 400; nothing is written for any of them', async () => {
    const { svc, f } = world();
    await assert.rejects(() => svc.grant(ADMIN, body({ showroomId: '999' })), isNotFound);
    f.st.plans[0]!.code = 'gone';
    await assert.rejects(() => svc.grant(ADMIN, body()), isNotFound);
    for (const b of [body({ amount: -5 }), body({ planCode: 'free' }), body({ paidAt: 'x' }), {}, null]) await assert.rejects(() => svc.grant(ADMIN, b), isValidation);
    assert.deepEqual([f.st.subs.length, f.st.pays.length, f.st.audits.length], [0, 0, 0]);
  });

  it('a member, a dealer and no actor are refused (404) before the body is looked at; nothing is read or written', async () => {
    const { svc, f } = world();
    for (const who of [MEMBER, DEALER, null]) {
      await assert.rejects(() => svc.grant(who, body()), isNotFound);
      await assert.rejects(() => svc.grant(who, 'garbage'), isNotFound);
      await assert.rejects(() => svc.history(who, '10'), isNotFound);
    }
    assert.deepEqual([f.st.subs.length, f.st.pays.length, f.st.audits.length], [0, 0, 0]);
  });

  it('history lists every subscription (newest first) with its payments, and 404 for an unknown or malformed showroom id', async () => {
    const { svc, setNow } = world();
    await svc.grant(ADMIN, body());
    setNow(iso('2027-03-01T08:00:00Z'));
    await svc.grant(ADMIN, body({ reference: 'RCPT-3', planCode: 'plan_6m' }));
    const h = await svc.history(ADMIN, '10');
    assert.deepEqual(h.subscriptions.map((s) => [s.status, s.payments.length]), [['active', 1], ['expired', 1]]);
    for (const id of ['999', 'abc', undefined, 10]) await assert.rejects(() => svc.history(ADMIN, id), isNotFound);
  });
});

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };

function http(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: 'unit-test-access-secret-0123456789abcdef-XYZ', logger: recordingLogger().logger, now: clock.now });
  const f = fakeRepo();
  const subscriptions = createSubscriptionsService({ repo: f.repo, now: () => NOW });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  registerSubscriptionsRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, subscriptions, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  let n = 0;
  const phone = () => `0771${String(3000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const sent: Sent = { headers: {} };
    const reply = { code: (c: number) => ((sent.status = c), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  async function account(role: 'member' | 'dealer' | 'admin') {
    const r = role === 'dealer' ? await auth.registerDealer({ name: 'تاجر', phone: phone(), password: 'Corr3ct-Horse-Battery' }) : await auth.register({ name: 'حساب', phone: phone(), password: 'Corr3ct-Horse-Battery' });
    const u = db.users().find((x) => x.id === r.user.id)!;
    if (role === 'dealer') u.status = 'active';
    if (role === 'admin') u.role = 'admin';
    return { authorization: `Bearer ${r.session.accessToken}` };
  }
  return { routes, call, account, f };
}
const POST = '/v1/admin/subscriptions';
const GET = '/v1/admin/showrooms/:id/subscriptions';

describe('subscriptions: HTTP', () => {
  it('registers exactly one POST and one GET, each rate limited when a limiter is supplied; the POST has a small body limit', () => {
    const { routes } = http(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`GET ${GET}`, `POST ${POST}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts!.bodyLimit, 4096);
  });

  it('401 without or with a bad token; 404 for a member and a dealer (same as an unknown showroom)', async () => {
    const s = http();
    for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
      const r = await s.call('POST', POST, { headers, body: body() });
      assert.equal(r.status, 401); assert.equal(r.headers['www-authenticate'], 'Bearer');
      assert.equal((await s.call('GET', GET, { headers, params: { id: '10' } })).status, 401);
    }
    const adminH = await s.account('admin');
    const unknown = await s.call('POST', POST, { headers: adminH, body: body({ showroomId: '999' }) });
    assert.equal(unknown.status, 404);
    for (const role of ['member', 'dealer'] as const) {
      const h = await s.account(role);
      const w = await s.call('POST', POST, { headers: h, body: body() });
      assert.equal(w.status, 404); assert.deepEqual(w.body, unknown.body);
      assert.equal((await s.call('GET', GET, { headers: h, params: { id: '10' } })).status, 404);
    }
    assert.deepEqual([s.f.st.subs.length, s.f.st.pays.length, s.f.st.audits.length], [0, 0, 0]);
  });

  it('an administrator activates (201 {outcome, subscription, payment}), renews, and reads the history', async () => {
    const s = http();
    const h = await s.account('admin');
    const a = await s.call('POST', POST, { headers: h, body: body() });
    assert.equal(a.status, 201); assert.deepEqual(Object.keys(a.body as object).sort(), ['outcome', 'payment', 'subscription']);
    assert.equal((a.body as { outcome: string }).outcome, 'activated');
    const r = await s.call('POST', POST, { headers: h, body: body({ reference: 'RCPT-2' }) });
    assert.equal((r.body as { outcome: string }).outcome, 'renewed');
    assert.equal(s.f.st.audits[0]!.requestId, 'req-abcdef01');
    const hist = await s.call('GET', GET, { headers: h, params: { id: '10' } });
    assert.equal(hist.status, 200); assert.equal((hist.body as { subscriptions: Array<{ payments: unknown[] }> }).subscriptions[0]!.payments.length, 2);
    assert.equal((await s.call('GET', GET, { headers: h, params: { id: '999' } })).status, 404);
  });

  it('answers 400 with field names only, 409 for a duplicate payment and for a plan mismatch, 415 for a non-JSON body', async () => {
    const s = http();
    const h = await s.account('admin');
    const bad = await s.call('POST', POST, { headers: h, body: body({ amount: -1, currency: 'USD' }) });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as { error: { fields: unknown } }).error.fields, [{ field: 'currency', code: 'unknown_field' }, { field: 'amount', code: 'invalid_format' }]);
    await s.call('POST', POST, { headers: h, body: body() });
    const dup = await s.call('POST', POST, { headers: h, body: body() });
    assert.equal(dup.status, 409); assert.equal((dup.body as { error: { code: string } }).error.code, 'duplicate_payment');
    const mismatch = await s.call('POST', POST, { headers: h, body: body({ planCode: 'plan_12m', reference: 'X-1' }) });
    assert.equal(mismatch.status, 409); assert.equal((mismatch.body as { error: { code: string } }).error.code, 'plan_mismatch');
    const text = await s.call('POST', POST, { headers: { ...h, 'content-type': 'text/plain' }, body: '{}' });
    assert.equal(text.status, 415);
    assert.equal(s.f.st.pays.length, 1);
  });

  it('writes have a budget per address (429 with Retry-After)', async () => {
    const s = http(true);
    const h = await s.account('admin');
    for (let i = 0; i < SUBSCRIPTIONS_RATE_LIMITS.write.limit; i++) assert.equal((await s.call('POST', POST, { headers: h, body: body({ reference: `R-${i}`, amount: 1 }) })).status, 201);
    const denied = await s.call('POST', POST, { headers: h, body: body({ reference: 'R-over' }) });
    assert.equal(denied.status, 429); assert.ok(Number(denied.headers['retry-after']) > 0);
  });

  it('maps errors: validation 400, duplicate and mismatch 409, authz 404, anything else not ours', () => {
    assert.equal(toSubscriptionsHttp(new SubscriptionsError('validation_failed', [{ field: 'amount', code: 'required' }]))?.status, 400);
    assert.equal(toSubscriptionsHttp(new SubscriptionsError('duplicate_payment'))?.status, 409);
    assert.equal(toSubscriptionsHttp(new SubscriptionsError('plan_mismatch'))?.status, 409);
    assert.equal(toSubscriptionsHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toSubscriptionsHttp(new Error('boom')), undefined);
  });
});

describe('subscriptions: SQL and source guards', () => {
  it('payments are only ever INSERTed and never updated or deleted; subscriptions are never deleted; nothing touches plans', () => {
    const r = code('src/subscriptions/repository.ts');
    assert.doesNotMatch(r, /(UPDATE|DELETE\s+FROM|TRUNCATE)\s+payments/i);
    assert.doesNotMatch(r, /DELETE\s+FROM|TRUNCATE/i);
    assert.doesNotMatch(r, /(UPDATE|INSERT\s+INTO)\s+subscription_plans/i);
    assert.doesNotMatch(r, /INSERT\s+INTO\s+audit_logs/i);
    assert.match(r, /audit: createPgAuditRepository\(t\)/);
    assert.doesNotMatch(r, /SELECT \*/);
    const updates = r.match(/UPDATE\s+subscriptions\s+SET[^`]*/gi) ?? [];
    assert.deepEqual(updates.map((u) => u.replace(/\s+/g, ' ').trim()), ["UPDATE subscriptions SET current_period_end = $2, status = 'active' WHERE id = $1", "UPDATE subscriptions SET status = 'expired' WHERE id = $1"]);
    assert.match(r, /FOR UPDATE OF s`/); // showroom lock and live-subscription lock
  });
  it('no gateway, automatic billing, messaging or network code exists in the module', () => {
    for (const f of ['repository', 'service', 'routes']) assert.doesNotMatch(code(`src/subscriptions/${f}.ts`), /fetch\(|https?:\/\/|webhook|stripe|zaincash|twilio|whatsapp|sms|setInterval|setTimeout|entitlements/i, f);
  });
  it('no other module writes subscriptions or payments, and the module is wired once', () => {
    for (const f of ['src/auth/repository.ts', 'src/rewards/repository.ts', 'src/admin-users/repository.ts', 'src/subscription-plans/repository.ts']) assert.doesNotMatch(code(f), /(UPDATE|INSERT\s+INTO)\s+(subscriptions|payments)\b/i, f);
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.subscriptions\) registerSubscriptionsRoutes\(/);
    assert.match(code('src/index.ts'), /createSubscriptionsService\(\{ repo: createPgSubscriptionsRepository\(db\) \}\)/);
  });
});

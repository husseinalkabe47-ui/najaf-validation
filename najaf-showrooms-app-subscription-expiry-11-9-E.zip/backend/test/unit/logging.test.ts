// Phase 11.8-H: operational logging. The masking rules (pure functions), the logger options against the REAL pino when it is installed
// (CI), the real HTTP server's log lines (CI), failure paths, and static guards that keep diagnostic logs and the audit trail apart.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { loadConfig } from '../../src/config.ts';
import { DbError, describeError } from '../../src/errors.ts';
import { SLOW_REQUEST_MS, buildLoggerOptions, httpOutcomeEvents, redactText, scrubLogObject, scrubValue, serializeErr, serializeReq, serializeRes } from '../../src/logging.ts';
import { createConsoleLogger } from '../../src/types.ts';

const PHONE = '+9647701234567';
const LOCAL = '07701234567';
const JWT = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.c2lnbmF0dXJlLXBhcnQ';
const text = (v: unknown) => JSON.stringify(v);

describe('redactText', () => {
  it('masks bearer credentials, JWTs, phone numbers (both forms) and URL credentials', () => {
    const t = redactText(`auth Bearer abcdef0123456789 jwt ${JWT} phone ${PHONE} / ${LOCAL} db postgres://najaf:S3cr3t@host:5432/db`);
    for (const leak of ['abcdef0123456789', JWT, PHONE, LOCAL, 'S3cr3t']) assert.ok(!t.includes(leak), leak);
    assert.match(t, /postgres:\/\/\[redacted\]@host/);
  });
  it('masks the row values a PostgreSQL message quotes, keeping the column and the sentence', () => {
    const t = redactText('duplicate key value violates unique constraint "users_phone_active_uq". Key (phone_e164)=(+9647701234567) already exists.');
    assert.ok(!t.includes('9647701234567'));
    assert.match(t, /Key \(phone_e164\)=\(\[redacted\]\) already exists/);
    assert.ok(!redactText('Failing row contains (5, Ali, +9647701234567, hash).').includes('Ali'));
  });
  it('masks signature/user/transaction/token query values inside a URL', () => {
    const t = redactText('/v1/rewards/admob/ssv?ad_unit=1&signature=MEUCIQ&user_id=77&transaction_id=tx-1&key_id=3');
    for (const leak of ['MEUCIQ', 'tx-1', 'user_id=77']) assert.ok(!t.includes(leak), leak);
  });
  it('leaves ordinary diagnostics readable', () => {
    assert.equal(redactText('connect ECONNREFUSED 10.0.0.5:5432'), 'connect ECONNREFUSED 10.0.0.5:5432');
    assert.equal(redactText('grant 7d8f0c2e-1111-4222-8333-444455556666 expired'), 'grant 7d8f0c2e-1111-4222-8333-444455556666 expired');
  });
});

describe('scrubValue / scrubLogObject', () => {
  it('replaces fields NAMED like a secret, at any depth, whatever they hold', () => {
    const o = scrubLogObject({
      event: 'x',
      password: 'p', newPassword: 'p2', refreshToken: 'r', accessToken: 'a', otp: '123456', verificationCode: '123456', resetCode: '1',
      authorization: 'Bearer x', cookie: 'c=1', setCookie: 'c', signature: 's', phone: PHONE, phoneE164: PHONE, passwordHash: 'h', apiKey: 'k',
      nested: { deep: { token: 't', ok: 1 } }, list: [{ secret: 's' }],
    });
    const t = text(o);
    for (const leak of ['"p"', '"p2"', '"r"', '"a"', '123456', 'Bearer', 'c=1', '"s"', PHONE, '"h"', '"k"', '"t"']) assert.ok(!t.includes(leak), leak);
    assert.equal((o['nested'] as { deep: { ok: number } }).deep.ok, 1);
    assert.equal(o['event'], 'x');
  });
  it('keeps the fields an operator needs: event, ids, counts, reason and error codes', () => {
    const o = scrubLogObject({ event: 'reward.consumed', userId: '7', grantId: '8', carId: '9', count: 3, reason: 'provider_error', code: 'rate_limited', status: 429 });
    assert.deepEqual(o, { event: 'reward.consumed', userId: '7', grantId: '8', carId: '9', count: 3, reason: 'provider_error', code: 'rate_limited', status: 429 });
  });
  it('masks secrets inside string VALUES of innocent-looking fields', () => {
    const o = scrubLogObject({ detail: `user ${PHONE} sent Bearer abcdef0123456789`, url: `/x?signature=abc` });
    assert.ok(!text(o).includes('9647701234567') && !text(o).includes('abcdef0123456789') && !text(o).includes('signature=abc'));
  });
  it('is bounded and cycle-safe, and never throws', () => {
    const a: Record<string, unknown> = { event: 'loop' };
    a['self'] = a;
    const big = Array.from({ length: 500 }, (_, i) => ({ i }));
    assert.doesNotThrow(() => scrubLogObject({ a, big, f: () => 1, s: Symbol('x'), long: 'x'.repeat(100000) }));
    const o = scrubLogObject({ big, long: 'x'.repeat(100000) });
    assert.equal((o['big'] as unknown[]).length, 50);
    assert.ok((o['long'] as string).length < 2100);
    assert.equal(scrubValue(undefined), undefined);
  });
  it('leaves req/res/err to their serializers', () => {
    const req = { method: 'GET' };
    assert.equal(scrubLogObject({ req })['req'], req);
  });
});

describe('serializers', () => {
  it('the request is logged without its query string, headers or body', () => {
    const s = serializeReq({ method: 'GET', url: '/v1/rewards/admob/ssv?signature=SIG&user_id=77&transaction_id=TX', ip: '203.0.113.9', host: 'api.example', headers: { authorization: 'Bearer abcdef0123456789' }, body: { password: 'p' } });
    assert.deepEqual(s, { method: 'GET', url: '/v1/rewards/admob/ssv', hasQuery: true, host: 'api.example', remoteAddress: '203.0.113.9', remotePort: undefined });
    assert.ok(!text(s).includes('SIG') && !text(s).includes('abcdef') && !text(s).includes('"p"'));
    assert.equal(serializeReq({ method: 'GET', url: '/healthz' }).hasQuery, undefined);
    assert.doesNotThrow(() => serializeReq(undefined));
  });
  it('a phone number inside a path is masked', () => {
    assert.ok(!text(serializeReq({ method: 'GET', url: `/v1/x/${PHONE}` })).includes('9647701234567'));
  });
  it('the response keeps only the status', () => {
    assert.deepEqual(serializeRes({ statusCode: 503, headers: { 'set-cookie': 'a=b' } }), { statusCode: 503 });
    assert.deepEqual(serializeRes(undefined), { statusCode: 0 });
  });
  it('a database error keeps kind/sqlstate/constraint and a masked driver message, never the row value', () => {
    const e = new DbError('unique', { sqlstate: '23505', constraint: 'users_phone_active_uq', driverMessage: `duplicate key. Key (phone_e164)=(${PHONE}) already exists.` });
    const s = serializeErr(e);
    assert.equal(s['kind'], 'unique');
    assert.equal(s['sqlstate'], '23505');
    assert.equal(s['constraint'], 'users_phone_active_uq');
    assert.ok(!text(s).includes('9647701234567'));
    assert.match(String(s['driverMessage']), /Key \(phone_e164\)=\(\[redacted\]\)/);
    assert.equal(typeof s['stack'], 'string');
  });
  it('any other error: name and masked message; odd values do not throw', () => {
    const s = serializeErr(new Error(`failed for ${PHONE} with Bearer abcdef0123456789`));
    assert.ok(!text(s).includes('9647701234567') && !text(s).includes('abcdef0123456789'));
    assert.equal(s['type'], 'Error');
    for (const odd of [null, undefined, 'plain ' + PHONE, 42, {}]) assert.doesNotThrow(() => serializeErr(odd));
    assert.ok(!text(serializeErr('plain ' + PHONE)).includes('9647701234567'));
  });
  it('an Error inside a scrubbed object goes through the error serializer', () => {
    const o = scrubValue({ cause: new DbError('unique', { driverMessage: `Key (phone_e164)=(${PHONE}) already exists` }) });
    assert.ok(!text(o).includes('9647701234567'));
  });
});

describe('describeError and the boot logger', () => {
  it('describeError masks the driver message (it is what scripts, readiness and boot logs print)', () => {
    const d = describeError(new DbError('unique', { sqlstate: '23505', driverMessage: `Key (phone_e164)=(${PHONE}) already exists` }));
    assert.ok(!text(d).includes('9647701234567'));
    assert.equal(d['kind'], 'unique');
    assert.ok(!text(describeError(new Error(`x ${LOCAL}`))).includes(LOCAL));
    assert.ok(!text(describeError(`raw ${PHONE}`)).includes('9647701234567'));
  });
  it('the console (boot) logger applies the same masking to the object and the message', () => {
    const lines: string[] = [];
    const log = createConsoleLogger((l) => lines.push(l));
    log.error({ event: 'boot.failed', password: 'p', err: new DbError('unique', { driverMessage: `Key (phone_e164)=(${PHONE}) already exists` }), target: 'postgres://u:pw@h/db' }, `failed for ${PHONE}`);
    log.warn('plain ' + PHONE);
    const all = lines.join('\n');
    for (const leak of ['9647701234567', '"p"', ':pw@']) assert.ok(!all.includes(leak), leak);
    assert.equal(JSON.parse(lines[0]!).event, 'boot.failed');
  });
});

describe('operational events', () => {
  it('a 5xx response and a slow request become warn events by route pattern, with numbers and method only', () => {
    const e = httpOutcomeEvents({ method: 'POST', route: '/v1/me/rewards', status: 503, durationMs: SLOW_REQUEST_MS + 5.4 });
    assert.deepEqual(e.map((x) => x.obj['event']), ['http.response_5xx', 'http.slow_request']);
    assert.deepEqual(e[0]!.obj, { event: 'http.response_5xx', method: 'POST', route: '/v1/me/rewards', status: 503, durationMs: 3005 });
  });
  it('a normal or client-error response logs nothing extra', () => {
    assert.deepEqual(httpOutcomeEvents({ method: 'GET', route: '/x', status: 200, durationMs: 12 }), []);
    assert.deepEqual(httpOutcomeEvents({ method: 'GET', route: '/x', status: 429, durationMs: SLOW_REQUEST_MS - 1 }), []);
  });
});

describe('pino accepts the options and applies them (CI: pino ships with fastify)', async () => {
  let pino: ((o: unknown, s: unknown) => { info(o: unknown, m?: string): void; error(o: unknown, m?: string): void }) | undefined;
  let reason: string | false = false;
  try {
    const specifier = 'pino'; // a variable, so TypeScript does not need pino's types (it is a transitive dependency of fastify)
    pino = ((await import(specifier)) as { default: typeof pino }).default;
  } catch {
    reason = 'pino is not installed here (it comes with fastify in CI)';
  }
  it('redacts headers, drops the query string, masks driver values and secret-named fields in the real logger', { skip: reason }, () => {
    const lines: string[] = [];
    const log = pino!(buildLoggerOptions('info'), { write: (l: string) => lines.push(l) });
    log.info({ req: { method: 'GET', url: '/a?signature=SIG', headers: { authorization: 'Bearer abcdef0123456789', cookie: 'sid=1' } }, event: 'x', password: 'pw', phone: PHONE }, 'hello ' + 'there');
    log.error({ err: new DbError('unique', { driverMessage: `Key (phone_e164)=(${PHONE}) already exists` }), event: 'y' }, 'failed');
    const all = lines.join('\n');
    for (const leak of ['SIG', 'abcdef0123456789', 'sid=1', '"pw"', '9647701234567']) assert.ok(!all.includes(leak), leak);
    assert.ok(all.includes('"event":"x"') && all.includes('"event":"y"') && all.includes('"kind":"unique"'));
  });
});

describe('the real HTTP server (CI: needs fastify)', async () => {
  type BuildServer = typeof import('../../src/server.ts').buildServer;
  let buildServer: BuildServer | undefined;
  let reason: string | false = false;
  try {
    ({ buildServer } = await import('../../src/server.ts'));
  } catch (e) {
    reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
  }
  const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'info', NODE_ENV: 'test' });
  const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };
  const make = async () => {
    const lines: string[] = [];
    const app = await buildServer!({ config, db: okDb, logStream: { write: (l: string) => void lines.push(l) } });
    return { app, lines, all: () => lines.join('\n') };
  };

  it('never logs a query string, a credential or a quoted phone number, and records the failure as events', { skip: reason }, async () => {
    const h = await make();
    // Routes are added BEFORE the first inject (inject makes the instance ready; a route added afterwards throws
    // FST_ERR_INSTANCE_ALREADY_LISTENING). '/__bad' is a 4xx that goes THROUGH the error handler; a 404 for an unknown path does not
    // (Fastify answers it with the not-found handler, which never logs http.request_rejected).
    h.app.get('/__bad', async () => {
      throw Object.assign(new Error('bad input 07701234567'), { statusCode: 400 });
    });
    h.app.get('/__boom', async () => {
      throw new DbError('unknown', { sqlstate: 'XX000', driverMessage: `Key (phone_e164)=(${PHONE}) already exists` });
    });
    const bad = await h.app.inject({ method: 'GET', url: '/__boom?signature=SIGNATURE-VALUE&user_id=77', headers: { authorization: 'Bearer abcdef0123456789', cookie: 'sid=SESSIONVALUE' } });
    assert.equal(bad.statusCode, 500);
    assert.ok(!bad.body.includes('9647701234567'));
    const nf = await h.app.inject({ method: 'GET', url: '/nope?token=TOKEN-VALUE&otp=123456' });
    assert.equal(nf.statusCode, 404);
    const rej = await h.app.inject({ method: 'GET', url: '/__bad?password=PW-VALUE' });
    assert.equal(rej.statusCode, 400);
    const all = h.all();
    for (const leak of ['SIGNATURE-VALUE', 'TOKEN-VALUE', '123456', 'abcdef0123456789', 'SESSIONVALUE', '9647701234567', '07701234567', 'PW-VALUE', 'user_id=77']) assert.ok(!all.includes(leak), leak);
    const parsed = h.lines.map((l) => JSON.parse(l) as { event?: string; err?: { kind?: string }; code?: string });
    const events = parsed.map((o) => o.event);
    for (const want of ['http.request_failed', 'http.response_5xx', 'http.request_rejected']) assert.ok(events.includes(want), `${want} missing; saw: ${events.filter(Boolean).join(', ')}`);
    assert.equal(parsed.find((o) => o.event === 'http.request_failed')!.err?.kind, 'unknown');
    assert.equal(parsed.find((o) => o.event === 'http.request_rejected')!.code, 'bad_request');
    await h.app.close();
  });

  it('readiness failure is logged with a masked database message and answers without details', { skip: reason }, async () => {
    const lines: string[] = [];
    const down = { ping: async () => { throw new DbError('unavailable', { driverMessage: 'connect ECONNREFUSED 10.0.0.5:5432 for postgres://najaf:S3cr3t@10.0.0.5/db' }); }, checkSchema: async () => ({ missing: [] as string[] }) };
    const app = await buildServer!({ config, db: down, logStream: { write: (l: string) => void lines.push(l) } });
    const r = await app.inject({ method: 'GET', url: '/readyz' });
    assert.equal(r.statusCode, 503);
    const all = lines.join('\n');
    assert.ok(!all.includes('S3cr3t'));
    assert.ok(all.includes('ECONNREFUSED'));
    await app.close();
  });
});

describe('static guards: diagnostic logs and the audit trail stay apart', () => {
  const root = join(import.meta.dirname, '..', '..');
  const walk = (d: string): string[] => readdirSync(d).flatMap((n) => (statSync(join(d, n)).isDirectory() ? walk(join(d, n)) : n.endsWith('.ts') ? [join(d, n)] : []));
  const code = (t: string) => t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  const files = walk(join(root, 'src')).map((f) => ({ f: f.slice(root.length + 1), t: code(readFileSync(f, 'utf8')) }));

  it('no log call passes a secret-named field (password, token, otp, phone, signature, cookie, authorization, hash, secret)', () => {
    const call = /\b(?:log|logger|boot|app\.log|request\.log)\??\.(?:debug|info|warn|error)\(\s*\{([^}]*)\}/g;
    const bad = /\b(password|newPassword|currentPassword|token|accessToken|refreshToken|otp|code_hash|phone|phoneE164|signature|cookie|authorization|secret|hash|passwordHash)\s*[:,}]/;
    for (const { f, t } of files) for (const m of t.matchAll(call)) assert.ok(!bad.test(m[1]!), `${f}: ${m[0].slice(0, 120)}`);
  });
  it('the logging module writes no audit row and touches no database; the audit writer stays the only audit_logs writer', () => {
    const l = files.find((x) => x.f === 'src/logging.ts')!.t;
    assert.doesNotMatch(l, /audit_logs|INSERT|\.query\(|from '\.\/db\.ts'|from '\.\/auth\//);
    const writers = files.filter((x) => /INSERT\s+INTO\s+audit_logs/i.test(x.t)).map((x) => x.f);
    assert.deepEqual(writers, ['src/auth/repository.ts']);
  });
  it('the server logger comes from buildLoggerOptions (no ad-hoc redaction list, no raw request serializer)', () => {
    const s = files.find((x) => x.f === 'src/server.ts')!.t;
    assert.match(s, /logger:\s*buildLoggerOptions\(/);
    assert.doesNotMatch(s, /redact:\s*\{/);
  });
  it('event names follow <area>.<event> in lower case', () => {
    for (const { f, t } of files) for (const m of t.matchAll(/[{,]\s*event:\s*'([^']+)'\s*[,}]/g)) assert.match(m[1]!, /^[a-z0-9_]+(\.[a-z0-9_]+)+$/, `${f}: ${m[1]}`);
  });
});

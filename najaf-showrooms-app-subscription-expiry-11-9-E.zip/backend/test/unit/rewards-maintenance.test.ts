// Phase 11.8-G: the reward-grant maintenance job. The service over an in-memory repository that follows the SQL's rules (what is
// eligible, what is never touched, bounded batches, failures that stop a run and a rerun that continues), the SQL builders, the
// command-line parser, and static guards (operator-run only: no route, no scheduler, nothing in the server).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { DbError } from '../../src/errors.ts';
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { Db } from '../../src/db.ts';
import { MAINTENANCE_DEFAULTS, MaintenanceOptionsError, resolveMaintenanceOptions, runRewardMaintenance } from '../../src/rewards/maintenance.ts';
import { buildExpireBatch, buildPurgeBatch, createPgMaintenanceRepository } from '../../src/rewards/maintenance-repository.ts';
import type { ExpireBatchResult, MaintenanceRepository } from '../../src/rewards/maintenance-repository.ts';
import { parseMaintenanceArgs } from '../../scripts/rewards-maintenance.ts';

const DAY = 86400;
type G = { id: number; status: 'requested' | 'verified' | 'consumed' | 'expired' | 'failed'; carId: number | null; expiredAgoSec: number };
/** A repository over plain rows. expiredAgoSec > 0 = expired that long ago; <= 0 = still valid. */
function fake(rows: G[], opts: { failOn?: string; failTimes?: number; auditFails?: boolean } = {}) {
  const calls: string[] = [];
  const audit: Record<string, number>[] = [];
  let fails = opts.failTimes ?? 1;
  const maybeFail = (name: string) => {
    if (opts.failOn === name && fails > 0) {
      fails--;
      throw new DbError('unavailable');
    }
  };
  const expirable = (g: G) => (g.status === 'requested' || g.status === 'verified') && g.carId === null && g.expiredAgoSec >= 0;
  const purgeable = (g: G, ret: number) => (g.status === 'expired' || g.status === 'failed') && g.carId === null && g.expiredAgoSec > ret;
  const repo: MaintenanceRepository = {
    async countExpirable() {
      calls.push('countExpirable');
      maybeFail('countExpirable');
      const r: ExpireBatchResult = { requested: 0, verified: 0 };
      for (const g of rows) if (expirable(g)) g.status === 'requested' ? r.requested++ : r.verified++;
      return r;
    },
    async countPurgeable(ret) {
      calls.push('countPurgeable');
      return rows.filter((g) => purgeable(g, ret)).length;
    },
    async expireBatch(limit) {
      calls.push('expireBatch');
      maybeFail('expireBatch');
      const r: ExpireBatchResult = { requested: 0, verified: 0 };
      for (const g of rows.filter(expirable).slice(0, limit)) {
        g.status === 'requested' ? r.requested++ : r.verified++;
        g.status = 'expired';
      }
      return r;
    },
    async purgeBatch(limit, ret) {
      calls.push('purgeBatch');
      maybeFail('purgeBatch');
      const hit = rows.filter((g) => purgeable(g, ret)).slice(0, limit);
      for (const g of hit) rows.splice(rows.indexOf(g), 1);
      return hit.length;
    },
    async recordRun(a) {
      calls.push('recordRun');
      if (opts.auditFails) throw new Error('audit down');
      assertAuditSafe({ action: 'reward_maintenance.run', actorUserId: null, actorRole: 'system', entityType: 'reward_maintenance', entityId: '0', afterData: a });
      audit.push(a);
    },
  };
  return { repo, rows, calls, audit };
}
const mk = (n: number, status: G['status'], expiredAgoSec: number, carId: number | null = null, from = 0): G[] =>
  Array.from({ length: n }, (_, i) => ({ id: from + i, status, carId, expiredAgoSec }));
const logs = () => {
  const out: { level: string; o: Record<string, unknown> }[] = [];
  return { out, logger: { info: (o: object) => out.push({ level: 'info', o: o as Record<string, unknown> }), warn: (o: object) => out.push({ level: 'warn', o: o as Record<string, unknown> }), error: (o: object) => out.push({ level: 'error', o: o as Record<string, unknown> }) } };
};

describe('options', () => {
  it('defaults to a dry run with the documented bounds', () => {
    const o = resolveMaintenanceOptions();
    assert.equal(o.dryRun, true);
    assert.deepEqual({ b: o.batchSize, m: o.maxBatches, r: o.retentionDays, a: o.alertVerifiedLost }, { b: 500, m: 10, r: 30, a: 10 });
    assert.equal(resolveMaintenanceOptions({ dryRun: false }).dryRun, false);
  });
  it('refuses out-of-range values, a retention under 7 days, and a run with nothing selected', () => {
    for (const bad of [{ batchSize: 0 }, { batchSize: 1001 }, { maxBatches: 101 }, { retentionDays: 6 }, { retentionDays: 366 }, { alertVerifiedLost: 0 }, { batchSize: 1.5 }]) {
      assert.throws(() => resolveMaintenanceOptions(bad), MaintenanceOptionsError, JSON.stringify(bad));
    }
    assert.throws(() => resolveMaintenanceOptions({ expire: false, purge: false }), (e: unknown) => (e as MaintenanceOptionsError).problems.includes('nothingToDo'));
  });
});

describe('command line', () => {
  it('parses flags and numbers; dry-run unless --execute', () => {
    assert.equal(parseMaintenanceArgs([]).dryRun, true);
    const o = parseMaintenanceArgs(['--execute', '--batch-size=50', '--max-batches=3', '--retention-days=14', '--alert-verified-lost=2', '--skip-purge']);
    assert.deepEqual([o.dryRun, o.batchSize, o.maxBatches, o.retentionDays, o.alertVerifiedLost, o.expire, o.purge], [false, 50, 3, 14, 2, true, false]);
  });
  it('names the offending arguments without echoing values', () => {
    for (const argv of [['--batch-size=abc'], ['--retention-days=3'], ['--execute=1'], ['--nope'], ['x'], ['--skip-expire', '--skip-purge']]) {
      assert.throws(() => parseMaintenanceArgs(argv), (e: unknown) => {
        assert.ok(e instanceof MaintenanceOptionsError);
        assert.ok(!JSON.stringify(e.problems).includes('abc'));
        return e.problems.length > 0;
      });
    }
  });
});

describe('expire and purge', () => {
  it('a dry run counts and changes nothing, writes no audit row', async () => {
    const f = fake([...mk(3, 'requested', 10), ...mk(2, 'verified', 10, null, 10), ...mk(4, 'expired', 40 * DAY, null, 20)]);
    const before = JSON.stringify(f.rows);
    const r = await runRewardMaintenance({ repo: f.repo }, {});
    assert.equal(r.dryRun, true);
    assert.equal(r.expire?.eligible, 5);
    assert.equal(r.purge?.eligible, 4);
    assert.equal(JSON.stringify(f.rows), before);
    assert.ok(!f.calls.includes('expireBatch') && !f.calls.includes('purgeBatch') && !f.calls.includes('recordRun'));
    assert.deepEqual(r.alerts, []);
  });
  it('expires past-expiry requested/verified grants and leaves valid, consumed and ad-holding ones alone', async () => {
    const f = fake([
      ...mk(2, 'requested', 5), // expired a moment ago
      ...mk(1, 'verified', 5, null, 10),
      ...mk(2, 'requested', -600, null, 20), // still valid
      ...mk(2, 'consumed', 5 * DAY, 77, 30), // consumed: never touched, however old
      ...mk(1, 'verified', 5, 55, 40), // holds an ad (cannot happen, but is never touched)
    ]);
    const r = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, purge: false });
    assert.deepEqual([r.expire?.expired, r.expire?.expiredVerified, r.expire?.complete], [3, 1, true]);
    assert.equal(r.purge, null);
    assert.equal(f.rows.filter((g) => g.status === 'expired').length, 3);
    assert.equal(f.rows.filter((g) => g.status === 'consumed').length, 2);
    assert.equal(f.rows.filter((g) => g.status === 'requested' && g.expiredAgoSec < 0).length, 2);
    assert.equal(r.error, null);
  });
  it('purges only expired/failed, unbound grants older than the retention; never consumed ones', async () => {
    const f = fake([
      ...mk(2, 'expired', 31 * DAY), // old enough
      ...mk(1, 'failed', 31 * DAY, null, 10),
      ...mk(2, 'expired', 29 * DAY, null, 20), // too recent
      ...mk(2, 'consumed', 400 * DAY, 9, 30), // never
      ...mk(1, 'requested', 400 * DAY, null, 40), // not dead yet: the expire phase handles it first
    ]);
    const r = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, expire: false });
    assert.equal(r.purge?.deleted, 3);
    assert.equal(f.rows.length, 5);
    assert.equal(f.rows.filter((g) => g.status === 'consumed').length, 2);
  });
  it('expire runs before purge, so a long-dead requested grant is expired and purged in the same run', async () => {
    const f = fake(mk(2, 'requested', 40 * DAY));
    const r = await runRewardMaintenance({ repo: f.repo }, { dryRun: false });
    assert.deepEqual([r.expire?.expired, r.purge?.deleted, f.rows.length], [2, 2, 0]);
  });
  it('a retention shorter than 7 days is refused before any change', async () => {
    const f = fake(mk(2, 'expired', 3 * DAY));
    await assert.rejects(runRewardMaintenance({ repo: f.repo }, { dryRun: false, retentionDays: 2 }), MaintenanceOptionsError);
    assert.equal(f.calls.length, 0);
  });
});

describe('bounds, repeat safety, failures', () => {
  it('stops at maxBatches, says so, and the next run continues', async () => {
    const f = fake(mk(25, 'requested', 5));
    const first = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, batchSize: 10, maxBatches: 2, purge: false });
    assert.deepEqual([first.expire?.expired, first.expire?.complete, first.expire?.batches], [20, false, 2]);
    assert.deepEqual(first.alerts.map((a) => a.code), ['backlog_remaining']);
    const second = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, batchSize: 10, maxBatches: 2, purge: false });
    assert.deepEqual([second.expire?.expired, second.expire?.complete], [5, true]);
    assert.deepEqual(second.alerts, []);
    const third = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, purge: false });
    assert.equal(third.expire?.expired, 0);
  });
  it('a database failure stops the run with a code, keeps what was done, and a retry finishes the job', async () => {
    const f = fake(mk(25, 'requested', 5), { failOn: 'expireBatch', failTimes: 1 });
    // Fails on the first call: nothing done.
    const a = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, batchSize: 10, purge: false });
    assert.equal(a.error, 'database_unavailable');
    assert.equal(a.expire?.expired, 0);
    assert.equal(f.rows.filter((g) => g.status === 'expired').length, 0);
    assert.equal(f.audit.length, 1); // the failed run is audited too
    assert.equal(f.audit[0]?.['stopped'], 1);
    const b = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, batchSize: 10, purge: false });
    assert.equal(b.error, null);
    assert.equal(b.expire?.expired, 25);
    assert.equal(f.rows.every((g) => g.status === 'expired'), true);
  });
  it('a failure in the purge phase keeps the expire phase result; a rerun purges', async () => {
    const f = fake([...mk(3, 'requested', 40 * DAY), ...mk(2, 'expired', 40 * DAY, null, 10)], { failOn: 'purgeBatch', failTimes: 1 });
    const a = await runRewardMaintenance({ repo: f.repo }, { dryRun: false });
    assert.deepEqual([a.error, a.expire?.expired, a.purge?.deleted], ['database_unavailable', 3, 0]);
    assert.equal(f.rows.length, 5);
    const b = await runRewardMaintenance({ repo: f.repo }, { dryRun: false });
    assert.deepEqual([b.error, b.expire?.expired, b.purge?.deleted, f.rows.length], [null, 0, 5, 0]);
  });
  it('a non-database error is reported as unexpected, without its message', async () => {
    const f = fake([]);
    f.repo.expireBatch = async () => {
      throw new Error('secret connection string');
    };
    const r = await runRewardMaintenance({ repo: f.repo }, { dryRun: false });
    assert.equal(r.error, 'unexpected');
    assert.ok(!JSON.stringify(r).includes('secret'));
  });
  it('a failing audit write is reported but does not undo the work', async () => {
    const f = fake(mk(3, 'requested', 5), { auditFails: true });
    const r = await runRewardMaintenance({ repo: f.repo }, { dryRun: false, purge: false });
    assert.equal(r.error, 'audit_unavailable');
    assert.equal(r.expire?.expired, 3);
    assert.equal(f.rows.every((g) => g.status === 'expired'), true);
  });
  it('an executed run writes exactly one audit row with numbers only', async () => {
    const f = fake([...mk(2, 'requested', 5), ...mk(1, 'verified', 5, null, 5), ...mk(1, 'expired', 40 * DAY, null, 9)]);
    await runRewardMaintenance({ repo: f.repo }, { dryRun: false });
    assert.equal(f.audit.length, 1);
    assert.deepEqual(f.audit[0], { expired: 3, expiredVerified: 1, purged: 1, retentionDays: 30, stopped: 0, alerts: 0 });
    assert.ok(Object.values(f.audit[0]!).every((v) => typeof v === 'number'));
  });
});

describe('alerts', () => {
  it('raises verified_rewards_expired_unused at the threshold, logs it, and never on a dry run', async () => {
    const f = fake(mk(12, 'verified', 5));
    const l = logs();
    const dry = await runRewardMaintenance({ repo: f.repo, logger: l.logger }, { alertVerifiedLost: 10 });
    assert.deepEqual(dry.alerts, []);
    const r = await runRewardMaintenance({ repo: f.repo, logger: l.logger }, { dryRun: false, alertVerifiedLost: 10 });
    assert.deepEqual(r.alerts, [{ code: 'verified_rewards_expired_unused', value: 12, threshold: 10 }]);
    assert.ok(l.out.some((x) => x.level === 'warn' && x.o['event'] === 'reward_maintenance.alert'));
    assert.equal(f.audit[0]?.['alerts'], 1);
  });
  it('stays quiet below the threshold and reports failures as an error event', async () => {
    const f = fake(mk(3, 'verified', 5));
    const l = logs();
    assert.deepEqual((await runRewardMaintenance({ repo: f.repo, logger: l.logger }, { dryRun: false, alertVerifiedLost: 10 })).alerts, []);
    const g = fake(mk(1, 'requested', 5), { failOn: 'expireBatch' });
    await runRewardMaintenance({ repo: g.repo, logger: l.logger }, { dryRun: false });
    assert.ok(l.out.some((x) => x.level === 'error' && x.o['code'] === 'database_unavailable'));
  });
  it('nothing in the report or the logs carries a user id, a grant id or a transaction id', async () => {
    const f = fake(mk(4, 'verified', 5));
    const l = logs();
    const r = await runRewardMaintenance({ repo: f.repo, logger: l.logger }, { dryRun: false, alertVerifiedLost: 1 });
    const text = JSON.stringify([r, l.out]);
    assert.ok(!/userId|grantId|transaction|ssv/i.test(text));
  });
});

describe('SQL', () => {
  it('expire: literal target status, locked skip-locked batch, unbound and past expiry only', () => {
    const s = buildExpireBatch(500);
    assert.match(s.text, /SET status = 'expired'/);
    assert.match(s.text, /status IN \('requested', 'verified'\) AND car_id IS NULL AND expires_at <= now\(\)/);
    assert.match(s.text, /FOR UPDATE SKIP LOCKED/);
    assert.match(s.text, /g\.status = c\.status AND g\.car_id IS NULL/);
    assert.doesNotMatch(s.text, /consumed/);
    assert.deepEqual(s.values, [500]);
  });
  it('purge: never consumed, never a grant holding an ad, retention from the database clock', () => {
    const s = buildPurgeBatch(100, 30 * DAY);
    assert.match(s.text, /^DELETE FROM reward_grants/);
    assert.match(s.text, /status IN \('expired', 'failed'\)/);
    assert.match(s.text, /car_id IS NULL/);
    assert.match(s.text, /expires_at < now\(\) - \(\$2::int \* interval '1 second'\)/);
    assert.match(s.text, /FOR UPDATE SKIP LOCKED/);
    assert.doesNotMatch(s.text, /consumed/);
    assert.deepEqual(s.values, [100, 30 * DAY]);
  });
  it('audit row: through the single audit writer, system actor with no user id, numbers only', async () => {
    const seen: { text: string; values: readonly unknown[] }[] = [];
    const db = { query: async (text: string, values: readonly unknown[] = []) => (seen.push({ text, values }), { rows: [], rowCount: 0 }) } as unknown as Db;
    await createPgMaintenanceRepository(db).recordRun({ expired: 1, expiredVerified: 1, purged: 1, retentionDays: 30, stopped: 0, alerts: 0 });
    assert.equal(seen.length, 1);
    assert.match(seen[0]!.text, /^\s*INSERT INTO audit_logs/);
    assert.deepEqual(seen[0]!.values, [null, 'system', 'reward_maintenance.run', 'reward_maintenance', '0', '{"expired":1,"expiredVerified":1,"purged":1,"retentionDays":30,"stopped":0,"alerts":0}', null]);
    await assert.rejects(createPgMaintenanceRepository(db).recordRun({ token: 1 }), /not allowed/);
    await assert.rejects(createPgMaintenanceRepository(db).recordRun({ expired: 'x' as unknown as number }), /must be a number/);
    assert.equal(seen.length, 1);
  });
  it('defaults are the documented ones', () => {
    assert.deepEqual({ ...MAINTENANCE_DEFAULTS }, { batchSize: 500, maxBatches: 10, retentionDays: 30, alertVerifiedLost: 10 });
  });
});

describe('static guards: operator-run only', () => {
  const root = join(import.meta.dirname, '..', '..');
  const read = (p: string) => readFileSync(join(root, p), 'utf8');
  const walk = (d: string): string[] => readdirSync(d).flatMap((n) => (statSync(join(d, n)).isDirectory() ? walk(join(d, n)) : [join(d, n)]));
  it('the maintenance module is imported by no server code, route or index', () => {
    for (const f of walk(join(root, 'src')).filter((p) => p.endsWith('.ts'))) {
      if (f.endsWith('rewards/maintenance.ts') || f.endsWith('rewards/maintenance-repository.ts')) continue;
      assert.doesNotMatch(readFileSync(f, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, ''), /rewards\/maintenance|from '\.\/maintenance/, f);
    }
  });
  it('no HTTP, timer, queue or external call in the maintenance code', () => {
    for (const p of ['src/rewards/maintenance.ts', 'src/rewards/maintenance-repository.ts']) {
      const t = read(p).replace(/^\/\/.*$/gm, '');
      assert.doesNotMatch(t, /fastify|setInterval|setTimeout|node:http|fetch\(|child_process|cron/i, p);
    }
  });
  it('is wired as an npm script and the unconfigured messaging provider is not used for alerts', () => {
    assert.match(read('package.json'), /"rewards:maintenance": ".*scripts\/rewards-maintenance\.ts"/);
    assert.doesNotMatch(read('src/rewards/maintenance.ts').replace(/^\/\/.*$/gm, ''), /messaging|MessagingProvider|whatsapp|sms/i);
  });
  it('touches only reward_grants (the audit row goes through the single audit writer)', () => {
    const t = read('src/rewards/maintenance-repository.ts').replace(/\/\/.*$/gm, '');
    const tables = new Set([...t.matchAll(/(?:FROM|INTO|UPDATE)\s+([a-z_]+)\b/g)].map((m) => m[1]).filter((x) => x !== 'c'));
    for (const x of tables) assert.equal(x, 'reward_grants');
  });
});

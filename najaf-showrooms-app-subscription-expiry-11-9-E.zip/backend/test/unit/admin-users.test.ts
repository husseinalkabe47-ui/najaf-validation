// Phase 11.7.2-J: the administrators' account directory and dashboard statistics. The service and policy run for real over an
// in-memory repository; the HTTP layer runs WITHOUT Fastify (routes on a recording stand-in) with the REAL authentication service.
// Plus SQL and source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError, can, isPublic, platformStatsResource, userDirectoryResource } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { ADMIN_USERS_RATE_LIMITS, registerAdminUsersRoutes, toAdminUsersHttp } from '../../src/admin-users/routes.ts';
import { AdminUsersError, createAdminUsersService, MEMBER_CARS_MAX } from '../../src/admin-users/service.ts';
import { buildCountMemberCarsOfOwner, buildFindShowroomOfOwner, buildFindUser, buildListMemberCarsOfOwner, buildListUsers, STATS_SQL } from '../../src/admin-users/repository.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeAdminUsersRepo } from '../helpers/fake-admin-users.ts';

const ADMIN: Actor = Object.freeze({ id: '1', role: 'admin' });
const MEMBER: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const SECRET_KEYS = /password|hash|failed|lock|session|token|otp|verification|code|deleted|version|updated/i;
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const isValidation = (e: unknown) => e instanceof AdminUsersError && e.code === 'validation_failed';

function world() {
  const f = makeFakeAdminUsersRepo();
  const svc = createAdminUsersService({ repo: f.repo });
  return { f, svc };
}

describe('admin users: least-privilege policy', () => {
  it('user_directory and platform_stats: read for administrators only; no other action for anyone; never public', () => {
    for (const r of [userDirectoryResource(), platformStatsResource()]) {
      assert.equal(can(ADMIN, 'read', r), true);
      for (const a of ['update', 'delete', 'moderate'] as const) assert.equal(can(ADMIN, a, r), false, `${r.kind}/${a}`);
      for (const who of [MEMBER, DEALER, null]) for (const a of ['read', 'update', 'delete', 'moderate'] as const) assert.equal(can(who, a, r), false);
      assert.equal(isPublic(r), false);
    }
  });

  it('a member, a dealer and a caller with no actor get the same 404 on list, details and stats, before anything is read', async () => {
    const { f, svc } = world();
    f.addUser();
    for (const who of [MEMBER, DEALER, null]) {
      await assert.rejects(svc.listUsers(who, {}), isNotFound);
      await assert.rejects(svc.listUsers(who, { bogus: 'x' }), isNotFound, 'authorization before validation');
      await assert.rejects(svc.getUser(who, '1'), isNotFound);
      await assert.rejects(svc.getStats(who), isNotFound);
    }
    assert.deepEqual(f.calls, []);
  });
});

describe('admin users: list', () => {
  it('returns exactly {id, name, phone, email, role, status, createdAt} for each account: never a hash, counter or lock', async () => {
    const { f, svc } = world();
    f.addUser({ name: 'مدير المنصة', role: 'admin', email: 'a@example.com' });
    f.addUser({ role: 'dealer', status: 'pending' });
    const out = await svc.listUsers(ADMIN, {});
    assert.equal(out.users.length, 2);
    for (const u of out.users) {
      assert.deepEqual(Object.keys(u).sort(), ['createdAt', 'email', 'id', 'name', 'phone', 'role', 'status']);
      for (const k of Object.keys(u)) assert.ok(!SECRET_KEYS.test(k), k);
    }
    assert.ok(!/SECRET-HASH|argon2/.test(JSON.stringify(out)));
    assert.deepEqual(out.users[0], { id: '1', name: 'مدير المنصة', phone: '+9647700000001', email: 'a@example.com', role: 'admin', status: 'active', createdAt: '2026-01-01T00:00:00.000Z' });
  });

  it('role filter (user | dealer | admin, or all) and soft-deleted accounts are left out', async () => {
    const { f, svc } = world();
    f.addUser({ role: 'admin' }); f.addUser(); f.addUser({ role: 'dealer' }); f.addUser({ role: 'dealer', status: 'pending' }); f.addUser({ deleted: true });
    assert.deepEqual((await svc.listUsers(ADMIN, {})).users.map((u) => u.id), ['1', '2', '3', '4']);
    assert.deepEqual((await svc.listUsers(ADMIN, { role: 'dealer' })).users.map((u) => u.id), ['3', '4']);
    assert.deepEqual((await svc.listUsers(ADMIN, { role: 'user' })).users.map((u) => u.id), ['2']);
    assert.deepEqual((await svc.listUsers(ADMIN, { role: 'admin' })).users.map((u) => u.id), ['1']);
  });

  it('keyset pagination: limit, nextAfter, after; the last page has nextAfter null; default 50, max 100', async () => {
    const { f, svc } = world();
    for (let i = 0; i < 5; i++) f.addUser();
    const p1 = await svc.listUsers(ADMIN, { limit: '2' });
    assert.deepEqual([p1.users.map((u) => u.id), p1.nextAfter], [['1', '2'], '2']);
    const p2 = await svc.listUsers(ADMIN, { limit: '2', after: p1.nextAfter! });
    assert.deepEqual([p2.users.map((u) => u.id), p2.nextAfter], [['3', '4'], '4']);
    const p3 = await svc.listUsers(ADMIN, { limit: '2', after: p2.nextAfter! });
    assert.deepEqual([p3.users.map((u) => u.id), p3.nextAfter], [['5'], null]);
    for (let i = 0; i < 120; i++) f.addUser();
    assert.equal((await svc.listUsers(ADMIN, {})).users.length, 50);
    assert.equal((await svc.listUsers(ADMIN, { limit: '100' })).users.length, 100);
  });

  it('invalid query is 400 with field codes only (unknown key, role, after, limit), and never reaches the repository', async () => {
    const { f, svc } = world();
    for (const q of [{ status: 'active' }, { role: 'superadmin' }, { role: ['user'] }, { after: '0' }, { after: 'abc' }, { limit: '0' }, { limit: '101' }, { limit: '1.5' }, { password: 'x' }, 'x']) {
      await assert.rejects(svc.listUsers(ADMIN, q), isValidation, JSON.stringify(q));
    }
    assert.deepEqual(f.calls, []);
  });
});

describe('admin users: one account', () => {
  it("a dealer's view: the account fields, its showroom {id, name, status} and its member ads {id, brand, model, status}, newest first", async () => {
    const { f, svc } = world();
    const d = f.addUser({ role: 'dealer', name: 'حيدر' });
    f.addShowroom(d.id, { name: 'معرض الكوفة', status: 'pending' });
    const c1 = f.addCar({ sourceType: 'member', ownerId: d.id, status: 'sold' });
    const c2 = f.addCar({ sourceType: 'member', ownerId: d.id, brand: 'Toyota', model: 'Camry', status: 'pending' });
    f.addCar({ sourceType: 'member', ownerId: d.id, deleted: true });
    f.addCar({ sourceType: 'showroom', showroomId: '900' });
    const out = await svc.getUser(ADMIN, d.id);
    assert.deepEqual(Object.keys(out).sort(), ['memberCars', 'memberCarsTotal', 'showroom', 'user']);
    assert.deepEqual(Object.keys(out.user).sort(), ['createdAt', 'email', 'id', 'name', 'phone', 'role', 'status']);
    assert.deepEqual(out.showroom, { id: '900', name: 'معرض الكوفة', status: 'pending' });
    assert.deepEqual(out.memberCars, [{ id: c2.id, brand: 'Toyota', model: 'Camry', status: 'pending' }, { id: c1.id, brand: 'Kia', model: 'Rio', status: 'sold' }]);
    assert.equal(out.memberCarsTotal, 2);
    assert.ok(!/SECRET-HASH|argon2|failedLogins|lockedUntil|ownerId|showroomId|deleted/.test(JSON.stringify(out)));
  });

  it('a member has no showroom lookup; an admin account is shown too; at most 100 ads with the real total', async () => {
    const { f, svc } = world();
    const m = f.addUser();
    for (let i = 0; i < MEMBER_CARS_MAX + 5; i++) f.addCar({ sourceType: 'member', ownerId: m.id });
    const out = await svc.getUser(ADMIN, m.id);
    assert.equal(out.showroom, null);
    assert.ok(!f.calls.includes('findShowroomOfOwner'));
    assert.equal(out.memberCars.length, MEMBER_CARS_MAX);
    assert.equal(out.memberCarsTotal, MEMBER_CARS_MAX + 5);
    const a = f.addUser({ role: 'admin' });
    assert.equal((await svc.getUser(ADMIN, a.id)).user.role, 'admin');
  });

  it('an unknown, a soft-deleted and a malformed id are the same 404; a malformed one never reaches the repository', async () => {
    const { f, svc } = world();
    const gone = f.addUser({ deleted: true });
    await assert.rejects(svc.getUser(ADMIN, '999999'), isNotFound);
    await assert.rejects(svc.getUser(ADMIN, gone.id), isNotFound);
    f.calls.length = 0;
    for (const id of ['abc', '0', '-1', '01', ' 1', '1;DROP', undefined, null, 1, {}, ['1']]) await assert.rejects(svc.getUser(ADMIN, id), isNotFound, JSON.stringify(id));
    assert.deepEqual(f.calls, []);
  });
});

describe('admin users: statistics', () => {
  it('the ten dashboard counts, computed from the records (soft-deleted rows excluded), and nothing else', async () => {
    const { f, svc } = world();
    f.addUser({ role: 'admin' }); const d1 = f.addUser({ role: 'dealer' }); f.addUser({ role: 'dealer', status: 'pending' }); f.addUser({ role: 'dealer', status: 'pending' });
    const m = f.addUser(); f.addUser({ deleted: true }); f.addUser({ role: 'dealer', status: 'pending', deleted: true });
    f.addShowroom(d1.id); f.addShowroom('77', { status: 'suspended' });
    for (const st of ['pending', 'pending', 'active', 'sold', 'rejected', 'suspended', 'active']) f.addCar({ sourceType: 'member', ownerId: m.id, status: st });
    f.addCar({ sourceType: 'member', ownerId: m.id, status: 'active', deleted: true });
    f.addCar({ sourceType: 'showroom', showroomId: '900', status: 'available' }); f.addCar({ sourceType: 'showroom', showroomId: '900', status: 'sold' }); f.addCar({ sourceType: 'showroom', showroomId: '900', deleted: true });
    const s = await svc.getStats(ADMIN);
    assert.deepEqual(s, {
      totalUsers: 5, totalShowrooms: 2, totalShowroomCars: 2, totalMemberCars: 7,
      pendingMemberCars: 2, activeMemberCars: 2, soldMemberCars: 1, rejectedMemberCars: 1, suspendedMemberCars: 1, pendingDealers: 2,
    });
    for (const v of Object.values(s)) assert.ok(Number.isInteger(v) && v >= 0);
  });
});

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };

function http(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: 'unit-test-access-secret-0123456789abcdef-XYZ', logger: recordingLogger().logger, now: clock.now });
  const f = makeFakeAdminUsersRepo();
  const adminUsers = createAdminUsersService({ repo: f.repo });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  registerAdminUsersRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, adminUsers, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const sent: Sent = { headers: {} };
    const reply = { code: (c: number) => ((sent.status = c), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  async function account(role: 'member' | 'dealer' | 'pendingDealer' | 'admin') {
    const r = role === 'dealer' || role === 'pendingDealer' ? await auth.registerDealer({ name: 'تاجر', phone: phone(), password: 'Corr3ct-Horse-Battery' }) : await auth.register({ name: 'حساب', phone: phone(), password: 'Corr3ct-Horse-Battery' });
    const u = db.users().find((x) => x.id === r.user.id)!;
    if (role === 'dealer') u.status = 'active';
    if (role === 'admin') u.role = 'admin';
    return { authorization: `Bearer ${r.session.accessToken}` };
  }
  return { routes, call, account, f, db };
}

describe('admin users: HTTP', () => {
  it('registers exactly three GET routes (no write route), each rate limited when a limiter is supplied', () => {
    const { routes } = http(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), ['GET /v1/admin/stats', 'GET /v1/admin/users', 'GET /v1/admin/users/:id']);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
  });

  it('401 without or with a bad token; 404 (identical to an unknown account) for a member, an active dealer and a pending dealer', async () => {
    const s = http();
    for (const [path, params] of [['/v1/admin/users', {}], ['/v1/admin/users/:id', { id: '1' }], ['/v1/admin/stats', {}]] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const r = await s.call('GET', path, { headers, params });
        assert.equal(r.status, 401); assert.equal(r.headers['www-authenticate'], 'Bearer');
      }
    }
    const adminH = await s.account('admin');
    const unknown = await s.call('GET', '/v1/admin/users/:id', { headers: adminH, params: { id: '999999' } });
    assert.equal(unknown.status, 404);
    s.f.calls.length = 0;
    for (const role of ['member', 'dealer', 'pendingDealer'] as const) {
      const h = await s.account(role);
      for (const [path, params] of [['/v1/admin/users', {}], ['/v1/admin/users/:id', { id: '1' }], ['/v1/admin/stats', {}]] as const) {
        const r = await s.call('GET', path, { headers: h, params });
        assert.equal(r.status, 404, `${role} ${path}`);
        assert.deepEqual(r.body, unknown.body);
      }
    }
    assert.deepEqual(s.f.calls, []);
  });

  it('an administrator gets {users, nextAfter}, {user, showroom, memberCars, memberCarsTotal} and {stats}; a bad query is 400 with fields', async () => {
    const s = http();
    const h = await s.account('admin');
    const u = s.f.addUser({ role: 'dealer' });
    const list = await s.call('GET', '/v1/admin/users', { headers: h, query: { role: 'dealer' } });
    assert.equal(list.status, 200); assert.deepEqual(Object.keys(list.body as object).sort(), ['nextAfter', 'users']);
    const one = await s.call('GET', '/v1/admin/users/:id', { headers: h, params: { id: u.id } });
    assert.equal(one.status, 200); assert.deepEqual(Object.keys(one.body as object).sort(), ['memberCars', 'memberCarsTotal', 'showroom', 'user']);
    const st = await s.call('GET', '/v1/admin/stats', { headers: h });
    assert.equal(st.status, 200); assert.equal(Object.keys((st.body as { stats: object }).stats).length, 10);
    const bad = await s.call('GET', '/v1/admin/users', { headers: h, query: { role: 'root', page: '2' } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as { error: { fields: unknown } }).error.fields, [{ field: 'page', code: 'unknown_field' }, { field: 'role', code: 'invalid_format' }]);
    assert.ok(!/SECRET-HASH|argon2/.test(JSON.stringify([list.body, one.body, st.body])));
  });

  it('reads have a budget per address (429 with Retry-After)', async () => {
    const s = http(true);
    const h = await s.account('admin');
    for (let i = 0; i < ADMIN_USERS_RATE_LIMITS.read.limit; i++) assert.equal((await s.call('GET', '/v1/admin/stats', { headers: h })).status, 200);
    const denied = await s.call('GET', '/v1/admin/stats', { headers: h });
    assert.equal(denied.status, 429); assert.ok(Number(denied.headers['retry-after']) > 0);
  });

  it('maps errors: validation 400 with fields, authz 404, anything else not ours', () => {
    assert.equal(toAdminUsersHttp(new AdminUsersError([{ field: 'role', code: 'invalid_format' }]))?.status, 400);
    assert.equal(toAdminUsersHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toAdminUsersHttp(new Error('boom')), undefined);
  });
});

describe('admin users: SQL and source guards', () => {
  it('the directory never selects a secret column, never SELECT *, writes nothing, and leaves out soft-deleted rows', () => {
    const src = code('src/admin-users/repository.ts');
    assert.ok(!/SELECT\s+\*/i.test(src));
    assert.ok(!/password_hash|failed_logins|locked_until|last_login_at|sessions|verification_codes|refresh|token/i.test(src));
    assert.ok(!/\b(INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/i.test(src), 'read only');
    for (const s of [buildListUsers({ role: null, afterId: null, limit: 50 }), buildFindUser('1')]) {
      assert.match(s.text, /u\.deleted_at IS NULL/);
      assert.match(s.text, /^SELECT u\.id, u\.name, u\.phone_e164, u\.email, u\.role, u\.status, u\.created_at/);
    }
  });

  it('every value is a parameter: role, keyset, limit, ids', () => {
    assert.deepEqual(buildListUsers({ role: 'dealer', afterId: '7', limit: 10 }).values, ['dealer', '7', 10]);
    assert.match(buildListUsers({ role: null, afterId: null, limit: 1 }).text, /\(\$1::text IS NULL OR u\.role = \$1::text\)[\s\S]*\(\$2::bigint IS NULL OR u\.id > \$2::bigint\)[\s\S]*ORDER BY u\.id[\s\S]*LIMIT \$3::int/);
    assert.deepEqual(buildFindShowroomOfOwner('4').values, ['4']);
    assert.match(buildListMemberCarsOfOwner('4', 100).text, /c\.owner_id = \$1::bigint AND c\.source_type = 'member' AND c\.deleted_at IS NULL[\s\S]*ORDER BY c\.id DESC[\s\S]*LIMIT \$2::int/);
    assert.match(buildCountMemberCarsOfOwner('4').text, /c\.source_type = 'member' AND c\.deleted_at IS NULL/);
  });

  it('the statistics are counts of the real tables, soft-deleted rows excluded, the five member-ad states by literal', () => {
    assert.equal((STATS_SQL.match(/count\(\*\)/g) ?? []).length, 10);
    assert.equal((STATS_SQL.match(/deleted_at IS NULL/g) ?? []).length, 9, 'every count but showrooms (no deleted_at column)');
    for (const st of ['pending', 'active', 'sold', 'rejected', 'suspended']) assert.match(STATS_SQL, new RegExp(`status = '${st}'\\)::int\\s+AS ${st}_member_cars`));
    assert.match(STATS_SQL, /role = 'dealer' AND status = 'pending' AND deleted_at IS NULL\)::int\s+AS pending_dealers/);
  });

  it('the service builds every DTO field by field and authorizes BEFORE parsing; routes take nothing but query and :id', () => {
    const svc = code('src/admin-users/service.ts');
    const routes = code('src/admin-users/routes.ts');
    assert.ok(!/\.\.\.(r|row|s|c)\b/.test(svc), 'no spread of a database row into a response');
    assert.match(svc, /authorize\(actor, 'read', userDirectoryResource\(\)\); \/\/ non-admins: 404 before the query is even parsed\n\s*const parsed = parseUsersQuery/);
    assert.match(svc, /authorize\(actor, 'read', platformStatsResource\(\)\)/);
    assert.ok(!/app\.(post|put|patch|delete)\(/.test(routes), 'no write route');
    assert.ok(!/request\.body/.test(routes));
    assert.match(routes, /return toActor\(found\.user\);/);
  });

  it('wired only together with authentication, with the Postgres-backed repository', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.adminUsers\) registerAdminUsersRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createAdminUsersService\(\{ repo: createPgAdminUsersRepository\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\badminUsers\b/);
  });
});

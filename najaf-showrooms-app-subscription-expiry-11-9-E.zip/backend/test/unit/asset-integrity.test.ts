// Phase 11.7.2-K: the administrators' asset integrity scan and confirmed cleanup. The service runs for real over the in-memory
// integrity repository (the audit fake of 11.6.6 plus getAsset / audited delete) and the real in-memory storage provider (listing
// included); the HTTP layer runs WITHOUT Fastify (routes on a recording stand-in) with the REAL authentication service.
// Covers: authorization, classification (corrupt / missing / orphaned / unverified are never confused), reference checks, races
// (an attach between the scan and the delete, a reference appearing between two lookups, a concurrent run), deletion safety, the
// audit trail, failures, and SQL / source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { assertAuditSafe } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError, assetIntegrityResource, can, isPublic } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { INTEGRITY_RATE_LIMITS, registerAssetIntegrityRoutes, toIntegrityHttp } from '../../src/assets/integrity-routes.ts';
import { CLEANUP_ITEMS_MAX, IntegrityError, createAssetIntegrityService, keyOfObjectRef, objectRef, parseCleanupBody, parseScanQuery } from '../../src/assets/integrity.ts';
import type { CleanupResult, ScanResult } from '../../src/assets/integrity.ts';
import { classifyObjectKey } from '../../src/assets/cleanup.ts';
import { GET_ASSET_SQL } from '../../src/assets/integrity-repository.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { ListableStorage } from '../../src/storage/index.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { makeFakeIntegrity } from '../helpers/fake-integrity.ts';
import type { AuditRow } from '../helpers/fake-audit.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const ADMIN: Actor = Object.freeze({ id: '1', role: 'admin' });
const MEMBER: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const T0 = Date.UTC(2026, 9, 10);
const H = 3600 * 1000;
const u = (i: number) => `d0000000-0000-4000-8000-${String(i).padStart(12, '0')}`;
const inc = (i: number, kind = 'car_image') => `incoming/${kind}/${u(i)}`;
const proc = (i: number, kind = 'car_image') => `processed/${kind}/${u(i)}.webp`;
const thumb = (i: number, kind = 'car_image') => `thumbs/${kind}/${u(i)}.webp`;
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');
const noSleep = async () => {};
const isNotFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
const isValidation = (e: unknown) => e instanceof IntegrityError && e.code === 'validation_failed';
const KEY_SHAPES = /incoming\/|processed\/|thumbs\/|\.webp|bucket|endpoint|secret|signature/i;

type Brk = 'missing_main' | 'missing_thumb' | 'garbage_main' | 'hash';
interface ReadyOpts {
  ageH?: number;
  referenced?: boolean;
  kind?: string;
  broken?: Brk;
}

function world(extra: Parameters<typeof createAssetIntegrityService>[0]['limits'] = {}) {
  const t = new Date(T0);
  const clock = { now: () => t };
  const storeTime = { at: new Date(T0) };
  const mem = createMemoryStorage({ now: () => storeTime.at });
  const fi = makeFakeIntegrity(clock);
  const order: string[] = [];
  const deleted: string[] = [];
  const faults: { get: ((key: string) => StorageError | null) | null; delete: ((key: string) => StorageError | null) | null; list: (() => Promise<StorageError | null | void> | StorageError | null) | null } = { get: null, delete: null, list: null };
  const storage: ListableStorage = {
    kind: 'memory',
    put: (k, b, o) => mem.put(k, b, o),
    async get(k) {
      const f = faults.get?.(k);
      if (f) throw f;
      return mem.get(k);
    },
    async delete(k) {
      const f = faults.delete?.(k);
      if (f) throw f;
      order.push(`delete:${k}`);
      deleted.push(k);
      return mem.delete(k);
    },
    exists: (k) => mem.exists(k),
    async list(p, o) {
      const f = await faults.list?.();
      if (f) throw f;
      return mem.list(p, o);
    },
  };
  const origAudit = fi.repo.recordAudit;
  fi.repo.recordAudit = async (e) => {
    order.push(`audit:${e.action}`);
    return origAudit(e);
  };
  const putAt = async (key: string, body: Uint8Array, ageH: number) => {
    storeTime.at = new Date(T0 - ageH * H);
    await mem.put(key, body, { contentType: 'image/webp' });
    storeTime.at = new Date(T0);
  };
  async function ready(i: number, o: ReadyOpts = {}): Promise<AuditRow> {
    const ageH = o.ageH ?? 48;
    const kind = o.kind ?? 'car_image';
    const main = fakeWebp(40, 30, { payload: 16 + (i % 9) * 2 });
    const th = fakeWebp(20, 15, { payload: 16 + (i % 5) * 2 });
    const row = fi.add({ id: u(i), kind, storageKey: proc(i, kind), thumbKey: thumb(i, kind), bytes: main.byteLength, width: 40, height: 30, sha256: sha(main), readyAt: new Date(T0 - ageH * H), referenced: o.referenced ?? false });
    const b = o.broken;
    if (b !== 'missing_main') await putAt(row.storageKey!, b === 'garbage_main' ? new Uint8Array([1, 2, 3, 4]) : b === 'hash' ? main.map((x, j, a) => (j === a.length - 1 ? x ^ 1 : x)) : main, ageH);
    if (b !== 'missing_thumb') await putAt(row.thumbKey!, th, ageH);
    return row;
  }
  const svc = createAssetIntegrityService({ repo: fi.repo, storage, now: clock.now, sleep: noSleep, limits: extra });
  const scan = (query: unknown = {}) => svc.scan(ADMIN, query);
  const cleanup = (items: Array<{ type: 'asset' | 'object'; id: string }>, confirm: unknown = true) => svc.cleanup(ADMIN, { confirm, items }, { requestId: 'req-abcdef01' });
  const refOf = (key: string) => objectRef(classifyObjectKey(key)!, key);
  const find = (r: ScanResult, type: 'asset' | 'object', id: string) => r.items.find((x) => x.ref.type === type && x.ref.id === id);
  const result = (r: CleanupResult, type: 'asset' | 'object', id: string) => r.results.find((x) => x.ref.type === type && x.ref.id === id)!;
  const sizeOf = async (...keys: string[]) => {
    let n = 0;
    for (const k of keys) n += (await mem.get(k))?.size ?? 0;
    return n;
  };
  return { fi, mem, storage, faults, deleted, order, ready, putAt, svc, scan, cleanup, refOf, find, result, sizeOf, storeTime };
}

describe('asset integrity: least-privilege policy', () => {
  it('asset_integrity: read and delete for administrators only; no other action for anyone; never public', () => {
    const r = assetIntegrityResource();
    for (const a of ['read', 'delete'] as const) assert.equal(can(ADMIN, a, r), true, a);
    for (const a of ['update', 'moderate'] as const) assert.equal(can(ADMIN, a, r), false, a);
    for (const who of [MEMBER, DEALER, null]) for (const a of ['read', 'update', 'delete', 'moderate'] as const) assert.equal(can(who, a, r), false, `${who?.role} ${a}`);
    assert.equal(isPublic(r), false);
  });

  it('a member, a dealer and a caller with no actor get 404 on scan AND cleanup before the input is parsed and before anything is read or touched', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    w.fi.calls.length = 0;
    const before = w.mem.keys();
    for (const who of [MEMBER, DEALER, null]) {
      await assert.rejects(w.svc.scan(who, { bogus: 'x' }), isNotFound, 'authorization before validation');
      await assert.rejects(w.svc.scan(who, {}), isNotFound);
      await assert.rejects(w.svc.cleanup(who, { confirm: true, items: [{ type: 'asset', id: u(1) }] }), isNotFound);
      await assert.rejects(w.svc.cleanup(who, 'garbage'), isNotFound, 'authorization before validation');
    }
    assert.deepEqual(w.fi.calls, []);
    assert.deepEqual(w.mem.keys(), before);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.fi.audits.length, 0);
  });
});

describe('asset integrity: input validation', () => {
  it('scan query: scope / after / shard are strict; unknown keys are refused; after needs a record scope, shard an object scope', () => {
    assert.deepEqual(parseScanQuery(undefined), { ok: true, value: { scope: 'all', afterId: null, shard: '' } });
    assert.deepEqual(parseScanQuery({ scope: 'assets', after: u(3) }), { ok: true, value: { scope: 'assets', afterId: u(3), shard: '' } });
    assert.deepEqual(parseScanQuery({ scope: 'objects', shard: 'a1' }), { ok: true, value: { scope: 'objects', afterId: null, shard: 'a1' } });
    const bad: Array<[unknown, string]> = [
      [{ scope: 'everything' }, 'scope'], [{ scope: 5 }, 'scope'], [{ after: 'x' }, 'after'], [{ after: u(3).toUpperCase() }, 'after'], [{ shard: 'xyz' }, 'shard'], [{ shard: 'A1' }, 'shard'],
      [{ page: '2' }, 'page'], [{ scope: 'objects', after: u(3) }, 'after'], [{ scope: 'assets', shard: 'a' }, 'shard'], ['x', 'query'], [[], 'query'],
    ];
    for (const [q, field] of bad) {
      const r = parseScanQuery(q);
      assert.equal(r.ok, false, JSON.stringify(q));
      assert.ok(!r.ok && r.errors.some((e) => e.field === field), `${JSON.stringify(q)} -> ${field}`);
    }
  });

  it('cleanup body: confirm must be the literal true; 1..50 unique items of a strict shape; unknown fields and paths are refused', () => {
    const ok = parseCleanupBody({ confirm: true, items: [{ type: 'asset', id: u(1) }, { type: 'object', id: `processed.car_image.${u(2)}` }] });
    assert.deepEqual(ok, { ok: true, value: [{ type: 'asset', id: u(1) }, { type: 'object', id: `processed.car_image.${u(2)}` }] });
    const a = (id = u(1)) => ({ type: 'asset', id });
    const bad: Array<[unknown, string]> = [
      [{ items: [a()] }, 'confirm'], [{ confirm: 'true', items: [a()] }, 'confirm'], [{ confirm: 1, items: [a()] }, 'confirm'], [{ confirm: false, items: [a()] }, 'confirm'],
      [{ confirm: true }, 'items'], [{ confirm: true, items: [] }, 'items'], [{ confirm: true, items: 'x' }, 'items'],
      [{ confirm: true, items: Array.from({ length: CLEANUP_ITEMS_MAX + 1 }, (_, i) => a(u(i + 1))) }, 'items'],
      [{ confirm: true, items: [a(), a()] }, 'items.1.id'],
      [{ confirm: true, items: [{ type: 'asset', id: 'processed/car_image/x' }] }, 'items.0.id'],
      [{ confirm: true, items: [{ type: 'asset', id: '../../etc/passwd' }] }, 'items.0.id'],
      [{ confirm: true, items: [{ type: 'object', id: `processed/car_image/${u(2)}.webp` }] }, 'items.0.id'],
      [{ confirm: true, items: [{ type: 'object', id: u(2) }] }, 'items.0.id'],
      [{ confirm: true, items: [{ type: 'object', id: `avatars.car_image.${u(2)}` }] }, 'items.0.id'],
      [{ confirm: true, items: [{ type: 'file', id: u(1) }] }, 'items.0.type'],
      [{ confirm: true, items: [{ type: 'asset', id: u(1), force: true }] }, 'items.0.force'],
      [{ confirm: true, items: [a()], all: true }, 'all'], ['x', 'body'], [null, 'body'], [[], 'body'],
    ];
    for (const [b, field] of bad) {
      const r = parseCleanupBody(b);
      assert.equal(r.ok, false, JSON.stringify(b).slice(0, 80));
      assert.ok(!r.ok && r.errors.some((e) => e.field === field), `${JSON.stringify(b).slice(0, 80)} -> ${field}: ${JSON.stringify(!r.ok && r.errors)}`);
    }
  });

  it('an object reference spells exactly a generated object name and maps back to its key; nothing else does', () => {
    for (const key of [inc(1), proc(2), thumb(3, 'showroom_cover')]) {
      const ref = objectRef(classifyObjectKey(key)!, key);
      assert.ok(!ref.includes('/') && !ref.includes('.webp'));
      assert.equal(keyOfObjectRef(ref)?.key, key);
    }
    for (const ref of ['', 'processed.car_image', `processed.car_image.${u(1)}.webp`, `processed.car_image.${u(1)}/x`, `PROCESSED.car_image.${u(1)}`, `x.car_image.${u(1)}`, `processed.logo.${u(1)}`]) assert.equal(keyOfObjectRef(ref), null, ref);
  });
});

describe('asset integrity: scan classification', () => {
  async function mixed() {
    const w = world();
    await w.ready(1, { referenced: true }); // healthy and in use: not reported
    await w.ready(2, { referenced: true, broken: 'garbage_main' }); // corrupt, in use
    await w.ready(3, { referenced: true, broken: 'missing_thumb' }); // missing, in use
    await w.ready(4, { ageH: 100 }); // healthy but unlinked, old
    await w.ready(5, { ageH: 100, broken: 'hash' }); // corrupt AND unlinked, old
    await w.ready(6, { ageH: 5 }); // unlinked but inside the grace period
    await w.ready(7, { ageH: 100, kind: 'showroom_cover', broken: 'missing_main' }); // missing AND unlinked
    await w.ready(8, { referenced: true }); // could not be verified (storage trouble)
    await w.putAt(proc(77), fakeWebp(8, 8, { payload: 24 }), 100); // object with no record, old
    await w.putAt(proc(78), fakeWebp(8, 8), 5); // object with no record, inside the grace period
    await w.putAt('processed/car_image/not-a-uuid.webp', fakeWebp(8, 8), 100); // not a shape this backend generates
    w.faults.get = (k) => (k === proc(8) ? new StorageError('unavailable', 503) : null);
    return w;
  }

  it('every finding is in exactly ONE category: corrupt, missing, unverified, orphaned; healthy records in use are not reported', async () => {
    const w = await mixed();
    const r = await w.scan();
    const cat = (id: string) => w.find(r, 'asset', id)?.category;
    assert.equal(cat(u(1)), undefined);
    assert.equal(cat(u(2)), 'corrupt');
    assert.equal(cat(u(3)), 'missing');
    assert.equal(cat(u(4)), 'orphaned');
    assert.equal(cat(u(5)), 'corrupt', 'unlinked AND corrupt: the health verdict wins, the record stays visible as unlinked');
    assert.equal(cat(u(6)), 'orphaned');
    assert.equal(cat(u(7)), 'missing');
    assert.equal(cat(u(8)), 'unverified');
    assert.equal(w.find(r, 'object', w.refOf(proc(77)))?.category, 'orphaned');
    assert.equal(w.find(r, 'object', w.refOf(proc(78))), undefined, 'inside the grace period: not reported (could be an upload in progress)');
    assert.equal(r.items.length, 7 + 1);
    assert.deepEqual({ corrupt: r.summary.corrupt, missing: r.summary.missing, orphaned: r.summary.orphaned, unverified: r.summary.unverified }, { corrupt: 2, missing: 2, orphaned: 3, unverified: 1 });
    assert.equal(r.items.reduce((n, i) => n + 1, 0), r.summary.corrupt + r.summary.missing + r.summary.orphaned + r.summary.unverified);
    assert.equal(r.error, null);
    assert.equal(r.complete, true);
  });

  it('reasons are specific and not interchangeable: invalid image / hash mismatch, object missing, unlinked record, no record, unverifiable', async () => {
    const w = await mixed();
    const r = await w.scan();
    assert.equal(w.find(r, 'asset', u(2))?.reason, 'invalid_image');
    assert.equal(w.find(r, 'asset', u(5))?.reason, 'hash_mismatch');
    assert.equal(w.find(r, 'asset', u(3))?.reason, 'object_missing');
    assert.equal(w.find(r, 'asset', u(4))?.reason, 'unlinked_record');
    assert.equal(w.find(r, 'asset', u(8))?.reason, 'unverifiable');
    assert.equal(w.find(r, 'object', w.refOf(proc(77)))?.reason, 'no_record');
    assert.equal(w.find(r, 'asset', u(7))?.kind, 'showroom_cover');
  });

  it('deletable only when the SERVER can prove it: unreferenced + past the grace period + generated shape; a referenced or unverified asset never is', async () => {
    const w = await mixed();
    const r = await w.scan();
    const d = (type: 'asset' | 'object', id: string) => { const i = w.find(r, type, id)!; return [i.deletable, i.protectedReason]; };
    assert.deepEqual(d('asset', u(2)), [false, 'referenced'], 'a corrupt asset that a listing uses is report-only');
    assert.deepEqual(d('asset', u(3)), [false, 'referenced']);
    assert.deepEqual(d('asset', u(4)), [true, null]);
    assert.deepEqual(d('asset', u(5)), [true, null], 'unreferenced and old: deletable because NOTHING USES it, not because it is unreadable');
    assert.deepEqual(d('asset', u(6)), [false, 'within_grace']);
    assert.deepEqual(d('asset', u(7)), [true, null]);
    assert.deepEqual(d('asset', u(8)), [false, 'referenced']);
    assert.deepEqual(d('object', w.refOf(proc(77))), [true, null]);
    for (const i of r.items) assert.equal(i.deletable, i.protectedReason === null, 'deletable <=> no protection reason');
    for (const i of r.items.filter((x) => x.referenced)) assert.equal(i.deletable, false);
    assert.equal(r.summary.deletable, 4);
    assert.equal(r.summary.protected, r.items.length - 4);
    assert.equal(r.summary.referencedProblems, 3);
  });

  it('an unverifiable asset is never deletable even when it is unlinked (storage trouble is not proof)', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    w.faults.get = (k) => (k === proc(1) ? new StorageError('unavailable', 503) : null);
    const i = w.find(await w.scan(), 'asset', u(1))!;
    assert.equal(i.category, 'unverified');
    assert.equal(i.deletable, false);
    assert.equal(i.protectedReason, 'unverified');
  });

  it('sizes and the recoverable estimate: stored bytes of the deletable items only; scan time and grace period are reported', async () => {
    const w = await mixed();
    const r = await w.scan();
    const s4 = await w.sizeOf(proc(4), thumb(4));
    const s5 = await w.sizeOf(proc(5), thumb(5));
    const s7 = await w.sizeOf(thumb(7, 'showroom_cover'));
    const s77 = await w.sizeOf(proc(77));
    assert.equal(w.find(r, 'asset', u(4))?.sizeBytes, s4);
    assert.equal(w.find(r, 'asset', u(5))?.sizeBytes, s5);
    assert.equal(w.find(r, 'asset', u(7))?.sizeBytes, s7, 'a missing object counts as 0');
    assert.equal(w.find(r, 'object', w.refOf(proc(77)))?.sizeBytes, s77);
    assert.equal(r.summary.recoverableBytes, s4 + s5 + s7 + s77);
    assert.equal(r.scannedAt, new Date(T0).toISOString());
    assert.equal(r.graceHours, 24);
    assert.equal(w.find(r, 'asset', u(4))?.ageHours, 100);
    assert.equal(w.find(r, 'object', w.refOf(proc(77)))?.ageHours, 100);
  });

  it('the scan is READ ONLY: nothing deleted, no record changed, no audit row, no write call at all', async () => {
    const w = await mixed();
    const keys = w.mem.keys();
    const rows = JSON.stringify(w.fi.rows());
    await w.scan();
    await w.scan({ scope: 'assets' });
    await w.scan({ scope: 'objects', shard: 'd' });
    assert.deepEqual(w.deleted, []);
    assert.deepEqual(w.mem.keys(), keys);
    assert.equal(JSON.stringify(w.fi.rows()), rows);
    assert.equal(w.fi.audits.length, 0);
    assert.deepEqual(w.fi.calls.filter((c) => /delete|recordAudit/i.test(c.op)), []);
  });

  it('nothing the scan returns discloses a storage key, bucket, endpoint or signature', async () => {
    const w = await mixed();
    const text = JSON.stringify(await w.scan());
    assert.ok(!KEY_SHAPES.test(text), text.match(KEY_SHAPES)?.[0] ?? '');
  });

  it('a record scan lists no storage; an object scan reads no record; the cursor continues where the page stopped', async () => {
    const w = world({ batchSize: 2, maxBatches: 1 });
    for (const i of [1, 2, 3, 4, 5]) await w.ready(i, { ageH: 100 });
    let lists = 0;
    w.faults.list = async () => { lists++; return null; };
    const first = await w.scan({ scope: 'assets' });
    assert.equal(lists, 0);
    assert.equal(first.complete, false);
    assert.equal(first.nextAfter, u(2));
    assert.deepEqual(first.items.map((i) => i.ref.id), [u(1), u(2)]);
    const second = await w.scan({ scope: 'assets', after: first.nextAfter });
    assert.deepEqual(second.items.map((i) => i.ref.id), [u(3), u(4)]);
    assert.equal(second.nextAfter, u(4));
    const last = await w.scan({ scope: 'assets', after: second.nextAfter });
    assert.deepEqual(last.items.map((i) => i.ref.id), [u(5)]);
    assert.equal(last.complete, true);
    assert.equal(last.nextAfter, null);
    w.fi.calls.length = 0;
    await w.scan({ scope: 'objects' });
    assert.equal(w.fi.calls.filter((c) => c.op === 'listReady').length, 0);
  });

  it('too many findings: the list is cut, `truncated` says so and the summary still counts them all', async () => {
    const w = world({ maxItems: 3 });
    for (const i of [1, 2, 3, 4, 5]) await w.ready(i, { ageH: 100 });
    const r = await w.scan({ scope: 'assets' });
    assert.equal(r.items.length, 3);
    assert.equal(r.truncated, true);
    assert.equal(r.summary.orphaned, 5);
  });

  it('a database or storage failure makes the scan partial and says why (never an empty "all clear")', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    w.fi.faults.failListFrom = 1;
    const r = await w.scan();
    assert.equal(r.error, 'database_unavailable');
    assert.equal(r.complete, false);
    w.fi.faults.failListFrom = null;
    w.faults.list = () => new StorageError('unavailable', 503);
    const r2 = await w.scan({ scope: 'objects' });
    assert.equal(r2.error, 'storage_unavailable');
    assert.equal(r2.complete, false);
  });

  it('only one scan or cleanup runs at a time: a second one is refused with busy and the first still finishes', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    let release: () => void = () => {};
    let held = false;
    w.faults.list = () => (held ? Promise.resolve() : ((held = true), new Promise<void>((resolve) => { release = resolve; })));
    const first = w.scan({ scope: 'objects' });
    await new Promise((r) => setImmediate(r));
    await assert.rejects(w.scan(), (e) => e instanceof IntegrityError && e.code === 'busy');
    await assert.rejects(w.cleanup([{ type: 'asset', id: u(1) }]), (e) => e instanceof IntegrityError && e.code === 'busy');
    release();
    const done = await first;
    assert.equal(done.error, null);
    w.faults.list = null;
    assert.equal((await w.scan()).error, null, 'the lock is released');
    assert.equal((await w.cleanup([{ type: 'asset', id: u(1) }])).summary.deleted, 1);
  });
});

describe('asset integrity: cleanup', () => {
  it('without the explicit confirmation nothing is read or deleted', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    w.fi.calls.length = 0;
    for (const confirm of [false, 'true', 1, null]) await assert.rejects(w.cleanup([{ type: 'asset', id: u(1) }], confirm), isValidation);
    await assert.rejects(w.svc.cleanup(ADMIN, { items: [{ type: 'asset', id: u(1) }] }), isValidation);
    assert.deepEqual(w.fi.calls, []);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.fi.rows().length, 1);
  });

  it('deletes an unlinked asset: the record and its three objects go, the audit row is written with the record, and only the selection is touched', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    await w.ready(2, { ageH: 100 }); // also deletable, but NOT selected
    await w.putAt(inc(1), fakeWebp(8, 8), 100); // a leftover original of asset 1
    await w.putAt(proc(99), fakeWebp(8, 8), 100); // an orphan, NOT selected
    const bytes = await w.sizeOf(proc(1), thumb(1));
    const r = await w.cleanup([{ type: 'asset', id: u(1) }]);
    assert.deepEqual(r.summary, { requested: 1, deleted: 1, protected: 0, gone: 0, changed: 0, failed: 0, notAttempted: 0, bytes });
    assert.equal(w.result(r, 'asset', u(1)).outcome, 'deleted');
    assert.deepEqual(w.fi.rows().map((x) => x.id), [u(2)]);
    assert.deepEqual(w.mem.keys().filter((k) => k.includes(u(1))), []);
    assert.ok(w.mem.keys().includes(proc(2)) && w.mem.keys().includes(thumb(2)) && w.mem.keys().includes(proc(99)), 'nothing outside the selection is touched');
    const a = w.fi.audits.find((e) => e.action === 'asset_integrity.delete_asset')!;
    assert.deepEqual({ actor: a.actorUserId, role: a.actorRole, type: a.entityType, id: a.entityId, data: a.afterData, req: a.requestId }, { actor: '1', role: 'admin', type: 'asset', id: u(1), data: { bytes }, req: 'req-abcdef01' });
    assert.ok(w.fi.audits.some((e) => e.action === 'asset_integrity.cleanup' && e.entityType === 'asset_integrity' && e.afterData['deleted'] === 1));
  });

  it('REVALIDATES the asset: a scan that said "deletable" is not trusted. Referenced / pending / rejected / too young / unrecognized / vanished are protected', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    await w.ready(2, { ageH: 100 });
    await w.ready(3, { ageH: 100 });
    await w.ready(4, { ageH: 100 });
    await w.ready(5, { ageH: 100 });
    const scan = await w.scan();
    for (const i of [1, 2, 3, 4, 5]) assert.equal(w.find(scan, 'asset', u(i))?.deletable, true);
    // ... then the world changes before the administrator confirms:
    w.fi.rows().find((x) => x.id === u(1))!.referenced = true; // attached to a car meanwhile
    w.fi.rows().find((x) => x.id === u(2))!.status = 'pending'; // back to uploading/processing
    w.fi.rows().find((x) => x.id === u(3))!.readyAt = new Date(T0 - 2 * H); // re-processed: too young
    w.fi.rows().find((x) => x.id === u(4))!.storageKey = 'legacy/imported.webp'; // not a key this backend generated
    w.fi.rows().splice(w.fi.rows().findIndex((x) => x.id === u(5)), 1); // deleted by someone else
    w.fi.calls.length = 0;
    const r = await w.cleanup([1, 2, 3, 4, 5].map((i) => ({ type: 'asset' as const, id: u(i) })));
    assert.deepEqual(r.results.map((x) => [x.outcome, x.reason]), [['protected', 'referenced'], ['protected', 'not_ready'], ['protected', 'within_grace'], ['protected', 'unrecognized_key'], ['gone', null]]);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.fi.rows().length, 4);
    assert.deepEqual(w.fi.calls.filter((c) => c.op === 'deleteUnlinkedAudited'), [], 'no delete statement is even attempted');
    assert.equal(r.summary.deleted, 0);
  });

  it('a rejected asset is protected too (the cleanup job owns its lifecycle)', async () => {
    const w = world();
    const row = await w.ready(1, { ageH: 100 });
    row.status = 'rejected';
    const r = await w.cleanup([{ type: 'asset', id: u(1) }]);
    assert.equal(w.result(r, 'asset', u(1)).reason, 'not_ready');
    assert.equal(w.fi.rows().length, 1);
  });

  it('RACE: the asset is attached between the revalidation and the delete. The locked compare-and-swap refuses; record, objects and trail are untouched', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    w.fi.faults.beforeDelete = (row) => { row.referenced = true; };
    const r = await w.cleanup([{ type: 'asset', id: u(1) }]);
    assert.equal(w.result(r, 'asset', u(1)).outcome, 'changed');
    assert.equal(w.fi.rows().length, 1);
    assert.deepEqual(w.deleted, []);
    assert.ok(w.mem.keys().includes(proc(1)) && w.mem.keys().includes(thumb(1)));
    assert.equal(w.fi.audits.filter((e) => e.action === 'asset_integrity.delete_asset').length, 0);
  });

  it('a corrupt or missing asset that a listing uses can never be deleted, however it is selected', async () => {
    const w = world();
    await w.ready(1, { referenced: true, broken: 'garbage_main' });
    await w.ready(2, { referenced: true, broken: 'missing_main' });
    const r = await w.cleanup([{ type: 'asset', id: u(1) }, { type: 'asset', id: u(2) }]);
    assert.deepEqual(r.results.map((x) => [x.outcome, x.reason]), [['protected', 'referenced'], ['protected', 'referenced']]);
    assert.equal(w.fi.rows().length, 2);
    assert.deepEqual(w.deleted, []);
  });

  it('a corrupt asset NOBODY uses may be removed (it is deletable because it is unused); asking twice is harmless (gone)', async () => {
    const w = world();
    await w.ready(1, { ageH: 100, broken: 'hash' });
    assert.equal(w.result(await w.cleanup([{ type: 'asset', id: u(1) }]), 'asset', u(1)).outcome, 'deleted');
    assert.equal(w.result(await w.cleanup([{ type: 'asset', id: u(1) }]), 'asset', u(1)).outcome, 'gone');
  });

  it('deletes an orphaned object: the audit row is written BEFORE the delete; the object is gone', async () => {
    const w = world();
    await w.putAt(proc(9), fakeWebp(8, 8, { payload: 30 }), 100);
    const size = await w.sizeOf(proc(9));
    const ref = w.refOf(proc(9));
    const r = await w.cleanup([{ type: 'object', id: ref }]);
    assert.equal(w.result(r, 'object', ref).outcome, 'deleted');
    assert.equal(w.result(r, 'object', ref).bytes, size);
    assert.deepEqual(w.order.filter((x) => /delete_object|delete:/.test(x)), ['audit:asset_integrity.delete_object', `delete:${proc(9)}`]);
    assert.deepEqual(w.mem.keys(), []);
    const a = w.fi.audits.find((e) => e.action === 'asset_integrity.delete_object')!;
    assert.deepEqual({ type: a.entityType, id: a.entityId, data: a.afterData, role: a.actorRole }, { type: 'asset_object', id: ref, data: { bytes: size }, role: 'admin' });
  });

  it('REVALIDATES an object: a row that now references it (itself, its original, its main image) protects it; so does a young or vanished one', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(8, 8), 100); // a row now has it as its main image
    await w.putAt(thumb(2), fakeWebp(8, 8), 100); // a row now has it as its thumbnail
    await w.putAt(proc(3), fakeWebp(8, 8), 100); // the output of an asset still being processed (pending row owns the original)
    await w.putAt(inc(4), fakeWebp(8, 8), 100); // the original of a pending upload
    await w.putAt(proc(5), fakeWebp(8, 8), 5); // too young
    const scan = await w.scan();
    for (const key of [proc(1), thumb(2), proc(3), inc(4)]) assert.equal(w.find(scan, 'object', w.refOf(key))?.deletable, true, key);
    w.fi.add({ id: u(1), storageKey: proc(1), thumbKey: null, status: 'ready' });
    w.fi.add({ id: u(2), storageKey: proc(2), thumbKey: thumb(2), status: 'ready' });
    w.fi.add({ id: u(3), status: 'pending', storageKey: inc(3), readyAt: null });
    w.fi.add({ id: u(4), status: 'pending', storageKey: inc(4), readyAt: null });
    const gone = proc(6);
    const r = await w.cleanup([proc(1), thumb(2), proc(3), inc(4), proc(5), gone].map((k) => ({ type: 'object' as const, id: w.refOf(k) })));
    assert.deepEqual(r.results.map((x) => [x.outcome, x.reason]), [['protected', 'referenced'], ['protected', 'referenced'], ['protected', 'referenced'], ['protected', 'referenced'], ['protected', 'within_grace'], ['gone', null]]);
    assert.deepEqual(w.deleted, []);
    assert.equal(w.fi.audits.filter((e) => e.action === 'asset_integrity.delete_object').length, 0);
  });

  it('RACE: a reference that appears between the two lookups protects the object (two independent lookups run right before the delete)', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(8, 8), 100);
    w.fi.faults.afterRefs = (n) => { if (n === 1) w.fi.add({ id: u(1), storageKey: proc(1), thumbKey: thumb(1), status: 'ready' }); };
    const r = await w.cleanup([{ type: 'object', id: w.refOf(proc(1)) }]);
    assert.deepEqual([r.results[0]!.outcome, r.results[0]!.reason], ['protected', 'referenced']);
    assert.equal(w.fi.calls.filter((c) => c.op === 'findReferencedKeys').length, 2);
    assert.deepEqual(w.deleted, []);
    assert.ok(w.mem.keys().includes(proc(1)));
  });

  it('a stale scan: the object was already deleted by someone else; the asset was attached after the scan', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    await w.putAt(proc(9), fakeWebp(8, 8), 100);
    const scan = await w.scan();
    await w.mem.delete(proc(9));
    w.fi.rows()[0]!.referenced = true;
    const r = await w.cleanup(scan.items.filter((i) => i.deletable).map((i) => ({ type: i.ref.type, id: i.ref.id })));
    assert.deepEqual(r.results.map((x) => [x.ref.type, x.outcome]).sort(), [['asset', 'protected'], ['object', 'gone']]);
    assert.deepEqual(w.deleted, []);
  });

  it('FAILURES stop the run and delete nothing on doubt: a database error on the lookup, then the remaining items are not attempted', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(8, 8), 100);
    await w.putAt(proc(2), fakeWebp(8, 8), 100);
    await w.ready(3, { ageH: 100 });
    w.fi.faults.failRefsFrom = 1;
    const r = await w.cleanup([{ type: 'object', id: w.refOf(proc(1)) }, { type: 'object', id: w.refOf(proc(2)) }, { type: 'asset', id: u(3) }]);
    assert.equal(r.stopped, 'database_unavailable');
    assert.deepEqual(r.results.map((x) => [x.outcome, x.reason]), [['failed', 'database_unavailable'], ['not_attempted', null], ['not_attempted', null]]);
    assert.deepEqual(w.deleted, []);
    assert.equal(r.summary.notAttempted, 2);
  });

  it('a storage failure while listing an object (cannot prove it is still there) stops the run without deleting', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(8, 8), 100);
    w.faults.list = () => new StorageError('unavailable', 503);
    const r = await w.cleanup([{ type: 'object', id: w.refOf(proc(1)) }]);
    assert.equal(r.stopped, 'storage_unavailable');
    assert.equal(r.results[0]!.outcome, 'failed');
    assert.deepEqual(w.deleted, []);
  });

  it('AUDIT is mandatory: if the audit row cannot be written the asset is NOT deleted (one transaction) and the object is NOT deleted', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    await w.putAt(proc(9), fakeWebp(8, 8), 100);
    w.fi.integrityFaults.failAuditFor = (e) => e.action === 'asset_integrity.delete_asset';
    const a = await w.cleanup([{ type: 'asset', id: u(1) }]);
    assert.equal(a.results[0]!.outcome, 'failed');
    assert.equal(w.fi.rows().length, 1, 'the record is still there');
    assert.ok(w.mem.keys().includes(proc(1)) && w.mem.keys().includes(thumb(1)));
    w.fi.integrityFaults.failAuditFor = (e) => e.action === 'asset_integrity.delete_object';
    const o = await w.cleanup([{ type: 'object', id: w.refOf(proc(9)) }]);
    assert.equal(o.results[0]!.outcome, 'failed');
    assert.ok(w.mem.keys().includes(proc(9)), 'no trail, no deletion');
    assert.deepEqual(w.deleted, []);
  });

  it('a storage failure on an object delete: reported as failed, the failure is audited, the rest is not attempted', async () => {
    const w = world();
    await w.putAt(proc(1), fakeWebp(8, 8), 100);
    await w.putAt(proc(2), fakeWebp(8, 8), 100);
    w.faults.delete = () => new StorageError('unavailable', 503);
    const r = await w.cleanup([{ type: 'object', id: w.refOf(proc(1)) }, { type: 'object', id: w.refOf(proc(2)) }]);
    assert.equal(r.stopped, 'storage_unavailable');
    assert.deepEqual(r.results.map((x) => x.outcome), ['failed', 'not_attempted']);
    assert.ok(w.fi.audits.some((e) => e.action === 'asset_integrity.delete_failed' && e.entityType === 'asset_object'));
    assert.equal(w.mem.keys().length, 2);
  });

  it('the record is deleted but some objects cannot be removed now: outcome deleted with objectsRemaining, a trail, and the next scan finds them as orphans', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    w.faults.delete = (k) => (k === thumb(1) ? new StorageError('unavailable', 503) : null);
    const r = await w.cleanup([{ type: 'asset', id: u(1) }]);
    assert.equal(r.results[0]!.outcome, 'deleted');
    assert.equal(r.results[0]!.objectsRemaining, 1);
    assert.ok(w.fi.audits.some((e) => e.action === 'asset_integrity.delete_failed' && e.entityType === 'asset' && e.afterData['objects'] === 1));
    assert.equal(w.fi.rows().length, 0);
    w.faults.delete = null;
    const next = await w.scan({ scope: 'objects' });
    assert.deepEqual(next.items.map((i) => i.ref.id), [w.refOf(thumb(1))]);
    assert.equal(next.items[0]!.deletable, true);
  });

  it('every audit row passes the audit writer\'s own safety rules (numbers only, no secret-looking key) and names no storage key', async () => {
    const w = world();
    await w.ready(1, { ageH: 100 });
    await w.putAt(proc(9), fakeWebp(8, 8), 100);
    await w.cleanup([{ type: 'asset', id: u(1) }, { type: 'object', id: w.refOf(proc(9)) }]);
    assert.ok(w.fi.audits.length >= 3);
    for (const e of w.fi.audits) {
      assertAuditSafe(e);
      assert.equal(e.actorRole, 'admin');
      assert.ok(!KEY_SHAPES.test(JSON.stringify(e)), JSON.stringify(e));
    }
  });
});

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };

function http(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: 'unit-test-access-secret-0123456789abcdef-XYZ', logger: recordingLogger().logger, now: clock.now });
  const w = world();
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  registerAssetIntegrityRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, integrity: w.svc, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter({ now: clock.now }) } : {}) });
  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const sent: Sent = { headers: {} };
    const reply = { code: (c: number) => ((sent.status = c), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  async function account(role: 'member' | 'dealer' | 'pendingDealer' | 'admin') {
    const r = role === 'dealer' || role === 'pendingDealer' ? await auth.registerDealer({ name: 'تاجر', phone: phone(), password: 'Corr3ct-Horse-Battery' }) : await auth.register({ name: 'حساب', phone: phone(), password: 'Corr3ct-Horse-Battery' });
    const user = db.users().find((x) => x.id === r.user.id)!;
    if (role === 'dealer') user.status = 'active';
    if (role === 'admin') user.role = 'admin';
    return { authorization: `Bearer ${r.session.accessToken}`, id: r.user.id };
  }
  return { routes, call, account, w };
}
const SCAN = '/v1/admin/asset-integrity/scan';
const CLEAN = '/v1/admin/asset-integrity/cleanup';

describe('asset integrity: HTTP', () => {
  it('registers exactly one GET (scan) and one POST (cleanup), both rate limited when a limiter is supplied; the body is small and JSON only', () => {
    const { routes } = http(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`GET ${SCAN}`, `POST ${CLEAN}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts?.bodyLimit, 16 * 1024);
  });

  it('401 without or with a bad token; 404 (nothing disclosed) for a member, an active dealer and a pending dealer, and nothing is read or deleted', async () => {
    const s = http();
    await s.w.ready(1, { ageH: 100 });
    for (const [method, path] of [['GET', SCAN], ['POST', CLEAN]] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const r = await s.call(method, path, { headers, body: { confirm: true, items: [{ type: 'asset', id: u(1) }] } });
        assert.equal(r.status, 401);
        assert.equal(r.headers['www-authenticate'], 'Bearer');
      }
    }
    s.w.fi.calls.length = 0;
    const bodies = new Set<string>();
    for (const role of ['member', 'dealer', 'pendingDealer'] as const) {
      const h = await s.account(role);
      for (const [method, path] of [['GET', SCAN], ['POST', CLEAN]] as const) {
        const r = await s.call(method, path, { headers: h, body: { confirm: true, items: [{ type: 'asset', id: u(1) }] } });
        assert.equal(r.status, 404, `${role} ${path}`);
        bodies.add(JSON.stringify((r.body as { error: { code: string; message: string } }).error.code));
      }
    }
    assert.deepEqual([...bodies], ['"not_found"']);
    assert.deepEqual(s.w.fi.calls, []);
    assert.equal(s.w.fi.rows().length, 1);
    assert.deepEqual(s.w.deleted, []);
  });

  it('an administrator scans and cleans: 200 with the documented shapes; bad input is 400 with field names only; a non-JSON body is 415', async () => {
    const s = http();
    const h = await s.account('admin');
    await s.w.ready(1, { ageH: 100 });
    const scan = await s.call('GET', SCAN, { headers: h });
    assert.equal(scan.status, 200);
    assert.equal(scan.headers['cache-control'], undefined, 'the server-wide no-store applies; no route decides caching');
    assert.deepEqual(Object.keys(scan.body as object).sort(), ['complete', 'error', 'graceHours', 'items', 'nextAfter', 'scannedAt', 'scope', 'summary', 'truncated']);
    assert.ok(!KEY_SHAPES.test(JSON.stringify(scan.body)));
    const bad = await s.call('GET', SCAN, { headers: h, query: { scope: 'x', page: '2' } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as { error: { fields: unknown } }).error.fields, [{ field: 'page', code: 'unknown_field' }, { field: 'scope', code: 'invalid_format' }]);
    assert.equal((await s.call('POST', CLEAN, { headers: { ...h, 'content-type': 'text/plain' }, body: 'x' })).status, 415);
    const noConfirm = await s.call('POST', CLEAN, { headers: h, body: { items: [{ type: 'asset', id: u(1) }] } });
    assert.equal(noConfirm.status, 400);
    assert.equal(s.w.fi.rows().length, 1, 'nothing deleted without the confirmation');
    const ok = await s.call('POST', CLEAN, { headers: h, body: { confirm: true, items: [{ type: 'asset', id: u(1) }] } });
    assert.equal(ok.status, 200);
    assert.deepEqual(Object.keys(ok.body as object).sort(), ['finishedAt', 'results', 'stopped', 'summary']);
    assert.equal((ok.body as CleanupResult).summary.deleted, 1);
    const trail = s.w.fi.audits.find((e) => e.action === 'asset_integrity.delete_asset')!;
    assert.equal(trail.actorUserId, h.id, 'the actor is the verified token, nothing from the request');
    assert.equal(trail.requestId, 'req-abcdef01');
  });

  it('budgets per address: 429 with Retry-After', async () => {
    const s = http(true);
    const h = await s.account('admin');
    for (let i = 0; i < INTEGRITY_RATE_LIMITS.scan.limit; i++) assert.equal((await s.call('GET', SCAN, { headers: h })).status, 200);
    const denied = await s.call('GET', SCAN, { headers: h });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
  });

  it('maps errors: validation 400 with fields, busy 409, authz 404, anything else not ours', () => {
    assert.equal(toIntegrityHttp(new IntegrityError('validation_failed', [{ field: 'confirm', code: 'required' }]))?.status, 400);
    assert.equal(toIntegrityHttp(new IntegrityError('busy'))?.status, 409);
    assert.equal(toIntegrityHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toIntegrityHttp(new Error('boom')), undefined);
  });
});

describe('asset integrity: SQL and source guards', () => {
  it('the asset lookup is one parameterized SELECT; the audited delete reuses the locked compare-and-swap and writes the audit row in the same transaction', () => {
    assert.match(GET_ASSET_SQL, /^SELECT a\.id, a\.kind, a\.status, a\.storage_key, a\.thumb_key,/);
    assert.match(GET_ASSET_SQL, /WHERE a\.id = \$1::uuid$/);
    assert.ok(!/\b(INSERT|UPDATE|DELETE)\b/i.test(GET_ASSET_SQL));
    const repo = code('src/assets/integrity-repository.ts');
    assert.ok(!/DELETE FROM/i.test(repo), 'the DELETE statement itself stays in audit-repository.ts, shared with the audit');
    assert.match(repo, /SET LOCAL lock_timeout[\s\S]*LOCK_READY_SQL[\s\S]*buildDeleteUnlinked|buildDeleteUnlinked[\s\S]*LOCK_READY_SQL/);
    assert.match(repo, /db\.tx\(async \(t\) => \{[\s\S]*LOCK_READY_SQL[\s\S]*await createPgAuditRepository\(t\)\.record\(input\.audit\);\s*return true;/);
  });

  it('the service: authorizes BEFORE parsing; the scan can only dry-run; there is no put, no SQL, no spread of a row; deletion is the audited paths only', () => {
    const svc = code('src/assets/integrity.ts');
    assert.match(svc, /authorize\(actor, 'read', assetIntegrityResource\(\)\);[^\n]*\n\s*const parsed = parseScanQuery/);
    assert.match(svc, /authorize\(actor, 'delete', assetIntegrityResource\(\)\);\n\s*const parsed = parseCleanupBody/);
    assert.match(svc, /dryRun: true/);
    assert.ok(!/dryRun: false/.test(svc));
    assert.ok(!/storage\.put|\.put\(/.test(svc), 'never writes an object');
    assert.ok(!/\b(INSERT INTO|UPDATE \w+ SET|DELETE FROM)\b/i.test(svc));
    assert.ok(!/\.\.\.(r|row|f|it)\b/.test(svc));
    assert.equal((svc.match(/storage\.delete\(/g) ?? []).length, 2, 'exactly the asset objects and the orphan object');
    assert.equal((svc.match(/repo\.deleteUnlinkedAudited\(/g) ?? []).length, 1);
    assert.ok(!/repo\.deleteUnlinked\(/.test(svc), 'the unaudited delete is never used here');
  });

  it('the scan route is a GET, the cleanup route a POST; both identify through the verified access token only', () => {
    const routes = code('src/assets/integrity-routes.ts');
    assert.match(routes, /app\.get\('\/v1\/admin\/asset-integrity\/scan'/);
    assert.match(routes, /app\.post\('\/v1\/admin\/asset-integrity\/cleanup'/);
    assert.equal((routes.match(/app\.(get|post|put|patch|delete)\(/g) ?? []).length, 2);
    assert.match(routes, /return toActor\(found\.user\);/);
  });

  it('wired only together with authentication and the configured storage, with the Postgres-backed repository', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.assetIntegrity\) registerAssetIntegrityRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /assets && storage \? createAssetIntegrityService\(\{ repo: createPgIntegrityRepository\(db\), storage, logger: boot \}\)/);
    assert.match(index, /buildServer\(\{[^\n]*\.\.\.\(assetIntegrity \? \{ assetIntegrity \} : \{\}\)/);
  });

  it('the observer added to the audit changes nothing for the CLI: the scan is the audit run with dryRun and the same checks', () => {
    const audit = code('src/assets/audit.ts');
    assert.match(audit, /observer\?: AuditObserver/);
    assert.match(code('src/assets/integrity.ts'), /runAssetAudit\(/);
  });
});

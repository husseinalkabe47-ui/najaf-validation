// Phase 11.9-E: subscription expiry. Unit level: options, the runner with an in-memory repository (idempotence, bounds, failure codes,
// dry run), the boundary rule, the operator script's argument parser and source/SQL guards. The real SQL runs in
// test/integration/subscription-expiry.integration.test.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DbError } from '../../src/errors.ts';
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import { COUNT_EXPIRABLE_SQL, EXPIRE_BATCH_SQL } from '../../src/subscriptions/expiry-repository.ts';
import type { SubscriptionExpiryRepository } from '../../src/subscriptions/expiry-repository.ts';
import { EXPIRY_DEFAULTS, EXPIRY_LIMITS, ExpiryOptionsError, resolveExpiryOptions, runSubscriptionExpiry } from '../../src/subscriptions/expiry.ts';
import type { ExpiryLogger } from '../../src/subscriptions/expiry.ts';
import { planGrant } from '../../src/subscriptions/service.ts';
import { parseExpiryArgs } from '../../scripts/subscriptions-expire.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) => readFileSync(join(ROOT, rel), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').split('\n').map((l) => l.replace(/^\s*\/\/.*$/, '')).join('\n');
const NOW = new Date('2026-10-14T12:00:00Z');

type Sub = { id: string; showroomId: string; planId: string; status: string; periodEnd: Date };
/** In-memory stand-in with the real rule: live status and end <= at; each changed row gets exactly one audit row. */
function fakeRepo(subs: Sub[], opts: { failOnBatch?: number } = {}) {
  const audits: AuditEvent[] = [];
  let batches = 0;
  const due = (s: Sub, at: Date) => ['trialing', 'active', 'past_due'].includes(s.status) && s.periodEnd.getTime() <= at.getTime();
  const repo: SubscriptionExpiryRepository = {
    async countExpirable(at = NOW) { return subs.filter((s) => due(s, at)).length; },
    async expireBatch(limit, at = NOW) {
      batches++;
      if (opts.failOnBatch === batches) throw new DbError('unavailable');
      const rows = subs.filter((s) => due(s, at)).sort((a, b) => a.periodEnd.getTime() - b.periodEnd.getTime() || Number(a.id) - Number(b.id)).slice(0, limit);
      for (const r of rows) {
        r.status = 'expired';
        audits.push({ action: 'subscription.expire', actorUserId: null, actorRole: 'system', entityType: 'subscription', entityId: r.id, afterData: { showroomId: Number(r.showroomId), planId: Number(r.planId), periodEnd: Math.floor(r.periodEnd.getTime() / 1000) } });
      }
      return rows.length;
    },
  };
  return { repo, audits, subs };
}
const sub = (id: string, status: string, end: string): Sub => ({ id, showroomId: String(100 + Number(id)), planId: '2', status, periodEnd: new Date(end) });
const recorder = () => { const events: Array<Record<string, unknown>> = []; const logger: ExpiryLogger = { info: (o) => events.push({ level: 'info', ...o }), warn: (o) => events.push({ level: 'warn', ...o }), error: (o) => events.push({ level: 'error', ...o }) }; return { logger, events }; };

describe('subscription expiry: options', () => {
  it('defaults to a dry run with bounded batches', () => {
    assert.deepEqual(resolveExpiryOptions(), { dryRun: true, batchSize: EXPIRY_DEFAULTS.batchSize, maxBatches: EXPIRY_DEFAULTS.maxBatches });
    assert.equal(resolveExpiryOptions({ dryRun: false }).dryRun, false);
    assert.equal(resolveExpiryOptions({ dryRun: undefined }).dryRun, true);
  });
  it('refuses out-of-range or non-integer bounds', () => {
    for (const bad of [{ batchSize: 0 }, { batchSize: EXPIRY_LIMITS.batchSizeMax + 1 }, { batchSize: 1.5 }, { maxBatches: 0 }, { maxBatches: EXPIRY_LIMITS.maxBatchesMax + 1 }, { maxBatches: Number.NaN }]) {
      assert.throws(() => resolveExpiryOptions(bad), (e: unknown) => e instanceof ExpiryOptionsError, JSON.stringify(bad));
    }
  });
});

describe('subscription expiry: the boundary', () => {
  it('a subscription that ends exactly at the instant is expired (end <= now); one millisecond later it is still in force', async () => {
    const f = fakeRepo([sub('1', 'active', '2026-10-14T12:00:00Z'), sub('2', 'active', '2026-10-14T12:00:00.001Z'), sub('3', 'active', '2026-10-14T11:59:59.999Z')]);
    const r = await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false });
    assert.equal(r.expired, 2);
    assert.deepEqual(f.subs.map((s) => s.status), ['expired', 'active', 'expired']);
  });
  it('agrees with the renewal rule of 11.9-D (planGrant): ends exactly now = expired = renewed after expiry', () => {
    assert.equal(planGrant({ periodEnd: NOW, planId: '2' }, '2', 3, NOW).kind, 'renewed_after_expiry');
    assert.equal(planGrant({ periodEnd: new Date(NOW.getTime() + 1), planId: '2' }, '2', 3, NOW).kind, 'renewed');
  });
  it('covers every live status (trialing, active, past_due) and never touches expired or canceled rows', async () => {
    const f = fakeRepo([sub('1', 'trialing', '2026-01-01T00:00:00Z'), sub('2', 'active', '2026-01-01T00:00:00Z'), sub('3', 'past_due', '2026-01-01T00:00:00Z'), sub('4', 'expired', '2026-01-01T00:00:00Z'), sub('5', 'canceled', '2026-01-01T00:00:00Z')]);
    assert.equal((await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false })).expired, 3);
    assert.deepEqual(f.subs.map((s) => s.status), ['expired', 'expired', 'expired', 'expired', 'canceled']);
    assert.deepEqual(f.audits.map((a) => a.entityId), ['1', '2', '3']);
  });
});

describe('subscription expiry: the runner', () => {
  it('a dry run counts and changes nothing, writes no audit row', async () => {
    const f = fakeRepo([sub('1', 'active', '2026-01-01T00:00:00Z'), sub('2', 'active', '2027-01-01T00:00:00Z')]);
    const r = await runSubscriptionExpiry({ repo: f.repo, at: NOW });
    assert.deepEqual([r.dryRun, r.eligible, r.expired, r.batches, r.complete], [true, 1, 0, 0, true]);
    assert.deepEqual(f.subs.map((s) => s.status), ['active', 'active']); assert.deepEqual(f.audits, []);
  });
  it('expires the due subscriptions with ONE audit row each (actor = the system, numbers only), leaving future ones alone', async () => {
    const f = fakeRepo([sub('1', 'active', '2026-01-01T00:00:00Z'), sub('2', 'active', '2027-01-01T00:00:00Z'), sub('3', 'past_due', '2026-06-01T00:00:00Z')]);
    const r = await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false });
    assert.deepEqual([r.expired, r.eligible, r.complete, r.error, r.alerts], [2, 2, true, null, []]);
    assert.deepEqual(f.subs.map((s) => s.status), ['expired', 'active', 'expired']);
    assert.equal(f.audits.length, 2);
    for (const a of f.audits) {
      assert.deepEqual([a.action, a.actorUserId, a.actorRole, a.entityType], ['subscription.expire', null, 'system', 'subscription']);
      assertAuditSafe(a);
    }
    assert.deepEqual(f.audits[0]!.afterData, { showroomId: 101, planId: 2, periodEnd: Math.floor(new Date('2026-01-01T00:00:00Z').getTime() / 1000) });
  });
  it('is idempotent: a second and a third run change nothing and add no transition or audit row', async () => {
    const f = fakeRepo([sub('1', 'active', '2026-01-01T00:00:00Z'), sub('2', 'trialing', '2026-02-01T00:00:00Z')]);
    await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false });
    const snap = JSON.stringify([f.subs, f.audits]);
    for (let i = 0; i < 2; i++) {
      const r = await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false });
      assert.deepEqual([r.expired, r.complete, r.error], [0, true, null]);
    }
    assert.equal(JSON.stringify([f.subs, f.audits]), snap);
  });
  it('works in bounded batches, continues on the next run, and signals a backlog when the bound is reached', async () => {
    const f = fakeRepo(Array.from({ length: 5 }, (_, i) => sub(String(i + 1), 'active', '2026-01-01T00:00:00Z')));
    const first = await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false, batchSize: 2, maxBatches: 2 });
    assert.deepEqual([first.expired, first.batches, first.complete], [4, 2, false]);
    assert.deepEqual(first.alerts, [{ code: 'backlog_remaining', value: 4, threshold: 4 }]);
    const second = await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false, batchSize: 2, maxBatches: 2 });
    assert.deepEqual([second.expired, second.complete, second.alerts], [1, true, []]);
    assert.equal(f.audits.length, 5); assert.equal(new Set(f.audits.map((a) => a.entityId)).size, 5);
  });
  it('a database failure stops the run with a CODE only; what was done stays, and a rerun finishes the rest', async () => {
    const f = fakeRepo(Array.from({ length: 4 }, (_, i) => sub(String(i + 1), 'active', '2026-01-01T00:00:00Z')), { failOnBatch: 2 });
    const { logger, events } = recorder();
    const r = await runSubscriptionExpiry({ repo: f.repo, logger, at: NOW }, { dryRun: false, batchSize: 2, maxBatches: 5 });
    assert.deepEqual([r.error, r.expired, r.complete], ['database_unavailable', 2, false]);
    assert.deepEqual(events.filter((e) => e['level'] === 'error').map((e) => e['code']), ['database_unavailable']);
    assert.ok(events.every((e) => !('message' in e) && !('stack' in e))); // codes only
    const again = await runSubscriptionExpiry({ repo: f.repo, at: NOW }, { dryRun: false, batchSize: 2 });
    assert.equal(again.expired, 2); assert.equal(f.audits.length, 4);
    const unexpected = await runSubscriptionExpiry({ repo: { countExpirable: async () => { throw new TypeError('boom'); }, expireBatch: async () => 0 } });
    assert.equal(unexpected.error, 'unexpected');
  });
});

describe('subscription expiry: operator script arguments', () => {
  it('is a dry run unless --execute is given, and accepts the two bounds', () => {
    assert.equal(parseExpiryArgs([]).dryRun, true);
    assert.deepEqual(parseExpiryArgs(['--execute', '--batch-size=50', '--max-batches=3']), { dryRun: false, batchSize: 50, maxBatches: 3 });
    assert.equal(parseExpiryArgs(['--execute', '--dry-run']).dryRun, true);
  });
  it('names (never echoes the value of) invalid arguments', () => {
    for (const [argv, expected] of [[['--batch-size=0'], ['--batch-size']], [['--max-batches=abc'], ['--max-batches']], [['--batch-size=5000'], ['--batch-size']], [['--execute=yes'], ['--execute']], [['--purge'], ['--purge']], [['nonsense value'], ['unknown argument']]] as const) {
      assert.throws(() => parseExpiryArgs(argv), (e: unknown) => e instanceof ExpiryOptionsError && JSON.stringify(e.problems) === JSON.stringify(expected), argv.join(' '));
    }
  });
});

describe('subscription expiry: SQL and source guards', () => {
  it('uses the entitlement rule (live status, end <= the database clock) and a locked compare-and-swap that re-checks both', () => {
    for (const sql of [COUNT_EXPIRABLE_SQL, EXPIRE_BATCH_SQL]) {
      assert.match(sql, /status IN \('trialing', 'active', 'past_due'\)/);
      assert.match(sql, /current_period_end <= COALESCE\(\$1::timestamptz, now\(\)\)/);
    }
    assert.match(EXPIRE_BATCH_SQL, /FOR UPDATE SKIP LOCKED/);
    assert.match(EXPIRE_BATCH_SQL, /SET status = 'expired'/);
    assert.match(EXPIRE_BATCH_SQL, /WHERE s\.id = c\.id AND s\.status IN \('trialing', 'active', 'past_due'\) AND s\.current_period_end <= COALESCE/);
    assert.match(readFileSync(join(ROOT, '..', 'database', 'migrations', '0011_audit_settings_functions.sql'), 'utf8'), /s\.current_period_end > now\(\)/); // the other side of the same boundary
  });
  it('the module only sets status, never inserts into or deletes from subscriptions or payments, never touches plans, and audits through the single writer', () => {
    const r = code('src/subscriptions/expiry-repository.ts');
    assert.doesNotMatch(r, /INSERT\s+INTO|DELETE\s+FROM|TRUNCATE|UPDATE\s+(payments|subscription_plans)/i);
    const updates = (r.match(/UPDATE\s+subscriptions\s+s?\s*SET[^`]*/gi) ?? []).map((u: string) => u.replace(/\s+/g, ' ').trim());
    assert.equal(updates.length, 1);
    assert.ok(updates[0]!.startsWith("UPDATE subscriptions s SET status = 'expired' FROM c WHERE s.id = c.id"), updates[0]);
    assert.match(r, /createPgAuditRepository\(t\)/);
    assert.doesNotMatch(r, /INSERT\s+INTO\s+audit_logs/i);
    assert.match(r, /db\.tx\(/); // rows and audit rows in ONE transaction
  });
  it('no scheduler, timer, network, messaging, payment or entitlement code, and the server does not start it', () => {
    for (const f of ['src/subscriptions/expiry.ts', 'src/subscriptions/expiry-repository.ts', 'scripts/subscriptions-expire.ts']) assert.doesNotMatch(code(f), /setInterval|setTimeout|cron|fetch\(|https?:\/\/|whatsapp|sms|stripe|webhook/i, f);
    for (const f of ['src/server.ts', 'src/index.ts']) assert.doesNotMatch(code(f), /expiry|subscriptions:expire/i, f);
    assert.match(readFileSync(join(ROOT, 'package.json'), 'utf8'), /"subscriptions:expire": "node [^"]*scripts\/subscriptions-expire\.ts"/);
  });
});

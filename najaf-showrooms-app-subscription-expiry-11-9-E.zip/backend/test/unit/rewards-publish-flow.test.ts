// Phase 11.8-D (unit side, runs without a database): the Android reward-to-publish flow over the real service, the real AdMob verifier and
// callback handler and the in-memory store. Covers the gaps around the existing suites: stale and expired callbacks, grant/user mismatches
// across accounts, concurrent repeats of Google's callback, failure safety of every step, and the website boundary.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DbError } from '../../src/errors.ts';
import { createAdmobCallbackHandler, createAdmobKeyStore, createAdmobRewardVerifier } from '../../src/rewards/admob.ts';
import { createRewardService } from '../../src/rewards/service.ts';
import { TEST_AD_UNIT, TEST_KEY_ID, makeAdmobSigner } from '../helpers/admob-sign.ts';
import { makeFakeRewards } from '../helpers/fake-rewards.ts';

const T0 = Date.now();
type Role = 'member' | 'dealer' | 'admin';

function world() {
  const clock = { t: T0, now: () => clock.t };
  const signer = makeAdmobSigner();
  const keys = createAdmobKeyStore({ now: clock.now, fetchKeys: async () => [{ keyId: TEST_KEY_ID, pem: signer.pem }] });
  const fr = makeFakeRewards(clock);
  const verifier = createAdmobRewardVerifier({ config: { adUnitId: TEST_AD_UNIT }, keys, now: clock.now });
  const svc = createRewardService({ store: fr.store, verifier });
  const handler = createAdmobCallbackHandler({ rewards: svc, keys });
  for (const id of ['7', '8']) fr.addUser(id);
  fr.addCar('100', '7');
  fr.addCar('101', '7');
  fr.addCar('200', '8');
  const actor = (id: string, role: Role = 'member') => ({ id, role });
  const open = async (id = '7') => ({ id: (await svc.requestReward(actor(id))).id, userId: id });
  const ts = (offsetMs: number) => String(clock.t + offsetMs);
  return { clock, signer, fr, svc, handler, actor, open, ts };
}
const grantStates = (w: ReturnType<typeof world>) => w.fr.grants().map((g) => g.status);

describe('reward -> publish: the Android lifecycle', () => {
  it('request, signed callback, verified grant, authenticated consumption, direct publication: each step changes exactly one thing', async () => {
    const w = world();
    const g = await w.open();
    assert.deepEqual([grantStates(w), w.fr.car('100')!.status], [['requested'], 'pending']);
    assert.deepEqual(await w.handler.handle(w.signer.query(g, { timestamp: w.ts(-1000) })), { status: 200, code: 'ok' });
    assert.deepEqual([grantStates(w), w.fr.car('100')!.status, w.fr.audits().length], [['verified'], 'pending', 0]);
    const out = await w.svc.consumeReward(w.actor('7'), g.id, '100');
    assert.deepEqual(out, { id: g.id, carId: '100', status: 'consumed', published: true });
    assert.deepEqual([grantStates(w), w.fr.car('100')!.status, w.fr.car('100')!.version, w.fr.car('101')!.status, w.fr.audits().length], [['consumed'], 'active', 2, 'pending', 1]);
    assert.deepEqual(w.fr.audits()[0], { action: 'member_car.reward_publish', actorUserId: '7', actorRole: 'user', entityType: 'car', entityId: '100', afterData: { version: 2 } });
  });
});

describe('reward -> publish: callbacks that must not verify', () => {
  it('stale, future and expired-grant callbacks leave the grant requested and the ad pending', async () => {
    const w = world();
    const g = await w.open();
    for (const q of [w.signer.query(g, { timestamp: w.ts(-2 * 3600 * 1000) }), w.signer.query(g, { timestamp: w.ts(3600 * 1000) }), w.signer.query(g, { timestamp: undefined })]) {
      assert.deepEqual(await w.handler.handle(q), { status: 400, code: 'rejected' });
    }
    w.clock.t += 31 * 60 * 1000; // the grant's own lifetime (30 minutes) is over, though the callback itself is fresh
    assert.deepEqual(await w.handler.handle(w.signer.query(g, { timestamp: w.ts(-1000) })), { status: 400, code: 'rejected' });
    assert.deepEqual([grantStates(w), w.fr.car('100')!.status], [['requested'], 'pending']);
    await assert.rejects(w.svc.consumeReward(w.actor('7'), g.id, '100'), { code: 'invalid_state' });
  });

  it('data of one account can never verify another account\'s grant, in either direction, and the other grant is untouched', async () => {
    const w = world();
    const mine = await w.open('7');
    const theirs = await w.open('8');
    const answers = [
      await w.handler.handle(w.signer.query(mine, { custom_data: theirs.id })), // my user id, their grant
      await w.handler.handle(w.signer.query(theirs, { custom_data: mine.id })), // their user id, my grant
      await w.handler.handle(w.signer.query(mine, { user_id: undefined })),
      await w.handler.handle(w.signer.query(mine, { custom_data: undefined })),
    ];
    for (const a of answers) assert.deepEqual(a, { status: 400, code: 'rejected' });
    assert.deepEqual(grantStates(w), ['requested', 'requested']);
  });

  it('a spent transaction id cannot verify another grant of the same or another account; the second grant cannot publish', async () => {
    const w = world();
    const a = await w.open('7');
    const b = await w.open('8');
    assert.equal((await w.handler.handle(w.signer.query(a, { transaction_id: 'SHARED01' }))).status, 200);
    assert.equal((await w.handler.handle(w.signer.query(b, { transaction_id: 'SHARED01' }))).status, 400);
    assert.deepEqual(grantStates(w), ['verified', 'requested']);
    await assert.rejects(w.svc.consumeReward(w.actor('8'), b.id, '200'), { code: 'invalid_state' });
    assert.equal(w.fr.car('200')!.status, 'pending');
  });

  it('a callback for another ad unit (a website or another developer\'s unit) is no proof, however well it is signed', async () => {
    const w = world();
    const g = await w.open();
    assert.equal((await w.handler.handle(w.signer.query(g, { ad_unit: '7777777' }))).status, 400);
    assert.equal((await w.handler.handle(w.signer.query(g, {}, { signWith: w.signer.otherKey() }))).status, 400);
    assert.deepEqual([grantStates(w), w.fr.car('100')!.status], [['requested'], 'pending']);
  });
});

describe('reward -> publish: idempotence', () => {
  it('five concurrent copies of Google\'s callback: all 200, one verified grant, one receipt, no new grant', async () => {
    const w = world();
    const g = await w.open();
    const q = w.signer.query(g, { transaction_id: 'ONCE0001' });
    const results = await Promise.all(Array.from({ length: 5 }, () => w.handler.handle(q)));
    assert.ok(results.every((r) => r.status === 200), JSON.stringify(results));
    assert.equal(w.fr.grants().length, 1);
    assert.deepEqual([w.fr.grants()[0]!.status, w.fr.grants()[0]!.ssvTransactionId], ['verified', 'ONCE0001']);
  });

  it('the callback repeated after consumption is 200 and changes nothing; repeating consume publishes and audits nothing more', async () => {
    const w = world();
    const g = await w.open();
    const q = w.signer.query(g, { transaction_id: 'ONCE0002' });
    await w.handler.handle(q);
    await w.svc.consumeReward(w.actor('7'), g.id, '100');
    const before = { car: w.fr.car('100')!, audits: w.fr.audits().length, grant: w.fr.grants()[0]! };
    assert.equal((await w.handler.handle(q)).status, 200);
    const again = await w.svc.consumeReward(w.actor('7'), g.id, '100');
    assert.deepEqual(again, { id: g.id, carId: '100', status: 'consumed', published: true });
    assert.deepEqual([w.fr.car('100'), w.fr.audits().length, w.fr.grants().length, w.fr.grants()[0]!.status], [before.car, before.audits, 1, 'consumed']);
    assert.equal(w.fr.grants()[0]!.consumedAt!.getTime(), before.grant.consumedAt!.getTime());
  });

  it('concurrent consumptions of a verified grant for two ads publish exactly one', async () => {
    const w = world();
    const g = await w.open();
    await w.handler.handle(w.signer.query(g));
    const r = await Promise.allSettled([w.svc.consumeReward(w.actor('7'), g.id, '100'), w.svc.consumeReward(w.actor('7'), g.id, '101')]);
    assert.equal(r.filter((x) => x.status === 'fulfilled').length, 1);
    assert.equal(['100', '101'].filter((id) => w.fr.car(id)!.status === 'active').length, 1);
    assert.equal(w.fr.audits().length, 1);
  });
});

describe('reward -> publish: failure safety', () => {
  const unavailable = () => new DbError('unavailable', { sqlstate: '08006' });

  it('a database error while verifying is not success: the callback propagates it (5xx, Google retries), nothing is verified or published; the retry then works', async () => {
    const w = world();
    const g = await w.open();
    const q = w.signer.query(g);
    w.fr.faults.beforeMarkVerified = () => { throw unavailable(); };
    await assert.rejects(w.handler.handle(q), DbError);
    await assert.rejects(w.svc.consumeReward(w.actor('7'), g.id, '100'), { code: 'invalid_state' });
    assert.deepEqual([grantStates(w), w.fr.car('100')!.status, w.fr.audits().length], [['requested'], 'pending', 0]);
    w.fr.faults.beforeMarkVerified = null;
    assert.equal((await w.handler.handle(q)).status, 200);
  });

  it('a failure in consumption, in the publish statement or in its audit row rolls everything back; a healthy retry publishes exactly once', async () => {
    for (const fault of ['consume', 'publish', 'audit'] as const) {
      const w = world();
      const g = await w.open();
      await w.handler.handle(w.signer.query(g));
      if (fault === 'consume') w.fr.faults.beforeConsume = () => { throw unavailable(); };
      if (fault === 'publish') w.fr.faults.beforePublish = () => { throw unavailable(); };
      if (fault === 'audit') w.fr.faults.failAudit = true;
      await assert.rejects(w.svc.consumeReward(w.actor('7'), g.id, '100'), () => true, fault);
      assert.deepEqual([w.fr.grants()[0]!.status, w.fr.grants()[0]!.carId, w.fr.car('100')!.status, w.fr.car('100')!.version, w.fr.audits().length], ['verified', null, 'pending', 1, 0], fault);
      assert.equal(w.fr.openTransactions(), 0);
      w.fr.faults.beforeConsume = null;
      w.fr.faults.beforePublish = null;
      w.fr.faults.failAudit = false;
      assert.equal((await w.svc.consumeReward(w.actor('7'), g.id, '100')).published, true, fault);
      assert.deepEqual([w.fr.car('100')!.status, w.fr.audits().length], ['active', 1], fault);
    }
  });

  it('failed or missing verification never publishes: invalid callback then consume, no callback at all, consume with another account\'s grant', async () => {
    const w = world();
    const g = await w.open();
    assert.equal((await w.handler.handle(w.signer.query(g, {}, { signWith: w.signer.otherKey() }))).status, 400);
    await assert.rejects(w.svc.consumeReward(w.actor('7'), g.id, '100'), { code: 'invalid_state' });
    const other = await w.open('8');
    await w.handler.handle(w.signer.query(other));
    await assert.rejects(w.svc.consumeReward(w.actor('7'), other.id, '100'), { code: 'not_found' });
    assert.deepEqual([w.fr.car('100')!.status, w.fr.car('200')!.status, w.fr.audits().length], ['pending', 'pending', 0]);
  });
});

describe('reward -> publish: the website boundary', () => {
  it('a callback is about a grant, never about an ad: even a signed car_id parameter publishes nothing, and the callback alone never publishes', async () => {
    const w = world();
    const g = await w.open();
    assert.equal((await w.handler.handle(w.signer.query(g, { car_id: '100', published: 'true', status: 'active' }))).status, 200);
    assert.deepEqual([w.fr.car('100')!.status, w.fr.car('101')!.status, w.fr.grants()[0]!.carId, w.fr.audits().length], ['pending', 'pending', null, 0]);
  });

  it('a showroom owner\'s or administrator\'s verified Android reward does not publish either (the administrator path is unchanged)', async () => {
    for (const role of ['dealer', 'admin'] as const) {
      const w = world();
      const g = await w.open();
      await w.handler.handle(w.signer.query(g));
      const out = await w.svc.consumeReward(w.actor('7', role), g.id, '100');
      assert.deepEqual([out.published, w.fr.car('100')!.status], [false, 'pending'], role);
    }
  });
});

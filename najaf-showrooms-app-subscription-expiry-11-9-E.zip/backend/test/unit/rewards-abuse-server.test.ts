// Phase 11.8-E through the REAL Fastify server (buildServer + inject): which address the limits see. Forwarding headers count only when the server
// was started with an explicit trusted-proxy list (the project-wide setting); otherwise they are ignored, so a client cannot dodge a limit or
// frame another address by sending X-Forwarded-For. Needs `fastify` (installed in CI); without it the file is SKIPPED visibly.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { ADMOB_GRANT_RATE_LIMIT, ADMOB_UNTRUSTED_RATE_LIMIT } from '../../src/rewards/admob-routes.ts';
import type { AdmobCallbackApi } from '../../src/rewards/admob.ts';
import { REWARD_RATE_LIMITS } from '../../src/rewards/routes.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let reason: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'silent', NODE_ENV: 'test' });
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };
const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';

async function server(trustProxy: string[] | undefined, kind: 'untrusted' | 'trusted' = 'untrusted') {
  const clock = makeClock();
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: makeFakeAuthStore(clock).store, hasher, accessTokenSecret: SECRET, logger: recordingLogger().logger, now: clock.now });
  const callbacks: AdmobCallbackApi = {
    precheck: async () => (kind === 'trusted' ? { kind: 'trusted', grantKey: 'g-1' } : { kind: 'untrusted' }),
    handle: async () => ({ status: 200, code: 'ok' }),
  };
  const rewards = { requestReward: async () => { throw new Error('not reached'); }, consumeReward: async () => { throw new Error('not reached'); } };
  return buildServer!({ config, db: okDb, auth, rewards, rewardCallbacks: callbacks, rateLimiter: createMemoryRateLimiter(), ...(trustProxy ? { trustProxy } : {}) });
}
const ssv = (app: Awaited<ReturnType<typeof server>>, remoteAddress: string, xff?: string) =>
  app.inject({ method: 'GET', url: '/v1/rewards/admob/ssv?junk=1', remoteAddress, ...(xff ? { headers: { 'x-forwarded-for': xff } } : {}) });
const asking = (app: Awaited<ReturnType<typeof server>>, remoteAddress: string, xff?: string) =>
  app.inject({ method: 'POST', url: '/v1/me/rewards', remoteAddress, ...(xff ? { headers: { 'x-forwarded-for': xff } } : {}) });

describe('reward limits see the real address (real server)', { skip: reason }, () => {
  it('no trusted proxy: X-Forwarded-For is ignored. Spoofing a new address on every garbage callback does not dodge the budget, and cannot frame another address', async () => {
    const app = await server(undefined);
    for (let i = 0; i < ADMOB_UNTRUSTED_RATE_LIMIT.limit; i++) assert.equal((await ssv(app, '198.51.100.20', `203.0.113.${(i % 250) + 1}`)).statusCode, 400);
    assert.equal((await ssv(app, '198.51.100.20', '203.0.113.250')).statusCode, 429);
    assert.equal((await ssv(app, '198.51.100.21', '198.51.100.20')).statusCode, 400, 'another socket address is not framed by a header naming the blocked one');
    await app.close();
  });

  it('no trusted proxy: the coarse per-address guard on the member routes cannot be dodged with forwarding headers either', async () => {
    const app = await server(undefined);
    for (let i = 0; i < REWARD_RATE_LIMITS.request.limit; i++) assert.equal((await asking(app, '198.51.100.30', `203.0.113.${(i % 250) + 1}`)).statusCode, 401);
    assert.equal((await asking(app, '198.51.100.30', '203.0.113.251')).statusCode, 429);
    await app.close();
  });

  it('explicit trusted proxy: the forwarded address is used, but only when the request really came from that proxy', async () => {
    const app = await server(['10.0.0.0/8']);
    for (let i = 0; i < ADMOB_UNTRUSTED_RATE_LIMIT.limit; i++) assert.equal((await ssv(app, '10.0.0.9', '203.0.113.7')).statusCode, 400);
    assert.equal((await ssv(app, '10.0.0.9', '203.0.113.7')).statusCode, 429, 'that client, seen through the trusted proxy, is blocked');
    assert.equal((await ssv(app, '10.0.0.9', '203.0.113.8')).statusCode, 400, 'a different client behind the same proxy has its own budget');
    // a request NOT from the proxy that sends the same header is counted by its own socket address
    assert.equal((await ssv(app, '192.0.2.9', '203.0.113.7')).statusCode, 400);
    await app.close();
  });

  it('genuinely signed callbacks are never counted against an address (only per grant), so no number of them from one address is blocked by address', async () => {
    const app = await server(undefined, 'trusted');
    // this stub answers one grant key for every call: the per-grant limit is what applies (limit times 200, then 429), never the address
    for (let i = 0; i < ADMOB_GRANT_RATE_LIMIT.limit; i++) assert.equal((await ssv(app, '198.51.100.40')).statusCode, 200);
    assert.equal((await ssv(app, '198.51.100.40')).statusCode, 429);
    await app.close();
  });
});

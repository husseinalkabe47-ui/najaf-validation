// Test helper (never part of src): signs AdMob SSV callbacks the way AdMob does, with a key generated for the test run.
// ECDSA P-256 / SHA-256 over the query before "&signature=", DER, web-safe base64; parameters alphabetical, then signature, then key_id.
import { generateKeyPairSync, sign } from 'node:crypto';
import type { KeyObject } from 'node:crypto';

export type EcPair = { publicKey: KeyObject; privateKey: KeyObject };
const newPair = (): EcPair => generateKeyPairSync('ec', { namedCurve: 'prime256v1' });

export const TEST_AD_UNIT = '1234567890';
export const TEST_KEY_ID = '3335741209';

export type SsvParams = Record<string, string | undefined>;

export function makeAdmobSigner() {
  const pair = newPair();
  const pem = pair.publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  /** The query string (after '?') of a callback for this grant; `over` replaces or (with undefined) removes parameters. */
  function query(grant: { id: string; userId: string }, over: SsvParams = {}, opts: { keyId?: string; signWith?: EcPair | null } = {}): string {
    const base: SsvParams = {
      ad_network: '5450213213286189855', ad_unit: TEST_AD_UNIT, custom_data: grant.id, reward_amount: '1', reward_item: 'publish',
      timestamp: String(Date.now() - 2000), transaction_id: `TX${Math.random().toString(16).slice(2)}${Date.now()}`, user_id: grant.userId, ...over,
    };
    const content = Object.keys(base).sort().filter((n) => base[n] !== undefined).map((n) => `${n}=${encodeURIComponent(base[n]!)}`).join('&');
    const key = (opts.signWith ?? pair).privateKey;
    const sig = sign('sha256', Buffer.from(content, 'utf8'), { key, dsaEncoding: 'der' });
    return `${content}&signature=${b64url(sig)}&key_id=${opts.keyId ?? TEST_KEY_ID}`;
  }
  return { pem, query, otherKey: (): EcPair => newPair() };
}

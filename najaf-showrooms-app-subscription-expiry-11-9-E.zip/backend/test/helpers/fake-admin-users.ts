// In-memory AdminUsersRepository (Phase 11.7.2-J). It mirrors, independently of src, what the SQL decides: the directory and every
// count leave out soft-deleted accounts and cars; the role filter and keyset are by ascending id; member ads are source 'member';
// a showroom is found by owner. Rows carry SECRET columns (password hash, counters, lock) exactly as the table does, so a test can
// prove they never reach a response.
import type { AdminUsersRepository, UserRole } from '../../src/admin-users/repository.ts';

export interface FakeAdminUser {
  id: string;
  name: string;
  phoneE164: string;
  email: string | null;
  role: string;
  status: string;
  createdAt: Date;
  deleted: boolean;
  passwordHash: string;
  failedLogins: number;
  lockedUntil: Date | null;
}
export interface FakeAdminCar {
  id: string;
  sourceType: 'member' | 'showroom';
  ownerId: string | null;
  showroomId: string | null;
  brand: string;
  model: string;
  status: string;
  deleted: boolean;
}

export function makeFakeAdminUsersRepo() {
  const users: FakeAdminUser[] = [];
  const showrooms: Array<{ id: string; ownerId: string; name: string; status: string }> = [];
  const cars: FakeAdminCar[] = [];
  const calls: string[] = [];
  let seq = 0;
  const live = () => users.filter((u) => !u.deleted);
  const memberCars = () => cars.filter((c) => c.sourceType === 'member' && !c.deleted);

  const repo: AdminUsersRepository = {
    async listUsers({ role, afterId, limit }: { role: UserRole | null; afterId: string | null; limit: number }) {
      calls.push('listUsers');
      return live()
        .filter((u) => (role === null || u.role === role) && (afterId === null || BigInt(u.id) > BigInt(afterId)))
        .sort((a, b) => Number(BigInt(a.id) - BigInt(b.id)))
        .slice(0, limit)
        .map((u) => ({ ...u })); // the WHOLE row, secrets included: the service must pick fields
    },
    async findUser(id) {
      calls.push('findUser');
      const u = live().find((x) => x.id === id);
      return u ? { ...u } : null;
    },
    async findShowroomOfOwner(ownerId) {
      calls.push('findShowroomOfOwner');
      const s = showrooms.find((x) => x.ownerId === ownerId);
      return s ? { ...s } : null;
    },
    async listMemberCarsOfOwner(ownerId, limit) {
      calls.push('listMemberCarsOfOwner');
      return memberCars().filter((c) => c.ownerId === ownerId).sort((a, b) => Number(BigInt(b.id) - BigInt(a.id))).slice(0, limit).map((c) => ({ ...c }));
    },
    async countMemberCarsOfOwner(ownerId) {
      calls.push('countMemberCarsOfOwner');
      return memberCars().filter((c) => c.ownerId === ownerId).length;
    },
    async stats() {
      calls.push('stats');
      const mc = memberCars();
      const n = (st: string) => mc.filter((c) => c.status === st).length;
      return {
        totalUsers: live().length,
        totalShowrooms: showrooms.length,
        totalShowroomCars: cars.filter((c) => c.sourceType === 'showroom' && !c.deleted).length,
        totalMemberCars: mc.length,
        pendingMemberCars: n('pending'),
        activeMemberCars: n('active'),
        soldMemberCars: n('sold'),
        rejectedMemberCars: n('rejected'),
        suspendedMemberCars: n('suspended'),
        pendingDealers: live().filter((u) => u.role === 'dealer' && u.status === 'pending').length,
      };
    },
  };

  return {
    repo,
    calls,
    users,
    showrooms,
    cars,
    addUser(o: Partial<FakeAdminUser> = {}): FakeAdminUser {
      const n = ++seq;
      const u: FakeAdminUser = {
        id: String(n), name: `حساب ${n}`, phoneE164: `+9647700${String(n).padStart(6, '0')}`, email: null, role: 'user', status: 'active',
        createdAt: new Date(Date.UTC(2026, 0, n)), deleted: false, passwordHash: '$argon2id$v=19$SECRET-HASH', failedLogins: 3, lockedUntil: null, ...o,
      };
      users.push(u);
      return u;
    },
    addShowroom(ownerId: string, o: { name?: string; status?: string } = {}) {
      const s = { id: String(900 + showrooms.length), ownerId, name: o.name ?? 'معرض اختبار', status: o.status ?? 'active' };
      showrooms.push(s);
      return s;
    },
    addCar(o: Partial<FakeAdminCar> & { sourceType: 'member' | 'showroom' }): FakeAdminCar {
      const c: FakeAdminCar = { id: String(5000 + cars.length), ownerId: null, showroomId: null, brand: 'Kia', model: 'Rio', status: 'active', deleted: false, ...o };
      cars.push(c);
      return c;
    },
  };
}

// In-memory IntegrityRepository (Phase 11.7.2-K) on top of the audit fake (11.6.6). Mirrors, independently of src, what the SQL does:
// getAsset = one row (status, keys, referenced, age since ready by the "database" clock); deleteUnlinkedAudited = the audit fake's
// compare-and-swap PLUS the audit row, all or nothing (a failing audit write rolls the delete back); recordAudit = one audit row.
import { DbError } from '../../src/errors.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import type { IntegrityRepository } from '../../src/assets/integrity-repository.ts';
import { makeFakeAudit } from './fake-audit.ts';

export function makeFakeIntegrity(clock: { now(): Date }) {
  const fa = makeFakeAudit(clock);
  const audits: AuditEvent[] = [];
  const faults: { failGet: boolean; failAudit: boolean; failAuditFor: ((e: AuditEvent) => boolean) | null; afterGet: (() => void) | null } = { failGet: false, failAudit: false, failAuditFor: null, afterGet: null };
  const fail = () => {
    throw new DbError('unavailable', { sqlstate: '08006' });
  };
  const auditFails = (e: AuditEvent) => faults.failAudit || (faults.failAuditFor?.(e) ?? false);
  const repo: IntegrityRepository = {
    ...fa.repo,
    async getAsset(id) {
      fa.calls.push({ op: 'getAsset', arg: id });
      if (faults.failGet) fail();
      const r = fa.rows().find((x) => x.id === id);
      const out = r
        ? { id: r.id, kind: r.kind, status: r.status, storageKey: r.storageKey, thumbKey: r.thumbKey, referenced: r.referenced, readyAgeSeconds: r.readyAt ? (clock.now().getTime() - r.readyAt.getTime()) / 1000 : null }
        : null;
      faults.afterGet?.();
      return out;
    },
    async deleteUnlinkedAudited(i) {
      fa.calls.push({ op: 'deleteUnlinkedAudited', arg: i.id });
      if (auditFails(i.audit)) {
        // The audit write fails inside the transaction: the delete is rolled back (nothing changes).
        return fail() as never;
      }
      const removed = await fa.repo.deleteUnlinked({ id: i.id, storageKey: i.storageKey, thumbKey: i.thumbKey, graceSeconds: i.graceSeconds });
      if (removed) audits.push(i.audit);
      return removed;
    },
    async recordAudit(e) {
      fa.calls.push({ op: 'recordAudit', arg: e.action });
      if (auditFails(e)) fail();
      audits.push(e);
    },
  };
  return { ...fa, repo, audits, integrityFaults: faults };
}

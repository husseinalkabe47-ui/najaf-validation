// Phase 11.9-B on PostgreSQL 16 (CI only; skipped visibly otherwise): after migrations 0001-0014 the three plans exist (IQD, price 0,
// durations 3/6/12), the free plan is intact, the duration rules are enforced by the database, and the application role can read
// the plans. Fixtures use the admin handle and are removed afterwards. Nothing here exercises subscriptions or payments.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

describe('subscription plans on PostgreSQL 16 (migration 0014)', { skip }, () => {
  let app: Db;
  let admin: Db;
  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    await admin?.query(`DELETE FROM subscription_plans WHERE code LIKE 'it_plan_%'`);
    await app?.close();
    await admin?.close();
  });

  type Plan = { code: string; duration_months: number | null; price: string; currency: string; billing_interval: string | null; is_active: boolean; entitlements: Record<string, unknown> };
  const plans = async (db: Db): Promise<Plan[]> =>
    (await db.query<Plan>(`SELECT code, duration_months, price::text AS price, currency, billing_interval, is_active, entitlements FROM subscription_plans WHERE code IN ('plan_3m','plan_6m','plan_12m') ORDER BY duration_months`)).rows;

  it('the three plans exist with durations 3, 6 and 12, IQD and a price of 0', async () => {
    const rows = await plans(admin);
    assert.deepEqual(rows.map((r) => [r.code, r.duration_months, r.currency, r.price, r.billing_interval]), [
      ['plan_3m', 3, 'IQD', '0', null],
      ['plan_6m', 6, 'IQD', '0', null],
      ['plan_12m', 12, 'IQD', '0', null],
    ]);
    for (const r of rows) assert.deepEqual(r.entitlements, {});
  });

  it('the free plan is intact (no duration, price 0, IQD, empty entitlements)', async () => {
    const r = (await admin.query<Plan>(`SELECT code, duration_months, price::text AS price, currency, billing_interval, is_active, entitlements FROM subscription_plans WHERE code = 'free'`)).rows;
    assert.equal(r.length, 1);
    assert.deepEqual([r[0]!.duration_months, r[0]!.price, r[0]!.currency, r[0]!.billing_interval, r[0]!.entitlements], [null, '0', 'IQD', null, {}]);
  });

  it('the application role can read the new plans (and the column)', async () => {
    assert.deepEqual((await plans(app)).map((r) => r.duration_months), [3, 6, 12]);
  });

  it('a duration other than 3, 6 or 12 is refused', async () => {
    for (const months of [1, 4, 24, 0, -3]) {
      await assert.rejects(admin.query(`INSERT INTO subscription_plans (code, name, duration_months) VALUES ('it_plan_bad', 'x', $1::smallint)`, [months]), (e: unknown) => e instanceof DbError && e.kind === 'check', String(months));
    }
  });

  it('only one plan per duration', async () => {
    await assert.rejects(admin.query(`INSERT INTO subscription_plans (code, name, duration_months) VALUES ('it_plan_dup', 'x', 3)`), (e: unknown) => e instanceof DbError && e.kind === 'unique');
  });

  it('a plan with a price needs a billing interval or a duration; the old rule still holds for plans without a duration', async () => {
    await assert.rejects(admin.query(`INSERT INTO subscription_plans (code, name, price) VALUES ('it_plan_nop', 'x', 5)`), (e: unknown) => e instanceof DbError && e.kind === 'check');
    await admin.query(`INSERT INTO subscription_plans (code, name, price, billing_interval) VALUES ('it_plan_legacy', 'x', 5, 'month')`);
    // a duration plan can carry a price without a billing interval (the price editing itself is a later step; this checks the rule only)
    await admin.query(`UPDATE subscription_plans SET price = 250000 WHERE code = 'plan_3m'`);
    assert.equal((await plans(admin))[0]!.price, '250000');
    await admin.query(`UPDATE subscription_plans SET price = 0 WHERE code = 'plan_3m'`);
    assert.equal((await plans(admin))[0]!.price, '0');
  });

  it('the plan currency stays IQD or USD and a negative price is refused', async () => {
    await assert.rejects(admin.query(`UPDATE subscription_plans SET currency = 'EUR' WHERE code = 'plan_6m'`), (e: unknown) => e instanceof DbError && e.kind === 'check');
    await assert.rejects(admin.query(`UPDATE subscription_plans SET price = -1 WHERE code = 'plan_6m'`), (e: unknown) => e instanceof DbError && e.kind === 'check');
  });

  it('entitlements for a showroom without a subscription are still the free plan\'s (the new plans change nothing)', async () => {
    const r = await admin.query<{ e: Record<string, unknown> }>(`SELECT entitlements_for_showroom(-1) AS e`);
    assert.deepEqual(r.rows[0]!.e, {});
  });
});

// Phase 11.8-E on PostgreSQL 16 (CI only; skipped visibly otherwise): the creation cap and the one-publication guarantees hold under REAL
// concurrency across two connections (so across application instances), through the real server and the application role.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import { createAdmobCallbackHandler, createAdmobKeyStore, createAdmobRewardVerifier } from '../../src/rewards/admob.ts';
import { createPgRewardStore } from '../../src/rewards/repository.ts';
import { RewardError, createRewardService } from '../../src/rewards/service.ts';
import { TEST_AD_UNIT, TEST_KEY_ID, makeAdmobSigner } from '../helpers/admob-sign.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Abuse-Flow-Passw0rd!';
const SECRET = 'integration-abuse-secret-0123456789-ASDFGHJKL';
const json = { 'content-type': 'application/json' };
const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);

describe('abuse protection on PostgreSQL 16 (real concurrency, two connections)', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  let server: Awaited<ReturnType<BuildServer>>;
  const signer = makeAdmobSigner();
  const keys = createAdmobKeyStore({ fetchKeys: async () => [{ keyId: TEST_KEY_ID, pem: signer.pem }] });
  const verifier = createAdmobRewardVerifier({ config: { adUnitId: TEST_AD_UNIT }, keys });
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET });
    const memberCars = createMemberCarService({ store: createPgMemberCarStore(app) });
    const rewards = createRewardService({ store: createPgRewardStore(app), verifier });
    server = await buildServer!({ config: config(), db: app, auth, memberCars, rewards, rewardCallbacks: createAdmobCallbackHandler({ rewards, keys }) });
  });
  after(async () => {
    await server?.close();
    if (admin && created.length > 0) {
      await admin.query('DELETE FROM reward_grants WHERE user_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM cars WHERE owner_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  type Member = { id: string; auth: Record<string, string> };
  const register = async (): Promise<Member> => {
    const phone = newPhone();
    const r = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'عضو حماية', phone: local(phone), password: PW }) })).json() as { user: { id: string }; session: { accessToken: string } };
    return { id: r.user.id, auth: { authorization: `Bearer ${r.session.accessToken}` } };
  };
  const newAd = async (m: Member) => ((await server.inject({ method: 'POST', url: '/v1/me/cars', headers: { ...json, ...m.auth }, payload: JSON.stringify(VALID) })).json() as { car: { id: string } }).car.id;
  const rows = async (m: Member) => Number((await admin.query<{ n: string }>('SELECT count(*)::text AS n FROM reward_grants WHERE user_id = $1::bigint', [m.id])).rows[0]!.n);

  it('the hourly creation cap holds across two connections under concurrency: exactly maxPerHour rows, the rest are rate_limited; the window counts every status', async () => {
    const m = await register();
    const a = createRewardService({ store: createPgRewardStore(app), verifier, policy: { maxOpen: 100, maxPerHour: 5 } });
    const b = createRewardService({ store: createPgRewardStore(app2), verifier, policy: { maxOpen: 100, maxPerHour: 5 } });
    const actor = { id: m.id, role: 'member' as const };
    const results = await Promise.allSettled(Array.from({ length: 16 }, (_, i) => (i % 2 === 0 ? a : b).requestReward(actor)));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 5);
    assert.ok(results.filter((r) => r.status === 'rejected').every((r) => (r as PromiseRejectedResult).reason instanceof RewardError && (r as PromiseRejectedResult).reason.code === 'rate_limited'));
    assert.equal(await rows(m), 5);
    await admin.query(`UPDATE reward_grants SET status = 'failed', verified_at = NULL, ssv_transaction_id = NULL WHERE user_id = $1::bigint`, [m.id]);
    await assert.rejects(a.requestReward(actor), (e: unknown) => e instanceof RewardError && e.code === 'rate_limited', 'failed rows still count toward the hour');
    await admin.query(`UPDATE reward_grants SET created_at = now() - interval '2 hours', expires_at = now() - interval '90 minutes' WHERE user_id = $1::bigint`, [m.id]);
    await a.requestReward(actor); // the window slides on the database clock
    assert.equal(await rows(m), 6);
  });

  it('a burst of concurrent HTTP requests from one account creates at most maxOpen grants', async () => {
    const m = await register();
    const results = await Promise.all(Array.from({ length: 15 }, () => server.inject({ method: 'POST', url: '/v1/me/rewards', headers: m.auth })));
    assert.ok(results.every((r) => r.statusCode === 201 || r.statusCode === 429), results.map((r) => r.statusCode).join());
    assert.equal(results.filter((r) => r.statusCode === 201).length, 3);
    assert.equal(await rows(m), 3);
  });

  it('a storm of identical consume requests for one grant and one ad publishes once: all answer 200 (idempotent), one audit row, one version bump', async () => {
    const m = await register();
    const ad = await newAd(m);
    const reward = ((await server.inject({ method: 'POST', url: '/v1/me/rewards', headers: m.auth })).json() as { reward: { id: string } }).reward;
    assert.equal((await server.inject({ method: 'GET', url: `/v1/rewards/admob/ssv?${signer.query({ id: reward.id, userId: m.id })}` })).statusCode, 200);
    const before = Number((await admin.query<{ version: number }>('SELECT version FROM cars WHERE id = $1::bigint', [ad])).rows[0]!.version);
    const results = await Promise.all(Array.from({ length: 12 }, () => server.inject({ method: 'POST', url: `/v1/me/rewards/${reward.id}/consume`, headers: { ...json, ...m.auth }, payload: JSON.stringify({ carId: ad }) })));
    assert.ok(results.every((r) => r.statusCode === 200), results.map((r) => r.statusCode).join());
    const after = (await admin.query<{ status: string; version: number }>('SELECT status, version FROM cars WHERE id = $1::bigint', [ad])).rows[0]!;
    assert.deepEqual([after.status, Number(after.version)], ['active', before + 1]);
    assert.equal((await admin.query(`SELECT 1 FROM audit_logs WHERE action = 'member_car.reward_publish' AND entity_id = $1::text`, [ad])).rows.length, 1);
    assert.equal(await rows(m), 1);
  });

  it('a consumed reward cannot be reused for a second ad even under concurrency, and a hijacked callback of another account cannot publish anyone\'s ad', async () => {
    const m = await register();
    const thief = await register();
    const a = await newAd(m);
    const b = await newAd(m);
    const stolenAd = await newAd(thief);
    const reward = ((await server.inject({ method: 'POST', url: '/v1/me/rewards', headers: m.auth })).json() as { reward: { id: string } }).reward;
    await server.inject({ method: 'GET', url: `/v1/rewards/admob/ssv?${signer.query({ id: reward.id, userId: m.id })}` });
    const results = await Promise.all([a, b, a, b].map((carId) => server.inject({ method: 'POST', url: `/v1/me/rewards/${reward.id}/consume`, headers: { ...json, ...m.auth }, payload: JSON.stringify({ carId }) })));
    const active = (await admin.query<{ n: string }>('SELECT count(*)::text AS n FROM cars WHERE id = ANY($1::bigint[]) AND status = $2', [[a, b], 'active'])).rows[0]!.n;
    assert.equal(Number(active), 1);
    assert.ok(results.some((r) => r.statusCode === 409));
    assert.equal((await server.inject({ method: 'POST', url: `/v1/me/rewards/${reward.id}/consume`, headers: { ...json, ...thief.auth }, payload: JSON.stringify({ carId: stolenAd }) })).statusCode, 404);
    assert.equal((await admin.query<{ status: string }>('SELECT status FROM cars WHERE id = $1::bigint', [stolenAd])).rows[0]!.status, 'pending');
  });
});

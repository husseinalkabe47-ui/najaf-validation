// Phase 11.8-D: the reward-to-publish flow end to end on PostgreSQL 16 through the real server and the application role. CI only (skipped
// visibly without DATABASE_URL / ADMIN_DATABASE_URL, argon2 or fastify). Google's key list is a key generated here (no network); callbacks are
// signed like AdMob's (test/helpers/admob-sign.ts). Database failures are injected INSIDE the real transaction (a wrapper around the real
// repository throws after the real statements ran), so what is proved is a real PostgreSQL rollback, not a mock's.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import { createAdmobCallbackHandler, createAdmobKeyStore, createAdmobRewardVerifier } from '../../src/rewards/admob.ts';
import { createPgRewardStore } from '../../src/rewards/repository.ts';
import type { RewardStore } from '../../src/rewards/repository.ts';
import { createRewardService } from '../../src/rewards/service.ts';
import { TEST_AD_UNIT, TEST_KEY_ID, makeAdmobSigner } from '../helpers/admob-sign.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Publish-Flow-Passw0rd!';
const SECRET = 'integration-publish-flow-secret-0123456789-ASDFGH';
const json = { 'content-type': 'application/json' };
const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);

describe('reward-to-publish flow on PostgreSQL 16 through the real server', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  let server: Awaited<ReturnType<BuildServer>>;
  const signer = makeAdmobSigner();
  const faults = { publish: false, audit: false, markVerified: false, consume: false };
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });
  const down = () => new DbError('unavailable', { sqlstate: '08006' });

  /** The real store; each fault throws AFTER the real statement of that step ran, inside the real transaction. */
  const faulty = (real: RewardStore): RewardStore => ({
    grants: real.grants,
    transaction: (fn) =>
      real.transaction(({ grants, audit }) =>
        fn({
          grants: {
            ...grants,
            markVerified: async (i) => {
              const row = await grants.markVerified(i);
              if (faults.markVerified) throw down();
              return row;
            },
            consume: async (i) => {
              const row = await grants.consume(i);
              if (faults.consume) throw down();
              return row;
            },
            publishOwnCar: async (i) => {
              const v = await grants.publishOwnCar(i);
              if (faults.publish) throw down();
              return v;
            },
          },
          audit: {
            ...audit,
            record: async (e) => {
              await audit.record(e);
              if (faults.audit) throw down();
            },
          },
        }),
      ),
  });

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET });
    const memberCars = createMemberCarService({ store: createPgMemberCarStore(app) });
    const keys = createAdmobKeyStore({ fetchKeys: async () => [{ keyId: TEST_KEY_ID, pem: signer.pem }] });
    const rewards = createRewardService({ store: faulty(createPgRewardStore(app)), verifier: createAdmobRewardVerifier({ config: { adUnitId: TEST_AD_UNIT }, keys }) });
    const rewardCallbacks = createAdmobCallbackHandler({ rewards, keys });
    server = await buildServer!({ config: config(), db: app, auth, memberCars, rewards, rewardCallbacks });
  });
  after(async () => {
    await server?.close();
    if (admin && created.length > 0) {
      await admin.query('DELETE FROM reward_grants WHERE user_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM cars WHERE owner_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    }
    await app?.close();
    await admin?.close();
  });

  type Member = { id: string; auth: Record<string, string> };
  const register = async (): Promise<Member> => {
    const phone = newPhone();
    const r = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'عضو نشر', phone: local(phone), password: PW }) })).json() as { user: { id: string }; session: { accessToken: string } };
    return { id: r.user.id, auth: { authorization: `Bearer ${r.session.accessToken}` } };
  };
  const newAd = async (m: Member, extra: Record<string, unknown> = {}) => {
    const res = await server.inject({ method: 'POST', url: '/v1/me/cars', headers: { ...json, ...m.auth }, payload: JSON.stringify({ ...VALID, ...extra }) });
    return { status: res.statusCode, id: (res.json() as { car?: { id: string } }).car?.id ?? '' };
  };
  const ask = async (m: Member) => ({ id: ((await server.inject({ method: 'POST', url: '/v1/me/rewards', headers: m.auth })).json() as { reward: { id: string } }).reward.id, userId: m.id });
  const callback = (q: string) => server.inject({ method: 'GET', url: `/v1/rewards/admob/ssv?${q}` });
  const consume = (m: Member, id: string, carId: string) => server.inject({ method: 'POST', url: `/v1/me/rewards/${id}/consume`, headers: { ...json, ...m.auth }, payload: JSON.stringify({ carId }) });
  const grant = async (id: string) => (await admin.query<{ status: string; car_id: string | null; ssv_transaction_id: string | null; consumed_at: Date | null }>('SELECT status, car_id::text, ssv_transaction_id, consumed_at FROM reward_grants WHERE id = $1::uuid', [id])).rows[0]!;
  const car = async (id: string) => (await admin.query<{ status: string; version: number }>('SELECT status, version FROM cars WHERE id = $1::bigint', [id])).rows[0]!;
  const isPublic = async (id: string) => (await admin.query('SELECT 1 FROM public_cars WHERE id = $1::bigint', [id])).rows.length === 1;
  const audits = async (carId: string) => (await admin.query<{ actor_id: string; actor_role: string; after_data: { version: number } }>(`SELECT actor_id::text, actor_role, after_data FROM audit_logs WHERE action = 'member_car.reward_publish' AND entity_id = $1::text`, [carId])).rows;
  const grantCount = async (m: Member) => Number((await admin.query<{ n: string }>('SELECT count(*)::text AS n FROM reward_grants WHERE user_id = $1::bigint', [m.id])).rows[0]!.n);
  const state = async (carId: string) => [(await car(carId)).status, await isPublic(carId)];

  it('the Android lifecycle: request, signed callback, verified grant, authenticated consume, direct publication, with the audit trail and one version bump', async () => {
    const m = await register();
    const ad = await newAd(m);
    assert.equal(ad.status, 201);
    const before = await car(ad.id);
    assert.deepEqual(await state(ad.id), ['pending', false]);
    const g = await ask(m);
    assert.deepEqual(await grant(g.id), { status: 'requested', car_id: null, ssv_transaction_id: null, consumed_at: null });

    assert.equal((await callback(signer.query(g, { transaction_id: `LIFE${g.id.slice(-8)}` }))).statusCode, 200);
    assert.equal((await grant(g.id)).status, 'verified');
    assert.deepEqual(await state(ad.id), ['pending', false]);

    const done = await consume(m, g.id, ad.id);
    assert.equal(done.statusCode, 200);
    assert.deepEqual(done.json(), { reward: { id: g.id, carId: ad.id, status: 'consumed', published: true } });
    const row = await grant(g.id);
    assert.deepEqual([row.status, row.car_id, row.ssv_transaction_id], ['consumed', ad.id, `LIFE${g.id.slice(-8)}`]);
    assert.ok(row.consumed_at instanceof Date);
    assert.deepEqual(await state(ad.id), ['active', true]);
    assert.equal((await car(ad.id)).version, before.version + 1);
    const trail = await audits(ad.id);
    assert.deepEqual(trail.map((a) => [a.actor_id, a.actor_role, a.after_data.version]), [[m.id, 'user', before.version + 1]]);
  });

  it('callbacks that must not verify: stale, future, expired grant, wrong key, wrong ad unit, wrong user, wrong grant, missing data', async () => {
    const m = await register();
    const g = await ask(m);
    const stranger = await register();
    const theirs = await ask(stranger);
    const attempts = [
      signer.query(g, { timestamp: String(Date.now() - 2 * 3600 * 1000) }),
      signer.query(g, { timestamp: String(Date.now() + 3600 * 1000) }),
      signer.query(g, {}, { signWith: signer.otherKey() }),
      signer.query(g, { ad_unit: '7777777' }),
      signer.query(g, { user_id: stranger.id }),
      signer.query(g, { custom_data: theirs.id }), // my user id on their grant
      signer.query(theirs, { custom_data: g.id }), // their user id on my grant
      signer.query(g, { user_id: undefined }),
      signer.query(g, { custom_data: undefined }),
      signer.query(g, { transaction_id: undefined }),
    ];
    for (const q of attempts) assert.equal((await callback(q)).statusCode, 400);
    await admin.query(`UPDATE reward_grants SET created_at = now() - interval '2 hours', expires_at = now() - interval '1 hour' WHERE id = $1::uuid`, [g.id]);
    assert.equal((await callback(signer.query(g))).statusCode, 400, 'a fresh callback for a grant whose own lifetime is over (database clock)');
    assert.deepEqual([(await grant(g.id)).status, (await grant(theirs.id)).status], ['requested', 'requested']);
  });

  it('a transaction id that was spent cannot verify any other grant (same or another account); the second grant cannot publish', async () => {
    const a = await register();
    const b = await register();
    const adA = await newAd(a);
    const adB = await newAd(b);
    const ga = await ask(a);
    const gb = await ask(b);
    const gb2 = await ask(a);
    const tx = `SPENT${ga.id.slice(-8)}`;
    assert.equal((await callback(signer.query(ga, { transaction_id: tx }))).statusCode, 200);
    assert.equal((await callback(signer.query(gb, { transaction_id: tx }))).statusCode, 400);
    assert.equal((await callback(signer.query(gb2, { transaction_id: tx }))).statusCode, 400);
    assert.deepEqual([(await grant(ga.id)).status, (await grant(gb.id)).status, (await grant(gb2.id)).status], ['verified', 'requested', 'requested']);
    assert.equal((await consume(b, gb.id, adB.id)).statusCode, 409);
    assert.deepEqual([await state(adB.id), await state(adA.id)], [['pending', false], ['pending', false]]);
  });

  it('idempotence: five concurrent copies of Google\'s callback, then repeats after consumption, create no grant, no second publication and no second audit row', async () => {
    const m = await register();
    const ad = await newAd(m);
    const g = await ask(m);
    const q = signer.query(g, { transaction_id: `ONCE${g.id.slice(-8)}` });
    const results = await Promise.all(Array.from({ length: 5 }, () => callback(q)));
    assert.deepEqual(results.map((r) => r.statusCode), [200, 200, 200, 200, 200]);
    assert.equal(await grantCount(m), 1);
    assert.deepEqual([(await grant(g.id)).status, (await grant(g.id)).ssv_transaction_id], ['verified', `ONCE${g.id.slice(-8)}`]);
    assert.equal((await consume(m, g.id, ad.id)).statusCode, 200);
    const published = await car(ad.id);
    const stamp = (await grant(g.id)).consumed_at!.getTime();
    assert.equal((await callback(q)).statusCode, 200, 'Google retrying after the member consumed');
    const repeat = await consume(m, g.id, ad.id);
    assert.equal(repeat.statusCode, 200);
    assert.deepEqual(repeat.json(), { reward: { id: g.id, carId: ad.id, status: 'consumed', published: true } });
    assert.deepEqual([await car(ad.id), (await grant(g.id)).consumed_at!.getTime(), (await audits(ad.id)).length, await grantCount(m)], [published, stamp, 1, 1]);
  });

  it('concurrent consumptions of one verified grant for two ads publish exactly one (real locks)', async () => {
    const m = await register();
    const a = await newAd(m);
    const b = await newAd(m);
    const g = await ask(m);
    await callback(signer.query(g));
    const results = await Promise.all([consume(m, g.id, a.id), consume(m, g.id, b.id)]);
    assert.deepEqual(results.map((r) => r.statusCode).sort(), [200, 409]);
    assert.equal([(await car(a.id)).status, (await car(b.id)).status].filter((s) => s === 'active').length, 1);
    assert.equal((await audits(a.id)).length + (await audits(b.id)).length, 1);
  });

  it('failure safety, verification: a database error after the real UPDATE rolls the verification back (5xx), nothing publishes, and Google\'s retry then verifies', async () => {
    const m = await register();
    const ad = await newAd(m);
    const g = await ask(m);
    const q = signer.query(g, { transaction_id: `RETRY${g.id.slice(-8)}` });
    faults.markVerified = true;
    try {
      assert.ok((await callback(q)).statusCode >= 500);
    } finally {
      faults.markVerified = false;
    }
    assert.deepEqual(await grant(g.id), { status: 'requested', car_id: null, ssv_transaction_id: null, consumed_at: null });
    assert.equal((await consume(m, g.id, ad.id)).statusCode, 409);
    assert.deepEqual(await state(ad.id), ['pending', false]);
    assert.equal((await callback(q)).statusCode, 200);
    assert.equal((await grant(g.id)).status, 'verified');
  });

  it('failure safety, consumption: a failure after the consume UPDATE, after the publish UPDATE or after the audit INSERT rolls ALL of it back; a healthy retry publishes once', async () => {
    for (const fault of ['consume', 'publish', 'audit'] as const) {
      const m = await register();
      const ad = await newAd(m);
      const g = await ask(m);
      await callback(signer.query(g));
      const before = await car(ad.id);
      faults[fault] = true;
      try {
        assert.ok((await consume(m, g.id, ad.id)).statusCode >= 500, fault);
      } finally {
        faults[fault] = false;
      }
      assert.deepEqual([(await grant(g.id)).status, (await grant(g.id)).car_id, await car(ad.id), await isPublic(ad.id), (await audits(ad.id)).length], ['verified', null, before, false, 0], fault);
      assert.equal((await consume(m, g.id, ad.id)).statusCode, 200, fault);
      assert.deepEqual([await state(ad.id), (await audits(ad.id)).length], [['active', true], 1], fault);
    }
  });

  it('failed or missing verification never publishes: an invalid callback, no callback, another account\'s grant, an unknown grant', async () => {
    const m = await register();
    const other = await register();
    const ad = await newAd(m);
    const g = await ask(m);
    assert.equal((await callback(signer.query(g, {}, { signWith: signer.otherKey() }))).statusCode, 400);
    assert.equal((await consume(m, g.id, ad.id)).statusCode, 409);
    await callback(signer.query(g));
    assert.equal((await consume(other, g.id, ad.id)).statusCode, 404);
    assert.equal((await consume(m, '00000000-0000-4000-8000-0000000000ff', ad.id)).statusCode, 404);
    assert.deepEqual(await state(ad.id), ['pending', false]);
    assert.equal((await audits(ad.id)).length, 0);
  });

  it('website boundary: a submitted ad is pending and not public; no callback can name or publish an ad; the callback of another ad unit is no proof; extra submit fields cannot publish', async () => {
    const m = await register();
    const web = await newAd(m);
    assert.deepEqual([web.status, ...(await state(web.id))], [201, 'pending', false]);
    const smuggled = await newAd(m, { status: 'active', rewardGrantId: '00000000-0000-4000-8000-000000000001', published: true });
    if (smuggled.status === 201) assert.deepEqual(await state(smuggled.id), ['pending', false]);
    else assert.equal(smuggled.status, 400);

    const g = await ask(m);
    assert.equal((await callback(signer.query(g, { ad_unit: '7777777' }))).statusCode, 400, 'a website ad unit is not the Android one');
    assert.equal((await callback(signer.query(g, { car_id: web.id, status: 'active', published: 'true' }))).statusCode, 200);
    assert.equal((await grant(g.id)).status, 'verified');
    assert.equal((await grant(g.id)).car_id, null, 'a callback binds the grant to no ad');
    assert.deepEqual(await state(web.id), ['pending', false], 'verifying a grant publishes nothing');
    const noGrant = await newAd(m);
    assert.deepEqual(await state(noGrant.id), ['pending', false]);
    assert.equal((await audits(web.id)).length, 0);
  });
});

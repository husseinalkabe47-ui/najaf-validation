// Phase 11.9-E against a real PostgreSQL 16 (migrations 0001-0014), through the least-privilege application role: the operator-run
// subscription expiry. Needs DATABASE_URL and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY); skipped visibly without them.
// Fixtures are subscriptions inserted by the admin handle with END DATES AROUND A FIXED INSTANT, and the job runs `at` that instant, so
// the boundary is exact; other suites' rows are never counted (every assertion is about this suite's own rows). Audit rows are
// append-only and stay, keyed by the fixtures' own ids.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgSubscriptionExpiryRepository } from '../../src/subscriptions/expiry-repository.ts';
import { runSubscriptionExpiry } from '../../src/subscriptions/expiry.ts';
import { createPgSubscriptionsRepository } from '../../src/subscriptions/repository.ts';
import { createSubscriptionsService } from '../../src/subscriptions/service.ts';
import type { Actor } from '../../src/authz/index.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const AT = new Date('2031-06-15T12:00:00Z'); // far from "now": the real rows of other suites are never due at this instant by accident of the test
const iso = (ms: number) => new Date(AT.getTime() + ms).toISOString();

describe('subscription expiry on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let admin: Db;
  let repo: ReturnType<typeof createPgSubscriptionExpiryRepository>;
  const userIds: string[] = [];
  const showroomIds: string[] = [];

  const newShowroom = async (): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const u = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, 'dealer', 'active', $2) RETURNING id`, [phone, HASH]);
    userIds.push(String(u.rows[0]!.id));
    const s = await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض انتهاء', 'active') RETURNING id`, [u.rows[0]!.id]);
    showroomIds.push(String(s.rows[0]!.id));
    return String(s.rows[0]!.id);
  };
  /** A subscription of a fresh showroom: status, start 90 days before its end, end `endMs` from AT. Returns {id, showroomId}. */
  const newSub = async (status: string, endMs: number, plan = 'plan_3m'): Promise<{ id: string; showroomId: string }> => {
    const showroomId = await newShowroom();
    const end = iso(endMs);
    const r = await admin.query<{ id: string }>(
      `INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end)
       VALUES ($1::bigint, (SELECT id FROM subscription_plans WHERE code = $2), $3, $4::timestamptz - interval '90 days', $4::timestamptz) RETURNING id`, [showroomId, plan, status, end]);
    return { id: String(r.rows[0]!.id), showroomId };
  };
  const status = async (id: string) => (await admin.query<{ status: string; v: number }>(`SELECT status, version AS v FROM subscriptions WHERE id = $1::bigint`, [id])).rows[0]!;
  const expireAudits = async (id: string) =>
    (await admin.query<{ actor_id: string | null; actor_role: string; after_data: Record<string, number> }>(`SELECT actor_id, actor_role, after_data FROM audit_logs WHERE action = 'subscription.expire' AND entity_id = $1 ORDER BY id`, [id])).rows;
  /** Runs the job at AT in bounded batches until it reports nothing left (other suites' due rows may exist, so loop until complete). */
  const runAll = async () => { let total = 0; for (let i = 0; i < 50; i++) { const r = await runSubscriptionExpiry({ repo, at: AT }, { dryRun: false, batchSize: 100 }); total += r.expired; if (r.complete) return total; } return total; };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    repo = createPgSubscriptionExpiryRepository(app);
  });
  after(async () => {
    if (admin) {
      if (showroomIds.length > 0) {
        await admin.query(`DELETE FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = ANY($1::bigint[]))`, [showroomIds]);
        await admin.query(`DELETE FROM subscriptions WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM showrooms WHERE id = ANY($1::bigint[])`, [showroomIds]);
      }
      if (userIds.length > 0) await admin.query(`DELETE FROM users WHERE id = ANY($1::bigint[])`, [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  it('the boundary: a subscription ending exactly at the instant expires; one millisecond later it stays in force (same rule as entitlements_for_showroom)', async () => {
    const exact = await newSub('active', 0);
    const later = await newSub('active', 1);
    const before = await newSub('active', -1);
    assert.match((await admin.query<{ d: string }>(`SELECT pg_get_functiondef('entitlements_for_showroom(bigint)'::regprocedure) AS d`)).rows[0]!.d, /current_period_end > now\(\)/);
    await runAll();
    assert.deepEqual([(await status(exact.id)).status, (await status(later.id)).status, (await status(before.id)).status], ['expired', 'active', 'expired']);
  });

  it('expires every live status, never touches expired/canceled rows, and records ONE audit row each (actor = the system, numbers only)', async () => {
    const subs = { trialing: await newSub('trialing', -1000), active: await newSub('active', -1000), pastDue: await newSub('past_due', -1000), expired: await newSub('expired', -1000), canceled: await newSub('canceled', -1000) };
    const dry = await runSubscriptionExpiry({ repo, at: AT });
    assert.equal(dry.dryRun, true); assert.ok(dry.eligible >= 3);
    assert.equal((await status(subs.active.id)).status, 'active'); // a dry run changes nothing
    assert.deepEqual(await expireAudits(subs.active.id), []);
    await runAll();
    assert.deepEqual([(await status(subs.trialing.id)).status, (await status(subs.active.id)).status, (await status(subs.pastDue.id)).status, (await status(subs.expired.id)).status, (await status(subs.canceled.id)).status], ['expired', 'expired', 'expired', 'expired', 'canceled']);
    for (const s of [subs.trialing, subs.active, subs.pastDue]) {
      const a = await expireAudits(s.id);
      assert.equal(a.length, 1);
      assert.deepEqual([a[0]!.actor_id, a[0]!.actor_role], [null, 'system']);
      assert.deepEqual(Object.keys(a[0]!.after_data).sort(), ['periodEnd', 'planId', 'showroomId']);
      assert.equal(a[0]!.after_data['showroomId'], Number(s.showroomId));
    }
    for (const s of [subs.expired, subs.canceled]) assert.deepEqual(await expireAudits(s.id), []);
  });

  it('is idempotent: repeated runs add no transition (version unchanged), no audit row, no payment and no subscription', async () => {
    const s = await newSub('active', -5000);
    await runAll();
    const v = await status(s.id);
    const audits = (await expireAudits(s.id)).length;
    const counts = async () => [Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM subscriptions WHERE showroom_id = $1::bigint`, [s.showroomId])).rows[0]!.n), Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM payments WHERE subscription_id = $1::bigint`, [s.id])).rows[0]!.n)];
    const before = await counts();
    for (let i = 0; i < 3; i++) assert.equal((await runSubscriptionExpiry({ repo, at: AT }, { dryRun: false })).error, null);
    assert.deepEqual(await status(s.id), v);
    assert.equal((await expireAudits(s.id)).length, audits); assert.equal(audits, 1);
    assert.deepEqual(await counts(), before);
  });

  it('concurrent runs never expire the same subscription twice: exactly one audit row and one status change per row', async () => {
    const subs = await Promise.all(Array.from({ length: 12 }, (_, i) => newSub(i % 2 ? 'active' : 'past_due', -2000 - i)));
    const before = await Promise.all(subs.map((s) => status(s.id)));
    const results = await Promise.all([runAll(), runAll(), runAll()]);
    assert.ok(results.reduce((a, b) => a + b, 0) >= 12);
    for (let i = 0; i < subs.length; i++) {
      assert.equal((await status(subs[i]!.id)).status, 'expired');
      assert.equal((await status(subs[i]!.id)).v, before[i]!.v + 1); // changed exactly once
      assert.equal((await expireAudits(subs[i]!.id)).length, 1);
    }
  });

  it('runs safely beside a manual renewal: a renewed (future-dated) subscription is not expired, and nothing ends half-done', async () => {
    const A: Actor = { id: String((await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('مدير اختبار', $1, 'admin', 'active', $2) RETURNING id`, ['+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0'), HASH])).rows[0]!.id), role: 'admin' };
    userIds.push(A.id);
    const clock = new Date(AT.getTime() - 60_000); // the manual service runs one minute BEFORE the job's instant
    const svc = createSubscriptionsService({ repo: createPgSubscriptionsRepository(app), now: () => clock });
    const s = await newSub('active', -30_000); // ends 30 s before the job's instant, but is still live for the manual clock (one minute earlier)
    const ref = `EXP${randomInt(100000, 999999)}`;
    const [grant] = await Promise.all([svc.grant(A, { showroomId: s.showroomId, planCode: 'plan_3m', method: 'cash', reference: ref, amount: 1000, paidAt: '2026-10-14' }), runAll()]);
    const rows = (await admin.query<{ id: string; status: string; current_period_end: Date }>(`SELECT id, status, current_period_end FROM subscriptions WHERE showroom_id = $1::bigint ORDER BY id`, [s.showroomId])).rows;
    const live = rows.filter((r) => ['trialing', 'active', 'past_due'].includes(r.status));
    assert.ok(live.length <= 1);
    const pays = Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = $1::bigint)`, [s.showroomId])).rows[0]!.n);
    assert.equal(pays, 1); // the payment is recorded exactly once whichever side won
    if (grant.outcome === 'renewed') assert.ok(live.length === 1 && live[0]!.current_period_end.getTime() > clock.getTime()); // the renewal moved the end forward
    for (const r of rows.filter((x) => x.status === 'expired')) assert.ok((await expireAudits(r.id)).length <= 1);
  });

  it('only the status moves: no subscription or payment is inserted or deleted by the job, plans are untouched, and the app role cannot delete', async () => {
    const plans = (await admin.query(`SELECT code, price, currency, is_active FROM subscription_plans ORDER BY id`)).rows;
    const s = await newSub('active', -3000);
    const before = (await admin.query<{ n: string }>(`SELECT count(*) AS n FROM payments`)).rows[0]!.n;
    const subsBefore = Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM subscriptions`)).rows[0]!.n);
    await runAll();
    assert.equal((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM payments`)).rows[0]!.n, before);
    assert.equal(Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM subscriptions`)).rows[0]!.n), subsBefore);
    assert.deepEqual((await admin.query(`SELECT code, price, currency, is_active FROM subscription_plans ORDER BY id`)).rows, plans);
    assert.equal((await status(s.id)).status, 'expired');
    await assert.rejects(app.query(`DELETE FROM subscriptions WHERE id = $1::bigint`, [s.id]));
  });
});

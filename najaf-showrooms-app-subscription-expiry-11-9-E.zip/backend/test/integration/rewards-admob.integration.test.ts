// Phase 11.8-C end to end: the real server, real argon2id sessions, real PostgreSQL 16 through the application role. CI only (skipped visibly
// without DATABASE_URL / ADMIN_DATABASE_URL, argon2 or fastify). Google's key list is replaced by a key generated here (no network); callbacks are
// signed the way AdMob signs them. Proves: a signed callback verifies the member's grant in the database (provider 'admob', receipt stored,
// reward_ssv_uq enforced), the callback alone publishes nothing, and the member's own consume request then publishes the ad directly.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, randomInt, sign } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import { createAdmobCallbackHandler, createAdmobKeyStore, createAdmobRewardVerifier } from '../../src/rewards/admob.ts';
import { createPgRewardStore } from '../../src/rewards/repository.ts';
import { createRewardService } from '../../src/rewards/service.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Admob-Http-Passw0rd!';
const SECRET = 'integration-admob-access-secret-0123456789-ASDFGH';
const AD_UNIT = '1234567890';
const KEY_ID = '3335741209';
const json = { 'content-type': 'application/json' };
const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);
const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

describe('AdMob callback on PostgreSQL 16 through the real server', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const keyPair = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  type Server = Awaited<ReturnType<BuildServer>>;
  let server: Server;
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });

  const callback = (grant: { id: string; userId: string }, over: Record<string, string> = {}, key = keyPair) => {
    const base: Record<string, string> = { ad_network: '5450213213286189855', ad_unit: AD_UNIT, custom_data: grant.id, reward_amount: '1', reward_item: 'publish', timestamp: String(Date.now() - 2000), transaction_id: `IT${randomInt(0, 1e9)}${Date.now()}`, user_id: grant.userId, ...over };
    const content = Object.keys(base).sort().map((n) => `${n}=${encodeURIComponent(base[n]!)}`).join('&');
    const sig = sign('sha256', Buffer.from(content), { key: key.privateKey, dsaEncoding: 'der' });
    return `/v1/rewards/admob/ssv?${content}&signature=${b64url(sig)}&key_id=${KEY_ID}`;
  };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET });
    const memberCars = createMemberCarService({ store: createPgMemberCarStore(app) });
    const keys = createAdmobKeyStore({
      fetchKeys: async () => {
        return [{ keyId: KEY_ID, pem: keyPair.publicKey.export({ type: 'spki', format: 'pem' }).toString() }];
      },
    });
    const rewards = createRewardService({ store: createPgRewardStore(app), verifier: createAdmobRewardVerifier({ config: { adUnitId: AD_UNIT }, keys }) });
    const rewardCallbacks = createAdmobCallbackHandler({ rewards, keys });
    server = await buildServer!({ config: config(), db: app, auth, memberCars, rewards, rewardCallbacks });
  });
  after(async () => {
    await server?.close();
    if (admin && created.length > 0) {
      await admin.query('DELETE FROM reward_grants WHERE user_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM cars WHERE owner_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    }
    await app?.close();
    await admin?.close();
  });

  const register = async () => {
    const phone = newPhone();
    const r = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'عضو أدموب', phone: local(phone), password: PW }) })).json() as { user: { id: string }; session: { accessToken: string } };
    return { id: r.user.id, auth: { authorization: `Bearer ${r.session.accessToken}` } };
  };
  const ad = async (m: { auth: Record<string, string> }) => ((await server.inject({ method: 'POST', url: '/v1/me/cars', headers: { ...json, ...m.auth }, payload: JSON.stringify(VALID) })).json() as { car: { id: string } }).car.id;
  const ask = async (m: { id: string; auth: Record<string, string> }) => ({ id: ((await server.inject({ method: 'POST', url: '/v1/me/rewards', headers: m.auth })).json() as { reward: { id: string } }).reward.id, userId: m.id });
  const consume = (m: { auth: Record<string, string> }, id: string, carId: string) => server.inject({ method: 'POST', url: `/v1/me/rewards/${id}/consume`, headers: { ...json, ...m.auth }, payload: JSON.stringify({ carId }) });
  const grant = async (id: string) => (await admin.query<{ status: string; provider: string; ssv_transaction_id: string | null }>('SELECT status, provider, ssv_transaction_id FROM reward_grants WHERE id = $1::uuid', [id])).rows[0]!;
  const carStatus = async (id: string) => String((await admin.query<{ status: string }>('SELECT status FROM cars WHERE id = $1::bigint', [id])).rows[0]!.status);
  const isPublic = async (id: string) => (await admin.query('SELECT 1 FROM public_cars WHERE id = $1::bigint', [id])).rows.length === 1;

  it('Android flow: request, Google\'s signed callback verifies it, the callback publishes nothing, the member\'s consume publishes directly; replays are refused', async () => {
    const m = await register();
    const carId = await ad(m);
    const g = await ask(m);
    assert.equal((await consume(m, g.id, carId)).statusCode, 409, 'consume before the callback: nothing is verified');
    assert.deepEqual([await carStatus(carId), await isPublic(carId)], ['pending', false]);

    const url = callback(g);
    const res = await server.inject({ method: 'GET', url });
    assert.equal(res.statusCode, 200);
    const row = await grant(g.id);
    assert.deepEqual([row.status, row.provider], ['verified', 'admob']);
    assert.ok(row.ssv_transaction_id);
    assert.deepEqual([await carStatus(carId), await isPublic(carId)], ['pending', false], 'the callback alone never publishes');
    assert.equal((await server.inject({ method: 'GET', url })).statusCode, 200, 'Google retrying the same callback');

    const done = await consume(m, g.id, carId);
    assert.equal(done.statusCode, 200);
    assert.deepEqual([await carStatus(carId), await isPublic(carId)], ['active', true]);
    assert.equal((await consume(m, g.id, await ad(m))).statusCode, 409, 'a spent grant cannot publish a second ad');
  });

  it('untrustworthy callbacks are 400 and verify nothing: another key, another user, another ad unit, a tampered parameter, a spent receipt', async () => {
    const m = await register();
    const g = await ask(m);
    const other = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
    for (const url of [callback(g, {}, other), callback(g, { user_id: '1' }), callback(g, { ad_unit: '999999' }), callback(g).replace('reward_amount=1', 'reward_amount=5'), callback(g, { custom_data: '00000000-0000-4000-8000-0000000000aa' })]) {
      assert.equal((await server.inject({ method: 'GET', url })).statusCode, 400);
    }
    assert.equal((await grant(g.id)).status, 'requested');

    const g2 = await ask(m);
    const g3 = await ask(m);
    assert.equal((await server.inject({ method: 'GET', url: callback(g2, { transaction_id: `SPENT${g2.id.slice(-8)}` }) })).statusCode, 200);
    assert.equal((await server.inject({ method: 'GET', url: callback(g3, { transaction_id: `SPENT${g2.id.slice(-8)}` }) })).statusCode, 400, 'reward_ssv_uq: one receipt verifies one request');
    assert.deepEqual([(await grant(g2.id)).status, (await grant(g3.id)).status], ['verified', 'requested']);
  });

  it('Google\'s keys unreachable: 503 (Google retries) and nothing is verified', async () => {
    const m = await register();
    const g = await ask(m);
    const fresh = createAdmobKeyStore({ fetchKeys: async () => { throw new Error('down'); } });
    const handler = createAdmobCallbackHandler({ rewards: { verifyReward: async () => { throw new Error('must not be reached'); } }, keys: fresh });
    assert.deepEqual(await handler.handle(callback(g).split('?')[1]), { status: 503, code: 'unavailable' });
    assert.equal((await grant(g.id)).status, 'requested');
  });
});

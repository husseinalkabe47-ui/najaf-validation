// Phase 11.8-B end to end: the real Fastify server, real argon2id sessions, real PostgreSQL 16 through the application role.
// CI only (DATABASE_URL + ADMIN_DATABASE_URL; skipped visibly otherwise, or when argon2 / fastify are not installed).
// The verifier is the FAKE one from test/helpers (never part of src); verification is done by SERVER-SIDE test code through the
// service, because no HTTP route can verify. Also proves the production default: with the unconfigured verifier no route can publish.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import { createUnconfiguredRewardVerifier } from '../../src/rewards/provider.ts';
import { createPgRewardStore } from '../../src/rewards/repository.ts';
import { createRewardService } from '../../src/rewards/service.ts';
import { makeFakeVerifier } from '../helpers/fake-rewards.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Rewards-Http-Passw0rd!';
const SECRET = 'integration-rewards-access-secret-0123456789-ASDFGH';
const json = { 'content-type': 'application/json' };
const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);

describe('reward routes on PostgreSQL 16 through the real server', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const verifier = makeFakeVerifier();
  type Server = Awaited<ReturnType<BuildServer>>;
  const servers: Server[] = [];
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    for (const s of servers) await s.close();
    if (admin && created.length > 0) {
      await admin.query('DELETE FROM reward_grants WHERE user_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM cars WHERE owner_id IN (SELECT id FROM users WHERE phone_e164::text = ANY($1::text[]))', [created]);
      await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    }
    await app?.close();
    await admin?.close();
  });

  const stack = async (configured: boolean) => {
    const auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET });
    const memberCars = createMemberCarService({ store: createPgMemberCarStore(app) });
    const rewards = createRewardService({ store: createPgRewardStore(app), verifier: configured ? verifier : createUnconfiguredRewardVerifier() });
    const server = await buildServer!({ config: config(), db: app, auth, memberCars, rewards });
    servers.push(server);
    return { server, rewards };
  };
  const register = async (server: Server) => {
    const phone = newPhone();
    const r = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'عضو مكافأة', phone: local(phone), password: PW }) })).json() as { user: { id: string }; session: { accessToken: string } };
    return { id: r.user.id, auth: { authorization: `Bearer ${r.session.accessToken}` } };
  };
  const newAd = async (server: Server, who: { auth: Record<string, string> }) =>
    ((await server.inject({ method: 'POST', url: '/v1/me/cars', headers: { ...json, ...who.auth }, payload: JSON.stringify(VALID) })).json() as { car: { id: string } }).car.id;
  const request = (server: Server, who: { auth: Record<string, string> }) => server.inject({ method: 'POST', url: '/v1/me/rewards', headers: who.auth });
  const consume = (server: Server, who: { auth: Record<string, string> }, id: string, body: unknown) =>
    server.inject({ method: 'POST', url: `/v1/me/rewards/${id}/consume`, headers: { ...json, ...who.auth }, payload: JSON.stringify(body) });
  const carStatus = async (id: string) => String((await admin.query<{ status: string }>('SELECT status FROM cars WHERE id = $1::bigint', [id])).rows[0]!.status);
  const isPublic = async (id: string) => (await admin.query('SELECT 1 FROM public_cars WHERE id = $1::bigint', [id])).rows.length === 1;
  const grantRow = async (id: string) => (await admin.query<{ status: string; car_id: string | null; user_id: string }>('SELECT status, car_id::text, user_id::text FROM reward_grants WHERE id = $1::uuid', [id])).rows[0]!;
  const verifyOnServer = (rewards: ReturnType<typeof createRewardService>, grantId: string, userId: string) => rewards.verifyReward(grantId, { grantId, userId, tx: `http-${grantId}` });

  it('full life: request over HTTP, server-side verification, consume over HTTP: the member\'s ad is public at once; a replay and another account are refused', async () => {
    const { server, rewards } = await stack(true);
    const m = await register(server);
    const other = await register(server);
    const ad = await newAd(server, m);
    assert.deepEqual([await carStatus(ad), await isPublic(ad)], ['pending', false]);

    const asked = await request(server, m);
    assert.equal(asked.statusCode, 201);
    const reward = (asked.json() as { reward: { id: string; expiresAt: string } }).reward;
    assert.deepEqual(await grantRow(reward.id), { status: 'requested', car_id: null, user_id: m.id }, 'the owner is the token\'s account');

    assert.equal((await consume(server, m, reward.id, { carId: ad })).statusCode, 409, 'not verified by the server: nothing is published');
    assert.deepEqual([await carStatus(ad), await isPublic(ad)], ['pending', false]);

    await verifyOnServer(rewards, reward.id, m.id);
    assert.equal((await consume(server, other, reward.id, { carId: ad })).statusCode, 404, 'another account');
    const done = await consume(server, m, reward.id, { carId: ad });
    assert.equal(done.statusCode, 200);
    assert.deepEqual(done.json(), { reward: { id: reward.id, carId: ad, status: 'consumed', published: true } });
    assert.deepEqual([await carStatus(ad), await isPublic(ad)], ['active', true]);
    assert.deepEqual(await grantRow(reward.id), { status: 'consumed', car_id: ad, user_id: m.id });

    assert.equal((await consume(server, m, reward.id, { carId: ad })).statusCode, 200, 'the same request again');
    const second = await newAd(server, m);
    assert.equal((await consume(server, m, reward.id, { carId: second })).statusCode, 409, 'replay for another ad');
    assert.deepEqual([await carStatus(second), await isPublic(second)], ['pending', false]);
  });

  it('client-supplied proof never publishes: unknown fields are 400, and no HTTP route can verify', async () => {
    const { server } = await stack(true);
    const m = await register(server);
    const ad = await newAd(server, m);
    const reward = ((await request(server, m)).json() as { reward: { id: string } }).reward;
    for (const extra of [{ status: 'verified' }, { transactionId: 'x' }, { userId: m.id }, { success: true }]) {
      assert.equal((await consume(server, m, reward.id, { carId: ad, ...extra })).statusCode, 400, JSON.stringify(extra));
    }
    for (const url of [`/v1/me/rewards/${reward.id}/verify`, `/v1/me/rewards/${reward.id}`, '/v1/rewards/verify', '/v1/rewards/callback']) {
      const res = await server.inject({ method: 'POST', url, headers: { ...json, ...m.auth }, payload: JSON.stringify({ transactionId: 'x', status: 'verified' }) });
      assert.ok(res.statusCode === 404 || res.statusCode === 405, `${url} -> ${res.statusCode}`);
    }
    assert.deepEqual(await grantRow(reward.id), { status: 'requested', car_id: null, user_id: m.id });
    assert.deepEqual([await carStatus(ad), await isPublic(ad)], ['pending', false]);
  });

  it('authentication: no token is 401; a pending showroom owner is 403 and its activation is untouched', async () => {
    const { server } = await stack(true);
    assert.equal((await server.inject({ method: 'POST', url: '/v1/me/rewards' })).statusCode, 401);
    assert.equal((await server.inject({ method: 'POST', url: '/v1/me/rewards/00000000-0000-4000-8000-000000000001/consume', headers: json, payload: '{"carId":"1"}' })).statusCode, 401);
    const phone = newPhone();
    const r = (await server.inject({ method: 'POST', url: '/v1/dealers/register', headers: json, payload: JSON.stringify({ name: 'تاجر مكافأة', phone: local(phone), password: PW }) }));
    if (r.statusCode === 201 || r.statusCode === 200) {
      const token = (r.json() as { session?: { accessToken: string } }).session?.accessToken;
      if (token) {
        assert.equal((await server.inject({ method: 'POST', url: '/v1/me/rewards', headers: { authorization: `Bearer ${token}` } })).statusCode, 403);
        assert.equal((await admin.query(`SELECT status FROM users WHERE phone_e164::text = $1`, [phone])).rows[0]!.status, 'pending');
      }
    }
  });

  it('production default: with the unconfigured verifier a request is 503 and nothing exists to consume', async () => {
    const { server } = await stack(false);
    const m = await register(server);
    const ad = await newAd(server, m);
    const res = await request(server, m);
    assert.equal(res.statusCode, 503);
    assert.equal((res.json() as { error: { code: string } }).error.code, 'unavailable');
    assert.equal((await admin.query('SELECT 1 FROM reward_grants WHERE user_id = $1::bigint', [m.id])).rows.length, 0);
    assert.equal((await consume(server, m, '00000000-0000-4000-8000-000000000001', { carId: ad })).statusCode, 404);
    assert.deepEqual([await carStatus(ad), await isPublic(ad)], ['pending', false]);
  });

  it('concurrency over HTTP: two consumptions of one grant for two ads publish exactly one', async () => {
    const { server, rewards } = await stack(true);
    const m = await register(server);
    const a = await newAd(server, m);
    const b = await newAd(server, m);
    const reward = ((await request(server, m)).json() as { reward: { id: string } }).reward;
    await verifyOnServer(rewards, reward.id, m.id);
    const results = await Promise.all([consume(server, m, reward.id, { carId: a }), consume(server, m, reward.id, { carId: b })]);
    assert.deepEqual(results.map((x) => x.statusCode).sort(), [200, 409]);
    assert.equal([await carStatus(a), await carStatus(b)].filter((s) => s === 'active').length, 1);
  });
});

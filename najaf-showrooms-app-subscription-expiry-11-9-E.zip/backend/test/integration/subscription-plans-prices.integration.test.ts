// Phase 11.9-C against a real PostgreSQL 16 (migrations 0001-0014), through the least-privilege application role: an administrator
// changes the price of a duration plan, the audit row is written in the same transaction with the old and new price, an unchanged
// price writes nothing, a failed audit rolls the price back, and the free plan and the other columns are never touched.
// Needs DATABASE_URL and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY); skipped visibly without them.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgSubscriptionPlansRepository } from '../../src/subscription-plans/repository.ts';
import { createSubscriptionPlansService, SubscriptionPlansError } from '../../src/subscription-plans/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

interface AuditRow { actor_id: string | null; actor_role: string; action: string; entity_type: string; entity_id: string; after_data: { oldPrice: number; newPrice: number }; request_id: string | null; occurred_at: Date }

describe('subscription plan prices on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let admin: Db;
  let svc: ReturnType<typeof createSubscriptionPlansService>;
  const A: Actor = { id: '987654321', role: 'admin' };
  const price = async (code: string): Promise<string> => (await admin.query<{ price: string }>(`SELECT price FROM subscription_plans WHERE code = $1`, [code])).rows[0]!.price;
  const planId = async (code: string): Promise<string> => String((await admin.query<{ id: number }>(`SELECT id FROM subscription_plans WHERE code = $1`, [code])).rows[0]!.id);
  const audits = async (entityId: string): Promise<AuditRow[]> =>
    (await admin.query<AuditRow>(`SELECT actor_id, actor_role, action, entity_type, entity_id, after_data, request_id, occurred_at FROM audit_logs WHERE entity_type = 'subscription_plan' AND entity_id = $1 ORDER BY id`, [entityId])).rows;
  const reset = async () => { await admin.query(`UPDATE subscription_plans SET price = 0 WHERE code IN ('plan_3m', 'plan_6m', 'plan_12m')`); };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    svc = createSubscriptionPlansService({ repo: createPgSubscriptionPlansRepository(app) });
    await reset();
  });
  after(async () => {
    if (admin) await reset(); // audit rows are append-only and stay; prices go back to the initial 0 other suites expect
    await app?.close();
    await admin?.close();
  });

  it('lists exactly the three duration plans, shortest first, in IQD, never the free plan', async () => {
    const { plans } = await svc.listPlans(A);
    assert.deepEqual(plans.map((p) => [p.code, p.durationMonths, p.currency, p.price]), [['plan_3m', 3, 'IQD', 0], ['plan_6m', 6, 'IQD', 0], ['plan_12m', 12, 'IQD', 0]]);
  });

  it('changes a price under the app role and writes one audit row with actor, plan, old price, new price and a timestamp', async () => {
    const id = await planId('plan_6m');
    const before = (await audits(id)).length;
    const out = await svc.setPrice(A, 'plan_6m', { price: 55000 }, { requestId: 'it-req-1' });
    assert.deepEqual([out.changed, out.plan.price, out.plan.currency], [true, 55000, 'IQD']);
    assert.equal(await price('plan_6m'), '55000');
    const rows = await audits(id);
    assert.equal(rows.length, before + 1);
    const row = rows[rows.length - 1]!;
    assert.deepEqual([String(row.actor_id), row.actor_role, row.action, row.entity_type, row.entity_id, row.request_id], ['987654321', 'admin', 'subscription_plan.price_update', 'subscription_plan', id, 'it-req-1']);
    assert.deepEqual(row.after_data, { oldPrice: 0, newPrice: 55000 });
    assert.ok(Math.abs(Date.now() - row.occurred_at.getTime()) < 60_000);
    const second = await svc.setPrice(A, 'plan_6m', { price: 60000 });
    assert.equal(second.changed, true);
    assert.deepEqual((await audits(id)).at(-1)!.after_data, { oldPrice: 55000, newPrice: 60000 });
  });

  it('the same price changes nothing and writes no audit row', async () => {
    const id = await planId('plan_12m');
    await svc.setPrice(A, 'plan_12m', { price: 120000 });
    const n = (await audits(id)).length;
    const again = await svc.setPrice(A, 'plan_12m', { price: 120000 });
    assert.equal(again.changed, false);
    assert.equal((await audits(id)).length, n);
  });

  it('only the price moves: currency, entitlements, activity, duration and code stay; the free plan is untouched', async () => {
    const snap = async () => (await admin.query(`SELECT code, name, duration_months, currency, entitlements, is_active, billing_interval FROM subscription_plans ORDER BY id`)).rows;
    const before = await snap();
    await svc.setPrice(A, 'plan_3m', { price: 30000 });
    assert.deepEqual(await snap(), before);
    assert.equal(await price('free'), '0');
  });

  it('refuses invalid prices, an unknown plan and the free plan; nothing is written for any of them', async () => {
    const free = await planId('free');
    const total = async () => Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM audit_logs WHERE action = 'subscription_plan.price_update'`)).rows[0]!.n);
    const n = await total();
    const p3 = await price('plan_3m');
    for (const body of [{ price: -1 }, { price: 1.5 }, { price: '5' }, { price: MAX + 1 }, {}, { price: 1, currency: 'USD' }]) await assert.rejects(() => svc.setPrice(A, 'plan_3m', body), (e) => e instanceof SubscriptionPlansError);
    for (const code of ['free', 'plan_1m', 'nope']) await assert.rejects(() => svc.setPrice(A, code, { price: 5 }), (e) => e instanceof AuthzError && e.code === 'not_found');
    assert.equal(await price('plan_3m'), p3); assert.equal(await price('free'), '0');
    assert.equal(await total(), n); assert.equal((await audits(free)).length, 0);
  });

  it('a member, a dealer and no actor cannot change a price; the price and the audit trail stay as they were', async () => {
    const p = await price('plan_3m');
    const n = (await audits(await planId('plan_3m'))).length;
    for (const who of [{ id: '5', role: 'member' }, { id: '6', role: 'dealer' }, null] as Array<Actor | null>) {
      await assert.rejects(() => svc.setPrice(who, 'plan_3m', { price: 1 }), (e) => e instanceof AuthzError && e.code === 'not_found');
      await assert.rejects(() => svc.listPlans(who), (e) => e instanceof AuthzError);
    }
    assert.equal(await price('plan_3m'), p);
    assert.equal((await audits(await planId('plan_3m'))).length, n);
  });

  it('the price and its audit row are one transaction: when the audit write fails, the price is rolled back', async () => {
    const id = await planId('plan_3m');
    const p = await price('plan_3m');
    const n = (await audits(id)).length;
    const repo = createPgSubscriptionPlansRepository(app);
    // afterData carrying a non-number makes the single audit writer throw INSIDE the transaction
    await assert.rejects(() => repo.setPrice({ code: 'plan_3m', price: 77777, audit: (oldPrice, planId) => ({ action: 'subscription_plan.price_update', actorUserId: '1', actorRole: 'admin', entityType: 'subscription_plan', entityId: planId, afterData: { oldPrice, newPrice: Number.NaN } }) }));
    assert.equal(await price('plan_3m'), p);
    assert.equal((await audits(id)).length, n);
  });

  it('two concurrent changes serialize: each audit row records the price it really replaced', async () => {
    const id = await planId('plan_3m');
    await svc.setPrice(A, 'plan_3m', { price: 1000 });
    const before = (await audits(id)).length;
    await Promise.all([svc.setPrice(A, 'plan_3m', { price: 2000 }), svc.setPrice(A, 'plan_3m', { price: 3000 })]);
    const rows = (await audits(id)).slice(before);
    assert.equal(rows.length, 2);
    assert.equal(rows[0]!.after_data.oldPrice, 1000);
    assert.equal(rows[1]!.after_data.oldPrice, rows[0]!.after_data.newPrice);
    assert.equal(await price('plan_3m'), String(rows[1]!.after_data.newPrice));
  });
});

const MAX = 9_999_999_999_999;

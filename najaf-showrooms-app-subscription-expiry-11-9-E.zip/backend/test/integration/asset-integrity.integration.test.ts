// Phase 11.7.2-K against a real PostgreSQL 16 (application role) and the in-memory storage provider: the single-asset lookup (status,
// referenced flag and age by the database clock), the audited delete (the record and its audit row are one transaction; a refusal or
// a failing audit write leaves everything as it was), the race with a concurrent cover attach, and a whole scan + confirmed cleanup
// through the service. Needs DATABASE_URL and ADMIN_DATABASE_URL; without them the suite is skipped visibly. Fixtures are written with
// the admin handle and removed afterwards (audit rows are append-only by design and stay).
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash, randomInt, randomUUID } from 'node:crypto';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgIntegrityRepository } from '../../src/assets/integrity-repository.ts';
import type { IntegrityRepository } from '../../src/assets/integrity-repository.ts';
import { createAssetIntegrityService, objectRef } from '../../src/assets/integrity.ts';
import { classifyObjectKey } from '../../src/assets/cleanup.ts';
import { createMemoryStorage } from '../../src/storage/index.ts';
import { fakeWebp } from '../helpers/fake-codec.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const MAIN = fakeWebp(16, 12, { payload: 40 });
const THUMB = fakeWebp(8, 6, { payload: 20 });
const sha = (b: Uint8Array) => createHash('sha256').update(b).digest('hex');
const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const GRACE = 24 * 3600;

describe('asset integrity scan and cleanup on PostgreSQL 16', { skip }, () => {
  let app: Db;
  let admin: Db;
  let repo: IntegrityRepository;
  const userIds: string[] = [];
  const storage = createMemoryStorage();
  let dealer: string;
  let showroom: string;

  const newUser = async (role: 'user' | 'dealer'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const readyAsset = async (ageHours: number, o: { objects?: boolean } = {}): Promise<{ id: string; key: string; thumbKey: string }> => {
    const u = randomUUID();
    const key = `processed/showroom_cover/${u}.webp`;
    const thumbKey = `thumbs/showroom_cover/${u}.webp`;
    const r = await admin.query<{ id: string }>(
      `INSERT INTO assets (owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at, created_at)
       VALUES ($1::bigint, 'showroom_cover', 'ready', $2, $3, 'image/webp', $4, 16, 12, $5, now() - make_interval(hours => $6), now() - make_interval(hours => $6 + 1)) RETURNING id`,
      [dealer, key, thumbKey, MAIN.byteLength, sha(MAIN), ageHours],
    );
    if (o.objects !== false) {
      await storage.put(key, MAIN, { contentType: 'image/webp' });
      await storage.put(thumbKey, THUMB, { contentType: 'image/webp' });
    }
    return { id: String(r.rows[0]!.id), key, thumbKey };
  };
  const setCover = (assetId: string | null) => admin.query('UPDATE showrooms SET cover_asset_id = $2::uuid WHERE id = $1::bigint', [showroom, assetId]);
  const exists = async (id: string) => (await admin.query<{ c: string }>('SELECT count(*) AS c FROM assets WHERE id = $1::uuid', [id])).rows[0]!.c === '1';
  const trail = async (entityId: string) => (await admin.query<{ action: string; entity_type: string; actor_role: string; actor_id: string; after_data: Record<string, number> }>(`SELECT action, entity_type, actor_role, actor_id, after_data FROM audit_logs WHERE entity_id = $1 ORDER BY id`, [entityId])).rows;
  const event = (id: string, afterData: Record<string, number> = { bytes: 1 }) => ({ action: 'asset_integrity.delete_asset' as const, actorUserId: dealer, actorRole: 'admin', entityType: 'asset' as const, entityId: id, afterData, requestId: 'req-int-test' });

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    repo = createPgIntegrityRepository(app);
    dealer = await newUser('dealer');
    showroom = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', 'active') RETURNING id`, [dealer])).rows[0]!.id);
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('UPDATE showrooms SET cover_asset_id = NULL WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM showrooms WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  it('getAsset: status, keys, referenced and age by the database clock; an unknown id is null; the app role can read it', async () => {
    const old = await readyAsset(48);
    const cover = await readyAsset(48);
    await setCover(cover.id);
    const pending = String((await admin.query<{ id: string }>(`INSERT INTO assets (owner_id, kind, status, storage_key, bytes, width, height, sha256) VALUES ($1::bigint, 'showroom_cover', 'pending', $2, 10, 4, 3, $3) RETURNING id`, [dealer, `incoming/showroom_cover/${randomUUID()}`, 'b'.repeat(64)])).rows[0]!.id);
    const a = (await repo.getAsset(old.id))!;
    assert.deepEqual({ status: a.status, kind: a.kind, referenced: a.referenced, storageKey: a.storageKey, thumbKey: a.thumbKey }, { status: 'ready', kind: 'showroom_cover', referenced: false, storageKey: old.key, thumbKey: old.thumbKey });
    assert.ok(a.readyAgeSeconds! > 47 * 3600 && a.readyAgeSeconds! < 49 * 3600);
    assert.equal((await repo.getAsset(cover.id))!.referenced, true);
    const p = (await repo.getAsset(pending))!;
    assert.deepEqual({ status: p.status, age: p.readyAgeSeconds }, { status: 'pending', age: null });
    assert.equal(await repo.getAsset(randomUUID()), null);
    await setCover(null);
  });

  it('deleteUnlinkedAudited: the record and its audit row are one unit; every refusal writes nothing', async () => {
    const referenced = await readyAsset(48);
    const young = await readyAsset(1);
    const old = await readyAsset(48);
    await setCover(referenced.id);
    const del = (x: { id: string; key: string; thumbKey: string }, o: { key?: string; grace?: number } = {}) => repo.deleteUnlinkedAudited({ id: x.id, storageKey: o.key ?? x.key, thumbKey: x.thumbKey, graceSeconds: o.grace ?? GRACE, audit: event(x.id) });
    assert.equal(await del(referenced), false);
    assert.equal(await del(young), false);
    assert.equal(await del(old, { key: old.key + 'x' }), false);
    assert.equal(await del(old, { grace: 72 * 3600 }), false);
    for (const x of [referenced, young, old]) assert.deepEqual(await trail(x.id), [], 'a refused delete writes no audit row');
    assert.equal(await del(old), true);
    assert.equal(await exists(old.id), false);
    const rows = await trail(old.id);
    assert.equal(rows.length, 1);
    assert.deepEqual({ action: rows[0]!.action, type: rows[0]!.entity_type, role: rows[0]!.actor_role, actor: rows[0]!.actor_id, data: rows[0]!.after_data }, { action: 'asset_integrity.delete_asset', type: 'asset', role: 'admin', actor: dealer, data: { bytes: 1 } });
    assert.equal(await del(old), false, 'repeat-safe');
    assert.equal((await trail(old.id)).length, 1);
    await setCover(null);
  });

  it('a failing audit write rolls the delete back: the record survives', async () => {
    const x = await readyAsset(48);
    await assert.rejects(repo.deleteUnlinkedAudited({ id: x.id, storageKey: x.key, thumbKey: x.thumbKey, graceSeconds: GRACE, audit: event(x.id, { token: 1 }) }));
    assert.equal(await exists(x.id), true);
    assert.deepEqual(await trail(x.id), []);
  });

  it('a cover attached concurrently is never cleared: the audited delete waits for the attach and then refuses', async () => {
    const a = await readyAsset(48);
    let attached!: () => void;
    const holding = new Promise<void>((resolve) => { attached = resolve; });
    const attacher = admin.tx(async (t) => {
      await t.query('UPDATE showrooms SET cover_asset_id = $2::uuid WHERE id = $1::bigint', [showroom, a.id]);
      attached();
      await new Promise((r) => setTimeout(r, 1500));
    });
    await holding;
    const started = Date.now();
    const removed = await repo.deleteUnlinkedAudited({ id: a.id, storageKey: a.key, thumbKey: a.thumbKey, graceSeconds: GRACE, audit: event(a.id) });
    await attacher;
    assert.equal(removed, false);
    assert.ok(Date.now() - started >= 1000, 'the delete waited for the attacher instead of racing it');
    assert.equal(await exists(a.id), true);
    assert.deepEqual(await trail(a.id), []);
    await setCover(null);
  });

  it('a whole scan and confirmed cleanup through the service: classifies, revalidates, deletes only what is proven safe, audits it', async () => {
    const damaged = await readyAsset(72, { objects: false }); // referenced by the cover, its objects are gone: report only
    const unused = await readyAsset(72);                      // unlinked, old: deletable
    const fresh = await readyAsset(2);                        // unlinked, inside the grace period: protected
    await setCover(damaged.id);
    const mine = new Set([damaged.id, unused.id, fresh.id]);
    const scoped: IntegrityRepository = { ...repo, async listReady(i) { return (await repo.listReady(i)).filter((r) => mine.has(r.id)); } };
    // The wrapper filters AFTER the repository's keyset page, and the audit treats a page shorter than batchSize as the end of the scan.
    // On the shared CI database other suites leave ready records, so a 50-row page can hold none of ours and end the scan early.
    // A page larger than the whole table (as in the 11.6.6 integration test) makes the filtered listing complete.
    const svc = createAssetIntegrityService({ repo: scoped, storage, sleep: async () => {}, limits: { batchSize: 1000 } });
    const admin1 = { id: dealer, role: 'admin' as const };
    const scan = await svc.scan(admin1, { scope: 'assets' });
    const by = new Map(scan.items.map((i) => [i.ref.id, i]));
    assert.equal(by.get(damaged.id)!.category, 'missing');
    assert.deepEqual([by.get(damaged.id)!.deletable, by.get(damaged.id)!.protectedReason], [false, 'referenced']);
    assert.deepEqual([by.get(unused.id)!.category, by.get(unused.id)!.deletable], ['orphaned', true]);
    assert.deepEqual([by.get(fresh.id)!.deletable, by.get(fresh.id)!.protectedReason], [false, 'within_grace']);
    assert.equal(await exists(unused.id), true, 'the scan deleted nothing');
    const r = await svc.cleanup(admin1, { confirm: true, items: [damaged.id, unused.id, fresh.id].map((id) => ({ type: 'asset', id })) }, { requestId: 'req-int-test' });
    const out = new Map(r.results.map((x) => [x.ref.id, x]));
    assert.deepEqual([out.get(damaged.id)!.outcome, out.get(damaged.id)!.reason], ['protected', 'referenced']);
    assert.equal(out.get(unused.id)!.outcome, 'deleted');
    assert.deepEqual([out.get(fresh.id)!.outcome, out.get(fresh.id)!.reason], ['protected', 'within_grace']);
    assert.equal(await exists(unused.id), false);
    assert.equal(await storage.exists(unused.key), false);
    assert.equal(await storage.exists(unused.thumbKey), false);
    assert.equal(await exists(damaged.id) && (await exists(fresh.id)), true);
    assert.equal(await storage.exists(fresh.key), true);
    assert.equal((await trail(unused.id)).length, 1);
    // An orphaned object: no row has it. Its trail is written before the delete.
    const orphanKey = `processed/car_image/${randomUUID()}.webp`;
    await storage.put(orphanKey, MAIN, { contentType: 'image/webp' });
    storage.touch(orphanKey, new Date(Date.now() - 72 * 3600 * 1000));
    const ref = objectRef(classifyObjectKey(orphanKey)!, orphanKey);
    const o = await svc.cleanup(admin1, { confirm: true, items: [{ type: 'object', id: ref }] });
    assert.equal(o.results[0]!.outcome, 'deleted');
    assert.equal(await storage.exists(orphanKey), false);
    assert.equal((await trail(ref))[0]!.action, 'asset_integrity.delete_object');
    await setCover(null);
  });
});

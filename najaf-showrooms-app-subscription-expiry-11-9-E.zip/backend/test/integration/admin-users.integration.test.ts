// The administrators' account directory and dashboard statistics (Phase 11.7.2-J) against a real PostgreSQL 16 (migrations 0001-0013),
// through the least-privilege application role. Needs DATABASE_URL and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY);
// skipped visibly without them. Proves the statements run under the app role's grants, never return a secret column, leave out
// soft-deleted rows, paginate by keyset, and that every statistic moves by exactly the records added (deltas, so other suites' rows
// in the same database do not matter).
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgAdminUsersRepository } from '../../src/admin-users/repository.ts';
import { createAdminUsersService } from '../../src/admin-users/service.ts';
import type { AdminUserView } from '../../src/admin-users/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';

describe('admin users and statistics on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let admin: Db;
  const userIds: string[] = [];
  let A: Actor;
  let svc: ReturnType<typeof createAdminUsersService>;

  const newUser = async (role: 'user' | 'dealer' | 'admin', status = 'active', email: string | null = null): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, email, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, $3, $4, $5) RETURNING id`, [phone, email, role, status, HASH]);
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const newShowroom = async (ownerId: string, status = 'active'): Promise<string> =>
    String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', $2) RETURNING id`, [ownerId, status])).rows[0]!.id);
  const newMemberCar = async (ownerId: string, status: string): Promise<string> =>
    String((await admin.query<{ id: string }>(
      `INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status, search_text, rejection_reason, suspension_reason)
       VALUES ('member', $1::bigint, 'Toyota', 'Corolla', 2016, 14500, 'USD', '+9647701234567', 'النجف', $2, 'toyota corolla 2016', $3, $4) RETURNING id`,
      [ownerId, status, status === 'rejected' ? 'سبب' : null, status === 'suspended' ? 'سبب' : null],
    )).rows[0]!.id);
  const newShowroomCar = async (showroomId: string): Promise<string> =>
    String((await admin.query<{ id: string }>(`INSERT INTO cars (source_type, showroom_id, brand, model, year, price, currency, status, search_text) VALUES ('showroom', $1::bigint, 'Kia', 'Sportage', 2022, 31000000, 'IQD', 'available', 'kia') RETURNING id`, [showroomId])).rows[0]!.id);

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    A = { id: await newUser('admin'), role: 'admin' };
    svc = createAdminUsersService({ repo: createPgAdminUsersRepository(app) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[]) OR showroom_id IN (SELECT id FROM showrooms WHERE owner_id = ANY($1::bigint[]))', [userIds]);
      await admin.query('DELETE FROM showrooms WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await admin?.close();
  });

  it('lists accounts with exactly the admin fields, filtered by role, paginated by keyset, without soft-deleted accounts', async () => {
    const d1 = await newUser('dealer', 'pending', 'd1@example.com');
    const d2 = await newUser('dealer');
    const gone = await newUser('dealer');
    await admin.query('UPDATE users SET deleted_at = now() WHERE id = $1::bigint', [gone]);
    const seen: string[] = [];
    let after: string | null = null;
    for (let i = 0; i < 1000; i++) {
      const page: { users: AdminUserView[]; nextAfter: string | null } = await svc.listUsers(A, { role: 'dealer', limit: '2', ...(after ? { after } : {}) });
      for (const u of page.users) {
        assert.deepEqual(Object.keys(u).sort(), ['createdAt', 'email', 'id', 'name', 'phone', 'role', 'status']);
        assert.equal(u.role, 'dealer');
        seen.push(u.id);
      }
      if (!page.nextAfter) break;
      after = page.nextAfter;
    }
    assert.ok(seen.includes(d1) && seen.includes(d2));
    assert.ok(!seen.includes(gone), 'soft-deleted account left out');
    assert.deepEqual([...seen].sort((a, b) => Number(BigInt(a) - BigInt(b))), seen, 'ascending ids');
    const one = (await svc.listUsers(A, { role: 'dealer', limit: '100' })).users.find((u) => u.id === d1)!;
    assert.deepEqual([one.status, one.email, typeof one.phone, typeof one.createdAt], ['pending', 'd1@example.com', 'string', 'string']);
    assert.ok(!/argon2/.test(JSON.stringify(one)));
  });

  it("one account: a dealer's showroom and member ads; unknown and soft-deleted accounts are 404; non-admins are 404", async () => {
    const d = await newUser('dealer');
    const s = await newShowroom(d, 'pending');
    const c1 = await newMemberCar(d, 'active');
    const c2 = await newMemberCar(d, 'rejected');
    const out = await svc.getUser(A, d);
    assert.equal(out.user.id, d);
    assert.deepEqual(out.showroom, { id: s, name: 'معرض اختبار', status: 'pending' });
    assert.deepEqual(out.memberCars.map((c) => [c.id, c.status]), [[c2, 'rejected'], [c1, 'active']]);
    assert.equal(out.memberCarsTotal, 2);
    const gone = await newUser('user');
    await admin.query('UPDATE users SET deleted_at = now() WHERE id = $1::bigint', [gone]);
    await assert.rejects(svc.getUser(A, gone), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    await assert.rejects(svc.getUser(A, '999999999999'), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    for (const who of [{ id: d, role: 'dealer' as const }, { id: gone, role: 'member' as const }]) {
      await assert.rejects(svc.getStats(who), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
      await assert.rejects(svc.listUsers(who, {}), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    }
  });

  it('every statistic moves by exactly the records added (soft-deleted excluded)', async () => {
    const before = await svc.getStats(A);
    const m = await newUser('user');
    await newUser('dealer', 'pending');
    const d = await newUser('dealer');
    const s = await newShowroom(d);
    for (const st of ['pending', 'active', 'active', 'sold', 'rejected', 'suspended']) await newMemberCar(m, st);
    const deletedCar = await newMemberCar(m, 'active');
    await admin.query('UPDATE cars SET deleted_at = now() WHERE id = $1::bigint', [deletedCar]);
    await newShowroomCar(s);
    await newShowroomCar(s);
    const gone = await newUser('dealer', 'pending');
    await admin.query('UPDATE users SET deleted_at = now() WHERE id = $1::bigint', [gone]);
    const now = await svc.getStats(A);
    const delta = Object.fromEntries(Object.keys(now).map((k) => [k, (now as unknown as Record<string, number>)[k]! - (before as unknown as Record<string, number>)[k]!]));
    assert.deepEqual(delta, {
      totalUsers: 3, totalShowrooms: 1, totalShowroomCars: 2, totalMemberCars: 6,
      pendingMemberCars: 1, activeMemberCars: 2, soldMemberCars: 1, rejectedMemberCars: 1, suspendedMemberCars: 1, pendingDealers: 1,
    });
  });
});

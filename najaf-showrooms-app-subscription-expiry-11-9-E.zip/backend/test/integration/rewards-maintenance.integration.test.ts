// Phase 11.8-G on PostgreSQL 16 (CI only; skipped visibly otherwise), through the least-privilege application role: the maintenance SQL is
// accepted (placeholder types, DELETE/UPDATE/INSERT privileges), expires and purges exactly the right rows, never touches a consumed grant,
// skips a row the live flow holds locked, is repeat-safe, and leaves one numbers-only 'system' audit row per executed run.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { createDb } from '../../src/db.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { createMemberCarService } from '../../src/member-cars/service.ts';
import type { Db } from '../../src/db.ts';
import { runRewardMaintenance } from '../../src/rewards/maintenance.ts';
import { createPgMaintenanceRepository } from '../../src/rewards/maintenance-repository.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';
import { makeGate } from '../helpers/pg-race.ts';

const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };
const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';

describe('reward maintenance on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  let repo: ReturnType<typeof createPgMaintenanceRepository>;
  const userIds: string[] = [];
  const carIds: string[] = [];

  const newUser = async (): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, 'user', 'active', $2) RETURNING id`, [phone, HASH]);
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  /** A grant whose expiry was `agoSeconds` ago (negative = still valid). created_at is set earlier so the expiry check constraint holds. */
  const insertGrant = async (userId: string, status: string, agoSeconds: number, opts: { carId?: string; tx?: string } = {}): Promise<string> => {
    const verified = status === 'verified' || status === 'consumed';
    const r = await admin.query<{ id: string }>(
      `INSERT INTO reward_grants (user_id, status, ssv_transaction_id, car_id, created_at, verified_at, consumed_at, expires_at)
       VALUES ($1::bigint, $2, $3, $4::bigint, now() - make_interval(secs => $5::int + 3600),
               CASE WHEN $6::boolean THEN now() - make_interval(secs => $5::int + 1800) END,
               CASE WHEN $2 = 'consumed' THEN now() - make_interval(secs => $5::int + 900) END,
               now() - make_interval(secs => $5::int)) RETURNING id`,
      [userId, status, verified ? (opts.tx ?? `mt-${randomInt(0, 1e9)}-${Math.random()}`) : null, opts.carId ?? null, agoSeconds, verified],
    );
    return String(r.rows[0]!.id);
  };
  const status = async (id: string): Promise<string | null> => (await admin.query<{ status: string }>('SELECT status FROM reward_grants WHERE id = $1::uuid', [id])).rows[0]?.status ?? null;
  const auditRows = async (): Promise<Record<string, number>[]> =>
    (await admin.query<{ after_data: Record<string, number> }>(`SELECT after_data FROM audit_logs WHERE action = 'reward_maintenance.run' ORDER BY id`)).rows.map((r) => r.after_data);

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    repo = createPgMaintenanceRepository(app);
  });
  after(async () => {
    if (admin) {
      await admin.query('DELETE FROM reward_grants WHERE user_id = ANY($1::bigint[])', [userIds]);
      if (carIds.length > 0) await admin.query('DELETE FROM cars WHERE id = ANY($1::bigint[])', [carIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('expires past-expiry requested/verified grants and nothing else; a dry run changes nothing', async () => {
    const u = await newUser();
    const reqOld = await insertGrant(u, 'requested', 120);
    const verOld = await insertGrant(u, 'verified', 120);
    const reqLive = await insertGrant(u, 'requested', -600);
    const verLive = await insertGrant(u, 'verified', -600);
    const failed = await insertGrant(u, 'failed', 120);
    const dry = await runRewardMaintenance({ repo }, { expire: true, purge: false });
    assert.equal(dry.dryRun, true);
    assert.ok((dry.expire?.eligible ?? 0) >= 2);
    assert.deepEqual([await status(reqOld), await status(verOld)], ['requested', 'verified']);

    const before = (await auditRows()).length;
    const r = await runRewardMaintenance({ repo }, { dryRun: false, purge: false, batchSize: 1000 });
    assert.equal(r.error, null);
    assert.ok((r.expire?.expired ?? 0) >= 2 && (r.expire?.expiredVerified ?? 0) >= 1);
    assert.deepEqual([await status(reqOld), await status(verOld)], ['expired', 'expired']);
    assert.deepEqual([await status(reqLive), await status(verLive), await status(failed)], ['requested', 'verified', 'failed']);
    const rows = await auditRows();
    assert.equal(rows.length, before + 1);
    assert.ok(Object.values(rows.at(-1)!).every((v) => typeof v === 'number'));

    // Repeat-safe: a second run finds nothing of ours to do.
    const again = await runRewardMaintenance({ repo }, { dryRun: false, purge: false, batchSize: 1000 });
    assert.equal(again.error, null);
    assert.equal(await status(reqOld), 'expired');
  });

  it('purges only old expired/failed grants without an ad; consumed grants and recent ones stay', async () => {
    const u = await newUser();
    const carId = (await createMemberCarService({ store: createPgMemberCarStore(app) }).create({ id: u, role: 'member' }, VALID)).id;
    carIds.push(carId);
    const oldExpired = await insertGrant(u, 'expired', 40 * 86400);
    const oldFailed = await insertGrant(u, 'failed', 40 * 86400);
    const recentExpired = await insertGrant(u, 'expired', 5 * 86400);
    const consumed = await insertGrant(u, 'consumed', 400 * 86400, { carId });
    const r = await runRewardMaintenance({ repo }, { dryRun: false, expire: false, retentionDays: 30, batchSize: 1000 });
    assert.equal(r.error, null);
    assert.ok((r.purge?.deleted ?? 0) >= 2);
    assert.deepEqual([await status(oldExpired), await status(oldFailed)], [null, null]);
    assert.equal(await status(recentExpired), 'expired');
    assert.equal(await status(consumed), 'consumed');
  });

  it('skips a grant the live flow holds locked, and picks it up on the next run', async () => {
    const u = await newUser();
    const id = await insertGrant(u, 'verified', 120);
    const gate = makeGate();
    const locked = makeGate();
    const holder = app2.tx(async (t) => {
      await t.query('SELECT id FROM reward_grants WHERE id = $1::uuid FOR UPDATE', [id]);
      locked.release();
      await gate.open;
    });
    await locked.open;
    const during = await runRewardMaintenance({ repo }, { dryRun: false, purge: false, batchSize: 1000 });
    assert.equal(during.error, null);
    assert.equal(await status(id), 'verified'); // skipped, not blocked
    gate.release();
    await holder;
    await runRewardMaintenance({ repo }, { dryRun: false, purge: false, batchSize: 1000 });
    assert.equal(await status(id), 'expired');
  });

  it('the application role may not rewrite or remove audit rows (the trail stays append-only)', async () => {
    await assert.rejects(app.query(`DELETE FROM audit_logs WHERE action = 'reward_maintenance.run'`));
    await assert.rejects(app.query(`UPDATE audit_logs SET action = 'x' WHERE action = 'reward_maintenance.run'`));
  });
});

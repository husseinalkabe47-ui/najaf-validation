// Operational (diagnostic) logging rules (Phase 11.8-H). Pure functions, no Fastify/pino import, so they are unit-testable anywhere.
//
// Two different records, never mixed:
//   - the AUDIT trail (audit_logs, auth/repository.ts createPgAuditRepository): who did what to which entity, written inside the
//     same transaction as the action, append-only, numbers only. Nothing in this file writes it and a log line never replaces it.
//   - DIAGNOSTIC logs (this file): what the process observed (events, failures, timings) for an operator. Best effort, can be lost,
//     never the source of truth for a business fact.
//
// What must never reach a log: passwords, one-time codes, access/refresh tokens, session cookies, secrets, signatures, the raw query
// string of a request (the AdMob callback carries the signature, user id and transaction id there), phone numbers, and the values the
// database driver puts inside its messages (`Key (phone_e164)=(+9647...) already exists`). Three layers enforce it:
//   1. serializers: the request is logged WITHOUT its query string; an error is logged as name/kind/sqlstate/constraint/redacted message;
//   2. a key/value scrub over every plain log object (a field NAMED like a secret is replaced; a string that LOOKS like a bearer token,
//      JWT, phone number, URL credential or driver value is masked);
//   3. pino's own header redaction (authorization, cookie, set-cookie, signature headers).
// The scrub is a safety net: call sites still pass only what an operator needs (event name, ids, counts, reason codes).
const CENSOR = '[redacted]';

/** Field names whose value is never logged, whatever it holds. Matched anywhere in the name, case-insensitively. */
const SECRET_KEY = /(pass(word|wd)?|token|secret|otp|authorization|cookie|signature|credential|api_?key|private_?key|session_?(id|key)|hash|phone|(verification|reset|one_?time|sms)_?code|csrf)/i;
/** Keys that are objects serialized by their own serializer (the raw request/response/error must not be walked here). */
const SERIALIZED_KEYS = new Set(['req', 'res', 'err', 'error']);

const BEARER = /\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}/gi;
const JWT = /\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\b/g;
const URL_CREDENTIALS = /\b([a-z][a-z0-9+.-]*:\/\/)[^\s/:@]+:[^\s/@]+@/gi;
/** Iraqi numbers as the project stores or accepts them: +9647XXXXXXXXX, 9647XXXXXXXXX, 07XXXXXXXXX. */
const PHONE = /(?<![0-9A-Za-z])(?:\+?964|0)7[0-9]{9}(?![0-9])/g;
/** pg messages: `Key (column)=(value) ...`, `Failing row contains (...)`, `DETAIL: ...` carry row values. */
const PG_KEY_VALUE = /\bKey \(([^)]*)\)=\((.*?)\)/g;
const PG_FAILING_ROW = /Failing row contains \([^\n]*\)/g;
const QUERY_IN_URL = /([?&](?:signature|key_id|user_id|custom_data|transaction_id|token|code|otp|password)=)[^&\s]*/gi;

/** Masks anything in a string that looks like a credential, a phone number or a driver-quoted row value. */
export function redactText(text: string): string {
  return text
    .replace(URL_CREDENTIALS, `$1${CENSOR}@`)
    .replace(PG_FAILING_ROW, `Failing row contains (${CENSOR})`)
    .replace(PG_KEY_VALUE, `Key ($1)=(${CENSOR})`)
    .replace(BEARER, `$1 ${CENSOR}`)
    .replace(JWT, CENSOR)
    .replace(QUERY_IN_URL, `$1${CENSOR}`)
    .replace(PHONE, CENSOR);
}

const MAX_DEPTH = 6;
const MAX_ITEMS = 50;
const MAX_STRING = 2000;

/** Deep copy of a log value with secrets removed. Cycle-safe, bounded, never throws. */
export function scrubValue(value: unknown, depth = 0, seen: WeakSet<object> = new WeakSet()): unknown {
  if (typeof value === 'string') return redactText(value.length > MAX_STRING ? `${value.slice(0, MAX_STRING)}…` : value);
  if (value === null || typeof value !== 'object') return typeof value === 'function' || typeof value === 'symbol' ? undefined : value;
  if (value instanceof Date) return value;
  if (value instanceof Error) return serializeErr(value);
  if (depth >= MAX_DEPTH || seen.has(value)) return '[truncated]';
  seen.add(value);
  if (Array.isArray(value)) return value.slice(0, MAX_ITEMS).map((v) => scrubValue(v, depth + 1, seen));
  const out: Record<string, unknown> = {};
  let n = 0;
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if (n++ >= MAX_ITEMS) break;
    out[k] = SECRET_KEY.test(k) ? CENSOR : scrubValue(v, depth + 1, seen);
  }
  return out;
}

/** The pino `formatters.log` hook: scrubs every plain field, leaving req/res/err to their serializers. */
export function scrubLogObject(obj: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    out[k] = SERIALIZED_KEYS.has(k) ? v : SECRET_KEY.test(k) ? CENSOR : scrubValue(v);
  }
  return out;
}

/**
 * The shapes below are exactly what Fastify's `logger.serializers` accepts (types/logger.d.ts): every return type carries an index
 * signature `[key: string]: unknown` (an interface without one is not assignable), req: method/url/host/remoteAddress/remotePort,
 * res: statusCode, err: type/message/stack always present. So the options type-check against Fastify without a cast.
 */
export interface LoggedReq {
  method?: string | undefined;
  url?: string | undefined;
  host?: string | undefined;
  remoteAddress?: string | undefined;
  remotePort?: number | undefined;
  /** The request had a query string; the string itself is never logged. */
  hasQuery?: boolean | undefined;
  [key: string]: unknown;
}
export interface LoggedRes {
  statusCode: number;
  [key: string]: unknown;
}
export interface LoggedErr {
  type: string;
  message: string;
  stack: string;
  [key: string]: unknown;
}

/** The request as logged: method, PATH (never the query string), host name, client address. No headers, no body. */
export function serializeReq(req: unknown): LoggedReq {
  const r = (req ?? {}) as { method?: unknown; url?: unknown; host?: unknown; hostname?: unknown; ip?: unknown; socket?: { remotePort?: unknown }; raw?: { url?: unknown } };
  const url = typeof r.url === 'string' ? r.url : typeof r.raw?.url === 'string' ? r.raw.url : '';
  const q = url.indexOf('?');
  const host = typeof r.host === 'string' ? r.host : typeof r.hostname === 'string' ? r.hostname : undefined;
  return {
    method: typeof r.method === 'string' ? r.method : undefined,
    url: redactText(q === -1 ? url : url.slice(0, q)),
    ...(q === -1 ? {} : { hasQuery: true }),
    host,
    remoteAddress: typeof r.ip === 'string' ? r.ip : undefined,
    remotePort: typeof r.socket?.remotePort === 'number' ? r.socket.remotePort : undefined,
  };
}

export function serializeRes(res: unknown): LoggedRes {
  const status = (res as { statusCode?: unknown } | null)?.statusCode;
  return { statusCode: typeof status === 'number' ? status : 0 };
}

/**
 * An error as logged. A database error keeps its classification (kind, sqlstate, constraint name) and its driver message with the
 * quoted row values masked; the stack is kept (it holds code locations, not data) and masked as text.
 */
export function serializeErr(err: unknown): LoggedErr {
  if (typeof err !== 'object' || err === null) return { type: 'Error', message: redactText(String(err)), stack: '' };
  const e = err as { name?: unknown; message?: unknown; stack?: unknown; kind?: unknown; sqlstate?: unknown; constraint?: unknown; code?: unknown; driverMessage?: unknown; statusCode?: unknown };
  const text = (v: unknown): string | undefined => (typeof v === 'string' ? redactText(v.length > MAX_STRING ? v.slice(0, MAX_STRING) : v) : undefined);
  return {
    type: typeof e.name === 'string' ? e.name : 'Error',
    message: text(e.message) ?? '',
    stack: typeof e.stack === 'string' ? redactText(e.stack.slice(0, 4000)) : '',
    ...(typeof e.kind === 'string' ? { kind: e.kind } : {}),
    ...(typeof e.sqlstate === 'string' ? { sqlstate: e.sqlstate } : {}),
    ...(typeof e.constraint === 'string' ? { constraint: e.constraint } : {}),
    ...(typeof e.code === 'string' && /^[A-Z0-9_]{2,40}$/.test(e.code) ? { code: e.code } : {}),
    ...(typeof e.statusCode === 'number' ? { statusCode: e.statusCode } : {}),
    ...(typeof e.driverMessage === 'string' ? { driverMessage: text(e.driverMessage) } : {}),
  };
}

/** The redaction paths handed to pino (header values that can carry a credential). */
export const REDACT_PATHS = Object.freeze([
  'req.headers.authorization',
  'req.headers.cookie',
  'req.headers["x-api-key"]',
  'res.headers["set-cookie"]',
]);

/** Everything the HTTP server's logger needs, in one place (server.ts passes it as `logger`). */
export function buildLoggerOptions(level: string, stream?: { write(line: string): void }) {
  return {
    level,
    ...(stream ? { stream } : {}),
    redact: { paths: [...REDACT_PATHS], censor: CENSOR },
    serializers: { req: serializeReq, res: serializeRes, err: serializeErr },
    formatters: { log: scrubLogObject },
  };
}

/** A request that took at least this long is logged as `http.slow_request` (milliseconds). */
export const SLOW_REQUEST_MS = 3000;

/** The diagnostic events the HTTP layer adds (the route PATTERN, never the URL: low cardinality, no ids, no query). */
export interface HttpOutcome {
  method: string;
  route: string;
  status: number;
  durationMs: number;
}
export function httpOutcomeEvents(o: HttpOutcome): { level: 'warn'; obj: Record<string, unknown> }[] {
  const out: { level: 'warn'; obj: Record<string, unknown> }[] = [];
  const base = { method: o.method, route: o.route, status: o.status, durationMs: Math.round(o.durationMs) };
  if (o.status >= 500) out.push({ level: 'warn', obj: { event: 'http.response_5xx', ...base } });
  if (o.durationMs >= SLOW_REQUEST_MS) out.push({ level: 'warn', obj: { event: 'http.slow_request', ...base } });
  return out;
}

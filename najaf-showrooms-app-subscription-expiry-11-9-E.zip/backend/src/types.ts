// Minimal logger contract (pino-compatible). The database layer depends on this, never on a concrete logger.
import { redactText, scrubValue } from './logging.ts';

export interface Logger {
  debug(obj: unknown, msg?: string): void;
  info(obj: unknown, msg?: string): void;
  warn(obj: unknown, msg?: string): void;
  error(obj: unknown, msg?: string): void;
}

export const nullLogger: Logger = {
  debug() {},
  info() {},
  warn() {},
  error() {},
};

// Structured JSON lines for boot-time messages (before the HTTP server's own logger exists).
export function createConsoleLogger(write: (line: string) => void = (line) => console.log(line)): Logger {
  const emit = (level: string, obj: unknown, msg?: string): void => {
    // Phase 11.8-H: the same masking as the HTTP logger (logging.ts), applied before anything is written.
    const base = (typeof obj === 'object' && obj !== null ? scrubValue(obj) : { msg: redactText(String(obj)) }) as Record<string, unknown>;
    write(JSON.stringify({ level, time: new Date().toISOString(), ...base, ...(msg ? { msg: redactText(msg) } : {}) }));
  };
  return {
    debug: (o, m) => emit('debug', o, m),
    info: (o, m) => emit('info', o, m),
    warn: (o, m) => emit('warn', o, m),
    error: (o, m) => emit('error', o, m),
  };
}

// Administrator-controlled asset INTEGRITY SCAN and confirmed CLEANUP (Phase 11.7.2-K). Built on what already exists: the integrity
// audit of Phase 11.6.6 (audit.ts: the same reads, checks and classification, run with dryRun: true), the cleanup job's key shapes
// and reference lookup (cleanup.ts), the locked compare-and-swap that removes an unlinked record (audit-repository.ts), the storage
// provider (list/get/delete), the authorization core and the single audit writer. No migration, no new storage path, no new asset state.
//
// SCAN (GET, READ ONLY). Nothing is deleted or written. Every finding falls in exactly ONE category:
//   corrupt    a 'ready' record whose objects exist but are not what the record says (invalid image, size, SHA-256 or dimensions);
//   missing    a 'ready' record with at least one object that does not exist;
//   unverified a 'ready' record that could not be checked (storage trouble that survived the retries): never deletable;
//   orphaned   stored data nothing uses: an object with NO record (no row has it as storage_key/thumb_key, nor its original/main
//              image), or a 'ready' record, healthy, that no car image and no showroom cover references ("unlinked").
//   A record that is both unreferenced and corrupt/missing is listed under corrupt/missing (health wins, the audit's precedence),
//   with `referenced: false` and its own deletability. A referenced record is NEVER deletable, whatever its health: it is reported only.
// Each item says whether it is `deletable` and, if not, why (`protectedReason`). Deletable means exactly what the audit's own
// execute pass deletes: an unlinked 'ready' record past the grace period whose keys have the generated shape, or an unreferenced
// object of a generated shape past the grace period. Health never makes anything deletable: an unreadable asset that something
// references stays; one that nothing references is deletable because NOTHING USES IT, not because it is unreadable.
//
// CLEANUP (POST, explicit confirmation). Nothing the scan said is trusted: for EACH selected item the server re-reads the database
// and the storage and decides again:
//   asset   the record must still exist, be 'ready' (a pending or rejected asset is uploading/processing/refused: protected), be
//           referenced by nothing, be past the grace period (database clock), and have the generated key shape. The record is then
//           removed by the SAME locked compare-and-swap as the audit (which waits for a concurrent attach, then re-checks all of it),
//           together with its audit row in ONE transaction; only after it commits are its objects (original, main, thumbnail) deleted.
//   object  it must still be listed, be of a generated shape, be past the grace period (storage clock) and be referenced by no row,
//           confirmed by TWO independent lookups; its audit row is written BEFORE the delete.
//   Anything that cannot be proven safe is skipped with a reason; it is never deleted "to be sure". A database/storage/audit failure
//   STOPS the run: the remaining items are `not_attempted`. At most one scan or cleanup runs at a time in this process (409 busy).
// Keys stay internal: a client sees an asset id (a UUID that is also the public image id) or an object REFERENCE `<area>.<kind>.<uuid>`
// (the object's generated name without its folder layout): never a prefix, bucket, endpoint, signed URL or credential.
import { DbError } from '../errors.ts';
import { StorageError } from '../storage/index.ts';
import type { ListableStorage } from '../storage/index.ts';
import type { FieldError } from '../auth/validation.ts';
import { assetIntegrityResource, authorize } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { runAssetAudit } from './audit.ts';
import type { AssetFinding, CorruptReason, OrphanFinding } from './audit.ts';
import type { IntegrityRepository } from './integrity-repository.ts';
import { classifyObjectKey, referenceCandidates } from './cleanup.ts';
import type { ObjectKeyInfo } from './cleanup.ts';

/** Same grace period as the audit and the cleanup job (never shorter: an upload about to be attached must not be removed). */
export const INTEGRITY_GRACE_HOURS = 24;
export const SCAN_ITEMS_MAX = 300;
export const CLEANUP_ITEMS_MAX = 50;
const SCAN_LIMITS = {
  assets: { batchSize: 50, maxBatches: 8 },
  objects: { batchSize: 100, maxBatches: 12 },
  all: { batchSize: 50, maxBatches: 8 },
} as const;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const OBJECT_REF = /^(incoming|processed|thumbs)\.(car_image|showroom_cover)\.([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/;
const SHARD = /^[0-9a-f]{0,2}$/;

export type IntegrityCategory = 'corrupt' | 'missing' | 'orphaned' | 'unverified';
export type ProtectedReason = 'referenced' | 'within_grace' | 'unrecognized_key' | 'unverified' | 'not_ready' | 'invalid_reference';
export type ItemReason = CorruptReason | 'object_missing' | 'unlinked_record' | 'no_record' | 'unverifiable';
export interface IntegrityItem {
  ref: { type: 'asset' | 'object'; id: string };
  category: IntegrityCategory;
  reason: ItemReason;
  kind: string;
  /** An asset record exists for it (false for an object without a record). */
  hasRecord: boolean;
  /** A car image or a showroom cover uses it (always false for an object without a record). */
  referenced: boolean;
  /** Bytes read from storage (a record: main image + thumbnail); null when none could be measured. */
  sizeBytes: number | null;
  /** Age in whole hours (a record: since it became ready; an object: since its last modification). */
  ageHours: number;
  deletable: boolean;
  protectedReason: ProtectedReason | null;
}
export interface ScanSummary {
  scannedAssets: number;
  scannedObjects: number;
  corrupt: number;
  missing: number;
  orphaned: number;
  unverified: number;
  /** Of those, referenced by a listing (report only). */
  referencedProblems: number;
  deletable: number;
  protected: number;
  /** Sum of the known sizes of the deletable items: an ESTIMATE (a missing or unmeasurable object counts as 0). */
  recoverableBytes: number;
}
export interface ScanResult {
  scannedAt: string;
  scope: 'all' | 'assets' | 'objects';
  graceHours: number;
  /** Every record (or, for objects, every listed prefix page) the limits allow was examined. false = scan again with the cursor/shard. */
  complete: boolean;
  /** Pass the value as `after` to continue the record scan; null when the records are done. */
  nextAfter: string | null;
  /** The scan stopped early on this condition; the items found so far are still individually verified. */
  error: 'database_unavailable' | 'storage_unavailable' | 'unexpected' | null;
  summary: ScanSummary;
  items: IntegrityItem[];
  /** More items were found than SCAN_ITEMS_MAX; the summary counts all of them. */
  truncated: boolean;
}

export type CleanupOutcome = 'deleted' | 'protected' | 'gone' | 'changed' | 'failed' | 'not_attempted';
export interface CleanupItemResult {
  ref: { type: 'asset' | 'object'; id: string };
  outcome: CleanupOutcome;
  reason: ProtectedReason | 'storage_unavailable' | 'database_unavailable' | 'audit_failed' | 'unexpected' | null;
  /** Bytes removed (measured just before deleting); 0 when nothing was deleted. */
  bytes: number;
  /** Deleted records whose stored objects could not all be removed now: they are orphans for the next scan. */
  objectsRemaining: number;
}
export interface CleanupResult {
  finishedAt: string;
  stopped: 'database_unavailable' | 'storage_unavailable' | 'unexpected' | null;
  summary: { requested: number; deleted: number; protected: number; gone: number; changed: number; failed: number; notAttempted: number; bytes: number };
  results: CleanupItemResult[];
}

export class IntegrityError extends Error {
  readonly code: 'validation_failed' | 'busy';
  readonly fields: FieldError[] | undefined;
  constructor(code: 'validation_failed' | 'busy', fields?: FieldError[]) {
    super(code === 'busy' ? 'Another integrity scan or cleanup is running' : 'The submitted data is not valid');
    this.name = 'IntegrityError';
    this.code = code;
    this.fields = fields;
  }
}

export interface IntegrityApi {
  scan(actor: Actor | null, query: unknown): Promise<ScanResult>;
  cleanup(actor: Actor | null, body: unknown, ctx?: { requestId?: string | undefined }): Promise<CleanupResult>;
}

export interface IntegrityLogger {
  info(obj: Record<string, unknown>, msg?: string): void;
  warn(obj: Record<string, unknown>, msg?: string): void;
}

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
const knownKeys = (o: Record<string, unknown>, allowed: readonly string[], errors: FieldError[], prefix = ''): void => {
  for (const k of Object.keys(o)) if (!allowed.includes(k)) errors.push({ field: /^[A-Za-z0-9_]{1,40}$/.test(k) ? `${prefix}${k}` : 'unknown', code: 'unknown_field' });
};

export function parseScanQuery(query: unknown): { ok: true; value: { scope: 'all' | 'assets' | 'objects'; afterId: string | null; shard: string } } | { ok: false; errors: FieldError[] } {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  knownKeys(q, ['scope', 'after', 'shard'], errors);
  let scope: 'all' | 'assets' | 'objects' = 'all';
  const s = q['scope'];
  if (s !== undefined) {
    if (typeof s !== 'string') errors.push({ field: 'scope', code: 'invalid_type' });
    else if (s !== 'all' && s !== 'assets' && s !== 'objects') errors.push({ field: 'scope', code: 'invalid_format' });
    else scope = s;
  }
  let afterId: string | null = null;
  const a = q['after'];
  if (a !== undefined) {
    if (typeof a !== 'string') errors.push({ field: 'after', code: 'invalid_type' });
    else if (!UUID.test(a)) errors.push({ field: 'after', code: 'invalid_format' });
    else afterId = a;
  }
  let shard = '';
  const h = q['shard'];
  if (h !== undefined) {
    if (typeof h !== 'string') errors.push({ field: 'shard', code: 'invalid_type' });
    else if (!SHARD.test(h)) errors.push({ field: 'shard', code: 'invalid_format' });
    else shard = h;
  }
  if (afterId !== null && scope === 'objects') errors.push({ field: 'after', code: 'invalid_format' });
  if (shard !== '' && scope === 'assets') errors.push({ field: 'shard', code: 'invalid_format' });
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { scope, afterId, shard } };
}

export interface CleanupRequestItem {
  type: 'asset' | 'object';
  id: string;
}
export function parseCleanupBody(body: unknown): { ok: true; value: CleanupRequestItem[] } | { ok: false; errors: FieldError[] } {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  knownKeys(body, ['confirm', 'items'], errors);
  // Explicit confirmation: the literal boolean true. Nothing else (a truthy string, 1, "yes") counts.
  if (body['confirm'] === undefined) errors.push({ field: 'confirm', code: 'required' });
  else if (body['confirm'] !== true) errors.push({ field: 'confirm', code: 'invalid_format' });
  const raw = body['items'];
  const items: CleanupRequestItem[] = [];
  if (raw === undefined) errors.push({ field: 'items', code: 'required' });
  else if (!Array.isArray(raw)) errors.push({ field: 'items', code: 'invalid_type' });
  else if (raw.length === 0) errors.push({ field: 'items', code: 'too_short' });
  else if (raw.length > CLEANUP_ITEMS_MAX) errors.push({ field: 'items', code: 'too_long' });
  else {
    const seen = new Set<string>();
    raw.forEach((it: unknown, i) => {
      const f = `items.${i}`;
      if (!isPlainObject(it)) return void errors.push({ field: f, code: 'invalid_type' });
      knownKeys(it, ['type', 'id'], errors, `${f}.`);
      const type = it['type'];
      const id = it['id'];
      if (type !== 'asset' && type !== 'object') return void errors.push({ field: `${f}.type`, code: 'invalid_format' });
      if (typeof id !== 'string') return void errors.push({ field: `${f}.id`, code: 'invalid_type' });
      if (!(type === 'asset' ? UUID.test(id) : OBJECT_REF.test(id))) return void errors.push({ field: `${f}.id`, code: 'invalid_format' });
      if (seen.has(`${type}:${id}`)) return void errors.push({ field: `${f}.id`, code: 'invalid_format' });
      seen.add(`${type}:${id}`);
      items.push({ type, id });
    });
  }
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: items };
}

/** `<area>.<kind>.<uuid>` for an object of a generated shape. */
export const objectRef = (info: ObjectKeyInfo, key: string): string => `${info.area}.${info.kind}.${key.slice(key.lastIndexOf('/') + 1).replace(/\.webp$/, '')}`;
/** The object key of a reference, or null if it does not spell exactly a generated shape. Never accepts a path. */
export function keyOfObjectRef(ref: string): { key: string; info: ObjectKeyInfo } | null {
  const m = OBJECT_REF.exec(ref);
  if (!m) return null;
  const key = m[1] === 'incoming' ? `incoming/${m[2]}/${m[3]}` : `${m[1]}/${m[2]}/${m[3]}.webp`;
  const info = classifyObjectKey(key);
  return info ? { key, info } : null;
}

class Stop extends Error {
  readonly code: 'database_unavailable' | 'storage_unavailable' | 'unexpected';
  constructor(code: Stop['code']) {
    super(code);
    this.code = code;
  }
}

const hours = (seconds: number): number => Math.max(0, Math.floor(seconds / 3600));
const PRIORITY: Record<IntegrityCategory, number> = { corrupt: 0, missing: 1, unverified: 2, orphaned: 3 };

export interface IntegrityLimits {
  batchSize: number;
  maxBatches: number;
  maxItems: number;
}
export function createAssetIntegrityService(deps: {
  repo: IntegrityRepository;
  storage: ListableStorage;
  now?: () => Date;
  logger?: IntegrityLogger;
  /** Test seams: the retry back-off of the audit's reads, and smaller scan bounds. Production uses the defaults above. */
  sleep?: (ms: number) => Promise<void>;
  limits?: Partial<IntegrityLimits>;
}): IntegrityApi {
  const { repo, storage, logger } = deps;
  const now = deps.now ?? (() => new Date());
  const graceSeconds = INTEGRITY_GRACE_HOURS * 3600;
  let busy = false;
  const exclusive = async <T>(fn: () => Promise<T>): Promise<T> => {
    if (busy) throw new IntegrityError('busy');
    busy = true;
    try {
      return await fn();
    } finally {
      busy = false;
    }
  };
  const db = async <T>(fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (e) {
      throw new Stop(e instanceof DbError ? 'database_unavailable' : 'unexpected');
    }
  };
  const store = async <T>(fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (e) {
      throw new Stop(e instanceof StorageError ? 'storage_unavailable' : 'unexpected');
    }
  };

  /** The listed entry of exactly this key (size and last-modified time), or null if there is none. */
  async function stat(key: string): Promise<{ size: number; lastModified: Date } | null> {
    const page = await store(() => storage.list(key, { maxKeys: 5 }));
    const hit = page.objects.find((o) => o.key === key);
    return hit ? { size: hit.size, lastModified: hit.lastModified } : null;
  }

  return {
    async scan(actor, rawQuery) {
      authorize(actor, 'read', assetIntegrityResource()); // non-admins: 404 before the query is even parsed
      const parsed = parseScanQuery(rawQuery);
      if (!parsed.ok) throw new IntegrityError('validation_failed', parsed.errors);
      const { scope, afterId, shard } = parsed.value;
      return exclusive(async () => {
        const items: IntegrityItem[] = [];
        const summary: ScanSummary = { scannedAssets: 0, scannedObjects: 0, corrupt: 0, missing: 0, orphaned: 0, unverified: 0, referencedProblems: 0, deletable: 0, protected: 0, recoverableBytes: 0 };
        let nextAfter: string | null = null;
        let assetsComplete = scope === 'objects';

        const add = (it: IntegrityItem): void => {
          summary[it.category]++;
          if (it.referenced) summary.referencedProblems++;
          if (it.deletable) {
            summary.deletable++;
            summary.recoverableBytes += it.sizeBytes ?? 0;
          } else summary.protected++;
          items.push(it);
        };
        const onAsset = (f: AssetFinding): void => {
          if (f.verdict === 'healthy' && !f.unlinked) return; // healthy and in use: nothing to report
          const category: IntegrityCategory = f.verdict === 'missing' ? 'missing' : f.verdict === 'corrupt' ? 'corrupt' : f.verdict === 'failed' ? 'unverified' : 'orphaned';
          const reason: ItemReason = f.verdict === 'corrupt' ? (f.corruptReason ?? 'unreadable') : f.verdict === 'missing' ? 'object_missing' : f.verdict === 'failed' ? 'unverifiable' : 'unlinked_record';
          const protectedReason: ProtectedReason | null = f.referenced ? 'referenced' : f.verdict === 'failed' ? 'unverified' : f.notEligible;
          const deletable = !f.referenced && f.unlinked && f.eligible && f.verdict !== 'failed';
          add({
            ref: { type: 'asset', id: f.id }, category, reason, kind: f.kind, hasRecord: true, referenced: f.referenced,
            sizeBytes: f.mainSize === null && f.thumbSize === null ? null : (f.mainSize ?? 0) + (f.thumbSize ?? 0),
            ageHours: hours(f.ageSeconds), deletable, protectedReason: deletable ? null : protectedReason,
          });
        };
        const onOrphan = (f: OrphanFinding): void => {
          add({
            ref: { type: 'object', id: objectRef(f.info, f.key) }, category: 'orphaned', reason: 'no_record', kind: f.info.kind, hasRecord: false, referenced: false,
            sizeBytes: f.size, ageHours: hours((now().getTime() - f.lastModified.getTime()) / 1000), deletable: true, protectedReason: null,
          });
        };

        const lim = { ...SCAN_LIMITS[scope], ...deps.limits };
        const maxItems = deps.limits?.maxItems ?? SCAN_ITEMS_MAX;
        const report = await runAssetAudit(
          {
            repo, storage, now, ...(logger ? { logger } : {}), ...(deps.sleep ? { sleep: deps.sleep } : {}),
            observer: { afterId, onAsset, onOrphan, onAssetsEnd: (i) => { assetsComplete = i.complete; nextAfter = i.complete ? null : i.lastId; } },
          },
          { dryRun: true, batchSize: lim.batchSize, maxBatches: lim.maxBatches, graceHours: INTEGRITY_GRACE_HOURS, shard, assets: scope !== 'objects', orphans: scope !== 'assets' },
        );
        summary.scannedAssets = report.assets?.scanned ?? 0;
        summary.scannedObjects = report.orphans?.scanned ?? 0;
        // Unverified assets are counted by the audit as `failed` and were added above as items; a scan error leaves the rest unknown.
        items.sort((a, b) => PRIORITY[a.category] - PRIORITY[b.category] || (a.ref.id < b.ref.id ? -1 : 1));
        const truncated = items.length > maxItems;
        const complete = report.error === null && assetsComplete && (report.orphans === null || report.orphans.complete);
        logger?.info({ event: 'asset_integrity.scan', scope, complete, error: report.error, summary });
        return {
          scannedAt: now().toISOString(), scope, graceHours: INTEGRITY_GRACE_HOURS, complete, nextAfter, error: report.error, summary,
          items: truncated ? items.slice(0, maxItems) : items, truncated,
        };
      });
    },

    async cleanup(actor, rawBody, ctx = {}) {
      authorize(actor, 'delete', assetIntegrityResource());
      const parsed = parseCleanupBody(rawBody);
      if (!parsed.ok) throw new IntegrityError('validation_failed', parsed.errors);
      const admin = actor!; // authorize() above refuses a missing actor
      const actorId = admin.id;
      return exclusive(async () => {
        const results: CleanupItemResult[] = [];
        let stopped: CleanupResult['stopped'] = null;
        const requestId = ctx.requestId;
        const audit = (action: 'asset_integrity.delete_asset' | 'asset_integrity.delete_object' | 'asset_integrity.delete_failed' | 'asset_integrity.cleanup', entityType: 'asset' | 'asset_object' | 'asset_integrity', entityId: string, afterData: Record<string, number>) =>
          ({ action, actorUserId: actorId, actorRole: 'admin', entityType, entityId, afterData, requestId }) as const;

        async function cleanAsset(id: string): Promise<CleanupItemResult> {
          const ref = { type: 'asset' as const, id };
          const res = (outcome: CleanupOutcome, reason: CleanupItemResult['reason'] = null, bytes = 0, objectsRemaining = 0): CleanupItemResult => ({ ref, outcome, reason, bytes, objectsRemaining });
          const row = await db(() => repo.getAsset(id));
          if (!row) return res('gone');
          if (row.status !== 'ready') return res('protected', 'not_ready'); // pending = uploading/processing, rejected = being cleaned by the job
          if (row.referenced) return res('protected', 'referenced');
          if (row.readyAgeSeconds === null || !(row.readyAgeSeconds > graceSeconds)) return res('protected', 'within_grace');
          const keys = row.storageKey === null ? null : classifyObjectKey(row.storageKey);
          if (!keys || keys.area !== 'processed' || keys.kind !== row.kind || row.thumbKey !== keys.thumb) return res('protected', 'unrecognized_key');
          // Measured for the report and the audit row only; a failed measurement never blocks (and never widens) the deletion.
          let bytes = 0;
          for (const k of [keys.main, keys.thumb]) {
            try {
              bytes += (await stat(k))?.size ?? 0;
            } catch {
              /* size unknown */
            }
          }
          const removed = await db(() => repo.deleteUnlinkedAudited({ id, storageKey: row.storageKey, thumbKey: row.thumbKey, graceSeconds, audit: audit('asset_integrity.delete_asset', 'asset', id, { bytes }) }));
          if (!removed) return res('changed'); // attached, changed or too young at the last moment: nothing was written
          let remaining = 0;
          for (const k of [keys.original, keys.main, keys.thumb]) {
            try {
              await storage.delete(k);
            } catch {
              remaining++;
            }
          }
          if (remaining > 0) {
            // The record is already gone, so these objects are orphans for the next scan. Best-effort trail; never blocks the result.
            await repo.recordAudit(audit('asset_integrity.delete_failed', 'asset', id, { objects: remaining })).catch(() => {});
          }
          return res('deleted', null, bytes, remaining);
        }

        async function cleanObject(refId: string): Promise<CleanupItemResult> {
          const ref = { type: 'object' as const, id: refId };
          const res = (outcome: CleanupOutcome, reason: CleanupItemResult['reason'] = null, bytes = 0): CleanupItemResult => ({ ref, outcome, reason, bytes, objectsRemaining: 0 });
          const k = keyOfObjectRef(refId);
          if (!k) return res('protected', 'invalid_reference');
          const meta = await stat(k.key);
          if (!meta) return res('gone');
          if (!(meta.lastModified.getTime() < now().getTime() - graceSeconds * 1000)) return res('protected', 'within_grace');
          const candidates = referenceCandidates(k.key, k.info);
          if ((await db(() => repo.findReferencedKeys(candidates))).size > 0) return res('protected', 'referenced');
          if ((await db(() => repo.findReferencedKeys(candidates))).size > 0) return res('protected', 'referenced'); // second, independent lookup right before the delete
          try {
            await repo.recordAudit(audit('asset_integrity.delete_object', 'asset_object', refId, { bytes: meta.size })); // the trail comes BEFORE the delete
          } catch (e) {
            throw new Stop(e instanceof DbError ? 'database_unavailable' : 'unexpected');
          }
          try {
            await storage.delete(k.key);
          } catch (e) {
            await repo.recordAudit(audit('asset_integrity.delete_failed', 'asset_object', refId, { bytes: meta.size })).catch(() => {});
            throw new Stop(e instanceof StorageError ? 'storage_unavailable' : 'unexpected');
          }
          return res('deleted', null, meta.size);
        }

        for (const it of parsed.value) {
          if (stopped !== null) {
            results.push({ ref: { type: it.type, id: it.id }, outcome: 'not_attempted', reason: null, bytes: 0, objectsRemaining: 0 });
            continue;
          }
          try {
            results.push(it.type === 'asset' ? await cleanAsset(it.id) : await cleanObject(it.id));
          } catch (e) {
            stopped = e instanceof Stop ? e.code : 'unexpected';
            results.push({ ref: { type: it.type, id: it.id }, outcome: 'failed', reason: stopped, bytes: 0, objectsRemaining: 0 });
          }
        }
        const count = (o: CleanupOutcome) => results.filter((r) => r.outcome === o).length;
        const summary = {
          requested: results.length, deleted: count('deleted'), protected: count('protected'), gone: count('gone'), changed: count('changed'), failed: count('failed'), notAttempted: count('not_attempted'),
          bytes: results.reduce((n, r) => n + r.bytes, 0),
        };
        // One summary row per run (best effort: the per-item rows above are the authoritative trail).
        await repo.recordAudit(audit('asset_integrity.cleanup', 'asset_integrity', requestId ?? '0', { requested: summary.requested, deleted: summary.deleted, protected: summary.protected, failed: summary.failed, bytes: summary.bytes })).catch(() => {});
        logger?.info({ event: 'asset_integrity.cleanup', stopped, summary });
        return { finishedAt: now().toISOString(), stopped, summary, results };
      });
    },
  };
}

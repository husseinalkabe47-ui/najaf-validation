// PostgreSQL access for the administrators' asset INTEGRITY SCAN and CLEANUP (Phase 11.7.2-K), on the existing tables. No migration.
//  - The scan reuses the audit repository of Phase 11.6.6 unchanged (listReady, findReferencedKeys).
//  - getAsset: ONE asset by id with the facts the cleanup re-validates right before deleting (status, keys, whether a car image or a
//    showroom cover references it, and its age since it became ready, by the DATABASE clock). Same statement shape as listReady.
//  - deleteUnlinkedAudited: the same locked compare-and-swap as audit-repository.ts deleteUnlinked (lock the row FOR UPDATE, then a
//    NEW conditional DELETE that re-checks status, keys, grace period and "referenced by nothing"), PLUS the audit row, written in
//    the SAME transaction: the record is deleted only if its audit row was written, and the other way round. Storage is touched
//    only after this transaction commits.
//  - recordAudit: one audit row in its own transaction (for the events that have no database change, e.g. an orphaned object).
import type { Db } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditEvent } from '../auth/repository.ts';
import { LOCK_READY_SQL, buildDeleteUnlinked, createPgAuditRepository as createPgAssetAuditRepository } from './audit-repository.ts';
import type { AuditRepository } from './audit-repository.ts';

export interface IntegrityAssetRow {
  id: string;
  kind: string;
  status: string;
  /** Internal: used to read/delete the objects; never returned to a client. */
  storageKey: string | null;
  thumbKey: string | null;
  referenced: boolean;
  /** Seconds since the asset became ready (database clock); null when it never became ready. */
  readyAgeSeconds: number | null;
}

export interface IntegrityRepository extends AuditRepository {
  getAsset(id: string): Promise<IntegrityAssetRow | null>;
  /** true = the record was deleted and its audit row written; false = the row changed/was attached/is too young (nothing written). */
  deleteUnlinkedAudited(input: { id: string; storageKey: string | null; thumbKey: string | null; graceSeconds: number; audit: AuditEvent }): Promise<boolean>;
  recordAudit(event: AuditEvent): Promise<void>;
}

export const GET_ASSET_SQL = `SELECT a.id, a.kind, a.status, a.storage_key, a.thumb_key,
              (EXISTS (SELECT 1 FROM car_images ci WHERE ci.asset_id = a.id)
               OR EXISTS (SELECT 1 FROM showrooms s WHERE s.cover_asset_id = a.id)) AS referenced,
              CASE WHEN a.ready_at IS NULL THEN NULL ELSE EXTRACT(EPOCH FROM (now() - a.ready_at))::double precision END AS age_seconds
         FROM assets a
        WHERE a.id = $1::uuid`;

interface AssetSql {
  id: string;
  kind: string;
  status: string;
  storage_key: string | null;
  thumb_key: string | null;
  referenced: boolean;
  age_seconds: number | string | null;
}

export function createPgIntegrityRepository(db: Db): IntegrityRepository {
  const base = createPgAssetAuditRepository(db);
  return {
    listReady: base.listReady,
    findReferencedKeys: base.findReferencedKeys,
    deleteUnlinked: base.deleteUnlinked,
    async getAsset(id) {
      const r = (await db.query<AssetSql>(GET_ASSET_SQL, [id])).rows[0];
      if (!r) return null;
      return {
        id: String(r.id),
        kind: r.kind,
        status: r.status,
        storageKey: r.storage_key,
        thumbKey: r.thumb_key,
        referenced: r.referenced !== false, // anything but a definite false counts as referenced (never delete on doubt)
        readyAgeSeconds: r.age_seconds === null ? null : Number(r.age_seconds),
      };
    },
    async deleteUnlinkedAudited(input) {
      const s = buildDeleteUnlinked(input);
      return db.tx(async (t) => {
        await t.query(`SET LOCAL lock_timeout = '3s'`);
        if ((await t.query(LOCK_READY_SQL, [input.id])).rows.length !== 1) return false;
        if ((await t.query(s.text, s.values)).rows.length !== 1) return false;
        await createPgAuditRepository(t).record(input.audit);
        return true;
      });
    },
    async recordAudit(event) {
      await db.tx((t) => createPgAuditRepository(t).record(event));
    },
  };
}

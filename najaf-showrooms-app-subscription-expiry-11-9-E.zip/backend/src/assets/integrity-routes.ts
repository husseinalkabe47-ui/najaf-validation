// HTTP contract for the administrators' asset integrity scan and confirmed cleanup (Phase 11.7.2-K). Thin: decisions live in
// assets/integrity.ts and src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify.
//
//   GET  /v1/admin/asset-integrity/scan?scope=all|assets|objects&after=<asset id>&shard=<0-2 hex>
//        Bearer (admin) -> 200 {scannedAt, scope, graceHours, complete, nextAfter, error, summary, items, truncated}     READ ONLY
//   POST /v1/admin/asset-integrity/cleanup    Bearer (admin), JSON {confirm: true, items: [{type: 'asset'|'object', id}]} (1..50)
//        -> 200 {finishedAt, stopped, summary, results: [{ref, outcome, reason, bytes, objectsRemaining}]}
//
// Errors: 401 no/invalid token; 404 for any non-administrator (identical to an unknown route's answer for them, decided before the
// input is parsed); 400 invalid input (field names and codes only); 409 busy (another scan or cleanup is running); 415 non-JSON body;
// 429 rate limited. Storage keys, buckets and endpoints never appear in a response.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { IntegrityError } from './integrity.ts';
import type { IntegrityApi } from './integrity.ts';

/** PROPOSED, per client address and per instance. A scan reads many stored objects, so it is limited much harder than a plain read. */
export const INTEGRITY_RATE_LIMITS = {
  scan: { limit: 20, windowSeconds: 10 * 60 },
  cleanup: { limit: 30, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type IntegrityRateLimitedRoute = keyof typeof INTEGRITY_RATE_LIMITS;

export function toIntegrityHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof IntegrityError) {
    if (e.code === 'busy') return { status: 409, code: e.code, message: e.message };
    return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateHook(limiter: RateLimiter, route: IntegrityRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`assetIntegrity.${route}:${request.ip}`, INTEGRITY_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'asset_integrity.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

export function registerAssetIntegrityRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; integrity: IntegrityApi; rateLimiter?: RateLimiter }): void {
  const { auth, integrity, rateLimiter } = deps;
  const limited = (route: IntegrityRateLimitedRoute): Hook[] => (rateLimiter ? [rateHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toIntegrityHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  app.get('/v1/admin/asset-integrity/scan', { onRequest: limited('scan') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await integrity.scan(actor, request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/admin/asset-integrity/cleanup', { bodyLimit: 16 * 1024, onRequest: [...limited('cleanup'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await integrity.cleanup(actor, request.body, { requestId: request.id }));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

// PostgreSQL access for the administrators' subscription plan prices (Phase 11.9-C). Rules:
//  - only the plans that have a duration (3, 6 and 12 months; migration 0014) are visible here: the free plan and any other plan are
//    never listed or changed by this module;
//  - every statement is parameterized and names its columns; the ONLY write is `UPDATE subscription_plans SET price` (currency,
//    entitlements, is_active, duration and code are never touched);
//  - the change and its audit row are written in ONE transaction, after locking the plan row, so the old price recorded is the
//    price that was really replaced (two concurrent changes cannot both claim the same old price).
import type { Db } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditEvent } from '../auth/repository.ts';

export interface PlanRow {
  id: string;
  code: string;
  name: string;
  durationMonths: number;
  price: number;
  currency: string;
  isActive: boolean;
  updatedAt: Date;
}
export type PriceChange = { kind: 'not_found' } | { kind: 'unchanged'; plan: PlanRow } | { kind: 'changed'; plan: PlanRow; oldPrice: number };

export interface SubscriptionPlansRepository {
  /** The duration plans, shortest first. */
  list(): Promise<PlanRow[]>;
  /** Sets the price of the duration plan `code`; `audit` receives the old price and is written in the same transaction (only when the price really changes). */
  setPrice(input: { code: string; price: number; audit: (oldPrice: number, planId: string) => AuditEvent }): Promise<PriceChange>;
}

interface PlanSql {
  id: string | number;
  code: string;
  name: string;
  duration_months: number;
  price: string;
  currency: string;
  is_active: boolean;
  updated_at: Date;
}
const COLUMNS = 'id, code, name, duration_months, price, currency, is_active, updated_at';
const toPlan = (r: PlanSql): PlanRow => ({
  id: String(r.id),
  code: r.code,
  name: r.name,
  durationMonths: r.duration_months,
  price: Number(r.price),
  currency: r.currency,
  isActive: r.is_active,
  updatedAt: r.updated_at,
});

export function createPgSubscriptionPlansRepository(db: Db): SubscriptionPlansRepository {
  return {
    async list() {
      const r = await db.query<PlanSql>(`SELECT ${COLUMNS} FROM subscription_plans WHERE duration_months IS NOT NULL ORDER BY duration_months`);
      return r.rows.map(toPlan);
    },
    async setPrice({ code, price, audit }) {
      return db.tx(async (t) => {
        await t.query(`SET LOCAL lock_timeout = '3s'`);
        const locked = await t.query<PlanSql>(`SELECT ${COLUMNS} FROM subscription_plans WHERE code = $1 AND duration_months IS NOT NULL FOR UPDATE`, [code]);
        const row = locked.rows[0];
        if (!row) return { kind: 'not_found' } as const;
        const before = toPlan(row);
        if (before.price === price) return { kind: 'unchanged', plan: before } as const;
        const updated = await t.query<PlanSql>(`UPDATE subscription_plans SET price = $2 WHERE id = $1 RETURNING ${COLUMNS}`, [row.id, price]);
        await createPgAuditRepository(t).record(audit(before.price, before.id));
        return { kind: 'changed', plan: toPlan(updated.rows[0]!), oldPrice: before.price } as const;
      });
    },
  };
}

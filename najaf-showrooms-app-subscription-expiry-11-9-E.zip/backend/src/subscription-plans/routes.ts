// HTTP contract for the administrators' subscription plan prices (Phase 11.9-C). Thin: decisions live in
// subscription-plans/service.ts and src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify.
//
//   GET /v1/admin/subscription-plans                 Bearer (admin) -> 200 {plans: [{code, name, durationMonths, price, currency, isActive, updatedAt}]}
//   PUT /v1/admin/subscription-plans/:code/price     Bearer (admin), JSON {price: <integer IQD>} -> 200 {plan, changed}
//        :code is plan_3m, plan_6m or plan_12m. Currency is always IQD and cannot be sent.
//
// Errors: 401 no/invalid token; 404 for any non-administrator and for an unknown plan code (identical), decided before the input is
// parsed; 400 invalid input (field names and codes only); 415 non-JSON body; 429 rate limited.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { SubscriptionPlansError } from './service.ts';
import type { SubscriptionPlansApi } from './service.ts';

/** PROPOSED, per client address and per instance. */
export const SUBSCRIPTION_PLANS_RATE_LIMITS = {
  read: { limit: 240, windowSeconds: 10 * 60 },
  write: { limit: 30, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type SubscriptionPlansRateLimitedRoute = keyof typeof SUBSCRIPTION_PLANS_RATE_LIMITS;

export function toSubscriptionPlansHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof SubscriptionPlansError) return { status: 400, code: e.code, message: e.message, fields: e.fields };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateHook(limiter: RateLimiter, route: SubscriptionPlansRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`subscriptionPlans.${route}:${request.ip}`, SUBSCRIPTION_PLANS_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'subscription_plans.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

export function registerSubscriptionPlansRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; subscriptionPlans: SubscriptionPlansApi; rateLimiter?: RateLimiter }): void {
  const { auth, subscriptionPlans, rateLimiter } = deps;
  const limited = (route: SubscriptionPlansRateLimitedRoute): Hook[] => (rateLimiter ? [rateHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toSubscriptionPlansHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  app.get('/v1/admin/subscription-plans', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await subscriptionPlans.listPlans(actor));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.put('/v1/admin/subscription-plans/:code/price', { bodyLimit: 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await subscriptionPlans.setPrice(actor, (request.params as Record<string, unknown> | undefined)?.['code'], request.body, { requestId: request.id }));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

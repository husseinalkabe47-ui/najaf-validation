// The administrators' subscription plan prices (Phase 11.9-C). The ONLY thing an administrator can change is the price of the
// 3-, 6- or 12-month plan (migration 0014).
//
// Decisions (each is covered by tests):
//  - WHO: an administrator only, through the dedicated 'subscription_plan' resource of the existing policy. Everyone else (member,
//    dealer, no actor) gets 404 BEFORE the input is parsed, exactly as the other admin routes.
//  - WHAT: {price} and nothing else. The currency is always IQD and cannot be sent (an unknown field is refused); the plan is named
//    by its code in the path and only the duration plans exist here (the free plan answers 404).
//  - PRICE: a JSON integer (IQD has no fractions) from 0 to MAX_PLAN_PRICE. Strings, decimals, negatives, NaN, null and booleans
//    are refused with field names and codes only.
//  - AUDIT: a successful change writes one audit row 'subscription_plan.price_update' (actor, plan id as the entity, oldPrice and
//    newPrice in afterData, the database's own timestamp) through the single audit writer, in the SAME transaction as the update.
//    Setting the price a plan already has changes nothing and writes nothing.
//  - Nothing here creates, renews, expires or enforces a subscription, and nothing reads a plan to decide access.
import { authorize, notFound, subscriptionPlanResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError } from '../auth/validation.ts';
import type { PlanRow, SubscriptionPlansRepository } from './repository.ts';

/** numeric(14,0) holds up to 99,999,999,999,999; the API accepts far less than that, and always a safe integer. */
export const MAX_PLAN_PRICE = 9_999_999_999_999;
export const PLAN_CODES = ['plan_3m', 'plan_6m', 'plan_12m'] as const;

export class SubscriptionPlansError extends Error {
  readonly code = 'validation_failed' as const;
  readonly fields: FieldError[];
  constructor(fields: FieldError[]) {
    super('The submitted data is not valid');
    this.name = 'SubscriptionPlansError';
    this.fields = fields;
  }
}

export interface PlanView {
  code: string;
  name: string;
  durationMonths: number;
  price: number;
  currency: string;
  isActive: boolean;
  updatedAt: string;
}
export const toPlanView = (r: PlanRow): PlanView => ({
  code: r.code,
  name: r.name,
  durationMonths: r.durationMonths,
  price: r.price,
  currency: r.currency,
  isActive: r.isActive,
  updatedAt: r.updatedAt.toISOString(),
});

export interface SubscriptionPlansApi {
  listPlans(actor: Actor | null): Promise<{ plans: PlanView[] }>;
  setPrice(actor: Actor | null, rawCode: unknown, body: unknown, ctx?: { requestId?: string | undefined }): Promise<{ plan: PlanView; changed: boolean }>;
}

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

export function parsePriceBody(body: unknown): { ok: true; value: number } | { ok: false; errors: FieldError[] } {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  for (const key of Object.keys(body)) if (key !== 'price') errors.push({ field: /^[A-Za-z0-9_]{1,40}$/.test(key) ? key : 'unknown', code: 'unknown_field' });
  const p = body['price'];
  if (p === undefined) errors.push({ field: 'price', code: 'required' });
  else if (typeof p !== 'number' || !Number.isFinite(p)) errors.push({ field: 'price', code: 'invalid_type' });
  else if (!Number.isSafeInteger(p) || p < 0 || p > MAX_PLAN_PRICE) errors.push({ field: 'price', code: 'invalid_format' });
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: p as number };
}

export function createSubscriptionPlansService(deps: { repo: SubscriptionPlansRepository }): SubscriptionPlansApi {
  const { repo } = deps;
  return {
    async listPlans(actor) {
      authorize(actor, 'read', subscriptionPlanResource());
      return { plans: (await repo.list()).map(toPlanView) };
    },

    async setPrice(actor, rawCode, body, ctx = {}) {
      authorize(actor, 'update', subscriptionPlanResource());
      if (!actor) throw notFound(); // unreachable: authorize refused a null actor
      const code = typeof rawCode === 'string' && (PLAN_CODES as readonly string[]).includes(rawCode) ? rawCode : null;
      if (code === null) throw notFound();
      const parsed = parsePriceBody(body);
      if (!parsed.ok) throw new SubscriptionPlansError(parsed.errors);
      const newPrice = parsed.value;
      const out = await repo.setPrice({
        code,
        price: newPrice,
        audit: (oldPrice, planId) => ({
          action: 'subscription_plan.price_update',
          actorUserId: actor.id,
          actorRole: 'admin',
          entityType: 'subscription_plan',
          entityId: planId,
          afterData: { oldPrice, newPrice },
          requestId: ctx.requestId,
        }),
      });
      if (out.kind === 'not_found') throw notFound();
      return { plan: toPlanView(out.plan), changed: out.kind === 'changed' };
    },
  };
}

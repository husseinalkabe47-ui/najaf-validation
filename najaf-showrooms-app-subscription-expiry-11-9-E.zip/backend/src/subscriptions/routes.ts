// HTTP contract for the administrators' manual subscription activation / renewal and payment recording (Phase 11.9-D). Thin: decisions
// live in subscriptions/service.ts and src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify.
//
//   POST /v1/admin/subscriptions   Bearer (admin), JSON {showroomId, planCode: plan_3m|plan_6m|plan_12m, method: cash|bank_transfer|mobile_wallet|other,
//                                  reference, amount: <whole IQD>, paidAt: <ISO date or date-time>}
//        -> 201 {outcome: activated|renewed|renewed_after_expiry, subscription, payment}
//   GET  /v1/admin/showrooms/:id/subscriptions   Bearer (admin) -> 200 {subscriptions: [{..., payments: [...]}]}   READ ONLY (history, newest first)
//
// Errors: 401 no/invalid token; 404 for any non-administrator, an unknown showroom or plan (identical), decided before the body is parsed;
// 400 invalid input (field names and codes only); 409 duplicate_payment (the same method + reference was already recorded) or plan_mismatch
// (a live subscription of another plan is still running); 415 non-JSON body; 429 rate limited.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { SubscriptionsError } from './service.ts';
import type { SubscriptionsApi } from './service.ts';

/** PROPOSED, per client address and per instance. */
export const SUBSCRIPTIONS_RATE_LIMITS = {
  read: { limit: 240, windowSeconds: 10 * 60 },
  write: { limit: 60, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type SubscriptionsRateLimitedRoute = keyof typeof SUBSCRIPTIONS_RATE_LIMITS;

export function toSubscriptionsHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof SubscriptionsError) {
    if (e.code === 'validation_failed') return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    return { status: 409, code: e.code, message: e.message };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateHook(limiter: RateLimiter, route: SubscriptionsRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`subscriptions.${route}:${request.ip}`, SUBSCRIPTIONS_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'subscriptions.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

export function registerSubscriptionsRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; subscriptions: SubscriptionsApi; rateLimiter?: RateLimiter }): void {
  const { auth, subscriptions, rateLimiter } = deps;
  const limited = (route: SubscriptionsRateLimitedRoute): Hook[] => (rateLimiter ? [rateHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toSubscriptionsHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  app.post('/v1/admin/subscriptions', { bodyLimit: 4 * 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(201).send(await subscriptions.grant(actor, request.body, { requestId: request.id }));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/admin/showrooms/:id/subscriptions', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await subscriptions.history(actor, (request.params as Record<string, unknown> | undefined)?.['id']));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

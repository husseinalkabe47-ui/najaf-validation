// Subscription expiry storage (Phase 11.9-E). The ONLY statements the expiry job runs. Rules:
//  - "expired" means exactly what the database's entitlement rule means: a live subscription (trialing, active, past_due) is in force
//    while current_period_end > now() (entitlements_for_showroom, migration 0011), so it has expired when current_period_end <= now().
//    A subscription that ends exactly now is expired, as in the manual renewal rules (subscriptions/service.ts planGrant).
//  - the clock is the DATABASE's now() (the entitlement function's own clock); `at` exists only so tests can fix the instant.
//  - each batch is ONE transaction: the rows are picked and locked (FOR UPDATE SKIP LOCKED), moved to 'expired' by a compare-and-swap
//    that re-checks status AND end date, and each row that REALLY changed gets its audit row through the single audit writer in that
//    same transaction. A second or concurrent run finds nothing left to do, so no duplicate transition and no duplicate audit row.
//  - nothing is inserted into subscriptions or payments and nothing is deleted: history stays; only status 'expired' is set.
//  - lock order: this job only locks subscription rows (never the showroom row), and a manual grant locks the showroom first and then
//    its subscription, so the two cannot deadlock; a grant holding the row makes the batch skip it, and a grant that renewed it first
//    moves its end into the future so the compare-and-swap leaves it alone.
import { createPgAuditRepository } from '../auth/repository.ts';
import type { Db } from '../db.ts';

export interface SubscriptionExpiryRepository {
  /** How many live subscriptions are past their end (the dry-run number). */
  countExpirable(at?: Date): Promise<number>;
  /** Expires up to `limit` of them, writing one audit row per subscription really changed. Returns how many. */
  expireBatch(limit: number, at?: Date): Promise<number>;
}

const LIVE = `status IN ('trialing', 'active', 'past_due')`;
const DUE = `current_period_end <= COALESCE($1::timestamptz, now())`;

export const COUNT_EXPIRABLE_SQL = `SELECT count(*)::int AS n FROM subscriptions WHERE ${LIVE} AND ${DUE}`;
export const EXPIRE_BATCH_SQL = `WITH c AS (
             SELECT id FROM subscriptions WHERE ${LIVE} AND ${DUE} ORDER BY current_period_end, id LIMIT $2::int FOR UPDATE SKIP LOCKED
           )
           UPDATE subscriptions s SET status = 'expired'
             FROM c
            WHERE s.id = c.id AND s.${LIVE} AND s.current_period_end <= COALESCE($1::timestamptz, now())
        RETURNING s.id, s.showroom_id, s.plan_id, s.current_period_end`;

export function createPgSubscriptionExpiryRepository(db: Db): SubscriptionExpiryRepository {
  return {
    async countExpirable(at) {
      return Number((await db.query<{ n: number }>(COUNT_EXPIRABLE_SQL, [at ?? null])).rows[0]?.n ?? 0);
    },
    async expireBatch(limit, at) {
      return db.tx(async (t) => {
        await t.query(`SET LOCAL lock_timeout = '3s'`);
        const r = await t.query<{ id: string | number; showroom_id: string | number; plan_id: string | number; current_period_end: Date }>(EXPIRE_BATCH_SQL, [at ?? null, limit]);
        const audit = createPgAuditRepository(t);
        for (const row of r.rows) {
          await audit.record({
            action: 'subscription.expire',
            actorUserId: null, // no user acted: an operator-run job
            actorRole: 'system',
            entityType: 'subscription',
            entityId: String(row.id),
            afterData: { showroomId: Number(row.showroom_id), planId: Number(row.plan_id), periodEnd: Math.floor(row.current_period_end.getTime() / 1000) },
          });
        }
        return r.rows.length;
      });
    },
  };
}

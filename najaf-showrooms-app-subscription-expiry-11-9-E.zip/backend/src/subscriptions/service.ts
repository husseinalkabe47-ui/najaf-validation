// Manual subscription activation and renewal with payment recording, by administrators (Phase 11.9-D). No gateway, no automatic
// billing, no expiry processing, no entitlement enforcement: this only RECORDS what an administrator confirms was paid.
//
// Decisions (each is covered by tests):
//  - WHO: an administrator only (resource 'subscription'); everyone else gets 404 BEFORE the body is parsed.
//  - WHAT: one showroom, one of the 3-, 6- or 12-month plans (by code), how it was paid (method), the payment reference, the amount
//    received in IQD (a whole number >= 0; it is RECORDED as received and need not equal the plan price) and the transaction date.
//  - DUPLICATES: a payment is identified by (provider 'manual', provider_ref '<method>:<reference>'). Processing the same one again is
//    409 duplicate_payment and changes nothing (checked first, and the UNIQUE constraint backstops a race).
//  - DATES (the period starts at the moment the administrator records it, the service clock, never at the transaction date):
//      no live subscription          -> activate: start = now, end = now + plan months;
//      live and not yet expired      -> renew: end = CURRENT END + plan months (same plan only: another plan is 409 plan_mismatch);
//      live but its end has passed   -> the old row is closed ('expired') and a NEW row starts: start = now, end = now + plan months.
//    Months are calendar months in UTC, clamped to the month's last day (31 Jan + 1 month = 28/29 Feb).
//  - ATOMIC: the payment and the subscription change (and their audit rows) are written in ONE transaction; any failure rolls back all.
//  - HISTORY: a payment row is never changed; a subscription row is only extended or closed, and after a lapse a new row is added.
//  - AUDIT: 'subscription.activate' / 'subscription.renew' (and 'subscription.close_lapsed' for the closed old row): actor, subscription as
//    the entity, numbers only (ids, plan, months, amount, payment id, old and new period end as epoch seconds).
import { authorize, isValidId, notFound, subscriptionResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { DbError } from '../errors.ts';
import type { FieldError } from '../auth/validation.ts';
import type { PaymentRow, SubscriptionHistoryRow, SubscriptionRow, SubscriptionsRepository } from './repository.ts';

export const PAYMENT_METHODS = ['cash', 'bank_transfer', 'mobile_wallet', 'other'] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];
export const MANUAL_PROVIDER = 'manual';
export const MAX_PAYMENT_AMOUNT = 9_999_999_999_999;
export const PLAN_CODES = ['plan_3m', 'plan_6m', 'plan_12m'] as const;
const PAID_AT_FLOOR = Date.UTC(2020, 0, 1);
const FUTURE_SKEW_MS = 5 * 60 * 1000;
const REFERENCE_PATTERN = /^[\p{L}\p{N}][\p{L}\p{N}._\-/]{0,63}$/u;
const PAID_AT_PATTERN = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2}))?$/;

export class SubscriptionsError extends Error {
  readonly code: 'validation_failed' | 'duplicate_payment' | 'plan_mismatch';
  readonly fields: FieldError[] | undefined;
  constructor(code: 'validation_failed' | 'duplicate_payment' | 'plan_mismatch', fields?: FieldError[]) {
    super(code === 'validation_failed' ? 'The submitted data is not valid' : code === 'duplicate_payment' ? 'This payment was already recorded' : 'A live subscription of another plan exists; renew with the same plan');
    this.name = 'SubscriptionsError';
    this.code = code;
    this.fields = fields;
  }
}

/** Calendar months added in UTC, clamped to the last day of the target month. */
export function addMonthsUtc(d: Date, months: number): Date {
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth() + months;
  const lastDay = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  return new Date(Date.UTC(y, m, Math.min(d.getUTCDate(), lastDay), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds(), d.getUTCMilliseconds()));
}

export type GrantKind = 'activated' | 'renewed' | 'renewed_after_expiry';
/** The pure date rule. `live` is the showroom's live subscription (or null). */
export function planGrant(live: { periodEnd: Date; planId: string } | null, planId: string, months: number, now: Date):
  { kind: GrantKind; start: Date; end: Date } | { kind: 'plan_mismatch' } {
  if (!live) return { kind: 'activated', start: now, end: addMonthsUtc(now, months) };
  if (live.periodEnd.getTime() > now.getTime()) {
    if (live.planId !== planId) return { kind: 'plan_mismatch' };
    return { kind: 'renewed', start: now, end: addMonthsUtc(live.periodEnd, months) };
  }
  return { kind: 'renewed_after_expiry', start: now, end: addMonthsUtc(now, months) };
}

export interface GrantInput { showroomId: string; planCode: string; method: PaymentMethod; reference: string; amount: number; paidAt: Date }
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

function parsePaidAt(raw: string, now: Date): Date | null {
  const m = PAID_AT_PATTERN.exec(raw);
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const probe = new Date(Date.UTC(y, mo - 1, d));
  if (probe.getUTCFullYear() !== y || probe.getUTCMonth() !== mo - 1 || probe.getUTCDate() !== d) return null; // 2026-02-31 and the like
  if (m[4] !== undefined && (Number(m[4]) > 23 || Number(m[5]) > 59 || Number(m[6] ?? '0') > 59)) return null;
  const t = Date.parse(m[4] === undefined ? `${raw}T00:00:00Z` : raw);
  if (!Number.isFinite(t) || t < PAID_AT_FLOOR || t > now.getTime() + FUTURE_SKEW_MS) return null;
  return new Date(t);
}

export function parseGrantBody(body: unknown, now: Date): { ok: true; value: GrantInput } | { ok: false; errors: FieldError[] } {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  const allowed = ['showroomId', 'planCode', 'method', 'reference', 'amount', 'paidAt'];
  for (const key of Object.keys(body)) if (!allowed.includes(key)) errors.push({ field: /^[A-Za-z0-9_]{1,40}$/.test(key) ? key : 'unknown', code: 'unknown_field' });
  const str = (f: string): string | undefined => {
    const v = body[f];
    if (v === undefined) errors.push({ field: f, code: 'required' });
    else if (typeof v !== 'string') errors.push({ field: f, code: 'invalid_type' });
    else return v;
    return undefined;
  };
  const showroomId = str('showroomId');
  if (showroomId !== undefined && !isValidId(showroomId)) errors.push({ field: 'showroomId', code: 'invalid_format' });
  const planCode = str('planCode');
  if (planCode !== undefined && !(PLAN_CODES as readonly string[]).includes(planCode)) errors.push({ field: 'planCode', code: 'invalid_format' });
  const method = str('method');
  if (method !== undefined && !(PAYMENT_METHODS as readonly string[]).includes(method)) errors.push({ field: 'method', code: 'invalid_format' });
  const rawRef = str('reference');
  const reference = rawRef?.trim();
  if (reference !== undefined && !REFERENCE_PATTERN.test(reference)) errors.push({ field: 'reference', code: reference.length === 0 ? 'required' : reference.length > 64 ? 'too_long' : 'invalid_format' });
  const a = body['amount'];
  if (a === undefined) errors.push({ field: 'amount', code: 'required' });
  else if (typeof a !== 'number' || !Number.isFinite(a)) errors.push({ field: 'amount', code: 'invalid_type' });
  else if (!Number.isSafeInteger(a) || a < 0 || a > MAX_PAYMENT_AMOUNT) errors.push({ field: 'amount', code: 'invalid_format' });
  const rawPaidAt = str('paidAt');
  const paidAt = rawPaidAt === undefined ? undefined : parsePaidAt(rawPaidAt, now);
  if (rawPaidAt !== undefined && paidAt === null) errors.push({ field: 'paidAt', code: 'invalid_format' });
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { showroomId: showroomId!, planCode: planCode!, method: method as PaymentMethod, reference: reference!, amount: a as number, paidAt: paidAt! } };
}

export interface SubscriptionView { id: string; showroomId: string; plan: { code: string; durationMonths: number }; status: string; periodStart: string; periodEnd: string; version: number }
export interface PaymentView { id: string; amount: number; currency: string; method: string; reference: string; paidAt: string }
export const toSubscriptionView = (s: SubscriptionRow): SubscriptionView => ({ id: s.id, showroomId: s.showroomId, plan: { code: s.planCode, durationMonths: s.durationMonths }, status: s.status, periodStart: s.periodStart.toISOString(), periodEnd: s.periodEnd.toISOString(), version: s.version });
export const toPaymentView = (p: PaymentRow): PaymentView => {
  const i = p.providerRef.indexOf(':');
  return { id: p.id, amount: p.amount, currency: p.currency, method: i < 0 ? p.provider : p.providerRef.slice(0, i), reference: i < 0 ? p.providerRef : p.providerRef.slice(i + 1), paidAt: p.paidAt.toISOString() };
};

export interface GrantResult { outcome: GrantKind; subscription: SubscriptionView; payment: PaymentView }
export interface SubscriptionsApi {
  grant(actor: Actor | null, body: unknown, ctx?: { requestId?: string | undefined }): Promise<GrantResult>;
  history(actor: Actor | null, rawShowroomId: unknown): Promise<{ subscriptions: Array<SubscriptionView & { payments: PaymentView[] }> }>;
}

const epoch = (d: Date): number => Math.floor(d.getTime() / 1000);
const num = (id: string): number => Number(id);

export function createSubscriptionsService(deps: { repo: SubscriptionsRepository; now?: () => Date }): SubscriptionsApi {
  const { repo } = deps;
  const clock = deps.now ?? (() => new Date());
  return {
    async grant(actor, body, ctx = {}) {
      authorize(actor, 'update', subscriptionResource());
      if (!actor) throw notFound(); // unreachable: authorize refused a null actor
      const now = clock();
      const parsed = parseGrantBody(body, now);
      if (!parsed.ok) throw new SubscriptionsError('validation_failed', parsed.errors);
      const input = parsed.value;
      const ref = `${input.method}:${input.reference}`;
      try {
        return await repo.transaction(async (t): Promise<GrantResult> => {
          if (!(await t.lockShowroom(input.showroomId))) throw notFound();
          const plan = await t.findPlan(input.planCode);
          if (!plan) throw notFound();
          if (await t.paymentExists(MANUAL_PROVIDER, ref)) throw new SubscriptionsError('duplicate_payment');
          const live = await t.findLive(input.showroomId);
          const decision = planGrant(live, plan.id, plan.durationMonths, now);
          if (decision.kind === 'plan_mismatch') throw new SubscriptionsError('plan_mismatch');
          const audit = (action: 'subscription.activate' | 'subscription.renew' | 'subscription.close_lapsed', entityId: string, afterData: Record<string, number>) =>
            t.audit.record({ action, actorUserId: actor.id, actorRole: 'admin', entityType: 'subscription', entityId, afterData, requestId: ctx.requestId });
          let sub: SubscriptionRow;
          if (decision.kind === 'renewed' && live) {
            sub = await t.extendSubscription({ id: live.id, end: decision.end });
          } else {
            if (decision.kind === 'renewed_after_expiry' && live) await t.closeLapsed(live.id);
            sub = await t.insertSubscription({ showroomId: input.showroomId, planId: plan.id, start: decision.start, end: decision.end, grantedBy: actor.id });
          }
          const payment = await t.insertPayment({ subscriptionId: sub.id, amount: input.amount, provider: MANUAL_PROVIDER, ref, paidAt: input.paidAt, recordedBy: actor.id });
          if (decision.kind === 'renewed_after_expiry' && live) await audit('subscription.close_lapsed', live.id, { showroomId: num(input.showroomId), oldPeriodEnd: epoch(live.periodEnd), newSubscriptionId: num(sub.id) });
          const data: Record<string, number> = { showroomId: num(input.showroomId), planId: num(plan.id), months: plan.durationMonths, amount: input.amount, planPrice: plan.price, paymentId: num(payment.id), newPeriodEnd: epoch(sub.periodEnd) };
          if (live) { data['oldSubscriptionId'] = num(live.id); data['oldPlanId'] = num(live.planId); data['oldPeriodEnd'] = epoch(live.periodEnd); }
          await audit(decision.kind === 'activated' ? 'subscription.activate' : 'subscription.renew', sub.id, data);
          return { outcome: decision.kind, subscription: toSubscriptionView(sub), payment: toPaymentView(payment) };
        });
      } catch (e) {
        // a concurrent duplicate that slipped past the check is stopped by UNIQUE (provider, provider_ref); the transaction is already rolled back
        if (e instanceof DbError && e.kind === 'unique' && e.constraint === 'payments_provider_ref_uq') throw new SubscriptionsError('duplicate_payment');
        throw e;
      }
    },

    async history(actor, rawShowroomId) {
      authorize(actor, 'read', subscriptionResource());
      if (!isValidId(rawShowroomId)) throw notFound();
      if (!(await repo.showroomExists(rawShowroomId))) throw notFound();
      const rows: SubscriptionHistoryRow[] = await repo.history(rawShowroomId);
      return { subscriptions: rows.map((r) => ({ ...toSubscriptionView(r), payments: r.payments.map(toPaymentView) })) };
    },
  };
}

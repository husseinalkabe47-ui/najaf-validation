// Subscription expiry (Phase 11.9-E): the background operation the manual subscriptions (11.9-D) need, run by an OPERATOR or an external
// scheduler through scripts/subscriptions-expire.ts (the same model as the reward maintenance, 11.8-G, and the asset cleanup). It is never
// an HTTP route and the server does not start it: no queue, no timer, no new service.
//
// What it does: every live subscription (trialing, active, past_due) whose paid period has ended (current_period_end <= the database's
// now(); the entitlement function treats `> now()` as in force, so an end exactly at now is expired) becomes status 'expired', and each
// change leaves one audit row 'subscription.expire' (actor = the system, numbers only).
// What it NEVER does: create or renew a subscription, touch a payment, delete anything, change a plan, enforce limits or hide cars (later
// steps). History stays: only the status moves.
// Safety: DRY-RUN unless told otherwise; bounded batches (batchSize x maxBatches); idempotent (a rerun finds nothing left, so no second
// transition or audit row) and safe to run concurrently (rows another run or a manual grant holds are skipped; see the repository).
// A database failure STOPS the run with a code (never a message); what was done is committed and consistent, and the report says how much.
import { DbError } from '../errors.ts';
import type { SubscriptionExpiryRepository } from './expiry-repository.ts';

export const EXPIRY_DEFAULTS = Object.freeze({ batchSize: 200, maxBatches: 10 });
export const EXPIRY_LIMITS = Object.freeze({ batchSizeMax: 1000, maxBatchesMax: 100 });

export interface ExpiryOptions {
  /** true (the default) = count only, change nothing. */
  dryRun: boolean;
  batchSize: number;
  maxBatches: number;
}

export class ExpiryOptionsError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`invalid expiry options: ${problems.join(', ')}`);
    this.name = 'ExpiryOptionsError';
    this.problems = problems;
  }
}

const intIn = (v: unknown, min: number, max: number): v is number => typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max;

/** Fills the defaults and validates every bound. Dry-run unless dryRun is explicitly false. */
export function resolveExpiryOptions(input: Partial<ExpiryOptions> = {}): ExpiryOptions {
  const o: ExpiryOptions = {
    dryRun: input.dryRun !== false,
    batchSize: input.batchSize ?? EXPIRY_DEFAULTS.batchSize,
    maxBatches: input.maxBatches ?? EXPIRY_DEFAULTS.maxBatches,
  };
  const problems: string[] = [];
  if (!intIn(o.batchSize, 1, EXPIRY_LIMITS.batchSizeMax)) problems.push('batchSize');
  if (!intIn(o.maxBatches, 1, EXPIRY_LIMITS.maxBatchesMax)) problems.push('maxBatches');
  if (problems.length > 0) throw new ExpiryOptionsError(problems);
  return o;
}

export type ExpiryErrorCode = 'database_unavailable' | 'unexpected';
export interface ExpiryAlert {
  code: 'backlog_remaining';
  /** Subscriptions expired in this run, and the most one run may do. */
  value: number;
  threshold: number;
}
export interface ExpiryLogger {
  info(o: object): void;
  warn(o: object): void;
  error(o: object): void;
}
export interface ExpiryReport {
  dryRun: boolean;
  options: { batchSize: number; maxBatches: number };
  /** dry run: `expired` stays 0 and `eligible` is the count; executed: `eligible` = `expired`. */
  batches: number;
  eligible: number;
  expired: number;
  /** false when maxBatches was reached with work possibly left: run again. */
  complete: boolean;
  alerts: ExpiryAlert[];
  error: ExpiryErrorCode | null;
}

/** `at` fixes the instant (tests only); production leaves it out and the database's now() decides. */
export async function runSubscriptionExpiry(deps: { repo: SubscriptionExpiryRepository; logger?: ExpiryLogger; at?: Date }, input: Partial<ExpiryOptions> = {}): Promise<ExpiryReport> {
  const opts = resolveExpiryOptions(input);
  const { repo, logger, at } = deps;
  const report: ExpiryReport = { dryRun: opts.dryRun, options: { batchSize: opts.batchSize, maxBatches: opts.maxBatches }, batches: 0, eligible: 0, expired: 0, complete: false, alerts: [], error: null };
  try {
    if (opts.dryRun) {
      report.eligible = await repo.countExpirable(at);
      report.complete = true;
    } else {
      for (;;) {
        if (report.batches >= opts.maxBatches) break;
        const n = await repo.expireBatch(opts.batchSize, at);
        report.batches++;
        report.expired += n;
        if (n < opts.batchSize) {
          report.complete = true;
          break;
        }
      }
      report.eligible = report.expired;
    }
  } catch (e) {
    report.error = e instanceof DbError ? 'database_unavailable' : 'unexpected';
  }
  if (!opts.dryRun && !report.complete && report.error === null) report.alerts.push({ code: 'backlog_remaining', value: report.expired, threshold: opts.batchSize * opts.maxBatches });
  for (const a of report.alerts) logger?.warn({ event: 'subscription_expiry.alert', ...a });
  if (report.error) logger?.error({ event: 'subscription_expiry.failed', code: report.error });
  else logger?.info({ event: 'subscription_expiry.done', dryRun: report.dryRun, expired: report.expired });
  return report;
}

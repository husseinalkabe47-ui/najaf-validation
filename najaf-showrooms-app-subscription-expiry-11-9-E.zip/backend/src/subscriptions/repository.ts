// PostgreSQL access for the administrators' manual subscription activation / renewal and payment recording (Phase 11.9-D). Rules:
//  - everything that changes state runs inside ONE transaction (`transaction`), after the showroom row is locked, so two requests
//    for the same showroom are serialized and the live subscription seen is the one that is really there;
//  - nothing is ever deleted and no payment row is ever updated: a payment is INSERTed once (UNIQUE (provider, provider_ref) also
//    blocks a duplicate under a race); a subscription row is only extended (current_period_end, status) or closed (status 'expired');
//    a new period after a lapse is a NEW row, so the old row stays as history;
//  - every statement is parameterized and names its columns; audit rows go through the single audit writer in the same transaction.
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';

export interface ShowroomRow { id: string; status: string }
export interface DurationPlanRow { id: string; code: string; durationMonths: number; price: number; currency: string }
export interface SubscriptionRow {
  id: string;
  showroomId: string;
  planId: string;
  planCode: string;
  durationMonths: number;
  status: string;
  periodStart: Date;
  periodEnd: Date;
  version: number;
}
export interface PaymentRow { id: string; subscriptionId: string; amount: number; currency: string; provider: string; providerRef: string; paidAt: Date }

/** What one transaction may do. Every method runs in that transaction. */
export interface SubscriptionTx {
  /** Locks and returns the showroom (its owner account must not be deleted); null if there is none. */
  lockShowroom(id: string): Promise<ShowroomRow | null>;
  /** An ACTIVE duration plan (3, 6 or 12 months) by code; null otherwise (the free plan never matches). */
  findPlan(code: string): Promise<DurationPlanRow | null>;
  /** The showroom's live subscription (trialing, active or past_due), locked; null if none. */
  findLive(showroomId: string): Promise<SubscriptionRow | null>;
  paymentExists(provider: string, ref: string): Promise<boolean>;
  insertSubscription(input: { showroomId: string; planId: string; start: Date; end: Date; grantedBy: string }): Promise<SubscriptionRow>;
  /** Extends a live subscription: new end, status 'active'. */
  extendSubscription(input: { id: string; end: Date }): Promise<SubscriptionRow>;
  /** A lapsed live subscription becomes 'expired' (history is kept). */
  closeLapsed(id: string): Promise<void>;
  insertPayment(input: { subscriptionId: string; amount: number; provider: string; ref: string; paidAt: Date; recordedBy: string }): Promise<PaymentRow>;
  audit: AuditRepository;
}

export interface SubscriptionHistoryRow extends SubscriptionRow { payments: PaymentRow[] }

export interface SubscriptionsRepository {
  transaction<T>(fn: (t: SubscriptionTx) => Promise<T>): Promise<T>;
  /** false when the showroom does not exist (or its owner is deleted). */
  showroomExists(id: string): Promise<boolean>;
  /** Every subscription of the showroom, newest first, each with its payments (newest first). */
  history(showroomId: string): Promise<SubscriptionHistoryRow[]>;
}

interface SubSql { id: string | number; showroom_id: string | number; plan_id: string | number; plan_code: string; duration_months: number; status: string; current_period_start: Date; current_period_end: Date; version: number }
interface PaySql { id: string | number; subscription_id: string | number; amount: string; currency: string; provider: string; provider_ref: string; paid_at: Date }
const SUB_COLUMNS = `s.id, s.showroom_id, s.plan_id, p.code AS plan_code, p.duration_months, s.status, s.current_period_start, s.current_period_end, s.version`;
const toSub = (r: SubSql): SubscriptionRow => ({ id: String(r.id), showroomId: String(r.showroom_id), planId: String(r.plan_id), planCode: r.plan_code, durationMonths: r.duration_months, status: r.status, periodStart: r.current_period_start, periodEnd: r.current_period_end, version: r.version });
const PAY_COLUMNS = 'id, subscription_id, amount, currency, provider, provider_ref, paid_at';
const toPay = (r: PaySql): PaymentRow => ({ id: String(r.id), subscriptionId: String(r.subscription_id), amount: Number(r.amount), currency: r.currency, provider: r.provider, providerRef: r.provider_ref, paidAt: r.paid_at });

function txRepo(t: Tx): SubscriptionTx {
  const subById = async (id: string): Promise<SubscriptionRow> => toSub((await t.query<SubSql>(`SELECT ${SUB_COLUMNS} FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id WHERE s.id = $1`, [id])).rows[0]!);
  return {
    async lockShowroom(id) {
      const r = await t.query<{ id: string | number; status: string }>(
        `SELECT s.id, s.status FROM showrooms s JOIN users u ON u.id = s.owner_id WHERE s.id = $1 AND u.deleted_at IS NULL FOR UPDATE OF s`, [id]);
      const row = r.rows[0];
      return row ? { id: String(row.id), status: row.status } : null;
    },
    async findPlan(code) {
      const r = await t.query<{ id: string | number; code: string; duration_months: number; price: string; currency: string }>(
        `SELECT id, code, duration_months, price, currency FROM subscription_plans WHERE code = $1 AND duration_months IS NOT NULL AND is_active`, [code]);
      const row = r.rows[0];
      return row ? { id: String(row.id), code: row.code, durationMonths: row.duration_months, price: Number(row.price), currency: row.currency } : null;
    },
    async findLive(showroomId) {
      const r = await t.query<SubSql>(
        `SELECT ${SUB_COLUMNS} FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id
          WHERE s.showroom_id = $1 AND s.status IN ('trialing', 'active', 'past_due') FOR UPDATE OF s`, [showroomId]);
      return r.rows[0] ? toSub(r.rows[0]) : null;
    },
    async paymentExists(provider, ref) {
      return (await t.query(`SELECT 1 FROM payments WHERE provider = $1 AND provider_ref = $2`, [provider, ref])).rows.length > 0;
    },
    async insertSubscription(i) {
      const r = await t.query<{ id: string | number }>(
        `INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end, granted_by)
         VALUES ($1, $2, 'active', $3, $4, $5) RETURNING id`, [i.showroomId, i.planId, i.start, i.end, i.grantedBy]);
      return subById(String(r.rows[0]!.id));
    },
    async extendSubscription(i) {
      await t.query(`UPDATE subscriptions SET current_period_end = $2, status = 'active' WHERE id = $1`, [i.id, i.end]);
      return subById(i.id);
    },
    async closeLapsed(id) {
      await t.query(`UPDATE subscriptions SET status = 'expired' WHERE id = $1`, [id]);
    },
    async insertPayment(i) {
      const r = await t.query<PaySql>(
        `INSERT INTO payments (subscription_id, amount, currency, status, provider, provider_ref, recorded_by, paid_at)
         VALUES ($1, $2, 'IQD', 'paid', $3, $4, $5, $6) RETURNING ${PAY_COLUMNS}`, [i.subscriptionId, i.amount, i.provider, i.ref, i.recordedBy, i.paidAt]);
      return toPay(r.rows[0]!);
    },
    audit: createPgAuditRepository(t),
  };
}

export function createPgSubscriptionsRepository(db: Db): SubscriptionsRepository {
  return {
    transaction: (fn) => db.tx(async (t) => { await t.query(`SET LOCAL lock_timeout = '3s'`); return fn(txRepo(t)); }),
    async showroomExists(id) {
      return (await db.query(`SELECT 1 FROM showrooms s JOIN users u ON u.id = s.owner_id WHERE s.id = $1 AND u.deleted_at IS NULL`, [id])).rows.length > 0;
    },
    async history(showroomId) {
      const subs = await db.query<SubSql>(`SELECT ${SUB_COLUMNS} FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id WHERE s.showroom_id = $1 ORDER BY s.id DESC`, [showroomId]);
      const pays = await db.query<PaySql>(`SELECT ${PAY_COLUMNS} FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = $1) ORDER BY id DESC`, [showroomId]);
      const all = pays.rows.map(toPay);
      return subs.rows.map(toSub).map((s) => ({ ...s, payments: all.filter((p) => p.subscriptionId === s.id) }));
    },
  };
}

// HTTP contract for the administrators' account directory and dashboard statistics (Phase 11.7.2-J). READ ONLY. Thin: decisions
// live in admin-users/service.ts and src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify.
//
//   GET /v1/admin/users?role=&after=&limit=   Bearer (admin) -> 200 {users: [{id, name, phone, email, role, status, createdAt}], nextAfter}
//   GET /v1/admin/users/:id                   Bearer (admin) -> 200 {user, showroom, memberCars, memberCarsTotal}
//   GET /v1/admin/stats                       Bearer (admin) -> 200 {stats: {totalUsers, totalShowrooms, totalShowroomCars, totalMemberCars,
//                                                               pendingMemberCars, activeMemberCars, soldMemberCars, rejectedMemberCars,
//                                                               suspendedMemberCars, pendingDealers}}
//
// Errors: 401 no/invalid token; 404 for any non-administrator, and for an unknown, deleted or malformed account id (identical);
// 400 invalid query (field names and codes only); 429 rate limited. No write route exists here.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { AdminUsersError } from './service.ts';
import type { AdminUsersApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same budget as the other admin reads). */
export const ADMIN_USERS_RATE_LIMITS = {
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type AdminUsersRateLimitedRoute = keyof typeof ADMIN_USERS_RATE_LIMITS;

export function toAdminUsersHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof AdminUsersError) return { status: 400, code: e.code, message: e.message, fields: e.fields };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateHook(limiter: RateLimiter, route: AdminUsersRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`adminUsers.${route}:${request.ip}`, ADMIN_USERS_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'admin_users.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

export function registerAdminUsersRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; adminUsers: AdminUsersApi; rateLimiter?: RateLimiter }): void {
  const { auth, adminUsers, rateLimiter } = deps;
  const limited = (route: AdminUsersRateLimitedRoute): Hook[] => (rateLimiter ? [rateHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toAdminUsersHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling": the verified access token, re-read from the database, then the account-state rules.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  app.get('/v1/admin/users', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await adminUsers.listUsers(actor, request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/admin/users/:id', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await adminUsers.getUser(actor, (request.params as Record<string, unknown> | undefined)?.['id']));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/admin/stats', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send({ stats: await adminUsers.getStats(actor) });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

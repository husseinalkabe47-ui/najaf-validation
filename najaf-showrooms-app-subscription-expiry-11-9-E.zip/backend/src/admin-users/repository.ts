// PostgreSQL access for the administrators' account directory and dashboard statistics (Phase 11.7.2-J). READ ONLY. Rules:
//  - every statement is parameterized; roles and statuses a statement REQUIRES are SQL literals or whitelisted by the service;
//  - no SELECT *: each query names its columns. password_hash, failed_logins, locked_until, session or verification data are
//    never selected; the only personal columns are the ones the admin screens display (name, phone, email);
//  - soft-deleted rows (deleted_at IS NOT NULL) are not part of the directory or of any count;
//  - nothing here writes anything (no INSERT / UPDATE / DELETE): this phase adds no account action.
import type { Tx } from '../db.ts';

export type UserRole = 'user' | 'dealer' | 'admin';

export interface AdminUserRow {
  id: string;
  name: string;
  phoneE164: string;
  email: string | null;
  role: string;
  status: string;
  createdAt: Date;
}
export interface AdminShowroomRow {
  id: string;
  name: string;
  status: string;
}
export interface AdminMemberCarRow {
  id: string;
  brand: string;
  model: string;
  status: string;
}
export interface PlatformStatsRow {
  totalUsers: number;
  totalShowrooms: number;
  totalShowroomCars: number;
  totalMemberCars: number;
  pendingMemberCars: number;
  activeMemberCars: number;
  soldMemberCars: number;
  rejectedMemberCars: number;
  suspendedMemberCars: number;
  pendingDealers: number;
}

export interface AdminUsersRepository {
  /** Accounts that are not deleted, optionally of one role, by ascending id (keyset pagination). */
  listUsers(input: { role: UserRole | null; afterId: string | null; limit: number }): Promise<AdminUserRow[]>;
  /** One account that is not deleted; null otherwise. */
  findUser(id: string): Promise<AdminUserRow | null>;
  /** The showroom owned by this account (showrooms.owner_id is UNIQUE), whatever its status; null if none. */
  findShowroomOfOwner(ownerId: string): Promise<AdminShowroomRow | null>;
  /** This account's member ads that are not deleted, newest first, at most `limit`. */
  listMemberCarsOfOwner(ownerId: string, limit: number): Promise<AdminMemberCarRow[]>;
  /** How many member ads of this account are not deleted. */
  countMemberCarsOfOwner(ownerId: string): Promise<number>;
  /** The dashboard counts, all from the tables in ONE statement (one snapshot). */
  stats(): Promise<PlatformStatsRow>;
}

const USER_COLUMNS = 'u.id, u.name, u.phone_e164, u.email, u.role, u.status, u.created_at';
interface UserSql {
  id: string;
  name: string;
  phone_e164: string;
  email: string | null;
  role: string;
  status: string;
  created_at: Date;
}
const toUser = (r: UserSql): AdminUserRow => ({
  id: String(r.id),
  name: r.name,
  phoneE164: r.phone_e164,
  email: r.email === null || r.email === undefined ? null : String(r.email),
  role: r.role,
  status: r.status,
  createdAt: r.created_at,
});

/** SQL builders, exported so tests can pin their text (and run it on a real database). */
export function buildListUsers(input: { role: UserRole | null; afterId: string | null; limit: number }): { text: string; values: unknown[] } {
  return {
    text: `SELECT ${USER_COLUMNS}
             FROM users u
            WHERE u.deleted_at IS NULL
              AND ($1::text IS NULL OR u.role = $1::text)
              AND ($2::bigint IS NULL OR u.id > $2::bigint)
            ORDER BY u.id
            LIMIT $3::int`,
    values: [input.role, input.afterId, input.limit],
  };
}
export function buildFindUser(id: string): { text: string; values: unknown[] } {
  return { text: `SELECT ${USER_COLUMNS} FROM users u WHERE u.id = $1::bigint AND u.deleted_at IS NULL`, values: [id] };
}
export function buildFindShowroomOfOwner(ownerId: string): { text: string; values: unknown[] } {
  return { text: `SELECT s.id, s.name, s.status FROM showrooms s WHERE s.owner_id = $1::bigint`, values: [ownerId] };
}
export function buildListMemberCarsOfOwner(ownerId: string, limit: number): { text: string; values: unknown[] } {
  return {
    text: `SELECT c.id, c.brand, c.model, c.status
             FROM cars c
            WHERE c.owner_id = $1::bigint AND c.source_type = 'member' AND c.deleted_at IS NULL
            ORDER BY c.id DESC
            LIMIT $2::int`,
    values: [ownerId, limit],
  };
}
export function buildCountMemberCarsOfOwner(ownerId: string): { text: string; values: unknown[] } {
  return { text: `SELECT count(*)::int AS n FROM cars c WHERE c.owner_id = $1::bigint AND c.source_type = 'member' AND c.deleted_at IS NULL`, values: [ownerId] };
}
/** Counts only. Member-ad states are the five of the schema (pending/active/sold/rejected/suspended). */
export const STATS_SQL = `SELECT
    (SELECT count(*) FROM users WHERE deleted_at IS NULL)::int                                                      AS total_users,
    (SELECT count(*) FROM showrooms)::int                                                                          AS total_showrooms,
    (SELECT count(*) FROM cars WHERE source_type = 'showroom' AND deleted_at IS NULL)::int                         AS total_showroom_cars,
    (SELECT count(*) FROM cars WHERE source_type = 'member' AND deleted_at IS NULL)::int                           AS total_member_cars,
    (SELECT count(*) FROM cars WHERE source_type = 'member' AND deleted_at IS NULL AND status = 'pending')::int     AS pending_member_cars,
    (SELECT count(*) FROM cars WHERE source_type = 'member' AND deleted_at IS NULL AND status = 'active')::int      AS active_member_cars,
    (SELECT count(*) FROM cars WHERE source_type = 'member' AND deleted_at IS NULL AND status = 'sold')::int        AS sold_member_cars,
    (SELECT count(*) FROM cars WHERE source_type = 'member' AND deleted_at IS NULL AND status = 'rejected')::int    AS rejected_member_cars,
    (SELECT count(*) FROM cars WHERE source_type = 'member' AND deleted_at IS NULL AND status = 'suspended')::int   AS suspended_member_cars,
    (SELECT count(*) FROM users WHERE role = 'dealer' AND status = 'pending' AND deleted_at IS NULL)::int          AS pending_dealers`;

export function createPgAdminUsersRepository(q: Tx): AdminUsersRepository {
  return {
    async listUsers(input) {
      const s = buildListUsers(input);
      return (await q.query<UserSql>(s.text, s.values)).rows.map(toUser);
    },
    async findUser(id) {
      const s = buildFindUser(id);
      const r = (await q.query<UserSql>(s.text, s.values)).rows[0];
      return r ? toUser(r) : null;
    },
    async findShowroomOfOwner(ownerId) {
      const s = buildFindShowroomOfOwner(ownerId);
      const r = (await q.query<{ id: string; name: string; status: string }>(s.text, s.values)).rows[0];
      return r ? { id: String(r.id), name: r.name, status: r.status } : null;
    },
    async listMemberCarsOfOwner(ownerId, limit) {
      const s = buildListMemberCarsOfOwner(ownerId, limit);
      return (await q.query<{ id: string; brand: string; model: string; status: string }>(s.text, s.values)).rows.map((r) => ({ id: String(r.id), brand: r.brand, model: r.model, status: r.status }));
    },
    async countMemberCarsOfOwner(ownerId) {
      const s = buildCountMemberCarsOfOwner(ownerId);
      return Number((await q.query<{ n: number }>(s.text, s.values)).rows[0]?.n ?? 0);
    },
    async stats() {
      const r = (await q.query<Record<string, number>>(STATS_SQL)).rows[0] ?? {};
      const n = (k: string) => Number(r[k] ?? 0);
      return {
        totalUsers: n('total_users'),
        totalShowrooms: n('total_showrooms'),
        totalShowroomCars: n('total_showroom_cars'),
        totalMemberCars: n('total_member_cars'),
        pendingMemberCars: n('pending_member_cars'),
        activeMemberCars: n('active_member_cars'),
        soldMemberCars: n('sold_member_cars'),
        rejectedMemberCars: n('rejected_member_cars'),
        suspendedMemberCars: n('suspended_member_cars'),
        pendingDealers: n('pending_dealers'),
      };
    },
  };
}

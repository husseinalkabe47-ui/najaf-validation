// The administrators' account directory and dashboard statistics (Phase 11.7.2-J). READ ONLY.
//
// Decisions (each is covered by tests):
//  - WHO: an administrator only, through dedicated least-privilege resources of the existing policy (user_directory,
//    platform_stats: action 'read', role admin). Everyone else (member, dealer, pending dealer = no actor) gets 404 BEFORE the query
//    is even parsed, exactly as GET /v1/admin/dealers (Step 5.2).
//  - WHAT: exactly the fields the existing admin screens display (screens/adminUsers.js, adminUserDetails.js, adminDashboard.js):
//    an account is {id, name, phone, email, role, status, createdAt}; its admin view adds the dealer's showroom {id, name, status}
//    and its member ads {id, brand, model, status} (at most MEMBER_CARS_MAX, newest first, with the total). Each DTO is built field
//    by field: no password hash, login counters, lock state, sessions, tokens or verification codes, ever.
//  - Statistics are the dashboard's ten counts, computed from the tables by one SQL statement (no cache, no client numbers).
//  - Listing: role filter (user | dealer | admin, or all), keyset pagination `after` / `limit` (default 50, max 100) with `nextAfter`,
//    the same shape as the dealer directory. Unknown query keys are 400.
//  - No state change: no suspend, activate, delete or edit action exists in this module; reads are not audited (as the other admin
//    lists), and nothing is written.
import { authorize, isValidId, notFound, platformStatsResource, userDirectoryResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError } from '../auth/validation.ts';
import { parseCarId } from '../member-cars/validation.ts';
import type { AdminMemberCarRow, AdminUserRow, AdminUsersRepository, PlatformStatsRow, UserRole } from './repository.ts';

export class AdminUsersError extends Error {
  readonly code = 'validation_failed' as const;
  readonly fields: FieldError[];
  constructor(fields: FieldError[]) {
    super('The submitted data is not valid');
    this.name = 'AdminUsersError';
    this.fields = fields;
  }
}

/** What an administrator sees of an account. */
export interface AdminUserView {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  role: string;
  status: string;
  createdAt: string;
}
export interface AdminUserDetails {
  user: AdminUserView;
  /** The dealer's showroom (any status); null for everyone else or a dealer without one. */
  showroom: { id: string; name: string; status: string } | null;
  memberCars: Array<{ id: string; brand: string; model: string; status: string }>;
  memberCarsTotal: number;
}
export type PlatformStats = PlatformStatsRow;

export interface AdminUsersApi {
  listUsers(actor: Actor | null, query: unknown): Promise<{ users: AdminUserView[]; nextAfter: string | null }>;
  getUser(actor: Actor | null, rawId: unknown): Promise<AdminUserDetails>;
  getStats(actor: Actor | null): Promise<PlatformStats>;
}

export const USERS_LIMIT_DEFAULT = 50;
export const USERS_LIMIT_MAX = 100;
export const MEMBER_CARS_MAX = 100;
const ROLES: readonly UserRole[] = ['user', 'dealer', 'admin'];
const LIMIT_PATTERN = /^[1-9][0-9]{0,2}$/;
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

export function parseUsersQuery(query: unknown): { ok: true; value: { role: UserRole | null; afterId: string | null; limit: number } } | { ok: false; errors: FieldError[] } {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  for (const key of Object.keys(q)) if (!['role', 'after', 'limit'].includes(key)) errors.push({ field: /^[A-Za-z0-9_]{1,40}$/.test(key) ? key : 'unknown', code: 'unknown_field' });
  let role: UserRole | null = null;
  const r = q['role'];
  if (r !== undefined) {
    if (typeof r !== 'string') errors.push({ field: 'role', code: 'invalid_type' });
    else if (!(ROLES as readonly string[]).includes(r)) errors.push({ field: 'role', code: 'invalid_format' });
    else role = r as UserRole;
  }
  let afterId: string | null = null;
  const a = q['after'];
  if (a !== undefined) {
    if (typeof a !== 'string') errors.push({ field: 'after', code: 'invalid_type' });
    else if (!isValidId(a)) errors.push({ field: 'after', code: 'invalid_format' });
    else afterId = a;
  }
  let limit = USERS_LIMIT_DEFAULT;
  const l = q['limit'];
  if (l !== undefined) {
    if (typeof l !== 'string') errors.push({ field: 'limit', code: 'invalid_type' });
    else if (!LIMIT_PATTERN.test(l) || Number(l) > USERS_LIMIT_MAX) errors.push({ field: 'limit', code: 'invalid_format' });
    else limit = Number(l);
  }
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { role, afterId, limit } };
}

export const toAdminUserView = (r: AdminUserRow): AdminUserView => ({
  id: r.id,
  name: r.name,
  phone: r.phoneE164,
  email: r.email,
  role: r.role,
  status: r.status,
  createdAt: r.createdAt.toISOString(),
});
const toCar = (c: AdminMemberCarRow) => ({ id: c.id, brand: c.brand, model: c.model, status: c.status });

export function createAdminUsersService(deps: { repo: AdminUsersRepository }): AdminUsersApi {
  const { repo } = deps;
  return {
    async listUsers(actor, query) {
      authorize(actor, 'read', userDirectoryResource()); // non-admins: 404 before the query is even parsed
      const parsed = parseUsersQuery(query);
      if (!parsed.ok) throw new AdminUsersError(parsed.errors);
      const rows = await repo.listUsers(parsed.value);
      const last = rows.length === parsed.value.limit ? rows[rows.length - 1] : undefined;
      return { users: rows.map(toAdminUserView), nextAfter: last ? last.id : null };
    },

    async getUser(actor, rawId) {
      authorize(actor, 'read', userDirectoryResource());
      const id = parseCarId(rawId); // the same strict positive-bigint id rule as every other path id
      if (id === null) throw notFound();
      const row = await repo.findUser(id);
      if (!row) throw notFound();
      const showroom = row.role === 'dealer' ? await repo.findShowroomOfOwner(row.id) : null;
      const [cars, total] = [await repo.listMemberCarsOfOwner(row.id, MEMBER_CARS_MAX), await repo.countMemberCarsOfOwner(row.id)];
      return { user: toAdminUserView(row), showroom: showroom ? { id: showroom.id, name: showroom.name, status: showroom.status } : null, memberCars: cars.map(toCar), memberCarsTotal: total };
    },

    async getStats(actor) {
      authorize(actor, 'read', platformStatsResource());
      const s = await repo.stats();
      return {
        totalUsers: s.totalUsers,
        totalShowrooms: s.totalShowrooms,
        totalShowroomCars: s.totalShowroomCars,
        totalMemberCars: s.totalMemberCars,
        pendingMemberCars: s.pendingMemberCars,
        activeMemberCars: s.activeMemberCars,
        soldMemberCars: s.soldMemberCars,
        rejectedMemberCars: s.rejectedMemberCars,
        suspendedMemberCars: s.suspendedMemberCars,
        pendingDealers: s.pendingDealers,
      };
    },
  };
}

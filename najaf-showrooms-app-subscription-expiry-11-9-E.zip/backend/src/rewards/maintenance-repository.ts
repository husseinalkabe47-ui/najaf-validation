// Reward-grant maintenance storage (Phase 11.8-G). The ONLY statements the maintenance job runs. Each batch is ONE statement (atomic).
// Concurrency with the live flow: a batch locks rows with FOR UPDATE SKIP LOCKED, so a grant being consumed or verified right now is
// skipped (the live path locks the grant first, as always), and the live paths themselves refuse an expired grant (expires_at > now()).
// Two maintenance runs at once never touch the same row. A 'consumed' grant is NEVER touched: moderation and the audit trail rely on it.
import { createPgAuditRepository } from '../auth/repository.ts';
import type { Db } from '../db.ts';

type Sql = { text: string; values: unknown[] };

/** Rows moved requested|verified -> expired, by what they were. `verified` = a viewer finished the ad and never used the reward. */
export interface ExpireBatchResult {
  requested: number;
  verified: number;
}

export interface MaintenanceRepository {
  /** Grants that are past their expiry but still 'requested' / 'verified' and unbound (database clock). */
  countExpirable(): Promise<ExpireBatchResult>;
  /** 'expired' / 'failed' unbound grants whose expiry is older than `retentionSeconds`. */
  countPurgeable(retentionSeconds: number): Promise<number>;
  /** Moves up to `limit` expirable grants to 'expired' (CAS on the status). */
  expireBatch(limit: number): Promise<ExpireBatchResult>;
  /** Deletes up to `limit` purgeable grants. Returns how many. */
  purgeBatch(limit: number, retentionSeconds: number): Promise<number>;
  /** One summary row in the append-only audit trail (numbers only). */
  recordRun(afterData: Record<string, number>): Promise<void>;
}

const EXPIRABLE = `status IN ('requested', 'verified') AND car_id IS NULL AND expires_at <= now()`;
const PURGEABLE = `status IN ('expired', 'failed') AND car_id IS NULL AND expires_at < now() - ($1::int * interval '1 second')`;

export function buildCountExpirable(): Sql {
  return {
    text: `SELECT status, count(*)::int AS n FROM reward_grants WHERE ${EXPIRABLE} GROUP BY status`,
    values: [],
  };
}
export function buildCountPurgeable(retentionSeconds: number): Sql {
  return { text: `SELECT count(*)::int AS n FROM reward_grants WHERE ${PURGEABLE}`, values: [retentionSeconds] };
}
export function buildExpireBatch(limit: number): Sql {
  // The new status is a literal. The inner SELECT picks and locks the rows (oldest first); the UPDATE re-checks the status, so a row
  // that changed between the two cannot be expired by mistake. `was` is the status before the change.
  return {
    text: `WITH c AS (
             SELECT id, status FROM reward_grants WHERE ${EXPIRABLE} ORDER BY expires_at, id LIMIT $1::int FOR UPDATE SKIP LOCKED
           )
           UPDATE reward_grants g SET status = 'expired'
             FROM c
            WHERE g.id = c.id AND g.status = c.status AND g.car_id IS NULL
        RETURNING c.status AS was`,
    values: [limit],
  };
}
export function buildPurgeBatch(limit: number, retentionSeconds: number): Sql {
  // Only grants that hold no ad. A purged grant can no longer be replayed: the retention is never shorter than the provider's
  // timestamp window (rewards/maintenance.ts), and the live paths already refuse an expired grant.
  return {
    text: `DELETE FROM reward_grants WHERE id IN (
             SELECT id FROM reward_grants WHERE ${PURGEABLE.replace('$1::int', '$2::int')} ORDER BY expires_at, id LIMIT $1::int FOR UPDATE SKIP LOCKED
           ) AND car_id IS NULL AND status IN ('expired', 'failed')
        RETURNING 1`,
    values: [limit, retentionSeconds],
  };
}
export function createPgMaintenanceRepository(db: Db): MaintenanceRepository {
  return {
    async countExpirable() {
      const s = buildCountExpirable();
      const out: ExpireBatchResult = { requested: 0, verified: 0 };
      for (const r of (await db.query<{ status: string; n: number }>(s.text, s.values)).rows) {
        if (r.status === 'requested') out.requested = Number(r.n);
        else if (r.status === 'verified') out.verified = Number(r.n);
      }
      return out;
    },
    async countPurgeable(retentionSeconds) {
      const s = buildCountPurgeable(retentionSeconds);
      return Number((await db.query<{ n: number }>(s.text, s.values)).rows[0]?.n ?? 0);
    },
    async expireBatch(limit) {
      const s = buildExpireBatch(limit);
      const out: ExpireBatchResult = { requested: 0, verified: 0 };
      for (const r of (await db.query<{ was: string }>(s.text, s.values)).rows) {
        if (r.was === 'requested') out.requested++;
        else if (r.was === 'verified') out.verified++;
      }
      return out;
    },
    async purgeBatch(limit, retentionSeconds) {
      const s = buildPurgeBatch(limit, retentionSeconds);
      return (await db.query(s.text, s.values)).rows.length;
    },
    async recordRun(afterData) {
      // The single audit writer (numbers only, secret-looking keys refused). actor_id stays NULL: no user acted.
      await createPgAuditRepository(db).record({ action: 'reward_maintenance.run', actorUserId: null, actorRole: 'system', entityType: 'reward_maintenance', entityId: '0', afterData });
    },
  };
}

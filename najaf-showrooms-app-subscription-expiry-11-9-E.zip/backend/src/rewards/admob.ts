// AdMob rewarded-ad server-side verification (SSV), Phase 11.8-C. Android rewarded ads only.
//
// Protocol (Google's AdMob SSV documentation): after a user earns a reward, AdMob's servers call OUR callback URL with a GET whose query
// carries ad_network, ad_unit, custom_data, reward_amount, reward_item, timestamp, transaction_id and user_id, then ALWAYS `signature`
// followed by `key_id` as the last two parameters. The signature is ECDSA (P-256) over SHA-256 of the query string BEFORE `&signature=`,
// byte for byte as received (order unchanged, nothing re-encoded), DER encoded, transported as web-safe base64. The public keys are
// published by Google as JSON ({keys:[{keyId, pem, base64}]}), may rotate, and may be cached for at most 24 hours. Google expects 200;
// on anything else it retries a few times.
//
// What this file adds on top of the signature (the signature only proves "AdMob signed these values"):
//  - ad_unit must be OUR configured ad unit: another developer's AdMob account also produces validly signed callbacks.
//  - user_id must equal the user the SERVER holds for the grant, and custom_data the grant's id (the app sets both through
//    ServerSideVerificationOptions before showing the ad, but only the values Google signed count, and they must match the server's record).
//  - transaction_id is the receipt: the database makes (provider, transaction_id) unique, so one callback verifies one request only.
//  - timestamp must be recent (and not in the future).
// Nothing a client sends from the app (an "ad completed" event, a flag, a transaction id) reaches this code: the only input is the raw
// query string of Google's own callback, and the only thing it can do is move a grant to 'verified' through RewardApi.verifyReward.
// It NEVER consumes a grant and never publishes anything: that stays the member's authenticated, atomic consume request.
// The evidence (query string) is never logged.
import { createPublicKey, verify as cryptoVerify } from 'node:crypto';
import type { KeyObject } from 'node:crypto';
import { RewardError } from './service.ts';
import type { RewardApi } from './service.ts';
import { TRANSACTION_ID_MAX_LENGTH } from './provider.ts';
import type { RewardVerdict, RewardVerification, RewardVerifier } from './provider.ts';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';

export const ADMOB_PROVIDER = 'admob';
export const ADMOB_KEYS_URL = 'https://gstatic.com/admob/reward/verifier-keys.json';
const KEY_HOSTS = new Set(['gstatic.com', 'www.gstatic.com']);

/** Limits. The callback URL is short (about 400 bytes in practice); anything far beyond that is not Google's. */
export const SSV_QUERY_MAX_LENGTH = 2048;
const KEYS_BODY_MAX = 64 * 1024;
const KEYS_FETCH_TIMEOUT_MS = 5000;
/** Google: cache for at most 24 h. We refresh at 6 h, and may fall back to a cached key only until the 24 h limit. */
export const KEY_REFRESH_MS = 6 * 60 * 60 * 1000;
export const KEY_HARD_MAX_AGE_MS = 24 * 60 * 60 * 1000;
/** An unknown key id triggers at most one refetch per this long (an attacker cannot make us hammer Google). */
export const UNKNOWN_KEY_REFETCH_COOLDOWN_MS = 60 * 1000;
export const SSV_MAX_AGE_SECONDS = 60 * 60;
export const SSV_FUTURE_SKEW_SECONDS = 5 * 60;

// ------------------------------------------------------------------------------------------------------------- configuration
export class AdmobConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super('invalid reward provider configuration');
    this.name = 'AdmobConfigError';
    this.problems = problems;
  }
}
export interface AdmobConfig {
  adUnitId: string;
}
/** null = the reward provider is not enabled (REWARD_PROVIDER unset): the unconfigured verifier stays in place. */
export function loadAdmobConfig(env: Record<string, string | undefined>): AdmobConfig | null {
  const provider = (env['REWARD_PROVIDER'] ?? '').trim();
  if (provider === '') return null;
  const problems: string[] = [];
  if (provider !== ADMOB_PROVIDER) problems.push(`REWARD_PROVIDER must be '${ADMOB_PROVIDER}' (or unset)`);
  const adUnitId = (env['ADMOB_SSV_AD_UNIT_ID'] ?? '').trim();
  if (!/^[0-9]{3,40}$/.test(adUnitId)) problems.push('ADMOB_SSV_AD_UNIT_ID must be the numeric AdMob ad unit id (digits only, the part after the slash)');
  if (problems.length > 0) throw new AdmobConfigError(problems);
  return { adUnitId };
}

// ------------------------------------------------------------------------------------------------------------- the query
export interface ParsedSsvQuery {
  /** The exact bytes Google signed. */
  signedContent: string;
  signature: Buffer;
  keyId: string;
  params: Map<string, string>;
}

const decode = (s: string, plusIsSpace = true): string | null => {
  try {
    return decodeURIComponent(plusIsSpace ? s.replace(/\+/g, ' ') : s);
  } catch {
    return null;
  }
};

/** Strict parse of the RAW query string (the text after '?', exactly as received). null = not a well-formed AdMob callback. */
export function parseSsvQuery(raw: unknown): ParsedSsvQuery | null {
  if (typeof raw !== 'string' || raw.length === 0 || raw.length > SSV_QUERY_MAX_LENGTH) return null;
  const pairs = raw.split('&');
  if (pairs.length < 3) return null;
  const sigPair = pairs[pairs.length - 2]!;
  const keyPair = pairs[pairs.length - 1]!;
  if (!sigPair.startsWith('signature=') || !keyPair.startsWith('key_id=')) return null;
  const signedContent = pairs.slice(0, -2).join('&');
  if (signedContent === '') return null;
  const keyId = keyPair.slice('key_id='.length);
  if (!/^[0-9]{1,20}$/.test(keyId)) return null;
  const sigText = decode(sigPair.slice('signature='.length), false);
  if (sigText === null || !/^[A-Za-z0-9_\-+/]+={0,2}$/.test(sigText)) return null;
  const signature = Buffer.from(sigText.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
  if (signature.length < 8 || signature.length > 80) return null; // a DER P-256 signature is 70-72 bytes
  const params = new Map<string, string>();
  for (const pair of pairs.slice(0, -2)) {
    const eq = pair.indexOf('=');
    if (eq < 1) return null;
    const name = decode(pair.slice(0, eq));
    const value = decode(pair.slice(eq + 1));
    if (name === null || value === null || params.has(name)) return null; // a repeated name is refused, never "first wins"
    params.set(name, value);
  }
  return { signedContent, signature, keyId, params };
}

// ------------------------------------------------------------------------------------------------------------- the keys
export class AdmobKeysUnavailableError extends Error {
  constructor() {
    super('the AdMob verifier keys cannot be loaded');
    this.name = 'AdmobKeysUnavailableError';
  }
}
export interface RawVerifierKey {
  keyId: string;
  pem: string;
}
export type FetchVerifierKeys = () => Promise<RawVerifierKey[]>;

/** Google's key list over HTTPS from Google's own host only. Throws on any problem (the caller fails closed). */
export const fetchAdmobKeysFromGoogle: FetchVerifierKeys = async () => {
  const res = await fetch(ADMOB_KEYS_URL, { redirect: 'follow', signal: AbortSignal.timeout(KEYS_FETCH_TIMEOUT_MS), headers: { accept: 'application/json' } });
  const finalUrl = new URL(res.url || ADMOB_KEYS_URL);
  if (finalUrl.protocol !== 'https:' || !KEY_HOSTS.has(finalUrl.hostname)) throw new Error('unexpected key host');
  if (!res.ok) throw new Error(`key list status ${res.status}`);
  const text = await res.text();
  if (text.length > KEYS_BODY_MAX) throw new Error('key list too large');
  const body = JSON.parse(text) as { keys?: Array<{ keyId?: unknown; pem?: unknown }> };
  if (!Array.isArray(body.keys)) throw new Error('key list malformed');
  const out: RawVerifierKey[] = [];
  for (const k of body.keys) if ((typeof k.keyId === 'number' || typeof k.keyId === 'string') && typeof k.pem === 'string') out.push({ keyId: String(k.keyId), pem: k.pem });
  return out;
};

export interface AdmobKeyStore {
  /** The public key for this key id; null = Google does not know it. Throws AdmobKeysUnavailableError when the list cannot be had. */
  get(keyId: string): Promise<KeyObject | null>;
}

export function createAdmobKeyStore(opts: { fetchKeys?: FetchVerifierKeys; now?: () => number; logger?: Logger } = {}): AdmobKeyStore {
  const fetchKeys = opts.fetchKeys ?? fetchAdmobKeysFromGoogle;
  const now = opts.now ?? Date.now;
  const logger = opts.logger ?? nullLogger;
  let keys = new Map<string, KeyObject>();
  let fetchedAt: number | null = null;
  let lastAttemptAt = Number.NEGATIVE_INFINITY;
  let inflight: Promise<void> | null = null;

  async function refresh(): Promise<void> {
    if (inflight) return inflight; // concurrent callers share one fetch
    lastAttemptAt = now();
    inflight = (async () => {
      try {
        const next = new Map<string, KeyObject>();
        for (const raw of await fetchKeys()) {
          try {
            const key = createPublicKey(raw.pem);
            if (key.asymmetricKeyType === 'ec') next.set(raw.keyId, key);
          } catch {
            // an unusable entry is skipped; it can only make a verification fail, never succeed
          }
        }
        if (next.size === 0) throw new Error('no usable key');
        keys = next;
        fetchedAt = now();
      } catch (e) {
        logger.warn({ event: 'reward.admob_keys_fetch_failed', reason: e instanceof Error ? e.name : 'error' });
        throw new AdmobKeysUnavailableError();
      } finally {
        inflight = null;
      }
    })();
    return inflight;
  }

  return {
    async get(keyId) {
      const t = now();
      const age = fetchedAt === null ? Number.POSITIVE_INFINITY : t - fetchedAt;
      if (age >= KEY_REFRESH_MS) {
        try {
          await refresh();
        } catch (e) {
          // Cached keys may serve until Google's 24 h limit; past it, fail closed.
          if (fetchedAt === null || t - fetchedAt >= KEY_HARD_MAX_AGE_MS) throw e;
        }
      }
      const known = keys.get(keyId);
      if (known) return known;
      // An id we do not have: maybe a rotation. One refetch per cooldown, otherwise the answer is simply "unknown".
      if (t - lastAttemptAt >= UNKNOWN_KEY_REFETCH_COOLDOWN_MS) {
        try {
          await refresh();
        } catch (e) {
          if (fetchedAt === null || t - fetchedAt >= KEY_HARD_MAX_AGE_MS) throw e;
        }
      }
      return keys.get(keyId) ?? null;
    },
  };
}

// ------------------------------------------------------------------------------------------------------------- the verifier
/** Normalizes AdMob's timestamp to milliseconds (seconds, milliseconds and microseconds all appear in its documentation). */
export function ssvTimestampMs(text: string): number | null {
  if (!/^[0-9]{9,17}$/.test(text)) return null;
  const n = Number(text);
  if (text.length <= 11) return n * 1000;
  if (text.length <= 14) return n;
  return Math.floor(n / 1000);
}

export interface AdmobEvidence {
  /** The RAW query string of Google's callback (after '?'), untouched. */
  query: string;
}

/** ECDSA P-256 / SHA-256 over the exact signed bytes. Never throws. */
export function signatureIsValid(parsed: ParsedSsvQuery, key: KeyObject): boolean {
  try {
    return cryptoVerify('sha256', Buffer.from(parsed.signedContent, 'utf8'), { key, dsaEncoding: 'der' }, parsed.signature);
  } catch {
    return false;
  }
}

export function createAdmobRewardVerifier(deps: { config: AdmobConfig; keys: AdmobKeyStore; now?: () => number; maxAgeSeconds?: number }): RewardVerifier {
  const now = deps.now ?? Date.now;
  const maxAgeMs = (deps.maxAgeSeconds ?? SSV_MAX_AGE_SECONDS) * 1000;
  return {
    provider: ADMOB_PROVIDER,
    async verify(input: RewardVerification): Promise<RewardVerdict> {
      const ev = input.evidence as Partial<AdmobEvidence> | null;
      const parsed = ev && typeof ev === 'object' ? parseSsvQuery(ev.query) : null;
      if (!parsed) return { ok: false };
      const key = await deps.keys.get(parsed.keyId); // may throw AdmobKeysUnavailableError: the service answers verification_failed, nothing is verified
      if (!key) return { ok: false };
      if (!signatureIsValid(parsed, key)) return { ok: false };

      const p = parsed.params;
      if (p.get('ad_unit') !== deps.config.adUnitId) return { ok: false };
      if (p.get('user_id') !== input.userId) return { ok: false };
      if (p.get('custom_data') !== input.grantId) return { ok: false };
      const tx = p.get('transaction_id');
      if (tx === undefined || !/^[A-Za-z0-9_-]{1,200}$/.test(tx) || tx.length > TRANSACTION_ID_MAX_LENGTH) return { ok: false };
      const at = ssvTimestampMs(p.get('timestamp') ?? '');
      const t = now();
      if (at === null || at > t + SSV_FUTURE_SKEW_SECONDS * 1000 || t - at > maxAgeMs) return { ok: false };
      return { ok: true, transactionId: tx };
    },
  };
}

// ------------------------------------------------------------------------------------------------------------- the callback
export type AdmobCallbackResult = { status: 200; code: 'ok' } | { status: 400; code: 'rejected' } | { status: 503; code: 'unavailable' };
/**
 * What can be said about a callback WITHOUT touching the database (11.8-E): is its signature Google's? 'trusted' = validly signed by a Google key
 * (it cannot be forged, so it is never counted as abuse; `grantKey` is the signed custom_data, bounded, for a per-grant replay limit).
 * 'untrusted' = malformed, unknown key or bad signature (abuse candidates). 'unavailable' = Google's keys cannot be loaded (never counted).
 */
export type SsvPrecheck = { kind: 'trusted'; grantKey: string } | { kind: 'untrusted' } | { kind: 'unavailable' };
export interface AdmobCallbackApi {
  precheck(rawQuery: unknown): Promise<SsvPrecheck>;
  handle(rawQuery: unknown): Promise<AdmobCallbackResult>;
}

/**
 * What the callback route calls. Success is 200 (also for the same callback arriving again). A callback that cannot be trusted is ONE
 * uniform 400 (no oracle on grants, users or the reason). If Google's keys cannot be loaded the answer is 503 so Google retries.
 * Any other failure (a database outage) propagates: the global handler answers 5xx and Google retries.
 */
export function createAdmobCallbackHandler(deps: { rewards: Pick<RewardApi, 'verifyReward'>; keys: AdmobKeyStore; logger?: Logger }): AdmobCallbackApi {
  const logger = deps.logger ?? nullLogger;
  return {
    async precheck(rawQuery) {
      const parsed = parseSsvQuery(rawQuery);
      if (!parsed) return { kind: 'untrusted' };
      let key: KeyObject | null;
      try {
        key = await deps.keys.get(parsed.keyId);
      } catch (e) {
        if (e instanceof AdmobKeysUnavailableError) return { kind: 'unavailable' };
        throw e;
      }
      if (!key || !signatureIsValid(parsed, key)) return { kind: 'untrusted' };
      return { kind: 'trusted', grantKey: (parsed.params.get('custom_data') ?? '').slice(0, 64) };
    },
    async handle(rawQuery) {
      const parsed = parseSsvQuery(rawQuery);
      const grantId = parsed?.params.get('custom_data');
      if (!parsed || grantId === undefined) {
        logger.warn({ event: 'reward.ssv_rejected', why: 'malformed' });
        return { status: 400, code: 'rejected' };
      }
      try {
        await deps.keys.get(parsed.keyId); // distinguishes "Google's keys are unreachable" (retry) from "this callback is bad"
      } catch (e) {
        if (e instanceof AdmobKeysUnavailableError) return { status: 503, code: 'unavailable' };
        throw e;
      }
      try {
        await deps.rewards.verifyReward(grantId, { query: rawQuery as string } satisfies AdmobEvidence);
        return { status: 200, code: 'ok' };
      } catch (e) {
        if (e instanceof RewardError) {
          if (e.code === 'unavailable') return { status: 503, code: 'unavailable' };
          logger.warn({ event: 'reward.ssv_rejected', why: e.code });
          return { status: 400, code: 'rejected' };
        }
        throw e;
      }
    },
  };
}

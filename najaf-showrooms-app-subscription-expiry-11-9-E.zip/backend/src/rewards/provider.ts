// The rewarded-ad verifier (Phase 11.8, Step 1). Only the interface and an "unconfigured" implementation live here: the real,
// provider-specific verification (an Android server-side-verification callback, a web provider's receipt) is a later step.
//
// A verifier answers ONE question: "does this evidence, issued by the ad provider, prove that THIS reward request (grant id) of THIS
// user was really watched?". It is handed the grant id and the user id the SERVER holds for that request, plus the provider's opaque
// evidence, and must check that the evidence names that same grant and user (a receipt for another request must not verify this
// one). It returns the provider's unique transaction id, which the database makes unique per provider (reward_ssv_uq), so one
// receipt can never verify two requests. Nothing a browser or an app claims ("I watched it") is ever evidence: only what the
// provider's own server signed. Implementations must not log the evidence.

export interface RewardVerification {
  /** Hand the evidence the PROVIDER signed; `grantId` and `userId` are the server's own record of the request being verified. */
  grantId: string;
  userId: string;
  evidence: unknown;
}

export type RewardVerdict = { ok: true; transactionId: string } | { ok: false };

export interface RewardVerifier {
  /** reward_grants.provider (varchar(40)): the name the grants of this verifier carry. */
  readonly provider: string;
  /**
   * false = this verifier can NEVER verify (nothing is wired in). Undefined/true = it can try. Lets the service refuse to open
   * reward requests nobody could ever verify. It describes the SERVER's configuration, not any account.
   */
  readonly configured?: boolean;
  verify(input: RewardVerification): Promise<RewardVerdict>;
}

/** The production default until a real provider is wired in: it rejects every verification. */
export function createUnconfiguredRewardVerifier(): RewardVerifier {
  return {
    provider: 'unconfigured',
    configured: false,
    async verify() {
      return { ok: false };
    },
  };
}

export const PROVIDER_MAX_LENGTH = 40; // reward_grants.provider varchar(40)
export const TRANSACTION_ID_MAX_LENGTH = 200; // a bound on the provider's id; the column is text

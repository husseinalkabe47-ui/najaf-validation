// The AdMob server-side-verification callback (Phase 11.8-C, limits 11.8-E). Google's servers call it; it is NOT a member endpoint.
//
//   GET /v1/rewards/admob/ssv?ad_network=..&ad_unit=..&custom_data=<grant id>&reward_amount=..&reward_item=..&timestamp=..
//                             &transaction_id=..&user_id=<user id>&signature=..&key_id=..
//        -> 200 {status:'ok'} | 400 {error:{code:'rejected'}} | 429 | 503 {error:{code:'unavailable'}}
//
// No bearer token (Google has none): trust comes ONLY from the ECDSA signature and the checks in rewards/admob.ts. The raw query string
// is passed on untouched (it is what was signed). This route can only move a grant to 'verified'; it never consumes one and never
// publishes an ad. Imports Fastify TYPES only.
//
// Limits (11.8-E), built around ONE fact: a callback with a valid Google signature cannot be forged, so it is never abuse and is never
// counted against an address (Google retries a failed callback several times, and Google's callers share addresses; blocking by address would
// punish exactly them). The signature is checked BEFORE any database access, so:
//   - untrusted callbacks (malformed, unknown key, bad signature) are counted per client address: that is where flooding comes from, and an
//     attacker flooding garbage cannot starve Google, whose callbacks are not counted;
//   - trusted callbacks are limited per GRANT (the signed custom_data), generously: Google retries a few times, a captured callback replayed in
//     a loop stops. The callback stays idempotent: a repeat of the same one is still 200 until the limit.
// Keys never come from a request field Google did not sign. request.ip is the socket address unless the server was started with an explicit
// trusted-proxy list (the project-wide setting); X-Forwarded-For from anyone else is ignored.
import type { FastifyInstance, FastifyRequest } from 'fastify';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import type { AdmobCallbackApi } from './admob.ts';

export const ADMOB_UNTRUSTED_RATE_LIMIT: RateRule = { limit: 60, windowSeconds: 10 * 60 };
export const ADMOB_GRANT_RATE_LIMIT: RateRule = { limit: 30, windowSeconds: 10 * 60 };

type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

export function registerAdmobCallbackRoutes(app: FastifyInstance, deps: { callbacks: AdmobCallbackApi; rateLimiter?: RateLimiter }): void {
  const { callbacks, rateLimiter } = deps;

  app.get('/v1/rewards/admob/ssv', async (request: FastifyRequest, reply) => {
    const r = reply as unknown as Reply;
    const url = request.url;
    const at = url.indexOf('?');
    const raw = at < 0 ? '' : url.slice(at + 1);
    const tooMany = (decision: { retryAfterSeconds: number }, event: string): Reply => {
      request.log.warn({ event });
      r.header('retry-after', String(decision.retryAfterSeconds));
      return r.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
    };

    const pre = await callbacks.precheck(raw);
    if (pre.kind === 'unavailable') return r.code(503).send({ error: { code: 'unavailable', message: 'Verification is temporarily unavailable', requestId: request.id } });
    if (pre.kind === 'untrusted') {
      if (rateLimiter) {
        const decision = rateLimiter.consume(`rewards.admob_ssv.untrusted:${request.ip}`, ADMOB_UNTRUSTED_RATE_LIMIT);
        if (!decision.allowed) return tooMany(decision, 'rewards.rate_limited.admob_untrusted');
      }
      return r.code(400).send({ error: { code: 'rejected', message: 'The callback was not accepted', requestId: request.id } });
    }
    if (rateLimiter) {
      const decision = rateLimiter.consume(`rewards.admob_ssv.grant:${pre.grantKey}`, ADMOB_GRANT_RATE_LIMIT);
      if (!decision.allowed) return tooMany(decision, 'rewards.rate_limited.admob_grant');
    }
    const out = await callbacks.handle(raw);
    if (out.status === 200) return r.code(200).send({ status: 'ok' });
    return r.code(out.status).send({ error: { code: out.code, message: out.status === 400 ? 'The callback was not accepted' : 'Verification is temporarily unavailable', requestId: request.id } });
  });
}

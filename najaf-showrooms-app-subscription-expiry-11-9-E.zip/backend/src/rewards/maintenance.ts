// Reward-grant maintenance (Phase 11.8-G): the background operation the rewarded-ad flow needs, run by an OPERATOR or an external
// scheduler through scripts/rewards-maintenance.ts (same model as the asset cleanup, 11.6.4). It is never an HTTP route, and the
// server does not start it: no queue, no timer and no new service are introduced.
//
// Why it exists. A grant that nobody finishes stays 'requested' / 'verified' forever: the live paths already REFUSE it once
// expires_at has passed, but the row keeps the status, and rows pile up. Two operations, in this order:
//   1. expire : 'requested' | 'verified' grants past their expiry that hold no ad -> 'expired'  (a compare-and-swap per batch).
//   2. purge  : 'expired' | 'failed' grants that hold no ad and expired more than `retentionDays` ago -> deleted.
// What it NEVER touches: a 'consumed' grant (moderation requires it, the audit trail points at it) and any grant holding an ad.
// Retention is never shorter than 7 days: a purged grant frees its provider transaction id, and the provider's callbacks are only
// accepted within 1 hour of their timestamp (rewards/admob.ts), so a purged receipt can no longer be replayed.
//
// Safety: DRY-RUN unless told otherwise; bounded batches (batchSize x maxBatches) so one run is short; repeat-safe (a rerun after a
// failure or a bound simply continues); concurrent with live traffic (rows being consumed/verified are skipped, see the repository).
// A database failure STOPS the run with a code (never a message); what was done is real and consistent, and the report says how much.
// Alerts are signals in the report and in the log, not a delivery channel (no e-mail, WhatsApp or SMS here): the operator or the
// scheduler's own monitoring reads them. An executed run leaves ONE audit row (numbers only).
import { DbError } from '../errors.ts';
import type { MaintenanceRepository } from './maintenance-repository.ts';

export const MAINTENANCE_DEFAULTS = Object.freeze({ batchSize: 500, maxBatches: 10, retentionDays: 30, alertVerifiedLost: 10 });
export const MAINTENANCE_LIMITS = Object.freeze({ batchSizeMax: 1000, maxBatchesMax: 100, retentionDaysMin: 7, retentionDaysMax: 365, alertMax: 100000 });

export interface MaintenanceOptions {
  /** true (the default) = count only, change nothing. */
  dryRun: boolean;
  batchSize: number;
  maxBatches: number;
  /** Expired/failed grants are deleted only when they expired at least this many days ago. */
  retentionDays: number;
  /** Alert when at least this many VERIFIED rewards expired unused in one run (people watched the ad and never used it). */
  alertVerifiedLost: number;
  expire: boolean;
  purge: boolean;
}

export class MaintenanceOptionsError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`invalid maintenance options: ${problems.join(', ')}`);
    this.name = 'MaintenanceOptionsError';
    this.problems = problems;
  }
}

const intIn = (v: unknown, min: number, max: number): v is number => typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max;

/** Fills the defaults and validates every bound. Dry-run unless dryRun is explicitly false. */
export function resolveMaintenanceOptions(input: Partial<MaintenanceOptions> = {}): MaintenanceOptions {
  const o: MaintenanceOptions = {
    dryRun: input.dryRun !== false,
    batchSize: input.batchSize ?? MAINTENANCE_DEFAULTS.batchSize,
    maxBatches: input.maxBatches ?? MAINTENANCE_DEFAULTS.maxBatches,
    retentionDays: input.retentionDays ?? MAINTENANCE_DEFAULTS.retentionDays,
    alertVerifiedLost: input.alertVerifiedLost ?? MAINTENANCE_DEFAULTS.alertVerifiedLost,
    expire: input.expire !== false,
    purge: input.purge !== false,
  };
  const problems: string[] = [];
  if (!intIn(o.batchSize, 1, MAINTENANCE_LIMITS.batchSizeMax)) problems.push('batchSize');
  if (!intIn(o.maxBatches, 1, MAINTENANCE_LIMITS.maxBatchesMax)) problems.push('maxBatches');
  if (!intIn(o.retentionDays, MAINTENANCE_LIMITS.retentionDaysMin, MAINTENANCE_LIMITS.retentionDaysMax)) problems.push('retentionDays');
  if (!intIn(o.alertVerifiedLost, 1, MAINTENANCE_LIMITS.alertMax)) problems.push('alertVerifiedLost');
  if (!o.expire && !o.purge) problems.push('nothingToDo');
  if (problems.length > 0) throw new MaintenanceOptionsError(problems);
  return o;
}

export type MaintenanceErrorCode = 'database_unavailable' | 'audit_unavailable' | 'unexpected';
export type MaintenanceAlertCode = 'verified_rewards_expired_unused' | 'backlog_remaining';
export interface MaintenanceAlert {
  code: MaintenanceAlertCode;
  /** The number that crossed the line (grants), and the line. */
  value: number;
  threshold: number;
}
export interface MaintenanceLogger {
  info(o: object): void;
  warn(o: object): void;
  error(o: object): void;
}

export interface MaintenanceReport {
  dryRun: boolean;
  options: { batchSize: number; maxBatches: number; retentionDays: number; alertVerifiedLost: number };
  /** null = the phase was not selected. dry run: `expired` stays 0 and `eligible` is the count. */
  expire: { batches: number; eligible: number; expired: number; expiredVerified: number; complete: boolean } | null;
  purge: { batches: number; eligible: number; deleted: number; complete: boolean } | null;
  alerts: MaintenanceAlert[];
  error: MaintenanceErrorCode | null;
}

class Stop extends Error {
  readonly code: MaintenanceErrorCode;
  constructor(code: MaintenanceErrorCode) {
    super(code);
    this.code = code;
  }
}

export async function runRewardMaintenance(deps: { repo: MaintenanceRepository; logger?: MaintenanceLogger }, input: Partial<MaintenanceOptions> = {}): Promise<MaintenanceReport> {
  const opts = resolveMaintenanceOptions(input);
  const { repo, logger } = deps;
  const retentionSeconds = opts.retentionDays * 86400;
  const report: MaintenanceReport = {
    dryRun: opts.dryRun,
    options: { batchSize: opts.batchSize, maxBatches: opts.maxBatches, retentionDays: opts.retentionDays, alertVerifiedLost: opts.alertVerifiedLost },
    expire: null,
    purge: null,
    alerts: [],
    error: null,
  };
  // Every repository call goes through this: a failure becomes a Stop with a code (never a message, never SQL).
  const db = async <T>(fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (e) {
      throw new Stop(e instanceof DbError ? 'database_unavailable' : 'unexpected');
    }
  };

  try {
    if (opts.expire) {
      const r = { batches: 0, eligible: 0, expired: 0, expiredVerified: 0, complete: false };
      report.expire = r;
      if (opts.dryRun) {
        const c = await db(() => repo.countExpirable());
        r.eligible = c.requested + c.verified;
        r.expiredVerified = 0;
        r.complete = true;
      } else {
        for (;;) {
          if (r.batches >= opts.maxBatches) break;
          const b = await db(() => repo.expireBatch(opts.batchSize));
          r.batches++;
          const n = b.requested + b.verified;
          r.expired += n;
          r.expiredVerified += b.verified;
          if (n < opts.batchSize) {
            r.complete = true;
            break;
          }
        }
        r.eligible = r.expired;
      }
    }

    if (opts.purge) {
      const r = { batches: 0, eligible: 0, deleted: 0, complete: false };
      report.purge = r;
      if (opts.dryRun) {
        r.eligible = await db(() => repo.countPurgeable(retentionSeconds));
        r.complete = true;
      } else {
        for (;;) {
          if (r.batches >= opts.maxBatches) break;
          const n = await db(() => repo.purgeBatch(opts.batchSize, retentionSeconds));
          r.batches++;
          r.deleted += n;
          if (n < opts.batchSize) {
            r.complete = true;
            break;
          }
        }
        r.eligible = r.deleted;
      }
    }
  } catch (e) {
    report.error = e instanceof Stop ? e.code : 'unexpected';
  }

  // Alerts: judged on what actually happened (an executed run), never on a dry run's estimate.
  if (!opts.dryRun) {
    const lost = report.expire?.expiredVerified ?? 0;
    if (lost >= opts.alertVerifiedLost) report.alerts.push({ code: 'verified_rewards_expired_unused', value: lost, threshold: opts.alertVerifiedLost });
    const incomplete = (report.expire !== null && !report.expire.complete) || (report.purge !== null && !report.purge.complete);
    if (incomplete && report.error === null) report.alerts.push({ code: 'backlog_remaining', value: (report.expire?.expired ?? 0) + (report.purge?.deleted ?? 0), threshold: opts.batchSize * opts.maxBatches });

    // One audit row for the run, even a failed one (it records how far it got). Its own failure never undoes the batches (they are
    // committed and repeat-safe); it is reported.
    try {
      await repo.recordRun({
        expired: report.expire?.expired ?? 0,
        expiredVerified: report.expire?.expiredVerified ?? 0,
        purged: report.purge?.deleted ?? 0,
        retentionDays: opts.retentionDays,
        stopped: report.error === null ? 0 : 1,
        alerts: report.alerts.length,
      });
    } catch {
      if (report.error === null) report.error = 'audit_unavailable';
    }
  }

  for (const a of report.alerts) logger?.warn({ event: 'reward_maintenance.alert', ...a });
  if (report.error) logger?.error({ event: 'reward_maintenance.failed', code: report.error });
  else logger?.info({ event: 'reward_maintenance.done', dryRun: report.dryRun, expired: report.expire?.expired ?? 0, purged: report.purge?.deleted ?? 0 });
  return report;
}

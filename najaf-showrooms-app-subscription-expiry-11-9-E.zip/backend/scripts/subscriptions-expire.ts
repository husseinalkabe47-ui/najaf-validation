// Operator tool (Phase 11.9-E): expires the subscriptions whose paid period has ended. DRY-RUN by default.
//   npm run subscriptions:expire                       count only (nothing is changed)
//   npm run subscriptions:expire -- --execute          expire them (one audit row each)
// Options (all optional): --batch-size=N (1-1000, default 200)  --max-batches=N (1-100, default 10)
// Reads the same environment as the server (database only). Run it from a scheduler or by hand; the server never starts it.
// Repeat-safe and safe to run twice at once: a rerun finds nothing left. Prints ONE JSON report with counts only.
// Exit codes: 0 done (also when a bound was reached: see "complete" and the backlog_remaining alert), 1 the run stopped on a database
// failure, 64 invalid arguments, 78 invalid configuration.
import { ConfigError, describeDbTarget, loadConfig } from '../src/config.ts';
import { createDb } from '../src/db.ts';
import { describeError } from '../src/errors.ts';
import { ExpiryOptionsError, resolveExpiryOptions, runSubscriptionExpiry } from '../src/subscriptions/expiry.ts';
import type { ExpiryLogger, ExpiryOptions } from '../src/subscriptions/expiry.ts';
import { createPgSubscriptionExpiryRepository } from '../src/subscriptions/expiry-repository.ts';

const EX_USAGE = 64;
const EX_CONFIG = 78;

/** Parses the command line. Throws ExpiryOptionsError naming the offending arguments (never echoing values). */
export function parseExpiryArgs(argv: readonly string[]): ExpiryOptions {
  const input: Partial<ExpiryOptions> = {};
  const problems: string[] = [];
  const NUM = /^[1-9][0-9]{0,5}$/;
  for (const arg of argv) {
    const eq = arg.indexOf('=');
    const name = eq === -1 ? arg : arg.slice(0, eq);
    const value = eq === -1 ? undefined : arg.slice(eq + 1);
    const flag = (set: () => void) => (value === undefined ? set() : problems.push(name));
    const num = (set: (n: number) => void) => (value !== undefined && NUM.test(value) ? set(Number(value)) : problems.push(name));
    switch (name) {
      case '--execute': flag(() => (input.dryRun = false)); break;
      case '--dry-run': flag(() => (input.dryRun = true)); break;
      case '--batch-size': num((n) => (input.batchSize = n)); break;
      case '--max-batches': num((n) => (input.maxBatches = n)); break;
      default: problems.push(/^--[a-z-]{1,30}$/.test(name) ? name : 'unknown argument');
    }
  }
  const ARG: Record<string, string> = { batchSize: '--batch-size', maxBatches: '--max-batches' };
  try {
    const opts = resolveExpiryOptions(input);
    if (problems.length === 0) return opts;
  } catch (e) {
    if (!(e instanceof ExpiryOptionsError)) throw e;
    for (const p of e.problems) problems.push(ARG[p] ?? p);
  }
  throw new ExpiryOptionsError(problems);
}

const logger: ExpiryLogger = {
  info: (o) => console.error(JSON.stringify({ level: 'info', ...o })),
  warn: (o) => console.error(JSON.stringify({ level: 'warn', ...o })),
  error: (o) => console.error(JSON.stringify({ level: 'error', ...o })),
};

async function run(): Promise<number> {
  let opts: ExpiryOptions;
  try {
    opts = parseExpiryArgs(process.argv.slice(2));
  } catch (e) {
    if (e instanceof ExpiryOptionsError) {
      console.error(JSON.stringify({ ok: false, invalidArguments: e.problems }, null, 2));
      return EX_USAGE;
    }
    throw e;
  }
  let config;
  try {
    config = loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      console.error(JSON.stringify({ ok: false, configProblems: e.problems }, null, 2));
      return EX_CONFIG;
    }
    throw e;
  }
  const db = await createDb(config.db);
  try {
    const report = await runSubscriptionExpiry({ repo: createPgSubscriptionExpiryRepository(db), logger }, opts);
    const ok = report.error === null;
    (ok ? console.log : console.error)(JSON.stringify({ ok, ...report }, null, 2));
    return ok ? 0 : 1;
  } catch (e) {
    console.error(JSON.stringify({ ok: false, target: describeDbTarget(config.db), error: describeError(e) }, null, 2));
    return 1;
  } finally {
    await db.close();
  }
}

// Run only as a script (the argument parser is imported by the unit tests).
if (import.meta.filename === process.argv[1]) process.exitCode = await run();

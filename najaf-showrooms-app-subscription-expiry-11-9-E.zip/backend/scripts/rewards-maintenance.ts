// Operator tool (Phase 11.8-G): expires abandoned reward grants and deletes old dead ones. DRY-RUN by default.
//   npm run rewards:maintenance                       count only (nothing is changed)
//   npm run rewards:maintenance -- --execute          expire, then purge
// Options (all optional): --batch-size=N (1-1000, default 500)  --max-batches=N (1-100, default 10)
//   --retention-days=N (7-365, default 30: expired/failed grants are deleted only after this)
//   --alert-verified-lost=N (1-100000, default 10)  --skip-expire  --skip-purge
// Reads the same environment as the server (database only). Run it from a scheduler or by hand; the server never starts it.
// Prints ONE JSON report with counts only. Alerts are listed in "alerts" and logged to stderr as events.
// Exit codes: 0 done (also when a bound was reached: see "complete" and the backlog_remaining alert), 1 the run stopped on a database
// failure, 64 invalid arguments, 78 invalid configuration.
import { ConfigError, describeDbTarget, loadConfig } from '../src/config.ts';
import { createDb } from '../src/db.ts';
import { describeError } from '../src/errors.ts';
import { MaintenanceOptionsError, resolveMaintenanceOptions, runRewardMaintenance } from '../src/rewards/maintenance.ts';
import type { MaintenanceLogger, MaintenanceOptions } from '../src/rewards/maintenance.ts';
import { createPgMaintenanceRepository } from '../src/rewards/maintenance-repository.ts';

const EX_USAGE = 64;
const EX_CONFIG = 78;

/** Parses the command line. Throws MaintenanceOptionsError naming the offending arguments (never echoing values). */
export function parseMaintenanceArgs(argv: readonly string[]): MaintenanceOptions {
  const input: Partial<MaintenanceOptions> = {};
  const problems: string[] = [];
  const NUM = /^[1-9][0-9]{0,5}$/;
  for (const arg of argv) {
    const eq = arg.indexOf('=');
    const name = eq === -1 ? arg : arg.slice(0, eq);
    const value = eq === -1 ? undefined : arg.slice(eq + 1);
    const flag = (set: () => void) => (value === undefined ? set() : problems.push(name));
    const num = (set: (n: number) => void) => (value !== undefined && NUM.test(value) ? set(Number(value)) : problems.push(name));
    switch (name) {
      case '--execute': flag(() => (input.dryRun = false)); break;
      case '--dry-run': flag(() => (input.dryRun = true)); break;
      case '--skip-expire': flag(() => (input.expire = false)); break;
      case '--skip-purge': flag(() => (input.purge = false)); break;
      case '--batch-size': num((n) => (input.batchSize = n)); break;
      case '--max-batches': num((n) => (input.maxBatches = n)); break;
      case '--retention-days': num((n) => (input.retentionDays = n)); break;
      case '--alert-verified-lost': num((n) => (input.alertVerifiedLost = n)); break;
      default: problems.push(/^--[a-z-]{1,30}$/.test(name) ? name : 'unknown argument');
    }
  }
  const ARG: Record<string, string> = { batchSize: '--batch-size', maxBatches: '--max-batches', retentionDays: '--retention-days', alertVerifiedLost: '--alert-verified-lost', nothingToDo: '--skip-expire/--skip-purge' };
  try {
    const opts = resolveMaintenanceOptions(input);
    if (problems.length === 0) return opts;
  } catch (e) {
    if (!(e instanceof MaintenanceOptionsError)) throw e;
    for (const p of e.problems) problems.push(ARG[p] ?? p);
  }
  throw new MaintenanceOptionsError(problems);
}

const logger: MaintenanceLogger = {
  info: (o) => console.error(JSON.stringify({ level: 'info', ...o })),
  warn: (o) => console.error(JSON.stringify({ level: 'warn', ...o })),
  error: (o) => console.error(JSON.stringify({ level: 'error', ...o })),
};

async function run(): Promise<number> {
  let opts: MaintenanceOptions;
  try {
    opts = parseMaintenanceArgs(process.argv.slice(2));
  } catch (e) {
    if (e instanceof MaintenanceOptionsError) {
      console.error(JSON.stringify({ ok: false, invalidArguments: e.problems }, null, 2));
      return EX_USAGE;
    }
    throw e;
  }
  let config;
  try {
    config = loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      console.error(JSON.stringify({ ok: false, configProblems: e.problems }, null, 2));
      return EX_CONFIG;
    }
    throw e;
  }
  const db = await createDb(config.db);
  try {
    const report = await runRewardMaintenance({ repo: createPgMaintenanceRepository(db), logger }, opts);
    const ok = report.error === null;
    (ok ? console.log : console.error)(JSON.stringify({ ok, ...report }, null, 2));
    return ok ? 0 : 1;
  } catch (e) {
    console.error(JSON.stringify({ ok: false, target: describeDbTarget(config.db), error: describeError(e) }, null, 2));
    return 1;
  } finally {
    await db.close();
  }
}

// Run only as a script (the argument parser is imported by the unit tests).
if (import.meta.filename === process.argv[1]) process.exitCode = await run();

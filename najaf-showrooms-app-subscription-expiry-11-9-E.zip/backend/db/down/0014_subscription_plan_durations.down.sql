DELETE FROM subscription_plans WHERE code IN ('plan_3m', 'plan_6m', 'plan_12m');
ALTER TABLE subscription_plans DROP CONSTRAINT plans_priced_needs_interval;
ALTER TABLE subscription_plans ADD CONSTRAINT plans_priced_needs_interval CHECK (price = 0 OR billing_interval IS NOT NULL);
DROP INDEX IF EXISTS plans_duration_uq;
ALTER TABLE subscription_plans DROP CONSTRAINT plans_duration_vocab;
ALTER TABLE subscription_plans DROP COLUMN duration_months;

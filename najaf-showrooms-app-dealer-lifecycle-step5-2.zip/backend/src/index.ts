// Process entry point: configuration -> database -> role/schema policy -> HTTP server -> graceful shutdown.
// Security failures (bad configuration, privileged database role, missing schema) stop the process with exit code 78.
import { ConfigError, describeDbTarget, loadConfig, redactConfig } from './config.ts';
import { AuthConfigError, loadAuthConfig, redactAuthConfig } from './auth/config.ts';
import { createAccountService } from './auth/account-service.ts';
import { createOtpService } from './auth/otp-service.ts';
import { createArgon2idHasher } from './auth/password.ts';
import { createMemoryRateLimiter } from './auth/rate-limit.ts';
import { createPgAuthStore } from './auth/repository.ts';
import { createAuthService } from './auth/service.ts';
import { createDb } from './db.ts';
import { createPgDealerStore } from './dealers/repository.ts';
import { createDealerService } from './dealers/service.ts';
import { createUnconfiguredMessagingProvider } from './messaging/provider.ts';
import { describeError } from './errors.ts';
import { RoleError, assertAppRole } from './role.ts';
import { buildServer } from './server.ts';
import { createConsoleLogger } from './types.ts';

const EX_CONFIG = 78;
const boot = createConsoleLogger();

async function main(): Promise<void> {
  let config;
  try {
    config = loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      boot.error({ problems: e.problems }, 'invalid configuration');
      process.exit(EX_CONFIG);
    }
    throw e;
  }
  boot.info({ config: redactConfig(config) }, 'configuration loaded');

  let authConfig;
  try {
    authConfig = loadAuthConfig();
  } catch (e) {
    if (e instanceof AuthConfigError) {
      boot.error({ problems: e.problems }, 'invalid authentication configuration');
      process.exit(EX_CONFIG);
    }
    throw e;
  }
  boot.info({ auth: redactAuthConfig(authConfig) }, 'authentication configuration loaded');

  const db = await createDb(config.db, { logger: boot });
  try {
    await db.ping();
    if (config.db.requireAppRole) assertAppRole(await db.verifyRole());
    const { missing } = await db.checkSchema();
    if (missing.length > 0) {
      boot.error({ missing }, 'database schema does not satisfy the backend contract (apply database/migrations 0001-0013)');
      await db.close();
      process.exit(EX_CONFIG);
    }
  } catch (e) {
    if (e instanceof RoleError) {
      boot.error({ violations: e.violations, target: describeDbTarget(config.db) }, 'refusing to run with a privileged database role');
      await db.close();
      process.exit(EX_CONFIG);
    }
    boot.error({ err: describeError(e), target: describeDbTarget(config.db) }, 'database startup check failed');
    await db.close();
    process.exit(1);
  }

  // Authentication needs argon2: prove the native module works BEFORE accepting traffic.
  const hasher = createArgon2idHasher();
  try {
    await hasher.ready();
  } catch (e) {
    boot.error({ err: describeError(e) }, 'password hasher (argon2) is not usable');
    await db.close();
    process.exit(1);
  }
  const auth = createAuthService({ store: createPgAuthStore(db), hasher, accessTokenSecret: authConfig.accessTokenSecret, logger: boot });

  // No SMS/WhatsApp provider is integrated yet: the OTP flows run end to end, but nothing can be delivered. Say so loudly.
  boot.warn({ event: 'messaging.provider_not_configured' }, 'no messaging provider is configured: one-time codes cannot be delivered');
  const otp = createOtpService({ store: createPgAuthStore(db), hasher, provider: createUnconfiguredMessagingProvider(), otpSecret: authConfig.accessTokenSecret, logger: boot });

  const account = createAccountService({ store: createPgAuthStore(db), hasher, logger: boot });

  const dealers = { registration: auth, lifecycle: createDealerService({ store: createPgDealerStore(db), logger: boot }) };

  const app = await buildServer({ config, db, auth, otp, account, dealers, rateLimiter: createMemoryRateLimiter(), trustProxy: authConfig.trustedProxies });
  await app.listen({ host: config.server.host, port: config.server.port });

  let stopping = false;
  const stop = async (signal: string): Promise<void> => {
    if (stopping) return;
    stopping = true;
    app.log.info({ signal }, 'shutting down');
    const force = setTimeout(() => process.exit(1), 10_000);
    force.unref();
    try {
      await app.close();
      await db.close();
      process.exit(0);
    } catch (e) {
      app.log.error({ err: describeError(e) }, 'shutdown failed');
      process.exit(1);
    }
  };
  process.on('SIGTERM', () => void stop('SIGTERM'));
  process.on('SIGINT', () => void stop('SIGINT'));
}

main().catch((e) => {
  boot.error({ err: describeError(e) }, 'fatal startup error');
  process.exit(1);
});

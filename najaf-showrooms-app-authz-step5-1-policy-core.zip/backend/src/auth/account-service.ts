// Account and session security for the AUTHENTICATED user: change password, sign out from all devices.
//
// Decisions (each is covered by tests):
//  - Ownership: the user id is a parameter that the HTTP layer takes from the VERIFIED access token. Nothing here reads a user
//    id from a request body, and the input parsers reject unknown fields, so a client cannot name another user.
//  - Change password REQUIRES the current password. Wrong attempts are counted like failed logins (same counter, same
//    lockout), so a stolen access token cannot be used to guess the password beyond 5 tries; while the account is locked the
//    current password is not even checked. Nothing here can tell the caller anything about OTHER accounts.
//  - The new password gets the full existing policy, and may not equal the current one. The policy is checked FIRST (a weak
//    password costs no attempt and no hashing); "same as current" is reported only after the current password was proved.
//  - Changing the password ends EVERY session of the user, INCLUDING the one that made the request. That is the project's
//    existing model (the users_revoke_sessions trigger revokes all sessions when password_hash changes; recovery does the
//    same), it avoids minting tokens inside a password change, and an attacker holding any session loses it. The cost is one
//    sign-in on this device with the new password.
//  - The swap is compare-and-swap on the stored hash: of two simultaneous changes that both proved the same current
//    password, only one applies; the other is told the current password is no longer correct.
//  - Sign out everywhere uses revokeAllLive (lock, then a fresh-snapshot UPDATE), so a refresh that is in flight cannot leave
//    a live session behind; a refresh that starts afterwards finds its row revoked. It never creates a session.
//  - Each action and its audit row are ONE transaction: no password change or revocation without its audit event, and no event
//    for something that did not happen. The audit data is numbers only.
import { randomBytes } from 'node:crypto';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import type { PasswordHasher } from './password.ts';
import type { AuthStore } from './repository.ts';
import { AuthError } from './types.ts';
import type { AccountApi, AccountContext } from './types.ts';
import { parseChangePasswordInput } from './validation.ts';

export function createAccountService(deps: { store: AuthStore; hasher: PasswordHasher; logger?: Logger }): AccountApi {
  const { store, hasher } = deps;
  const logger = deps.logger ?? nullLogger;

  // A real argon2 hash of a random value, computed once, for the "account is locked" path (same cost as a real check).
  let dummy: Promise<string> | undefined;
  const dummyHash = (): Promise<string> => (dummy ??= hasher.hash(randomBytes(16).toString('hex')));

  async function changePassword(userId: string, input: unknown, ctx: AccountContext = {}): Promise<{ status: 'password_changed' }> {
    const parsed = parseChangePasswordInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const { currentPassword, newPassword } = parsed.value;

    const cred = await store.users.findCredentialsById(userId);
    if (!cred || cred.status !== 'active') throw new AuthError('unauthorized'); // suspended/pending/deleted: same as the token check

    if (cred.locked) {
      await hasher.verify(await dummyHash(), currentPassword);
      logger.info({ event: 'auth.password_change.rejected', reason: 'locked', userId });
      throw new AuthError('invalid_current_password');
    }
    if (!(await hasher.verify(cred.passwordHash, currentPassword))) {
      await store.users.recordFailedLogin(userId); // counted exactly like a failed login (and committed)
      logger.info({ event: 'auth.password_change.rejected', reason: 'wrong_password', userId });
      throw new AuthError('invalid_current_password');
    }
    if (newPassword === currentPassword) throw new AuthError('validation_failed', [{ field: 'newPassword', code: 'same_as_current' }]);

    const newHash = await hasher.hash(newPassword); // slow: done before the transaction, so no lock is held meanwhile

    const revoked = await store.transaction(async ({ users, sessions, audit }) => {
      const ended = await sessions.revokeAllLive(userId, 'password_changed');
      if (!(await users.changePasswordIf(userId, cred.passwordHash, newHash))) {
        // A concurrent change won. Throwing rolls back the revocation above as well: nothing happened here.
        throw new AuthError('invalid_current_password');
      }
      await audit.record({ action: 'auth.password_changed', actorUserId: userId, actorRole: cred.role, entityType: 'user', entityId: userId, afterData: { sessions_revoked: ended }, requestId: ctx.requestId });
      return ended;
    });
    logger.info({ event: 'auth.password_changed', userId, sessionsRevoked: revoked });
    return { status: 'password_changed' };
  }

  async function logoutAll(userId: string, ctx: AccountContext = {}): Promise<{ status: 'signed_out_everywhere' }> {
    const user = await store.users.findById(userId);
    if (!user || user.status !== 'active') throw new AuthError('unauthorized');
    const revoked = await store.transaction(async ({ sessions, audit }) => {
      const ended = await sessions.revokeAllLive(userId, 'logout_all');
      await audit.record({ action: 'auth.logout_all', actorUserId: userId, actorRole: user.role, entityType: 'user', entityId: userId, afterData: { sessions_revoked: ended }, requestId: ctx.requestId });
      return ended;
    });
    logger.info({ event: 'auth.logout_all', userId, sessionsRevoked: revoked });
    return { status: 'signed_out_everywhere' };
  }

  return { changePassword, logoutAll };
}

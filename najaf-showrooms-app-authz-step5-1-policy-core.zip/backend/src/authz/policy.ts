// Authorization core (Phase 11.5, Step 5.1): PRIVATE authorization as pure, deny-by-default functions.
//
// can(actor, action, resource) answers only "may this authenticated actor do this to this resource?". No I/O, no request data.
// A null actor (guest, or an account that may not act) is never allowed. An unknown action or kind is never allowed.

import type { Actor } from './actor.ts';
import type { Resource } from './resources.ts';

export type Action = 'read' | 'update' | 'delete' | 'moderate';

const ACTIONS: ReadonlySet<string> = new Set<Action>(['read', 'update', 'delete', 'moderate']);

const isAdmin = (a: Actor) => a.role === 'admin';
/** A dealer owns a showroom (and so its cars) by id. A member can never act as a showroom owner. */
const isDealerOwner = (a: Actor, ownerId: string) => a.role === 'dealer' && a.id === ownerId;
const isSelf = (a: Actor, userId: string) => a.id === userId;

export function can(actor: Actor | null, action: Action, resource: Resource): boolean {
  if (!actor || typeof actor !== 'object') return false;
  if (!ACTIONS.has(action)) return false;
  if (typeof resource !== 'object' || resource === null) return false;

  switch (resource.kind) {
    case 'user':
      // Own profile: read and update. Administrators read any account and moderate (suspend/restore) it; they do not edit profiles.
      if (action === 'read') return isSelf(actor, resource.id) || isAdmin(actor);
      if (action === 'update') return isSelf(actor, resource.id);
      if (action === 'moderate') return isAdmin(actor);
      return false;

    case 'showroom':
      // The owner manages the showroom even while it is not public (pending/suspended); only an administrator deletes or moderates.
      if (action === 'read' || action === 'update') return isAdmin(actor) || isDealerOwner(actor, resource.ownerId);
      return isAdmin(actor);

    case 'showroom_car':
      if (action === 'moderate') return isAdmin(actor);
      return isAdmin(actor) || isDealerOwner(actor, resource.showroomOwnerId);

    case 'member_car':
      // The owner (by id, never by role) manages their own ad; an administrator may read, delete and moderate any ad but not rewrite it.
      if (action === 'read' || action === 'delete') return isSelf(actor, resource.ownerId) || isAdmin(actor);
      if (action === 'update') return isSelf(actor, resource.ownerId);
      return isAdmin(actor);

    case 'favorite':
      // Strictly the owner: not even an administrator (least privilege).
      return action !== 'moderate' && isSelf(actor, resource.userId);

    default:
      return false;
  }
}

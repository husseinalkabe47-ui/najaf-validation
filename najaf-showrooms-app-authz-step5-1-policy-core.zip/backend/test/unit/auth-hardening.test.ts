// Step 5.0 hardening: (1) a login cannot create a live session from stale credentials, (2) a successful password recovery is
// audited, (3) one authoritative session-revocation mechanism. Nothing here depends on timing: a login is FROZEN between its
// password verification and its transaction by a wrapped store, and the competing operation runs while it is frozen.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { createAccountService } from '../../src/auth/account-service.ts';
import { createOtpService } from '../../src/auth/otp-service.ts';
import { createPgSessionsRepository, createPgUsersRepository } from '../../src/auth/repository.ts';
import type { AuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { Tx } from '../../src/db.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeProvider } from '../helpers/fake-messaging.ts';

const SECRET = 'hardening-test-secret-0123456789abcdef-QWERTY';
const OLD = 'Old-Passw0rd-123';
const NEW = 'Brand-New-Passw0rd';
const PHONE_E164 = '+9647701234567';
const reg = { name: 'علي حسين', phone: '07701234567', password: OLD };

function setup() {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher, calls } = makeFakeHasher();
  const log = recordingLogger();
  const msg = makeFakeProvider();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const account = createAccountService({ store: db.store, hasher, logger: log.logger });
  const otp = createOtpService({ store: db.store, hasher, provider: msg.provider, otpSecret: SECRET, logger: log.logger });
  return { clock, db, hasher, calls, log, msg, auth, account, otp };
}
type Env = ReturnType<typeof setup>;
const live = (env: Env) => env.db.sessions().filter((s) => s.revokedAt === null);
async function failure(p: Promise<unknown>): Promise<AuthError> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
    return e;
  }
  throw new Error('expected a failure');
}
const shape = (e: AuthError) => JSON.stringify({ code: e.code, message: e.message, fields: e.fields });

/**
 * A login service whose transaction is held back until `count` logins have verified their password; then `hook` runs (the
 * competing operation, through the REAL services), and only after it the logins are let through. So every login has verified
 * the credentials as they were BEFORE the hook, and creates its session AFTER it.
 */
function stalledLogins(env: Env, count: number, hook: () => Promise<void>) {
  const real = env.db.store;
  let reached = 0;
  let release!: () => void;
  const gate = new Promise<void>((resolve) => (release = resolve));
  const store: AuthStore = {
    ...real,
    transaction: (async (fn: Parameters<AuthStore['transaction']>[0]) => {
      reached += 1;
      if (reached === count) {
        await hook();
        release();
      }
      await gate;
      return real.transaction(fn);
    }) as AuthStore['transaction'],
  };
  return createAuthService({ store, hasher: env.hasher, accessTokenSecret: SECRET, logger: env.log.logger, now: env.clock.now });
}

async function registered(env: Env, extraLogins = 0) {
  const first = await env.auth.register(reg);
  const sessions = [first];
  for (let i = 0; i < extraLogins; i++) sessions.push(await env.auth.login({ phone: reg.phone, password: OLD }));
  return { userId: first.user.id, sessions };
}

describe('login: credentials verified before a change can never become a live session after it', () => {
  it('control: with no competing change, the compare-and-swap succeeds and the login works as before', async () => {
    const env = setup();
    await registered(env);
    const before = env.db.counters.loginCas;
    const r = await env.auth.login({ phone: reg.phone, password: OLD });
    assert.ok(await env.auth.authenticate(r.session.accessToken));
    assert.equal(env.db.counters.loginCas, before + 1);
    assert.ok(env.db.users()[0]?.lastLoginAt instanceof Date);
  });

  it('a password CHANGE that commits between the verification and the session creation: the login fails and creates NO session', async () => {
    const env = setup();
    const { userId } = await registered(env);
    const rows = env.db.sessions().length;
    const stalled = stalledLogins(env, 1, async () => void (await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW })));
    const e = await failure(stalled.login({ phone: reg.phone, password: OLD }));
    assert.equal(e.code, 'invalid_credentials');
    assert.equal(env.db.sessions().length, rows, 'no session row was created by the stale login');
    assert.equal(live(env).length, 0, 'and nothing is live');
    assert.equal((await env.auth.login({ phone: reg.phone, password: NEW })).user.id, userId, 'the new password works');
  });

  it('the failure is the SAME generic error as a wrong password: it does not reveal that the password changed', async () => {
    const env = setup();
    const { userId } = await registered(env);
    const wrong = await failure(env.auth.login({ phone: reg.phone, password: 'definitely-not-it' }));
    const stalled = stalledLogins(env, 1, async () => void (await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW })));
    const stale = await failure(stalled.login({ phone: reg.phone, password: OLD }));
    assert.equal(shape(stale), shape(wrong));
    assert.equal(shape(stale), shape(await failure(env.auth.login({ phone: '07709999999', password: OLD }))), 'and as an unknown account');
  });

  it('a stale outcome is not a failed password: it does not count toward the lockout', async () => {
    const env = setup();
    const { userId } = await registered(env);
    const stalled = stalledLogins(env, 1, async () => void (await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW })));
    await failure(stalled.login({ phone: reg.phone, password: OLD }));
    assert.equal(env.db.users()[0]?.failedLogins, 0);
    assert.equal(env.db.users()[0]?.locked, false);
  });

  it('a password RECOVERY that commits in between: the login fails and creates no session', async () => {
    const env = setup();
    const { userId } = await registered(env);
    await env.otp.requestPasswordReset({ phone: reg.phone });
    const code = env.msg.lastCode(PHONE_E164, 'password_reset')!;
    const rows = env.db.sessions().length;
    const stalled = stalledLogins(env, 1, async () => void (await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW })));
    assert.equal((await failure(stalled.login({ phone: reg.phone, password: OLD }))).code, 'invalid_credentials');
    assert.equal(env.db.sessions().length, rows);
    assert.equal(live(env).length, 0);
    assert.ok(await env.auth.login({ phone: reg.phone, password: NEW }));
    assert.equal(env.db.users()[0]?.id, userId);
  });

  it('a SUSPENSION or a DELETION in between also refuses the login (the compare-and-swap checks the account is still active)', async () => {
    for (const how of ['suspended', 'deleted'] as const) {
      const env = setup();
      const { userId } = await registered(env);
      const rows = env.db.sessions().length;
      const stalled = stalledLogins(env, 1, async () => {
        if (how === 'suspended') env.db.setStatus(userId, 'suspended');
        else env.db.users()[0]!.deletedAt = new Date();
      });
      assert.equal((await failure(stalled.login({ phone: reg.phone, password: OLD }))).code, 'invalid_credentials', how);
      assert.equal(env.db.sessions().length, rows, how);
    }
  });

  it('SEVERAL logins that all verified the old password while the password is changed: every one fails, none leaves a live session', async () => {
    const env = setup();
    const { userId } = await registered(env, 1);
    const rows = env.db.sessions().length;
    const stalled = stalledLogins(env, 5, async () => void (await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW })));
    const results = await Promise.allSettled(Array.from({ length: 5 }, () => stalled.login({ phone: reg.phone, password: OLD })));
    assert.ok(results.every((r) => r.status === 'rejected' && (r.reason as AuthError).code === 'invalid_credentials'));
    assert.equal(env.db.sessions().length, rows, 'no stale session row exists');
    assert.equal(live(env).length, 0);
  });

  it('the other order: a login that finished BEFORE the change has its session ended by the change', async () => {
    const env = setup();
    const { userId } = await registered(env);
    const early = await env.auth.login({ phone: reg.phone, password: OLD });
    assert.ok(await env.auth.authenticate(early.session.accessToken));
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW });
    assert.equal(await env.auth.authenticate(early.session.accessToken), null);
    assert.equal((await failure(env.auth.refresh({ refreshToken: early.session.refreshToken }))).code, 'unauthorized');
    assert.equal(live(env).length, 0);
  });

  it('the stale outcome is logged by reason and user id only: no password, hash or token', async () => {
    const env = setup();
    const { userId } = await registered(env);
    const stalled = stalledLogins(env, 1, async () => void (await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW })));
    await failure(stalled.login({ phone: reg.phone, password: OLD }));
    const text = env.log.text();
    assert.ok(text.includes('stale_credentials'));
    for (const secret of [OLD, NEW, '$argon2', 'nsj_', 'eyJ', SECRET, '07701234567', PHONE_E164]) assert.ok(!text.includes(secret), secret);
  });
});

describe('login compare-and-swap statement', () => {
  const script = (rowCount: number) => {
    const calls: Array<{ text: string; values: readonly unknown[] }> = [];
    const tx: Tx = { query: async <R>(text: string, values: readonly unknown[] = []) => (calls.push({ text, values }), { rows: [] as R[], rowCount }) };
    return { tx, calls };
  };
  const HASH = '$argon2id$v=19$m=19456,p=1,t=2$c2FsdHNhbHRzYWx0c2FsdA$aGFzaGhhc2hoYXNoaGFzaGhhc2hoYXNoaGFzaGhhc2g';

  it('is ONE parameterized UPDATE that requires the verified hash, an active account and no deletion, and returns nothing', async () => {
    const { tx, calls } = script(1);
    assert.equal(await createPgUsersRepository(tx).recordSuccessfulLoginIf('7', HASH), true);
    assert.equal(calls.length, 1);
    assert.match(calls[0]!.text, /^\s*UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now\(\)\s+WHERE id = \$1 AND password_hash = \$2 AND status = 'active' AND deleted_at IS NULL\s*$/);
    assert.deepEqual(calls[0]!.values, ['7', HASH]);
    assert.ok(!/RETURNING|SELECT/i.test(calls[0]!.text), 'the stored hash is never read back');
  });

  it('answers false when nothing matched (stale hash, inactive, or deleted)', async () => {
    assert.equal(await createPgUsersRepository(script(0).tx).recordSuccessfulLoginIf('7', HASH), false);
  });

  it('binds hostile values and updates only columns the application role may update', async () => {
    const evil = "7'; UPDATE users SET role = 'admin'; --";
    const { tx, calls } = script(1);
    await createPgUsersRepository(tx).recordSuccessfulLoginIf(evil, evil);
    assert.ok(!calls[0]!.text.includes(evil) && !calls[0]!.text.includes("role = 'admin'"));
    const allowed = new Set(['failed_logins', 'locked_until', 'last_login_at']);
    const set = /SET\s+([\s\S]*?)\s+WHERE/.exec(calls[0]!.text)?.[1] ?? '';
    for (const col of set.match(/\b([a-z_]+)\s*=/g) ?? []) assert.ok(allowed.has(col.replace(/\s*=/, '')), col);
  });
});

describe('password recovery: the audit event', () => {
  async function pending(extraLogins = 0) {
    const env = setup();
    const r = await registered(env, extraLogins);
    await env.otp.requestPasswordReset({ phone: reg.phone });
    return { env, ...r, code: env.msg.lastCode(PHONE_E164, 'password_reset')! };
  }

  it('a successful reset writes exactly ONE auth.password_reset event: actor, role, entity, request id, and only the count of ended sessions', async () => {
    const { env, userId, code } = await pending(2);
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW }, { requestId: 'req-reset-001' });
    assert.equal(env.db.audits().length, 1);
    const a = env.db.audits()[0]!;
    assert.deepEqual({ action: a.action, actor: a.actorUserId, role: a.actorRole, type: a.entityType, id: a.entityId, data: a.afterData, req: a.requestId },
      { action: 'auth.password_reset', actor: userId, role: 'user', type: 'user', id: userId, data: { sessions_revoked: 3 }, req: 'req-reset-001' });
  });

  it('with no session to end the count is 0, and an absent request id is simply absent', async () => {
    const { env, code } = await pending();
    env.db.sessions().forEach((s) => (s.revokedAt = new Date()));
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW });
    assert.deepEqual(env.db.audits()[0]?.afterData, { sessions_revoked: 0 });
    assert.equal(env.db.audits()[0]?.requestId, undefined);
  });

  it('holds no secret: no code, password, hash, token, phone number or name', async () => {
    const { env, code, sessions } = await pending(1);
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW }, { requestId: 'req-reset-002' });
    const text = JSON.stringify(env.db.audits());
    for (const secret of [code, OLD, NEW, '$argon2', 'nsj_', 'eyJ', SECRET, PHONE_E164, '07701234567', '9647701234567', 'علي', sessions[0]!.session.refreshToken, sessions[0]!.session.accessToken]) {
      assert.ok(!text.includes(secret), `the audit trail must not contain ${secret}`);
    }
  });

  it('refusals write NO event: wrong code, replay of a used code, weak password, unknown phone, wrong purpose', async () => {
    const { env, code } = await pending();
    await failure(env.otp.resetPassword({ phone: reg.phone, code: code === '000000' ? '000001' : '000000', newPassword: NEW }));
    await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword: '1' }));
    await failure(env.otp.resetPassword({ phone: '07709999999', code, newPassword: NEW }));
    assert.equal(env.db.audits().length, 0);
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW });
    await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword: 'Another-New-Passw0rd' }));
    assert.equal(env.db.audits().length, 1, 'the replay added nothing');
  });

  it('is the ONLY event of the recovery flow: asking for a code and verifying a phone write none', async () => {
    const env = setup();
    const { userId } = await registered(env);
    await env.otp.requestPasswordReset({ phone: reg.phone });
    await env.otp.requestPhoneVerification(userId);
    await env.otp.confirmPhoneVerification(userId, { code: env.msg.lastCode(PHONE_E164, 'phone_verify')! });
    assert.equal(env.db.audits().length, 0);
  });

  it('is ATOMIC with the reset: if the event cannot be written, the password is unchanged, the code is NOT consumed, sessions live, and a retry with the same code works', async () => {
    const { env, userId, code, sessions } = await pending(1);
    const hash = env.db.users()[0]!.passwordHash;
    env.db.faults.failNextAudit = true;
    await assert.rejects(env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW }), /simulated audit insert failure/);
    assert.equal(env.db.users()[0]?.passwordHash, hash);
    assert.equal(env.db.codes()[0]?.consumedAt ?? null, null, 'the code was not spent');
    assert.equal(live(env).length, 2);
    assert.ok(await env.auth.authenticate(sessions[0]!.session.accessToken));
    assert.equal(env.db.audits().length, 0);
    assert.deepEqual(await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW }), { status: 'password_reset' });
    assert.equal(env.db.audits().length, 1);
    assert.equal(env.db.audits()[0]?.entityId, userId);
  });

  it('is atomic against ANY later failure in the transaction: a forced rollback leaves no audit row, no password change, no spent code', async () => {
    const { env, code } = await pending(1);
    const real = env.db.store.transaction.bind(env.db.store);
    const hash = env.db.users()[0]!.passwordHash;
    (env.db.store as { transaction: unknown }).transaction = (fn: Parameters<AuthStore['transaction']>[0]) =>
      real(async (repos) => {
        await fn(repos);
        throw new Error('forced rollback after everything ran');
      });
    await assert.rejects(env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW }), /forced rollback/);
    (env.db.store as { transaction: unknown }).transaction = real;
    assert.equal(env.db.audits().length, 0);
    assert.equal(env.db.users()[0]?.passwordHash, hash);
    assert.equal(env.db.codes()[0]?.consumedAt ?? null, null);
    assert.equal(live(env).length, 2);
  });

  it('two simultaneous resets with the same code: one wins, exactly one event', async () => {
    const { env, code } = await pending();
    const results = await Promise.allSettled([
      env.otp.resetPassword({ phone: reg.phone, code, newPassword: 'First-Candidate-1' }),
      env.otp.resetPassword({ phone: reg.phone, code, newPassword: 'Second-Candidate-2' }),
    ]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(env.db.audits().length, 1);
  });
});

describe('one authoritative session revocation', () => {
  const walk = (dir: string): string[] => readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? walk(join(dir, f)) : f.endsWith('.ts') ? [join(dir, f)] : []));
  const srcDir = join(import.meta.dirname, '..', '..', 'src');
  const sources = walk(srcDir).map((f) => ({ f: f.slice(srcDir.length + 1), text: readFileSync(f, 'utf8') }));
  const code = (t: string) => t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');

  it('the legacy single-UPDATE methods (revokeAllForUser, revokeFamilyByTokenHash) are kept only for their own tests: NO production code calls them', () => {
    for (const { f, text } of sources) {
      if (f === 'auth/repository.ts') continue; // where they are declared
      assert.ok(!/revokeAllForUser|revokeFamilyByTokenHash/.test(code(text)), f);
    }
  });

  it('revokeAllLive and revokeFamilyLive are ONE mechanism: both are thin calls of the single revokeLive helper, which is the only lock-then-update', () => {
    const repo = code(sources.find((x) => x.f === 'auth/repository.ts')!.text);
    assert.equal((repo.match(/async function revokeLive\(/g) ?? []).length, 1);
    assert.ok(/async revokeAllLive\(userId, reason\) \{\s*return revokeLive\(q, LIVE_SCOPE\.user, userId, reason\);\s*\}/.test(repo));
    assert.ok(/async revokeFamilyLive\(tokenHash\) \{\s*return revokeLive\(q, LIVE_SCOPE\.family, tokenHash, 'logout'\);\s*\}/.test(repo));
    assert.equal((repo.match(/ORDER BY id FOR UPDATE/g) ?? []).length, 1, 'the lock statement exists exactly once');
  });

  it('the three account flows and sign-out call ONLY the safe methods', () => {
    const calls = (file: string) => code(sources.find((x) => x.f === file)!.text);
    assert.ok(calls('auth/account-service.ts').includes("revokeAllLive(userId, 'password_changed')") && calls('auth/account-service.ts').includes("revokeAllLive(userId, 'logout_all')"));
    assert.ok(calls('auth/otp-service.ts').includes("revokeAllLive(user.id, 'password_changed')"));
    assert.ok(calls('auth/service.ts').includes('revokeFamilyLive'));
  });

  it('sign-out runs its revocation INSIDE a transaction (the row locks of revokeFamilyLive only live as long as one)', () => {
    const svc = code(sources.find((x) => x.f === 'auth/service.ts')!.text);
    const logout = svc.slice(svc.indexOf('async function logout('), svc.indexOf('async function', svc.indexOf('async function logout(') + 10));
    assert.ok(/store\.transaction\(\(\{ sessions \}\) => sessions\.revokeFamilyLive\(/.test(logout), 'revokeFamilyLive is called from inside store.transaction');
    assert.ok(!/store\.sessions\.revoke/.test(logout), 'and never straight on the store (autocommit)');
  });

  it('change password, sign out everywhere and password recovery ALL end sessions through revokeAllLive, each with its own reason', async () => {
    const env = setup();
    const { userId } = await registered(env, 1);
    await env.account.logoutAll(userId);
    assert.equal(env.db.counters.revokeAllLive, 1);
    assert.ok(env.db.sessions().every((s) => s.revokedReason === 'logout_all'));

    const second = setup();
    const { userId: u2 } = await registered(second, 1);
    await second.account.changePassword(u2, { currentPassword: OLD, newPassword: NEW });
    assert.equal(second.db.counters.revokeAllLive, 1);

    const third = setup();
    await registered(third, 1);
    await third.otp.requestPasswordReset({ phone: reg.phone });
    await third.otp.resetPassword({ phone: reg.phone, code: third.msg.lastCode(PHONE_E164, 'password_reset')!, newPassword: NEW });
    assert.equal(third.db.counters.revokeAllLive, 1);
    assert.ok(third.db.sessions().every((s) => s.revokedReason === 'password_changed'));
  });

  it('sign-out ends ONE login session through revokeFamilyLive (never the user-wide revocation): the other logins of the user keep working', async () => {
    const env = setup();
    const { sessions } = await registered(env, 1);
    await env.auth.logout({ refreshToken: sessions[0]!.session.refreshToken });
    assert.equal(env.db.counters.revokeFamilyLive, 1);
    assert.equal(env.db.counters.revokeAllLive, 0, 'sign-out does not use the user-wide revocation');
    assert.equal(await env.auth.authenticate(sessions[0]!.session.accessToken), null);
    assert.ok(await env.auth.authenticate(sessions[1]!.session.accessToken), 'the other login keeps working');
    assert.deepEqual(env.db.sessions().filter((x) => x.revokedAt !== null).map((x) => x.revokedReason), ['logout']);
  });

  it('recovery racing with a refresh cannot leave a live session, in either order', async () => {
    for (const order of ['refresh-first', 'reset-first'] as const) {
      const env = setup();
      const { sessions } = await registered(env);
      await env.otp.requestPasswordReset({ phone: reg.phone });
      const code = env.msg.lastCode(PHONE_E164, 'password_reset')!;
      const ops = [() => env.auth.refresh({ refreshToken: sessions[0]!.session.refreshToken }), () => env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW })];
      if (order === 'reset-first') ops.reverse();
      await Promise.allSettled(ops.map((f) => f()));
      assert.equal(live(env).length, 0, order);
    }
  });

  it('the login service uses the compare-and-swap, and it runs BEFORE the session is created', () => {
    const svc = code(sources.find((s) => s.f === 'auth/service.ts')!.text);
    const login = svc.slice(svc.indexOf('async function login('), svc.indexOf('async function refresh('));
    assert.ok(login.includes('recordSuccessfulLoginIf'));
    assert.ok(!/recordSuccessfulLogin\(/.test(login), 'the unconditional version is never used by a sign-in');
    assert.ok(login.indexOf('recordSuccessfulLoginIf') < login.indexOf('sessions.create'));
  });

  it('the recovery flow runs revokeAllLive before it changes the password and writes its event in the same transaction', () => {
    const svc = code(sources.find((s) => s.f === 'auth/otp-service.ts')!.text);
    const reset = svc.slice(svc.indexOf('async function resetPassword'));
    const [a, b, c] = [reset.indexOf('revokeAllLive'), reset.indexOf('users.resetPassword'), reset.indexOf("audit.record")];
    assert.ok(a > 0 && a < b && b < c, 'revoke, then change the password, then audit');
    assert.ok(reset.indexOf('hasher.hash') < a, 'the slow hash is computed before any session row is locked');
  });
});

describe('sign-out: the same lock-then-update, scoped to ONE login session (family)', () => {
  const run = (updated: number) => {
    const calls: Array<{ text: string; values: readonly unknown[] }> = [];
    const tx: Tx = {
      query: async <R>(text: string, values: readonly unknown[] = []) => {
        calls.push({ text, values });
        return (text.startsWith('UPDATE') ? { rows: [] as R[], rowCount: updated } : { rows: [{ id: 'a' }] as unknown as R[], rowCount: 1 });
      },
    };
    return { calls, revoke: (hash: Buffer) => createPgSessionsRepository(tx).revokeFamilyLive(hash) };
  };
  const HASH = Buffer.alloc(32, 7);

  it('runs exactly two statements in order: LOCK the live rows of the token\'s family, then UPDATE them with the reason logout', async () => {
    const { calls, revoke } = run(1);
    assert.equal(await revoke(HASH), 1);
    assert.equal(calls.length, 2);
    assert.match(calls[0]!.text, /^SELECT id FROM sessions WHERE family_id = \(SELECT family_id FROM sessions WHERE token_hash = \$1\) AND revoked_at IS NULL ORDER BY id FOR UPDATE$/);
    assert.deepEqual(calls[0]!.values, [HASH]);
    assert.match(calls[1]!.text, /^UPDATE sessions SET revoked_at = now\(\), revoked_reason = \$2 WHERE family_id = \(SELECT family_id FROM sessions WHERE token_hash = \$1\) AND revoked_at IS NULL$/);
    assert.deepEqual(calls[1]!.values, [HASH, 'logout']);
  });

  it('returns what the UPDATE changed (0 for an unknown token or an already ended session), never what the lock returned', async () => {
    assert.equal(await run(0).revoke(HASH), 0);
    assert.equal(await run(3).revoke(HASH), 3);
  });

  it('is scoped to one family: it never touches another family, other users or other columns', async () => {
    const { calls, revoke } = run(1);
    await revoke(HASH);
    for (const c of calls) assert.ok(c.text.includes('family_id =') && c.text.includes('revoked_at IS NULL'), c.text);
    assert.ok(!calls.some((c) => /INSERT|DELETE|user_id|revoked_at\s*=\s*NULL/.test(c.text)));
  });

  it('binds the token hash and the reason: nothing is spliced into the SQL', async () => {
    const evil = Buffer.from("x'; UPDATE sessions SET revoked_at = NULL; --");
    const { calls, revoke } = run(1);
    await revoke(evil);
    for (const c of calls) assert.ok(!c.text.includes('UPDATE sessions SET revoked_at = NULL') && !c.text.includes(evil.toString()), c.text);
    assert.equal(calls[1]!.values[1], 'logout');
  });

  it('the user-wide statements are exactly what they were (the shared helper changed no SQL text)', async () => {
    const calls: Array<{ text: string; values: readonly unknown[] }> = [];
    const tx: Tx = { query: async <R>(text: string, values: readonly unknown[] = []) => (calls.push({ text, values }), { rows: [] as R[], rowCount: 2 }) };
    await createPgSessionsRepository(tx).revokeAllLive('7', 'logout_all');
    assert.equal(calls[0]!.text, 'SELECT id FROM sessions WHERE user_id = $1 AND revoked_at IS NULL ORDER BY id FOR UPDATE');
    assert.equal(calls[1]!.text, 'UPDATE sessions SET revoked_at = now(), revoked_reason = $2 WHERE user_id = $1 AND revoked_at IS NULL');
  });

  it('through the service: it ends only that login session, with reason logout; an unknown token or a repeat is silent and changes nothing', async () => {
    const env = setup();
    const { sessions } = await registered(env, 1);
    await env.auth.logout({ refreshToken: sessions[0]!.session.refreshToken });
    await env.auth.logout({ refreshToken: sessions[0]!.session.refreshToken });
    await env.auth.logout({ refreshToken: 'nsj_' + 'C'.repeat(43) });
    assert.equal(live(env).length, 1);
    assert.equal(env.db.counters.revokeFamilyLive, 3);
  });

  it('a refresh racing with the sign-out of the same session cannot leave a live session, in either order', async () => {
    for (const order of ['refresh-first', 'logout-first'] as const) {
      const env = setup();
      const { sessions } = await registered(env);
      const token = sessions[0]!.session.refreshToken;
      const ops = [() => env.auth.refresh({ refreshToken: token }), () => env.auth.logout({ refreshToken: token })];
      if (order === 'logout-first') ops.reverse();
      await Promise.allSettled(ops.map((f) => f()));
      assert.equal(live(env).length, 0, order);
    }
  });

  it('the answers do not change: sign-out is still silent and a refresh after it is an ordinary refusal, not a reuse', async () => {
    const env = setup();
    const { sessions } = await registered(env);
    await env.auth.logout({ refreshToken: sessions[0]!.session.refreshToken });
    assert.equal((await failure(env.auth.refresh({ refreshToken: sessions[0]!.session.refreshToken }))).code, 'unauthorized');
    assert.ok(!env.db.sessions().some((x) => x.revokedReason === 'reuse_detected'));
  });
});

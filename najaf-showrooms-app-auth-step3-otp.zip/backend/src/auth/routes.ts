// HTTP contract for authentication (Phase 11.4). Thin by design: the decisions live in service.ts and in the pure
// helpers below. This file imports Fastify TYPES only, so the helpers are unit-testable without Fastify installed.
//
//   POST /v1/auth/register   {name, phone, password}  -> 201 {user, session}
//   POST /v1/auth/login      {phone, password}        -> 200 {user, session}
//   POST /v1/auth/refresh    {refreshToken}           -> 200 {user, session}   (the refresh token is rotated)
//   GET  /v1/auth/me         Authorization: Bearer <accessToken>  -> 200 {user}
//   POST /v1/auth/logout     {refreshToken}           -> 204
//   session = {accessToken, accessExpiresAt, refreshToken, refreshExpiresAt}
//
//   One-time codes (registered only when an OtpApi is supplied):
//   POST /v1/auth/phone/verify/request   Authorization: Bearer   -> 202 {status:'sent'} | 200 {status:'already_verified'}
//   POST /v1/auth/phone/verify/confirm   Bearer, {code}          -> 200 {user}
//   POST /v1/auth/password/forgot        {phone}                 -> 202 {status:'accepted'}  (ALWAYS, account or not)
//   POST /v1/auth/password/reset         {phone, code, newPassword} -> 200 {status:'password_reset'}
//
// Errors use the project's body shape { error: { code, message, requestId, fields? } }. Messages are fixed and generic.
// register/login/refresh/logout are rate limited per client address (429 + Retry-After) before the body is read.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { FieldError } from './validation.ts';
import { AuthError } from './types.ts';
import type { AuthApi, AuthContext, OtpApi } from './types.ts';
import type { RateLimitedRoute } from './policy.ts';
import { RATE_LIMITS } from './policy.ts';
import type { RateLimiter } from './rate-limit.ts';

export interface AuthHttpError {
  status: number;
  code: string;
  message: string;
  fields?: FieldError[];
  /** Only for 429 from a per-account throttle: seconds for the Retry-After header. */
  retryAfterSeconds?: number;
}

export function toAuthHttp(e: unknown): AuthHttpError | undefined {
  if (!(e instanceof AuthError)) return undefined;
  switch (e.code) {
    case 'validation_failed':
      return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    case 'conflict':
      return { status: 409, code: e.code, message: e.message };
    case 'invalid_code':
      return { status: 400, code: e.code, message: e.message };
    case 'rate_limited':
      return { status: 429, code: e.code, message: e.message, ...(e.retryAfterSeconds !== undefined ? { retryAfterSeconds: e.retryAfterSeconds } : {}) };
    case 'invalid_credentials':
    case 'unauthorized':
      return { status: 401, code: e.code, message: e.message };
  }
}

/** application/json, with optional parameters (e.g. charset), case-insensitive. Nothing else qualifies. */
export function isJsonContentType(value: unknown): boolean {
  return typeof value === 'string' && /^\s*application\/json\s*(;.*)?$/i.test(value);
}

// Fastify natively accepts BOTH application/json and text/plain. text/plain is a CORS "simple" content type (a cross-site
// page can send it without a preflight), and these endpoints take JSON only, so anything else is answered 415 here, in
// onRequest: before the body is read or parsed and before the service runs. (No content type at all: Fastify itself answers
// 415 when a body is present, and an empty body is a validation error.)
async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;

/**
 * Per-client-address limit for one route. request.ip is the socket address unless the server was built with a trusted
 * proxy list (AUTH_TRUSTED_PROXIES), in which case Fastify resolves X-Forwarded-For through those proxies only.
 */
export function rateLimitHook(limiter: RateLimiter, route: RateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`${route}:${request.ip}`, RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'auth.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

/** "Bearer <token>" (scheme case-insensitive, exactly one token, no extra spaces); anything else is undefined. */
export function bearerToken(header: unknown): string | undefined {
  if (typeof header !== 'string') return undefined;
  const m = /^Bearer ([^\s]+)$/i.exec(header);
  return m ? (m[1] as string) : undefined;
}

const contextOf = (request: FastifyRequest): AuthContext => {
  const ua = request.headers['user-agent'];
  return { userAgent: typeof ua === 'string' ? ua : undefined };
};

export function registerAuthRoutes(app: FastifyInstance, deps: { auth: AuthApi; otp?: OtpApi; rateLimiter?: RateLimiter }): void {
  const { auth, otp, rateLimiter } = deps;
  const limit = (route: RateLimitedRoute): Hook[] => (rateLimiter ? [rateLimitHook(rateLimiter, route)] : []);

  type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };
  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toAuthHttp(e);
    if (!mapped) throw e; // not an authentication error: the global error handler maps it (generic 4xx/5xx body)
    if (mapped.status === 401 && mapped.code === 'unauthorized') reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // Rate limit first (cheap), then the JSON-only check; both run in onRequest, before the body is read or parsed.
  const bodyRoute = (route: RateLimitedRoute) => ({ bodyLimit: 4096, onRequest: [...limit(route), requireJsonBody] });

  app.post('/v1/auth/register', bodyRoute('register'), async (request, reply) => {
    try {
      const result = await auth.register(request.body, contextOf(request));
      return reply.code(201).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/login', bodyRoute('login'), async (request, reply) => {
    try {
      const result = await auth.login(request.body, contextOf(request));
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/refresh', bodyRoute('refresh'), async (request, reply) => {
    try {
      const result = await auth.refresh(request.body, contextOf(request));
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/auth/me', async (request, reply) => {
    try {
      const found = await auth.authenticate(bearerToken(request.headers['authorization']));
      if (!found) throw new AuthError('unauthorized');
      return reply.code(200).send({ user: found.user });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/logout', bodyRoute('logout'), async (request, reply) => {
    try {
      await auth.logout(request.body);
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  // ---- one-time codes ----
  if (!otp) return;

  const limitOnly = (route: RateLimitedRoute) => {
    const hooks = limit(route);
    return hooks.length > 0 ? { onRequest: hooks } : {};
  };
  const requireAccess = async (request: FastifyRequest) => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return found;
  };

  app.post('/v1/auth/phone/verify/request', limitOnly('phoneVerifyRequest'), async (request, reply) => {
    try {
      const { user } = await requireAccess(request);
      const result = await otp.requestPhoneVerification(user.id);
      return reply.code(result.status === 'sent' ? 202 : 200).send({ status: result.status });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/phone/verify/confirm', bodyRoute('phoneVerifyConfirm'), async (request, reply) => {
    try {
      const { user } = await requireAccess(request);
      const verified = await otp.confirmPhoneVerification(user.id, request.body);
      return reply.code(200).send({ user: verified });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/password/forgot', bodyRoute('passwordForgot'), async (request, reply) => {
    try {
      const result = await otp.requestPasswordReset(request.body);
      return reply.code(202).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/password/reset', bodyRoute('passwordReset'), async (request, reply) => {
    try {
      const result = await otp.resetPassword(request.body);
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

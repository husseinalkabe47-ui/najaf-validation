// Server-side validation of authentication inputs. Strict: unknown fields are rejected, types are checked, lengths are
// bounded. Error objects carry only a field name and a machine code: they never echo the submitted values.
import { normalizeIraqiPhone } from './phone.ts';
import { NAME_MAX, NAME_MIN, PASSWORD_MAX, PASSWORD_MIN } from './policy.ts';
import { isWellFormedOtp } from './otp.ts';
import { isWellFormedToken } from './tokens.ts';

export type FieldCode = 'required' | 'invalid_type' | 'too_short' | 'too_long' | 'invalid_format' | 'unknown_field';
export interface FieldError {
  field: string;
  code: FieldCode;
}
export type Parsed<T> = { ok: true; value: T } | { ok: false; errors: FieldError[] };

export interface RegisterInput {
  name: string;
  /** Canonical E.164 (+9647XXXXXXXXX). */
  phone: string;
  password: string;
}
export interface LoginInput {
  phone: string;
  password: string;
}

const MAX_ERRORS = 10;
const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
// eslint-disable-next-line no-control-regex
const CONTROL_CHARS = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;

const codePoints = (s: string): number => Array.from(s).length;
const isPlainObject = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v) && Object.getPrototypeOf(v) === Object.prototype;

function unknownFields(body: Record<string, unknown>, allowed: readonly string[], errors: FieldError[]): void {
  for (const key of Object.keys(body)) {
    if (!allowed.includes(key)) errors.push({ field: SAFE_FIELD.test(key) ? key : 'unknown', code: 'unknown_field' });
  }
}

function parseName(value: unknown, errors: FieldError[]): string | undefined {
  if (value === undefined || value === null) return void errors.push({ field: 'name', code: 'required' });
  if (typeof value !== 'string') return void errors.push({ field: 'name', code: 'invalid_type' });
  const name = value.normalize('NFC').trim();
  if (CONTROL_CHARS.test(name)) return void errors.push({ field: 'name', code: 'invalid_format' });
  const n = codePoints(name);
  if (n < NAME_MIN) return void errors.push({ field: 'name', code: n === 0 ? 'required' : 'too_short' });
  if (n > NAME_MAX) return void errors.push({ field: 'name', code: 'too_long' });
  return name;
}

function parsePhone(value: unknown, errors: FieldError[]): string | undefined {
  if (value === undefined || value === null || value === '') return void errors.push({ field: 'phone', code: 'required' });
  if (typeof value !== 'string') return void errors.push({ field: 'phone', code: 'invalid_type' });
  const phone = normalizeIraqiPhone(value);
  if (phone === null) return void errors.push({ field: 'phone', code: 'invalid_format' });
  return phone;
}

// Passwords are never trimmed or normalized. mode 'new' enforces the minimum; 'existing' (login) only bounds the size.
// `field` names the input in error objects (registration: 'password'; recovery: 'newPassword'); the rules are the same.
function parsePassword(value: unknown, mode: 'new' | 'existing', errors: FieldError[], field = 'password'): string | undefined {
  if (value === undefined || value === null || value === '') return void errors.push({ field, code: 'required' });
  if (typeof value !== 'string') return void errors.push({ field, code: 'invalid_type' });
  if (value.includes('\u0000')) return void errors.push({ field, code: 'invalid_format' });
  const n = codePoints(value);
  if (n > PASSWORD_MAX) return void errors.push({ field, code: 'too_long' });
  if (mode === 'new' && n < PASSWORD_MIN) return void errors.push({ field, code: 'too_short' });
  return value;
}

export function parseRegisterInput(body: unknown): Parsed<RegisterInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  unknownFields(body, ['name', 'phone', 'password'], errors);
  const name = parseName(body['name'], errors);
  const phone = parsePhone(body['phone'], errors);
  const password = parsePassword(body['password'], 'new', errors);
  if (errors.length > 0 || name === undefined || phone === undefined || password === undefined) return { ok: false, errors: errors.slice(0, MAX_ERRORS) };
  return { ok: true, value: { name, phone, password } };
}

export function parseLoginInput(body: unknown): Parsed<LoginInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  unknownFields(body, ['phone', 'password'], errors);
  const phone = parsePhone(body['phone'], errors);
  const password = parsePassword(body['password'], 'existing', errors);
  if (errors.length > 0 || phone === undefined || password === undefined) return { ok: false, errors: errors.slice(0, MAX_ERRORS) };
  return { ok: true, value: { phone, password } };
}

export interface RefreshInput {
  refreshToken: string;
}

/** { refreshToken } and nothing else; the token must have the exact refresh-token shape (so garbage never reaches the database). */
export function parseRefreshInput(body: unknown): Parsed<RefreshInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  unknownFields(body, ['refreshToken'], errors);
  const value = body['refreshToken'];
  let token: string | undefined;
  if (value === undefined || value === null || value === '') errors.push({ field: 'refreshToken', code: 'required' });
  else if (typeof value !== 'string') errors.push({ field: 'refreshToken', code: 'invalid_type' });
  else if (!isWellFormedToken(value)) errors.push({ field: 'refreshToken', code: 'invalid_format' });
  else token = value;
  if (errors.length > 0 || token === undefined) return { ok: false, errors: errors.slice(0, MAX_ERRORS) };
  return { ok: true, value: { refreshToken: token } };
}

function parseCode(value: unknown, errors: FieldError[]): string | undefined {
  if (value === undefined || value === null || value === '') return void errors.push({ field: 'code', code: 'required' });
  if (typeof value !== 'string') return void errors.push({ field: 'code', code: 'invalid_type' });
  if (!isWellFormedOtp(value)) return void errors.push({ field: 'code', code: 'invalid_format' });
  return value;
}

export interface OtpConfirmInput {
  code: string;
}
/** { code } and nothing else. The code must be exactly 6 digits, so malformed guesses never reach the database. */
export function parseOtpConfirmInput(body: unknown): Parsed<OtpConfirmInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  unknownFields(body, ['code'], errors);
  const code = parseCode(body['code'], errors);
  if (errors.length > 0 || code === undefined) return { ok: false, errors: errors.slice(0, MAX_ERRORS) };
  return { ok: true, value: { code } };
}

export interface ForgotInput {
  phone: string;
}
export function parseForgotInput(body: unknown): Parsed<ForgotInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  unknownFields(body, ['phone'], errors);
  const phone = parsePhone(body['phone'], errors);
  if (errors.length > 0 || phone === undefined) return { ok: false, errors: errors.slice(0, MAX_ERRORS) };
  return { ok: true, value: { phone } };
}

export interface ResetInput {
  phone: string;
  code: string;
  newPassword: string;
}
/** The password policy is enforced HERE, before any code is looked at: a policy violation never burns an attempt. */
export function parseResetInput(body: unknown): Parsed<ResetInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  unknownFields(body, ['phone', 'code', 'newPassword'], errors);
  const phone = parsePhone(body['phone'], errors);
  const code = parseCode(body['code'], errors);
  const newPassword = parsePassword(body['newPassword'], 'new', errors, 'newPassword');
  if (errors.length > 0 || phone === undefined || code === undefined || newPassword === undefined) return { ok: false, errors: errors.slice(0, MAX_ERRORS) };
  return { ok: true, value: { phone, code, newPassword } };
}

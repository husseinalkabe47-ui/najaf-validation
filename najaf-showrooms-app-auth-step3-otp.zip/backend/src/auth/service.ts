// Authentication service: registration, credential verification (login), refresh-token rotation, authentication of an
// access token, logout.
//
// Security properties (each one is covered by tests):
//  - Passwords exist only as an argon2id hash; they are never logged, returned, or placed in an error.
//  - Every login failure is the SAME error (AuthError 'invalid_credentials'): unknown phone, wrong password, locked account
//    and non-active account are indistinguishable, and each performs exactly one argon2 verification (a dummy hash when the
//    account is unknown or locked), so neither the response nor the timing reveals whether an account exists.
//  - role/status are never inputs: registration always creates an active regular user.
//  - Two tokens per login: a 15-minute signed ACCESS token (sub + sid only) and an opaque 256-bit REFRESH token that is
//    shown once, stored only as SHA-256, rotated on every use, and absolute-limited to 30 days.
//  - Refresh-token reuse (presenting a token that was already exchanged) revokes the whole login session.
//  - Every request re-reads the session and the user from the database, so logout, suspension and reuse detection take
//    effect immediately, including for access tokens that have not expired yet. The role is never taken from a token.
//  - Every refresh failure (unknown, expired, revoked, reused, inactive account) is the same 'unauthorized' error.
import { randomBytes } from 'node:crypto';
import { DbError } from '../errors.ts';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import { signAccessToken, verifyAccessToken } from './access-token.ts';
import { MIN_SECRET_LENGTH } from './config.ts';
import { USER_AGENT_MAX } from './policy.ts';
import type { PasswordHasher } from './password.ts';
import type { AuthStore, NewSession, UserRow } from './repository.ts';
import { generateSessionToken, hashSessionToken, isWellFormedToken } from './tokens.ts';
import { AuthError } from './types.ts';
import type { AuthApi, AuthContext, AuthResult, AuthenticatedUser, PublicUser } from './types.ts';
import { parseLoginInput, parseRefreshInput, parseRegisterInput } from './validation.ts';

export function toPublicUser(u: UserRow): PublicUser {
  // Built field by field on purpose: a spread of the row could leak a column added later.
  return { id: u.id, name: u.name, phone: u.phoneE164, role: u.role, status: u.status, phoneVerified: u.phoneVerifiedAt !== null, createdAt: u.createdAt.toISOString() };
}

// eslint-disable-next-line no-control-regex
const NON_PRINTABLE = /[\u0000-\u001f\u007f-\u009f]/g;
function cleanUserAgent(ua: string | undefined): string | null {
  if (typeof ua !== 'string') return null;
  const cleaned = ua.replace(NON_PRINTABLE, '').trim().slice(0, USER_AGENT_MAX);
  return cleaned === '' ? null : cleaned;
}

export function createAuthService(deps: {
  store: AuthStore;
  hasher: PasswordHasher;
  /** HS256 key for access tokens (validated by loadAuthConfig; re-checked here). */
  accessTokenSecret: string;
  logger?: Logger;
  randomBytes?: (bytes: number) => Buffer;
  /** Milliseconds since the epoch; injectable so expiry can be tested. */
  now?: () => number;
}): AuthApi {
  const { store, hasher } = deps;
  if (typeof deps.accessTokenSecret !== 'string' || deps.accessTokenSecret.length < MIN_SECRET_LENGTH) {
    throw new Error(`the access token secret must be at least ${MIN_SECRET_LENGTH} characters`);
  }
  const secret = deps.accessTokenSecret;
  const logger = deps.logger ?? nullLogger;
  const rand = deps.randomBytes ?? randomBytes;
  const now = deps.now ?? Date.now;

  // A real argon2 hash of a random value, computed once. Verifying against it costs the same as a real verification.
  let dummy: Promise<string> | undefined;
  const dummyHash = (): Promise<string> => (dummy ??= hasher.hash(rand(16).toString('hex')));

  function grant(user: UserRow, session: NewSession, refreshToken: string): AuthResult {
    const access = signAccessToken({ sub: user.id, sid: session.familyId }, secret, now());
    return {
      user: toPublicUser(user),
      session: { accessToken: access.token, accessExpiresAt: access.expiresAt.toISOString(), refreshToken, refreshExpiresAt: session.expiresAt.toISOString() },
    };
  }

  async function register(input: unknown, ctx: AuthContext = {}): Promise<AuthResult> {
    const parsed = parseRegisterInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const { name, phone, password } = parsed.value;

    const passwordHash = await hasher.hash(password);
    const refreshToken = generateSessionToken(rand);
    try {
      const result = await store.transaction(async ({ users, sessions }) => {
        const user = await users.insert({ name, phoneE164: phone, passwordHash });
        const session = await sessions.create({ userId: user.id, tokenHash: hashSessionToken(refreshToken), userAgent: cleanUserAgent(ctx.userAgent) });
        return { user, session };
      });
      logger.info({ event: 'auth.registered', userId: result.user.id });
      return grant(result.user, result.session, refreshToken);
    } catch (e) {
      // Race-safe: the unique index decides, never a prior SELECT. Nothing identifies which account collided.
      if (e instanceof DbError && e.kind === 'unique' && e.constraint === 'users_phone_active_uq') {
        logger.info({ event: 'auth.register.conflict' });
        throw new AuthError('conflict');
      }
      throw e;
    }
  }

  async function login(input: unknown, ctx: AuthContext = {}): Promise<AuthResult> {
    const parsed = parseLoginInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const { phone, password } = parsed.value;

    const cred = await store.users.findCredentialsByPhone(phone);

    if (!cred || cred.locked) {
      await hasher.verify(await dummyHash(), password); // same cost as a real verification; the result is discarded
      logger.info({ event: 'auth.login.failed', reason: cred ? 'locked' : 'unknown_account', ...(cred ? { userId: cred.id } : {}) });
      throw new AuthError('invalid_credentials');
    }

    const matches = await hasher.verify(cred.passwordHash, password);
    if (!matches) {
      await store.users.recordFailedLogin(cred.id);
      logger.info({ event: 'auth.login.failed', reason: 'bad_password', userId: cred.id });
      throw new AuthError('invalid_credentials');
    }
    if (cred.status !== 'active') {
      // Correct password but the account may not sign in (pending/suspended). Deliberately the same generic failure.
      logger.info({ event: 'auth.login.failed', reason: 'inactive', userId: cred.id });
      throw new AuthError('invalid_credentials');
    }

    const refreshToken = generateSessionToken(rand);
    const session = await store.transaction(async ({ users, sessions }) => {
      await users.recordSuccessfulLogin(cred.id);
      return sessions.create({ userId: cred.id, tokenHash: hashSessionToken(refreshToken), userAgent: cleanUserAgent(ctx.userAgent) });
    });
    logger.info({ event: 'auth.login.success', userId: cred.id });
    return grant(cred, session, refreshToken);
  }

  async function refresh(input: unknown, ctx: AuthContext = {}): Promise<AuthResult> {
    const parsed = parseRefreshInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);

    const newToken = generateSessionToken(rand);
    // The outcome is RETURNED by the transaction (never thrown from inside it), so a reuse revocation is committed.
    const outcome = await store.transaction(({ sessions }) =>
      sessions.rotate({ presentedHash: hashSessionToken(parsed.value.refreshToken), newHash: hashSessionToken(newToken), userAgent: cleanUserAgent(ctx.userAgent) }),
    );
    if (outcome.kind === 'rotated') {
      logger.info({ event: 'auth.refresh.rotated', userId: outcome.user.id });
      return grant(outcome.user, outcome.session, newToken);
    }
    if (outcome.kind === 'reuse') {
      logger.warn({ event: 'auth.refresh.reuse_detected', userId: outcome.userId });
    } else {
      logger.info({ event: 'auth.refresh.rejected' });
    }
    throw new AuthError('unauthorized'); // identical for every failure: nothing says why
  }

  async function authenticate(accessToken: string | undefined): Promise<AuthenticatedUser | null> {
    const claims = verifyAccessToken(accessToken, secret, now()); // malformed/forged/expired: no database work at all
    if (!claims) return null;
    const found = await store.sessions.findActiveByFamily(claims.sid, claims.sub);
    if (!found) return null; // revoked (logout, suspension, reuse), expired, or the account is no longer active
    try {
      await store.sessions.touch(found.sessionId);
    } catch {
      // last_used_at is bookkeeping; a failed touch must not fail an otherwise valid request
    }
    return { user: toPublicUser(found.user), sessionId: found.familyId };
  }

  async function logout(input: unknown): Promise<void> {
    const parsed = parseRefreshInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const revoked = await store.sessions.revokeFamilyByTokenHash(hashSessionToken(parsed.value.refreshToken));
    if (revoked) logger.info({ event: 'auth.logout' });
  }

  return { register, login, refresh, authenticate, logout };
}

// keep the token-shape helper exported for the HTTP layer's tests
export { isWellFormedToken };

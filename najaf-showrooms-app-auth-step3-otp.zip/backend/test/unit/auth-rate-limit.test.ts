import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { RATE_LIMITS, RATE_LIMIT_MAX_KEYS } from '../../src/auth/policy.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { rateLimitHook } from '../../src/auth/routes.ts';

function clock(start = 1_000_000) {
  let t = start;
  return { now: () => t, advance: (ms: number) => void (t += ms) };
}
const rule = { limit: 3, windowSeconds: 60 };

describe('memory rate limiter', () => {
  it('allows up to the limit, then blocks, reporting what remains', () => {
    const c = clock();
    const rl = createMemoryRateLimiter({ now: c.now });
    assert.deepEqual(rl.consume('k', rule), { allowed: true, remaining: 2, retryAfterSeconds: 0 });
    assert.deepEqual(rl.consume('k', rule), { allowed: true, remaining: 1, retryAfterSeconds: 0 });
    assert.deepEqual(rl.consume('k', rule), { allowed: true, remaining: 0, retryAfterSeconds: 0 });
    const blocked = rl.consume('k', rule);
    assert.equal(blocked.allowed, false);
    assert.equal(blocked.remaining, 0);
    assert.equal(blocked.retryAfterSeconds, 60);
  });

  it('Retry-After counts down to the end of the window and is never below 1', () => {
    const c = clock();
    const rl = createMemoryRateLimiter({ now: c.now });
    for (let i = 0; i < 3; i++) rl.consume('k', rule);
    c.advance(45_000);
    assert.equal(rl.consume('k', rule).retryAfterSeconds, 15);
    c.advance(14_999);
    assert.equal(rl.consume('k', rule).retryAfterSeconds, 1);
  });

  it('a new window starts when the old one ends', () => {
    const c = clock();
    const rl = createMemoryRateLimiter({ now: c.now });
    for (let i = 0; i < 4; i++) rl.consume('k', rule);
    assert.equal(rl.consume('k', rule).allowed, false);
    c.advance(60_000);
    assert.deepEqual(rl.consume('k', rule), { allowed: true, remaining: 2, retryAfterSeconds: 0 });
  });

  it('blocked attempts do not extend the window (a patient client is not punished further)', () => {
    const c = clock();
    const rl = createMemoryRateLimiter({ now: c.now });
    for (let i = 0; i < 3; i++) rl.consume('k', rule);
    for (let i = 0; i < 50; i++) {
      c.advance(1000);
      rl.consume('k', rule);
    }
    c.advance(10_000);
    assert.equal(rl.consume('k', rule).allowed, true, 'the window ended 60s after the first request');
  });

  it('keys are independent', () => {
    const rl = createMemoryRateLimiter({ now: clock().now });
    for (let i = 0; i < 3; i++) rl.consume('login:1.1.1.1', rule);
    assert.equal(rl.consume('login:1.1.1.1', rule).allowed, false);
    assert.equal(rl.consume('login:2.2.2.2', rule).allowed, true);
    assert.equal(rl.consume('register:1.1.1.1', rule).allowed, true);
  });

  it('a limit of 1 allows exactly one request per window', () => {
    const rl = createMemoryRateLimiter({ now: clock().now });
    assert.equal(rl.consume('k', { limit: 1, windowSeconds: 10 }).allowed, true);
    assert.equal(rl.consume('k', { limit: 1, windowSeconds: 10 }).allowed, false);
  });

  it('memory is bounded: a spray of distinct keys never exceeds the cap, and expired windows are pruned first', () => {
    const c = clock();
    const rl = createMemoryRateLimiter({ now: c.now, maxKeys: 100 });
    for (let i = 0; i < 1000; i++) rl.consume(`ip-${i}`, rule);
    assert.ok(rl.size() <= 100, `size ${rl.size()}`);
    c.advance(61_000);
    rl.consume('fresh', rule);
    assert.ok(rl.size() <= 100);
    assert.ok(rl.size() < 100, 'expired windows were pruned, not just evicted one by one');
  });

  it('under the cap, active windows are never evicted by other keys', () => {
    const rl = createMemoryRateLimiter({ now: clock().now, maxKeys: 100 });
    for (let i = 0; i < 3; i++) rl.consume('victim', rule);
    for (let i = 0; i < 50; i++) rl.consume(`other-${i}`, rule);
    assert.equal(rl.consume('victim', rule).allowed, false, 'the blocked client is still blocked');
  });

  it('the default cap is the policy value', () => {
    assert.equal(RATE_LIMIT_MAX_KEYS, 50_000);
  });
});

describe('rate limit policy', () => {
  it('has a positive integer limit and window for each sensitive route; registration is the strictest', () => {
    assert.deepEqual(Object.keys(RATE_LIMITS).sort(), ['login', 'logout', 'passwordForgot', 'passwordReset', 'phoneVerifyConfirm', 'phoneVerifyRequest', 'refresh', 'register']);
    for (const r of Object.values(RATE_LIMITS)) {
      assert.ok(Number.isInteger(r.limit) && r.limit >= 1);
      assert.ok(Number.isInteger(r.windowSeconds) && r.windowSeconds >= 1);
    }
    const perHour = (r: { limit: number; windowSeconds: number }) => (r.limit * 3600) / r.windowSeconds;
    assert.ok(perHour(RATE_LIMITS.register) < perHour(RATE_LIMITS.login));
  });
});

function fakeReply() {
  const sent: { status?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
  const reply = {
    code: (n: number) => ((sent.status = n), reply),
    header: (k: string, v: string) => ((sent.headers[k] = v), reply),
    send: (b?: unknown) => ((sent.body = b), reply),
  };
  return { reply, sent };
}
function fakeRequest(ip: string, logs: unknown[] = []) {
  return { ip, id: 'req-1', log: { warn: (o: unknown) => logs.push(o) }, headers: {} };
}

describe('rateLimitHook', () => {
  it('lets requests through under the limit (no reply is sent)', async () => {
    const hook = rateLimitHook(createMemoryRateLimiter({ now: clock().now }), 'login');
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) {
      const { reply, sent } = fakeReply();
      assert.equal(await hook(fakeRequest('1.2.3.4') as never, reply as never), undefined);
      assert.equal(sent.status, undefined);
    }
  });

  it('answers 429 with a generic body and Retry-After once the limit is exceeded, returning the reply to end the request', async () => {
    const hook = rateLimitHook(createMemoryRateLimiter({ now: clock().now }), 'login');
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) await hook(fakeRequest('1.2.3.4') as never, fakeReply().reply as never);
    const { reply, sent } = fakeReply();
    const out = await hook(fakeRequest('1.2.3.4') as never, reply as never);
    assert.equal(out, reply);
    assert.equal(sent.status, 429);
    assert.deepEqual(sent.body, { error: { code: 'rate_limited', message: 'Too many requests', requestId: 'req-1' } });
    assert.equal(sent.headers['retry-after'], String(RATE_LIMITS.login.windowSeconds));
  });

  it('limits per client address and per route independently', async () => {
    const rl = createMemoryRateLimiter({ now: clock().now });
    const login = rateLimitHook(rl, 'login');
    const register = rateLimitHook(rl, 'register');
    for (let i = 0; i < RATE_LIMITS.login.limit + 1; i++) await login(fakeRequest('9.9.9.9') as never, fakeReply().reply as never);
    const blocked = fakeReply();
    assert.equal(await login(fakeRequest('9.9.9.9') as never, blocked.reply as never), blocked.reply);
    const otherIp = fakeReply();
    assert.equal(await login(fakeRequest('8.8.8.8') as never, otherIp.reply as never), undefined, 'another address is not limited');
    const otherRoute = fakeReply();
    assert.equal(await register(fakeRequest('9.9.9.9') as never, otherRoute.reply as never), undefined, 'another route is not limited');
  });

  it('the registration limit is hit sooner than the login limit', async () => {
    const hook = rateLimitHook(createMemoryRateLimiter({ now: clock().now }), 'register');
    let allowed = 0;
    for (let i = 0; i < 20; i++) if ((await hook(fakeRequest('5.5.5.5') as never, fakeReply().reply as never)) === undefined) allowed += 1;
    assert.equal(allowed, RATE_LIMITS.register.limit);
  });

  it('logs only the event and the route: no address, no body, no token', async () => {
    const logs: unknown[] = [];
    const hook = rateLimitHook(createMemoryRateLimiter({ now: clock().now }), 'refresh');
    for (let i = 0; i < RATE_LIMITS.refresh.limit + 1; i++) await hook(fakeRequest('203.0.113.7', logs) as never, fakeReply().reply as never);
    assert.equal(logs.length, 1);
    assert.deepEqual(logs[0], { event: 'auth.rate_limited', route: 'refresh' });
    assert.ok(!JSON.stringify(logs).includes('203.0.113.7'));
  });

  it('the window reopens after it ends', async () => {
    const c = clock();
    const hook = rateLimitHook(createMemoryRateLimiter({ now: c.now }), 'login');
    for (let i = 0; i < RATE_LIMITS.login.limit + 1; i++) await hook(fakeRequest('1.1.1.1') as never, fakeReply().reply as never);
    c.advance(RATE_LIMITS.login.windowSeconds * 1000);
    assert.equal(await hook(fakeRequest('1.1.1.1') as never, fakeReply().reply as never), undefined);
  });
});

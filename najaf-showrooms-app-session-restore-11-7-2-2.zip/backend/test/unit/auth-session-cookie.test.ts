// Cookie transport for the refresh token (Phase 11.7.2.2): configuration, the pure cookie/CSRF rules, and the three route handlers
// run directly (no Fastify needed, same technique as auth-http.test.ts). NOT covered here: a real browser and a real Fastify server.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { registerAuthRoutes } from '../../src/auth/routes.ts';
import { AUTH_ENV_VARS } from '../../src/auth/config.ts';
import {
  SESSION_COOKIE_ENV_VARS, SessionCookieConfigError, checkCookieRequest, loadSessionCookieConfig, readSessionCookie, redactSessionCookieConfig,
  requestsCookieTransport, serializeClearCookie, serializeSessionCookie,
} from '../../src/auth/session-cookie.ts';
import type { SessionCookieConfig } from '../../src/auth/session-cookie.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AuthApi, AuthResult } from '../../src/auth/types.ts';

const ORIGIN = 'https://najaf.example.com';
const RT1 = 'nsj_' + 'A'.repeat(43);
const RT2 = 'nsj_' + 'B'.repeat(43);
const RT3 = 'nsj_' + 'C'.repeat(43);
const ACCESS = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.' + 'A'.repeat(60) + '.' + 'B'.repeat(43);
const NOW = Date.parse('2030-01-01T00:00:00Z');
const REFRESH_EXPIRES = new Date(NOW + 30 * 864e5).toISOString();
const user = { id: '7', name: 'علي حسين', phone: '+9647701234567', role: 'user', status: 'active', phoneVerified: false, createdAt: '2026-01-02T03:04:05.000Z' };
const grant = (rt: string): AuthResult => ({ user, session: { accessToken: ACCESS, accessExpiresAt: new Date(NOW + 15 * 60e3).toISOString(), refreshToken: rt, refreshExpiresAt: REFRESH_EXPIRES } });
const cfg = (over: Record<string, string> = {}): SessionCookieConfig => loadSessionCookieConfig({ AUTH_COOKIE_ORIGINS: ORIGIN, ...over }) as SessionCookieConfig;
const problemsOf = (env: Record<string, string | undefined>): string[] => {
  try { loadSessionCookieConfig(env); } catch (e) { if (e instanceof SessionCookieConfigError) return e.problems; throw e; }
  return [];
};

describe('session cookie config', () => {
  it('is disabled (null) unless AUTH_COOKIE_ORIGINS is set: the default changes nothing', () => {
    assert.equal(loadSessionCookieConfig({}), null);
    assert.equal(loadSessionCookieConfig({ AUTH_COOKIE_ORIGINS: '   ' }), null);
    assert.deepEqual(redactSessionCookieConfig(null), { enabled: false });
  });
  it('secure by default, __Secure- name, frozen, de-duplicated', () => {
    const c = loadSessionCookieConfig({ AUTH_COOKIE_ORIGINS: `${ORIGIN}, ${ORIGIN},https://m.example.com:8443` }) as SessionCookieConfig;
    assert.equal(c.secure, true);
    assert.equal(c.cookieName, '__Secure-najaf_rt');
    assert.deepEqual([...c.allowedOrigins], [ORIGIN, 'https://m.example.com:8443']);
    assert.equal(Object.isFrozen(c), true);
  });
  it('accepts only exact origins: no wildcard, null, path, trailing slash, query, credentials, other schemes', () => {
    for (const bad of ['*', 'https://*.example.com', 'null', 'https://najaf.example.com/', 'https://najaf.example.com/app', 'https://najaf.example.com?x=1', 'https://u:p@najaf.example.com', 'najaf.example.com', 'ftp://najaf.example.com', 'http://najaf.example.com', 'HTTPS://najaf.example.com']) {
      assert.ok(problemsOf({ AUTH_COOKIE_ORIGINS: bad }).length > 0, bad);
    }
  });
  it('http is allowed only for loopback and only with AUTH_COOKIE_SECURE=false (development)', () => {
    assert.ok(problemsOf({ AUTH_COOKIE_ORIGINS: 'http://localhost:3000' }).length > 0);
    const dev = loadSessionCookieConfig({ AUTH_COOKIE_ORIGINS: 'http://localhost:3000', AUTH_COOKIE_SECURE: 'false' }) as SessionCookieConfig;
    assert.equal(dev.secure, false);
    assert.equal(dev.cookieName, 'najaf_rt');
    assert.ok(problemsOf({ AUTH_COOKIE_ORIGINS: 'http://najaf.example.com', AUTH_COOKIE_SECURE: 'false' }).length > 0, 'non-loopback http is never accepted');
  });
  it('AUTH_COOKIE_SECURE=false is refused in production; other values are validated', () => {
    assert.ok(problemsOf({ AUTH_COOKIE_ORIGINS: ORIGIN, AUTH_COOKIE_SECURE: 'false', NODE_ENV: 'production' }).some((m) => m.includes('production')));
    assert.ok(problemsOf({ AUTH_COOKIE_ORIGINS: ORIGIN, AUTH_COOKIE_SECURE: 'maybe' }).length > 0);
    assert.ok(problemsOf({ AUTH_COOKIE_SECURE: 'true' }).length > 0, 'a secure flag without origins is a mistake, not a silent no-op');
  });
  it('rejects too many origins', () => {
    const many = Array.from({ length: 11 }, (_, i) => `https://a${i}.example.com`).join(',');
    assert.ok(problemsOf({ AUTH_COOKIE_ORIGINS: many }).some((m) => m.includes('more than 10')));
  });
  it('redaction shows no token material (there is none) and states the effective settings', () => {
    assert.deepEqual(redactSessionCookieConfig(cfg()), { enabled: true, secure: true, origins: [ORIGIN], cookieName: '__Secure-najaf_rt' });
  });
});

describe('.env.auth.example documents the cookie variables', () => {
  const example = readFileSync(join(import.meta.dirname, '..', '..', '.env.auth.example'), 'utf8');
  const documented = new Set([...example.matchAll(/^#?\s*([A-Z][A-Z0-9_]*)=/gm)].map((m) => m[1] as string));
  it('every cookie variable the code reads is documented, and each documented variable is read by the code', () => {
    for (const v of SESSION_COOKIE_ENV_VARS) assert.ok(documented.has(v), `${v} is not documented`);
    for (const v of documented) assert.ok([...AUTH_ENV_VARS, ...SESSION_COOKIE_ENV_VARS].includes(v as never), `${v} is listed but not read`);
  });
  it('ships disabled', () => {
    assert.ok(!/^AUTH_COOKIE_ORIGINS=\S/m.test(example));
  });
});

describe('cookie attributes', () => {
  const c = cfg();
  it('Set-Cookie: HttpOnly, Secure, SameSite=Strict, narrow Path, no Domain, Max-Age from the ABSOLUTE expiry', () => {
    const v = serializeSessionCookie(c, RT1, Date.parse(REFRESH_EXPIRES), NOW);
    assert.equal(v, `__Secure-najaf_rt=${RT1}; Path=/v1/auth; HttpOnly; SameSite=Strict; Secure; Max-Age=${30 * 86400}`);
    assert.ok(!/Domain=/i.test(v));
  });
  it('rotation does not extend the cookie: a later rotation has a SHORTER Max-Age for the same absolute expiry', () => {
    const later = serializeSessionCookie(c, RT2, Date.parse(REFRESH_EXPIRES), NOW + 10 * 864e5);
    assert.match(later, /Max-Age=1728000$/);
  });
  it('Max-Age never goes negative; a malformed token is never written', () => {
    assert.match(serializeSessionCookie(c, RT1, NOW - 5000, NOW), /Max-Age=0$/);
    for (const bad of ['', 'x', RT1 + ';', 'nsj_short', `${RT1}\r\nSet-Cookie: a=b`]) assert.throws(() => serializeSessionCookie(c, bad, NOW + 1000, NOW));
  });
  it('the clearing cookie has the same name/path/attributes and is already expired', () => {
    assert.equal(serializeClearCookie(c), '__Secure-najaf_rt=; Path=/v1/auth; HttpOnly; SameSite=Strict; Secure; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT');
  });
  it('development mode drops Secure and the prefix, and nothing else', () => {
    const dev = loadSessionCookieConfig({ AUTH_COOKIE_ORIGINS: 'http://localhost:3000', AUTH_COOKIE_SECURE: 'false' }) as SessionCookieConfig;
    assert.equal(serializeSessionCookie(dev, RT1, NOW + 60000, NOW), `najaf_rt=${RT1}; Path=/v1/auth; HttpOnly; SameSite=Strict; Max-Age=60`);
  });
});

describe('reading the cookie', () => {
  const c = cfg();
  it('returns the token among other cookies', () => {
    assert.equal(readSessionCookie(c, `a=1; __Secure-najaf_rt=${RT1}; b=2`), RT1);
    assert.equal(readSessionCookie(c, `__Secure-najaf_rt=${RT1}`), RT1);
  });
  it('refuses absent, duplicated (somebody else may have set one), malformed and oversized values', () => {
    assert.equal(readSessionCookie(c, undefined), undefined);
    assert.equal(readSessionCookie(c, 'a=1'), undefined);
    assert.equal(readSessionCookie(c, `__Secure-najaf_rt=${RT1}; __Secure-najaf_rt=${RT2}`), undefined);
    assert.equal(readSessionCookie(c, '__Secure-najaf_rt=garbage'), undefined);
    assert.equal(readSessionCookie(c, `__Secure-najaf_rt=${RT1}x`), undefined);
    assert.equal(readSessionCookie(c, `x=${'a'.repeat(5000)}; __Secure-najaf_rt=${RT1}`), undefined);
    assert.equal(readSessionCookie(c, ['__Secure-najaf_rt=' + RT1]), undefined);
  });
  it('a cookie with a similar name is not ours', () => {
    assert.equal(readSessionCookie(c, `najaf_rt=${RT1}`), undefined);
    assert.equal(readSessionCookie(c, `x__Secure-najaf_rt=${RT1}`), undefined);
  });
});

describe('CSRF checks', () => {
  const c = cfg();
  const ok = { 'x-session-transport': 'cookie', origin: ORIGIN };
  it('accepts the allowed origin with the transport header (and a same-origin/same-site Sec-Fetch-Site)', () => {
    assert.equal(checkCookieRequest(c, ok), undefined);
    assert.equal(checkCookieRequest(c, { ...ok, 'sec-fetch-site': 'same-origin' }), undefined);
    assert.equal(checkCookieRequest(c, { ...ok, 'sec-fetch-site': 'same-site' }), undefined);
    assert.equal(checkCookieRequest(c, { ...ok, 'x-session-transport': ' Cookie ' }), undefined);
  });
  it('refuses a missing, null, foreign, look-alike or differently-cased origin', () => {
    assert.equal(checkCookieRequest(c, { 'x-session-transport': 'cookie' }), 'origin_missing');
    assert.equal(checkCookieRequest(c, { ...ok, origin: '' }), 'origin_missing');
    for (const o of ['null', 'https://evil.example', `${ORIGIN}.evil.example`, 'http://najaf.example.com', 'https://NAJAF.example.com', `${ORIGIN}/`, 'https://najaf.example.com:444']) {
      assert.equal(checkCookieRequest(c, { ...ok, origin: o }), 'origin_not_allowed', o);
    }
    assert.equal(checkCookieRequest(c, { ...ok, origin: [ORIGIN] }), 'origin_missing');
  });
  it('refuses cross-site and navigation fetch metadata even with a correct Origin', () => {
    assert.equal(checkCookieRequest(c, { ...ok, 'sec-fetch-site': 'cross-site' }), 'fetch_site');
    assert.equal(checkCookieRequest(c, { ...ok, 'sec-fetch-site': 'none' }), 'fetch_site');
  });
  it('refuses a missing or different transport value', () => {
    assert.equal(checkCookieRequest(c, { origin: ORIGIN }), 'transport_value');
    assert.equal(checkCookieRequest(c, { ...ok, 'x-session-transport': 'body' }), 'transport_value');
    assert.equal(requestsCookieTransport({}), false);
    assert.equal(requestsCookieTransport({ 'x-session-transport': 'anything' }), true);
  });
});

// ---- the route handlers, run directly ----
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
function setup(opts: { cookie?: SessionCookieConfig | null; api?: Partial<AuthApi> } = {}) {
  const calls: Array<{ fn: string; input: unknown }> = [];
  const api: AuthApi = {
    register: async (i) => (calls.push({ fn: 'register', input: i }), grant(RT1)),
    login: async (i) => (calls.push({ fn: 'login', input: i }), grant(RT1)),
    refresh: async (i) => (calls.push({ fn: 'refresh', input: i }), grant(RT2)),
    authenticate: async () => null,
    logout: async (i) => void calls.push({ fn: 'logout', input: i }),
    ...opts.api,
  };
  const routes = new Map<string, Handler>();
  const app = { get: (p: string, ...r: unknown[]) => routes.set('GET ' + p, r[r.length - 1] as Handler), post: (p: string, ...r: unknown[]) => routes.set('POST ' + p, r[r.length - 1] as Handler) };
  registerAuthRoutes(app as never, { auth: api, ...(opts.cookie === undefined ? { sessionCookie: cfg() } : opts.cookie === null ? {} : { sessionCookie: opts.cookie }), now: () => NOW });
  const warns: unknown[] = [];
  const send = async (path: string, headers: Record<string, string>, body?: unknown) => {
    const sent: { status?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
    const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
    let threw: unknown;
    try { await routes.get('POST ' + path)!({ id: 'req-1', ip: '1.1.1.1', headers, body, log: { warn: (o: unknown) => warns.push(o) } }, reply); } catch (e) { threw = e; }
    return { sent, threw };
  };
  return { calls, send, warns };
}
const COOKIE_REQ = { 'x-session-transport': 'cookie', origin: ORIGIN };
const withCookie = (rt: string) => ({ ...COOKIE_REQ, cookie: `__Secure-najaf_rt=${rt}` });

describe('cookie transport: login', () => {
  it('sets the HttpOnly cookie and the body carries NO refresh token anywhere', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/login', COOKIE_REQ, { phone: '07701234567', password: 'x' });
    assert.equal(sent.status, 200);
    assert.equal(sent.headers['set-cookie'], `__Secure-najaf_rt=${RT1}; Path=/v1/auth; HttpOnly; SameSite=Strict; Secure; Max-Age=${30 * 86400}`);
    const text = JSON.stringify(sent.body);
    assert.ok(!text.includes(RT1) && !/refreshToken/.test(text));
    assert.deepEqual(sent.body, { user, session: { accessToken: ACCESS, accessExpiresAt: new Date(NOW + 15 * 60e3).toISOString(), refreshExpiresAt: REFRESH_EXPIRES } });
    assert.equal(t.calls.length, 1);
  });
  it('without the header nothing changes: the refresh token is in the body and no cookie is set', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/login', {}, { phone: 'p', password: 'x' });
    assert.deepEqual(sent.body, grant(RT1));
    assert.equal(sent.headers['set-cookie'], undefined);
  });
  it('a hostile or unlisted origin is refused 403 BEFORE the password is processed', async () => {
    const t = setup();
    for (const headers of [{ 'x-session-transport': 'cookie' }, { ...COOKIE_REQ, origin: 'https://evil.example' }, { ...COOKIE_REQ, origin: 'null' }, { ...COOKIE_REQ, 'sec-fetch-site': 'cross-site' }]) {
      const { sent } = await t.send('/v1/auth/login', headers, { phone: 'p', password: 'x' });
      assert.equal(sent.status, 403);
      assert.equal((sent.body as { error: { code: string } }).error.code, 'forbidden_origin');
      assert.equal(sent.headers['set-cookie'], undefined);
    }
    assert.equal(t.calls.length, 0);
    assert.ok(t.warns.length >= 4);
  });
  it('when cookie transport is not enabled the header is refused (400), never answered with a token in the body', async () => {
    const t = setup({ cookie: null });
    const { sent } = await t.send('/v1/auth/login', COOKIE_REQ, { phone: 'p', password: 'x' });
    assert.equal(sent.status, 400);
    assert.equal((sent.body as { error: { code: string } }).error.code, 'session_transport_unsupported');
    assert.equal(t.calls.length, 0);
  });
  it('an unknown transport value is refused 400', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/login', { ...COOKIE_REQ, 'x-session-transport': 'body' }, {});
    assert.equal(sent.status, 400);
    assert.equal(t.calls.length, 0);
  });
  it('a failed login sets no cookie', async () => {
    const t = setup({ api: { login: async () => { throw new AuthError('invalid_credentials'); } } });
    const { sent } = await t.send('/v1/auth/login', COOKIE_REQ, {});
    assert.equal(sent.status, 401);
    assert.equal(sent.headers['set-cookie'], undefined);
  });
});

describe('cookie transport: refresh', () => {
  it('takes the token ONLY from the cookie (a token in the body is ignored), rotates the cookie, returns no refresh token', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/refresh', withCookie(RT1), { refreshToken: RT3 });
    assert.equal(sent.status, 200);
    assert.deepEqual(t.calls, [{ fn: 'refresh', input: { refreshToken: RT1 } }]);
    assert.match(sent.headers['set-cookie'] as string, new RegExp(`^__Secure-najaf_rt=${RT2};`));
    assert.ok(!JSON.stringify(sent.body).includes(RT2));
  });
  it('without a cookie: 401 and the service is never called', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/refresh', COOKIE_REQ);
    assert.equal(sent.status, 401);
    assert.equal(t.calls.length, 0);
    assert.match(sent.headers['set-cookie'] as string, /Max-Age=0/, 'a harmless idempotent delete: whatever the browser holds is useless');
  });
  it('a malformed or duplicated cookie is refused AND deleted', async () => {
    const t = setup();
    for (const cookie of ['__Secure-najaf_rt=garbage', `__Secure-najaf_rt=${RT1}; __Secure-najaf_rt=${RT2}`]) {
      const { sent } = await t.send('/v1/auth/refresh', { ...COOKIE_REQ, cookie });
      assert.equal(sent.status, 401);
      assert.match(sent.headers['set-cookie'] as string, /Max-Age=0/);
    }
    assert.equal(t.calls.length, 0);
  });
  it('a refresh the server rejects (expired / revoked / REUSED) deletes the cookie', async () => {
    const t = setup({ api: { refresh: async () => { throw new AuthError('unauthorized'); } } });
    const { sent } = await t.send('/v1/auth/refresh', withCookie(RT1));
    assert.equal(sent.status, 401);
    assert.match(sent.headers['set-cookie'] as string, /^__Secure-najaf_rt=; .*Max-Age=0/);
  });
  it('an outage (not an authentication error) keeps the cookie: a database failure must not sign users out', async () => {
    const t = setup({ api: { refresh: async () => { throw new Error('db down'); } } });
    const { sent, threw } = await t.send('/v1/auth/refresh', withCookie(RT1));
    assert.ok(threw instanceof Error, 'propagates to the global error handler (generic 500)');
    assert.equal(sent.headers['set-cookie'], undefined);
  });
  it('a hostile origin never reaches the service and never deletes or sets a cookie', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/refresh', { ...withCookie(RT1), origin: 'https://evil.example' });
    assert.equal(sent.status, 403);
    assert.equal(sent.headers['set-cookie'], undefined);
    assert.equal(t.calls.length, 0);
  });
  it('body transport is unchanged (token in the body, no cookie)', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/refresh', {}, { refreshToken: RT1 });
    assert.deepEqual(sent.body, grant(RT2));
    assert.equal(sent.headers['set-cookie'], undefined);
    assert.deepEqual(t.calls, [{ fn: 'refresh', input: { refreshToken: RT1 } }]);
  });
  it('a cookie sent without the transport header is ignored (the cookie alone is never a credential)', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/refresh', { cookie: `__Secure-najaf_rt=${RT1}`, origin: ORIGIN }, undefined);
    assert.equal(t.calls[0]?.input, undefined, 'the body path is used, with the (empty) body: the service rejects it as validation_failed');
    assert.equal(sent.headers['set-cookie'], undefined);
  });
});

describe('cookie transport: logout', () => {
  it('revokes the session named by the cookie, deletes the cookie, 204', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/logout', withCookie(RT1));
    assert.equal(sent.status, 204);
    assert.deepEqual(t.calls, [{ fn: 'logout', input: { refreshToken: RT1 } }]);
    assert.match(sent.headers['set-cookie'] as string, /^__Secure-najaf_rt=; .*Max-Age=0/);
  });
  it('without a cookie it is still 204 and still deletes (idempotent), with no service call', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/logout', COOKIE_REQ);
    assert.equal(sent.status, 204);
    assert.equal(t.calls.length, 0);
    assert.match(sent.headers['set-cookie'] as string, /Max-Age=0/);
  });
  it('if revoking FAILS the cookie is kept so the sign-out can be retried', async () => {
    const t = setup({ api: { logout: async () => { throw new Error('db down'); } } });
    const { sent, threw } = await t.send('/v1/auth/logout', withCookie(RT1));
    assert.ok(threw instanceof Error);
    assert.equal(sent.headers['set-cookie'], undefined);
  });
  it('a hostile origin cannot log a user out (no service call, no cookie change)', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/logout', { ...withCookie(RT1), origin: 'https://evil.example' });
    assert.equal(sent.status, 403);
    assert.equal(t.calls.length, 0);
    assert.equal(sent.headers['set-cookie'], undefined);
  });
  it('body transport logout is unchanged', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/logout', {}, { refreshToken: RT1 });
    assert.equal(sent.status, 204);
    assert.deepEqual(t.calls, [{ fn: 'logout', input: { refreshToken: RT1 } }]);
    assert.equal(sent.headers['set-cookie'], undefined);
  });
});

describe('what cookie transport does NOT change', () => {
  it('register keeps its contract (not connected to cookies in this phase)', async () => {
    const t = setup();
    const { sent } = await t.send('/v1/auth/register', {}, { name: 'n' });
    assert.deepEqual(sent.body, grant(RT1));
    assert.equal(sent.headers['set-cookie'], undefined);
  });
});

// HTTP contract for authentication (Phase 11.4). Thin by design: the decisions live in service.ts and in the pure
// helpers below. This file imports Fastify TYPES only, so the helpers are unit-testable without Fastify installed.
//
//   POST /v1/auth/register   {name, phone, password}  -> 201 {user, session}
//   POST /v1/auth/login      {phone, password}        -> 200 {user, session}
//   POST /v1/auth/refresh    {refreshToken}           -> 200 {user, session}   (the refresh token is rotated)
//   GET  /v1/auth/me         Authorization: Bearer <accessToken>  -> 200 {user}
//   POST /v1/auth/logout     {refreshToken}           -> 204
//   session = {accessToken, accessExpiresAt, refreshToken, refreshExpiresAt}
//
//   One-time codes (registered only when an OtpApi is supplied):
//   POST /v1/auth/phone/verify/request   Authorization: Bearer   -> 202 {status:'sent'} | 200 {status:'already_verified'}
//   POST /v1/auth/phone/verify/confirm   Bearer, {code}          -> 200 {user}
//   POST /v1/auth/password/forgot        {phone}                 -> 202 {status:'accepted'}  (ALWAYS, account or not)
//   POST /v1/auth/password/reset         {phone, code, newPassword} -> 200 {status:'password_reset'}
//
//   Account security (registered only when an AccountApi is supplied; all need Authorization: Bearer <accessToken>):
//   POST /v1/auth/password/change        {currentPassword, newPassword} -> 200 {status:'password_changed'}  (ends EVERY session)
//   POST /v1/auth/logout/all             (no body)                -> 204                                   (ends EVERY session)
//
//   Cookie transport (Phase 11.7.2.2; only when AUTH_COOKIE_ORIGINS is configured, per request via `X-Session-Transport: cookie`):
//   login/refresh/logout take the refresh token from, and set it in, an HttpOnly cookie instead of the JSON body. See session-cookie.ts.
//   login   {phone, password}  -> 200 {user, session:{accessToken, accessExpiresAt, refreshExpiresAt}} + Set-Cookie (no refreshToken in the body)
//   refresh (no body)          -> same shape; the cookie is rotated.  A rejected refresh also deletes the cookie.
//   logout  (no body)          -> 204 and the cookie is deleted.
//
// Errors use the project's body shape { error: { code, message, requestId, fields? } }. Messages are fixed and generic.
// register/login/refresh/logout are rate limited per client address (429 + Retry-After) before the body is read.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { FieldError } from './validation.ts';
import { AuthError } from './types.ts';
import type { AccountApi, AuthApi, AuthContext, AuthResult, OtpApi } from './types.ts';
import type { RateLimitedRoute } from './policy.ts';
import { RATE_LIMITS } from './policy.ts';
import type { RateLimiter } from './rate-limit.ts';
import { checkCookieRequest, readSessionCookie, requestsCookieTransport, serializeClearCookie, serializeSessionCookie } from './session-cookie.ts';
import type { SessionCookieConfig } from './session-cookie.ts';

export interface AuthHttpError {
  status: number;
  code: string;
  message: string;
  fields?: FieldError[];
  /** Only for 429 from a per-account throttle: seconds for the Retry-After header. */
  retryAfterSeconds?: number;
}

export function toAuthHttp(e: unknown): AuthHttpError | undefined {
  if (!(e instanceof AuthError)) return undefined;
  switch (e.code) {
    case 'validation_failed':
      return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    case 'conflict':
      return { status: 409, code: e.code, message: e.message };
    case 'invalid_code':
      return { status: 400, code: e.code, message: e.message };
    case 'invalid_current_password':
      return { status: 400, code: e.code, message: e.message };
    case 'rate_limited':
      return { status: 429, code: e.code, message: e.message, ...(e.retryAfterSeconds !== undefined ? { retryAfterSeconds: e.retryAfterSeconds } : {}) };
    case 'invalid_credentials':
    case 'unauthorized':
      return { status: 401, code: e.code, message: e.message };
  }
}

/** application/json, with optional parameters (e.g. charset), case-insensitive. Nothing else qualifies. */
export function isJsonContentType(value: unknown): boolean {
  return typeof value === 'string' && /^\s*application\/json\s*(;.*)?$/i.test(value);
}

// Fastify natively accepts BOTH application/json and text/plain. text/plain is a CORS "simple" content type (a cross-site
// page can send it without a preflight), and these endpoints take JSON only, so anything else is answered 415 here, in
// onRequest: before the body is read or parsed and before the service runs. (No content type at all: Fastify itself answers
// 415 when a body is present, and an empty body is a validation error.)
async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;

/**
 * Per-client-address limit for one route. request.ip is the socket address unless the server was built with a trusted
 * proxy list (AUTH_TRUSTED_PROXIES), in which case Fastify resolves X-Forwarded-For through those proxies only.
 */
export function rateLimitHook(limiter: RateLimiter, route: RateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`${route}:${request.ip}`, RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'auth.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

/** "Bearer <token>" (scheme case-insensitive, exactly one token, no extra spaces); anything else is undefined. */
export function bearerToken(header: unknown): string | undefined {
  if (typeof header !== 'string') return undefined;
  const m = /^Bearer ([^\s]+)$/i.exec(header);
  return m ? (m[1] as string) : undefined;
}

const contextOf = (request: FastifyRequest): AuthContext => {
  const ua = request.headers['user-agent'];
  return { userAgent: typeof ua === 'string' ? ua : undefined };
};

export function registerAuthRoutes(app: FastifyInstance, deps: { auth: AuthApi; otp?: OtpApi; account?: AccountApi; rateLimiter?: RateLimiter; sessionCookie?: SessionCookieConfig | null; now?: () => number }): void {
  const { auth, otp, account, rateLimiter } = deps;
  const cookieCfg = deps.sessionCookie ?? null;
  const nowMs = deps.now ?? Date.now;
  const limit = (route: RateLimitedRoute): Hook[] => (rateLimiter ? [rateLimitHook(rateLimiter, route)] : []);

  type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };
  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toAuthHttp(e);
    if (!mapped) throw e; // not an authentication error: the global error handler maps it (generic 4xx/5xx body)
    if (mapped.status === 401 && mapped.code === 'unauthorized') reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // ---- cookie transport (opt-in per request; see session-cookie.ts) ----
  type Transport = { kind: 'body' } | { kind: 'cookie'; cfg: SessionCookieConfig } | { kind: 'refused'; reply: Reply };
  /** Decides the transport BEFORE any credential is processed. A refused request never reaches the service. */
  const transportOf = (request: FastifyRequest, reply: Reply): Transport => {
    if (!requestsCookieTransport(request.headers)) return { kind: 'body' };
    const refuse = (status: number, code: string, message: string): Transport => ({ kind: 'refused', reply: reply.code(status).send({ error: { code, message, requestId: request.id } }) });
    if (!cookieCfg) return refuse(400, 'session_transport_unsupported', 'Cookie session transport is not enabled');
    const bad = checkCookieRequest(cookieCfg, request.headers);
    if (bad === undefined) return { kind: 'cookie', cfg: cookieCfg };
    request.log.warn({ event: 'auth.cookie.rejected', reason: bad });
    return bad === 'transport_value'
      ? refuse(400, 'session_transport_unsupported', 'Unsupported session transport')
      : refuse(403, 'forbidden_origin', 'This request origin is not allowed');
  };
  /** The grant for the client: in cookie transport the refresh token goes to the cookie and is REMOVED from the body. */
  const deliver = (reply: Reply, t: Transport, result: AuthResult, status: number): Reply => {
    if (t.kind !== 'cookie') return reply.code(status).send(result);
    const { accessToken, accessExpiresAt, refreshToken, refreshExpiresAt } = result.session;
    reply.header('set-cookie', serializeSessionCookie(t.cfg, refreshToken, Date.parse(refreshExpiresAt), nowMs()));
    return reply.code(status).send({ user: result.user, session: { accessToken, accessExpiresAt, refreshExpiresAt } });
  };

  // Rate limit first (cheap), then the JSON-only check; both run in onRequest, before the body is read or parsed.
  const bodyRoute = (route: RateLimitedRoute) => ({ bodyLimit: 4096, onRequest: [...limit(route), requireJsonBody] });

  app.post('/v1/auth/register', bodyRoute('register'), async (request, reply) => {
    try {
      const result = await auth.register(request.body, contextOf(request));
      return reply.code(201).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/login', bodyRoute('login'), async (request, reply) => {
    try {
      const t = transportOf(request, reply as unknown as Reply);
      if (t.kind === 'refused') return t.reply;
      const result = await auth.login(request.body, contextOf(request));
      return deliver(reply as unknown as Reply, t, result, 200);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/refresh', bodyRoute('refresh'), async (request, reply) => {
    const r = reply as unknown as Reply;
    let t: Transport = { kind: 'body' };
    try {
      t = transportOf(request, r);
      if (t.kind === 'refused') return t.reply;
      if (t.kind === 'body') return r.code(200).send(await auth.refresh(request.body, contextOf(request)));
      // Cookie transport: the token comes ONLY from the cookie; anything in the body is ignored.
      const token = readSessionCookie(t.cfg, request.headers['cookie']);
      if (token === undefined) {
        if (typeof request.headers['cookie'] === 'string' && request.headers['cookie'].includes(t.cfg.cookieName)) r.header('set-cookie', serializeClearCookie(t.cfg)); // malformed/duplicate: drop it
        throw new AuthError('unauthorized');
      }
      return deliver(r, t, await auth.refresh({ refreshToken: token }, contextOf(request)), 200);
    } catch (e) {
      // A refresh the server rejected (unknown, expired, revoked, reused, inactive account) can never succeed again: delete the cookie.
      // Anything else (database down, ...) keeps it, so the user is not signed out by an outage.
      if (t.kind === 'cookie' && e instanceof AuthError && e.code === 'unauthorized') r.header('set-cookie', serializeClearCookie(t.cfg));
      return fail(request, r, e);
    }
  });

  app.get('/v1/auth/me', async (request, reply) => {
    try {
      const found = await auth.authenticate(bearerToken(request.headers['authorization']));
      if (!found) throw new AuthError('unauthorized');
      return reply.code(200).send({ user: found.user });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/logout', bodyRoute('logout'), async (request, reply) => {
    try {
      const t = transportOf(request, reply as unknown as Reply);
      if (t.kind === 'refused') return t.reply;
      if (t.kind === 'body') {
        await auth.logout(request.body);
        return reply.code(204).send();
      }
      // Cookie transport: revoke the session the cookie names (if any), then ALWAYS delete the cookie. If revoking fails (database
      // down) the error propagates and the cookie is kept, so the sign-out can be retried and is not silently half done.
      const token = readSessionCookie(t.cfg, request.headers['cookie']);
      if (token !== undefined) await auth.logout({ refreshToken: token });
      (reply as unknown as Reply).header('set-cookie', serializeClearCookie(t.cfg));
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  // ---- shared by the routes below ----
  const limitOnly = (route: RateLimitedRoute) => {
    const hooks = limit(route);
    return hooks.length > 0 ? { onRequest: hooks } : {};
  };
  // The ONLY source of "who is calling": the verified access token, re-read from the database. Never the request body.
  const requireAccess = async (request: FastifyRequest) => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return found;
  };

  // ---- account security ----
  if (account) {
    app.post('/v1/auth/password/change', bodyRoute('passwordChange'), async (request, reply) => {
      try {
        const { user } = await requireAccess(request);
        const result = await account.changePassword(user.id, request.body, { requestId: request.id });
        return reply.code(200).send(result);
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });

    app.post('/v1/auth/logout/all', limitOnly('logoutAll'), async (request, reply) => {
      try {
        const { user } = await requireAccess(request);
        await account.logoutAll(user.id, { requestId: request.id });
        return reply.code(204).send();
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    });
  }

  // ---- one-time codes ----
  if (!otp) return;

  app.post('/v1/auth/phone/verify/request', limitOnly('phoneVerifyRequest'), async (request, reply) => {
    try {
      const { user } = await requireAccess(request);
      const result = await otp.requestPhoneVerification(user.id);
      return reply.code(result.status === 'sent' ? 202 : 200).send({ status: result.status });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/phone/verify/confirm', bodyRoute('phoneVerifyConfirm'), async (request, reply) => {
    try {
      const { user } = await requireAccess(request);
      const verified = await otp.confirmPhoneVerification(user.id, request.body);
      return reply.code(200).send({ user: verified });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/password/forgot', bodyRoute('passwordForgot'), async (request, reply) => {
    try {
      const result = await otp.requestPasswordReset(request.body);
      return reply.code(202).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/auth/password/reset', bodyRoute('passwordReset'), async (request, reply) => {
    try {
      const result = await otp.resetPassword(request.body, { requestId: request.id });
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

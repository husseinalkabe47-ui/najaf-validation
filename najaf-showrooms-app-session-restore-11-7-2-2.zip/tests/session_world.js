/* مساعد اختبارات 11.7.2.2 (ليس اختبارًا): «خادم» وهمي يحاكي عقد الخلفية الجديد + ملف ارتباط المتصفح + قفل Web Locks مشترك. */
const ApiClient = require('../api/apiClient.js');
const T0 = Date.parse('2030-01-01T00:00:00Z');
const iso = ms => new Date(ms).toISOString();
const tick = () => new Promise(r => setImmediate(r));

/** خادم وهمي + ملف ارتباط المتصفح. gate(path) اختياري: يؤخّر تسليم الاستجابة (وتطبيق Set-Cookie) لإنتاج سباقات حقيقية. */
function world(opts) {
  opts = opts || {};
  const clock = { t: T0 };
  const jar = { rt: null };                         // ملف ارتباط المتصفح (مشترك بين كل التبويبات)
  const srv = { families: new Map(), byToken: new Map(), seq: 0, calls: [], bodies: [], access: new Map(), gate: null, fail: null, down: false };
  const issue = (fam) => {
    const at = 'AT-' + (++srv.seq);
    srv.access.set(at, { fam, exp: clock.t + 15 * 60e3 });
    return { accessToken: at, accessExpiresAt: iso(clock.t + 15 * 60e3), refreshExpiresAt: iso(T0 + 30 * 864e5) };
  };
  const rotate = (fam) => { const rt = 'nsj_' + (++srv.seq) + '_' + fam.id; fam.current = rt; srv.byToken.set(rt, fam); return rt; };
  const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
  const userOf = fam => ({ id: String(fam.userId), name: 'مستخدم ' + fam.userId, phone: '+9647700000' + fam.userId, role: 'user', status: 'active', phoneVerified: false, createdAt: iso(T0) });

  async function fetchImpl(url, init) {
    const path = new URL(url, 'https://app.test').pathname;
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const cookie = init.credentials === 'same-origin' ? jar.rt : null;   // المتصفح يقرأ الملف لحظة الإرسال
    const call = { path, method: init.method, headers: h, credentials: init.credentials, cookie, body: init.body === undefined ? undefined : JSON.parse(init.body) };
    srv.calls.push(call);
    if (srv.down) throw new TypeError('Failed to fetch');
    if (srv.fail && srv.fail(call)) return srv.fail(call);
    let res, setCookie;                               // undefined = لا تغيير | null = حذف | string = قيمة
    const viaCookie = h['x-session-transport'] === 'cookie';
    if (path === '/v1/auth/login') {
      const userId = Number(String(call.body.phone).slice(-1)) || 1;
      const fam = { id: 'f' + (++srv.seq), userId, revoked: false, current: null };
      srv.families.set(fam.id, fam);
      const rt = rotate(fam);
      const session = issue(fam);
      if (!viaCookie) session.refreshToken = rt; else setCookie = rt;
      res = json(200, { user: userOf(fam), session });
    } else if (path === '/v1/auth/refresh') {
      const fam = viaCookie && cookie ? srv.byToken.get(cookie) : null;
      if (!fam || fam.revoked) { res = json(401, { error: { code: 'unauthorized', message: 'Authentication required', requestId: 'r' } }); if (viaCookie) setCookie = null; }
      else if (fam.current !== cookie) { fam.revoked = true; srv.reuse = (srv.reuse || 0) + 1; res = json(401, { error: { code: 'unauthorized', message: 'x', requestId: 'r' } }); setCookie = null; }
      else { const rt = rotate(fam); srv.rotations = (srv.rotations || 0) + 1; setCookie = rt; res = json(200, { user: userOf(fam), session: issue(fam) }); }
    } else if (path === '/v1/auth/logout') {
      const fam = cookie ? srv.byToken.get(cookie) : null;
      if (fam) fam.revoked = true;
      setCookie = null; res = new Response(null, { status: 204 });
    } else if (path.startsWith('/v1/me')) {
      const m = /^Bearer (.+)$/.exec(h.authorization || '');
      const rec = m && srv.access.get(m[1]);
      res = rec && rec.exp > clock.t && !rec.fam.revoked ? json(200, { ok: true, userId: rec.fam.userId }) : json(401, { error: { code: 'unauthorized', message: 'x', requestId: 'r' } });
    } else res = json(404, { error: { code: 'not_found', message: 'x', requestId: 'r' } });
    if (srv.gate) await srv.gate(call);
    if (setCookie !== undefined) jar.rt = setCookie;  // Set-Cookie يُطبَّق لحظة تسليم الاستجابة
    srv.bodies.push(res.status === 204 ? '' : null);
    return res;
  }

  /** قفل Web Locks وهمي مشترك بين التبويبات (طابور FIFO). */
  const locks = (() => { let q = Promise.resolve(); return { request: (name, fn) => { const p = q.then(() => fn()); q = p.then(() => {}, () => {}); return p; } }; })();

  function tab(extra) {
    const lost = [];
    const api = ApiClient.create(Object.assign({
      baseUrl: '/', sessionTransport: 'cookie', fetch: fetchImpl, now: () => clock.t, locks,
      setTimeout: () => 1, clearTimeout: () => {}, onAuthLost: r => lost.push(r),
    }, extra));
    return { api, lost };
  }
  return { clock, jar, srv, tab, locks, fetchImpl };
}
module.exports = { world, T0, iso, tick };

/* ==========================================================================
   UI ACTIONS
   حلقة الوصل بين الشاشات والخدمات: تقرأ حقول النماذج، تستدعي AuthService/
   FavoritesService، ثم تتنقل. الشاشات لا تحتوي أي منطق دخول أو صلاحيات.
   ========================================================================== */
function _val(id) { const el = document.getElementById(id); return el ? el.value : ''; }
function _setMsg(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg || '';
  el.style.display = msg ? 'block' : 'none';
  if (msg) _focusMessage(el);
}
/** (الجزء 6.2-B) رسالة خطأ/ملاحظة ظاهرة: يُنقل إليها التركيز ويُمرَّر إليها (قارئ الشاشة يقرؤها، ومستخدم لوحة المفاتيح لا يضيع)؛ role=alert في الـmarkup */
function _focusMessage(el) {
  try {
    if (typeof el.setAttribute === 'function') el.setAttribute('tabindex', '-1');
    if (typeof el.scrollIntoView === 'function') el.scrollIntoView({ block: 'center' });
    if (typeof el.focus === 'function') el.focus({ preventScroll: true });
  } catch (e) { /* لا استثناء من التركيز */ }
}

let _loginBusy = false;
/** (11.7.2.1) دخول عبر الخادم: لا يُرسل طلبان معًا، ولا تبقى كلمة المرور في الحقل بعد الفشل. */
async function handleRemoteLogin() {
  if (_loginBusy) return;
  _loginBusy = true;
  _setMsg('loginError', '');
  _setMsg('loginNote', 'جارٍ تسجيل الدخول…');
  let r;
  try { r = await AuthService.loginRemote(_val('loginIdentifier'), _val('loginPassword')); }
  finally {
    _loginBusy = false;
    const pwEl = document.getElementById('loginPassword');   // كلمة المرور لا تبقى في الصفحة بعد الطلب (نجاحًا أو فشلًا)
    if (pwEl) pwEl.value = '';
  }
  if (currentRoute !== 'login') { render(); return; }   // انتقل المستخدم أثناء الطلب: تتبع الشاشة الحالية حالة الجلسة الجديدة
  _setMsg('loginNote', '');
  if (!r.ok) {
    const pw = document.getElementById('loginPassword');
    if (pw) pw.value = '';
    _setMsg('loginError', r.error);
    return;
  }
  const back = (currentParam && currentParam.returnTo) || 'home';
  go(back, currentParam && currentParam.returnParam);
}

function handleLoginSubmit() {
  if (AuthService.isRemote()) return handleRemoteLogin();
  const r = AuthService.login(_val('loginIdentifier'), _val('loginPassword'));
  if (!r.ok) { _setMsg('loginError', r.error); return; }
  const back = (currentParam && currentParam.returnTo) || 'home';
  go(back, currentParam && currentParam.returnParam);
}

let _registerBusy = false;
/** (11.7.2.3) تسجيل عبر الخادم. لا يُرسل دورًا/نوع حساب/بريدًا: الخادم ينشئ «مستخدمًا» دائمًا. طلب حساب صاحب معرض لم يُربط بعد. */
async function handleRemoteRegister() {
  if (_registerBusy) return;
  const typeEl = document.querySelector('input[name=accountType]:checked');
  if (typeEl && typeEl.value === 'dealer') { _setMsg('registerError', BackendAuth.messages.dealerLater); return; }   // دفاعي: الحقل مخفي في وضع الخادم
  _registerBusy = true;
  _setMsg('registerError', '');
  _setMsg('registerNote', 'جارٍ إنشاء الحساب…');
  let r;
  try { r = await AuthService.registerRemote({ name: _val('regName'), phone: _val('regPhone'), password: _val('regPassword'), confirmPassword: _val('regConfirm') }); }
  finally {
    _registerBusy = false;
    ['regPassword', 'regConfirm'].forEach((id) => { const el = document.getElementById(id); if (el) el.value = ''; });   // كلمة المرور لا تبقى في الصفحة
  }
  if (currentRoute !== 'register') { render(); return; }   // انتقل المستخدم أثناء الطلب
  _setMsg('registerNote', '');
  if (!r.ok) { _setMsg('registerError', r.error); return; }
  go('account');
}

/** (11.7-H) طلب حساب صاحب معرض: POST /v1/dealers/register بنقل الملف الآمن نفسه. لا دور ولا حالة من الواجهة؛ الحساب يُنشأ «بانتظار الموافقة» ويدخل به صاحبه. */
async function handleRemoteDealerRegister() {
  if (_registerBusy || !AuthService.isRemote()) return;
  _registerBusy = true;
  _setMsg('registerError', '');
  _setMsg('registerNote', 'جارٍ إرسال طلب التسجيل…');
  let r;
  try { r = await AuthService.registerDealerRemote({ name: _val('regName'), phone: _val('regPhone'), password: _val('regPassword'), confirmPassword: _val('regConfirm') }); }
  finally {
    _registerBusy = false;
    ['regPassword', 'regConfirm'].forEach((id) => { const el = document.getElementById(id); if (el) el.value = ''; });   // كلمة المرور لا تبقى في الصفحة
  }
  if (currentRoute !== 'register') { render(); return; }   // انتقل المستخدم أثناء الطلب
  _setMsg('registerNote', '');
  if (!r.ok) { _setMsg('registerError', r.error); return; }
  notify(BackendAuth.messages.dealerPending);
  go('account');
}

function handleRegisterSubmit() {
  if (AuthService.isRemote()) return handleRemoteRegister();
  const typeEl = document.querySelector('input[name=accountType]:checked');
  const r = AuthService.register({
    name: _val('regName'), phone: _val('regPhone'), email: _val('regEmail'),
    password: _val('regPassword'), confirmPassword: _val('regConfirm'),
    accountType: typeEl ? typeEl.value : ''
  });
  if (!r.ok) { _setMsg('registerError', r.error); return; }
  go('account');
  warnIfNotSaved(r);   // تدقيق ما قبل الباكند: لا يبقى نجاح التسجيل صامتًا إن تعذّر الحفظ على الجهاز
}

let _recoveryBusy = false;
/** (11.7.2.3) طلب رمز استعادة. الردّ المقبول واحد لأي رقم؛ وإن لم يكن مزوّد الرسائل مُفعَّلًا يُقال ذلك صراحةً ولا ننتقل. */
async function handleForgotSubmit() {
  if (_recoveryBusy) return;
  _recoveryBusy = true;
  _setMsg('forgotError', '');
  _setMsg('forgotNote', 'جارٍ الإرسال…');
  let r;
  try { r = await AuthService.requestPasswordReset(_val('forgotPhone')); }
  finally { _recoveryBusy = false; }
  if (currentRoute !== 'forgotPassword') { render(); return; }
  _setMsg('forgotNote', '');
  if (!r.ok) { _setMsg('forgotError', r.error); return; }
  go('resetPassword', { phone: r.phone, sent: true });
}

/** (11.7.2.3) تعيين كلمة مرور جديدة بالرمز. النجاح يُنهي كل جلسات الحساب، فننتقل للدخول برسالة واضحة. */
async function handleResetSubmit() {
  if (_recoveryBusy) return;
  _recoveryBusy = true;
  _setMsg('resetError', '');
  let r;
  try { r = await AuthService.resetPassword({ phone: _val('resetPhone'), code: _val('resetCode'), newPassword: _val('resetPassword'), confirmPassword: _val('resetConfirm') }); }
  finally {
    _recoveryBusy = false;
    ['resetPassword', 'resetConfirm', 'resetCode'].forEach((id) => { const el = document.getElementById(id); if (el) el.value = ''; });
  }
  if (currentRoute !== 'resetPassword') { render(); return; }
  if (!r.ok) { _setMsg('resetError', r.error); return; }
  go('login');
  _setMsg('loginNote', r.message);
}

/* ---- (11.7-F) أمان الحساب (وضع الخادم): طلب واحد في آنٍ واحد يفرضه BackendAuth؛ هنا نمنع النقر المزدوج ونمسح الحقول ---- */
let _accountActing = false;
/** تغيير كلمة المرور. النجاح يُنهي كل الجلسات (بما فيها الحالية) فننتقل للدخول برسالة واضحة. كلمات المرور لا تبقى في الصفحة. */
async function handleChangePasswordSubmit() {
  if (_accountActing) return;
  _accountActing = true;
  _setMsg('cpError', '');
  _setMsg('cpNote', 'جارٍ تغيير كلمة المرور…');
  let r;
  try { r = await BackendAuth.changeCredential({ currentPassword: _val('cpCurrent'), newPassword: _val('cpNew'), confirmPassword: _val('cpConfirm') }); }
  finally {
    _accountActing = false;
    ['cpCurrent', 'cpNew', 'cpConfirm'].forEach((id) => { const el = document.getElementById(id); if (el) el.value = ''; });
  }
  if (r.ok) { go('login'); _setMsg('loginNote', r.message); return; }
  if (currentRoute !== 'account') { render(); return; }
  _setMsg('cpNote', '');
  _setMsg('cpError', r.error);
}

/** الخروج من كل الأجهزة بعد تأكيد. الفشل لا يُخرج المستخدم ولا يدّعي نجاحًا. */
async function handleLogoutAll() {
  if (_accountActing) return;
  _accountActing = true;
  let r = null;
  try {
    _setMsg('logoutAllError', '');
    const yes = await askConfirmAsync({ title: 'الخروج من كل الأجهزة', message: 'ستنتهي جلساتك على كل الأجهزة، بما فيها هذا الجهاز، وستحتاج إلى تسجيل الدخول من جديد.', confirmLabel: 'خروج من الكل', danger: true });
    if (!yes) return;
    r = await BackendAuth.logoutAll();
  } finally { _accountActing = false; }
  if (r.ok) { go('login'); _setMsg('loginNote', r.message); return; }
  if (currentRoute !== 'account') { render(); notify(r.error, 'error'); return; }
  _setMsg('logoutAllError', r.error);
}

/** طلب رمز توثيق الهاتف. لا يُدَّعى وصول الرمز: الرسالة تقول إنه طُلب فقط. */
async function handleVerifyPhoneRequest() {
  if (_accountActing) return;
  _accountActing = true;
  _setMsg('verifyError', '');
  _setMsg('verifyNote', 'جارٍ الطلب…');
  let r;
  try { r = await BackendAuth.requestPhoneVerification(); }
  finally { _accountActing = false; }
  if (currentRoute !== 'account') { render(); return; }
  if (!r.ok) { _setMsg('verifyNote', ''); _setMsg('verifyError', r.error); return; }
  if (r.sent) { currentParam = { codeSent: true }; render(); return; }   // الشاشة نفسها: تظهر خانة الرمز (بلا تنقل ولا سجل)
  render(); _setMsg('verifyNote', r.message);   // موثّق بالفعل
}

/** تأكيد التوثيق بالرمز. الحقل يُفرَّغ بعد الطلب. */
async function handleVerifyPhoneConfirm() {
  if (_accountActing) return;
  _accountActing = true;
  _setMsg('verifyError', '');
  let r;
  try { r = await BackendAuth.confirmPhoneVerification(_val('verifyCode')); }
  finally {
    _accountActing = false;
    const el = document.getElementById('verifyCode'); if (el) el.value = '';
  }
  if (currentRoute !== 'account') { render(); return; }
  if (!r.ok) { _setMsg('verifyError', r.error); return; }
  currentParam = null; render();
  _setMsg('verifyNote', r.message);
}

function onAccountTypeChange() {
  const typeEl = document.querySelector('input[name=accountType]:checked');
  const note = document.getElementById('dealerNote');
  if (note) note.style.display = (typeEl && typeEl.value === 'dealer') ? 'block' : 'none';
}

function handleForgotPassword() {
  if (AuthService.isRemote()) { go('forgotPassword', { phone: _val('loginIdentifier') }); return; }   // 11.7.2.3
  _setMsg('loginNote', 'استعادة كلمة المرور تحتاج خادمًا (Backend) وستُضاف في مرحلة لاحقة.');
}

function fillDemoAccount(i) {
  const a = DEMO_ACCOUNTS[i];
  if (!a) return;
  const idEl = document.getElementById('loginIdentifier'), pwEl = document.getElementById('loginPassword');
  if (idEl) idEl.value = a.identifier;
  if (pwEl) pwEl.value = a.password;
}

function handleLogout() {
  const pending = AuthService.logout();   // وضع الخادم: وعد إبطال الجلسة في الخادم (الواجهة مُسحت فورًا)
  go('home');
  if (pending && typeof pending.then === 'function') {
    pending.then(r => { if (r && r.hadSession && !r.revoked) notify('تم تسجيل الخروج على هذا الجهاز، لكن تعذّر إبلاغ الخادم. ستنتهي الجلسة تلقائيًا.', 'error'); });
  }
}

/** (11.7.2.1) فقدت الجلسة نهائيًا (تجديد مرفوض/منتهٍ): الحالة مُسحت، فنُبلّغ المستخدم ونُعيد الشاشة الحالية إلى حالتها الصحيحة (دخول إن كانت محمية). */
function handleAuthLost(reason) {
  notify(BackendAuth.messages.expired, 'error');
  const route = ROUTES[currentRoute];
  let verdict = true;
  try { verdict = route && route.guard ? route.guard(currentParam) : true; } catch (e) { verdict = false; }
  if (verdict === 'login' && currentRoute !== 'login') go('login', { returnTo: currentRoute, returnParam: currentParam });
  else render();
}

/** المفضلة: الزائر يُحوَّل لتسجيل الدخول ثم يعود لنفس الشاشة */
/* (11.7-C) وضع الخادم: POST/DELETE /v1/me/favorites عبر BackendFavorites؛ لا تغيير محلي إلا بنجاح الخادم، وطلب واحد لكل سيارة في آنٍ واحد. */
async function _handleFavoriteToggleRemote(carId) {
  if (!SessionService.isLoggedIn()) { go('login', { returnTo: currentRoute, returnParam: currentParam }); return; }
  const r = await BackendFavorites.toggle(String(carId));
  if (r.busy) return;
  if (!r.ok) { if (SessionService.isLoggedIn()) notify(r.error, 'error'); return; }   // الجلسة المنتهية: handleAuthLost أبلغت المستخدم أصلًا
  notify(r.isFavorite ? 'أُضيفت السيارة إلى المفضلة' : 'أُزيلت السيارة من المفضلة');
  render();
}
function handleFavoriteToggle(carId) {
  if (BackendFavorites.isEnabled()) return _handleFavoriteToggleRemote(carId);
  const r = toggleFavorite(carId);
  if (!r.ok && r.reason === 'login_required') {
    go('login', { returnTo: currentRoute, returnParam: currentParam });
    return;
  }
  warnIfNotSaved(r);
  render();
}

/* ---- المرحلة 4/6: سيارات الأعضاء ---- */
let _currentDraftId = null;
let _rewardCountdownTimer = null;
const REWARD_AD_SECONDS = 8; // ضمن المدى المطلوب (5-10 ثوانٍ)

function _collectMemberCarFormData() {
  return {
    brand: _val('mcBrand'), model: _val('mcModel'), year: _val('mcYear'), price: _val('mcPrice'), currency: _val('mcCurrency') || undefined,   // القائمة لا تحوي خيارًا فارغًا: القيمة المختارة دائمًا (فارغ = العنصر غير موجود)
    mileage: _val('mcMileage'), transmission: _val('mcTransmission'), fuelType: _val('mcFuelType'),
    color: _val('mcColor'), location: _val('mcLocation'), phone: _val('mcPhone'),
    whatsapp: _val('mcWhatsapp'), description: _val('mcDescription'), mainImage: _val('mcImage'),
  };
}

/* ---- (11.7-B) وضع الخادم: إعلانات المستخدم عبر /v1/me/cars (api/authBridge.js → BackendMember). تحقق الواجهة قبل الإرسال، والخادم يعيد التحقق. ---- */
function _remoteMemberCarBody(edit) {
  const raw = _collectMemberCarFormData();
  const tooLong = textLimitError(raw, ['brand', 'model', 'color', 'description', 'location']);
  if (tooLong) return { error: tooLong };
  const brand = String(raw.brand || '').trim(), model = String(raw.model || '').trim(), phone = String(raw.phone || '').trim(), wa = String(raw.whatsapp || '').trim();
  if (!brand || !model || String(raw.year || '').trim() === '' || String(raw.price || '').trim() === '' || !phone) return { error: 'الرجاء تعبئة الحقول المطلوبة (الماركة، الموديل، السنة، السعر، رقم الهاتف).' };
  const hasWord = /[\p{L}\p{N}]/u;
  if (!hasWord.test(brand)) return { error: 'اسم الماركة غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
  if (!hasWord.test(model)) return { error: 'اسم الموديل غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
  const year = parseWholeNumber(raw.year); if (isNaN(year) || year < 1980 || year > 2100) return { error: 'سنة الصنع غير صحيحة.' };
  const price = parseWholeNumber(raw.price); if (isNaN(price) || price <= 0 || price > 999999999999) return { error: 'السعر غير صحيح.' };
  const cur = parseCurrency(raw.currency); if (!cur.ok) return { error: 'عملة السعر غير صحيحة. اختر الدينار العراقي أو الدولار الأمريكي.' };
  let mileage = null;
  if (String(raw.mileage || '').trim() !== '') { mileage = parseWholeNumber(raw.mileage); if (isNaN(mileage) || mileage > 10000000) return { error: 'الكيلومترات غير صحيحة.' }; }
  const body = { brand, model, year, price, currency: cur.value, mileage, transmission: String(raw.transmission || '').trim(), fuelType: String(raw.fuelType || '').trim(),
    color: String(raw.color || '').trim(), description: String(raw.description || '').trim(), phone, location: String(raw.location || '').trim() };
  if (wa) body.whatsapp = wa; else if (edit) body.whatsapp = null;   // إضافة بلا واتساب: الخادم يجعله رقم الهاتف
  return { body };
}
let _memberRemoteBusy = false;
async function _handleAddMemberCarRemote() {
  if (_memberRemoteBusy) return;
  const f = _remoteMemberCarBody(false); if (f.error) { _setMsg('addMemberCarError', f.error); return; }
  _memberRemoteBusy = true; setBusy('addMemberCarBtn', true);
  try {
    const rr = await BackendMember.createCar(f.body);
    if (!rr.ok) { _setMsg('addMemberCarError', rr.error); return; }
    notify('تم إرسال إعلانك. سيظهر للجميع بعد المراجعة. يمكنك إضافة الصور من «تعديل الإعلان».');
    go('myMemberCars');
  } finally { _memberRemoteBusy = false; setBusy('addMemberCarBtn', false); }
}
async function _handleEditMemberCarRemote(id) {
  if (_memberRemoteBusy) return;
  const st = BackendMember.car();
  if (st.status !== 'ready' || st.id !== id) return;
  const f = _remoteMemberCarBody(true); if (f.error) { _setMsg('editMemberCarError', f.error); return; }
  _memberRemoteBusy = true; setBusy('editMemberCarBtn', true);
  try {
    const rr = await BackendMember.updateCar(id, st.car.version, f.body);
    if (!rr.ok) {
      if (rr.conflict || rr.gone || rr.state) { notify(rr.error, 'error'); render(); return; }   // نسخته القديمة لا تُعاد: تُجلب نسخة الخادم الحالية
      _setMsg('editMemberCarError', rr.error); return;
    }
    notify(st.car.status === 'rejected' ? 'تم حفظ التعديلات وأُعيد إرسال الإعلان للمراجعة.' : 'تم حفظ التعديلات');   // 11.7.2-G: تعديل المرفوض = إعادة إرسال
    go('myMemberCars');
  } finally { _memberRemoteBusy = false; setBusy('editMemberCarBtn', false); }
}
/* ---- (11.7-D) صور إعلان العضو في وضع الخادم (BackendImages). تُطبَّق فورًا على الخادم؛ القسم يتحدّث وحده؛ قفل واحد يمنع الرفع المكرر. ---- */
async function handleRemoteImagePick(input) {
  const file = input && input.files && input.files[0];
  try { if (input) input.value = ''; } catch (e) { /* اختيار الملف نفسه مرة أخرى لاحقًا */ }
  if (!file || !BackendImages.isEnabled()) return;
  _riMsg = '';
  const r = await BackendImages.addToCar(_riCar, file, refreshRemoteImages);
  if (r.stale || r.busy) return;
  if (r.ok) notify('تمت إضافة الصورة'); else _riMsg = r.error;
  refreshRemoteImages();
}
let _riRemoving = false;
async function handleRemoteImageRemove(imageId) {
  if (_riRemoving || !BackendImages.isEnabled()) return;
  _riRemoving = true;
  try {
    const yes = await askConfirmAsync({ title: 'حذف الصورة', message: 'هل تريد حذف هذه الصورة من الإعلان؟', confirmLabel: 'حذف', danger: true });
    if (!yes) return;
    _riMsg = '';
    const r = await BackendImages.removeFromCar(_riCar, String(imageId), refreshRemoteImages);
    if (r.stale || r.busy) return;
    if (r.ok) notify('تم حذف الصورة'); else _riMsg = r.error;
    refreshRemoteImages();
  } finally { _riRemoving = false; }
}
function handleRemoteImagesRetry() { _riMsg = ''; BackendImages.retryGallery(_riCar, refreshRemoteImages); refreshRemoteImages(); }
const _memberDeleting = {};
async function _handleDeleteMemberCarRemote(id) {
  if (_memberDeleting[id]) return;
  const car = BackendMember.listCar(id), name = car ? `${car.brand} ${car.model}` : 'هذا الإعلان';
  _memberDeleting[id] = true;
  const yes = await askConfirmAsync({ title: 'حذف الإعلان', message: `هل أنت متأكد من حذف «${name}»؟ لا يمكن التراجع عن هذا الإجراء.`, confirmLabel: 'حذف', danger: true });
  if (!yes) { delete _memberDeleting[id]; return; }
  try {
    const rr = await BackendMember.deleteCar(id);
    if (!rr.ok) { notify(rr.error, 'error'); render(); return; }
    notify('تم حذف الإعلان');
    go('myMemberCars');
  } finally { delete _memberDeleting[id]; }
}
let _memberSoldBusy = false;
async function _handleMemberCarSoldRemote(id) {
  if (_memberSoldBusy) return;
  const car = BackendMember.listCar(id), name = car ? `${car.brand} ${car.model}` : 'هذا الإعلان';
  _memberSoldBusy = true;
  try {
    const yes = await askConfirmAsync({ title: 'تحديد كمباعة', message: `تحديد «${name}» كمباعة؟ لا يمكن إعادة نشره بعد ذلك من التطبيق.`, confirmLabel: 'تحديد كمباعة' });
    if (!yes) return;
    const rr = await BackendMember.markSold(id);
    if (!rr.ok) notify(rr.error, 'error'); else notify('تم تحديد الإعلان كمباع');
    render();
  } finally { _memberSoldBusy = false; }
}

/** الضغط على «نشر السيارة»: يبني مسودة عبر الخدمة، وهي من تقرر إن كان يحتاج إعلانًا (حسب الدور). */
let _memberSubmitBusy = false;
function handleAddMemberCarSubmit() {
  if (BackendMember.isEnabled()) return _handleAddMemberCarRemote();
  if (_memberSubmitBusy || _currentDraftId) return;   // يمنع التكرار أثناء الحفظ أو أثناء نافذة الإعلان
  const r = createDraftMemberCar(_collectMemberCarFormData());
  if (!r.ok) { _setMsg('addMemberCarError', userMsg(r.error)); return; }
  _setMsg('addMemberCarError', '');   // (تدقيق ما قبل الباكند) لا يبقى خطأ سابق ظاهرًا بعد نجاح التحقق (خلف نافذة الإعلان/بعد إلغائها)

  const imgDraft = (_imageCtx && _imageCtx.mode === 'draft') ? _imageCtx.draft : null;
  if (r.published) {
    // dealer/admin: نشر فوري بلا إعلان (قاعدة المرحلة 6)
    const finish = () => { notifySaved('تم نشر سيارتك بنجاح', r); go('myMemberCars'); };
    if (imgDraft && imgDraft.count()) {
      _memberSubmitBusy = true; setBusy('addMemberCarBtn', true);   // حفظ الصور غير فوري: نقفل الزر حتى لا تتكرر السيارة
      commitImageDraft(r.car.id, imgDraft).then(res => { _memberSubmitBusy = false; setBusy('addMemberCarBtn', false); finish(); warnImagesNotSaved(res); });
    } else finish();
    return;
  }
  // user: يحتاج مشاهدة إعلان قبل النشر
  _currentDraftId = r.draftId;
  const overlay = document.getElementById('rewardAdOverlay');
  if (overlay) {
    overlay.style.display = 'flex';
    _rewardStepLabel('Intro');
    // (الجزء 6.2-B) التركيز يدخل النافذة (زر «مشاهدة الإعلان»)، Tab محبوس داخلها، وEscape = إلغاء (قبل اكتمال الإعلان فقط)
    ModalFocus.activate(overlay, { onEscape: _rewardEscape, initial: '#rewardAdStepIntro .btn-primary' });
  }
}
/** عنوان النافذة (aria-labelledby) يتبع الخطوة الظاهرة: Intro | Playing | Done */
function _rewardStepLabel(step) {
  const box = document.getElementById('rewardAdBox');
  if (box && typeof box.setAttribute === 'function') box.setAttribute('aria-labelledby', 'rewardAdTitle' + step);
}
/** Escape داخل نافذة المكافأة: يلغي إن لم يكتمل الإعلان؛ بعد الاكتمال (النشر جارٍ) لا شيء */
function _rewardEscape() {
  const done = document.getElementById('rewardAdStepDone');
  if (done && done.style && done.style.display === 'block') return;
  handleCancelRewardAd();
}

/** الضغط على «مشاهدة الإعلان»: يطلب الإعلان من rewardService (Mock الآن، AdMob لاحقًا بنفس الواجهة) ثم يبدأ عدّادًا فعليًا. */
function handleWatchRewardAd() {
  if (!_currentDraftId || _rewardCountdownTimer) return;   // نقرة ثانية أثناء العدّ لا تبدأ عدّادًا ثانيًا
  const load = requestPublishReward(_currentDraftId);
  if (!load.ok) { _setMsg('rewardAdError', load.error || 'تعذر تحميل الإعلان، حاول مرة أخرى.'); return; }

  document.getElementById('rewardAdStepIntro').style.display = 'none';
  document.getElementById('rewardAdStepPlaying').style.display = 'block';
  _rewardStepLabel('Playing'); ModalFocus.refocus({ box: true });   // الزر المضغوط اختفى: التركيز على النافذة (لا على «إلغاء»): نقرة Enter/Space ثانية سريعة لا تلغي الإعلان بالخطأ
  let remaining = REWARD_AD_SECONDS;
  const el = document.getElementById('rewardAdCountdown');
  const tick = () => { if (el) el.textContent = '00:' + String(remaining).padStart(2, '0'); };
  tick();
  _rewardCountdownTimer = setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(_rewardCountdownTimer);
      _rewardCountdownTimer = null;
      _completeRewardAndPublish();
      return;
    }
    tick();
  }, 1000);
}

/** ينفَّذ فقط عند وصول العدّاد إلى الصفر فعليًا — لا طريقة أخرى لتعليم الإعلان كمكتمل من الواجهة. */
function _completeRewardAndPublish() {
  const draftId = _currentDraftId;
  if (!draftId) return;   // اكتمل/أُلغي مسبقًا: لا رسالة خطأ متأخرة
  const completed = onRewardCompleted(draftId); // rewardService: يسجّل الاكتمال لنفس draftId تحديدًا
  if (!completed.ok) { _setMsg('rewardAdError', 'تعذر إكمال الإعلان، حاول مرة أخرى.'); return; }

  const r = publishMemberCarAfterReward(draftId);
  if (!r.ok) { _setMsg('rewardAdError', r.error); return; }
  warnIfNotSaved(r);

  document.getElementById('rewardAdStepPlaying').style.display = 'none';
  document.getElementById('rewardAdStepDone').style.display = 'block';
  _rewardStepLabel('Done'); ModalFocus.refocus({ box: true });     // خطوة «اكتمل» بلا أزرار: التركيز على النافذة نفسها فيُقرأ العنوان
  _currentDraftId = null;
  // صور الإعلان المضغوطة تُخزَّن بعد النشر (المرحلة 7)، ثم ننتقل لإعلاناتي
  const imgDraft = (_imageCtx && _imageCtx.mode === 'draft') ? _imageCtx.draft : null;
  const saved = (imgDraft && imgDraft.count()) ? commitImageDraft(r.car.id, imgDraft) : Promise.resolve();
  saved.then(res => { warnImagesNotSaved(res); setTimeout(() => { go('myMemberCars'); }, 1200); });
}

/** إغلاق/إلغاء الإعلان قبل اكتماله: لا نشر إطلاقًا، والمسودة تُهمَل (يمكن المحاولة من جديد بالضغط على نشر ثانية). */
function handleCancelRewardAd() {
  if (_rewardCountdownTimer) { clearInterval(_rewardCountdownTimer); _rewardCountdownTimer = null; }
  if (_currentDraftId) {
    onRewardCancelled(_currentDraftId);
    discardMemberCarDraft(_currentDraftId);
    _currentDraftId = null;
  }
  const overlay = document.getElementById('rewardAdOverlay');
  if (overlay) overlay.style.display = 'none';
  _rewardStepLabel('Intro'); ModalFocus.deactivate();     // يعود التركيز إلى زر «نشر السيارة» الذي فتحها
  const intro = document.getElementById('rewardAdStepIntro'), playing = document.getElementById('rewardAdStepPlaying'), done = document.getElementById('rewardAdStepDone');
  if (intro) intro.style.display = 'block';
  if (playing) playing.style.display = 'none';
  if (done) done.style.display = 'none';
}

function handleEditMemberCarSubmit(id) {
  if (BackendMember.isEnabled()) return _handleEditMemberCarRemote(String(id));
  const r = updateMemberCar(id, {
    brand: _val('mcBrand'), model: _val('mcModel'), year: _val('mcYear'),
    price: _val('mcPrice'), currency: _val('mcCurrency') || undefined, mileage: _val('mcMileage'), transmission: _val('mcTransmission'), fuelType: _val('mcFuelType'),
    color: _val('mcColor'), location: _val('mcLocation'), phone: _val('mcPhone'), whatsapp: _val('mcWhatsapp'),
    description: _val('mcDescription'),
  });
  if (!r.ok) { _setMsg('editMemberCarError', userMsg(r.error)); return; }
  notifySaved('تم حفظ التعديلات', r);
  go('memberCarDetails', id);
}

function handleDeleteMemberCar(id) {
  if (BackendMember.isEnabled()) return _handleDeleteMemberCarRemote(String(id));
  const car = getMemberCarById(id);
  const name = car ? `${car.brand} ${car.model}` : 'هذا الإعلان';
  askConfirm({ title: 'حذف الإعلان', message: `هل أنت متأكد من حذف «${name}»؟ لا يمكن التراجع عن هذا الإجراء.`, confirmLabel: 'حذف', danger: true }, () => {
    const r = deleteMemberCar(id);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    go('myMemberCars');
  });
}

/** المالك: active/sold فقط. المدير: أي من الحالات الخمس (يتحقق منها changeMemberCarStatus نفسها). */
function handleMemberCarStatusChange(id) {
  if (BackendMember.isEnabled()) return _handleMemberCarSoldRemote(String(id));
  const car = getMemberCarById(id);
  if (!car) return;
  const isAdmin = AuthorizationService.canAccessAdmin();
  const options = isAdmin
    ? Object.values(MEMBER_CAR_STATUS)
    : [MEMBER_CAR_STATUS.ACTIVE, MEMBER_CAR_STATUS.SOLD];
  const labels = options.map(s => `${s} = ${MEMBER_CAR_STATUS_LABEL[s]}`).join('\n');
  // (الجزء 6.2-B) اختيار بالأزرار بدل كتابة الرمز؛ الصلاحية والتحقق في changeMemberCarStatus كما كانا
  askChoice({ title: 'تغيير حالة الإعلان', options: options.map(s => ({ value: s, label: MEMBER_CAR_STATUS_LABEL[s] })), current: car.status,
              nativeMessage: `أدخل الحالة الجديدة:\n${labels}`, nativeDefault: car.status }, status => {
    const r = changeMemberCarStatus(id, status);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}

function handleShareMemberCar(id) {
  const car = getMemberCarById(id);
  if (!car) return;
  const text = `${car.brand} ${car.model} ${car.year} — ${carPriceOrDash(car)} — معارض النجف`;
  if (navigator.share) {
    navigator.share({ title: 'معارض النجف', text, url: location.href }).catch(() => {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(text + ' ' + location.href).then(() => notify('تم نسخ رابط الإعلان')).catch(() => notify(text));
  } else {
    notify(text);
  }
}

/* ---- المرحلة 5: لوحة الإدارة ---- */
function handleApproveMemberCar(id) {
  const r = approveMemberCar(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  notifySaved('تمت الموافقة على الإعلان ونشره', r);
  render();
}
function handleRejectMemberCar(id) {
  askText({ title: 'رفض الإعلان', label: 'سبب الرفض', confirmLabel: 'رفض الإعلان', nativeMessage: 'سبب الرفض:' }, reason => {
    const r = rejectMemberCar(id, reason);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}
function handleSuspendMemberCarAdmin(id) {
  askText({ title: 'إيقاف الإعلان', label: 'سبب الإيقاف (اختياري)', confirmLabel: 'إيقاف الإعلان', nativeMessage: 'سبب الإيقاف (اختياري):', nativeDefault: '' }, reason => {
    const r = suspendMemberCarAdmin(id, reason);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}
function handleRestoreMemberCarAdmin(id) {
  const r = restoreMemberCar(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleAdminSuspendShowroom(id) {
  const r = suspendShowroom(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleAdminActivateShowroom(id) {
  const r = activateShowroom(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleAdminShowroomCarStatusChange(id) {
  const car = getCarById(id);
  askChoice({ title: 'تغيير حالة السيارة', options: SHOWROOM_CAR_STATUSES.map(s => ({ value: s, label: CAR_STATUS_LABEL[s] })), current: car ? car.status : undefined,
              nativeMessage: 'أدخل الحالة الجديدة:\navailable = متاحة للبيع\nsold = مباعة', nativeDefault: 'available' }, status => {
    const r = setShowroomCarStatus(id, status);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}
/* ---- (11.7-E) أصحاب المعارض في وضع الخادم (BackendAdmin): تبويب/المزيد/إعادة المحاولة وإجراء واحد في آنٍ واحد. ---- */
function handleAdminDealersTab(key) { BackendAdmin.setFilter(key, _rerenderIf('adminDealerRequests')); }
function handleAdminDealersMore() { BackendAdmin.more(_rerenderIf('adminDealerRequests')); render(); }
function handleAdminDealersRetry() { BackendAdmin.retry(_rerenderIf('adminDealerRequests')); render(); }
let _adminDealerActing = false;
async function handleAdminDealerAction(action, id) {
  if (_adminDealerActing || !BackendAdmin.isEnabled()) return;
  _adminDealerActing = true;
  try {
    const cfg = BackendAdmin.view().items.filter(d => d.id === String(id)).map(d => d.actions.filter(a => a.action === action)[0])[0];
    if (cfg && cfg.confirm) {
      const yes = await askConfirmAsync({ title: cfg.confirm.title, message: cfg.confirm.message, confirmLabel: cfg.confirm.confirmLabel, danger: true });
      if (!yes) return;
    }
    const r = await BackendAdmin.act(action, String(id), _rerenderIf('adminDealerRequests'));
    if (r.stale || r.busy) return;
    if (r.ok) notify(r.message); else notify(r.error, 'error');
    if (currentRoute === 'adminDealerRequests') render();
  } finally { _adminDealerActing = false; }
}
/* ---- (11.7.2-G) مراجعة إعلانات الأعضاء في وضع الخادم (BackendModeration). تأكيد قبل كل إجراء، سبب إلزامي للإيقاف واختياري للرفض، وقفل واحد يمنع الإجراء المكرر. ---- */
function handleModerationTab(key) { BackendModeration.setFilter(key, _rerenderIf('adminMemberCars')); currentParam = key; render(); }
function handleModerationMore() { BackendModeration.more(_rerenderIf('adminMemberCars')); render(); }
function handleModerationRetry() { BackendModeration.retry(_rerenderIf('adminMemberCars')); render(); }
const _MOD_DLG = {
  approve: { kind: 'confirm', title: 'الموافقة ونشر الإعلان', message: 'سيصبح الإعلان ظاهرًا للعامة إن تحقق الخادم من إعلان المكافأة. هل تريد المتابعة؟', confirmLabel: 'موافقة ونشر' },
  restore: { kind: 'confirm', title: 'استعادة الإعلان', message: 'سيعود الإعلان ظاهرًا للعامة. هل تريد المتابعة؟', confirmLabel: 'استعادة' },
  reject: { kind: 'text', title: 'رفض الإعلان', label: 'سبب الرفض (اختياري)', confirmLabel: 'رفض الإعلان', required: false },
  suspend: { kind: 'text', title: 'إيقاف الإعلان', label: 'سبب الإيقاف (مطلوب)', confirmLabel: 'إيقاف الإعلان', required: true, requiredMessage: 'سبب الإيقاف مطلوب.' },
};
/** يعيد null عند الإلغاء، وإلا النص (قد يكون '' للرفض بلا سبب). */
function _askModerationInput(action) {
  const d = _MOD_DLG[action];
  if (d.kind === 'confirm') return askConfirmAsync({ title: d.title, message: d.message, confirmLabel: d.confirmLabel, danger: false }).then(y => (y ? '' : null));
  return new Promise(res => askText({ title: d.title, label: d.label, confirmLabel: d.confirmLabel, required: d.required, requiredMessage: d.requiredMessage, nativeMessage: d.label + ':', nativeDefault: '' }, v => res(v === undefined || v === null ? '' : String(v)), () => res(null)));
}
let _modActing = false;
async function handleModerationAction(action, id) {
  if (_modActing || !BackendModeration.isEnabled()) return;
  _modActing = true;
  try {
    const c = BackendModeration.get(String(id));
    if (!c || !c.actions.some(a => a.action === action)) { notify(BackendModeration.messages.unknown, 'error'); return; }
    const reason = await _askModerationInput(action);
    if (reason === null) return;
    _adminModMsg = '';
    const r = await BackendModeration.act(action, String(id), reason, _rerenderIf(currentRoute));
    if (r.stale || r.busy) return;
    if (r.ok) { notify(r.message); if (currentRoute === 'adminMemberCarDetails') { goBack('adminMemberCars'); return; } }
    else {
      notify(r.error, 'error');
      if (r.state || r.gone) { if (currentRoute === 'adminMemberCarDetails') { goBack('adminMemberCars'); return; } }
      else if (currentRoute === 'adminMemberCarDetails') _adminModMsg = r.error;
    }
    render();
  } finally { _modActing = false; }
}
function handleApproveDealer(id) {
  const r = approveDealer(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleRejectDealer(id) {
  askConfirm({ title: 'رفض طلب صاحب المعرض', message: 'هل أنت متأكد من رفض هذا الطلب؟ سيبقى الحساب موجودًا بلا صلاحية إدارة معرض.', confirmLabel: 'رفض الطلب', danger: true }, () => {
    const r = rejectDealer(id);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}

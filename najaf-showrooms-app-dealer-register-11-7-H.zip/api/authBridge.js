/* ==========================================================================
   BACKEND AUTH — جسر المصادقة الحقيقية (المرحلة 11.7.2.1)
   يربط تسجيل الدخول والخروج بالخادم عبر ApiClient وفق العقد الموجود (backend/src/auth/routes.ts):
     POST /v1/auth/login  { phone, password } → 200 { user, session }
     POST /v1/auth/logout { refreshToken }     → 204
   (التجديد عند انتهاء رمز الوصول يتم داخل ApiClient بعقد POST /v1/auth/refresh نفسه.)

   الوضعان (يُحدَّدان عند التشغيل من وسم <meta name="najaf-api-base-url">، انظر api/README.md):
     • العنوان فارغ (الافتراضي) = وضع التجربة المحلي: لا يُنشئ هذا الملف أي عميل ولا يتصل بشيء، والتطبيق يعمل كما كان.
     • العنوان مضبوط = وضع الخادم: الدخول والخروج من الخادم فقط. لا رجوع إلى الحسابات التجريبية المحلية، ولا تُقرأ
       الجلسة المحلية القديمة ولا تُكتب جلسة محلية. بيانات السيارات/المعارض/المفضلة ما زالت محلية تجريبية (لم تُربط بعد).

   (11.7.2.3) التسجيل واستعادة كلمة المرور — بالعقد الموجود فقط:
     POST /v1/auth/register        { name, phone, password }       → 201 { user, session }  (الدور «مستخدم» دائمًا من الخادم؛ لا يُرسل العميل دورًا أبدًا)
     POST /v1/auth/password/forgot { phone }                        → 202 { status:'accepted' } | 503 delivery_unavailable (لا مزوّد رسائل مُفعَّل)
     POST /v1/auth/password/reset  { phone, code, newPassword }     → 200 { status:'password_reset' } | 400 invalid_code
   التسجيل يمرّ بنقل الملف نفسه وبقفل الجلسة نفسه (فلا يظهر رمز تجديد لـ JavaScript). حساب صاحب المعرض وإدارته خارج هذه الخطوة.
   الاستعادة لا تعمل فعليًا حتى يُربط مزوّد SMS/واتساب في الخلفية (انظر api/README.md)؛ الواجهة لا تدّعي إرسالًا لم يتم.

   (11.7-F) إكمال المصادقة — أمان الحساب، بالعقد الموجود فقط (backend/src/auth/routes.ts)، والمعرّف دائمًا من رمز الوصول لا من الطلب:
     POST /v1/auth/password/change      { currentPassword, newPassword } → 200 { status:'password_changed' }  (يُنهي كل الجلسات بما فيها الحالية)
     POST /v1/auth/logout/all           (بلا جسم)                        → 204                                   (يُنهي كل الجلسات)
     POST /v1/auth/phone/verify/request (بلا جسم)                        → 202 { status:'sent' } | 200 { status:'already_verified' }
     POST /v1/auth/phone/verify/confirm { code }                         → 200 { user }  (phoneVerified=true) | 400 invalid_code
   بعد تغيير كلمة المرور أو الخروج الشامل تُمسح حالة الواجهة ويُستدعى خروج عادي (أفضل جهد) لمسح ملف الارتباط؛ لا يُدّعى بقاء الجلسة.

   (11.7.2.2) استعادة الجلسة بعد إعادة التحميل — فقط عند <meta name="najaf-session-transport" content="cookie"> وخلفية مفعّلة بـ AUTH_COOKIE_ORIGINS:
     • رمز التجديد في ملف ارتباط HttpOnly يضعه الخادم (لا يراه JavaScript إطلاقًا)؛ restore() تجدّد مرة واحدة عند الإقلاع فيعود المستخدم.
     • «تلميح» بوليانيّ فقط (AuthHint في storage/localStorageAdapter.js، المفتاح najaf-auth-hint = 1) كي لا يطلب الزوّار تجديدًا عند كل فتح. ليس اعتمادًا ولا يحوي رمزًا،
       ولا يُصدَّق: الخادم وحده يقرّر. غيابه (وتخزين يعمل) = لا محاولة. تعذّر التخزين = تجربة الاستعادة دائمًا.
     • عدّاد gen: دخول/خروج/فقدان جلسة أثناء الاستعادة يُلغي نتيجتها (لا تُحيا جلسة خرج منها المستخدم ولا تستبدل جلسة جديدة).

   الأمان:
     • الرموز تبقى داخل ApiClient في الذاكرة فقط؛ هذا الملف لا يراها ولا يخزّنها ولا يسجّلها.
     • كلمة المرور تُمرَّر لطلب الدخول فقط، ولا تُخزَّن ولا تُسجَّل ولا تبقى في أي متغير بعد الطلب.
     • هذا الملف لا يذكر التخزين إطلاقًا؛ التلميح البوليانيّ أعلاه يمرّ عبر محوّل التخزين وحده. وبلا وضع الملف (الافتراضي القديم) إعادة التحميل تُنهي الجلسة (api/README.md).
     • مستخدم الخادم يحمل معرّفًا ببادئة «srv:» كي لا يتطابق أبدًا مع معرّف مستخدم تجريبي محلي (فلا يرث ملكية بيانات تجريبية).
   ========================================================================== */
const BackendAuth = (function () {
  const MSG = {
    badInput: 'أدخل رقم الهاتف وكلمة المرور.',
    badPhone: 'رقم الهاتف غير صحيح. مثال: 07701234567',
    email: 'تسجيل الدخول عبر الخادم يتم برقم الهاتف فقط.',
    credentials: 'بيانات الدخول غير صحيحة.',
    validation: 'تحقق من رقم الهاتف وكلمة المرور.',
    network: 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.',
    timeout: 'انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.',
    server: 'حدث خطأ في الخادم. حاول لاحقًا.',
    invalid: 'ردّ الخادم غير صالح. حاول لاحقًا.',
    config: 'إعداد الاتصال بالخادم غير صحيح.',
    expired: 'انتهت الجلسة. سجّل الدخول من جديد.',
    busy: 'جارٍ تسجيل الدخول…',
    register: 'إنشاء الحساب عبر الخادم سيتوفر في خطوة لاحقة.',
    generic: 'تعذّر تسجيل الدخول. حاول مرة أخرى.',
    nameShort: 'الاسم يجب ألا يقل عن 3 أحرف.',
    nameLong: 'الاسم طويل جدًا (الحد الأقصى 100 حرف).',
    nameBad: 'الاسم يحوي رموزًا غير مسموحة.',
    passwordShort: 'كلمة المرور يجب ألا تقل عن 6 أحرف.',
    passwordLong: 'كلمة المرور طويلة جدًا (الحد الأقصى 128 حرفًا).',
    passwordBad: 'كلمة المرور تحوي رموزًا غير مسموحة.',
    mismatch: 'كلمتا المرور غير متطابقتين.',
    registerConflict: 'تعذّر إنشاء الحساب بهذه البيانات. إن كان لديك حساب فسجّل الدخول.',
    dealerLater: 'لإنشاء حساب صاحب معرض استخدم زر «تسجيل كصاحب معرض».',
    dealerPending: 'تم إنشاء حسابك وهو بانتظار موافقة الإدارة. يمكنك الدخول به، ولن تُفعَّل إدارة المعرض إلا بعد الموافقة.',
    recoveryUnavailable: 'استعادة كلمة المرور غير متاحة الآن: خدمة إرسال الرموز (SMS/واتساب) لم تُفعَّل على الخادم بعد. تواصل مع الدعم.',
    recoverySent: 'إن كان الرقم مسجّلًا لدينا فسيصلك رمز تحقق خلال دقائق. أدخله مع كلمة المرور الجديدة.',
    invalidCode: 'الرمز غير صحيح أو منتهي الصلاحية. اطلب رمزًا جديدًا إن لزم.',
    codeFormat: 'الرمز مكوّن من 6 أرقام.',
    resetDone: 'تم تغيير كلمة المرور. سجّل الدخول بكلمة المرور الجديدة.',
    restoreFailed: 'تعذّر استعادة جلستك الآن. تحقق من الاتصال أو سجّل الدخول من جديد.',
    // (11.7-F) أمان الحساب
    currentRequired: 'أدخل كلمة المرور الحالية.',
    currentWrong: 'كلمة المرور الحالية غير صحيحة.',
    samePassword: 'كلمة المرور الجديدة يجب أن تختلف عن الحالية.',
    passwordChanged: 'تم تغيير كلمة المرور وأُنهيت جلساتك على كل الأجهزة. سجّل الدخول بكلمة المرور الجديدة.',
    logoutAllDone: 'تم تسجيل الخروج من كل الأجهزة. سجّل الدخول من جديد.',
    accountBusy: 'جارٍ تنفيذ طلب سابق…',
    phoneCodeSent: 'طُلب إرسال رمز التوثيق إلى رقمك. إن لم يصلك خلال دقائق فقد تكون خدمة الرسائل غير مفعّلة على الخادم بعد.',
    phoneAlready: 'رقم هاتفك موثّق بالفعل.',
    phoneVerified: 'تم توثيق رقم هاتفك.',
    phoneUnavailable: 'توثيق الهاتف غير متاح الآن: خدمة إرسال الرموز (SMS/واتساب) لم تُفعَّل على الخادم بعد.',
  };
  let enabled = false;
  let misconfigured = false;
  let client = null;
  let user = null;
  let busy = false;
  let recoveryBusy = false;
  let accountBusy = false;   // (11.7-F) طلب واحد لأمان الحساب في آنٍ واحد (تغيير كلمة المرور/الخروج الشامل/التوثيق)
  let lostListener = null;
  let gen = 0;            // يزيد عند أي تغيير لهوية الواجهة (دخول/خروج/فقدان): نتيجة استعادة قديمة لا تُطبَّق
  let restoring = null;
  let hint = null;        // { get(): '1'|null|'unavailable', set(), clear() } — تلميح بوليانيّ فقط، لا رموز

  function defaultHint() { return typeof AuthHint !== 'undefined' ? AuthHint : null; }   // يعرّفه محوّل التخزين (الملف الوحيد الذي يلمس التخزين)
  function hintSet() { if (hint) hint.set(); }
  function hintClear() { if (hint) hint.clear(); }
  /** (11.7-D) يحرّر روابط Blob الخاصة (صور المستخدم) فور خروجه أو فقدانه الجلسة، لا عند أول وصول لاحق. */
  function dropImages() { try { if (typeof BackendImages !== 'undefined') BackendImages.reset(); if (typeof BackendAdmin !== 'undefined') BackendAdmin.reset(); } catch (e) { /* لا يكسر الخروج */ } }

  /** الخادم فقد الجلسة نهائيًا (تجديد مرفوض/منتهٍ): تُمسح الحالة هنا أولًا ثم يُبلَّغ مستمع الواجهة. */
  function handleLost(reason) {
    user = null; gen++; hintClear(); dropImages();
    if (lostListener) { try { lostListener(reason); } catch (e) { /* مستمع الواجهة لا يكسر العميل */ } }
  }

  /**
   * يُستدعى عند التشغيل. opts (للاختبار): baseUrl وخيارات ApiClient.create (fetch، now، ...). بلا opts يُقرأ العنوان من الصفحة.
   * يعيد true إن كان وضع الخادم مفعّلًا. عنوان مضبوط لكنه غير صالح = وضع الخادم «معطّل الإعداد» (الدخول يفشل برسالة، ولا رجوع للوضع المحلي).
   */
  function init(opts) {
    opts = opts || {};
    enabled = false; misconfigured = false; client = null; user = null; busy = false; recoveryBusy = false; accountBusy = false; gen++; restoring = null; hint = null;
    let raw = '';
    try { raw = opts.baseUrl !== undefined ? String(opts.baseUrl || '').trim() : ApiClient.readConfiguredBaseUrl(); } catch (e) { raw = ''; }
    if (!raw) return false;
    enabled = true;
    let transport = opts.sessionTransport;
    if (transport === undefined) {
      try { const m = typeof document !== 'undefined' && document.querySelector ? document.querySelector('meta[name="najaf-session-transport"]') : null; transport = m && typeof m.content === 'string' ? m.content.trim() : ''; } catch (e) { transport = ''; }
    }
    transport = transport === 'cookie' ? 'cookie' : 'body';
    try { client = ApiClient.create(Object.assign({}, opts, { baseUrl: raw, sessionTransport: transport, onAuthLost: handleLost })); } catch (e) { misconfigured = true; }
    if (client && transport === 'cookie') hint = opts.hint !== undefined ? opts.hint : defaultHint();
    return true;
  }

  /** أخطاء الحقول من الخادم (رمز آلي فقط، بلا قيم) → رسالة عربية. تُستعمل احتياطًا؛ العميل يتحقق أولًا. */
  function fieldMessage(fields) {
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i] || {};
      if (f.code === 'same_as_current') return MSG.samePassword;
      if (f.field === 'currentPassword') return f.code === 'too_long' ? MSG.passwordLong : MSG.currentRequired;
      if (f.field === 'name') return f.code === 'too_long' ? MSG.nameLong : f.code === 'invalid_format' ? MSG.nameBad : MSG.nameShort;
      if (f.field === 'phone') return MSG.badPhone;
      if (f.field === 'password' || f.field === 'newPassword') return f.code === 'too_long' ? MSG.passwordLong : f.code === 'invalid_format' ? MSG.passwordBad : MSG.passwordShort;
      if (f.field === 'code') return MSG.codeFormat;
    }
    return null;
  }

  function messageFor(err, context) {
    if (!err || err.name !== 'ApiError') return MSG.generic;
    if (err.kind === 'network') return MSG.network;
    if (err.kind === 'timeout') return MSG.timeout;
    if (err.kind === 'aborted') return 'أُلغي الطلب.';
    if (err.kind === 'config') return MSG.config;
    if (err.kind === 'invalid_response') return MSG.invalid;
    if (err.kind === 'auth') return MSG.expired;
    if (err.kind === 'http') {
      if (err.status === 401) return context === 'session' ? MSG.expired : MSG.credentials;
      if ((err.status === 400 && err.code === 'session_transport_unsupported') || (err.status === 403 && err.code === 'forbidden_origin')) return MSG.config;   // الخادم لا يقبل هذا النقل/الأصل: إعداد لا خطأ مستخدم
      if (err.status === 400 && err.code === 'invalid_code') return MSG.invalidCode;
      if (err.status === 400 && err.code === 'invalid_current_password') return MSG.currentWrong;
      if (err.status === 400 && Array.isArray(err.fields)) { const m = fieldMessage(err.fields); if (m) return m; }
      if (err.status === 409 && context === 'register') return MSG.registerConflict;
      if (err.status === 503 && err.code === 'delivery_unavailable') return context === 'phone' ? MSG.phoneUnavailable : MSG.recoveryUnavailable;
      if (err.status === 400) return MSG.validation;
      if (err.status === 429) {
        const m = Number.isFinite(err.retryAfterSeconds) ? Math.max(1, Math.ceil(err.retryAfterSeconds / 60)) : 0;
        return 'محاولات كثيرة. ' + (m ? 'حاول بعد ' + m + ' دقيقة.' : 'انتظر قليلًا ثم حاول مرة أخرى.');
      }
      if (err.status >= 500) return MSG.server;
    }
    return MSG.generic;
  }

  /** مستخدم الخادم بالشكل الذي تفهمه الواجهة (نفس حقول UserService.toPublic). null إن كان الشكل أو الدور أو الحالة غير معروف. */
  function toLocalShape(u) {
    if (!u || typeof u !== 'object') return null;
    const roles = Object.keys(ROLES).map(function (k) { return ROLES[k]; });
    const statuses = Object.keys(USER_STATUS).map(function (k) { return USER_STATUS[k]; });
    if (typeof u.id !== 'string' || !/^[0-9]{1,20}$/.test(u.id)) return null;
    if (typeof u.name !== 'string' || !u.name || typeof u.phone !== 'string') return null;
    if (roles.indexOf(u.role) < 0 || statuses.indexOf(u.status) < 0) return null;
    return { id: 'srv:' + u.id, name: u.name, phone: normalizePhone(u.phone) || u.phone, email: null, role: u.role, status: u.status, createdAt: typeof u.createdAt === 'string' ? u.createdAt : null };
  }
  /** (11.7-F) حالة توثيق الهاتف من الخادم، مربوطة بمعرّف مستخدم الواجهة (لا تُضاف لشكل المستخدم المحلي). */
  let verifiedFor = null;
  function noteVerified(u, id) { verifiedFor = u && u.phoneVerified === true ? id : null; }

  /** تسجيل الدخول. يعيد دائمًا { ok:true, user } أو { ok:false, error: نص عربي آمن }. لا يرمي. */
  async function login(identifier, password) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (busy) return { ok: false, error: MSG.busy };
    const id = String(identifier == null ? '' : identifier).trim();
    const pw = password == null ? '' : String(password);
    if (!id || !pw) return { ok: false, error: MSG.badInput };
    if (id.indexOf('@') >= 0) return { ok: false, error: MSG.email };       // العقد: الدخول بالهاتف فقط
    const phone = normalizePhone(id);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const tooLong = textLimitError({ password: pw }, ['password']);
    if (tooLong) return { ok: false, error: tooLong };
    busy = true;
    try {
      // الدخول والتخزين داخل العميل (تحت القفل): هنا نتحقق من شكل المستخدم فقط، فإن لم يُقبل لا تبقى جلسة.
      let mapped = null;
      await client.login({ phone: phone, password: pw }, function (data) { mapped = toLocalShape(data && data.user); if (mapped) noteVerified(data.user, mapped.id); return !!mapped; });
      user = mapped; gen++; hintSet();
      return { ok: true, user: Object.assign({}, mapped) };
    } catch (e) {
      client.clearSession();             // لا جلسة نصف مكتملة بعد أي فشل
      user = null; gen++;
      return { ok: false, error: messageFor(e, 'login') };
    } finally {
      busy = false;
    }
  }

  /**
   * تسجيل الخروج: حالة الواجهة تُمسح فورًا (متزامنًا)، ثم يُبطَل رمز الجلسة في الخادم.
   * الوعد لا يُرفض أبدًا: { hadSession, revoked, error? }. revoked=false مع hadSession=true = خرج المستخدم محليًا لكن تعذّر إبلاغ الخادم.
   */
  function logout() {
    user = null; gen++; hintClear(); dropImages();
    if (!client) return Promise.resolve({ hadSession: false, revoked: false });
    return client.logout().catch(function () { return { hadSession: true, revoked: false }; });
  }


  const cpLen = function (t) { return Array.from(t).length; };
  // eslint-disable-next-line no-control-regex
  const CONTROL = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;
  /** نفس قواعد الخادم (backend/src/auth/validation.ts) لتجنّب طلب شبكة محكوم عليه بالفشل. الخادم يبقى الحَكَم. */
  function checkNewPassword(pw) {
    if (typeof pw !== 'string' || pw === '') return MSG.badInput;
    if (pw.indexOf('\u0000') >= 0) return MSG.passwordBad;
    const n = cpLen(pw);
    if (n > 128) return MSG.passwordLong;
    if (n < 6) return MSG.passwordShort;
    return null;
  }

  /**
   * (11.7.2.3) إنشاء حساب عبر الخادم. الجسم المُرسَل {name, phone, password} فقط: لا دور ولا حالة ولا نوع حساب ولا بريد (الخادم يرفض أي حقل آخر).
   * يعيد { ok:true, user } (المستخدم مسجَّل الدخول بجلسته) أو { ok:false, error }. لا يرمي.
   */
  async function register(input) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (busy) return { ok: false, error: MSG.busy };
    input = input || {};
    const name = String(input.name == null ? '' : input.name).normalize('NFC').trim();
    const pw = input.password == null ? '' : String(input.password);
    if (!name) return { ok: false, error: MSG.nameShort };
    if (CONTROL.test(name)) return { ok: false, error: MSG.nameBad };
    if (cpLen(name) < 3) return { ok: false, error: MSG.nameShort };
    if (cpLen(name) > 100) return { ok: false, error: MSG.nameLong };
    const phone = normalizePhone(input.phone);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const pwErr = checkNewPassword(pw);
    if (pwErr) return { ok: false, error: pwErr };
    if (input.confirmPassword !== undefined && String(input.confirmPassword) !== pw) return { ok: false, error: MSG.mismatch };
    busy = true;
    try {
      let mapped = null;
      await client.register({ name: name, phone: phone, password: pw }, function (data) { mapped = toLocalShape(data && data.user); if (mapped) noteVerified(data.user, mapped.id); return !!mapped; });
      user = mapped; gen++; hintSet();
      return { ok: true, user: Object.assign({}, mapped) };
    } catch (e) {
      client.clearSession();
      user = null; gen++;
      return { ok: false, error: messageFor(e, 'register') };
    } finally {
      busy = false;
    }
  }

  /** (11.7.2.3) طلب رمز استعادة: POST /v1/auth/password/forgot. الردّ المقبول متطابق لأي رقم (لا كشف لوجود حساب). { ok, error?, unavailable? } */
  async function requestRecovery(identifier) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (recoveryBusy) return { ok: false, error: MSG.busy };
    const raw = String(identifier == null ? '' : identifier).trim();
    if (!raw) return { ok: false, error: MSG.badInput };
    if (raw.indexOf('@') >= 0) return { ok: false, error: MSG.email };
    const phone = normalizePhone(raw);
    if (!phone) return { ok: false, error: MSG.badPhone };
    recoveryBusy = true;
    try {
      await client.post('/v1/auth/password/forgot', { phone: phone }, { auth: 'none' });
      return { ok: true, message: MSG.recoverySent, phone: phone };
    } catch (e) {
      return { ok: false, error: messageFor(e, 'recovery'), unavailable: !!(e && e.status === 503 && e.code === 'delivery_unavailable') };
    } finally {
      recoveryBusy = false;
    }
  }

  /** (11.7.2.3) إعادة التعيين: POST /v1/auth/password/reset. نجاحها يُنهي كل جلسات الحساب في الخادم، فنمسح حالتنا المحلية أيضًا. */
  /**
   * (11.7-H) طلب حساب صاحب معرض: POST /v1/dealers/register بالجسم نفسه {name, phone, password} ونقل الجلسة نفسه (ملف ارتباط HttpOnly عند نقل الملف).
   * لا دور ولا حالة من الواجهة: الخادم يُنشئ حسابًا «بانتظار الموافقة» ويدخل به صاحبه؛ أي ردّ بغير ذلك يُرفض وتُبطَل جلسته.
   * يعيد { ok:true, user } أو { ok:false, error }. لا يرمي.
   */
  async function registerDealer(input) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (busy) return { ok: false, error: MSG.busy };
    input = input || {};
    const name = String(input.name == null ? '' : input.name).normalize('NFC').trim();
    const pw = input.password == null ? '' : String(input.password);
    if (!name) return { ok: false, error: MSG.nameShort };
    if (CONTROL.test(name)) return { ok: false, error: MSG.nameBad };
    if (cpLen(name) < 3) return { ok: false, error: MSG.nameShort };
    if (cpLen(name) > 100) return { ok: false, error: MSG.nameLong };
    const phone = normalizePhone(input.phone);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const pwErr = checkNewPassword(pw);
    if (pwErr) return { ok: false, error: pwErr };
    if (input.confirmPassword !== undefined && String(input.confirmPassword) !== pw) return { ok: false, error: MSG.mismatch };
    busy = true;
    try {
      let mapped = null;
      await client.registerDealer({ name: name, phone: phone, password: pw }, function (data) {
        mapped = toLocalShape(data && data.user);
        if (mapped && !(mapped.role === ROLES.DEALER && mapped.status === USER_STATUS.PENDING)) mapped = null;
        if (mapped) noteVerified(data.user, mapped.id);
        return !!mapped;
      });
      user = mapped; gen++; hintSet();
      return { ok: true, user: Object.assign({}, mapped) };
    } catch (e) {
      client.clearSession();
      user = null; gen++;
      return { ok: false, error: messageFor(e, 'register') };
    } finally {
      busy = false;
    }
  }

  async function completeRecovery(input) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (recoveryBusy) return { ok: false, error: MSG.busy };
    input = input || {};
    const phone = normalizePhone(input.phone);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const code = normCode(input.code);
    if (!/^[0-9]{6}$/.test(code)) return { ok: false, error: MSG.codeFormat };
    const pw = input.newPassword == null ? '' : String(input.newPassword);
    const pwErr = checkNewPassword(pw);
    if (pwErr) return { ok: false, error: pwErr };
    if (input.confirmPassword !== undefined && String(input.confirmPassword) !== pw) return { ok: false, error: MSG.mismatch };
    recoveryBusy = true;
    try {
      await client.post('/v1/auth/password/reset', { phone: phone, code: code, newPassword: pw }, { auth: 'none' });
      client.clearSession(); user = null; gen++; hintClear();   // كل الجلسات انتهت في الخادم
      return { ok: true, message: MSG.resetDone };
    } catch (e) {
      return { ok: false, error: messageFor(e, 'recovery') };
    } finally {
      recoveryBusy = false;
    }
  }

  /** رمز لمرة واحدة: تُقبل الأرقام العربية والفارسية وتُحوَّل إلى لاتينية. */
  function normCode(v) {
    return String(v == null ? '' : v).trim().replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); });
  }

  /* ---------------- (11.7-F) أمان الحساب ---------------- */
  /** فحوص مشتركة قبل أي طلب يخص الحساب: وضع الخادم، إعداد صالح، مستخدم حاضر، ولا طلب جارٍ. null = مسموح. */
  function accountGate() {
    if (!enabled) return MSG.generic;
    if (misconfigured || !client) return MSG.config;
    if (!user) return MSG.expired;
    if (accountBusy) return MSG.accountBusy;
    return null;
  }
  /** الخادم أنهى كل الجلسات (تغيير كلمة المرور/الخروج الشامل): تُمسح الواجهة فورًا، ثم خروج عادي بأفضل جهد يمسح ملف الارتباط. */
  async function endAllLocal() {
    user = null; gen++; hintClear(); dropImages();
    try { await client.logout(); } catch (e) { /* الجلسة منتهية في الخادم أصلًا */ }
  }

  /** تغيير كلمة المرور: الحالية مطلوبة، والجديدة بسياسة الخادم نفسها. النجاح يُنهي كل الجلسات (بما فيها هذه). { ok, message? , error? } */
  async function changeCredential(input) {
    const gate = accountGate();
    if (gate) return { ok: false, error: gate };
    input = input || {};
    const current = input.currentPassword == null ? '' : String(input.currentPassword);
    const pw = input.newPassword == null ? '' : String(input.newPassword);
    if (!current) return { ok: false, error: MSG.currentRequired };
    if (cpLen(current) > 128) return { ok: false, error: MSG.passwordLong };
    const pwErr = checkNewPassword(pw);
    if (pwErr) return { ok: false, error: pwErr };
    if (input.confirmPassword !== undefined && String(input.confirmPassword) !== pw) return { ok: false, error: MSG.mismatch };
    if (pw === current) return { ok: false, error: MSG.samePassword };
    accountBusy = true;
    const g0 = gen;
    try {
      await client.post('/v1/auth/password/change', { currentPassword: current, newPassword: pw }, { auth: 'required' });
      if (gen === g0) await endAllLocal();
      return { ok: true, message: MSG.passwordChanged };
    } catch (e) {
      return { ok: false, error: gen !== g0 ? MSG.expired : messageFor(e, 'session') };
    } finally {
      accountBusy = false;
    }
  }

  /** الخروج من كل الأجهزة (بلا جسم). النجاح يُنهي كل الجلسات، فتُمسح الواجهة أيضًا. الفشل لا يمسح شيئًا ولا يدّعي خروجًا. */
  async function logoutAll() {
    const gate = accountGate();
    if (gate) return { ok: false, error: gate };
    accountBusy = true;
    const g0 = gen;
    try {
      await client.post('/v1/auth/logout/all', undefined, { auth: 'required' });
      if (gen === g0) await endAllLocal();
      return { ok: true, message: MSG.logoutAllDone };
    } catch (e) {
      return { ok: false, error: gen !== g0 ? MSG.expired : messageFor(e, 'session') };
    } finally {
      accountBusy = false;
    }
  }

  /** طلب رمز توثيق الهاتف (بلا جسم؛ الهاتف هو هاتف صاحب الرمز في الخادم). { ok, sent?, already?, message?, error? } */
  async function requestPhoneVerification() {
    const gate = accountGate();
    if (gate) return { ok: false, error: gate };
    if (verifiedFor === user.id) return { ok: true, already: true, message: MSG.phoneAlready };
    accountBusy = true;
    const g0 = gen;
    try {
      const d = await client.post('/v1/auth/phone/verify/request', undefined, { auth: 'required' });
      if (gen !== g0) return { ok: false, error: MSG.expired };
      const st = d && typeof d === 'object' ? d.status : null;
      if (st === 'already_verified') { if (user) verifiedFor = user.id; return { ok: true, already: true, message: MSG.phoneAlready }; }
      if (st === 'sent') return { ok: true, sent: true, message: MSG.phoneCodeSent };
      return { ok: false, error: MSG.invalid };
    } catch (e) {
      return { ok: false, error: gen !== g0 ? MSG.expired : messageFor(e, 'phone') };
    } finally {
      accountBusy = false;
    }
  }

  /** تأكيد التوثيق بالرمز. يُقبل الرد فقط إن كان المستخدم نفسه (المعرّف ذاته) وصار موثّقًا. */
  async function confirmPhoneVerification(codeInput) {
    const gate = accountGate();
    if (gate) return { ok: false, error: gate };
    const code = normCode(codeInput);
    if (!/^[0-9]{6}$/.test(code)) return { ok: false, error: MSG.codeFormat };
    accountBusy = true;
    const g0 = gen;
    try {
      const d = await client.post('/v1/auth/phone/verify/confirm', { code: code }, { auth: 'required' });
      if (gen !== g0 || !user) return { ok: false, error: MSG.expired };
      const mapped = toLocalShape(d && d.user);
      if (!mapped || mapped.id !== user.id || d.user.phoneVerified !== true) return { ok: false, error: MSG.invalid };
      user = mapped; verifiedFor = mapped.id;
      return { ok: true, message: MSG.phoneVerified };
    } catch (e) {
      return { ok: false, error: gen !== g0 ? MSG.expired : messageFor(e, 'phone') };
    } finally {
      accountBusy = false;
    }
  }

  /**
   * (11.7.2.2) استعادة الجلسة عند الإقلاع. لا تُنفَّذ إلا في وضع الملف. تعيد دائمًا (لا ترمي):
   *   { status: 'restored', user } | { status: 'none' } | { status: 'active' } | { status: 'superseded' } | { status: 'error', error: نص عربي }
   * استدعاءات متزامنة تشترك في وعد واحد (لا تجديد مكرّر).
   */
  function restore() {
    if (!enabled || misconfigured || !client || client.sessionTransport !== 'cookie') return Promise.resolve({ status: 'none' });
    if (user) return Promise.resolve({ status: 'active' });
    if (restoring) return restoring;
    if (hint && hint.get() === null) return Promise.resolve({ status: 'none' });   // لا تلميح (والتخزين يعمل): زائر، لا طلب
    const g0 = gen;
    restoring = (async function () {
      try {
        const r = await client.restore();
        if (r.status === 'restored') {
          const mapped = toLocalShape(r.user);
          if (gen !== g0 || !mapped) {
            // تغيّرت هوية الواجهة أثناء الانتظار، أو شكل المستخدم غير معروف: لا تُعرض هذه الجلسة، ونُنهيها في الخادم.
            await client.logout();
            return gen !== g0 ? { status: 'superseded' } : { status: 'error', error: MSG.invalid };
          }
          user = mapped; gen++; hintSet(); noteVerified(r.user, mapped.id);
          return { status: 'restored', user: Object.assign({}, mapped) };
        }
        if (r.status === 'none') { if (gen === g0) hintClear(); return { status: 'none' }; }
        if (r.status === 'error') return { status: 'error', error: messageFor(r.error, 'session') === MSG.expired ? MSG.restoreFailed : messageFor(r.error, 'session') };
        return { status: r.status };
      } catch (e) {
        return { status: 'error', error: MSG.restoreFailed };
      } finally { restoring = null; }
    })();
    return restoring;
  }

  return {
    init: init,
    register: register,
    registerDealer: registerDealer,
    requestRecovery: requestRecovery,
    completeRecovery: completeRecovery,
    restore: restore,
    changeCredential: changeCredential,   // تغيير كلمة المرور (الاسم العام بلا «password» عمدًا: حارس الواجهة العامة)
    isPhoneVerified: function () { return !!user && verifiedFor === user.id; },
    logoutAll: logoutAll,
    requestPhoneVerification: requestPhoneVerification,
    confirmPhoneVerification: confirmPhoneVerification,
    isAccountBusy: function () { return accountBusy; },
    /** هل ستُجرَّب استعادة عند الإقلاع؟ (وضع الملف، ولا تلميح ينفيها) */
    canRestore: function () { return enabled && !misconfigured && !!client && client.sessionTransport === 'cookie' && !(hint && hint.get() === null); },
    isEnabled: function () { return enabled; },
    currentUser: function () { return user ? Object.assign({}, user) : null; },
    /** يمسح مستخدم الواجهة فقط (دون اتصال) — تستعمله SessionService.logout. */
    forgetUser: function () { user = null; dropImages(); },
    login: login,
    logout: logout,
    /** عميل الـAPI لخطوات لاحقة (لا يكشف الرموز). null في الوضع المحلي. */
    api: function () { return client; },
    onLost: function (fn) { lostListener = typeof fn === 'function' ? fn : null; },
    messageFor: messageFor,
    messages: MSG,
  };
})();

/* ==========================================================================
   BACKEND MODERATION — مراجعة إعلانات الأعضاء من الخادم (المهمة 11.7.2-G). وضع الخادم فقط، بالعقد الموجود فقط (backend/src/member-cars/moderation-routes.ts):
     GET  /v1/admin/member-cars?status=pending|active|sold|rejected|suspended&after=<id>&limit=1..100 → 200 { items: [إعلان + ownerId/ownerName/reviewedAt], nextAfter }
     POST /v1/admin/member-cars/:id/approve  { version }                pending   → active     (النشر)
     POST /v1/admin/member-cars/:id/reject   { version, reason? }       pending   → rejected   (السبب اختياري)
     POST /v1/admin/member-cars/:id/suspend  { version, reason }        active    → suspended  (السبب إلزامي)
     POST /v1/admin/member-cars/:id/restore  { version }                suspended → active
   • الحالة الهدف يحدّدها الخادم وحده؛ لا يُرسَل منها شيء. المرفوض لا يعيده المدير (يعدّله مالكه فيعود «قيد المراجعة»)؛ «مباعة» للمالك وحده.
   • النشر (approve) يتطلب في الخادم تحققًا مؤكدًا من إعلان مكافأة (reward_grants) — لا يوجد بعدُ في الخلفية، فيردّ 409 reward_required
     وتعرض الواجهة ذلك صراحةً؛ لا علم «نجاح» من الواجهة ولا تحقق مختلَق.
   • الحالة في الذاكرة فقط ومربوطة بهوية المستخدم؛ نتيجة طلب قديم لا تُطبَّق. عملية كتابة واحدة في آنٍ واحد. الإصدار (version) من آخر قراءة ويُتحقَّق منه في الخادم.
   • لا رجوع إلى بيانات محلية/تجريبية في وضع الخادم: فشل الطلب = رسالة عربية وإعادة محاولة.
   (جسر مستقل عن BackendAdmin عمدًا: حارس مصدر 11.7-E يحصر مسارات ذلك الجسر في /v1/admin/dealers.)
   ========================================================================== */
const BackendModeration = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;
  const PAGE = 50;
  const REASON_MAX = 500;
  const STATUSES = ['pending', 'active', 'rejected', 'suspended', 'sold'];
  const TABS = { pending: 'قيد المراجعة', active: 'نشطة', rejected: 'مرفوضة', suspended: 'موقوفة', sold: 'مباعة' };
  const ACTIONS = {
    approve: { from: 'pending', to: 'active', label: '✅ موافقة ونشر', kind: 'approve', reason: 'none', ok: 'تمت الموافقة ونُشر الإعلان.' },
    reject: { from: 'pending', to: 'rejected', label: '❌ رفض', kind: 'danger', reason: 'optional', ok: 'تم رفض الإعلان. يستطيع صاحبه تعديله وإعادة إرساله للمراجعة.' },
    suspend: { from: 'active', to: 'suspended', label: '⏸️ إيقاف', kind: 'danger', reason: 'required', ok: 'تم إيقاف الإعلان وإخفاؤه عن العامة.' },
    restore: { from: 'suspended', to: 'active', label: '↩️ استعادة', kind: 'approve', reason: 'none', ok: 'تمت استعادة الإعلان وهو ظاهر للعامة.' },
  };
  const MSG = {
    load: 'تعذّر تحميل إعلانات الأعضاء من الخادم. حاول مرة أخرى.',
    denied: 'هذه الصفحة للمدير فقط.',
    busy: 'جارٍ تنفيذ إجراء سابق… انتظر قليلًا.',
    gone: 'الإعلان غير موجود أو لم يعد متاحًا. أُعيد تحميل القائمة.',
    state: 'تغيّرت حالة هذا الإعلان (ربما بقرار مدير آخر أو بتعديل صاحبه). أُعيد تحميل القائمة؛ راجعها ثم أعد المحاولة.',
    reward: 'لا يمكن نشر الإعلان الآن: لا يوجد تحقق مؤكد من الخادم لمشاهدة إعلان المكافأة. لم يتغير شيء، والإعلان ما زال غير ظاهر للعامة.',
    forbidden: 'ليس لديك صلاحية تنفيذ هذا الإجراء.',
    invalidRequest: 'تعذّر تنفيذ الإجراء. أعد المحاولة.',
    unknown: 'إجراء غير معروف أو غير مسموح في حالة الإعلان الحالية.',
    reasonRequired: 'سبب الإيقاف مطلوب.',
    reasonLong: 'السبب طويل (الحد الأقصى 500 حرف).',
    reasonBad: 'السبب يحوي رموزًا غير مسموحة.',
  };
  let owner = null, gen = 0, writing, filter, lists;
  const emptyList = () => ({ status: 'idle', items: [], next: null, error: null, more: false });
  function reset() { gen++; writing = false; filter = 'pending'; lists = {}; STATUSES.forEach(function (s) { lists[s] = emptyList(); }); }
  reset();

  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  function client() { return isEnabled() ? BackendAuth.api() : null; }
  function sync() {
    const u = typeof BackendAuth !== 'undefined' ? BackendAuth.currentUser() : null;
    const id = u ? u.id : null;
    if (id !== owner) { owner = id; reset(); }
    return id;
  }
  const str = v => typeof v === 'string';
  const optStr = v => v === null || v === undefined || typeof v === 'string';
  const idOk = id => typeof id === 'string' && ID_RE.test(id);
  function valid(c) {
    return !!c && typeof c === 'object' && idOk(c.id) && str(c.brand) && str(c.model) && Number.isFinite(c.year) && Number.isFinite(c.price) && str(c.currency)
      && STATUSES.indexOf(c.status) >= 0 && Number.isInteger(c.version) && c.version >= 1 && idOk(c.ownerId) && str(c.ownerName)
      && (c.mileage === null || c.mileage === undefined || Number.isFinite(c.mileage))
      && optStr(c.transmission) && optStr(c.fuelType) && optStr(c.color) && optStr(c.description) && optStr(c.phone) && optStr(c.whatsapp) && optStr(c.location)
      && optStr(c.rejectionReason) && optStr(c.suspensionReason) && optStr(c.reviewedAt) && optStr(c.createdAt);
  }
  const copy = c => ({ id: c.id, brand: c.brand, model: c.model, year: c.year, price: c.price, currency: c.currency, mileage: c.mileage === undefined ? null : c.mileage,
    transmission: c.transmission || '', fuelType: c.fuelType || '', color: c.color || '', description: c.description || '', phone: c.phone || '', whatsapp: c.whatsapp || '', location: c.location || '',
    status: c.status, version: c.version, ownerId: c.ownerId, ownerName: c.ownerName, rejectionReason: c.rejectionReason || '', suspensionReason: c.suspensionReason || '',
    reviewedAt: c.reviewedAt || '', createdAt: c.createdAt || '' });
  function messageOf(e) {
    let m = MSG.load;
    try { m = BackendAuth.messageFor(e, 'session'); if (m === BackendAuth.messages.generic) m = MSG.load; } catch (x) { m = MSG.load; }
    return m;
  }
  function readFailure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404 || e.status === 403) return { status: 'denied', error: MSG.denied };
      if (e.status < 500 && e.status !== 401 && e.status !== 429) return { status: 'error', error: MSG.load };
    }
    return { status: 'error', error: messageOf(e) };
  }

  function load(status, onDone, append) {
    const api = client(); sync();
    if (!api || !owner || STATUSES.indexOf(status) < 0) return Promise.resolve(false);
    const cur = lists[status];
    if (cur.status === 'loading' || cur.more) return Promise.resolve(false);
    const after = append ? cur.next : null;
    if (append && (cur.status !== 'ready' || !after)) return Promise.resolve(false);
    const g = gen, query = { status: status, limit: String(PAGE) };
    if (after) query.after = after;
    if (append) lists[status] = Object.assign({}, cur, { more: true, error: null }); else lists[status] = { status: 'loading', items: [], next: null, error: null, more: false };
    return api.get('/v1/admin/member-cars', { query: query }).then(function (d) {
      if (g !== gen) return false;
      const ok = d && Array.isArray(d.items) && d.items.every(function (x) { return valid(x) && x.status === status; }) && (d.nextAfter === null || (str(d.nextAfter) && ID_RE.test(d.nextAfter)));
      if (!ok) { lists[status] = append ? Object.assign({}, cur, { more: false, error: BackendAuth.messages.invalid }) : { status: 'error', items: [], next: null, error: BackendAuth.messages.invalid, more: false }; return true; }
      const items = (append ? cur.items : []).concat(d.items.map(copy));
      lists[status] = { status: items.length ? 'ready' : 'empty', items: items, next: d.nextAfter, error: null, more: false };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = readFailure(e);
      if (append && f.status === 'error') lists[status] = Object.assign({}, cur, { more: false, error: f.error });
      else lists[status] = { status: f.status, items: [], next: null, error: f.error, more: false };
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }
  function actionsOf(c) {
    return Object.keys(ACTIONS).filter(function (a) { return ACTIONS[a].from === c.status; }).map(function (a) { return { action: a, label: ACTIONS[a].label, kind: ACTIONS[a].kind, reason: ACTIONS[a].reason }; });
  }
  function present(c) { return Object.assign({}, c, { actions: actionsOf(c) }); }
  function find(id) {
    for (let i = 0; i < STATUSES.length; i++) { const hit = lists[STATUSES[i]].items.filter(function (x) { return x.id === id; })[0]; if (hit) return hit; }
    return null;
  }

  /** نموذج عرض جاهز للشاشة. يبدأ التحميل تلقائيًا للتبويب الفارغ. */
  function view(onDone) {
    sync();
    if (owner && lists[filter].status === 'idle') load(filter, onDone);
    const l = lists[filter];
    return {
      filter: filter, status: l.status, error: l.error, more: l.more, hasMore: !!l.next && l.status === 'ready', busy: writing,
      tabs: STATUSES.map(function (k) { return { key: k, label: TABS[k], active: k === filter }; }),
      items: l.items.map(present),
    };
  }
  function setFilter(key, onDone) { sync(); if (STATUSES.indexOf(key) < 0) return; filter = key; if (typeof onDone === 'function') onDone(); }
  function more(onDone) { return load(filter, onDone, true); }
  function retry(onDone) { sync(); lists[filter] = emptyList(); return load(filter, onDone); }
  /** إعلان محمَّل في إحدى القوائم (تفاصيله من القائمة؛ لا طلب إضافي). null إن لم يكن محمَّلًا. */
  function get(id) { sync(); const c = idOk(id) ? find(id) : null; return c ? present(c) : null; }
  function has(id) { return !!get(id); }

  function cleanReason(raw) {
    if (raw === undefined || raw === null) return { ok: true, value: '' };
    if (typeof raw !== 'string') return { ok: false, error: MSG.reasonBad };
    const t = raw.normalize('NFC').trim();
    if (/[\u0000-\u001f\u007f-\u009f\u2028\u2029]/.test(t)) return { ok: false, error: MSG.reasonBad };
    if (Array.from(t).length > REASON_MAX) return { ok: false, error: MSG.reasonLong };
    return { ok: true, value: t };
  }

  /** إجراء واحد على إعلان محمَّل في قائمته وفي حالة المصدر الصحيحة؛ قفل واحد؛ الحالة لا تتغير إلا بنجاح الخادم. */
  function act(action, id, reason, onDone) {
    const api = client(); sync();
    const def = Object.prototype.hasOwnProperty.call(ACTIONS, action) ? ACTIONS[action] : null;
    if (!api || !owner) return Promise.resolve({ ok: false, error: MSG.load });
    if (!def || !idOk(id)) return Promise.resolve({ ok: false, error: MSG.unknown });
    const car = find(id);
    if (!car || car.status !== def.from) return Promise.resolve({ ok: false, error: MSG.unknown });
    const rs = cleanReason(def.reason === 'none' ? undefined : reason);
    if (!rs.ok) return Promise.resolve({ ok: false, error: rs.error, field: 'reason' });
    if (def.reason === 'required' && rs.value === '') return Promise.resolve({ ok: false, error: MSG.reasonRequired, field: 'reason' });
    if (writing) return Promise.resolve({ ok: false, error: MSG.busy, busy: true });
    writing = true; const g = gen;
    const body = { version: car.version };
    if (def.reason !== 'none' && rs.value !== '') body.reason = rs.value;
    if (typeof onDone === 'function') onDone();
    return api.post('/v1/admin/member-cars/' + id + '/' + action, body).then(function (d) {
      if (g !== gen) return { ok: false, stale: true, error: MSG.load };
      writing = false;
      if (!(d && valid(d.car) && d.car.id === id && d.car.status === def.to)) { lists[def.from] = emptyList(); lists[def.to] = emptyList(); return { ok: false, error: BackendAuth.messages.invalid }; }
      const src = lists[def.from];
      const items = src.items.filter(function (x) { return x.id !== id; });
      lists[def.from] = { status: items.length || src.next ? 'ready' : 'empty', items: items, next: src.next, error: null, more: false };
      lists[def.to] = emptyList();   // يُجلب من الخادم عند فتح تبويبه
      return { ok: true, message: def.ok, car: copy(d.car) };
    }, function (e) {
      if (g !== gen) return { ok: false, stale: true, error: MSG.load };
      writing = false;
      if (e && e.name === 'ApiError' && e.kind === 'http') {
        if (e.status === 409 && e.code === 'reward_required') return { ok: false, error: MSG.reward, reward: true };
        if (e.status === 409) { lists[def.from] = emptyList(); lists[def.to] = emptyList(); return { ok: false, error: MSG.state, state: true }; }
        if (e.status === 404) { lists[def.from] = emptyList(); return { ok: false, error: MSG.gone, gone: true }; }
        if (e.status === 403) return { ok: false, error: MSG.forbidden };
        if (e.status === 400) return { ok: false, error: MSG.invalidRequest };
      }
      return { ok: false, error: messageOf(e) };
    });
  }

  return { isEnabled: isEnabled, messages: MSG, tabs: TABS, statuses: STATUSES, reasonMax: REASON_MAX, view: view, setFilter: setFilter, more: more, retry: retry, get: get, has: has, act: act, reset: function () { owner = null; reset(); } };
})();

/* ==========================================================================
   BACKEND ADMIN — إدارة أصحاب المعارض من الخادم (المهمة 11.7-E). وضع الخادم فقط، بالعقد الموجود فقط (backend/src/dealers/routes.ts):
     GET  /v1/admin/dealers?status=pending|active|suspended&after=<id>&limit=1..100 → 200 { dealers: [{ id, name, phone, status, phoneVerified, createdAt, showroom: {id,status}|null }], nextAfter: string|null }
     POST /v1/admin/dealers/:id/approve      pending   → active    (+ ينشئ المعرض)
     POST /v1/admin/dealers/:id/reject       pending   → suspended
     POST /v1/admin/dealers/:id/suspend      active    → suspended (تنتهي جلساته)
     POST /v1/admin/dealers/:id/reactivate   suspended → active    (+ المعرض)
   إجراء المدير لا يأخذ جسمًا ولا حقولًا أبدًا (المعرّف في المسار هو الهدف الوحيد). 404 لغير المدير (كأنه غير موجود)، 409 invalid_state لحالة لا تسمح.
   غير موجود في الخلفية فلا يُربط ولا يُختلَق: قائمة المستخدمين، سيارات الأعضاء (مراجعة/موافقة/رفض)، قائمة المعارض الإدارية، إحصاءات اللوحة،
   وقراءة إدارية لسيارات المعارض (PATCH /v1/admin/showroom-cars/:id/status موجود لكنه يتطلب «version» ولا مسار قراءة إداري يعيده، وPublicCar بلا version).
   • الحالة في الذاكرة فقط ومربوطة بهوية المستخدم؛ نتيجة طلب قديم لا تُطبَّق. عملية كتابة واحدة في آنٍ واحد (لا إجراء مكرر).
   • لا رجوع إلى بيانات محلية أو تجريبية في وضع الخادم: فشل الطلب = رسالة عربية وإعادة محاولة.
   ========================================================================== */
const BackendAdmin = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;
  const PAGE = 50;
  const STATUSES = ['pending', 'active', 'suspended'];
  const TABS = { pending: 'بانتظار المراجعة', active: 'فعّالون', suspended: 'موقوفون' };
  const ACTIONS = {
    approve: { from: 'pending', to: 'active', label: '✅ موافقة', kind: 'approve', ok: 'تمت الموافقة على صاحب المعرض وتفعيل معرضه.' },
    reject: { from: 'pending', to: 'suspended', label: '❌ رفض', kind: 'danger', confirm: { title: 'رفض طلب صاحب المعرض', message: 'هل أنت متأكد من رفض هذا الطلب؟ سيبقى الحساب موجودًا بلا صلاحية إدارة معرض.', confirmLabel: 'رفض الطلب' }, ok: 'تم رفض الطلب.' },
    suspend: { from: 'active', to: 'suspended', label: '⏸️ إيقاف', kind: 'danger', confirm: { title: 'إيقاف صاحب المعرض', message: 'سيُوقف الحساب وتنتهي جلساته الحالية. هل أنت متأكد؟', confirmLabel: 'إيقاف الحساب' }, ok: 'تم إيقاف الحساب وإنهاء جلساته.' },
    reactivate: { from: 'suspended', to: 'active', label: '✅ إعادة تفعيل', kind: 'approve', ok: 'تمت إعادة تفعيل الحساب ومعرضه.' },
  };
  const MSG = {
    load: 'تعذّر تحميل أصحاب المعارض من الخادم. حاول مرة أخرى.',
    denied: 'هذه الصفحة للمدير فقط.',
    busy: 'جارٍ تنفيذ إجراء سابق… انتظر قليلًا.',
    gone: 'الحساب غير موجود أو لم يعد متاحًا. أُعيد تحميل القائمة.',
    state: 'تغيّرت حالة هذا الحساب (ربما بقرار مدير آخر). أُعيد تحميل القائمة؛ راجعها ثم أعد المحاولة.',
    forbidden: 'ليس لديك صلاحية تنفيذ هذا الإجراء.',
    invalidRequest: 'تعذّر تنفيذ الإجراء. أعد المحاولة.',
    unknown: 'إجراء غير معروف أو غير مسموح لهذا الحساب.',
  };
  let owner = null, gen = 0, writing, filter, lists;
  const emptyList = () => ({ status: 'idle', items: [], next: null, error: null, more: false });
  function reset() { gen++; writing = false; filter = 'pending'; lists = { pending: emptyList(), active: emptyList(), suspended: emptyList() }; }
  reset();

  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  function client() { return isEnabled() ? BackendAuth.api() : null; }
  function sync() {
    const u = typeof BackendAuth !== 'undefined' ? BackendAuth.currentUser() : null;
    const id = u ? u.id : null;
    if (id !== owner) { owner = id; reset(); }
    return id;
  }
  const str = v => typeof v === 'string';
  function valid(d) {
    return !!d && typeof d === 'object' && str(d.id) && ID_RE.test(d.id) && str(d.name) && str(d.phone) && STATUSES.indexOf(d.status) >= 0 && typeof d.phoneVerified === 'boolean'
      && (d.createdAt === null || d.createdAt === undefined || str(d.createdAt))
      && (d.showroom === null || d.showroom === undefined || (!!d.showroom && typeof d.showroom === 'object' && str(d.showroom.id) && str(d.showroom.status)));
  }
  const copy = d => ({ id: d.id, name: d.name, phone: d.phone, status: d.status, phoneVerified: d.phoneVerified, createdAt: d.createdAt || '', showroom: d.showroom ? { id: d.showroom.id, status: d.showroom.status } : null });
  function messageOf(e) {
    let m = MSG.load;
    try { m = BackendAuth.messageFor(e, 'session'); if (m === BackendAuth.messages.generic) m = MSG.load; } catch (x) { m = MSG.load; }
    return m;
  }
  function readFailure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404 || e.status === 403) return { status: 'denied', error: MSG.denied };
      if (e.status < 500 && e.status !== 401 && e.status !== 429) return { status: 'error', error: MSG.load };
    }
    return { status: 'error', error: messageOf(e) };
  }

  function load(status, onDone, append) {
    const api = client(); sync();
    if (!api || !owner || STATUSES.indexOf(status) < 0) return Promise.resolve(false);
    const cur = lists[status];
    if (cur.status === 'loading' || cur.more) return Promise.resolve(false);
    const after = append ? cur.next : null;
    if (append && (cur.status !== 'ready' || !after)) return Promise.resolve(false);
    const g = gen, query = { status: status, limit: String(PAGE) };
    if (after) query.after = after;
    if (append) lists[status] = Object.assign({}, cur, { more: true, error: null }); else lists[status] = { status: 'loading', items: [], next: null, error: null, more: false };
    return api.get('/v1/admin/dealers', { query: query }).then(function (d) {
      if (g !== gen) return false;
      const ok = d && Array.isArray(d.dealers) && d.dealers.every(function (x) { return valid(x) && x.status === status; }) && (d.nextAfter === null || (str(d.nextAfter) && ID_RE.test(d.nextAfter)));
      if (!ok) { lists[status] = append ? Object.assign({}, cur, { more: false, error: BackendAuth.messages.invalid }) : { status: 'error', items: [], next: null, error: BackendAuth.messages.invalid, more: false }; return true; }
      const items = (append ? cur.items : []).concat(d.dealers.map(copy));
      lists[status] = { status: items.length ? 'ready' : 'empty', items: items, next: d.nextAfter, error: null, more: false };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = readFailure(e);
      if (append && f.status === 'error') lists[status] = Object.assign({}, cur, { more: false, error: f.error });
      else lists[status] = { status: f.status, items: [], next: null, error: f.error, more: false };
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }

  /** نموذج عرض جاهز للشاشة (لا منطق حالة في الشاشة). يبدأ التحميل تلقائيًا للتبويب الفارغ. */
  function view(onDone) {
    sync();
    if (owner && lists[filter].status === 'idle') load(filter, onDone);
    const l = lists[filter];
    return {
      filter: filter, status: l.status, error: l.error, more: l.more, hasMore: !!l.next && l.status === 'ready', busy: writing,
      tabs: STATUSES.map(function (k) { return { key: k, label: TABS[k], active: k === filter }; }),
      items: l.items.map(function (d) {
        return { id: d.id, name: d.name, phone: d.phone, createdAt: d.createdAt, showroomStatus: d.showroom ? d.showroom.status : '',
          actions: Object.keys(ACTIONS).filter(function (a) { return ACTIONS[a].from === d.status; }).map(function (a) { return { action: a, label: ACTIONS[a].label, kind: ACTIONS[a].kind, confirm: ACTIONS[a].confirm || null }; }) };
      }),
    };
  }
  function setFilter(key, onDone) { sync(); if (STATUSES.indexOf(key) < 0) return; filter = key; if (typeof onDone === 'function') onDone(); }
  function more(onDone) { return load(filter, onDone, true); }
  function retry(onDone) { sync(); lists[filter] = emptyList(); return load(filter, onDone); }
  /** عدد المنتظرين للوحة: null حتى يُحمَّل، ويُضاف «+» إن وُجدت صفحة تالية */
  function pendingBadge(onDone) {
    sync();
    if (owner && lists.pending.status === 'idle') load('pending', onDone);
    const l = lists.pending;
    return l.status === 'ready' || l.status === 'empty' ? String(l.items.length) + (l.next ? '+' : '') : null;
  }

  /** إجراء واحد على صاحب معرض محمَّل في تبويبه؛ قفل واحد؛ الحالة لا تتغير إلا بنجاح الخادم. */
  function act(action, id, onDone) {
    const api = client(); sync();
    const def = Object.prototype.hasOwnProperty.call(ACTIONS, action) ? ACTIONS[action] : null;
    if (!api || !owner) return Promise.resolve({ ok: false, error: MSG.load });
    if (!def || typeof id !== 'string' || !ID_RE.test(id)) return Promise.resolve({ ok: false, error: MSG.unknown });
    const src = lists[def.from];
    if (!src.items.some(function (d) { return d.id === id; })) return Promise.resolve({ ok: false, error: MSG.unknown });
    if (writing) return Promise.resolve({ ok: false, error: MSG.busy, busy: true });
    writing = true; const g = gen;
    if (typeof onDone === 'function') onDone();
    return api.post('/v1/admin/dealers/' + id + '/' + action).then(function (d) {
      if (g !== gen) return { ok: false, stale: true, error: MSG.load };
      writing = false;
      if (!(d && valid(d.dealer) && d.dealer.id === id && d.dealer.status === def.to)) { lists[def.from] = emptyList(); lists[def.to] = emptyList(); return { ok: false, error: BackendAuth.messages.invalid }; }
      const items = src.items.filter(function (x) { return x.id !== id; });
      lists[def.from] = { status: items.length || src.next ? 'ready' : 'empty', items: items, next: src.next, error: null, more: false };
      lists[def.to] = emptyList();   // يُجلب من الخادم عند فتح تبويبه
      return { ok: true, message: def.ok, dealer: copy(d.dealer) };
    }, function (e) {
      if (g !== gen) return { ok: false, stale: true, error: MSG.load };
      writing = false;
      if (e && e.name === 'ApiError' && e.kind === 'http') {
        if (e.status === 409) { lists[def.from] = emptyList(); lists[def.to] = emptyList(); return { ok: false, error: MSG.state, state: true }; }
        if (e.status === 404) { lists[def.from] = emptyList(); return { ok: false, error: MSG.gone, gone: true }; }
        if (e.status === 403) return { ok: false, error: MSG.forbidden };
        if (e.status === 400) return { ok: false, error: MSG.invalidRequest };
      }
      return { ok: false, error: messageOf(e) };
    });
  }

  return { isEnabled: isEnabled, messages: MSG, tabs: TABS, view: view, setFilter: setFilter, more: more, retry: retry, pendingBadge: pendingBadge, act: act, reset: function () { owner = null; reset(); } };
})();

/* ==========================================================================
   BACKEND IMAGES — صور السيارات وغلاف المعرض مع الخادم (المهمة 11.7-D). وضع الخادم فقط، بالعقد الموجود فقط:
     POST   /v1/me/assets?kind=car_image|showroom_cover   جسم خام image/jpeg|png|webp (≤ 8MB)  → 201 { asset: { id, kind, status, bytes, width, height, createdAt } }
     GET    /v1/me/assets/:id                             → 200 { asset }            (أصل المتصل وحده)
     GET    /v1/me/assets/:id/thumb | /image              Bearer، يعيد image/webp خاصًا (يُحمَّل Blob ثم رابط مؤقت في الذاكرة)
     GET    /v1/me/cars/:id/images                        → 200 { images: [{ id, assetId, sortOrder, isMain, width, height, createdAt }], maxImages }
     POST   /v1/me/cars/:id/images { assetId }            → 201 { image }
     DELETE /v1/me/cars/:id/images/:imageId               → 204
     GET    /v1/public/cars/:id/images                    → 200 { images: [{ assetId, isMain, sortOrder, width, height }] }      بلا مصادقة
     GET    /v1/public/showrooms/:id/cover                → 200 { cover: { assetId, width, height } | null }                    بلا مصادقة
     GET    /v1/public/assets/:id/thumb | /image          بلا مصادقة (روابط <img> مباشرة)
     GET/PUT/DELETE /v1/dealer/showroom/cover             PUT { assetId } → 200 { cover } | 409 invalid_state | 404
   حدود الخادم: صور سيارة العضو فقط (ولا مسار لصور سيارات المعرض)، 4 صور كحد (maxImages من الخادم)، رفع الغلاف لصاحب المعرض الفعّال فقط.
   • الضغط (WebP/JPEG، أطول ضلع 1600) يتم في المتصفح بـ ImageService قبل الرفع؛ الخادم يعيد التحقق ويعالج.
   • الحالة في الذاكرة فقط ومربوطة بهوية المستخدم (خروج/دخول يُسقطها ويُلغي روابط Blob)، ونتيجة طلب قديم لا تُطبَّق.
   • عملية كتابة واحدة في آنٍ واحد (لا رفع مكرر). لا رجوع إلى صور محلية/تجريبية بعد أي فشل: الخطأ رسالة عربية والحالة لا تتغير إلا بنجاح الخادم.
   ========================================================================== */
const BackendImages = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;
  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const IMG_ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
  const MAX_BYTES = 8 * 1024 * 1024;
  const MSG = {
    load: 'تعذّر تحميل الصور من الخادم. حاول مرة أخرى.',
    busy: 'جارٍ تنفيذ عملية سابقة… انتظر قليلًا.',
    denied: 'حسابك لا يملك صلاحية إدارة الصور حاليًا.',
    gone: 'الإعلان غير موجود أو لم يعد لك.',
    coverGone: 'لا يوجد معرض فعّال مرتبط بحسابك، أو الصورة غير متاحة.',
    coverDenied: 'غلاف المعرض متاح لصاحب معرض فعّال فقط.',
    limit: 'وصل الإعلان إلى الحد الأقصى من الصور.',
    state: 'لا يمكن استخدام هذه الصورة الآن. ارفع صورة أخرى.',
    badImage: 'الملف المختار ليس صورة صالحة.',
    tooBig: 'حجم الصورة كبير جدًا حتى بعد الضغط. اختر صورة أصغر.',
    type: 'نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WebP.',
    rejected: 'رفض الخادم هذه الصورة. جرّب صورة أخرى.',
    pending: 'ما زالت الصورة قيد المعالجة في الخادم. حاول مرة أخرى بعد قليل.',
    uploadLimit: 'بلغت الحد المسموح من الرفع حاليًا. حاول لاحقًا.',
    storage: 'خدمة تخزين الصور غير متاحة الآن. حاول لاحقًا.',
    steps: { prepare: 'جارٍ ضغط الصورة…', upload: 'جارٍ رفع الصورة…', attach: 'جارٍ حفظ الصورة في الإعلان…', cover: 'جارٍ تعيين الغلاف…', remove: 'جارٍ الحذف…' },
  };
  const STALE = { stale: true };
  let owner = null, gen = 0, writing, step, gallery, own, pubCar, pubShow, cover;
  const emptyGallery = () => ({ status: 'idle', carId: null, items: [], max: 0, error: null });
  const emptyPub = () => ({ status: 'idle', id: null, items: [], cover: null, error: null });
  const emptyCover = () => ({ status: 'idle', cover: null, error: null });
  function reset() {
    gen++; writing = false; step = '';
    if (own) Object.keys(own).forEach(function (k) { revoke(own[k]); });
    own = {}; gallery = emptyGallery(); pubCar = emptyPub(); pubShow = emptyPub(); cover = emptyCover();
  }
  function revoke(slot) {
    try { if (slot && slot.url && typeof URL !== 'undefined' && typeof URL.revokeObjectURL === 'function') URL.revokeObjectURL(slot.url); } catch (e) { /* لا يكسر الواجهة */ }
  }
  function makeUrl(blob) {
    try { return typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function' && blob ? URL.createObjectURL(blob) : null; } catch (e) { return null; }
  }
  reset();

  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  function client() { return isEnabled() ? BackendAuth.api() : null; }
  function sync() {
    const u = typeof BackendAuth !== 'undefined' ? BackendAuth.currentUser() : null;
    const id = u ? u.id : null;
    if (id !== owner) { owner = id; reset(); }
    return id;
  }
  const done = onDone => { if (typeof onDone === 'function') onDone(); };
  function messageOf(e) {
    let m = MSG.load;
    try { m = BackendAuth.messageFor(e, 'session'); if (m === BackendAuth.messages.generic) m = MSG.load; } catch (x) { m = MSG.load; }
    return m;
  }
  function validImage(im) {
    return !!im && typeof im === 'object' && typeof im.id === 'string' && IMG_ID_RE.test(im.id) && typeof im.assetId === 'string' && UUID_RE.test(im.assetId)
      && typeof im.isMain === 'boolean' && (im.sortOrder === undefined || Number.isFinite(im.sortOrder));
  }
  const copyImage = im => ({ id: im.id, assetId: im.assetId, isMain: im.isMain, sortOrder: Number.isFinite(im.sortOrder) ? im.sortOrder : 0, width: Number.isFinite(im.width) ? im.width : null, height: Number.isFinite(im.height) ? im.height : null });
  const byOrder = (a, b) => (a.isMain === b.isMain ? a.sortOrder - b.sortOrder : (a.isMain ? -1 : 1));
  function validAsset(a, kind) {
    return !!a && typeof a === 'object' && typeof a.id === 'string' && UUID_RE.test(a.id) && a.kind === kind && ['pending', 'ready', 'rejected'].indexOf(a.status) >= 0;
  }
  function validCover(c) {
    return !!c && typeof c === 'object' && typeof c.assetId === 'string' && UUID_RE.test(c.assetId) && (c.width === null || c.width === undefined || Number.isFinite(c.width)) && (c.height === null || c.height === undefined || Number.isFinite(c.height));
  }
  const copyCover = c => ({ assetId: c.assetId, width: Number.isFinite(c.width) ? c.width : null, height: Number.isFinite(c.height) ? c.height : null });
  function publicUrl(api, assetId, variant) { return api.baseUrl + '/v1/public/assets/' + assetId + '/' + variant; }

  /* ---------------- روابط الصور الخاصة (Blob في الذاكرة) ---------------- */
  const ownKey = (assetId, variant) => variant + ':' + assetId;
  function ensureOwn(assetId, variant, onDone) {
    const api = client();
    if (!api || !owner || !UUID_RE.test(assetId)) return;
    const k = ownKey(assetId, variant);
    if (own[k]) return;
    const slot = { status: 'loading', url: null }; own[k] = slot;
    const g = gen;
    api.getBlob('/v1/me/assets/' + assetId + '/' + variant).then(function (blob) {
      if (g !== gen || own[k] !== slot) return false;
      const u = makeUrl(blob); slot.url = u; slot.status = u ? 'ready' : 'error';
      return true;
    }, function () {
      if (g !== gen || own[k] !== slot) return false;
      slot.status = 'error';
      return true;
    }).then(function (applied) { if (applied) done(onDone); });
  }
  function ownUrl(assetId, variant) { const s = own[ownKey(assetId, variant)]; return s && s.status === 'ready' ? s.url : null; }
  function ownLoading(assetId, variant) { const s = own[ownKey(assetId, variant)]; return !s || s.status === 'loading'; }
  /** يحرّر روابط الأصول التي لم تعد معروضة (معرض السيارة الحالي + الغلاف الحالي) */
  function prune() {
    const keep = {};
    gallery.items.forEach(function (i) { keep[i.assetId] = 1; });
    if (cover.cover) keep[cover.cover.assetId] = 1;
    Object.keys(own).forEach(function (k) { if (!keep[k.slice(k.indexOf(':') + 1)]) { revoke(own[k]); delete own[k]; } });
  }

  /* ---------------- القراءة ---------------- */
  function readFailure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404) return { status: 'gone', error: MSG.gone };
      if (e.status === 403) return { status: 'denied', error: MSG.denied };
      if (e.status < 500 && e.status !== 401 && e.status !== 429) return { status: 'error', error: MSG.load };
    }
    return { status: 'error', error: messageOf(e) };
  }
  /** معرض صور سيارتي. silent: تحديث هادئ بعد كتابة (لا «جارٍ التحميل»، ولا يُستبدل بالخطأ إلا لغياب الإعلان/الصلاحية). */
  function loadGallery(carId, onDone, silent) {
    const api = client(); sync();
    if (!api || !owner || !ID_RE.test(carId)) return Promise.resolve(false);
    if (!silent && gallery.status === 'loading' && gallery.carId === carId) return Promise.resolve(false);
    const g = gen;
    if (!silent) gallery = { status: 'loading', carId: carId, items: [], max: 0, error: null };
    return api.get('/v1/me/cars/' + carId + '/images').then(function (d) {
      if (g !== gen) return false;
      const ok = d && Array.isArray(d.images) && d.images.every(validImage) && Number.isInteger(d.maxImages) && d.maxImages >= 1 && d.maxImages <= 50;
      if (!ok) { if (!silent) gallery = { status: 'error', carId: carId, items: [], max: 0, error: BackendAuth.messages.invalid }; return !silent; }
      const items = d.images.map(copyImage).sort(byOrder);
      gallery = { status: items.length ? 'ready' : 'empty', carId: carId, items: items, max: d.maxImages, error: null };
      prune();
      items.forEach(function (i) { ensureOwn(i.assetId, 'thumb', onDone); });
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = readFailure(e);
      if (silent && f.status !== 'gone' && f.status !== 'denied') return false;
      gallery = { status: f.status, carId: carId, items: [], max: 0, error: f.error };
      prune();
      return true;
    }).then(function (applied) { if (applied) done(onDone); return applied; });
  }
  function galleryState(carId, onDone, wantFull) {
    sync();
    if (owner && ID_RE.test(carId) && (gallery.carId !== carId || gallery.status === 'idle')) loadGallery(carId, onDone);
    const s = gallery;
    if (wantFull && s.carId === carId && s.items.length) ensureOwn(s.items[0].assetId, 'image', onDone);   // الصورة الرئيسية بحجم العرض الكامل (للقراءة فقط)
    return {
      status: s.status, carId: s.carId, max: s.max, error: s.error, busy: writing, step: step ? MSG.steps[step] || '' : '',
      canAdd: (s.status === 'ready' || s.status === 'empty') && s.items.length < s.max && !writing,
      full: (s.status === 'ready' || s.status === 'empty') && s.items.length >= s.max,
      items: s.items.map(function (i) { return { id: i.id, assetId: i.assetId, isMain: i.isMain, url: ownUrl(i.assetId, 'thumb'), full: ownUrl(i.assetId, 'image'), loading: ownLoading(i.assetId, 'thumb') }; }),
    };
  }
  function retryGallery(carId, onDone) { sync(); gallery = emptyGallery(); return loadGallery(carId, onDone); }

  function loadPublicCar(carId, onDone) {
    const api = client();
    if (!api || !ID_RE.test(carId)) return Promise.resolve(false);
    const g = gen;
    pubCar = { status: 'loading', id: carId, items: [], cover: null, error: null };
    return api.get('/v1/public/cars/' + carId + '/images', { auth: 'none' }).then(function (d) {
      if (g !== gen) return false;
      if (!(d && Array.isArray(d.images) && d.images.every(function (x) { return !!x && typeof x.assetId === 'string' && UUID_RE.test(x.assetId) && typeof x.isMain === 'boolean'; }))) {
        pubCar = { status: 'error', id: carId, items: [], cover: null, error: BackendAuth.messages.invalid }; return true;
      }
      const items = d.images.map(function (x) { return { assetId: x.assetId, isMain: x.isMain, sortOrder: Number.isFinite(x.sortOrder) ? x.sortOrder : 0 }; }).sort(byOrder)
        .map(function (x) { return { assetId: x.assetId, isMain: x.isMain, url: publicUrl(api, x.assetId, 'image'), thumb: publicUrl(api, x.assetId, 'thumb') }; });
      pubCar = { status: items.length ? 'ready' : 'empty', id: carId, items: items, cover: null, error: null };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const gone = e && e.name === 'ApiError' && e.kind === 'http' && e.status === 404;
      pubCar = gone ? { status: 'empty', id: carId, items: [], cover: null, error: null } : { status: 'error', id: carId, items: [], cover: null, error: MSG.load };
      return true;
    }).then(function (applied) { if (applied) done(onDone); return applied; });
  }
  function publicCar(carId, onDone) {
    sync();
    if (isEnabled() && ID_RE.test(carId) && (pubCar.id !== carId || pubCar.status === 'idle')) loadPublicCar(carId, onDone);
    return { status: pubCar.status, id: pubCar.id, error: pubCar.error, items: pubCar.items.map(function (i) { return Object.assign({}, i); }) };
  }
  function retryPublicCar(carId, onDone) { pubCar = emptyPub(); return loadPublicCar(carId, onDone); }

  function loadPublicShowroom(id, onDone) {
    const api = client();
    if (!api || !ID_RE.test(id)) return Promise.resolve(false);
    const g = gen;
    pubShow = { status: 'loading', id: id, items: [], cover: null, error: null };
    return api.get('/v1/public/showrooms/' + id + '/cover', { auth: 'none' }).then(function (d) {
      if (g !== gen) return false;
      const c = d && typeof d === 'object' && 'cover' in d ? d.cover : undefined;
      if (c === null) { pubShow = { status: 'empty', id: id, items: [], cover: null, error: null }; return true; }
      if (!validCover(c)) { pubShow = { status: 'error', id: id, items: [], cover: null, error: BackendAuth.messages.invalid }; return true; }
      pubShow = { status: 'ready', id: id, items: [], cover: { assetId: c.assetId, url: publicUrl(api, c.assetId, 'image') }, error: null };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const gone = e && e.name === 'ApiError' && e.kind === 'http' && e.status === 404;
      pubShow = gone ? { status: 'empty', id: id, items: [], cover: null, error: null } : { status: 'error', id: id, items: [], cover: null, error: MSG.load };
      return true;
    }).then(function (applied) { if (applied) done(onDone); return applied; });
  }
  function publicShowroom(id, onDone) {
    sync();
    if (isEnabled() && ID_RE.test(id) && (pubShow.id !== id || pubShow.status === 'idle')) loadPublicShowroom(id, onDone);
    return { status: pubShow.status, id: pubShow.id, error: pubShow.error, cover: pubShow.cover ? Object.assign({}, pubShow.cover) : null };
  }
  function retryPublicShowroom(id, onDone) { pubShow = emptyPub(); return loadPublicShowroom(id, onDone); }

  function loadCover(onDone) {
    const api = client(); sync();
    if (!api || !owner || cover.status === 'loading') return Promise.resolve(false);
    const g = gen;
    cover = { status: 'loading', cover: null, error: null };
    return api.get('/v1/dealer/showroom/cover').then(function (d) {
      if (g !== gen) return false;
      const c = d && typeof d === 'object' && 'cover' in d ? d.cover : undefined;
      if (c === null) cover = { status: 'ready', cover: null, error: null };
      else if (validCover(c)) { cover = { status: 'ready', cover: copyCover(c), error: null }; prune(); ensureOwn(c.assetId, 'image', onDone); }
      else cover = { status: 'error', cover: null, error: BackendAuth.messages.invalid };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      if (e && e.name === 'ApiError' && e.kind === 'http' && (e.status === 404 || e.status === 403)) cover = { status: 'denied', cover: null, error: e.status === 404 ? MSG.coverGone : MSG.coverDenied };
      else cover = { status: 'error', cover: null, error: e && e.name === 'ApiError' && e.kind === 'http' && e.status < 500 && e.status !== 401 && e.status !== 429 ? MSG.load : messageOf(e) };
      return true;
    }).then(function (applied) { if (applied) done(onDone); return applied; });
  }
  function coverState(onDone) {
    sync();
    if (owner && cover.status === 'idle') loadCover(onDone);
    const c = cover.cover;
    return { status: cover.status, error: cover.error, busy: writing, step: step ? MSG.steps[step] || '' : '', cover: c ? { assetId: c.assetId, url: ownUrl(c.assetId, 'image'), loading: ownLoading(c.assetId, 'image') } : null };
  }
  function retryCover(onDone) { sync(); cover = emptyCover(); return loadCover(onDone); }

  /* ---------------- الكتابة ---------------- */
  function writeFailure(e, forCover) {
    if (e && e.localMsg) return { ok: false, error: e.localMsg };
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      const s = e.status, c = e.code;
      if (s === 403) return { ok: false, error: forCover ? MSG.coverDenied : MSG.denied, denied: true };
      if (s === 404) return { ok: false, error: forCover ? MSG.coverGone : MSG.gone, gone: true };
      if (s === 409 && c === 'upload_limit') return { ok: false, error: MSG.uploadLimit };
      if (s === 409 && c === 'image_limit') return { ok: false, error: MSG.limit, limit: true };
      if (s === 409) return { ok: false, error: MSG.state, state: true };
      if (s === 413) return { ok: false, error: MSG.tooBig };
      if (s === 415) return { ok: false, error: MSG.type };
      if (s === 400) return { ok: false, error: MSG.badImage };
      if (s === 503) return { ok: false, error: MSG.storage };
    }
    return { ok: false, error: messageOf(e) };
  }
  function setStep(name, onDone) { step = name; done(onDone); }
  /** كتابة واحدة: قفل، ثم نتيجة {ok,...}. الحالة المحلية لا تُمسّ إلا إن بقيت الهوية نفسها. */
  function lockWrite(first, onDone, forCover, run) {
    const api = client(); sync();
    if (!api || !owner) return Promise.resolve({ ok: false, error: MSG.load });
    if (writing) return Promise.resolve({ ok: false, error: MSG.busy, busy: true });
    writing = true; const g = gen;
    setStep(first, onDone);
    return run(api, g).then(function (r) {
      if (g !== gen) return { ok: false, stale: true, error: MSG.load };
      writing = false; step = '';
      return r;
    }, function (e) {
      if (g !== gen || e === STALE) return { ok: false, stale: true, error: MSG.load };
      writing = false; step = '';
      return writeFailure(e, forCover);
    });
  }
  /** يضغط الملف ثم يرفعه ويتأكد أنه «ready». أي فشل يرمي (localMsg أو ApiError). */
  async function uploadAsset(api, file, kind, g, onDone) {
    if (!file || typeof file !== 'object' || !/^image\//.test(String(file.type || ''))) throw { localMsg: MSG.badImage };
    const comp = typeof ImageService !== 'undefined' ? await ImageService.compressImage(file) : { ok: false, error: MSG.badImage };
    if (g !== gen) throw STALE;
    if (!comp || !comp.ok || !comp.blob) throw { localMsg: (comp && comp.error) || MSG.badImage };
    const blob = comp.blob;
    if (!blob.size) throw { localMsg: MSG.badImage };
    if (blob.size > MAX_BYTES) throw { localMsg: MSG.tooBig };
    setStep('upload', onDone);
    const d = await api.upload('/v1/me/assets', blob, blob.type, { query: { kind: kind } });
    if (g !== gen) throw STALE;
    let a = d && d.asset;
    if (!validAsset(a, kind)) throw { localMsg: BackendAuth.messages.invalid };
    if (a.status === 'pending') {
      const id = a.id, d2 = await api.get('/v1/me/assets/' + id);
      if (g !== gen) throw STALE;
      a = d2 && d2.asset;
      if (!validAsset(a, kind) || a.id !== id) throw { localMsg: BackendAuth.messages.invalid };
    }
    if (a.status === 'rejected') throw { localMsg: MSG.rejected };
    if (a.status !== 'ready') throw { localMsg: MSG.pending };
    return a;
  }

  function addToCar(carId, file, onDone) {
    sync();
    if (!ID_RE.test(carId)) return Promise.resolve({ ok: false, error: MSG.gone });
    if (gallery.carId !== carId || (gallery.status !== 'ready' && gallery.status !== 'empty')) return Promise.resolve({ ok: false, error: MSG.load });
    if (gallery.items.length >= gallery.max) return Promise.resolve({ ok: false, error: MSG.limit, limit: true });
    return lockWrite('prepare', onDone, false, async function (api, g) {
      const a = await uploadAsset(api, file, 'car_image', g, onDone);
      setStep('attach', onDone);
      const d = await api.post('/v1/me/cars/' + carId + '/images', { assetId: a.id });
      if (g !== gen) throw STALE;
      if (!validImage(d && d.image)) throw { localMsg: BackendAuth.messages.invalid };
      if (gallery.carId === carId) {
        const items = gallery.items.filter(function (x) { return x.id !== d.image.id; }).concat([copyImage(d.image)]).sort(byOrder);
        gallery = { status: 'ready', carId: carId, items: items, max: gallery.max, error: null };
        ensureOwn(d.image.assetId, 'thumb', onDone);
      }
      if (typeof BackendCatalog !== 'undefined') BackendCatalog.invalidate();
      return { ok: true };
    }).then(function (r) { return settle(r, carId, onDone); });
  }
  function removeFromCar(carId, imageId, onDone) {
    sync();
    if (!ID_RE.test(carId) || typeof imageId !== 'string' || !IMG_ID_RE.test(imageId)) return Promise.resolve({ ok: false, error: MSG.gone });
    if (gallery.carId !== carId || !gallery.items.some(function (x) { return x.id === imageId; })) return Promise.resolve({ ok: false, error: MSG.gone });
    return lockWrite('remove', onDone, false, async function (api, g) {
      await api.delete('/v1/me/cars/' + carId + '/images/' + imageId);
      if (g !== gen) throw STALE;
      if (gallery.carId === carId) {
        const items = gallery.items.filter(function (x) { return x.id !== imageId; });
        gallery = { status: items.length ? 'ready' : 'empty', carId: carId, items: items, max: gallery.max, error: null };
        prune();
      }
      if (typeof BackendCatalog !== 'undefined') BackendCatalog.invalidate();
      return { ok: true };
    }).then(function (r) { return settle(r, carId, onDone); });
  }
  /** بعد كتابة: تحديث هادئ من الخادم (يصحّح الترتيب والرئيسية، ويكشف إعلانًا فُقد أو حدًّا تغيّر) ثم إعادة الرسم */
  function settle(r, carId, onDone) {
    if (r.stale) return r;
    if (r.ok || r.gone || r.limit || r.state) loadGallery(carId, onDone, true);
    done(onDone);
    return r;
  }

  function setCover(file, onDone) {
    sync();
    if (cover.status !== 'ready') return Promise.resolve({ ok: false, error: MSG.load });
    return lockWrite('prepare', onDone, true, async function (api, g) {
      const a = await uploadAsset(api, file, 'showroom_cover', g, onDone);
      setStep('cover', onDone);
      const d = await api.put('/v1/dealer/showroom/cover', { assetId: a.id });
      if (g !== gen) throw STALE;
      if (!(d && validCover(d.cover))) throw { localMsg: BackendAuth.messages.invalid };
      cover = { status: 'ready', cover: copyCover(d.cover), error: null };
      prune(); ensureOwn(d.cover.assetId, 'image', onDone);
      return { ok: true };
    }).then(function (r) { done(onDone); return r; });
  }
  function clearCover(onDone) {
    sync();
    if (cover.status !== 'ready' || !cover.cover) return Promise.resolve({ ok: false, error: MSG.state });
    return lockWrite('remove', onDone, true, async function (api, g) {
      await api.delete('/v1/dealer/showroom/cover');
      if (g !== gen) throw STALE;
      cover = { status: 'ready', cover: null, error: null };
      prune();
      return { ok: true };
    }).then(function (r) { done(onDone); return r; });
  }

  return {
    isEnabled: isEnabled, messages: MSG,
    gallery: galleryState, retryGallery: retryGallery, addToCar: addToCar, removeFromCar: removeFromCar,
    publicCar: publicCar, retryPublicCar: retryPublicCar, publicShowroom: publicShowroom, retryPublicShowroom: retryPublicShowroom,
    cover: coverState, retryCover: retryCover, setCover: setCover, clearCover: clearCover,
    reset: function () { owner = null; reset(); },
  };
})();

/* ==========================================================================
   BACKEND FAVORITES — مفضلة المستخدم من الخادم (المهمة 11.7-C). وضع الخادم فقط، بالعقد الموجود
   (backend/src/favorites/routes.ts) — لا مسار مُختلَق:
     GET    /v1/me/favorites?limit(1..50)&before   → 200 { items: [{ car: PublicCar, favoritedAt }], nextBefore: مؤشر معتم|null }
     POST   /v1/me/favorites { carId }             → 201 { favorite } (جديدة) | 200 (موجودة أصلًا: idempotent) | 404 (سيارة غير عامة) | 403
     DELETE /v1/me/favorites/:carId                → 204 (idempotent: أيضًا إن لم تكن مفضلة)
   لا مسار «هل هي مفضلة؟» في الخادم، فحالة القلب مشتقة من القائمة المحمّلة (حتى 4 صفحات = 200 سيارة)؛ وPOST/DELETE idempotent فيُصحَّح أي اختلاف.
   • الحالة في الذاكرة فقط ومربوطة بهوية المستخدم (خروج/دخول يُسقطها)، ونتيجة طلب قديم لا تُطبَّق.
   • لا نسخة محلية ولا رجوع إلى بيانات محلية بعد فشل أي طلب؛ الحالة لا تتغير إلا بنجاح الخادم؛ طلب واحد لكل سيارة في آنٍ واحد.
   ========================================================================== */
const BackendFavorites = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;
  const PAGE = 50, AUTO_PAGES = 4;
  const MSG = {
    load: 'تعذّر تحميل المفضلة من الخادم. حاول مرة أخرى.',
    denied: 'حسابك لا يملك صلاحية استخدام المفضلة حاليًا.',
    gone: 'هذه السيارة غير متاحة حاليًا ولا يمكن إضافتها إلى المفضلة.',
    badId: 'السيارة غير صالحة.',
    write: 'تعذّر تحديث المفضلة. حاول مرة أخرى.',
  };
  let owner = null, gen = 0, list, ids, busy;
  const emptyList = () => ({ status: 'idle', items: [], nextBefore: null, error: null, more: false, pages: 0 });
  function reset() { gen++; list = emptyList(); ids = new Set(); busy = {}; }
  reset();

  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  function client() { return isEnabled() ? BackendAuth.api() : null; }
  function sync() {
    const u = typeof BackendAuth !== 'undefined' ? BackendAuth.currentUser() : null;
    const id = u ? u.id : null;
    if (id !== owner) { owner = id; reset(); }
    return id;
  }
  const str = v => typeof v === 'string';
  const idOk = id => typeof id === 'string' && ID_RE.test(id);
  const cursorOk = v => v === null || (str(v) && v.length > 0 && v.length <= 300);
  function messageOf(e) {
    let m = MSG.load;
    try { m = BackendAuth.messageFor(e, 'session'); if (m === BackendAuth.messages.generic) m = MSG.load; } catch (x) { m = MSG.load; }
    return m;
  }
  function readFailure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http' && e.status === 403) return { status: 'denied', error: MSG.denied };
    if (e && e.name === 'ApiError' && e.kind === 'http' && e.status < 500 && e.status !== 401 && e.status !== 429) return { status: 'error', error: MSG.load };
    return { status: 'error', error: messageOf(e) };
  }
  /** عنصر من الخادم → { car, favoritedAt } أو null (سيارة بشكل عام صالح عبر مدقّق الكتالوج) */
  function item(x) {
    if (!x || typeof x !== 'object' || !str(x.favoritedAt) || typeof BackendCatalog === 'undefined') return null;
    const car = BackendCatalog.carOf(x.car);
    return car ? { car: car, favoritedAt: x.favoritedAt } : null;
  }

  function fetchPage(onDone, append, autoPages) {
    const api = client(); sync();
    if (!api || !owner || list.status === 'loading' || list.more) return Promise.resolve(false);
    const before = append ? list.nextBefore : null;
    if (append && (list.status !== 'ready' || !before)) return Promise.resolve(false);
    const g = gen, query = { limit: String(PAGE) };
    if (before) query.before = before;
    if (append) list = Object.assign({}, list, { more: true, error: null }); else list = { status: 'loading', items: [], nextBefore: null, error: null, more: false, pages: 0 };
    return api.get('/v1/me/favorites', { query: query }).then(function (d) {
      if (g !== gen) return false;
      const parsed = d && Array.isArray(d.items) && cursorOk(d.nextBefore) ? d.items.map(item) : null;
      if (!parsed || parsed.some(function (x) { return x === null; })) {
        list = append ? Object.assign({}, list, { more: false, error: BackendAuth.messages.invalid }) : { status: 'error', items: [], nextBefore: null, error: BackendAuth.messages.invalid, more: false, pages: 0 };
        return true;
      }
      const have = {}; (append ? list.items : []).forEach(function (x) { have[x.car.id] = true; });
      const items = (append ? list.items : []).concat(parsed.filter(function (x) { return !have[x.car.id] && (have[x.car.id] = true); }));
      list = { status: items.length ? 'ready' : 'empty', items: items, nextBefore: d.nextBefore, error: null, more: false, pages: list.pages + 1 };
      ids = new Set(items.map(function (x) { return x.car.id; }));
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = readFailure(e);
      if (append && f.status === 'error') list = Object.assign({}, list, { more: false, error: f.error });
      else list = { status: f.status, items: [], nextBefore: null, error: f.error, more: false, pages: 0 };
      return true;
    }).then(function (applied) {
      if (applied && autoPages > 1 && list.status === 'ready' && list.nextBefore && list.pages < autoPages) return fetchPage(onDone, true, autoPages);
      if (applied && typeof onDone === 'function') onDone();
      return applied;
    });
  }
  /** تحميل أول مرة (حتى 4 صفحات لاشتقاق حالة القلوب) إن لم تُحمَّل بعد؛ لا يعيد المحاولة تلقائيًا بعد فشل. */
  function ensure(onDone) { sync(); if (client() && owner && list.status === 'idle') fetchPage(onDone, false, AUTO_PAGES); }
  function reload(onDone) { sync(); list = emptyList(); return fetchPage(onDone, false, AUTO_PAGES); }
  function more(onDone) { return fetchPage(onDone, true, 1); }

  function isFavorite(carId) { sync(); return owner !== null && ids.has(String(carId)); }

  function failure(e, adding) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404) return { ok: false, error: adding ? MSG.gone : MSG.write, gone: adding };
      if (e.status === 403) return { ok: false, error: MSG.denied };
      if (e.status === 400) return { ok: false, error: MSG.write };
    }
    return { ok: false, error: messageOf(e) };
  }
  /** تبديل حالة المفضلة لسيارة. لا يتغير شيء محليًا إلا بعد نجاح الخادم؛ طلب واحد لكل سيارة في آنٍ واحد. */
  function toggle(carId) {
    const api = client(); sync();
    if (!api || !owner) return Promise.resolve({ ok: false, error: MSG.load });
    if (!idOk(carId)) return Promise.resolve({ ok: false, error: MSG.badId });
    if (busy[carId]) return Promise.resolve({ ok: false, busy: true });
    const adding = !ids.has(carId), g = gen;
    busy[carId] = true;
    const call = adding ? api.post('/v1/me/favorites', { carId: carId }) : api.delete('/v1/me/favorites/' + carId);
    return call.then(function () {
      if (g !== gen) return { ok: true, stale: true, isFavorite: adding };
      delete busy[carId];
      if (adding) { ids.add(carId); if (list.status !== 'loading') list = emptyList(); }   // القائمة تُعاد جلبها لتضم السيارة (بياناتها من الخادم)
      else {
        ids.delete(carId);
        const items = list.items.filter(function (x) { return x.car.id !== carId; });
        if (list.status === 'ready' || list.status === 'empty') list = Object.assign({}, list, items.length || list.nextBefore ? { items: items } : { items: [], status: 'empty' });
      }
      return { ok: true, isFavorite: adding };
    }, function (e) {
      if (g !== gen) return { ok: false, error: MSG.load, stale: true };
      delete busy[carId];
      return failure(e, adding);
    });
  }

  function listState() { sync(); return Object.assign({}, list, { items: list.items.map(function (x) { return { car: Object.assign({}, x.car), favoritedAt: x.favoritedAt }; }) }); }
  return { isEnabled: isEnabled, list: listState, ensure: ensure, reload: reload, more: more, isFavorite: isFavorite, toggle: toggle, messages: MSG, reset: function () { owner = null; reset(); } };
})();

/* ==========================================================================
   BACKEND MEMBER — إعلانات سيارات المستخدم نفسه من الخادم (المهمة 11.7-B). وضع الخادم فقط، بالعقد الموجود
   (backend/src/member-cars/routes.ts) — لا مسار مُختلَق:
     GET    /v1/me/cars?limit(1..50)&before          → 200 { items: OwnMemberCar[], nextBefore }
     GET    /v1/me/cars/:id                          → 200 { car } | 404 (ليست له/غير موجودة: الخادم لا يفرّق)
     POST   /v1/me/cars  { brand, model, year, price, currency, phone, [mileage, transmission, fuelType, color, description, whatsapp, location] } → 201 { car } (الحالة pending)
     PATCH  /v1/me/cars/:id { version, ...الحقول } أو { version, status:'sold' } (من active فقط) → 200 { car }
     DELETE /v1/me/cars/:id?version=n                → 204
   لا مالك ولا حالة ولا نشر يُرسل من العميل (ما عدا sold). 403 = الحساب لا يملك صلاحية الإعلانات؛ 409 version_conflict ← إعادة جلب لا كتابة فوق.
   • الحالة في الذاكرة فقط ومربوطة بهوية المستخدم (خروج/دخول يُسقطها)، وعملية كتابة واحدة في آنٍ واحد.
   • لا رجوع إلى البيانات المحلية بعد فشل أي طلب. الصور والمفضلة وإعلان المكافأة خارج هذه الخطوة.
   ========================================================================== */
const BackendMember = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;
  const PAGE = 50;   // MEMBER_CAR_LIMIT_MAX
  const STATUSES = ['pending', 'active', 'sold', 'rejected', 'suspended'];
  const MSG = {
    load: 'تعذّر تحميل إعلاناتك من الخادم. حاول مرة أخرى.',
    denied: 'حسابك لا يملك صلاحية إدارة الإعلانات حاليًا.',
    busy: 'جارٍ تنفيذ عملية سابقة… انتظر قليلًا.',
    conflict: 'تغيّر هذا الإعلان من مكان آخر. أُعيد تحميل بياناته؛ راجعه ثم أعد المحاولة.',
    gone: 'الإعلان غير موجود أو لم يعد لك.',
    badId: 'الإعلان غير صالح.',
    validation: 'تحقق من بيانات الإعلان ثم أعد المحاولة.',
    state: 'لا يمكن تنفيذ هذا الإجراء على الإعلان في وضعه الحالي.',
    noSold: 'يمكن تحديد «مباعة» للإعلان النشط فقط.',
  };
  const FIELD_LABEL = { brand: 'الماركة', model: 'الموديل', year: 'سنة الصنع', price: 'السعر', currency: 'العملة', mileage: 'الكيلومترات', transmission: 'ناقل الحركة', fuelType: 'نوع الوقود', color: 'اللون', description: 'الوصف', phone: 'رقم الهاتف', whatsapp: 'رقم واتساب', location: 'الموقع' };
  let owner = null, gen = 0, list, detail, writing;
  const emptyList = () => ({ status: 'idle', items: [], nextBefore: null, error: null, more: false });
  const emptyDetail = () => ({ status: 'idle', id: null, car: null, error: null });
  function reset() { gen++; writing = false; list = emptyList(); detail = emptyDetail(); }
  reset();

  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  function client() { return isEnabled() ? BackendAuth.api() : null; }
  function sync() {
    const u = typeof BackendAuth !== 'undefined' ? BackendAuth.currentUser() : null;
    const id = u ? u.id : null;
    if (id !== owner) { owner = id; reset(); }
    return id;
  }
  const str = v => typeof v === 'string';
  const optStr = v => v === null || v === undefined || typeof v === 'string';
  const idOk = id => typeof id === 'string' && ID_RE.test(id);
  function valid(c) {
    return !!c && typeof c === 'object' && str(c.id) && ID_RE.test(c.id) && str(c.brand) && str(c.model) && Number.isFinite(c.year) && Number.isFinite(c.price)
      && str(c.currency) && STATUSES.indexOf(c.status) >= 0 && Number.isInteger(c.version) && c.version >= 1
      && (c.mileage === null || c.mileage === undefined || Number.isFinite(c.mileage))
      && str(c.transmission) && str(c.fuelType) && str(c.color) && str(c.description) && str(c.phone) && optStr(c.whatsapp) && optStr(c.location)
      && optStr(c.rejectionReason) && optStr(c.suspensionReason) && optStr(c.createdAt);
  }
  function copy(c) {
    return { id: c.id, brand: c.brand, model: c.model, year: c.year, price: c.price, currency: c.currency, mileage: c.mileage === undefined ? null : c.mileage,
      transmission: c.transmission, fuelType: c.fuelType, color: c.color, description: c.description, phone: c.phone, whatsapp: c.whatsapp || '', location: c.location || '',
      latitude: Number.isFinite(c.latitude) ? c.latitude : null, longitude: Number.isFinite(c.longitude) ? c.longitude : null,
      status: c.status, version: c.version, rejectionReason: c.rejectionReason || '', suspensionReason: c.suspensionReason || '', createdAt: c.createdAt || '' };
  }
  function messageOf(e) {
    let m = MSG.load;
    try { m = BackendAuth.messageFor(e, 'session'); if (m === BackendAuth.messages.generic) m = MSG.load; } catch (x) { m = MSG.load; }
    return m;
  }
  /** خطأ قراءة → حالة (403 = denied، 404 = غير موجود للتفاصيل) */
  function readFailure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404) return { status: 'empty', error: null };
      if (e.status === 403) return { status: 'denied', error: MSG.denied };
      if (e.status < 500 && e.status !== 401 && e.status !== 429) return { status: 'error', error: MSG.load };
    }
    return { status: 'error', error: messageOf(e) };
  }

  function loadList(onDone, append) {
    const api = client(); sync();
    if (!api || !owner || list.status === 'loading' || list.more) return Promise.resolve(false);
    const before = append ? list.nextBefore : null;
    if (append && (list.status !== 'ready' || !before)) return Promise.resolve(false);
    const g = gen, query = { limit: String(PAGE) };
    if (before) query.before = before;
    if (append) list = Object.assign({}, list, { more: true, error: null }); else list = { status: 'loading', items: [], nextBefore: null, error: null, more: false };
    return api.get('/v1/me/cars', { query: query }).then(function (d) {
      if (g !== gen) return false;
      const ok = d && Array.isArray(d.items) && d.items.every(valid) && (d.nextBefore === null || str(d.nextBefore));
      if (!ok) {
        list = append ? Object.assign({}, list, { more: false, error: BackendAuth.messages.invalid }) : { status: 'error', items: [], nextBefore: null, error: BackendAuth.messages.invalid, more: false };
        return true;
      }
      const items = (append ? list.items : []).concat(d.items.map(copy));
      list = { status: items.length ? 'ready' : 'empty', items: items, nextBefore: d.nextBefore, error: null, more: false };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = readFailure(e);
      // فشل قائمة فارغة بـ404 غير متوقع: خطأ لا «لا توجد إعلانات»
      const st = f.status === 'empty' ? 'error' : f.status, msg = f.status === 'empty' ? MSG.load : f.error;
      if (append && st === 'error') list = Object.assign({}, list, { more: false, error: msg });
      else list = { status: st, items: [], nextBefore: null, error: msg, more: false };
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }
  function loadCar(id, onDone) {
    const api = client(); sync();
    if (!api || !owner || !idOk(id) || (detail.status === 'loading' && detail.id === id)) return Promise.resolve(false);
    const g = gen;
    detail = { status: 'loading', id: id, car: null, error: null };
    return api.get('/v1/me/cars/' + id).then(function (d) {
      if (g !== gen) return false;
      detail = valid(d && d.car) && d.car.id === id ? { status: 'ready', id: id, car: copy(d.car), error: null } : { status: 'error', id: id, car: null, error: BackendAuth.messages.invalid };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = readFailure(e); detail = { status: f.status, id: id, car: null, error: f.error };
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }

  /* ---------------- الكتابة ---------------- */
  function writeFailure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 409 && e.code === 'version_conflict') return { ok: false, error: MSG.conflict, conflict: true };
      if (e.status === 409) return { ok: false, error: MSG.state, state: true };
      if (e.status === 404) return { ok: false, error: MSG.gone, gone: true };
      if (e.status === 403) return { ok: false, error: MSG.denied };
      if (e.status === 400) {
        if (Array.isArray(e.fields)) for (let i = 0; i < e.fields.length; i++) { const f = e.fields[i] || {}; if (FIELD_LABEL[f.field]) return { ok: false, error: 'تحقق من الحقل: ' + FIELD_LABEL[f.field] + '.' }; }
        return { ok: false, error: MSG.validation };
      }
    }
    return { ok: false, error: messageOf(e) };
  }
  function invalidateAll() {
    if (typeof BackendCatalog !== 'undefined') BackendCatalog.invalidate();
    list = emptyList(); detail = emptyDetail();
  }
  /** كتابة واحدة: قفل، ثم onOk عند النجاح فقط. الحالة المحلية لا تُمسّ إلا إن بقيت الهوية نفسها. */
  function write(call, onOk) {
    const api = client(); sync();
    if (!api || !owner) return Promise.resolve({ ok: false, error: MSG.load });
    if (writing) return Promise.resolve({ ok: false, error: MSG.busy, busy: true });
    writing = true; const g = gen;
    return call(api).then(function (data) {
      if (g === gen) { writing = false; onOk(data); if (typeof BackendCatalog !== 'undefined') BackendCatalog.invalidate(); }
      return { ok: true, stale: g !== gen, car: data && valid(data.car) ? copy(data.car) : null };
    }, function (e) {
      if (g !== gen) return { ok: false, error: MSG.load, stale: true };
      writing = false;
      const f = writeFailure(e);
      if (f.conflict || f.gone || f.state) { list = emptyList(); detail = emptyDetail(); }   // نسخة قديمة: تُجلب الحالية من الخادم
      return f;
    });
  }
  function versionOf(id) {
    const c = list.items.filter(function (x) { return x.id === id; })[0] || (detail.status === 'ready' && detail.id === id ? detail.car : null);
    return c && Number.isInteger(c.version) ? c : null;
  }
  function createCar(fields) { return write(function (api) { return api.post('/v1/me/cars', fields); }, invalidateAll); }
  function updateCar(id, version, fields) {
    if (!idOk(id) || !Number.isInteger(version)) return Promise.resolve({ ok: false, error: MSG.badId });
    return write(function (api) { return api.patch('/v1/me/cars/' + id, Object.assign({ version: version }, fields)); }, invalidateAll);
  }
  /** «مباعة» فقط (الخادم لا يقبل غيرها من المالك) */
  function markSold(id) {
    sync();
    const c = versionOf(id);
    if (!idOk(id) || !c) return Promise.resolve({ ok: false, error: MSG.badId });
    if (c.status !== 'active') return Promise.resolve({ ok: false, error: MSG.noSold });
    return write(function (api) { return api.patch('/v1/me/cars/' + id, { version: c.version, status: 'sold' }); }, invalidateAll);
  }
  function deleteCar(id) {
    sync();
    const c = versionOf(id);
    if (!idOk(id) || !c) return Promise.resolve({ ok: false, error: MSG.badId });
    return write(function (api) { return api.delete('/v1/me/cars/' + id, { query: { version: String(c.version) } }); }, invalidateAll);
  }

  /** المالك يستطيع «مباعة» للإعلان النشط فقط (قاعدة الخادم) */
  function canSell(c) { return !!c && c.status === 'active'; }
  /** سبب الرفض/الإيقاف الذي يعرضه الخادم لصاحب الإعلان */
  function reasonOf(c) { return !c ? '' : c.status === 'rejected' ? (c.rejectionReason || '') : c.status === 'suspended' ? (c.suspensionReason || '') : ''; }
  function listState() { sync(); return Object.assign({}, list, { items: list.items.map(function (c) { return Object.assign({}, c); }) }); }
  function carState() { sync(); return Object.assign({}, detail, { car: detail.car ? Object.assign({}, detail.car) : null }); }
  function listCar(id) { sync(); const c = versionOf(id); return c ? Object.assign({}, c) : null; }

  return { isEnabled: isEnabled, canSell: canSell, reasonOf: reasonOf, list: listState, car: carState, loadList: loadList, loadCar: loadCar, createCar: createCar, updateCar: updateCar, markSold: markSold, deleteCar: deleteCar, listCar: listCar, messages: MSG, reset: function () { owner = null; reset(); } };
})();

/* ==========================================================================
   BACKEND DEALER — قراءة لوحة صاحب المعرض من الخادم (المرحلة 11.7.2.4) — قراءة فقط.
   (في ملف الجسر نفسه عمدًا: لا سكربت جديد في index.html — عدد السكربتات ثابت 87 تحرسه اختبارات المراحل السابقة.)
   بالعقد الموجود فقط (backend/src/dealers/routes.ts و backend/src/showroom-cars/routes.ts):
     GET /v1/dealer/showroom                      → 200 { showroom: { id, name, status, phone, whatsapp, address, createdAt } }
     GET /v1/dealer/cars?limit=1..50&before=<id>  → 200 { items: ShowroomCarView[], nextBefore: string|null }
   كلاهما يردّ 404 not_found إن لم يكن المتصل تاجرًا نشطًا له معرض، و401 بلا جلسة صالحة (يعالجها ApiClient بالتجديد ثم onAuthLost).

   • يعمل في وضع الخادم فقط (BackendAuth.api() غير null). في الوضع المحلي لا يُستدعى ولا يتصل بشيء.
   • لا رجوع إلى البيانات التجريبية المحلية أبدًا: فشل الطلب = حالة «error» برسالة عربية وزر إعادة المحاولة.
   • الحالة في الذاكرة فقط ومربوطة بهوية المستخدم: تغيّر المستخدم (دخول/خروج/فقدان جلسة) يُسقطها، ونتيجة طلب قديم لا تُطبَّق.
   • (11.7.2.5) عمليات سيارات المعرض بالعقد الموجود (backend/src/showroom-cars/routes.ts) — إضافة/تعديل/تغيير حالة/حذف:
       POST   /v1/dealer/cars                { brand, model, year, price, currency, mileage|null, transmission, fuelType, color, description } → 201 { car }
       PATCH  /v1/dealer/cars/:id            { version, ...الحقول } أو { version, status:'available'|'sold' }                                       → 200 { car } | 409 version_conflict
       DELETE /v1/dealer/cars/:id?version=n                                                                                                       → 204          | 409 version_conflict
       GET    /v1/dealer/cars/:id            → 200 { car } (يُجلب عند فتح شاشة التعديل ليكون «version» حديثًا)
     لا معرّف معرض ولا دور ولا حالة ما عدا available/sold يُرسل من العميل أبدًا. عملية كتابة واحدة في آنٍ واحد. الصور وغلاف المعرض ليست ضمن هذه الخطوة.
   الحالات: idle | loading | ready | empty (لا معرض مرتبط) | denied (403) | error
   ========================================================================== */
const BackendDealer = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;   // معرّف الخادم (رقم نصي): يدخل في onclick وفي مسار الطلب فلا يُقبل غيره
  const CARS_PAGE = 50;   // SHOWROOM_CAR_LIMIT_MAX في الخلفية
  const MSG = {
    load: 'تعذّر تحميل البيانات من الخادم. حاول مرة أخرى.',
    denied: 'لا تملك صلاحية الوصول إلى هذه البيانات.',
  };
  let owner = null;          // معرّف المستخدم الذي تخصّه الحالة
  let gen = 0;
  let showroom, cars, detail, writing;
  function reset() { gen++; writing = false; detail = { status: 'idle', id: null, car: null, error: null }; showroom = { status: 'idle', data: null, error: null }; cars = { status: 'idle', items: [], nextBefore: null, error: null, more: false, noShowroom: false }; }
  reset();

  function client() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled() ? BackendAuth.api() : null; }
  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  /** الحالة تخص المستخدم الحالي فقط */
  function sync() {
    const u = typeof BackendAuth !== 'undefined' ? BackendAuth.currentUser() : null;
    const id = u ? u.id : null;
    if (id !== owner) { owner = id; reset(); }
    return id;
  }

  const str = v => typeof v === 'string';
  const optStr = v => v === null || v === undefined || typeof v === 'string';
  function validShowroom(s) {
    return !!s && typeof s === 'object' && str(s.id) && str(s.name) && str(s.status) && optStr(s.phone) && optStr(s.whatsapp) && optStr(s.address);
  }
  function validCar(c) {
    return !!c && typeof c === 'object' && str(c.id) && ID_RE.test(c.id) && str(c.brand) && str(c.model) && Number.isFinite(c.year)
      && Number.isFinite(c.price) && str(c.currency) && str(c.status) && (c.mileage === null || c.mileage === undefined || Number.isFinite(c.mileage));
  }
  function copyCar(c) {
    return { id: c.id, brand: c.brand, model: c.model, year: c.year, price: c.price, currency: c.currency, mileage: c.mileage === undefined ? null : c.mileage,
      color: str(c.color) ? c.color : '', status: c.status,
      version: Number.isInteger(c.version) ? c.version : null, transmission: str(c.transmission) ? c.transmission : '', fuelType: str(c.fuelType) ? c.fuelType : '', description: str(c.description) ? c.description : '' };
  }
  const validFull = c => validCar(c) && Number.isInteger(c.version) && c.version >= 1 && str(c.transmission) && str(c.fuelType) && str(c.description) && str(c.color);

  /** خطأ ApiError → حالة. 404 = لا معرض مرتبط بالحساب (حالة فارغة لا خطأ). */
  function failure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404) return { status: 'empty', error: null };
      if (e.status === 403) return { status: 'denied', error: MSG.denied };
    }
    let m = MSG.load;
    if (e && e.name === 'ApiError' && (e.kind !== 'http' || e.status === 401 || e.status === 429 || e.status >= 500)) {
      try { m = BackendAuth.messageFor(e, 'session'); } catch (x) { m = MSG.load; }
      if (m === BackendAuth.messages.generic) m = MSG.load;
    }
    return { status: 'error', error: m };
  }

  /** onDone() يُستدعى بعد اكتمال طلب (نجاح أو فشل) يخص المستخدم نفسه — لإعادة رسم الشاشة. */
  function loadShowroom(onDone) {
    const api = client(); sync();
    if (!api || !owner || showroom.status === 'loading') return Promise.resolve(false);
    const g = gen;
    showroom = { status: 'loading', data: null, error: null };
    return api.get('/v1/dealer/showroom').then(function (d) {
      if (g !== gen) return false;
      const s = d && d.showroom;
      showroom = validShowroom(s)
        ? { status: 'ready', data: { id: s.id, name: s.name, status: s.status, phone: s.phone || null, whatsapp: s.whatsapp || null, address: s.address || null }, error: null }
        : { status: 'error', data: null, error: BackendAuth.messages.invalid };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = failure(e); showroom = { status: f.status, data: null, error: f.error };
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }

  /** append: تحميل الصفحة التالية (before = nextBefore) وإلحاقها؛ وإلا الصفحة الأولى من جديد. */
  function loadCars(onDone, append) {
    const api = client(); sync();
    if (!api || !owner || cars.status === 'loading' || cars.more) return Promise.resolve(false);
    const before = append ? cars.nextBefore : null;
    if (append && (cars.status !== 'ready' || !before)) return Promise.resolve(false);
    const g = gen;
    const query = { limit: String(CARS_PAGE) };
    if (before) query.before = before;
    if (append) cars = Object.assign({}, cars, { more: true, error: null });
    else cars = { status: 'loading', items: [], nextBefore: null, error: null, more: false, noShowroom: false };
    return api.get('/v1/dealer/cars', { query: query }).then(function (d) {
      if (g !== gen) return false;
      const ok = d && Array.isArray(d.items) && d.items.every(validCar) && (d.nextBefore === null || str(d.nextBefore));
      if (!ok) {
        cars = append ? Object.assign({}, cars, { more: false, error: BackendAuth.messages.invalid })
                      : { status: 'error', items: [], nextBefore: null, error: BackendAuth.messages.invalid, more: false, noShowroom: false };
        return true;
      }
      const items = (append ? cars.items : []).concat(d.items.map(copyCar));
      cars = { status: items.length ? 'ready' : 'empty', items: items, nextBefore: d.nextBefore, error: null, more: false, noShowroom: false };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      const f = failure(e);
      // فشل «عرض المزيد» لا يُخفي ما عُرض: تبقى القائمة مع رسالة الخطأ
      if (append && f.status === 'error') cars = Object.assign({}, cars, { more: false, error: f.error });
      else cars = { status: f.status, items: [], nextBefore: null, error: f.error, more: false, noShowroom: f.status === 'empty' };
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }

  /* ---------------- (11.7.2.5) عمليات الكتابة ---------------- */
  const FIELD_LABEL = { brand: 'الماركة', model: 'الموديل', year: 'سنة الصنع', price: 'السعر', currency: 'العملة', mileage: 'المسافة المقطوعة', transmission: 'ناقل الحركة', fuelType: 'نوع الوقود', color: 'اللون', description: 'الوصف' };
  const WMSG = {
    busy: 'جارٍ تنفيذ عملية سابقة… انتظر قليلًا.',
    conflict: 'تغيّرت هذه السيارة من مكان آخر. أُعيد تحميل بياناتها؛ راجعها ثم أعد المحاولة.',
    gone: 'السيارة غير موجودة أو لم تعد في معرضك.',
    noShowroom: 'لا يوجد معرض مرتبط بحسابك.',
    badId: 'السيارة غير صالحة.',
    validation: 'تحقق من بيانات السيارة ثم أعد المحاولة.',
    unsupported: 'ميزة الخادم غير مفعّلة.',
  };
  /** فشل كتابة → { ok:false, error, conflict?, gone? }. لا يُعدَّل أي شيء محليًا. */
  function writeFailure(e, isCreate) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 409 && e.code === 'version_conflict') return { ok: false, error: WMSG.conflict, conflict: true };
      if (e.status === 404) return isCreate ? { ok: false, error: WMSG.noShowroom } : { ok: false, error: WMSG.gone, gone: true };
      if (e.status === 403) return { ok: false, error: MSG.denied };
      if (e.status === 400 && Array.isArray(e.fields)) {
        for (let i = 0; i < e.fields.length; i++) { const f = e.fields[i] || {}; if (FIELD_LABEL[f.field]) return { ok: false, error: 'تحقق من الحقل: ' + FIELD_LABEL[f.field] + '.' }; }
        return { ok: false, error: WMSG.validation };
      }
      if (e.status === 400) return { ok: false, error: WMSG.validation };
    }
    let m = MSG.load;
    try { m = BackendAuth.messageFor(e, 'session'); if (m === BackendAuth.messages.generic) m = MSG.load; } catch (x) { m = MSG.load; }
    return { ok: false, error: m };
  }
  const idOk = id => typeof id === 'string' && ID_RE.test(id);
  /** تنفيذ كتابة واحدة: قفل، ثم onOk(data, g) عند النجاح فقط. الحالة المحلية لا تُمسّ إلا إن بقيت الهوية نفسها. */
  function write(isCreate, call, onOk) {
    const api = client(); sync();
    if (!api || !owner) return Promise.resolve({ ok: false, error: MSG.load });
    if (writing) return Promise.resolve({ ok: false, error: WMSG.busy, busy: true });
    writing = true; const g = gen;
    return call(api).then(function (data) {
      if (g === gen) { writing = false; onOk(data); if (typeof BackendCatalog !== 'undefined') BackendCatalog.invalidate(); }
      return { ok: true, stale: g !== gen };
    }, function (e) {
      if (g !== gen) return { ok: false, error: MSG.load, stale: true };
      writing = false;
      const f = writeFailure(e, isCreate);
      if (f.conflict || f.gone) { cars = { status: 'idle', items: [], nextBefore: null, error: null, more: false, noShowroom: false }; detail = { status: 'idle', id: null, car: null, error: null }; }
      return f;
    });
  }
  function invalidateCars() { if (typeof BackendCatalog !== 'undefined') BackendCatalog.invalidate(); cars = { status: 'idle', items: [], nextBefore: null, error: null, more: false, noShowroom: false }; }
  function putInList(raw) {
    if (!validFull(raw)) { invalidateCars(); return; }
    const c = copyCar(raw);
    if (cars.status === 'ready') cars = Object.assign({}, cars, { items: cars.items.map(function (x) { return x.id === c.id ? c : x; }) });
  }

  /** حقول النموذج (مُتحقَّق منها في الواجهة) → إضافة */
  function createCar(fields) {
    return write(true, function (api) { return api.post('/v1/dealer/cars', fields); }, function () { invalidateCars(); detail = { status: 'idle', id: null, car: null, error: null }; });
  }
  function updateCar(id, version, fields) {
    if (!idOk(id) || !Number.isInteger(version)) return Promise.resolve({ ok: false, error: WMSG.badId });
    return write(false, function (api) { return api.patch('/v1/dealer/cars/' + id, Object.assign({ version: version }, fields)); },
      function (d) { detail = { status: 'idle', id: null, car: null, error: null }; putInList(d && d.car); });
  }
  /** تغيير الحالة: الإصدار من القائمة المعروضة (نسخة الخادم الأخيرة التي رآها المستخدم) */
  function setStatus(id, status) {
    sync();
    const c = cars.items.filter(function (x) { return x.id === id; })[0];
    if (!idOk(id) || !c || !Number.isInteger(c.version)) return Promise.resolve({ ok: false, error: WMSG.badId });
    if (status !== 'available' && status !== 'sold') return Promise.resolve({ ok: false, error: 'حالة غير مسموحة.' });
    return write(false, function (api) { return api.patch('/v1/dealer/cars/' + id, { version: c.version, status: status }); },
      function (d) { detail = { status: 'idle', id: null, car: null, error: null }; putInList(d && d.car); });
  }
  function deleteCar(id) {
    sync();
    const c = cars.items.filter(function (x) { return x.id === id; })[0];
    if (!idOk(id) || !c || !Number.isInteger(c.version)) return Promise.resolve({ ok: false, error: WMSG.badId });
    return write(false, function (api) { return api.delete('/v1/dealer/cars/' + id, { query: { version: String(c.version) } }); },
      function () {
        detail = { status: 'idle', id: null, car: null, error: null };
        if (cars.status === 'ready') { const items = cars.items.filter(function (x) { return x.id !== id; }); cars = Object.assign({}, cars, items.length || cars.nextBefore ? { items: items } : { items: [], status: 'empty' }); }
      });
  }
  /** سيارة واحدة طازجة لشاشة التعديل (GET /v1/dealer/cars/:id) */
  function loadCar(id, onDone) {
    const api = client(); sync();
    if (!api || !owner || !idOk(id) || (detail.status === 'loading' && detail.id === id)) return Promise.resolve(false);
    const g = gen;
    detail = { status: 'loading', id: id, car: null, error: null };
    return api.get('/v1/dealer/cars/' + id).then(function (d) {
      if (g !== gen) return false;
      detail = validFull(d && d.car) && d.car.id === id ? { status: 'ready', id: id, car: copyCar(d.car), error: null } : { status: 'error', id: id, car: null, error: BackendAuth.messages.invalid };
      return true;
    }, function (e) {
      if (g !== gen) return false;
      if (e && e.name === 'ApiError' && e.kind === 'http' && (e.status === 404)) detail = { status: 'empty', id: id, car: null, error: null };
      else { const f = failure(e); detail = { status: f.status === 'empty' ? 'empty' : f.status, id: id, car: null, error: f.error }; }
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); return applied; });
  }
  function carState() { sync(); return Object.assign({}, detail, { car: detail.car ? Object.assign({}, detail.car) : null }); }
  function carsFor(id) { sync(); return cars.items.filter(function (x) { return x.id === id; })[0] || null; }

  /** نسخ للعرض فقط */
  function showroomState() { sync(); return Object.assign({}, showroom, { data: showroom.data ? Object.assign({}, showroom.data) : null }); }
  function carsState() { sync(); return Object.assign({}, cars, { items: cars.items.map(function (c) { return Object.assign({}, c); }) }); }

  return { isEnabled: isEnabled, showroom: showroomState, cars: carsState, loadShowroom: loadShowroom, loadCars: loadCars, createCar: createCar, updateCar: updateCar, setStatus: setStatus, deleteCar: deleteCar, loadCar: loadCar, car: carState, listCar: carsFor, reset: function () { owner = null; reset(); } };
})();

/* ==========================================================================
   BACKEND CATALOG — القوائم والتفاصيل العامة من الخادم (المهمة 11.7-A) — قراءة فقط، بلا مصادقة.
   بالعقد الموجود (backend/src/catalog/routes.ts + params.ts):
     GET /v1/public/cars?q&limit(1..50)&before&source(showroom|member)&showroomId&brand&model&color&transmission&fuelType&status
                        &yearMin&yearMax&currency&priceMin&priceMax   → 200 { items: PublicCar[], nextBefore: string|null }
     GET /v1/public/cars/:id       → 200 { car }       | 404 (غير موجودة/غير عامة: الخادم لا يفرّق)
     GET /v1/public/showrooms?q&limit&before            → 200 { items: PublicShowroom[], nextBefore }
     GET /v1/public/showrooms/:id  → 200 { showroom }  | 404
   • يعمل في وضع الخادم فقط. لا رجوع إلى البيانات المحلية بعد فشل أي طلب، ولا يُكتب شيء في التخزين.
   • ذاكرة مؤقتة قصيرة (30 ث) مفتاحها المسار+الاستعلام نفسه (استعلامان متطابقان = حالة واحدة)؛ نتيجة طلب قديم لا تُطبَّق على استعلام تغيّر.
   • لا خيار «كيلومترات» في الخادم (غير موجود في العقد): لا يُرسل ولا يُصفّى محليًا. الصور والمفضلة غير مربوطتين هنا.
   ========================================================================== */
const BackendCatalog = (function () {
  const ID_RE = /^[1-9][0-9]{0,18}$/;
  const TTL_MS = 30000, MAX_STATES = 60, PAGE = 50;
  const MSG = {
    load: 'تعذّر تحميل البيانات من الخادم. حاول مرة أخرى.',
    bad: 'تحقق من قيم البحث والفلاتر.',
    limited: 'محاولات كثيرة. انتظر قليلًا ثم حاول مرة أخرى.',
  };
  const lists = new Map(), details = new Map();
  let seq = 0, debounceTimer = null;
  const str = v => typeof v === 'string';
  const optStr = v => v === null || v === undefined || typeof v === 'string';
  const optNum = v => v === null || v === undefined || Number.isFinite(v);
  const now = () => Date.now();

  function isEnabled() { return typeof BackendAuth !== 'undefined' && BackendAuth.isEnabled(); }
  function client() { return isEnabled() ? BackendAuth.api() : null; }
  function sigOf(path, query) { return path + '?' + JSON.stringify(Object.keys(query || {}).sort().map(function (k) { return [k, query[k]]; })); }
  function evict(map) { while (map.size > MAX_STATES) map.delete(map.keys().next().value); }

  function validCar(c) {
    return !!c && typeof c === 'object' && str(c.id) && ID_RE.test(c.id) && (c.sourceType === 'showroom' || c.sourceType === 'member')
      && (c.showroomId === null || c.showroomId === undefined || (str(c.showroomId) && ID_RE.test(c.showroomId)))
      && str(c.brand) && str(c.model) && Number.isFinite(c.year) && Number.isFinite(c.price) && str(c.currency) && str(c.status)
      && optNum(c.mileage) && optStr(c.transmission) && optStr(c.fuelType) && optStr(c.color) && optStr(c.description) && optStr(c.phone) && optStr(c.whatsapp)
      && optStr(c.location) && optNum(c.latitude) && optNum(c.longitude) && optStr(c.ownerName);
  }
  function copyCar(c) {
    return { id: c.id, sourceType: c.sourceType, showroomId: c.showroomId || null, brand: c.brand, model: c.model, year: c.year, price: c.price, currency: c.currency,
      mileage: c.mileage === undefined ? null : c.mileage, transmission: c.transmission || '', fuelType: c.fuelType || '', color: c.color || '', description: c.description || '',
      status: c.status, phone: c.phone || null, whatsapp: c.whatsapp || null, location: c.location || '', latitude: c.latitude === undefined ? null : c.latitude,
      longitude: c.longitude === undefined ? null : c.longitude, ownerName: c.ownerName || null, createdAt: str(c.createdAt) ? c.createdAt : null };
  }
  function validShowroom(s) {
    return !!s && typeof s === 'object' && str(s.id) && ID_RE.test(s.id) && str(s.name) && optStr(s.description) && optStr(s.phone) && optStr(s.whatsapp) && optStr(s.address)
      && optNum(s.latitude) && optNum(s.longitude) && optStr(s.workingHours) && (s.services === undefined || (Array.isArray(s.services) && s.services.every(str)));
  }
  function copyShowroom(s) {
    return { id: s.id, name: s.name, description: s.description || '', phone: s.phone || null, whatsapp: s.whatsapp || null, address: s.address || '',
      latitude: s.latitude === undefined ? null : s.latitude, longitude: s.longitude === undefined ? null : s.longitude, workingHours: s.workingHours || '',
      services: Array.isArray(s.services) ? s.services.slice() : [], status: 'active' };
  }
  const validators = { cars: [validCar, copyCar], showrooms: [validShowroom, copyShowroom] };
  const kindOf = path => (path === '/v1/public/showrooms' ? 'showrooms' : 'cars');

  /** خطأ ApiError → { status:'error'|'missing', error } (404 في التفاصيل = «غير موجودة»؛ 400 = قيم غير صالحة) */
  function failure(e) {
    if (e && e.name === 'ApiError' && e.kind === 'http') {
      if (e.status === 404) return { status: 'missing', error: null };
      if (e.status === 400) return { status: 'error', error: MSG.bad };
    }
    let m = MSG.load;
    if (e && e.name === 'ApiError') { try { m = BackendAuth.messageFor(e, 'public'); if (m === BackendAuth.messages.generic || m === BackendAuth.messages.credentials) m = MSG.load; } catch (x) { m = MSG.load; } }
    return { status: 'error', error: m };
  }
  const fresh = st => st && st.status !== 'error' && (st.status === 'loading' || now() - st.at < TTL_MS);
  const view = st => (st ? Object.assign({}, st, { items: st.items.map(function (x) { return Object.assign({}, x); }) }) : { status: 'idle', items: [], nextBefore: null, error: null, more: false });

  /** يطلب صفحة (append: التالية). يعيد وعدًا بعد التطبيق؛ onDone يُستدعى عند تغيّر الحالة النهائية. */
  function fetchPage(path, query, append, onDone, autoPages) {
    const api = client(), sig = sigOf(path, query);
    if (!api) return Promise.resolve(false);
    const st = lists.get(sig), kind = kindOf(path), v = validators[kind];
    const before = append ? (st && st.nextBefore) : null;
    if (append && (!st || st.status !== 'ready' || !before || st.more)) return Promise.resolve(false);
    const mine = ++seq;
    const q = Object.assign({ limit: String(PAGE) }, query); if (before) q.before = before;
    if (append) lists.set(sig, Object.assign({}, st, { more: true, error: null, req: mine }));
    else lists.set(sig, { status: 'loading', items: [], nextBefore: null, error: null, more: false, at: now(), req: mine, pages: 0 });
    evict(lists);
    return api.get(path, { query: q, auth: 'none' }).then(function (d) {
      const cur = lists.get(sig); if (!cur || cur.req !== mine) return false;
      const ok = d && Array.isArray(d.items) && d.items.every(v[0]) && (d.nextBefore === null || (str(d.nextBefore) && ID_RE.test(d.nextBefore)));
      if (!ok) { lists.set(sig, append ? Object.assign({}, cur, { more: false, error: BackendAuth.messages.invalid }) : { status: 'error', items: [], nextBefore: null, error: BackendAuth.messages.invalid, more: false, at: now(), req: mine, pages: 0 }); return true; }
      const items = (append ? cur.items : []).concat(d.items.map(v[1]));
      lists.set(sig, { status: items.length ? 'ready' : 'empty', items: items, nextBefore: d.nextBefore, error: null, more: false, at: now(), req: mine, pages: (cur.pages || 0) + 1 });
      return true;
    }, function (e) {
      const cur = lists.get(sig); if (!cur || cur.req !== mine) return false;
      const f = failure(e);
      lists.set(sig, append ? Object.assign({}, cur, { more: false, error: f.error || MSG.load }) : { status: 'error', items: [], nextBefore: null, error: f.error || MSG.load, more: false, at: now(), req: mine, pages: 0 });
      return true;
    }).then(function (applied) {
      if (!applied) return false;
      const cur = lists.get(sig);
      if (autoPages > 1 && cur && cur.status === 'ready' && cur.nextBefore && cur.pages < autoPages) return fetchPage(path, query, true, onDone, autoPages);
      if (typeof onDone === 'function') onDone();
      return true;
    });
  }

  /** حالة القائمة للاستعلام؛ تُحمَّل إن لم توجد أو قدمت (وفشل سابق لا يُعاد تلقائيًا: زر «إعادة المحاولة»). */
  function list(path, query, onDone, opts) {
    const sig = sigOf(path, query), st = lists.get(sig);
    if (isEnabled() && (!st || (st.status !== 'error' && !fresh(st)))) fetchPage(path, query, false, onDone, opts && opts.autoPages);
    return view(lists.get(sig));
  }
  /** إعادة محاولة الأقسام الفاشلة فقط (defs: { مفتاح: { path, query } }) */
  function retryFailed(defs, onDone) {
    Object.keys(defs).forEach(function (k) {
      const s = defs[k], st = lists.get(sigOf(s.path, s.query));
      if (st && st.status === 'error') fetchPage(s.path, s.query, false, onDone);
    });
  }
  function reload(path, query, onDone, opts) { lists.delete(sigOf(path, query)); return fetchPage(path, query, false, onDone, opts && opts.autoPages); }
  function more(path, query, onDone) { return fetchPage(path, query, true, onDone, 0); }

  /** تفصيل واحد: kind 'car' | 'showroom' */
  function detail(kind, id, onDone) {
    const key = kind + ':' + id, st = details.get(key);
    if (!isEnabled() || !ID_RE.test(String(id))) return { status: 'missing', item: null, error: null };
    if (st && (st.status === 'loading' || st.status === 'error' || (now() - st.at < TTL_MS))) return Object.assign({}, st);
    const api = client(), mine = ++seq;
    details.set(key, { status: 'loading', item: null, error: null, at: now(), req: mine }); evict(details);
    const path = '/v1/public/' + (kind === 'car' ? 'cars/' : 'showrooms/') + id;
    api.get(path, { auth: 'none' }).then(function (d) {
      const cur = details.get(key); if (!cur || cur.req !== mine) return false;
      const raw = d && (kind === 'car' ? d.car : d.showroom);
      const ok = kind === 'car' ? validCar(raw) : validShowroom(raw);
      details.set(key, ok && raw.id === String(id) ? { status: 'ready', item: kind === 'car' ? copyCar(raw) : copyShowroom(raw), error: null, at: now(), req: mine }
        : { status: 'error', item: null, error: BackendAuth.messages.invalid, at: now(), req: mine });
      return true;
    }, function (e) {
      const cur = details.get(key); if (!cur || cur.req !== mine) return false;
      const f = failure(e); details.set(key, { status: f.status, item: null, error: f.error, at: now(), req: mine });
      return true;
    }).then(function (applied) { if (applied && typeof onDone === 'function') onDone(); });
    return Object.assign({}, details.get(key));
  }
  function reloadDetail(kind, id, onDone) { details.delete(kind + ':' + id); return detail(kind, id, onDone); }

  /** فلاتر الواجهة (CarFilters) → معاملات الخادم. الكيلومترات غير مدعومة في العقد فلا تُرسل. نطاق معكوس أو قيمة غير صالحة لا تُرسل (تنبّه الواجهة بملاحظتها). */
  function filterQuery(raw) {
    const c = CarFilters.normalize(raw), q = {};
    if (c.brand) q.brand = c.brand;
    if (c.model && c.brand) q.model = c.model;
    if (c.year !== null && Number.isInteger(c.year)) { q.yearMin = String(c.year); q.yearMax = String(c.year); }
    const lo = c.minPrice, hi = c.maxPrice;
    if (lo === null || hi === null || lo <= hi) {
      if (lo !== null) q.priceMin = String(lo);
      if (hi !== null) q.priceMax = String(hi);
    }
    if (q.priceMin !== undefined || q.priceMax !== undefined) q.currency = c.priceCurrency || 'IQD';
    return q;
  }
  /** بحث نصي: يُقصّ إلى حدّ الخادم (≤100 حرف، ≤5 كلمات) كي لا يُرفض الطلب كله */
  function searchTerm(text) {
    const t = Array.from(String(text === undefined || text === null ? '' : text).replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').normalize('NFKC').replace(/\s+/g, ' ').trim()).slice(0, 100).join('');
    return t.split(' ').filter(Boolean).slice(0, 5).join(' ');
  }
  function debounce(fn, ms) { if (debounceTimer) clearTimeout(debounceTimer); debounceTimer = setTimeout(function () { debounceTimer = null; fn(); }, ms === undefined ? 300 : ms); }
  function invalidate() { lists.clear(); details.clear(); seq++; }

  return { isEnabled: isEnabled, carOf: function (c) { return validCar(c) ? copyCar(c) : null; }, list: list, reload: reload, retryFailed: retryFailed, more: more, detail: detail, reloadDetail: reloadDetail, filterQuery: filterQuery, searchTerm: searchTerm, debounce: debounce, invalidate: invalidate, PAGE: PAGE, messages: MSG };
})();

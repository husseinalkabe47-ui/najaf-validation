/* أكشنز المرحلة 7: إدارة سيارات المعرض + منتقي الصور. الشاشات تستدعي الخدمات فقط،
   والخدمات هي التي تتحقق من الصلاحية والحد الأقصى والضغط. */
function _collectShowroomCarForm() {
  return {
    brand: _val('scBrand'), model: _val('scModel'), year: _val('scYear'), price: _val('scPrice'), currency: _val('scCurrency') || undefined,   // قائمة بلا خيار فارغ: القيمة المختارة دائمًا
    mileage: _val('scMileage'), transmission: _val('scTransmission'), fuelType: _val('scFuelType'),
    color: _val('scColor'), description: _val('scDescription'),
  };
}

/* ---- (11.7.2.5) وضع الخادم: سيارات المعرض عبر /v1/dealer/cars (api/authBridge.js → BackendDealer). تحقق الواجهة قبل الإرسال، والخادم يعيد التحقق. ---- */
function _remoteShowroomCarBody() {
  const raw = _collectShowroomCarForm();
  const tooLong = textLimitError(raw, ['brand', 'model', 'color', 'description']);
  if (tooLong) return { error: tooLong };
  const brand = String(raw.brand || '').trim(), model = String(raw.model || '').trim();
  if (!brand || !model || String(raw.year || '').trim() === '' || String(raw.price || '').trim() === '') return { error: 'الرجاء تعبئة الحقول المطلوبة (الماركة، الموديل، السنة، السعر).' };
  const hasWord = /[\p{L}\p{N}]/u;
  if (!hasWord.test(brand)) return { error: 'اسم الماركة غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
  if (!hasWord.test(model)) return { error: 'اسم الموديل غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
  const year = parseWholeNumber(raw.year); if (isNaN(year) || year < 1980 || year > 2100) return { error: 'سنة الصنع غير صحيحة.' };
  const price = parseWholeNumber(raw.price); if (isNaN(price) || price <= 0 || price > 999999999999) return { error: 'السعر غير صحيح.' };
  const cur = parseCurrency(raw.currency); if (!cur.ok) return { error: 'عملة السعر غير صحيحة. اختر الدينار العراقي أو الدولار الأمريكي.' };
  let mileage = null;
  if (String(raw.mileage || '').trim() !== '') { mileage = parseWholeNumber(raw.mileage); if (isNaN(mileage) || mileage > 10000000) return { error: 'المسافة المقطوعة غير صحيحة.' }; }
  return { body: { brand, model, year, price, currency: cur.value, mileage, transmission: String(raw.transmission || '').trim(), fuelType: String(raw.fuelType || '').trim(),
    color: String(raw.color || '').trim(), description: String(raw.description || '').trim() } };
}

/* قفل ضد الضغط المتكرر: السيارة تُنشأ فورًا ثم تُحفظ الصور (غير فوري)، فبدون قفل تتكرر السيارة */
let _showroomSubmitBusy = false;
async function handleAddShowroomCarSubmit() {
  if (_showroomSubmitBusy) return;
  _showroomSubmitBusy = true; setBusy('addShowroomCarBtn', true);
  try {
    if (BackendDealer.isEnabled()) {
      const f = _remoteShowroomCarBody(); if (f.error) { _setMsg('showroomCarError', f.error); return; }
      const rr = await BackendDealer.createCar(f.body);
      if (!rr.ok) { _setMsg('showroomCarError', rr.error); return; }
      notify('تمت إضافة السيارة ونشرها');
      go('myShowroomCars');
      return;
    }
    const draft = _imageCtx && _imageCtx.mode === 'draft' ? _imageCtx.draft : null;
    const r = await createShowroomCar(_collectShowroomCarForm(), draft);
    if (!r.ok) { _setMsg('showroomCarError', userMsg(r.error)); return; }
    notifySaved('تمت إضافة السيارة ونشرها', r);
    warnImagesNotSaved(r);
    go('myShowroomCars');
  } finally { _showroomSubmitBusy = false; setBusy('addShowroomCarBtn', false); }
}

let _showroomEditBusy = false;
async function _handleEditShowroomCarRemote(id) {
  if (_showroomEditBusy) return;
  const st = BackendDealer.car();
  if (st.status !== 'ready' || st.id !== id) return;
  const f = _remoteShowroomCarBody(); if (f.error) { _setMsg('showroomCarError', f.error); return; }
  _showroomEditBusy = true; setBusy('editShowroomCarBtn', true);
  try {
    const rr = await BackendDealer.updateCar(id, st.car.version, f.body);
    if (!rr.ok) {
      if (rr.conflict || rr.gone) { notify(rr.error, 'error'); render(); return; }   // بياناته القديمة لا تُعاد: تُجلب نسخة الخادم الحالية (أو «غير موجودة»)
      _setMsg('showroomCarError', rr.error); return;
    }
    notify('تم حفظ التعديلات');
    go('myShowroomCars');
  } finally { _showroomEditBusy = false; setBusy('editShowroomCarBtn', false); }
}

function handleEditShowroomCarSubmit(id) {
  if (BackendDealer.isEnabled()) return _handleEditShowroomCarRemote(id);
  const r = updateShowroomCar(id, _collectShowroomCarForm());
  if (!r.ok) { _setMsg('showroomCarError', userMsg(r.error)); return; }
  notifySaved('تم حفظ التعديلات', r);
  go('myShowroomCars');
}

const _deleting = {};
async function handleDeleteShowroomCar(id) {
  if (_deleting[id]) return;
  const remote = BackendDealer.isEnabled();
  const car = remote ? BackendDealer.listCar(id) : getCarById(id);
  const name = car ? `${car.brand} ${car.model}` : 'هذه السيارة';
  _deleting[id] = true;                                   // نقرة ثانية أثناء نافذة التأكيد أو الحذف لا تعيد المحاولة
  const yes = await askConfirmAsync({ title: 'حذف السيارة', message: remote ? `هل أنت متأكد من حذف «${name}»؟ لا يمكن التراجع.` : `هل أنت متأكد من حذف «${name}»؟ ستُحذف صورها أيضًا ولا يمكن التراجع.`, confirmLabel: 'حذف', danger: true });
  if (!yes) { delete _deleting[id]; return; }
  try {
    if (remote) {
      const rr = await BackendDealer.deleteCar(id);
      if (!rr.ok) notify(rr.error, 'error'); else notify('تم حذف السيارة');
      render();
      return;
    }
    const r = await deleteShowroomCar(id);
    if (!r.ok) { notify(r.error); return; }
    notifySaved('تم حذف السيارة', r);
    render();
  } finally { delete _deleting[id]; }
}

let _statusBusy = false;
async function _handleShowroomCarStatusRemote(id, status) {
  if (_statusBusy) return;
  _statusBusy = true;
  try {
    const rr = await BackendDealer.setStatus(id, status);
    if (!rr.ok) notify(rr.error, 'error'); else notify('تم تغيير الحالة');
    render();
  } finally { _statusBusy = false; }
}
function handleShowroomCarStatusChange(id, status) {
  if (!status) return;
  if (BackendDealer.isEnabled()) return _handleShowroomCarStatusRemote(id, status);
  const r = changeShowroomCarStatus(id, status);
  if (!r.ok) { notify(r.error); return; }
  notifySaved('تم تغيير الحالة', r);
  render();
}

/* ---- منتقي الصور ---- */
async function handlePickImages(input) {
  const ctx = _imageCtx;
  if (!ctx) return;
  const files = Array.from(input.files || []);
  input.value = '';                 // لا يبقى الملف الأصلي مرتبطًا بعنصر الإدخال
  if (ctx.busy) return;             // معالجة صور جارية: لا تبدأ معالجة متداخلة
  ctx.busy = true; ctx.message = ''; refreshImagePicker();
  for (const f of files) {
    const r = ctx.mode === 'draft' ? await ctx.draft.add(f) : await addCarImage(ctx.carId, f);
    if (!r.ok) { ctx.message = r.error; break; }
  }
  ctx.busy = false; refreshImagePicker();
}

async function handleRemoveImage(ref) {
  const ctx = _imageCtx; if (!ctx) return;
  const r = ctx.mode === 'draft' ? ctx.draft.remove(ref) : await removeCarImage(ref);
  ctx.message = r.ok ? '' : (r.error || '');
  refreshImagePicker();
}

function handleSetMainImage(ref) {
  const ctx = _imageCtx; if (!ctx) return;
  const r = ctx.mode === 'draft' ? ctx.draft.setMain(ref) : setMainImage(ref);
  ctx.message = r.ok ? '' : (r.error || '');
  refreshImagePicker();
}

/** حالة «جارٍ الحفظ…» على زر أثناء عملية غير فورية (تمنع الضغط المتكرر بتعطيل الزر) */
function setBusy(btnId, busy) {
  const el = btnId ? document.getElementById(btnId) : null;
  if (!el) return;
  el.disabled = !!busy;
  if (busy) { el._label = el.textContent; el.textContent = 'جارٍ الحفظ…'; }
  else if (el._label) { el.textContent = el._label; }
}

/* ---- (11.7-D) غلاف المعرض في وضع الخادم (BackendImages.cover). رفع ثم PUT الغلاف؛ الحذف DELETE. قفل واحد يمنع التكرار. ---- */
async function handleRemoteCoverPick(input) {
  const file = input && input.files && input.files[0];
  try { if (input) input.value = ''; } catch (e) { /* اختيار الملف نفسه مرة أخرى لاحقًا */ }
  if (!file || !BackendImages.isEnabled()) return;
  _rcMsg = '';
  const r = await BackendImages.setCover(file, refreshRemoteCover);
  if (r.stale || r.busy) return;
  if (r.ok) notify('تم تعيين غلاف المعرض'); else _rcMsg = r.error;
  refreshRemoteCover();
}
let _rcClearing = false;
async function handleRemoteCoverClear() {
  if (_rcClearing || !BackendImages.isEnabled()) return;
  _rcClearing = true;
  try {
    const yes = await askConfirmAsync({ title: 'حذف الغلاف', message: 'هل تريد حذف غلاف المعرض؟', confirmLabel: 'حذف', danger: true });
    if (!yes) return;
    _rcMsg = '';
    const r = await BackendImages.clearCover(refreshRemoteCover);
    if (r.stale || r.busy) return;
    if (r.ok) notify('تم حذف غلاف المعرض'); else _rcMsg = r.error;
    refreshRemoteCover();
  } finally { _rcClearing = false; }
}
function handleRemoteCoverRetry() { _rcMsg = ''; BackendImages.retryCover(refreshRemoteCover); refreshRemoteCover(); }

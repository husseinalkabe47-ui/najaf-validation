/* ==========================================================================
   API CLIENT — عميل الخلفية المركزي (المرحلة 11.7.1)
   الطبقة الوحيدة التي ستتصل بالخادم عبر الشبكة. لا تلمس البيانات المحلية/التجريبية
   (repositories / AppStorage) ولا تعتمد عليها؛ ولا تعتمد عليها أي شاشة حاليًا
   (لم تُربط أي شاشة في هذه المرحلة، فسلوك التطبيق الحالي لم يتغيّر).

   عقد الخلفية الذي يعكسه (backend/src/auth/routes.ts):
     • الجسم JSON فقط (application/json).
     • الأخطاء: { error: { code, message, fields?, requestId } } — و401 مع WWW-Authenticate، و429 مع Retry-After.
     • الجلسة: { accessToken, accessExpiresAt, refreshToken, refreshExpiresAt } (التواريخ ISO 8601).
     • POST /v1/auth/refresh { refreshToken } → { user, session } والرمز يُدوَّر (القديم يبطل).
     • الدور والحالة لا تأتي من الرمز ولا من العميل: الخادم يقرّر. هذا العميل لا يقرّر أي صلاحية.

   الأمان:
     • لا يكتب العميل أي سجل (لا console) ولا يضع الرموز في الأخطاء أو الرسائل.
     • رمز الوصول يُرسل فقط إلى base URL المهيّأ (المسار يجب أن يبدأ بـ "/" ولا يقبل روابط مطلقة).
     • الرموز في الذاكرة فقط افتراضيًا (تُفقد عند إعادة تحميل الصفحة) ولا تُكتب في localStorage.
     • كلمة المرور تمرّ فقط في جسم طلب الدخول (login) ولا تُخزَّن ولا تُسجَّل.
     • التجديد (refresh): استدعاء واحد فقط في آنٍ واحد (single-flight)، ومحاولة إعادة واحدة للطلب بعد 401.

   (11.7.2.2) نقل الجلسة بملف ارتباط (sessionTransport: 'cookie'):
     • رمز التجديد يعيش فقط في ملف ارتباط HttpOnly يضعه الخادم؛ لا يصل إلى JavaScript إطلاقًا (ولا يوجد في أي استجابة ولا مخزن).
       الجلسة في الذاكرة تحوي رمز الوصول وتواريخ الانتهاء فقط؛ ويُرفض أي ردّ يحمل refreshToken في هذا الوضع.
     • الدخول/التجديد/الخروج/الاستعادة تُرسل بالترويسة X-Session-Transport: cookie وcredentials:'same-origin' (يلزم أن تُخدَم الواجهة من أصل الخادم نفسه).
     • كل عملية تغيّر ملف الارتباط تمرّ عبر قفل واحد (Web Locks بين التبويبات + طابور داخل الصفحة)، لأن الخلفية تعتبر إعادة استعمال رمز تجديد
       قديم سرقةً وتُبطل الجلسة كلها؛ فلا يجوز أن يجدّد تبويبان بالرمز نفسه، ولا أن يتقاطع تجديد قديم مع دخول جديد.
     • restore(): استعادة الجلسة عند فتح الصفحة بتجديد واحد؛ نتيجتها لا تُطبَّق إن تغيّرت الهوية أثناء الانتظار (epoch).

   لا يعتمد على أي مكتبة. يعمل في المتصفح (متغيّر عام ApiClient) وفي Node (module.exports) للاختبار.
   fetch والمؤقّتات و AbortController والساعة كلها قابلة للحقن.
   ========================================================================== */
const ApiClient = (function () {
  const DEFAULT_TIMEOUT_MS = 15000;
  const MAX_TIMEOUT_MS = 120000;
  const REFRESH_SKEW_MS = 30000;            // نجدّد قبل انتهاء رمز الوصول بهذه المدة
  const REFRESH_PATH = '/v1/auth/refresh';  // العقد الموجود في الخلفية — لا مسار جديد
  const LOGOUT_PATH = '/v1/auth/logout';    // POST { refreshToken } → 204 (idempotent)
  const LOGIN_PATH = '/v1/auth/login';      // POST { phone, password } → { user, session }
  const REGISTER_PATH = '/v1/auth/register'; // POST { name, phone, password } → 201 { user, session } (11.7.2.3؛ الدور دائمًا «مستخدم» من الخادم)
  const TRANSPORT_HEADER = 'X-Session-Transport';
  const LOCK_NAME = 'najaf-auth-session';   // Web Locks: عمليات ملف الارتباط تمرّ واحدة في آنٍ واحد عبر كل التبويبات
  const RAW_TYPE = /^image\/(?:jpeg|png|webp)$/;   // (11.7-D) أنواع الرفع الثنائي المقبولة (تطابق الخادم)

  /* رسائل عربية عامة للواجهة (لا تحتوي أي بيانات من الخادم). رسالة الخادم الإنجليزية تبقى في .serverMessage للتشخيص فقط. */
  const AR_BY_KIND = {
    network: 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.',
    timeout: 'انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.',
    aborted: 'أُلغي الطلب.',
    invalid_response: 'ردّ الخادم غير صالح. حاول لاحقًا.',
    config: 'إعداد الاتصال بالخادم غير صحيح.',
    auth: 'يلزم تسجيل الدخول.',
  };
  const AR_BY_STATUS = {
    400: 'البيانات المرسلة غير صحيحة.',
    401: 'انتهت الجلسة. سجّل الدخول من جديد.',
    403: 'لا تملك صلاحية تنفيذ هذا الإجراء.',
    404: 'العنصر المطلوب غير موجود.',
    409: 'تعذّر تنفيذ الطلب بسبب تعارض في البيانات.',
    413: 'حجم البيانات المرسلة كبير جدًا.',
    415: 'نوع البيانات غير مدعوم.',
    429: 'محاولات كثيرة. انتظر قليلًا ثم حاول مرة أخرى.',
  };

  /** خطأ موحّد. kind: network | timeout | aborted | http | invalid_response | config | auth */
  class ApiError extends Error {
    constructor(kind, o) {
      o = o || {};
      super(o.message || kind);
      this.name = 'ApiError';
      this.kind = kind;
      this.status = o.status === undefined ? null : o.status;       // رمز HTTP أو null
      this.code = o.code || kind;                                   // رمز الخادم (error.code) أو kind
      this.fields = Array.isArray(o.fields) ? o.fields : undefined; // أخطاء الحقول كما يرسلها الخادم
      this.requestId = typeof o.requestId === 'string' ? o.requestId : undefined;
      this.retryAfterSeconds = o.retryAfterSeconds;
      this.serverMessage = typeof o.serverMessage === 'string' ? o.serverMessage : undefined;
      this.messageAr = AR_BY_STATUS[this.status] || AR_BY_KIND[kind] || (this.status >= 500 ? 'حدث خطأ في الخادم. حاول لاحقًا.' : 'تعذّر تنفيذ الطلب.');
    }
    get isNetworkError() { return this.kind === 'network' || this.kind === 'timeout'; }
    get isUnauthorized() { return this.status === 401 || this.kind === 'auth'; }
  }

  /* ---------------- الإعداد ---------------- */

  /** يتحقق من base URL ويعيده بلا "/" أخيرة. يقبل http(s) مطلقًا أو مسارًا نسبيًا يبدأ بـ "/" (خلف وكيل عكسي). يرمي ApiError(config). */
  function normalizeBaseUrl(raw) {
    const bad = () => new ApiError('config', { code: 'invalid_base_url', message: 'invalid API base URL' });
    if (typeof raw !== 'string') throw bad();
    const s = raw.trim();
    if (!s || /[\s\u0000-\u001f\\]/.test(s)) throw bad();
    if (s.startsWith('/')) {
      if (s.startsWith('//') || /[?#]/.test(s)) throw bad();
      return s.replace(/\/+$/, '');
    }
    let u;
    try { u = new URL(s); } catch (e) { throw bad(); }
    if ((u.protocol !== 'https:' && u.protocol !== 'http:') || u.username || u.password || u.search || u.hash) throw bad();
    return (u.origin + u.pathname).replace(/\/+$/, '');
  }

  /** يقرأ base URL من وسم <meta name="najaf-api-base-url"> ثم من window.NAJAF_API_BASE_URL. فارغ = الخلفية غير مفعّلة (وضع التجربة المحلي). */
  function readConfiguredBaseUrl(env) {
    env = env || {};
    const doc = env.document !== undefined ? env.document : (typeof document !== 'undefined' ? document : null);
    const win = env.window !== undefined ? env.window : (typeof window !== 'undefined' ? window : null);
    let v = '';
    try {
      const m = doc && typeof doc.querySelector === 'function' ? doc.querySelector('meta[name="najaf-api-base-url"]') : null;
      if (m && typeof m.content === 'string') v = m.content.trim();
    } catch (e) { v = ''; }
    if (!v && win && typeof win.NAJAF_API_BASE_URL === 'string') v = win.NAJAF_API_BASE_URL.trim();
    return v;
  }

  function validPath(path) {
    return typeof path === 'string' && path.startsWith('/') && !path.startsWith('//') && !/[\s\u0000-\u001f\\#]/.test(path) && !path.includes('://') && !path.includes('..');
  }

  function buildQuery(query) {
    if (query === undefined || query === null) return '';
    if (typeof query !== 'object' || Array.isArray(query)) throw new ApiError('config', { code: 'invalid_query', message: 'query must be an object' });
    const parts = [];
    Object.keys(query).forEach(function (k) {
      const v = query[k];
      if (v === undefined || v === null) return;
      if (typeof v === 'object') throw new ApiError('config', { code: 'invalid_query', message: 'query values must be primitive' });
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(v)));
    });
    return parts.length ? '?' + parts.join('&') : '';
  }

  /* ---------------- مخزن الجلسة (ذاكرة فقط افتراضيًا) ---------------- */

  /** cookieMode: لا يجوز أن تحوي الجلسة refreshToken أبدًا (يبقى في ملف الارتباط HttpOnly فقط). */
  function isSession(s, cookieMode) {
    const base = !!s && typeof s === 'object'
      && typeof s.accessToken === 'string' && s.accessToken.length > 0
      && Number.isFinite(Date.parse(s.accessExpiresAt)) && Number.isFinite(Date.parse(s.refreshExpiresAt));
    if (!base) return false;
    if (cookieMode) return s.refreshToken === undefined;
    return typeof s.refreshToken === 'string' && s.refreshToken.length > 0;
  }

  function createMemoryTokenStore() {
    let session = null;
    return { get: function () { return session; }, set: function (s) { session = s; }, clear: function () { session = null; } };
  }

  /* ---------------- العميل ---------------- */

  /**
   * @param {object} o
   *   baseUrl (إلزامي) | timeoutMs | fetch | now | setTimeout | clearTimeout | AbortController
   *   tokenStore {get,set,clear} (افتراضي: ذاكرة)  | onAuthLost(reason) — يُستدعى عند فقدان الجلسة نهائيًا ('expired' | 'refresh_rejected')
   *   sessionTransport: 'body' (افتراضي، 11.7.2.1) | 'cookie' (11.7.2.2) | locks (افتراضي navigator.locks) | pageOrigin (افتراضي location.origin)
   */
  function create(o) {
    o = o || {};
    const baseUrl = normalizeBaseUrl(o.baseUrl);
    if (o.sessionTransport !== undefined && o.sessionTransport !== 'body' && o.sessionTransport !== 'cookie') throw new ApiError('config', { code: 'invalid_transport', message: 'invalid session transport' });
    const cookieMode = o.sessionTransport === 'cookie';
    if (cookieMode && baseUrl !== '' && baseUrl.charAt(0) !== '/') {   // '' أو '/prefix' = نسبي لأصل الصفحة
      // ملف الارتباط يُرسل بـ credentials:'same-origin' فقط، ولا يوجد CORS في الخلفية: عنوان من أصل آخر لن يعمل ولا يجوز التظاهر بعكس ذلك.
      let po = o.pageOrigin;
      if (po === undefined) { try { po = typeof location !== 'undefined' && location ? location.origin : undefined; } catch (e) { po = undefined; } }
      let bo; try { bo = new URL(baseUrl).origin; } catch (e) { bo = undefined; }
      if (!po || !bo || po !== bo) throw new ApiError('config', { code: 'cookie_cross_origin', message: 'cookie transport requires the API on the page origin' });
    }
    const valid = function (s) { return isSession(s, cookieMode); };
    const defaultTimeout = clampTimeout(o.timeoutMs === undefined ? DEFAULT_TIMEOUT_MS : o.timeoutMs);
    const now = typeof o.now === 'function' ? o.now : function () { return Date.now(); };
    const store = o.tokenStore || createMemoryTokenStore();
    const onAuthLost = typeof o.onAuthLost === 'function' ? o.onAuthLost : null;
    let refreshing = null;                    // وعد التجديد الجاري (واحد فقط)
    let chain = Promise.resolve();            // طابور داخل الصفحة لعمليات ملف الارتباط (احتياط إن غابت Web Locks)
    let epoch = 0;                            // يزيد عند تغيير هوية الجلسة صراحةً (دخول/خروج/مسح): يمنع أن يعمل طلب قديم أو تجديد متأخر باسم جلسة أخرى

    function clampTimeout(ms) {
      if (!Number.isFinite(ms) || ms <= 0) throw new ApiError('config', { code: 'invalid_timeout', message: 'invalid timeout' });
      return Math.min(ms, MAX_TIMEOUT_MS);
    }
    function env() {
      const f = o.fetch || (typeof fetch === 'function' ? fetch : null);
      const AC = o.AbortController || (typeof AbortController === 'function' ? AbortController : null);
      if (!f || !AC) throw new ApiError('config', { code: 'no_fetch', message: 'fetch/AbortController unavailable' });
      return {
        fetch: f, AC: AC,
        setT: o.setTimeout || function (fn, ms) { return setTimeout(fn, ms); },
        clearT: o.clearTimeout || function (id) { clearTimeout(id); },
      };
    }

    /** فقدان الجلسة نهائيًا. إن تغيّرت الجلسة منذ بدء العملية (epoch) فلا نمسح الجلسة الجديدة ولا نبلّغ. */
    function notifyLost(reason, startEpoch) {
      if (startEpoch !== undefined && startEpoch !== epoch) return false;
      epoch++;
      store.clear();
      if (onAuthLost) { try { onAuthLost(reason); } catch (e) { /* خطأ المستمع لا يكسر الطلب */ } }
      return true;
    }

    function locksApi() {
      if (o.locks !== undefined) return o.locks;
      try { return typeof navigator !== 'undefined' && navigator && navigator.locks ? navigator.locks : null; } catch (e) { return null; }
    }
    /**
     * وضع الملف: كل عملية تقرأ/تدوّر/تمسح ملف الارتباط (دخول، تجديد، استعادة، خروج) تُنفَّذ وحدها: طابور داخل الصفحة ثم قفل Web Locks بين التبويبات.
     * وضع الجسم: لا ملف مشترك فلا قفل (التجديد المفرد single-flight كافٍ).
     */
    function guarded(fn) {
      if (!cookieMode) return Promise.resolve().then(fn);
      const run = function () {
        const L = locksApi();
        return L && typeof L.request === 'function' ? L.request(LOCK_NAME, fn) : fn();
      };
      const p = chain.then(run, run);
      chain = p.then(function () {}, function () {});
      return p;
    }

    /** إرسال واحد بلا منطق مصادقة. يرمي ApiError عند أي فشل. يعيد { status, data }. */
    async function send(method, path, opt) {
      if (!validPath(path)) throw new ApiError('config', { code: 'invalid_path', message: 'invalid request path' });
      const e = env();
      const url = baseUrl + path + buildQuery(opt.query);
      const headers = { Accept: opt.asBlob ? 'image/webp' : 'application/json' };
      let body;
      if (opt.raw !== undefined) {
        // (11.7-D) رفع ثنائي: جسم خام (Blob) بنوع صورة معروف فقط. الأخطاء تبقى JSON.
        if (!opt.raw || typeof opt.raw !== 'object' || !RAW_TYPE.test(String(opt.rawType || ''))) throw new ApiError('config', { code: 'invalid_body', message: 'invalid binary body' });
        body = opt.raw;
        headers['Content-Type'] = opt.rawType;
      } else if (opt.body !== undefined) {
        try { body = JSON.stringify(opt.body); } catch (err) { body = undefined; }
        if (body === undefined) throw new ApiError('config', { code: 'invalid_body', message: 'body is not JSON-serializable' });
        headers['Content-Type'] = 'application/json';
      }
      if (opt.token) headers.Authorization = 'Bearer ' + opt.token;
      if (opt.cookie) headers[TRANSPORT_HEADER] = 'cookie';

      const ctrl = new e.AC();
      let timedOut = false, callerAborted = false, rejectAbort;
      const aborted = new Promise(function (_, rej) { rejectAbort = rej; });
      aborted.catch(function () { /* يمنع unhandled rejection عندما ينتهي الطلب أولًا */ });
      const timer = e.setT(function () { timedOut = true; ctrl.abort(); rejectAbort(new Error('timeout')); }, clampTimeout(opt.timeoutMs === undefined ? defaultTimeout : opt.timeoutMs));
      const onCallerAbort = function () { callerAborted = true; ctrl.abort(); rejectAbort(new Error('aborted')); };
      if (opt.signal) {
        if (opt.signal.aborted) { e.clearT(timer); throw new ApiError('aborted', { message: 'aborted' }); }
        opt.signal.addEventListener('abort', onCallerAbort);
      }
      try {
        const work = (async function () {
          const res = await e.fetch(url, { method: method, headers: headers, body: body, signal: ctrl.signal, credentials: opt.cookie ? 'same-origin' : 'omit', cache: 'no-store', redirect: 'error' });
          if (opt.asBlob && res.status >= 200 && res.status < 300) {
            // (11.7-D) قراءة صورة WebP كـ Blob: أي نوع آخر يُرفض (لا نعرض جسمًا غير متوقع).
            const ct = headerOf(res, 'content-type');
            if (res.status !== 200 || typeof ct !== 'string' || !/^\s*image\/webp\s*(?:;|$)/i.test(ct) || typeof res.blob !== 'function') throw new ApiError('invalid_response', { status: res.status, message: 'unexpected image response' });
            return { res: res, text: '', blob: await res.blob() };
          }
          const text = (res.status === 204 || res.status === 205) ? '' : await res.text();
          return { res: res, text: text };
        })();
        const out = await Promise.race([work, aborted]);
        work.catch(function () {});
        if (out.blob !== undefined) return { status: out.res.status, data: out.blob };
        return interpret(out.res, out.text);
      } catch (err) {
        if (err instanceof ApiError) throw err;
        if (timedOut) throw new ApiError('timeout', { message: 'request timed out' });
        if (callerAborted) throw new ApiError('aborted', { message: 'aborted' });
        // رسالة الخطأ الأصلية قد تحوي الرابط؛ لا نمرّرها. الاسم فقط.
        throw new ApiError('network', { message: 'network error' });
      } finally {
        e.clearT(timer);
        if (opt.signal) opt.signal.removeEventListener('abort', onCallerAbort);
      }
    }

    function headerOf(res, name) {
      try { return res.headers && typeof res.headers.get === 'function' ? res.headers.get(name) : null; } catch (e) { return null; }
    }

    function parseJson(text) {
      if (text === '' || text === undefined) return { ok: true, value: null };
      try { return { ok: true, value: JSON.parse(text) }; } catch (e) { return { ok: false }; }
    }

    function interpret(res, text) {
      const status = res.status;
      const parsed = parseJson(text);
      if (status >= 200 && status < 300) {
        if (!parsed.ok) throw new ApiError('invalid_response', { status: status, message: 'invalid JSON in response' });
        const ct = headerOf(res, 'content-type');
        if (text !== '' && ct !== null && !/^\s*application\/(?:[\w.+-]+\+)?json\b/i.test(ct)) throw new ApiError('invalid_response', { status: status, message: 'unexpected content type' });
        return { status: status, data: parsed.value };
      }
      const err = parsed.ok && parsed.value && typeof parsed.value === 'object' && parsed.value.error && typeof parsed.value.error === 'object' ? parsed.value.error : null;
      let retry;
      const ra = headerOf(res, 'retry-after');
      if (typeof ra === 'string' && /^\d{1,7}$/.test(ra.trim())) retry = Number(ra.trim());
      throw new ApiError('http', {
        status: status,
        code: err && typeof err.code === 'string' && /^[a-z0-9_]{1,64}$/i.test(err.code) ? err.code : 'http_error',
        serverMessage: err && typeof err.message === 'string' ? err.message.slice(0, 300) : undefined,
        fields: err && Array.isArray(err.fields) ? err.fields.slice(0, 20) : undefined,
        requestId: err && typeof err.requestId === 'string' ? err.requestId.slice(0, 100) : undefined,
        retryAfterSeconds: retry,
        message: 'HTTP ' + status,
      });
    }

    /* ---------------- الجلسة والتجديد ---------------- */

    function accessFresh(s) { return Date.parse(s.accessExpiresAt) - REFRESH_SKEW_MS > now(); }
    function refreshUsable(s) { return Date.parse(s.refreshExpiresAt) > now(); }

    /** تجديد واحد فقط في آنٍ واحد: كل من يطلبه أثناء التجديد ينتظر الوعد نفسه. e0 تُلتقط الآن لا بعد انتظار القفل. */
    function refreshSession() {
      if (!refreshing) {
        const e0 = epoch;
        refreshing = guarded(function () { return doRefresh(e0); }).then(function (v) { refreshing = null; return v; }, function (e) { refreshing = null; throw e; });
      }
      return refreshing;
    }

    function sessionOnly(next) {
      return cookieMode
        ? { accessToken: next.accessToken, accessExpiresAt: next.accessExpiresAt, refreshExpiresAt: next.refreshExpiresAt }
        : { accessToken: next.accessToken, accessExpiresAt: next.accessExpiresAt, refreshToken: next.refreshToken, refreshExpiresAt: next.refreshExpiresAt };
    }
    /** إبطال جلسة لم نعد نريدها (أفضل جهد، لا يرمي). وضع الملف: الملف نفسه يحدّد الجلسة. وضع الجسم: الرمز المُدوَّر. */
    function revokeBestEffort(next) {
      const opt = cookieMode ? { cookie: true } : (next && typeof next.refreshToken === 'string' ? { body: { refreshToken: next.refreshToken } } : null);
      if (!opt) return Promise.resolve();
      return send('POST', LOGOUT_PATH, opt).then(function () {}, function () { /* أفضل جهد */ });
    }

    async function doRefresh(e0) {
      if (epoch !== e0) return false;   // تغيّرت الهوية أثناء الانتظار في الطابور/القفل: لا طلب شبكة أصلًا
      const cur = store.get();
      if (!valid(cur) || !refreshUsable(cur)) { notifyLost('expired', e0); throw new ApiError('auth', { code: 'session_expired', message: 'session expired' }); }
      let out;
      try {
        out = await send('POST', REFRESH_PATH, cookieMode ? { cookie: true } : { body: { refreshToken: cur.refreshToken } });
      } catch (e) {
        // الخادم رفض رمز التجديد (غير صالح/منتهٍ/مُعاد استعماله/حساب موقوف): انتهت الجلسة نهائيًا.
        if (e instanceof ApiError && e.kind === 'http' && (e.status === 401 || e.status === 400)) { notifyLost('refresh_rejected', e0); throw new ApiError('auth', { status: 401, code: 'session_expired', message: 'session expired' }); }
        // شبكة/مهلة/429/5xx: الجلسة تبقى كما هي ويُعاد الخطأ كما هو (لا نُخرج المستخدم بسبب عطل عابر).
        throw e;
      }
      const next = out.data && out.data.session;
      if (!valid(next)) throw new ApiError('invalid_response', { status: out.status, message: 'invalid session in refresh response' });
      if (epoch !== e0) {
        // خرج المستخدم (أو دخل بحساب آخر) أثناء التجديد: لا نُحيي الجلسة القديمة. الخادم دوّر الرمز فجلسته حيّة هناك، فنُنهيها بأفضل جهد.
        await revokeBestEffort(next);
        return false;
      }
      store.set(sessionOnly(next));
      return true;
    }
    function sessionChanged() { return new ApiError('auth', { status: 401, code: 'session_changed', message: 'session changed' }); }

    const EXPIRED = {};
    /** يضمن رمز وصول صالحًا قبل الإرسال. يعيد الرمز، أو null (بلا جلسة)، أو EXPIRED (انتهت الجلسة محليًا الآن). */
    async function accessTokenForRequest(e0) {
      let s = store.get();
      if (!valid(s)) return null;
      if (!accessFresh(s)) {
        if (!refreshUsable(s)) { notifyLost('expired', e0); return EXPIRED; }
        if (!(await refreshSession()) || epoch !== e0) throw sessionChanged();
        s = store.get();
        if (!valid(s)) return null;
      }
      return s.accessToken;
    }

    /**
     * auth: 'required' (افتراضي: بلا جلسة → خطأ auth دون اتصال) | 'optional' (يرسل الرمز إن وُجد) | 'none' (لا يرسل رمزًا أبدًا).
     * opts: { query, body, timeoutMs, signal, auth }
     */
    async function request(method, path, opts) {
      opts = opts || {};
      const mode = opts.auth === undefined ? 'required' : opts.auth;
      if (mode !== 'required' && mode !== 'optional' && mode !== 'none') throw new ApiError('config', { code: 'invalid_auth_mode', message: 'invalid auth mode' });
      const base = { query: opts.query, body: opts.body, raw: opts.raw, rawType: opts.rawType, asBlob: opts.asBlob === true, timeoutMs: opts.timeoutMs, signal: opts.signal };
      if (mode === 'none') return (await send(method, path, base)).data;

      const e0 = epoch;
      let token = await accessTokenForRequest(e0);
      if (token === EXPIRED) {
        if (mode === 'required') throw new ApiError('auth', { status: 401, code: 'session_expired', message: 'session expired' });
        token = null;
      }
      if (!token && mode === 'required') throw new ApiError('auth', { status: 401, code: 'not_authenticated', message: 'not authenticated' });
      try {
        return (await send(method, path, Object.assign({}, base, { token: token }))).data;
      } catch (e) {
        if (!(e instanceof ApiError) || e.kind !== 'http' || e.status !== 401 || !token) throw e;
        // 401: الخادم لم ينفّذ الطلب، فإعادته مرة واحدة آمنة. إن كان غيرنا قد جدّد الرمز فنستعمل الجديد دون تجديد آخر.
        if (epoch !== e0) throw e; // الهوية تغيّرت (خروج/دخول جديد): لا نعيد الطلب باسم جلسة أخرى
        const cur = store.get();
        if (valid(cur) && cur.accessToken !== token) token = cur.accessToken;
        else { if (!(await refreshSession()) || epoch !== e0) throw e; const s2 = store.get(); token = valid(s2) ? s2.accessToken : null; }
        if (!token) throw e;
        try {
          return (await send(method, path, Object.assign({}, base, { token: token }))).data;
        } catch (e2) {
          if (e2 instanceof ApiError && e2.kind === 'http' && e2.status === 401) notifyLost('expired', e0);
          throw e2;
        }
      }
    }

    /** دخول/تسجيل: يُنفَّذ داخل القفل، وتُخزَّن الجلسة هنا. validate(data) اختياري؛ رفضه يُبطل الجلسة التي أنشأها الخادم ولا يُخزَّن شيء. */
    function authenticate(path, body, validate) {
      return guarded(async function () {
        const out = await send('POST', path, cookieMode ? { body: body, cookie: true } : { body: body });
        const data = out.data;
        const next = data && typeof data === 'object' ? data.session : null;
        if (!valid(next) || (typeof validate === 'function' && !validate(data))) {
          await revokeBestEffort(next && typeof next === 'object' ? next : null);   // الخادم أنشأ جلسة لا نقبلها: لا تبقى حيّة
          throw new ApiError('invalid_response', { status: out.status, message: 'invalid ' + (path === REGISTER_PATH ? 'register' : 'login') + ' response' });
        }
        epoch++;
        store.set(sessionOnly(next));
        return { user: data.user };
      });
    }

    return {
      request: request,
      get: function (path, opts) { return request('GET', path, opts); },
      post: function (path, body, opts) { return request('POST', path, Object.assign({}, opts, { body: body })); },
      put: function (path, body, opts) { return request('PUT', path, Object.assign({}, opts, { body: body })); },
      patch: function (path, body, opts) { return request('PATCH', path, Object.assign({}, opts, { body: body })); },
      delete: function (path, opts) { return request('DELETE', path, opts); },
      /** (11.7-D) رفع جسم خام: POST بنوع image/jpeg|png|webp. الاستجابة JSON كالمعتاد. */
      upload: function (path, blob, type, opts) { return request('POST', path, Object.assign({}, opts, { raw: blob, rawType: type })); },
      /** (11.7-D) GET يعيد Blob لصورة image/webp فقط (للمسارات المحمية بـ Bearer). */
      getBlob: function (path, opts) { return request('GET', path, Object.assign({}, opts, { asBlob: true })); },
      /** يخزّن جلسة حصلت عليها من الخادم. لا تُعاد الرموز لأي مستدعٍ. (وضع الملف: الجلسة بلا refreshToken.) */
      setSession: function (session) {
        if (!valid(session)) throw new ApiError('config', { code: 'invalid_session', message: 'invalid session' });
        epoch++;
        store.set(sessionOnly(session));
      },
      clearSession: function () { epoch++; store.clear(); },
      /**
       * (11.7.2.2) دخول: POST /v1/auth/login. يُنفَّذ داخل القفل (لا يتقاطع مع تجديد أو استعادة)، وتُخزَّن الجلسة هنا فلا يراها المستدعي.
       * validate(data) اختياري: إن أعاد false (مثلًا شكل المستخدم غير معروف) تُرفض النتيجة، ولا تبقى جلسة (تُبطَل في الخادم بأفضل جهد).
       * يعيد { user } أو يرمي ApiError. الدخول فعل صريح من المستخدم فهو يُنشئ هوية جديدة (epoch) ويُبطل أي عملية قديمة معلّقة.
       */
      login: function (body, validate) { return authenticate(LOGIN_PATH, body, validate); },
      /** (11.7.2.3) إنشاء حساب: العقد نفسه كالدخول (جلسة + ملف الارتباط عند نقل الملف). الجسم {name, phone, password} فقط. */
      register: function (body, validate) { return authenticate(REGISTER_PATH, body, validate); },
      /**
       * (11.7.2.2) استعادة الجلسة بعد إعادة تحميل الصفحة: تجديد واحد بملف الارتباط. لا شيء يُرسل في وضع الجسم (لا اعتماد دائم).
       * يعيد دائمًا (لا يرمي): { status: 'restored', user } | { status: 'none' } (لا ملف/منتهٍ/مرفوض: زائر) | { status: 'active' } (توجد جلسة أصلًا)
       *   | { status: 'superseded' } (دخل/خرج المستخدم أثناء الانتظار: لا تُطبَّق النتيجة) | { status: 'error', error } (شبكة/مهلة/5xx/429: الملف قد يبقى صالحًا).
       */
      restore: function () {
        if (!cookieMode) return Promise.resolve({ status: 'none' });
        const e0 = epoch;
        return guarded(async function () {
          if (valid(store.get())) return { status: 'active' };
          if (epoch !== e0) return { status: 'superseded' };
          let out;
          try {
            out = await send('POST', REFRESH_PATH, { cookie: true });
          } catch (e) {
            if (e instanceof ApiError && e.kind === 'http' && (e.status === 401 || e.status === 400)) return { status: 'none' };
            return { status: 'error', error: e instanceof ApiError ? e : new ApiError('network', { message: 'network error' }) };
          }
          const next = out.data && out.data.session;
          if (!valid(next)) { await revokeBestEffort(null); return { status: 'error', error: new ApiError('invalid_response', { status: out.status, message: 'invalid session in restore response' }) }; }
          if (epoch !== e0) { await revokeBestEffort(next); return { status: 'superseded' }; }
          epoch++;
          store.set(sessionOnly(next));
          return { status: 'restored', user: out.data.user };
        });
      },
      /**
       * خروج: تُمسح الجلسة محليًا أولًا (دائمًا)، ثم POST /v1/auth/logout لإبطال الجلسة في الخادم ومسح ملف الارتباط (يعيد 204 حتى لرمز مجهول).
       * ينتظر تجديدًا جاريًا كي يُبطل الرمز المُدوَّر الأحدث. لا يرمي: يعيد { hadSession, revoked, error? } (error: ApiError لتفسير الفشل للواجهة).
       * بلا جلسة: لا طلب (epoch فقط، فاستعادة جارية تُهمَل وتُبطَل).
       */
      logout: async function () {
        while (refreshing) { try { await refreshing; } catch (e) { /* فشل التجديد لا يمنع الخروج */ } }
        const s = store.get();
        epoch++;
        store.clear();
        if (!valid(s)) return { hadSession: false, revoked: false };
        try {
          await guarded(function () { return send('POST', LOGOUT_PATH, cookieMode ? { cookie: true } : { body: { refreshToken: s.refreshToken } }); });
          return { hadSession: true, revoked: true };
        } catch (e) {
          return { hadSession: true, revoked: false, error: e instanceof ApiError ? e : new ApiError('network', { message: 'network error' }) };
        }
      },
      hasSession: function () { return valid(store.get()); },
      get baseUrl() { return baseUrl; },
      get sessionTransport() { return cookieMode ? 'cookie' : 'body'; },
    };
  }

  /** عميل من إعداد الصفحة، أو null إن لم تُهيَّأ الخلفية (وضع التجربة المحلي: لا اتصال إطلاقًا). */
  function fromEnvironment(extra) {
    const raw = readConfiguredBaseUrl(extra);
    if (!raw) return null;
    return create(Object.assign({}, extra, { baseUrl: raw }));
  }
  function isConfigured(env) { return readConfiguredBaseUrl(env) !== ''; }

  return { create: create, fromEnvironment: fromEnvironment, isConfigured: isConfigured, normalizeBaseUrl: normalizeBaseUrl, readConfiguredBaseUrl: readConfiguredBaseUrl, ApiError: ApiError, DEFAULT_TIMEOUT_MS: DEFAULT_TIMEOUT_MS, REFRESH_SKEW_MS: REFRESH_SKEW_MS };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = ApiClient;

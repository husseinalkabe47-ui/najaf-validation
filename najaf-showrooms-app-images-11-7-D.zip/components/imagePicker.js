/* ImagePicker — عدّاد الصور + المعاينات + (تعيين رئيسية/حذف) + زر الإضافة.
   يعمل بوضعين عبر سياق واحد للشاشة الحالية (_imageCtx):
   - 'draft': سيارة لم تُنشأ بعد (صور مضغوطة في الذاكرة حتى الحفظ).
   - 'car'  : سيارة موجودة (كل إجراء يُطبَّق ويُحفظ فورًا عبر carImagesService).
   لا منطق صلاحيات/ضغط هنا: الشاشة تعرض فقط، والخدمات تقرّر وتتحقق. */
let _imageCtx = null;

function initImageCtxDraft(max) { _imageCtx = { mode: 'draft', draft: createImageDraft(max), max, busy: false, message: '' }; }
function initImageCtxCar(carId) { const car = getCarById(carId); _imageCtx = { mode: 'car', carId, max: getMaxImagesForCar(car), busy: false, message: '' }; }

function _imagePickerItems() {
  const c = _imageCtx;
  if (c.mode === 'draft') return c.draft.items.map((it, i) => ({ ref: i, src: it.previewUrl, isMain: it.isMain }));
  return getCarImages(c.carId).map(im => ({ ref: im.id, src: resolveImageSrc(im.imageUrl), isMain: im.isMain }));
}

function ImagePickerInner() {
  const c = _imageCtx;
  if (!c) return '';
  const items = _imagePickerItems();
  const atMax = items.length >= c.max;
  return `
    <div class="img-counter">الصور ${items.length} / ${c.max}</div>
    <div class="img-grid">${items.map((it, i) => `
      <div class="thumb ${it.isMain ? 'main' : ''}">
        ${it.isMain ? '<span class="thumb-badge">رئيسية</span>' : ''}
        <div class="thumb-img">${it.src ? `<img src="${esc(it.src)}" alt="صورة ${i + 1}${it.isMain ? ' (رئيسية)' : ''}" data-ph="🚘" onerror="imgFallback(this)">` : '<span aria-hidden="true">🚘</span>'}</div>
        <div class="thumb-actions">
          ${it.isMain ? '' : `<button type="button" aria-label="تعيين الصورة ${i + 1} كرئيسية" onclick="handleSetMainImage(${it.ref})">تعيين كرئيسية</button>`}
          <button type="button" class="danger" aria-label="حذف الصورة ${i + 1}" onclick="handleRemoveImage(${it.ref})">حذف</button>
        </div>
      </div>`).join('')}</div>
    ${c.message ? `<div class="form-error" role="alert">${esc(c.message)}</div>` : ''}
    ${c.busy ? '<div class="img-busy" role="status">جارٍ معالجة الصورة…</div>' : ''}
    ${atMax
      ? `<div class="img-max">${CarImagesService.MSG_MAX}</div>`
      : `<label class="img-add">+ إضافة صور<input id="imgFileInput" type="file" accept="image/*" multiple onchange="handlePickImages(this)"></label>`}`;
}
function ImagePickerHtml() { return `<div id="imagePicker" tabindex="-1">${ImagePickerInner()}</div>`; }
function refreshImagePicker() {
  const el = document.getElementById('imagePicker'); if (!el) return;
  // (الجزء 6.2-B) الأزرار تُستبدل مع كل تحديث: إن كان التركيز داخل المنتقي (حذف/تعيين رئيسية) يعود إلى بدايته بدل أن يضيع في الصفحة
  const had = typeof el.contains === 'function' && typeof document !== 'undefined' && !!document.activeElement && el.contains(document.activeElement);
  el.innerHTML = ImagePickerInner();
  if (had && typeof el.focus === 'function') el.focus({ preventScroll: true });
}

/* ==========================================================================
   (11.7-D) وضع الخادم: صور إعلان العضو (BackendImages). تُطبَّق كل إضافة/حذف فورًا على الخادم (لا «حفظ» منفصل للصور)،
   والقسم يُحدَّث وحده (لا يُعاد رسم النموذج فتضيع الحقول المكتوبة). صورة واحدة في كل اختيار، والقفل يمنع الرفع المكرر.
   ========================================================================== */
let _riCar = null, _riRoute = null, _riMsg = '';
function RemoteImagesInner() {
  const g = BackendImages.gallery(_riCar, refreshRemoteImages);
  if (g.status === 'idle' || g.status === 'loading') return '<div class="placeholder" role="status" aria-busy="true"><span class="ic" aria-hidden="true">⏳</span><b>جارٍ تحميل الصور…</b></div>';
  if (g.status === 'error') return `<div role="alert" class="form-error">${esc(g.error || BackendImages.messages.load)} <button type="button" class="link-btn" onclick="handleRemoteImagesRetry()">إعادة المحاولة</button></div>`;
  if (g.status === 'gone' || g.status === 'denied') return `<div role="alert" class="form-error">${esc(g.error)}</div>`;
  const grid = g.items.length ? `<div class="img-grid">${g.items.map((it, i) => `
      <div class="thumb ${it.isMain ? 'main' : ''}">
        ${it.isMain ? '<span class="thumb-badge">رئيسية</span>' : ''}
        <div class="thumb-img">${it.url ? `<img src="${esc(it.url)}" alt="صورة ${i + 1}${it.isMain ? ' (رئيسية)' : ''}" data-ph="🚘" onerror="imgFallback(this)">` : `<span aria-hidden="true">${it.loading ? '⏳' : '🚘'}</span>`}</div>
        <div class="thumb-actions"><button type="button" class="danger" aria-label="حذف الصورة ${i + 1}" ${g.busy ? 'disabled' : ''} onclick="handleRemoteImageRemove('${esc(it.id)}')">حذف</button></div>
      </div>`).join('')}</div>` : '<div class="sub" role="status">لا توجد صور بعد. أضف صور سيارتك لتظهر في الإعلان.</div>';
  return `
    <div class="img-counter">الصور ${g.items.length} / ${g.max}</div>
    ${grid}
    ${_riMsg ? `<div class="form-error" role="alert">${esc(_riMsg)}</div>` : ''}
    ${g.busy ? `<div class="img-busy" role="status">${esc(g.step || 'جارٍ المعالجة…')}</div>` : ''}
    ${g.full ? `<div class="img-max">${esc(BackendImages.messages.limit)}</div>` : ''}
    ${g.canAdd ? '<label class="img-add">+ إضافة صورة<input id="imgFileInput" type="file" accept="image/*" onchange="handleRemoteImagePick(this)"></label>' : ''}
    <div class="sub">تُحفظ الصور فور رفعها، وتبقى بعد الخروج من هذه الشاشة.</div>`;
}
function RemoteImagesHtml(carId, route) { _riCar = carId; _riRoute = route; _riMsg = ''; return `<div id="remoteImages" tabindex="-1">${RemoteImagesInner()}</div>`; }
function refreshRemoteImages() {
  if (currentRoute !== _riRoute) return;
  const el = document.getElementById('remoteImages'); if (!el) return;
  el.innerHTML = RemoteImagesInner();
}

/* (11.7-D) غلاف المعرض لصاحبه (BackendImages.cover): معاينة + اختيار/تغيير + حذف. القسم يتحدّث وحده. */
let _rcMsg = '';
function RemoteCoverInner() {
  const c = BackendImages.cover(refreshRemoteCover);
  if (c.status === 'idle' || c.status === 'loading') return '<div class="placeholder" role="status" aria-busy="true"><span class="ic" aria-hidden="true">⏳</span><b>جارٍ تحميل غلاف المعرض…</b></div>';
  if (c.status === 'error') return `<div role="alert" class="form-error">${esc(c.error || BackendImages.messages.load)} <button type="button" class="link-btn" onclick="handleRemoteCoverRetry()">إعادة المحاولة</button></div>`;
  if (c.status === 'denied') return `<div role="alert" class="form-error">${esc(c.error)}</div>`;
  const prev = c.cover ? (c.cover.url ? `<img src="${esc(c.cover.url)}" alt="غلاف المعرض" data-ph="🏢" onerror="imgFallback(this)">` : `<span class="img-ph" aria-hidden="true">${c.cover.loading ? '⏳' : '🏢'}</span>`) : SHOWROOM_PLACEHOLDER;
  return `
    <div class="detail-hero">${prev}</div>
    ${c.cover ? '' : '<div class="sub" role="status">لا يوجد غلاف للمعرض بعد.</div>'}
    ${_rcMsg ? `<div class="form-error" role="alert">${esc(_rcMsg)}</div>` : ''}
    ${c.busy ? `<div class="img-busy" role="status">${esc(c.step || 'جارٍ المعالجة…')}</div>` : `
    <label class="img-add">${c.cover ? 'تغيير الغلاف' : '+ اختيار غلاف'}<input id="coverFileInput" type="file" accept="image/*" onchange="handleRemoteCoverPick(this)"></label>
    ${c.cover ? '<button type="button" class="link-btn danger" onclick="handleRemoteCoverClear()">حذف الغلاف</button>' : ''}`}`;
}
function RemoteCoverHtml() { _rcMsg = ''; return `<div id="remoteCover" tabindex="-1">${RemoteCoverInner()}</div>`; }
function refreshRemoteCover() {
  if (currentRoute !== 'dealerHome') return;
  const el = document.getElementById('remoteCover'); if (!el) return;
  el.innerHTML = RemoteCoverInner();
}

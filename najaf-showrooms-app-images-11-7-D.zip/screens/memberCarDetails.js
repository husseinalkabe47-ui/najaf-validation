/* MemberCarDetailsScreen — تفاصيل سيارة عضو. أزرار الإدارة (تعديل/حذف/تغيير الحالة) تظهر فقط
   لمالك الإعلان أو المدير، والتحقق الفعلي عبر authorizationService (والراوتر يمنع الوصول أيضًا). */
function MemberCarDetailsScreen(id) {
  if (BackendMember.isEnabled()) return _OwnMemberCarDetailsRemote(String(id));   // 11.7-B: وضع الخادم
  const access = getMemberCarAccess(id);   // المسار العام: ok | hidden (غير نشط لغير مالكه/المدير) | missing (حتى لو كان المعرّف لسيارة معرض)
  if (access.status === 'missing') return `${DetailBackButton('memberCars', true)}${EmptyState({ icon: '🚘', heading: true, title: 'الإعلان غير موجود', actions: [{ label: 'سيارات الأعضاء', onclick: "go('memberCars')" }] })}`;
  if (access.status === 'hidden') return `${DetailBackButton('memberCars', true)}${EmptyState({ icon: '🚘', heading: true, title: 'هذا الإعلان غير متاح حاليًا', actions: [{ label: 'سيارات الأعضاء', onclick: "go('memberCars')" }] })}`;
  const c = access.car;
  const owner = UserService.getPublicById(c.ownerId); // اسم فقط، بلا أي بيانات حساسة
  const canManage = AuthorizationService.canManageMemberCar(undefined, c);
  const ownerName = owner ? plainText(owner.name) : '', postedDate = createdDateText(c.createdAt), loc = plainText(c.location);
  const ownerBlock = (ownerName || postedDate) ? `
    <div class="info-block">
      <h3>🧑 صاحب الإعلان</h3>
      ${ownerName ? `<div class="info-row strong">${esc(ownerName)}</div>` : ''}
      ${postedDate ? `<div class="info-row">🗓️ تاريخ النشر: ${esc(postedDate)}</div>` : ''}
    </div>` : '';
  return `
  ${DetailBackButton('memberCars')}
  <div class="detail-hero">${CarImageInner(c)}</div>
  ${CarImageStrip(c)}
  <div class="detail-body">
    ${DetailIdentity(c, sourceBadge('member'))}
    ${DetailPrice(c)}
    ${DetailStatusRow(memberCarStatusBadge(c.status))}
    ${DetailSpecs(CarCoreSpecs(c).concat([['الموقع', loc ? '📍 ' + esc(loc) : '']]))}
    ${DetailDescription(c)}
    ${ownerBlock}
    ${AdSlot('member_car_details')}
    ${ContactButtons({ phone: c.phone, whatsapp: c.whatsapp, lat: c.latitude, lng: c.longitude })}
    <button class="action-btn" style="width:100%;margin-top:10px;" onclick="handleShareMemberCar(${c.id})">🔗 مشاركة</button>
    ${canManage ? `
    <div class="owner-actions">
      <button onclick="go('editMemberCar', ${c.id})">✏️ تعديل الإعلان</button>
      <button onclick="handleMemberCarStatusChange(${c.id})">🔄 تغيير الحالة</button>
      <button class="danger" onclick="handleDeleteMemberCar(${c.id})">🗑️ حذف الإعلان</button>
    </div>` : ''}
  </div>`;
}

/* (11.7-B) وضع الخادم: إعلان المستخدم نفسه (GET /v1/me/cars/:id) بحالته وسببها وأزرار إدارته. الإعلانات العامة لغيره تفتح carDetails. */
function _OwnMemberCarDetailsRemote(id) {
  let st = BackendMember.car();
  if (st.id !== id || st.status === 'idle') { BackendMember.loadCar(id, _rerenderIf('memberCarDetails')); st = BackendMember.car(); }
  const back = DetailBackButton('myMemberCars', true);
  if (st.status !== 'ready' || st.id !== id) {
    return back + RemoteState(st.status === 'idle' ? { status: 'loading' } : st, { loading: 'جارٍ تحميل الإعلان…',
      retry: "BackendMember.loadCar(currentParam, _rerenderIf('memberCarDetails'));render()",
      empty: { icon: '🚘', title: 'الإعلان غير موجود أو لم يعد لك.', heading: true, actions: [{ label: 'سياراتي', onclick: "go('myMemberCars')" }] } });
  }
  const c = st.car, loc = plainText(c.location), rid = "'" + c.id + "'";
  const gal = RemoteCarGallery(BackendImages.gallery(c.id, _rerenderIf('memberCarDetails'), true), carTitle(c), "BackendImages.retryGallery(currentParam, _rerenderIf('memberCarDetails'));render()");   // 11.7-D
  return `
  ${DetailBackButton('myMemberCars')}
  <div class="detail-hero">${gal.hero}</div>
  ${gal.strip}
  <div class="detail-body">
    ${DetailIdentity(c, sourceBadge('member'))}
    ${DetailPrice(c)}
    ${DetailStatusRow(memberCarStatusBadge(c.status))}
    ${OwnAdReason(c)}
    ${DetailSpecs(CarCoreSpecs(c).concat([['الموقع', loc ? '📍 ' + esc(loc) : '']]))}
    ${DetailDescription(c)}
    ${ContactButtons({ phone: c.phone, whatsapp: c.whatsapp, lat: c.latitude, lng: c.longitude })}
    <div class="owner-actions">
      <button onclick="go('editMemberCar', ${rid})">✏️ تعديل الإعلان</button>
      ${OwnAdSoldButton(c)}
      <button class="danger" onclick="handleDeleteMemberCar(${rid})">🗑️ حذف الإعلان</button>
    </div>
  </div>`;
}

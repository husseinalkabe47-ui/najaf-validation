-- Creates (or refreshes) the dedicated MIGRATION account. It is NOT the application account:
--   * najaf_app_login (runtime)  : least privilege, member of najaf_app; the backend refuses to start with anything more.
--   * najaf_migrator  (this one) : owns the database objects so migrations can create/alter/drop them. It has CREATEROLE
--                                  only because migration 0012 creates the cluster roles najaf_app / najaf_report on first apply.
--                                  It is not a superuser and must never be a member of najaf_app (the runner checks this).
--
-- Run as an administrator, once per database. The password never appears in this file:
--   psql -v ON_ERROR_STOP=1 -d najaf -v login=najaf_migrator -v pw="$NAJAF_MIGRATOR_PASSWORD" -f backend/ops/create_migration_role.sql
--
-- IMPORTANT: this makes the account the OWNER of the database (required for CREATE EXTENSION / CREATE SCHEMA ops / DDL in public).
\set ON_ERROR_STOP on

SELECT format('CREATE ROLE %I LOGIN PASSWORD %L NOSUPERUSER CREATEROLE NOCREATEDB NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 5', :'login', :'pw')
 WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'login') \gexec

-- Already exists: rotate the password and re-assert the restrictions.
SELECT format('ALTER ROLE %I LOGIN PASSWORD %L NOSUPERUSER CREATEROLE NOCREATEDB NOREPLICATION NOBYPASSRLS', :'login', :'pw')
 WHERE EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'login') \gexec

SELECT format('ALTER DATABASE %I OWNER TO %I', current_database(), :'login') \gexec

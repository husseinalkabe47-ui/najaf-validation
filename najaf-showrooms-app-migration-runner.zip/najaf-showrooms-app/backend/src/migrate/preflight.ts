// Pre-flight check run before any migration: the connection must be the migration account, not the application role.
import { isDriverError, mapDriverError } from '../errors.ts';
import type { MigrationClientConfig, MigrationConfig } from './config.ts';
import { APP_ROLE } from '../schema-contract.ts';

export interface MigrationRoleReport {
  currentUser: string;
  isSuperuser: boolean;
  canCreateRole: boolean;
  isAppMember: boolean;
  serverVersionNum: number;
}

// The CASE keeps the query valid on a database where najaf_app does not exist yet (first apply creates it).
export const MIGRATION_ROLE_QUERY = `
SELECT current_user::text AS cur_user,
       r.rolsuper AS is_super,
       r.rolcreaterole AS can_create_role,
       CASE WHEN EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${APP_ROLE}')
            THEN pg_has_role(current_user, '${APP_ROLE}', 'member') ELSE false END AS is_app_member,
       current_setting('server_version_num')::int AS server_version_num
  FROM pg_roles r
 WHERE r.rolname = current_user`;

export function parseMigrationRoleRow(row: Record<string, unknown> | undefined): MigrationRoleReport {
  if (!row) throw new Error('migration role query returned no row');
  return {
    currentUser: String(row['cur_user']),
    isSuperuser: row['is_super'] === true,
    canCreateRole: row['can_create_role'] === true,
    isAppMember: row['is_app_member'] === true,
    serverVersionNum: Number(row['server_version_num']),
  };
}

// A superuser is implicitly a member of every role, so membership only counts against non-superusers.
export function migrationRoleViolations(r: MigrationRoleReport, minServerVersionNum = 160000): string[] {
  const v: string[] = [];
  if (r.isAppMember && !r.isSuperuser) v.push(`role "${r.currentUser}" is a member of ${APP_ROLE}: the migration account must not be an application identity`);
  if (r.serverVersionNum < minServerVersionNum) v.push(`PostgreSQL ${r.serverVersionNum} is older than the supported 16`);
  return v;
}

export class MigrationRoleError extends Error {
  readonly violations: string[];
  constructor(violations: string[]) {
    super(`Migration account policy violated:\n- ${violations.join('\n- ')}`);
    this.name = 'MigrationRoleError';
    this.violations = violations;
  }
}

export interface PgClientLike {
  connect(): Promise<void>;
  query(text: string, values?: unknown[]): Promise<{ rows: Array<Record<string, unknown>> }>;
  end(): Promise<void>;
}
export type ClientFactory = (cfg: MigrationClientConfig) => Promise<PgClientLike>;

type ClientCtor = new (options: Record<string, unknown>) => PgClientLike;
export interface PgClientModuleLike {
  default?: { Client: ClientCtor };
  Client?: ClientCtor;
}

export function createClientFactory(importPg: () => Promise<PgClientModuleLike> = () => import('pg') as unknown as Promise<PgClientModuleLike>): ClientFactory {
  return async (cfg) => {
    const mod = await importPg();
    const Client = mod.default?.Client ?? mod.Client;
    if (!Client) throw new Error('the "pg" package does not expose a Client class');
    return new Client({ ...cfg });
  };
}
export const defaultClientFactory: ClientFactory = createClientFactory();

/** Connects with the migration account, reads its role attributes, always closes the connection. */
export async function preflightMigrationRole(client: MigrationClientConfig, deps: { clientFactory?: ClientFactory } = {}): Promise<MigrationRoleReport> {
  const c = await (deps.clientFactory ?? defaultClientFactory)(client);
  try {
    await c.connect();
    const r = await c.query(MIGRATION_ROLE_QUERY);
    return parseMigrationRoleRow(r.rows[0]);
  } catch (e) {
    throw isDriverError(e) ? mapDriverError(e) : e;
  } finally {
    await c.end().catch(() => undefined);
  }
}

export async function assertMigrationRole(cfg: MigrationConfig, deps: { clientFactory?: ClientFactory } = {}): Promise<MigrationRoleReport> {
  const report = await preflightMigrationRole(cfg.client, deps);
  const v = migrationRoleViolations(report);
  if (v.length > 0) throw new MigrationRoleError(v);
  return report;
}

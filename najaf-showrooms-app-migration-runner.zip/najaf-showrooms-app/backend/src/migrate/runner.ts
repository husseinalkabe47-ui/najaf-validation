// Migration runner: a thin, testable wrapper around node-pg-migrate (pinned to 9.0.0 in package.json).
// It applies the validated, unmodified database/migrations SQL through the wrappers in db/migrations and rolls back
// with db/down. Tracking lives in ops.pgmigrations. node-pg-migrate is imported lazily and can be injected in tests.
import { basename } from 'node:path';
import { createRequire } from 'node:module';
import { isDriverError, mapDriverError } from '../errors.ts';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import type { MigrationClientConfig, MigrationConfig } from './config.ts';
import { defaultClientFactory } from './preflight.ts';
import type { ClientFactory } from './preflight.ts';
import { MIGRATIONS_DIR, TRACKING_SCHEMA, TRACKING_TABLE, listMigrationNames } from './paths.ts';

export interface RunnerOptions {
  databaseUrl: MigrationClientConfig;
  dir: string;
  direction: 'up' | 'down';
  count?: number;
  migrationsTable: string;
  migrationsSchema: string;
  createMigrationsSchema: boolean;
  singleTransaction: boolean;
  log: (msg: string) => void;
}
export type RunnerFn = (options: RunnerOptions) => Promise<Array<{ name?: string; path?: string }>>;

interface ToolModuleLike {
  runner?: RunnerFn;
  default?: { runner?: RunnerFn };
}

export async function defaultRunnerFn(): Promise<RunnerFn> {
  let mod: ToolModuleLike;
  try {
    mod = (await import('node-pg-migrate')) as unknown as ToolModuleLike;
  } catch {
    // CommonJS-only builds are loaded through require.
    mod = createRequire(import.meta.url)('node-pg-migrate') as ToolModuleLike;
  }
  const fn = mod.runner ?? mod.default?.runner;
  if (typeof fn !== 'function') throw new Error('node-pg-migrate does not export runner()');
  return fn;
}

export type MigrationErrorCode = 'bad_request' | 'rollback_disabled' | 'runner_failed';
export class MigrationError extends Error {
  readonly code: MigrationErrorCode;
  constructor(code: MigrationErrorCode, message: string) {
    super(message);
    this.name = 'MigrationError';
    this.code = code;
  }
}

export type Command = { kind: 'up' } | { kind: 'down'; steps: number | 'all' } | { kind: 'status' };

export const USAGE = 'usage: migrate.ts up | down (--steps N | --all) | status';

export function parseMigrateArgs(argv: readonly string[]): Command {
  const [cmd, ...rest] = argv;
  if (cmd === 'up' || cmd === 'status') {
    if (rest.length > 0) throw new MigrationError('bad_request', `${cmd} takes no arguments. ${USAGE}`);
    return { kind: cmd };
  }
  if (cmd === 'down') {
    if (rest.length === 1 && rest[0] === '--all') return { kind: 'down', steps: 'all' };
    if (rest.length === 2 && rest[0] === '--steps' && /^[1-9]\d{0,2}$/.test(rest[1] ?? '')) return { kind: 'down', steps: Number(rest[1]) };
    throw new MigrationError('bad_request', `down needs exactly one of --steps N or --all (no implicit default). ${USAGE}`);
  }
  throw new MigrationError('bad_request', USAGE);
}

export function buildRunnerOptions(
  cfg: MigrationConfig,
  req: { direction: 'up' | 'down'; steps: number | 'all' | undefined },
  log: (msg: string) => void,
  dir: string = MIGRATIONS_DIR,
): RunnerOptions {
  const options: RunnerOptions = {
    databaseUrl: cfg.client,
    dir,
    direction: req.direction,
    migrationsTable: TRACKING_TABLE,
    migrationsSchema: TRACKING_SCHEMA,
    createMigrationsSchema: true,
    singleTransaction: cfg.singleTransaction,
    log,
  };
  if (req.direction === 'down') {
    const total = listMigrationNames(dir).length;
    const count = req.steps === 'all' ? total : req.steps;
    if (count === undefined || !Number.isInteger(count) || count < 1) throw new MigrationError('bad_request', 'down needs a positive number of steps');
    if (count > total) throw new MigrationError('bad_request', `cannot roll back ${count} steps: only ${total} migrations exist`);
    options.count = count;
  }
  return options;
}

function sanitize(message: string, secret: string): string {
  const cleaned = secret === '' ? message : message.split(secret).join('***');
  return cleaned.replace(/\s+/g, ' ').slice(0, 500);
}

export interface MigrationResult {
  direction: 'up' | 'down';
  ran: string[];
}

export async function runMigrations(
  cfg: MigrationConfig,
  req: { direction: 'up' | 'down'; steps?: number | 'all' },
  deps: { runnerFn?: RunnerFn; logger?: Logger; dir?: string } = {},
): Promise<MigrationResult> {
  const logger = deps.logger ?? nullLogger;
  if (req.direction === 'down' && cfg.env === 'production' && !cfg.allowRollback) {
    throw new MigrationError('rollback_disabled', 'rollback is disabled in production (set MIGRATION_ALLOW_ROLLBACK=true to allow it explicitly)');
  }
  const options = buildRunnerOptions(cfg, { direction: req.direction, steps: req.steps }, (m) => logger.info({ migration: m }, 'node-pg-migrate'), deps.dir);
  const runnerFn = deps.runnerFn ?? (await defaultRunnerFn());
  try {
    const ran = await runnerFn(options);
    return { direction: req.direction, ran: ran.map((m) => m.name ?? (m.path ? basename(m.path).replace(/\.(js|cjs|mjs|sql)$/, '') : String(m))) };
  } catch (e) {
    if (isDriverError(e)) throw mapDriverError(e);
    throw new MigrationError('runner_failed', sanitize(e instanceof Error ? e.message : String(e), cfg.client.password));
  }
}

export interface MigrationStatus {
  applied: string[];
  pending: string[];
  /** Tracked in the database but no longer present in db/migrations. */
  unknown: string[];
}

export async function migrationStatus(
  cfg: MigrationConfig,
  deps: { clientFactory?: ClientFactory; dir?: string } = {},
): Promise<MigrationStatus> {
  const known = listMigrationNames(deps.dir);
  const client = await (deps.clientFactory ?? defaultClientFactory)(cfg.client);
  let applied: string[] = [];
  try {
    await client.connect();
    try {
      const r = await client.query(`SELECT name FROM ${TRACKING_SCHEMA}.${TRACKING_TABLE} ORDER BY id`);
      applied = r.rows.map((row) => String(row['name']));
    } catch (e) {
      // 42P01 (undefined_table) / 3F000 (invalid_schema_name): nothing has been applied yet.
      const code = (e as { code?: unknown }).code;
      if (code !== '42P01' && code !== '3F000') throw isDriverError(e) ? mapDriverError(e) : e;
    }
  } finally {
    await client.end().catch(() => undefined);
  }
  return {
    applied,
    pending: known.filter((n) => !applied.includes(n)),
    unknown: applied.filter((n) => !known.includes(n)),
  };
}

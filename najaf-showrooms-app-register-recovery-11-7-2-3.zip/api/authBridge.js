/* ==========================================================================
   BACKEND AUTH — جسر المصادقة الحقيقية (المرحلة 11.7.2.1)
   يربط تسجيل الدخول والخروج بالخادم عبر ApiClient وفق العقد الموجود (backend/src/auth/routes.ts):
     POST /v1/auth/login  { phone, password } → 200 { user, session }
     POST /v1/auth/logout { refreshToken }     → 204
   (التجديد عند انتهاء رمز الوصول يتم داخل ApiClient بعقد POST /v1/auth/refresh نفسه.)

   الوضعان (يُحدَّدان عند التشغيل من وسم <meta name="najaf-api-base-url">، انظر api/README.md):
     • العنوان فارغ (الافتراضي) = وضع التجربة المحلي: لا يُنشئ هذا الملف أي عميل ولا يتصل بشيء، والتطبيق يعمل كما كان.
     • العنوان مضبوط = وضع الخادم: الدخول والخروج من الخادم فقط. لا رجوع إلى الحسابات التجريبية المحلية، ولا تُقرأ
       الجلسة المحلية القديمة ولا تُكتب جلسة محلية. بيانات السيارات/المعارض/المفضلة ما زالت محلية تجريبية (لم تُربط بعد).

   (11.7.2.3) التسجيل واستعادة كلمة المرور — بالعقد الموجود فقط:
     POST /v1/auth/register        { name, phone, password }       → 201 { user, session }  (الدور «مستخدم» دائمًا من الخادم؛ لا يُرسل العميل دورًا أبدًا)
     POST /v1/auth/password/forgot { phone }                        → 202 { status:'accepted' } | 503 delivery_unavailable (لا مزوّد رسائل مُفعَّل)
     POST /v1/auth/password/reset  { phone, code, newPassword }     → 200 { status:'password_reset' } | 400 invalid_code
   التسجيل يمرّ بنقل الملف نفسه وبقفل الجلسة نفسه (فلا يظهر رمز تجديد لـ JavaScript). حساب صاحب المعرض وإدارته خارج هذه الخطوة.
   الاستعادة لا تعمل فعليًا حتى يُربط مزوّد SMS/واتساب في الخلفية (انظر api/README.md)؛ الواجهة لا تدّعي إرسالًا لم يتم.

   (11.7.2.2) استعادة الجلسة بعد إعادة التحميل — فقط عند <meta name="najaf-session-transport" content="cookie"> وخلفية مفعّلة بـ AUTH_COOKIE_ORIGINS:
     • رمز التجديد في ملف ارتباط HttpOnly يضعه الخادم (لا يراه JavaScript إطلاقًا)؛ restore() تجدّد مرة واحدة عند الإقلاع فيعود المستخدم.
     • «تلميح» بوليانيّ فقط (AuthHint في storage/localStorageAdapter.js، المفتاح najaf-auth-hint = 1) كي لا يطلب الزوّار تجديدًا عند كل فتح. ليس اعتمادًا ولا يحوي رمزًا،
       ولا يُصدَّق: الخادم وحده يقرّر. غيابه (وتخزين يعمل) = لا محاولة. تعذّر التخزين = تجربة الاستعادة دائمًا.
     • عدّاد gen: دخول/خروج/فقدان جلسة أثناء الاستعادة يُلغي نتيجتها (لا تُحيا جلسة خرج منها المستخدم ولا تستبدل جلسة جديدة).

   الأمان:
     • الرموز تبقى داخل ApiClient في الذاكرة فقط؛ هذا الملف لا يراها ولا يخزّنها ولا يسجّلها.
     • كلمة المرور تُمرَّر لطلب الدخول فقط، ولا تُخزَّن ولا تُسجَّل ولا تبقى في أي متغير بعد الطلب.
     • هذا الملف لا يذكر التخزين إطلاقًا؛ التلميح البوليانيّ أعلاه يمرّ عبر محوّل التخزين وحده. وبلا وضع الملف (الافتراضي القديم) إعادة التحميل تُنهي الجلسة (api/README.md).
     • مستخدم الخادم يحمل معرّفًا ببادئة «srv:» كي لا يتطابق أبدًا مع معرّف مستخدم تجريبي محلي (فلا يرث ملكية بيانات تجريبية).
   ========================================================================== */
const BackendAuth = (function () {
  const MSG = {
    badInput: 'أدخل رقم الهاتف وكلمة المرور.',
    badPhone: 'رقم الهاتف غير صحيح. مثال: 07701234567',
    email: 'تسجيل الدخول عبر الخادم يتم برقم الهاتف فقط.',
    credentials: 'بيانات الدخول غير صحيحة.',
    validation: 'تحقق من رقم الهاتف وكلمة المرور.',
    network: 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.',
    timeout: 'انتهت مهلة الاتصال بالخادم. حاول مرة أخرى.',
    server: 'حدث خطأ في الخادم. حاول لاحقًا.',
    invalid: 'ردّ الخادم غير صالح. حاول لاحقًا.',
    config: 'إعداد الاتصال بالخادم غير صحيح.',
    expired: 'انتهت الجلسة. سجّل الدخول من جديد.',
    busy: 'جارٍ تسجيل الدخول…',
    register: 'إنشاء الحساب عبر الخادم سيتوفر في خطوة لاحقة.',
    generic: 'تعذّر تسجيل الدخول. حاول مرة أخرى.',
    nameShort: 'الاسم يجب ألا يقل عن 3 أحرف.',
    nameLong: 'الاسم طويل جدًا (الحد الأقصى 100 حرف).',
    nameBad: 'الاسم يحوي رموزًا غير مسموحة.',
    passwordShort: 'كلمة المرور يجب ألا تقل عن 6 أحرف.',
    passwordLong: 'كلمة المرور طويلة جدًا (الحد الأقصى 128 حرفًا).',
    passwordBad: 'كلمة المرور تحوي رموزًا غير مسموحة.',
    mismatch: 'كلمتا المرور غير متطابقتين.',
    registerConflict: 'تعذّر إنشاء الحساب بهذه البيانات. إن كان لديك حساب فسجّل الدخول.',
    dealerLater: 'إنشاء حساب صاحب معرض عبر الخادم سيتوفر في خطوة لاحقة.',
    recoveryUnavailable: 'استعادة كلمة المرور غير متاحة الآن: خدمة إرسال الرموز (SMS/واتساب) لم تُفعَّل على الخادم بعد. تواصل مع الدعم.',
    recoverySent: 'إن كان الرقم مسجّلًا لدينا فسيصلك رمز تحقق خلال دقائق. أدخله مع كلمة المرور الجديدة.',
    invalidCode: 'الرمز غير صحيح أو منتهي الصلاحية. اطلب رمزًا جديدًا إن لزم.',
    codeFormat: 'الرمز مكوّن من 6 أرقام.',
    resetDone: 'تم تغيير كلمة المرور. سجّل الدخول بكلمة المرور الجديدة.',
    restoreFailed: 'تعذّر استعادة جلستك الآن. تحقق من الاتصال أو سجّل الدخول من جديد.',
  };
  let enabled = false;
  let misconfigured = false;
  let client = null;
  let user = null;
  let busy = false;
  let recoveryBusy = false;
  let lostListener = null;
  let gen = 0;            // يزيد عند أي تغيير لهوية الواجهة (دخول/خروج/فقدان): نتيجة استعادة قديمة لا تُطبَّق
  let restoring = null;
  let hint = null;        // { get(): '1'|null|'unavailable', set(), clear() } — تلميح بوليانيّ فقط، لا رموز

  function defaultHint() { return typeof AuthHint !== 'undefined' ? AuthHint : null; }   // يعرّفه محوّل التخزين (الملف الوحيد الذي يلمس التخزين)
  function hintSet() { if (hint) hint.set(); }
  function hintClear() { if (hint) hint.clear(); }

  /** الخادم فقد الجلسة نهائيًا (تجديد مرفوض/منتهٍ): تُمسح الحالة هنا أولًا ثم يُبلَّغ مستمع الواجهة. */
  function handleLost(reason) {
    user = null; gen++; hintClear();
    if (lostListener) { try { lostListener(reason); } catch (e) { /* مستمع الواجهة لا يكسر العميل */ } }
  }

  /**
   * يُستدعى عند التشغيل. opts (للاختبار): baseUrl وخيارات ApiClient.create (fetch، now، ...). بلا opts يُقرأ العنوان من الصفحة.
   * يعيد true إن كان وضع الخادم مفعّلًا. عنوان مضبوط لكنه غير صالح = وضع الخادم «معطّل الإعداد» (الدخول يفشل برسالة، ولا رجوع للوضع المحلي).
   */
  function init(opts) {
    opts = opts || {};
    enabled = false; misconfigured = false; client = null; user = null; busy = false; recoveryBusy = false; gen++; restoring = null; hint = null;
    let raw = '';
    try { raw = opts.baseUrl !== undefined ? String(opts.baseUrl || '').trim() : ApiClient.readConfiguredBaseUrl(); } catch (e) { raw = ''; }
    if (!raw) return false;
    enabled = true;
    let transport = opts.sessionTransport;
    if (transport === undefined) {
      try { const m = typeof document !== 'undefined' && document.querySelector ? document.querySelector('meta[name="najaf-session-transport"]') : null; transport = m && typeof m.content === 'string' ? m.content.trim() : ''; } catch (e) { transport = ''; }
    }
    transport = transport === 'cookie' ? 'cookie' : 'body';
    try { client = ApiClient.create(Object.assign({}, opts, { baseUrl: raw, sessionTransport: transport, onAuthLost: handleLost })); } catch (e) { misconfigured = true; }
    if (client && transport === 'cookie') hint = opts.hint !== undefined ? opts.hint : defaultHint();
    return true;
  }

  /** أخطاء الحقول من الخادم (رمز آلي فقط، بلا قيم) → رسالة عربية. تُستعمل احتياطًا؛ العميل يتحقق أولًا. */
  function fieldMessage(fields) {
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i] || {};
      if (f.field === 'name') return f.code === 'too_long' ? MSG.nameLong : f.code === 'invalid_format' ? MSG.nameBad : MSG.nameShort;
      if (f.field === 'phone') return MSG.badPhone;
      if (f.field === 'password' || f.field === 'newPassword') return f.code === 'too_long' ? MSG.passwordLong : f.code === 'invalid_format' ? MSG.passwordBad : MSG.passwordShort;
      if (f.field === 'code') return MSG.codeFormat;
    }
    return null;
  }

  function messageFor(err, context) {
    if (!err || err.name !== 'ApiError') return MSG.generic;
    if (err.kind === 'network') return MSG.network;
    if (err.kind === 'timeout') return MSG.timeout;
    if (err.kind === 'aborted') return 'أُلغي الطلب.';
    if (err.kind === 'config') return MSG.config;
    if (err.kind === 'invalid_response') return MSG.invalid;
    if (err.kind === 'auth') return MSG.expired;
    if (err.kind === 'http') {
      if (err.status === 401) return context === 'session' ? MSG.expired : MSG.credentials;
      if ((err.status === 400 && err.code === 'session_transport_unsupported') || (err.status === 403 && err.code === 'forbidden_origin')) return MSG.config;   // الخادم لا يقبل هذا النقل/الأصل: إعداد لا خطأ مستخدم
      if (err.status === 400 && err.code === 'invalid_code') return MSG.invalidCode;
      if (err.status === 400 && Array.isArray(err.fields)) { const m = fieldMessage(err.fields); if (m) return m; }
      if (err.status === 409 && context === 'register') return MSG.registerConflict;
      if (err.status === 503 && err.code === 'delivery_unavailable') return MSG.recoveryUnavailable;
      if (err.status === 400) return MSG.validation;
      if (err.status === 429) {
        const m = Number.isFinite(err.retryAfterSeconds) ? Math.max(1, Math.ceil(err.retryAfterSeconds / 60)) : 0;
        return 'محاولات كثيرة. ' + (m ? 'حاول بعد ' + m + ' دقيقة.' : 'انتظر قليلًا ثم حاول مرة أخرى.');
      }
      if (err.status >= 500) return MSG.server;
    }
    return MSG.generic;
  }

  /** مستخدم الخادم بالشكل الذي تفهمه الواجهة (نفس حقول UserService.toPublic). null إن كان الشكل أو الدور أو الحالة غير معروف. */
  function toLocalShape(u) {
    if (!u || typeof u !== 'object') return null;
    const roles = Object.keys(ROLES).map(function (k) { return ROLES[k]; });
    const statuses = Object.keys(USER_STATUS).map(function (k) { return USER_STATUS[k]; });
    if (typeof u.id !== 'string' || !/^[0-9]{1,20}$/.test(u.id)) return null;
    if (typeof u.name !== 'string' || !u.name || typeof u.phone !== 'string') return null;
    if (roles.indexOf(u.role) < 0 || statuses.indexOf(u.status) < 0) return null;
    return { id: 'srv:' + u.id, name: u.name, phone: normalizePhone(u.phone) || u.phone, email: null, role: u.role, status: u.status, createdAt: typeof u.createdAt === 'string' ? u.createdAt : null };
  }

  /** تسجيل الدخول. يعيد دائمًا { ok:true, user } أو { ok:false, error: نص عربي آمن }. لا يرمي. */
  async function login(identifier, password) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (busy) return { ok: false, error: MSG.busy };
    const id = String(identifier == null ? '' : identifier).trim();
    const pw = password == null ? '' : String(password);
    if (!id || !pw) return { ok: false, error: MSG.badInput };
    if (id.indexOf('@') >= 0) return { ok: false, error: MSG.email };       // العقد: الدخول بالهاتف فقط
    const phone = normalizePhone(id);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const tooLong = textLimitError({ password: pw }, ['password']);
    if (tooLong) return { ok: false, error: tooLong };
    busy = true;
    try {
      // الدخول والتخزين داخل العميل (تحت القفل): هنا نتحقق من شكل المستخدم فقط، فإن لم يُقبل لا تبقى جلسة.
      let mapped = null;
      await client.login({ phone: phone, password: pw }, function (data) { mapped = toLocalShape(data && data.user); return !!mapped; });
      user = mapped; gen++; hintSet();
      return { ok: true, user: Object.assign({}, mapped) };
    } catch (e) {
      client.clearSession();             // لا جلسة نصف مكتملة بعد أي فشل
      user = null; gen++;
      return { ok: false, error: messageFor(e, 'login') };
    } finally {
      busy = false;
    }
  }

  /**
   * تسجيل الخروج: حالة الواجهة تُمسح فورًا (متزامنًا)، ثم يُبطَل رمز الجلسة في الخادم.
   * الوعد لا يُرفض أبدًا: { hadSession, revoked, error? }. revoked=false مع hadSession=true = خرج المستخدم محليًا لكن تعذّر إبلاغ الخادم.
   */
  function logout() {
    user = null; gen++; hintClear();
    if (!client) return Promise.resolve({ hadSession: false, revoked: false });
    return client.logout().catch(function () { return { hadSession: true, revoked: false }; });
  }


  const cpLen = function (t) { return Array.from(t).length; };
  // eslint-disable-next-line no-control-regex
  const CONTROL = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;
  /** نفس قواعد الخادم (backend/src/auth/validation.ts) لتجنّب طلب شبكة محكوم عليه بالفشل. الخادم يبقى الحَكَم. */
  function checkNewPassword(pw) {
    if (typeof pw !== 'string' || pw === '') return MSG.badInput;
    if (pw.indexOf('\u0000') >= 0) return MSG.passwordBad;
    const n = cpLen(pw);
    if (n > 128) return MSG.passwordLong;
    if (n < 6) return MSG.passwordShort;
    return null;
  }

  /**
   * (11.7.2.3) إنشاء حساب عبر الخادم. الجسم المُرسَل {name, phone, password} فقط: لا دور ولا حالة ولا نوع حساب ولا بريد (الخادم يرفض أي حقل آخر).
   * يعيد { ok:true, user } (المستخدم مسجَّل الدخول بجلسته) أو { ok:false, error }. لا يرمي.
   */
  async function register(input) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (busy) return { ok: false, error: MSG.busy };
    input = input || {};
    const name = String(input.name == null ? '' : input.name).normalize('NFC').trim();
    const pw = input.password == null ? '' : String(input.password);
    if (!name) return { ok: false, error: MSG.nameShort };
    if (CONTROL.test(name)) return { ok: false, error: MSG.nameBad };
    if (cpLen(name) < 3) return { ok: false, error: MSG.nameShort };
    if (cpLen(name) > 100) return { ok: false, error: MSG.nameLong };
    const phone = normalizePhone(input.phone);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const pwErr = checkNewPassword(pw);
    if (pwErr) return { ok: false, error: pwErr };
    if (input.confirmPassword !== undefined && String(input.confirmPassword) !== pw) return { ok: false, error: MSG.mismatch };
    busy = true;
    try {
      let mapped = null;
      await client.register({ name: name, phone: phone, password: pw }, function (data) { mapped = toLocalShape(data && data.user); return !!mapped; });
      user = mapped; gen++; hintSet();
      return { ok: true, user: Object.assign({}, mapped) };
    } catch (e) {
      client.clearSession();
      user = null; gen++;
      return { ok: false, error: messageFor(e, 'register') };
    } finally {
      busy = false;
    }
  }

  /** (11.7.2.3) طلب رمز استعادة: POST /v1/auth/password/forgot. الردّ المقبول متطابق لأي رقم (لا كشف لوجود حساب). { ok, error?, unavailable? } */
  async function requestRecovery(identifier) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (recoveryBusy) return { ok: false, error: MSG.busy };
    const raw = String(identifier == null ? '' : identifier).trim();
    if (!raw) return { ok: false, error: MSG.badInput };
    if (raw.indexOf('@') >= 0) return { ok: false, error: MSG.email };
    const phone = normalizePhone(raw);
    if (!phone) return { ok: false, error: MSG.badPhone };
    recoveryBusy = true;
    try {
      await client.post('/v1/auth/password/forgot', { phone: phone }, { auth: 'none' });
      return { ok: true, message: MSG.recoverySent, phone: phone };
    } catch (e) {
      return { ok: false, error: messageFor(e, 'recovery'), unavailable: !!(e && e.status === 503 && e.code === 'delivery_unavailable') };
    } finally {
      recoveryBusy = false;
    }
  }

  /** (11.7.2.3) إعادة التعيين: POST /v1/auth/password/reset. نجاحها يُنهي كل جلسات الحساب في الخادم، فنمسح حالتنا المحلية أيضًا. */
  async function completeRecovery(input) {
    if (!enabled) return { ok: false, error: MSG.generic };
    if (misconfigured || !client) return { ok: false, error: MSG.config };
    if (recoveryBusy) return { ok: false, error: MSG.busy };
    input = input || {};
    const phone = normalizePhone(input.phone);
    if (!phone) return { ok: false, error: MSG.badPhone };
    const code = String(input.code == null ? '' : input.code).trim().replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); });
    if (!/^[0-9]{6}$/.test(code)) return { ok: false, error: MSG.codeFormat };
    const pw = input.newPassword == null ? '' : String(input.newPassword);
    const pwErr = checkNewPassword(pw);
    if (pwErr) return { ok: false, error: pwErr };
    if (input.confirmPassword !== undefined && String(input.confirmPassword) !== pw) return { ok: false, error: MSG.mismatch };
    recoveryBusy = true;
    try {
      await client.post('/v1/auth/password/reset', { phone: phone, code: code, newPassword: pw }, { auth: 'none' });
      client.clearSession(); user = null; gen++; hintClear();   // كل الجلسات انتهت في الخادم
      return { ok: true, message: MSG.resetDone };
    } catch (e) {
      return { ok: false, error: messageFor(e, 'recovery') };
    } finally {
      recoveryBusy = false;
    }
  }

  /**
   * (11.7.2.2) استعادة الجلسة عند الإقلاع. لا تُنفَّذ إلا في وضع الملف. تعيد دائمًا (لا ترمي):
   *   { status: 'restored', user } | { status: 'none' } | { status: 'active' } | { status: 'superseded' } | { status: 'error', error: نص عربي }
   * استدعاءات متزامنة تشترك في وعد واحد (لا تجديد مكرّر).
   */
  function restore() {
    if (!enabled || misconfigured || !client || client.sessionTransport !== 'cookie') return Promise.resolve({ status: 'none' });
    if (user) return Promise.resolve({ status: 'active' });
    if (restoring) return restoring;
    if (hint && hint.get() === null) return Promise.resolve({ status: 'none' });   // لا تلميح (والتخزين يعمل): زائر، لا طلب
    const g0 = gen;
    restoring = (async function () {
      try {
        const r = await client.restore();
        if (r.status === 'restored') {
          const mapped = toLocalShape(r.user);
          if (gen !== g0 || !mapped) {
            // تغيّرت هوية الواجهة أثناء الانتظار، أو شكل المستخدم غير معروف: لا تُعرض هذه الجلسة، ونُنهيها في الخادم.
            await client.logout();
            return gen !== g0 ? { status: 'superseded' } : { status: 'error', error: MSG.invalid };
          }
          user = mapped; gen++; hintSet();
          return { status: 'restored', user: Object.assign({}, mapped) };
        }
        if (r.status === 'none') { if (gen === g0) hintClear(); return { status: 'none' }; }
        if (r.status === 'error') return { status: 'error', error: messageFor(r.error, 'session') === MSG.expired ? MSG.restoreFailed : messageFor(r.error, 'session') };
        return { status: r.status };
      } catch (e) {
        return { status: 'error', error: MSG.restoreFailed };
      } finally { restoring = null; }
    })();
    return restoring;
  }

  return {
    init: init,
    register: register,
    requestRecovery: requestRecovery,
    completeRecovery: completeRecovery,
    restore: restore,
    /** هل ستُجرَّب استعادة عند الإقلاع؟ (وضع الملف، ولا تلميح ينفيها) */
    canRestore: function () { return enabled && !misconfigured && !!client && client.sessionTransport === 'cookie' && !(hint && hint.get() === null); },
    isEnabled: function () { return enabled; },
    currentUser: function () { return user ? Object.assign({}, user) : null; },
    /** يمسح مستخدم الواجهة فقط (دون اتصال) — تستعمله SessionService.logout. */
    forgetUser: function () { user = null; },
    login: login,
    logout: logout,
    /** عميل الـAPI لخطوات لاحقة (لا يكشف الرموز). null في الوضع المحلي. */
    api: function () { return client; },
    onLost: function (fn) { lostListener = typeof fn === 'function' ? fn : null; },
    messageFor: messageFor,
    messages: MSG,
  };
})();

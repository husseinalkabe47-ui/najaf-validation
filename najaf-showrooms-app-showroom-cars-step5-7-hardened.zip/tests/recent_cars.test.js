/* اختبارات ميزة «السيارات المضافة حديثاً» (ميزة جديدة ج1): قسم في الرئيسية (6 بطاقات) + شاشة recentCars بالقائمة الكاملة.
   المصدر الوحيد: getRecentCars ← searchCars(query,'all',criteria) ← getPublicCars ← visibilityService، ثم ترتيب createdAt تنازليًا.
   «المضافة حديثًا» تصنيف زمني لا حالة. القياسات البصرية (320/360/390/412) في Chromium؛ هنا المنطق والبنية والسلامة.
   مراجع مستقلة: الترتيب من طوابع المخزَّن، والظهور من حالة المعرض/الحساب/الإعلان مباشرة، وسجلات مضبوطة بطوابع متباينة تُحقن عبر المستودعات. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 240)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const dec = s => s.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
const clone = o => JSON.parse(JSON.stringify(o));
const ID = { user: 7, dealer1: 1, dealer2: 2, dealer3: 3, dealer4: 4, admin: 6 };
const BAD = /undefined|NaN|\[object/, ERR = 'حدث خطأ، حاول مرة أخرى';
function view(who, store) {
  const E = makeEnv(store ? clone(store) : undefined, { fullSeed: 'p3' }), R = c => E.run(c);
  R('SessionService.logout()'); if (who) R(`SessionService.login(${ID[who]})`);
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
const world = fn => { const w = view('admin'); if (fn) fn(w); return clone(w.E.store); };
const setSh = (w, id, status) => w.R(`ShowroomsRepository.update(${id}, { status: ${JSON.stringify(status)} })`);
const mustExist = (w, repo, id, what) => { if (!(Number.isInteger(id)) || w.R(`${repo}.getById(${id}) === null || ${repo}.getById(${id}) === undefined`)) throw new Error(`${what} ${id} لم يُنشأ (توقيع خاطئ؟)`); };   // يمنع النجاح الفارغ
const addSh = (w, o) => { if (!o || typeof o !== 'object') throw new Error('addSh(w, { id, ... })'); w.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify(Object.assign({ status: 'active', ownerId: 1, createdAt: '2026-01-01T00:00:00', updatedAt: '2026-01-01T00:00:00' }, o))}))`); mustExist(w, 'ShowroomsRepository', o.id, 'showroom'); };
const addCar = (w, id, showroomId, createdAt, o = {}) => { w.R(`CarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'showroom', showroomId, brand: 'Zeekr', model: 'R' + id, year: 2024, price: 10000000, currency: 'IQD', mileage: 1000, status: 'available', createdAt, updatedAt: createdAt }, o))}))`); mustExist(w, 'CarsRepository', id, 'car'); };
const addMem = (w, id, ownerId, createdAt, o = {}) => { w.R(`MemberCarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'member', ownerId, brand: 'Zeekr', model: 'M' + id, year: 2024, price: 9000000, currency: 'IQD', mileage: 2000, status: 'active', phone: '07700000001', whatsapp: '9647700000001', location: 'حي النصر، النجف', createdAt, updatedAt: createdAt }, o))}))`); mustExist(w, 'MemberCarsRepository', id, 'member car'); };
const cardIds = html => [...String(html).matchAll(/class="card car-card"[\s\S]*?go\('(?:memberCarDetails|carDetails)',\s*(\d+)\)/g)].map(m => Number(m[1]));
const section = (h, id, next) => { const i = h.indexOf(`id="${id}"`), j = next ? h.indexOf(`id="${next}"`, i) : -1; return i < 0 ? '' : h.slice(i, j > i ? j : undefined); };
const homeRecent = h => cardIds(section(h, 'homeRecent', 'homeCars'));
const idsIn = html => [...String(html).matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const onclickOf = el => { const m = /onclick="([^"]*)"/.exec(el); return m ? dec(m[1]) : null; };
const T0 = '2027-01-01T19:30:00', T1 = '2027-01-01T19:20:00', T2 = '2027-01-01T19:10:00', T3 = '2027-01-01T18:50:00', T4 = '2026-12-31T20:00:00';   // أحدث من كل بذور النظام

(async () => {
  const ref = view(null);
  const SH = ref.J('ShowroomsRepository.getAll()'), US = ref.J('UsersRepository.getAll()'), SC = ref.J('CarsRepository.getAll()'), MC = ref.J('MemberCarsRepository.getAll()');
  const act = id => { const s = SH.find(x => x.id === id); return !!s && String(s.status).trim().toLowerCase() === 'active' && US.some(u => u.id === s.ownerId && u.status === 'active'); };
  const PUB = SC.filter(c => act(c.showroomId)).concat(MC.filter(c => c.status === 'active' && US.some(u => u.id === c.ownerId && u.status === 'active')));   // مرجع الظهور العلني من البيانات مباشرة
  const ms = c => Date.parse(c.createdAt);
  const ORACLE = PUB.slice().sort((a, b) => ms(b) - ms(a)).map(c => c.id);                    // مرجع الترتيب المستقل (طوابع البذور فريدة وصالحة)

  /* ======================= A) الرئيسية ======================= */
  console.log('\n--- A) قسم الرئيسية ---');
  await tc('1) الرئيسية تحوي «السيارات المضافة حديثاً» بعنوان h2 مرتبط (aria-labelledby) وسطر مساعد «أحدث السيارات التي أضيفت إلى معارض النجف»، بعد إعلان home_banner وقبل «أحدث السيارات»', async () => {
    const g = view(null); g.R(`go('home')`); const h = g.E.screen(); const p = s => h.indexOf(s);
    return (/<section id="homeRecent"[^>]*aria-labelledby="homeRecentTitle"/.test(h) && /<h2 id="homeRecentTitle">🆕 السيارات المضافة حديثاً<\/h2>/.test(h) && h.includes('<p class="sub">أحدث السيارات التي أضيفت إلى معارض النجف</p>') && p('home_banner') < p('id="homeRecent"') && p('id="homeRecent"') < p('id="homeCars"')) || 'title'; });
  await tc('2) الرئيسية تعرض سيارات عامة فقط، بحد 6 بطاقات (حد الخدمة RECENT_CARS_HOME_LIMIT)، كلها من المسار العام الموحّد (معارض + أعضاء) ومن المرجع المستقل للظهور', async () => {
    const g = view(null); g.R(`go('home')`); const ids = homeRecent(g.E.screen()); const lim = g.R('RECENT_CARS_HOME_LIMIT');
    return (lim === 6 && ids.length === 6 && ids.every(i => PUB.some(c => c.id === i)) && new Set(ids).size === 6) || { ids, lim }; });
  await tc('3) ترتيب الرئيسية الأحدث أولًا: 6 أحدث من المرجع المستقل بترتيبها، وبسجلات مضبوطة (معرض T0، عضو T1، معرض T2، معرض T3) تتصدر بهذا الترتيب بالضبط (مصدرها مختلط في سلسلة زمنية واحدة)', async () => {
    const s0 = world(w => { addCar(w, 9301, 1, T0); addMem(w, 9302, 7, T1); addCar(w, 9303, 2, T2); addCar(w, 9304, 4, T3); });
    const g = view(null, s0); g.R(`go('home')`); const ids = homeRecent(g.E.screen()); const base = view(null); base.R(`go('home')`);
    return (same(ids.slice(0, 4), [9301, 9302, 9303, 9304]) && ids.length === 6 && same(homeRecent(base.E.screen()), ORACLE.slice(0, 6))) || { ids, base: homeRecent(base.E.screen()), oracle: ORACLE.slice(0, 6) }; });
  await tc('4) لا قائمة معرّفات ولا تواريخ ثابتة: الكود بلا أرقام معرّفات/تواريخ حرفية، والترتيب ديناميكي فعلًا: إضافة سيارة أحدث تتصدر، وإخفاء المعرض يُسقطها، وتغيير createdAt يعيد الترتيب', async () => {
    const code = strip(read('screens/home.js')) + strip(read('screens/recentCars.js')) + (strip(read('services/searchService.js')).match(/RECENT_CARS_HOME_LIMIT[\s\S]*?function getRecentCars[\s\S]*?\n\}/) || [''])[0];
    const noLit = !/\b\d{4}-\d{2}-\d{2}\b/.test(code) && !/\[\s*\d+\s*(,\s*\d+\s*)+\]/.test(code) && !/ids?\s*[:=]\s*\[/.test(code) && !/go\('(carDetails|memberCarDetails)',\s*\d+/.test(code);
    const w = view('admin'); addCar(w, 9310, 1, T0); const top1 = w.J('getRecentCars({limit:1}).map(c=>c.id)')[0]; w.R(`CarsRepository.update(9310, { createdAt: '2000-01-01T00:00:00' })`); const top2 = w.J('getRecentCars({limit:1}).map(c=>c.id)')[0];
    const w2 = view('admin'); addCar(w2, 9311, 1, T0); setSh(w2, 1, 'pending'); const g = view(null, clone(w2.E.store)); const gone = !g.J('getRecentCars().map(c=>c.id)').includes(9311);
    return (noLit && top1 === 9310 && top2 !== 9310 && gone) || { noLit, top1, top2, gone }; });
  await tc('5) «عرض الكل» في القسم: <button type="button" class="link-btn"> بـaria-label واضح، وجهته go(\'recentCars\') ويفتح المسار فعلًا (بتنفيذ onclick المفكوك)، ويُخفى إن لم توجد سيارات', async () => {
    const g = view(null); g.R(`go('home')`); const sec = section(g.E.screen(), 'homeRecent', 'homeCars'); const b = (sec.match(/<button[^>]*class="link-btn"[^>]*>عرض الكل<\/button>/) || [''])[0];
    g.R(onclickOf(b)); const route = g.R('currentRoute');
    const e = view(null); e.R('CARS.length = 0; MEMBER_CARS.length = 0'); e.R(`go('home')`); const es = section(e.E.screen(), 'homeRecent', 'homeCars');
    return (/^<button type="button" class="link-btn" onclick="go\('recentCars'\)" aria-label="عرض كل السيارات المضافة حديثاً">/.test(b) && route === 'recentCars' && !es.includes('عرض الكل')) || { b, route }; });

  /* ======================= B) شاشة recentCars ======================= */
  console.log('\n--- B) شاشة recentCars ---');
  await tc('6) الشاشة موجودة وتُرسم: screens/recentCars.js مدرج في index.html، المسار ROUTES.recentCars (عام بلا حارس، nav:home)، وعنوان h1 «السيارات المضافة حديثاً» وشرح «أحدث السيارات التي أضيفت إلى المنصة» وحقل بحث باسم وصولي وزر رجوع حقيقي', async () => {
    const g = view(null); g.R(`go('recentCars')`); const h = g.E.screen(); const r = strip(read('navigation/router.js')); const idx = read('index.html');
    return (fs.existsSync(path.join(ROOT, 'screens/recentCars.js')) && /<script src="screens\/recentCars\.js"><\/script>/.test(idx) && /recentCars: \{ render: RecentCarsScreen, nav: 'home' \}/.test(r) && g.R('currentRoute') === 'recentCars' && /<h1>🆕 السيارات المضافة حديثاً<\/h1>/.test(h) && h.includes('أحدث السيارات التي أضيفت إلى المنصة') && h.includes('aria-label="ابحث عن سيارة"') && h.includes('class="back-pill"') && !h.includes(ERR)) || 'screen'; });
  await tc('7) ترتيب createdAt تنازليًا في القائمة الكاملة: كل السيارات العامة (115) بترتيب المرجع المستقل بالضبط، والطوابع غير متزايدة، ولا ترتيب بالمعرّف أو موضع المصفوفة (المعرّفات الناتجة غير مرتبة)', async () => {
    const g = view(null); g.R(`go('recentCars')`); const ids = cardIds(g.E.screen()); const times = ids.map(i => ms(PUB.find(c => c.id === i)));
    const byId = ids.slice().sort((a, b) => b - a), byIdAsc = ids.slice().sort((a, b) => a - b);
    return (same(ids, ORACLE) && ids.length === PUB.length && times.every((x, i) => i === 0 || times[i - 1] >= x) && !same(ids, byId) && !same(ids, byIdAsc) && g.E.screen().includes(`النتائج: ${g.R(`carCountLabel(${ids.length})`)}`)) || { n: ids.length, exp: PUB.length, first: ids.slice(0, 5), oracle: ORACLE.slice(0, 5) }; });
  await tc('8) سيارات المعارض مضمَّنة: سيارة معرض فعّال تظهر في الرئيسية والشاشة بنوعها الصحيح (تفاصيل carDetails، شارة المصدر بلا «من عضو»)، وفي القائمة الكاملة سيارات معارض', async () => {
    const s = world(w => addCar(w, 9320, 1, T0)); const g = view(null, s); g.R(`go('home')`); const hs = homeRecent(g.E.screen()); g.R(`go('recentCars')`); const full = g.E.screen();
    const card = g.R('CarCard(getCarById(9320))');
    return (hs.includes(9320) && cardIds(full).includes(9320) && card.includes("go('carDetails',9320)") && !card.includes('من عضو') && g.J('getRecentCars().filter(c=>c.sourceType==="showroom").length') > 20) || { hs }; });
  await tc('9) سيارات الأعضاء مضمَّنة: إعلان عضو نشط يظهر مع سيارات المعارض في سلسلة واحدة بنوعه الصحيح (CarCard يوجّه لتفاصيل العضو وشارة «من عضو»)، والبذور تضم الجنسين', async () => {
    const s = world(w => { addMem(w, 9330, 7, T0); addCar(w, 9331, 1, T1); }); const g = view(null, s); g.R(`go('home')`); const hs = homeRecent(g.E.screen()); g.R(`go('recentCars')`); const full = cardIds(g.E.screen());
    const card = g.R('CarCard(getCarById(9330))'); const kinds = new Set(g.J('getRecentCars().map(c=>c.sourceType)'));
    return (same(hs.slice(0, 2), [9330, 9331]) && full.indexOf(9330) < full.indexOf(9331) && card.includes("go('memberCarDetails',9330)") && card.includes('من عضو') && kinds.has('member') && kinds.has('showroom')) || { hs: hs.slice(0, 3), kinds: [...kinds] }; });

  /* ======================= C) الظهور ======================= */
  console.log('\n--- C) الظهور (visibilityService) ---');
  const VIEWERS = [null, 'user', 'dealer2', 'dealer3'];
  await tc('10) سيارات المعرض المخفي مستبعدة بأحدث طوابع: معرض pending/rejected/suspended/disabled/inactive أو حساب مالكه موقوف ← لا في الرئيسية ولا القائمة الكاملة ولا البحث، لزائر وعضو وتاجرين غير مالكين وحتى للمدير ومالك المعارض المخفية', async () => {
    const s = world(w => { [['pending', 9401], ['rejected', 9402], ['suspended', 9403], ['disabled', 9404], ['inactive', 9405]].forEach(([st, id], i) => { addSh(w, { id, name: 'Rc ' + st, status: st, ownerId: 4 }); addCar(w, id + 100, id, T0, { brand: 'RcHidden' + st }); });
      addSh(w, { id: 9406, name: 'Rc acct', status: 'active', ownerId: 5 }); addCar(w, 9506, 9406, T0, { brand: 'RcHiddenacct' }); w.R(`UsersRepository.update(5, { status: 'suspended' })`); });
    const bad = []; const hidIds = [9501, 9502, 9503, 9504, 9505, 9506];
    for (const v of VIEWERS.concat(['dealer4', 'admin'])) { const g = view(v, s); g.R(`go('home')`); const h = homeRecent(g.E.screen()); g.R(`go('recentCars')`); const f = cardIds(g.E.screen()); g.R("onRecentCarsSearch('RcHidden')"); const q = cardIds(g.E.els.recentCarsList.innerHTML); const svc = g.J('getRecentCars().map(c=>c.id)');
      if ([h, f, q, svc].some(a => a.some(i => hidIds.includes(i)))) bad.push(v || 'guest'); }
    return bad.length === 0 || bad; });
  await tc('11) إعلانات الأعضاء المخفية مستبعدة لكل مشاهد حتى المدير: مالك حسابه موقوف/pending، وحالة الإعلان pending/rejected/suspended/sold — بأحدث طوابع', async () => {
    const s = world(w => { addMem(w, 9601, 7, T0); addMem(w, 9602, 7, T0, { status: 'pending' }); addMem(w, 9603, 7, T0, { status: 'rejected' }); addMem(w, 9604, 7, T0, { status: 'suspended' }); addMem(w, 9605, 7, T0, { status: 'sold' }); addMem(w, 9606, 2, T0); w.R(`UsersRepository.update(2, { status: 'pending' })`); });
    const bad = []; for (const v of [null, 'user', 'dealer3', 'admin']) { const g = view(v, s); const ids = g.J('getRecentCars().map(c=>c.id)'); g.R(`go('home')`); const h = homeRecent(g.E.screen()); if (!ids.includes(9601)) bad.push(v + ':active-missing'); if ([9602, 9603, 9604, 9605, 9606].some(i => ids.includes(i) || h.includes(i))) bad.push((v || 'guest') + ':hidden-member'); }
    return bad.length === 0 || bad; });
  await tc('12) غير العامة مستبعدة والمصدر واحد: لكل مشاهد (زائر/عضو/تاجران/مالك المعارض المخفية/مدير) مجموعة getRecentCars = getPublicCars("all", null) (المسار العام بلا مشاهد في visibilityService) = المرجع المستقل للزائر؛ والمدير/المالك يريان سيارات المخفي في السيارات (getPublicCars("all") بتفويضهما) لا في «المضافة حديثًا» — فلا سجل إدارة يتسرّب لقسم عام', async () => {
    const s = world(w => { addSh(w, { id: 9701, name: 'Rc12', status: 'pending', ownerId: 4 }); addCar(w, 9801, 9701, T0); addMem(w, 9802, 7, T0, { status: 'pending' }); });
    const bad = []; const srt = a => a.slice().sort((x, y) => x - y); const exp = srt(PUB.map(c => c.id));
    for (const v of [null, 'user', 'dealer2', 'dealer4', 'admin']) { const g = view(v, s); const a = srt(g.J('getRecentCars().map(c=>c.id)')), b = srt(g.J(`getPublicCars('all', null).map(c=>c.id)`)); if (!same(a, b) || !same(a, exp)) bad.push(v || 'guest'); }
    const adm = view('admin', s), own = view('dealer4', s); const admPool = adm.J(`getPublicCars('all').map(c=>c.id)`), ownPool = own.J(`getPublicCars('all').map(c=>c.id)`);
    return (bad.length === 0 && admPool.includes(9801) && ownPool.includes(9801) && !adm.J('getRecentCars().map(c=>c.id)').includes(9801) && !own.J('getRecentCars().map(c=>c.id)').includes(9801) && !admPool.includes(9802)) || { bad, a: admPool.includes(9801), o: ownPool.includes(9801) }; });
  await tc('13) السيارة المباعة تتبع الظهور القائم بلا حالة جديدة: سيارة معرض sold تظهر (كما في السيارات) وإعلان عضو sold لا يظهر، وكل الحالات في الخلاصة ضمن available/sold/active فقط', async () => {
    const s = world(w => { addCar(w, 9901, 1, T0, { status: 'sold' }); addMem(w, 9902, 7, T0, { status: 'sold' }); }); const g = view(null, s); const feed = g.J('getRecentCars()'); const ids = feed.map(c => c.id); g.R(`go('recentCars')`); const card = g.R('CarCard(getCarById(9901))');
    const statuses = new Set(feed.map(c => c.status));
    return (ids.includes(9901) && !ids.includes(9902) && [...statuses].every(x => ['available', 'sold', 'active'].includes(x)) && card.includes('data-status="sold"') && !feed.some(c => c.isNew || c.recent || c.status === 'new')) || { statuses: [...statuses] }; });
  await tc('14) لا reserved ولا حالة «جديد»: لا ذكر لـreserved/محجوز في كود الميزة ولا HTML الناتج، ولا حالة جديدة في الخدمة/الشاشتين', async () => {
    const g = view(null); g.R(`go('home')`); const h = g.E.screen(); g.R(`go('recentCars')`); const r = g.E.screen(); const code = strip(read('screens/recentCars.js')) + strip(read('screens/home.js')) + (strip(read('services/searchService.js')).match(/RECENT_CARS_HOME_LIMIT[\s\S]*?function getRecentCars[\s\S]*?\n\}/) || [''])[0];
    return (!/reserved|محجوز/i.test(code + h + r) && !/status\s*[:=]\s*['"]new['"]|STATUS\.\w*NEW|'new'/.test(code)) || 'status'; });

  /* ======================= D) createdAt ======================= */
  console.log('\n--- D) createdAt ---');
  await tc('15) createdAt مفقود لا يُسقط: undefined/null/«»/مسافات/غير موجود: لا استثناء، تأتي بعد كل المؤرَّخ بترتيب حتمي، لا تاريخ مخترع (السجل يبقى بلا createdAt)، ولا كتابة في التخزين من العرض/الخدمة', async () => {
    const s = world(w => { addCar(w, 9951, 1, T0); w.R(`CarsRepository.create(CarModel({ id: 9952, sourceType: 'showroom', showroomId: 1, brand: 'NoDate', model: 'A', year: 2024, price: 1, currency: 'IQD', status: 'available' }))`); addCar(w, 9953, 1, null, { brand: 'NoDate' }); addCar(w, 9954, 1, '', { brand: 'NoDate' }); addCar(w, 9955, 1, '   ', { brand: 'NoDate' }); });
    const g = view(null, s); const before = JSON.stringify(g.E.store); const ids = g.J('getRecentCars().map(c=>c.id)'); g.R(`go('home')`); g.R(`go('recentCars')`); const scr = g.E.screen(); const after = JSON.stringify(g.E.store);
    const undated = [9952, 9953, 9954, 9955]; const posD = ids.indexOf(9951), lastDated = Math.max(...ids.filter(i => !undated.includes(i)).map(i => ids.indexOf(i))); const posU = undated.map(i => ids.indexOf(i));
    return (g.E.errors.length === 0 && posD === 0 && posU.every(p => p > lastDated) && same(posU.slice().sort((a, b) => a - b), posU.slice().sort((a, b) => a - b)) && !BAD.test(scr) && before === after && g.J('CarsRepository.getById(9952).createdAt') === undefined) || { posD, lastDated, posU, same: before === after }; });
  await tc('16) createdAt تالف لا ينتج NaN: «garbage»/«2026-02-30T10:00:00»/«0»/«12»/«2026-13-01»/«2026-06-14T25:00:00»/{}/[]/NaN/-5/true ← تُعامل غير مؤرَّخة (تأتي بعد المؤرَّخ)، لا NaN في أي HTML، ولا استثناء، والدالة الداخلية تعيد NaN فقط', async () => {
    const bad = ['garbage', '2026-02-30T10:00:00', '0', '12', '2026-13-01', '2026-06-14T25:00:00', '2026-06-14T10:61:00', 'ٱلْيَوْم', '١٤٤٨-٠١-٠١'];
    const s = world(w => { addCar(w, 9960, 1, T0); bad.forEach((v, i) => addCar(w, 9961 + i, 1, v, { brand: 'BadDate' })); [{}, [], -5, true].forEach((v, i) => addCar(w, 9980 + i, 1, v, { brand: 'BadDate' })); });
    const g = view(null, s); const ids = g.J('getRecentCars().map(c=>c.id)'); const badIds = [...bad.map((_, i) => 9961 + i), 9980, 9981, 9982, 9983]; const lastDated = Math.max(...ids.filter(i => !badIds.includes(i)).map(i => ids.indexOf(i)));
    g.R(`go('home')`); const h = g.E.screen(); g.R(`go('recentCars')`); const r = g.E.screen(); g.R("onRecentCarsSearch('BadDate')"); const q = g.E.els.recentCarsList.innerHTML;
    const parsed = g.J(`[${JSON.stringify('2026-02-30T10:00:00')}, '0', '12', 'x', '', null, undefined, {}, [], true, NaN, -5, '2026-06-14T09:00:00', 1781427600000].map(v => _createdAtMs({ createdAt: v }))`);
    return (ids.indexOf(9960) === 0 && badIds.every(i => ids.indexOf(i) > lastDated) && !BAD.test(h + r + q) && g.E.errors.length === 0 && parsed.slice(0, 11).every(x => x === null) && parsed[11] === null && typeof parsed[12] === 'number' && parsed[13] === 1781427600000) || { first: ids.slice(0, 3), parsed }; });
  await tc('D3) صيغ الطوابع المختلطة تُقارَن زمنيًا لا نصيًا: «2026-06-14T09:00:00» و«…Z» و«2026-06-14 09:00» و«+03:00» وتاريخ فقط ورقم ms، والتعادل يُحسم بالمعرّف تنازليًا (ثانويًا فقط)، والترتيب يتبع الزمن حتى حين تعاكس الأحرف الترتيب النصي', async () => {
    const s = world(w => { addCar(w, 9971, 1, '2027-06-14T12:00:00+03:00'); addCar(w, 9972, 1, '2027-06-14T09:30:00Z'); addCar(w, 9973, 1, '2027-06-14 09:00'); addCar(w, 9974, 1, '2027-06-14'); addCar(w, 9975, 1, 1812000000000); addCar(w, 9976, 1, '2027-06-14T09:30:00Z'); });
    const g = view(null, s); const ids = g.J('getRecentCars().map(c=>c.id)').slice(0, 7); const t = id => g.J(`_createdAtMs(getCarById(${id}))`);
    const order = [9975, 9971, 9976, 9972, 9973, 9974].sort((a, b) => (t(b) - t(a)) || (b - a));   // المرجع داخل الاختبار: الزمن ثم المعرّف
    return (same(ids.filter(i => i >= 9971 && i <= 9976), order) && t(9972) === t(9976) && ids.indexOf(9976) < ids.indexOf(9972)) || { got: ids, order }; });

  /* ======================= E) عرض آمن ======================= */
  console.log('\n--- E) عرض آمن ---');
  await tc('17) الصورة المفقودة آمنة: سيارة بلا صورة تُعرض ببديلها الآمن بلا <img> مكسور، وصورة معطوبة بـonerror=imgFallback، في الرئيسية والشاشة', async () => {
    const s = world(w => { addCar(w, 9990, 1, T0, { mainImage: '' }); addCar(w, 9991, 1, T1, { mainImage: 'https://invalid.example.invalid/x.jpg' }); }); const g = view(null, s); g.R(`go('home')`); const hs = section(g.E.screen(), 'homeRecent', 'homeCars'); g.R(`go('recentCars')`); const full = g.E.screen();
    const c0 = g.R('CarCard(getCarById(9990))'), c1 = g.R('CarCard(getCarById(9991))');
    return (hs.includes("go('carDetails',9990)") && !/<img[^>]*src=""/.test(c0 + hs + full) && c0.includes('img-ph') && (c1.includes('onerror="imgFallback(this)"') || !c1.includes('<img')) && !BAD.test(hs + full)) || { c0: c0.slice(0, 160) }; });
  await tc('18) الأسماء الطويلة لا تكسر البنية: ماركة/موديل/معرض بأكثر من 100 حرف تُهرَّب وتُعرض كاملة في البطاقة، وإدخال HTML يُهرَّب، وCSS الالتفاف قائم (overflow-wrap:anywhere للبطاقة)', async () => {
    const L = 'ماركة-طويلة-جدا-'.repeat(5) + 'Extraordinarily-Long-Name-'.repeat(3); const s = world(w => { addSh(w, { id: 9702, name: L + '<b>x</b>', ownerId: 4 }); addCar(w, 9992, 9702, T0, { brand: L, model: L + '<i>y</i>' }); });
    const g = view(null, s); g.R(`go('home')`); const hs = section(g.E.screen(), 'homeRecent', 'homeCars'); g.R(`go('recentCars')`); const full = g.E.screen(); const css = read('theme/theme.css');
    const c = { long: L.length > 100, hs: hs.includes(L.slice(0, 40)), full: full.includes(L.slice(0, 40)), noI: !hs.includes('<i>y</i>'), noB: !full.includes('<b>x</b>'), esc: full.includes('&lt;i&gt;y&lt;/i&gt;'), css: /\.card-title,\.card-row,\.info-row,\.detail-body h1[^{]*\{[^}]*overflow-wrap:\s*anywhere/.test(css), clean: !BAD.test(hs + full) }; return Object.values(c).every(Boolean) || c; });

  /* ======================= F) إعادة الاستخدام لا الازدواج ======================= */
  console.log('\n--- F) مصدر واحد ---');
  await tc('19) CarCard القائم يُعاد استخدامه: الرئيسية والشاشة تستدعيانه فقط، ولا RecentCarCard ولا بطاقة HTML حرفية (card car-card)، وبطاقة الشاشة مطابقة لـCarCard(getCarById) حرفيًا', async () => {
    const hs = strip(read('screens/home.js')), rs = strip(read('screens/recentCars.js')); const all = ['screens', 'components', 'services'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => strip(read(d + '/' + f)))).join('\n');
    const g = view(null); g.R(`go('recentCars')`); const first = g.J('getRecentCars()[0].id'); const exact = g.E.screen().includes(g.R(`CarCard(getCarById(${first}))`));
    return (/recent\.map\(CarCard\)/.test(hs) && /results\.map\(CarCard\)/.test(rs) && !/RecentCarCard|function Recent[A-Za-z]*Card/.test(all) && !/card car-card/.test(hs + rs) && exact) || 'card'; });
  await tc('20) visibilityService يُعاد استخدامه ولا التفاف: الخدمة تنادي searchCars(…,\'all\') فقط، والشاشتان لا تلمسان getCars/getMemberCars/getShowrooms/المستودعات/AuthorizationService/_showroomVisible ولا تفحصان حالة/مالك', async () => {
    const svc = (strip(read('services/searchService.js')).match(/function getRecentCars[\s\S]*?\n\}/) || [''])[0]; const hs = strip(read('screens/home.js')), rs = strip(read('screens/recentCars.js'));
    return (/searchCars\(o\.query, 'all', o\.criteria, null\)/.test(svc) && !/getCars\(|getMemberCars|getShowrooms|Repository|CARS\b|getCarById|getVisible/.test(svc) && !/getCars\(|getMemberCars|getShowrooms|Repository|AuthorizationService\.can|_showroomVisible|_memberPublic|\.status\s*[!=]==|\.ownerId|\.showroomId/.test(rs) && !/Repository|_showroomVisible|\.ownerId|c\.status\s*[!=]==/.test(hs.replace(/\/\*[\s\S]*?\*\//g, ''))) || { svc: svc.slice(0, 160) }; });
  await tc('21) لا محرك بحث/فلترة/ظهور ثانٍ: تعريف واحد لـgetRecentCars وsearchCars وgetPublicCars، ولا recentSearchService/recentFilterService، والشاشة بلا .filter()/.some()/.find() للسيارات ولا .sort() (الترتيب في الخدمة فقط)، ولا ملف خدمة/مستودع/مكوّن جديد', async () => {
    const all = ['screens', 'components', 'services', 'repositories'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => d + '/' + f)); const src = all.map(f => strip(read(f))).join('\n'); const rs = strip(read('screens/recentCars.js'));
    const def = n => (src.match(new RegExp('^function ' + n + '\\(', 'gm')) || []).length;   // التعريفات العامة فقط (غلاف VisibilityService الداخلي ليس تعريفًا ثانيًا)
    return (def('getRecentCars') === 1 && def('searchCars') === 1 && def('getPublicCars') === 1 && !/recentSearch|recentFilter|RecentRepository|recentCarsRepository/i.test(src) && !/\.filter\(|\.some\(|\.find\(|\.sort\(/.test(rs) && all.filter(f => /recent/i.test(f)).join() === 'screens/recentCars.js' && fs.readdirSync(path.join(ROOT, 'services')).length === 20 && fs.readdirSync(path.join(ROOT, 'repositories')).length === 11) || { rec: all.filter(f => /recent/i.test(f)) }; });
  await tc('22) البحث والفلاتر (المُعاد استخدامها) تحفظ الأحدث أولًا: كل استعلام/معيار يعيد مجموعة searchCars نفسها مرتبة زمنيًا (تنازليًا)، عربيًا ولاتينيًا وبالأرقام العربية، وبمعيار CarFilters (ماركة/سنة/سعر)، وبحد limit', async () => {
    const g = view(null); const bad = [];
    for (const [q, c] of [['toyota', undefined], ['كورولا', undefined], ['Corolla', undefined], ['٢٠١٩', undefined], ['', { brand: 'Toyota' }], ['', { year: 2019 }], ['kia', { minPrice: 10000000 }], ['', { brand: 'Nissan', model: 'Patrol' }], ['zzzz', undefined]]) {
      const got = g.J(`getRecentCars(${JSON.stringify({ query: q, criteria: c })}).map(c=>c.id)`); const pool = g.J(`searchCars(${JSON.stringify(q)}, 'all', ${JSON.stringify(c === undefined ? null : c)} || undefined).map(c=>c.id)`);
      const exp = pool.slice().sort((a, b) => ms(PUB.find(x => x.id === b)) - ms(PUB.find(x => x.id === a)));
      if (!same(got, exp)) bad.push([q, c]); }
    g.R(`go('recentCars')`); g.R("onRecentCarsSearch('toyota')"); const scr = cardIds(g.E.els.recentCarsList.innerHTML); const exp = PUB.filter(c => /toyota/i.test(c.brand)).sort((a, b) => ms(b) - ms(a)).map(c => c.id);
    const lims = [g.J('getRecentCars({limit:3}).length'), g.J('getRecentCars({limit:0}).length'), g.J('getRecentCars({limit:-1}).length'), g.J('getRecentCars({limit:"x"}).length'), g.J('getRecentCars(null).length'), g.J('getRecentCars(5).length')];
    return (bad.length === 0 && same(scr, exp) && scr.length > 3 && lims[0] === 3 && lims.slice(1).every(n => n === PUB.length)) || { bad, lims }; });
  await tc('23) الحالات الفارغة بـEmptyState القائم: لا سيارات عامة ← الرئيسية «لا توجد سيارات مضافة حديثًا» بلا «عرض الكل»، والشاشة «لا توجد سيارات مضافة حديثًا» بزر «العودة للرئيسية»؛ وبحث بلا نتيجة ← «لم نعثر على سيارات مطابقة لبحثك» + «مسح البحث» يعيد القائمة، ولا undefined', async () => {
    const e = view(null); e.R('CARS.length = 0; MEMBER_CARS.length = 0'); e.R(`go('home')`); const hs = section(e.E.screen(), 'homeRecent', 'homeCars'); e.R(`go('recentCars')`); const es = e.E.screen();
    const g = view(null); g.R(`go('recentCars')`); g.R("onRecentCarsSearch('zzzzqqq')"); const nr = g.E.els.recentCarsList.innerHTML; g.R('clearRecentCarsSearch()'); const back = cardIds(g.E.screen());
    return (hs.includes('لا توجد سيارات مضافة حديثًا') && !hs.includes('عرض الكل') && es.includes('لا توجد سيارات مضافة حديثًا') && es.includes("go('home')") && !es.includes('لم نعثر') && nr.includes('لم نعثر على سيارات مطابقة لبحثك') && nr.includes('clearRecentCarsSearch()') && same(back, ORACLE) && !BAD.test(hs + es + nr)) || 'empty'; });
  await tc('24) لا undefined/NaN/[object Object]/«حدث خطأ» في الرئيسية والشاشة لكل الأدوار (ضيف/عضو/تاجران/مدير) وبيانات عدائية (طوابع تالفة، ناقصة، أسماء طويلة، سيارات مخفية)، ولا استثناء', async () => {
    const s = world(w => { addCar(w, 9660, 1, 'garbage'); addCar(w, 9661, 1, null); addMem(w, 9662, 7, '2026-02-30T10:00:00'); addCar(w, 9663, 1, T0, { brand: 'L'.repeat(150), mainImage: '' }); addSh(w, { id: 9703, name: 'RcHid', status: 'pending', ownerId: 4 }); addCar(w, 9664, 9703, T0); }); const bad = [];
    for (const v of [null, 'user', 'dealer1', 'dealer4', 'admin']) { const g = view(v, s); for (const r of ['home', 'recentCars']) { g.R(`go('${r}')`); const h = g.E.screen(); if (BAD.test(h) || h.includes(ERR)) bad.push((v || 'guest') + ':' + r); } g.R("onRecentCarsSearch('x')"); if (BAD.test(g.E.els.recentCarsList.innerHTML)) bad.push((v || 'guest') + ':search'); if (g.E.errors.length) bad.push((v || 'guest') + ':errors'); }
    return bad.length === 0 || bad; });
  await tc('25) لا معرّف مكرر في الرئيسية ولا شاشة recentCars (حتى مع 115 بطاقة)، وفي الرئيسية عنوان القسم homeRecentTitle فريد', async () => {
    const g = view(null); g.R(`go('home')`); const a = idsIn(g.E.screen()); g.R(`go('recentCars')`); const b = idsIn(g.E.screen());
    return (new Set(a).size === a.length && new Set(b).size === b.length && a.filter(x => x === 'homeRecentTitle').length === 1 && b.includes('recentCarsList')) || { a: a.length, b: b.length }; });
  await tc('26) الوصول: القسم <section id="homeRecent" aria-labelledby> لـh2 بمعرّف، «عرض الكل» button أصلي type=button باسم وصولي، رأس الشاشة h1 وزر رجوع حقيقي وبحث باسم، ولا div قابل للنقر بلا زر أصلي بداخله (بطاقات CarCard)، ولا role=button على div، والتركيز المرئي مفعّل في CSS للأزرار', async () => {
    const g = view(null); g.R(`go('home')`); const hh = g.E.screen(); const hs = section(hh, 'homeRecent', 'homeCars'); g.R(`go('recentCars')`); const r = g.E.screen(); const css = read('theme/theme.css');
    const divClicks = [...(hs + r).matchAll(/<div[^>]*class="card car-card"[\s\S]*?(?=<div class="card car-card"|$)/g)].filter(m => !/<button type="button"/.test(m[0]));
    const c = { section: /<section id="homeRecent"[^>]*aria-labelledby="homeRecentTitle"/.test(hh), h2: /<h2 id="homeRecentTitle">/.test(hs), all: /<button type="button" class="link-btn"[^>]*aria-label="[^"]+"/.test(hs), h1: /<h1>/.test(r), back: /<button type="button" class="back-pill"[^>]*aria-label="رجوع"/.test(r), search: /<input[^>]*aria-label="ابحث عن سيارة"/.test(r) || r.includes('aria-label="ابحث عن سيارة"'), noRoleDiv: !/<div[^>]*role="button"/.test(hs + r), noDivClicks: divClicks.length === 0, focus: /:focus-visible/.test(css) };
    return Object.values(c).every(Boolean) || c; });

  /* ======================= G) عدم التراجع والتنقل ======================= */
  console.log('\n--- G) عدم التراجع والتنقل ---');
  await tc('27) أقسام الرئيسية القائمة سليمة بترتيبها: البطل ← الإجراءات ← الوصول السريع ← الإعلان ← المضافة حديثًا (الجديد) ← أحدث السيارات ← المعارض ← لماذا ← سيارات الأعضاء، وكل أزرارها وعناوينها كما كانت (أحدث السيارات بزر «عرض الكل» إلى cars، المعارض إلى showrooms، الأعضاء إلى memberCars)', async () => {
    const g = view(null); g.R(`go('home')`); const h = g.E.screen(); const marks = ['home-hero', 'home-actions', 'homeQuickTitle', 'home_banner', 'id="homeRecent"', 'id="homeCars"', 'id="homeShowrooms"', 'homeValueTitle', 'id="homeMembers"'].map(s => h.indexOf(s));
    return (marks.every(i => i >= 0) && marks.every((x, i) => i === 0 || marks[i - 1] < x) && h.includes("go('cars')") && h.includes("go('showrooms')") && h.includes("go('memberCars')") && (h.match(/>عرض الكل<\/button>/g) || []).length === 4 && !h.includes(ERR)) || marks; });
  await tc('28) شاشتا السيارات والأعضاء وتفاصيل السيارة لم تتراجع: السيارات (بحث ولوحة مطويّة وزر تصفية وبطاقاتها الظاهرة)، الأعضاء (لوحة مطويّة وزر تصفية)، التفاصيل (رجوع ومفضلة مدمجة)، والمعارض (بحث وعدّاد)', async () => {
    const x = view(null); x.R(`go('cars')`); const c = x.E.screen(); x.R(`go('memberCars')`); const m = x.E.screen(); const first = x.J('getVisibleCars()[0].id'); x.R(`go('carDetails',${first})`); const d = x.E.screen(); x.R(`go('showrooms')`); const s = x.E.screen();
    return (c.includes('placeholder="ابحث عن سيارة"') && /id="carsRefinePanel"[^>]*hidden/.test(c) && (c.match(/class="card car-card"/g) || []).length === x.J('getVisibleCars().length') && /id="memberRefinePanel"[^>]*hidden/.test(m) && d.includes('class="back-pill"') && d.includes('class="fav-inline"') && s.includes('placeholder="ابحث عن معرض"') && s.includes('class="results-count"')) || 'regression'; });
  await tc('29) التنقل بالمسار القائم: الرئيسية ← عرض الكل ← recentCars ← بطاقة ← تفاصيل ← رجوع = recentCars (ببحثها)، والرئيسية ← بطاقة ← تفاصيل ← رجوع = الرئيسية، والدخول المباشر بلا سجل ← البديل home بلا انهيار، والمفضلة تعمل من البطاقة', async () => {
    const x = view('user'); x.R(`go('home')`); const sec = section(x.E.screen(), 'homeRecent', 'homeCars'); x.R(`go('recentCars')`); const id = cardIds(x.E.screen())[0]; const ty = x.J(`getCarById(${id}).sourceType`); x.R(ty === 'member' ? `go('memberCarDetails',${id})` : `go('carDetails',${id})`); const d = x.R('currentRoute');
    x.R(onclickOf((x.E.screen().match(/<button[^>]*class="back-pill"[^>]*>/) || [''])[0])); const r1 = x.R('currentRoute');
    x.R(`go('home')`); x.R(ty === 'member' ? `go('memberCarDetails',${id})` : `go('carDetails',${id})`); x.R(onclickOf((x.E.screen().match(/<button[^>]*class="back-pill"[^>]*>/) || [''])[0])); const r2 = x.R('currentRoute');
    const fav = x.J(`toggleFavorite(${id})`); const y = view(null); y.R(`currentRoute = 'recentCars'; _navStack = []; render();`); y.R(`go('carDetails', ${y.J('getVisibleCars()[0].id')})`); y.R(`_navStack = []; goBack('home')`);
    return (sec.includes("go('recentCars')") && /^(carDetails|memberCarDetails)$/.test(d) && r1 === 'recentCars' && r2 === 'home' && fav.ok === true && y.R('currentRoute') === 'home' && y.E.errors.length === 0) || { d, r1, r2, fav: fav.ok }; });
  await tc('30) لا تغيير خارج النطاق: سكربت واحد جديد فقط (85)، لا سجل جديد في التخزين من الميزة، الراوتر بمنطقه (go/goBack/_navStack) وحارسه، ولا ملف خدمة/مستودع/مكوّن جديد، وبلا تخزين في الخدمة الجديدة', async () => {
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length; const r = strip(read('navigation/router.js')); const w = view('admin'); const before = new Set(Object.keys(w.E.store)); w.R('getRecentCars()'); w.R(`go('home')`); w.R(`go('recentCars')`); const after = Object.keys(w.E.store).filter(k => !before.has(k));
    const svc = (strip(read('services/searchService.js')).match(/RECENT_CARS_HOME_LIMIT[\s\S]*?function getRecentCars[\s\S]*?\n\}/) || [''])[0];
    return (order === 85 && after.length === 0 && /function goBack\(fallback\)/.test(r) && /_navStack\.pop\(\)/.test(r) && /_entryUsable\(prev\)/.test(r) && !/AppStorage|localStorage|sessionStorage|indexedDB/.test(svc + strip(read('screens/recentCars.js')))) || { order, after }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

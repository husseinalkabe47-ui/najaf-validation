/* اختبارات «المرحلة 9 — التحصين النهائي» (Phase 9 Final Hardening).
   أربعة بنود فقط: A) ظهور معرض التاجر الموقوف/المرفوض · B) المعرض التلقائي بلا تكرار ·
   C) أمان تصادم المعرّفات القديمة (مفضلة/صور) · D) أمان توحيد الماركة/الموديل.
   كُتبت قبل الإصلاح لإثبات الثغرات، ثم مرّت بعده. «إعادة تحميل» = بيئة جديدة بنفس التخزين. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, !!r, r === false ? '' : (typeof r === 'object' ? JSON.stringify(r) : '')); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 160)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer2: ['07709876543', 'dealer123'],
  pendingDealer: ['07733445566', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const cardsIn = h => (String(h).match(/class="card car-card"/g) || []).length;
const showroomCardsIn = h => (String(h).match(/class="card showroom-card"/g) || []).length;
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const mkCar = async (x, o = {}) => x.R(`createShowroomCar(${JSON.stringify(Object.assign({ brand: 'Kia', model: 'Fx', year: 2020, price: 1000 }, o))})`);
const NAME1 = 'معرض النجف للسيارات';

/** تخزين بصيغة «ما قبل الإصلاح» من بيانات تجريبية + تعديلات (بلا idCounters/schemaVersion/seedIds) */
function legacyStore(mutate) {
  const E0 = makeEnv(), G = c => JSON.parse(E0.run(`JSON.stringify(${c})`));
  const st = { cars: G('CARS'), members: G('MEMBER_CARS'), images: G('CAR_IMAGES'), showrooms: G('SHOWROOMS'), favs: [], deleted: [], overrides: null };
  mutate(st);
  const s = {};
  s['najaf.showroomCars'] = JSON.stringify(st.cars); s['najaf.memberCars'] = JSON.stringify(st.members);
  s['najaf.carImages'] = JSON.stringify(st.images); s['najaf.favorites'] = JSON.stringify(st.favs);
  s['najaf.memberCarsDeleted'] = JSON.stringify(st.deleted); s['najaf.showrooms'] = JSON.stringify(st.showrooms);
  if (st.overrides) s['najaf.userOverrides'] = JSON.stringify(st.overrides);
  return s;
}
const car = o => Object.assign({ sourceType: 'showroom', showroomId: 1, brand: 'Kia', model: 'Legacy', year: 2020, price: 1000, mileage: 5000,
  transmission: 'أوتوماتيك', fuelType: 'بنزين', color: '', description: '', status: 'available', mainImage: '', createdAt: '2026-09-01T10:00:00.000Z', updatedAt: '2026-09-01T10:00:00.000Z' }, o);
const img = (id, carId, url, order, main) => ({ id, carId, imageUrl: url, sortOrder: order, isMain: !!main });
const fav = (id, carId, at, userId = 7) => ({ id, userId, carId, createdAt: at });

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) تعليق/رفض حساب التاجر ======================= */
  console.log('\n--- A) ظهور معرض التاجر الموقوف/المرفوض ---');
  await tc('A1) رفض التاجر: معرضه الفعّال لا يظهر للزائر (المعارض/الرئيسية/الخريطة/البحث) ولا سياراته', async () => {
    const a = mk('admin'); const r = a.R('rejectDealer(1)'); const g = asGuest(a);
    const scr = n => (g.R(`go('${n}')`), g.E.screen());
    g.R(`go('showrooms')`); g.R(`onShowroomsSearch('النجف')`); const bySearch = g.E.els.showroomsList.innerHTML;
    g.R(`go('search','النجف')`); g.R(`onSearchScreenInput('النجف')`); const sr = g.E.els.searchResults.innerHTML;
    g.R(`go('cars')`); const n = cardsIn(g.E.screen());
    return r.ok && !scr('showrooms').includes(NAME1) && !scr('home').includes(NAME1) && !scr('map').includes(NAME1) && !bySearch.includes(NAME1) && !sr.includes(NAME1) &&
      g.R(`searchShowrooms('').length`) === 2 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && n === 6 && g.R(`getVisibleCars().some(c=>c.showroomId===1)`) === false && g.R(`searchCars('', 'all').some(c=>c.showroomId===1)`) === false; });
  await tc('A2) سيارات المعرض المخفي لا تظهر عبر التفاصيل (معرض/سيارة) ولا المفضلة ولا toggleFavorite', async () => {
    const u = mk('user'); u.R(`toggleFavorite(1)`); const a = mk('admin', u.E.store); a.R('rejectDealer(1)'); const g = mk('user', a.E.store);
    g.R(`go('showroomDetails',1)`); const det = g.E.screen(); g.R(`go('carDetails',1)`); const cd = g.E.screen(); g.R(`go('favorites')`); const fv = g.E.screen();
    return det.includes('غير متاح') && !det.includes(NAME1) && cd.includes('غير متاح') && g.R(`getFavoriteCars().length`) === 0 && !fv.includes('Corolla') && g.R(`toggleFavorite(1).ok`) === false &&
      g.R(`FavoritesRepository.getAll().length`) === 1; });
  await tc('A3) المدير يرى المعرض وسياراته في كل الشاشات العامة وفي لوحة الإدارة ويديره', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); a.R(`go('showrooms')`); const s = a.E.screen(); a.R(`go('cars')`); const c = cardsIn(a.E.screen()); a.R(`go('map')`); const m = a.E.screen();
    a.R(`go('showroomDetails',1)`); const det = a.E.screen(); a.R(`go('adminShowrooms')`); const adm = a.E.screen(); a.R(`go('adminShowroomCars')`);
    return s.includes(NAME1) && c === 15 && m.includes(NAME1) && det.includes(NAME1) && !det.includes('غير متاح') && adm.includes(NAME1) &&
      a.R(`AdminService.getAllShowrooms().length`) === 5 && a.R(`AdminService.setShowroomCarStatus(1,'sold').ok`) === true && a.R(`AdminService.suspendShowroom(1).ok`) === true; });
  await tc('A4) لا حذف بيانات: المعرض (حالته active) وسياراته وصوره ومفضلته كلها باقية بعد الرفض وإعادة التحميل', async () => {
    const a = mk('admin'); const before = J(a, `{s:getShowrooms().length,c:getCars().length,i:CAR_IMAGES.length,f:FavoritesRepository.getAll().length}`);
    a.R('rejectDealer(1)'); const b = mk('admin', a.E.store);
    return JSON.stringify(J(b, `{s:getShowrooms().length,c:getCars().length,i:CAR_IMAGES.length,f:FavoritesRepository.getAll().length}`)) === JSON.stringify(before) &&
      b.R(`getShowroomById(1).status`) === 'active' && b.R(`getCarsByShowroom(1).length`) === 3; });
  await tc('A5) الإخفاء يُحفظ بعد إعادة التحميل (الزائر ما زال لا يراه)', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); const g = asGuest(a); const g2 = asGuest(g); g2.R(`go('showrooms')`);
    return !g2.E.screen().includes(NAME1) && g2.R(`getVisibleShowrooms().some(s=>s.id===1)`) === false; });
  await tc('A6) إعادة اعتماد التاجر تعيد الظهور تلقائيًا (المعرض والسيارات) دون معرض مكرر', async () => {
    const a = mk('admin'); const n0 = a.R(`getShowrooms().length`); a.R('rejectDealer(1)'); a.R('approveDealer(1)'); const g = asGuest(a); g.R(`go('showrooms')`); const s = g.E.screen(); g.R(`go('cars')`);
    return s.includes(NAME1) && cardsIn(g.E.screen()) === 9 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && a.R(`getShowrooms().length`) === n0 && a.R(`getShowrooms().filter(s=>s.ownerId===1).length`) === 1; });
  await tc('A7) قواعد المعرض نفسها باقية: معرض موقوف + مالك أُعيد اعتماده = ما زال مخفيًا حتى يفعّله المدير', async () => {
    const a = mk('admin'); a.R('AdminService.suspendShowroom(1)'); a.R('rejectDealer(1)'); a.R('approveDealer(1)');
    const hidden = asGuest(a).R(`getVisibleShowrooms().some(s=>s.id===1)`) === false; a.R('AdminService.activateShowroom(1)');
    return hidden && asGuest(a).R(`getVisibleShowrooms().some(s=>s.id===1)`) === true; });
  await tc('A8) التاجر المرفوض يعامل كزائر: لا يرى معرضه ولا يديره ولا يدخل منطقة التاجر', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); const d = mk('dealer1', asGuest(a).E.store);   // محاولة دخول التاجر المرفوض
    return d.R(`SessionService.isLoggedIn()`) === false && d.R(`getVisibleShowrooms().some(s=>s.id===1)`) === false && d.R(`canViewShowroom(1)`) === false &&
      d.R(`AuthorizationService.canManageShowroom(1)`) === false && d.R(`AuthorizationService.canAccessDealerArea()`) === false; });
  await tc('A9) أي حالة حساب غير «active» (suspended/pending/disabled/rejected) تخفي معرض مالكها', async () => {
    const out = [];
    for (const st of ['suspended', 'pending', 'disabled', 'rejected']) {
      const x = mk(null, legacyStore(s => { s.overrides = { 2: { status: st } }; }));
      out.push(x.R(`getVisibleShowrooms().some(s=>s.id===2)`) === false && x.R(`getVisibleCars().some(c=>c.showroomId===2)`) === false &&
        x.R(`getShowroomById(2).status`) === 'active');
    }
    if (!out.every(Boolean)) console.log('   حالات الإخفاء [suspended,pending,disabled,rejected]:', JSON.stringify(out));
    return out.length === 4 && out.every(Boolean); });
  await tc('A10) مالك غير موجود في المستخدمين: لا حساب يُعلَّق فيبقى المعرض ظاهرًا (قرار موثّق، لا إخفاء بالتخمين)', async () => {
    const x = mk(null); x.R(`SHOWROOMS.push(ShowroomModel({ id: 77, name: 'Orphan Owner Showroom', status: 'active', ownerId: 9999 }))`);
    return x.R(`getVisibleShowrooms().some(s=>s.id===77)`) === true; });
  await tc('A11) التحقق يشمل كل الأسطح: البحث الموحّد وسيارات الأعضاء النشطة غير متأثرة (لا إخفاء أوسع من المطلوب)', async () => {
    const a = mk('admin'); const members = a.R(`getActiveMemberCars().length`); a.R('rejectDealer(2)'); const g = asGuest(a);
    return g.R(`getActiveMemberCars().length`) === members && members > 0 && g.R(`searchShowrooms('').length`) === 2 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && g.R(`getVisibleShowrooms().map(s=>s.id).join()`) === '1,4'; });

  /* ======================= B) المعرض التلقائي بلا تكرار ======================= */
  console.log('\n--- B) المعرض التلقائي ---');
  const owned = (x, id) => x.R(`getShowrooms().filter(s=>s.ownerId===${id}).length`);
  await tc('B1) اعتماد متكرر (5 مرات + دورات رفض/اعتماد + إعادة تحميل): معرض واحد فقط', async () => {
    const a = mk('admin'); const total0 = a.R(`getShowrooms().length`); const first = a.R('approveDealer(8)');
    a.R('approveDealer(8)'); a.R('approveDealer(8)'); a.R('rejectDealer(8)'); a.R('approveDealer(8)'); const b = mk('admin', a.E.store); b.R('approveDealer(8)'); b.R('rejectDealer(8)'); b.R('approveDealer(8)');
    return first.showroomCreated === true && owned(b, 8) === 1 && b.R(`getShowrooms().length`) === total0 + 1; });
  await tc('B2) تاجر لديه معرض (تجريبي): يُربط به ولا يُنشأ ثانٍ، وتُعاد نفس معرّفه', async () => {
    const a = mk('admin'); const n0 = a.R(`getShowrooms().length`); const r = a.R('approveDealer(2)');
    return r.ok && r.showroomCreated === false && r.showroom.id === 2 && a.R(`getShowrooms().length`) === n0 && owned(a, 2) === 1; });
  await tc('B3) تاجر لديه معرضان (تكرار قديم): الاعتماد لا يضيف ثالثًا ويربط بالأول', async () => {
    const x = mk('admin', legacyStore(s => { s.showrooms.push(Object.assign({}, s.showrooms[0], { id: 40, name: 'dup A', ownerId: 8, status: 'active' }), Object.assign({}, s.showrooms[0], { id: 41, name: 'dup B', ownerId: 8, status: 'active' })); }));
    const r = x.R('approveDealer(8)'); return r.ok && r.showroomCreated === false && r.showroom.id === 40 && owned(x, 8) === 2; });
  await tc('B4) مسح schemaVersion وإعادة التحميل (إعادة تشغيل الهجرة) لا تكرّر معرض التاجر', async () => {
    const a = mk('admin'); a.R('approveDealer(8)'); const s = a.E.store; delete s['najaf.schemaVersion']; const b = mk('admin', s); const c = mk('admin', b.E.store);
    return owned(c, 8) === 1; });
  await tc('B5) تاجران جديدان: معرضان مختلفان بمعرّفين فريدين، لكلٍّ معرض واحد', async () => {
    const n = mk(null); const r1 = n.R(`AuthService.register({name:'تاجر ا',phone:'07712345671',email:'',password:'secret1',confirmPassword:'secret1',accountType:'dealer'})`);
    n.R('AuthService.logout()'); const r2 = n.R(`AuthService.register({name:'تاجر ب',phone:'07712345672',email:'',password:'secret1',confirmPassword:'secret1',accountType:'dealer'})`);
    const a = mk('admin', n.E.store); a.R(`approveDealer(${r1.user.id})`); a.R(`approveDealer(${r2.user.id})`); a.R(`approveDealer(${r1.user.id})`);
    const ids = J(a, `getShowrooms().map(s=>s.id)`); return owned(a, r1.user.id) === 1 && owned(a, r2.user.id) === 1 && new Set(ids).size === ids.length; });
  await tc('B6) اعتماد مستخدم ليس تاجرًا أو غير موجود: خطأ بلا معرض', async () => {
    const a = mk('admin'); const n0 = a.R(`getShowrooms().length`); const r1 = a.R('approveDealer(7)'), r2 = a.R('approveDealer(9999)');
    return r1.ok === false && r2.ok === false && a.R(`getShowrooms().length`) === n0; });
  await tc('B7) فشل إنشاء المعرض: التاجر يعود لحالته السابقة (pending) ولا يبقى فعّالًا بلا معرض', async () => {
    const a = mk('admin'); a.R(`ShowroomsRepository.create = function () { return { ok: false, error: 'invalid_data' }; }`);
    const r = a.R('approveDealer(8)'); return r.ok === false && a.R(`UsersRepository.getById(8).status`) === 'pending' && owned(a, 8) === 0; });
  await tc('B8) غير المدير لا يعتمد ولا يُنشئ معرضًا (تاجر/مستخدم)', async () => {
    const d = mk('dealer1'); const r1 = d.R('approveDealer(8)'); const u = mk('user', d.E.store); const r2 = u.R('approveDealer(8)');
    return r1.ok === false && r2.ok === false && owned(u, 8) === 0 && u.R(`UsersRepository.getById(8).status`) === 'pending'; });
  await tc('B9) تاجر معرضه موقوف: الاعتماد يربط بمعرضه الموقوف (لا جديد) ويبقى مخفيًا حتى يفعّله المدير', async () => {
    const a = mk('admin'); a.R('AdminService.suspendShowroom(2)'); const n0 = a.R(`getShowrooms().length`); const r = a.R('approveDealer(2)');
    return r.ok && r.showroom.id === 2 && a.R(`getShowrooms().length`) === n0 && asGuest(a).R(`getVisibleShowrooms().some(s=>s.id===2)`) === false; });
  await tc('B10) التاجر المعتمد حديثًا يدخل لوحته ويدير معرضه بلا «لا يوجد معرض» حتى بعد دورة رفض/اعتماد', async () => {
    const a = mk('admin'); a.R('approveDealer(8)'); a.R('rejectDealer(8)'); a.R('approveDealer(8)'); const d = mk('pendingDealer', a.E.store); d.R(`go('dealerHome')`); const scr = d.E.screen();
    const c = await mkCar(d, { model: 'AfterCycle' }); return d.R('currentRoute') === 'dealerHome' && !scr.includes('لا يوجد معرض مرتبط بحسابك') && c.ok === true && d.R(`getMyShowroomCars().length`) === 1; });

  /* ======================= C) أمان تصادم المعرّفات القديمة ======================= */
  console.log('\n--- C) تصادم المعرّفات القديمة ---');
  const collision = () => legacyStore(s => {
    s.cars.push(car({ id: 101, model: 'ShowroomClash', mainImage: 'idb:900' }));
    s.images.push(img(900, 101, 'idb:900', 0, true), img(901, 101, 'idb:901', 1), img(902, 101, 'assets/member-cars/101_1.jpg', 2), img(903, 101, 'idb:903', 3));
    s.favs.push(fav(1, 101, '2026-09-29T10:00:00.000Z'), fav(2, 1, '2026-09-29T10:00:00.000Z'), fav(3, 101, '2026-09-30T10:00:00.000Z', 1), fav(4, 101, 'تاريخ تالف'));
  });
  await tc('C1) تصادم قديم: كل صورة مبهمة (لا مسار ولا صورة رئيسية تدل عليها) تُحذف بدل أن تلتصق بسيارة العضو', async () => {
    const x = mk(null, collision()); const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`); const ids = J(x, `CAR_IMAGES.map(i=>i.id)`);
    return sc.id !== 101 && !ids.includes(901) && !ids.includes(903) && ids.includes(900) && ids.includes(902); });
  await tc('C2) الصور المحسومة فقط تبقى مع سيارتها: الرئيسية تتبع سيارة المعرض (id الجديد)، ومسار الأعضاء مع سيارة العضو 101', async () => {
    const x = mk(null, collision()); const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`);
    return x.R(`CAR_IMAGES.find(i=>i.id===900).carId`) === sc.id && x.R(`CAR_IMAGES.find(i=>i.id===902).carId`) === 101 &&
      x.R(`CAR_IMAGES.filter(i=>i.carId===101).every(i=>i.imageUrl.indexOf('assets/member-cars/')===0)`) === true; });
  await tc('C3) المفضلة على المعرّف المتصادم تُحذف كلها (لأي مستخدم)، وغيرها تبقى، ولا شيء على المعرّف الجديد', async () => {
    const x = mk(null, collision()); const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`);
    return x.R(`FavoritesRepository.getAll().filter(f=>f.carId===101).length`) === 0 && x.R(`FavoritesRepository.getAll().filter(f=>f.carId===${sc.id}).length`) === 0 &&
      x.R(`FavoritesRepository.getAll().map(f=>f.id).join()`) === '2'; });
  await tc('C4) صورة مبهمة محذوفة لا تغيّر mainImage لسيارة لا تشير إليها (لا مسح بلا سبب)', async () => {
    const x = mk(null, legacyStore(s => { s.cars.push(car({ id: 101, model: 'ShowroomClash', mainImage: '' })); s.images.push(img(901, 101, 'idb:901', 0, true)); }));
    const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`); const m = J(x, `getMemberCarById(101)`);
    return sc.mainImage === '' && m.mainImage === 'assets/member-cars/101_1.jpg' && x.R(`CAR_IMAGES.some(i=>i.id===901)`) === false &&
      J(x, `CAR_IMAGES.filter(i=>i.carId===101).map(i=>i.id)`).join() === '31,32' && x.R(`CAR_IMAGES.filter(i=>i.carId===${sc.id}).length`) === 0; });   // 31,32 = صورتا سيارة العضو التجريبية فقط
  await tc('C5) صورة رئيسية متطابقة الرابط عند السيارتين = مبهمة: تُحذف ولا تُنسب لأيٍّ منهما', async () => {
    const x = mk(null, legacyStore(s => { s.cars.push(car({ id: 101, model: 'ShowroomClash', mainImage: 'idb:950' })); s.members.find(c => c.id === 101).mainImage = 'idb:950'; s.images.push(img(950, 101, 'idb:950', 0, true)); }));
    const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`); const m = J(x, `getMemberCarById(101)`);
    return x.R(`CAR_IMAGES.some(i=>i.id===950)`) === false && sc.mainImage === '' && m.mainImage === 'assets/member-cars/101_1.jpg'; });   // mainImage المشيرة للصورة المحذوفة تُصحَّح: لسيارة المعرض فارغ (لا صور)، ولسيارة العضو صورتها الرئيسية الباقية
  await tc('C6) تصادمان معًا (101 و102): كل منهما يُحل منفردًا، المعرّفات الجديدة فريدة وجديدة كليًا، والصور لا تنتقل بين الأزواج', async () => {
    const x = mk(null, legacyStore(s => {
      s.cars.push(car({ id: 101, model: 'ClashA', mainImage: 'idb:910' }), car({ id: 102, model: 'ClashB', mainImage: 'idb:920' }));
      s.images.push(img(910, 101, 'idb:910', 0, true), img(920, 102, 'idb:920', 0, true), img(921, 102, 'idb:921', 1)); }));
    const a = J(x, `getCars().find(c=>c.model==='ClashA')`), b = J(x, `getCars().find(c=>c.model==='ClashB')`);
    const all = J(x, `getCars().map(c=>c.id).concat(MemberCarsRepository.getAll().map(c=>c.id))`);
    return a.id !== b.id && new Set(all).size === all.length && x.R(`CAR_IMAGES.find(i=>i.id===910).carId`) === a.id && x.R(`CAR_IMAGES.find(i=>i.id===920).carId`) === b.id &&
      x.R(`CAR_IMAGES.some(i=>i.id===921)`) === false; });
  await tc('C7) صورة تناقض نوع سيارتها (مسار الأعضاء على سيارة معرض، أو مسار سيارة معرض بمعرّف آخر) تُحذف حتى بلا تصادم', async () => {
    const x = mk(null, legacyStore(s => { s.cars.push(car({ id: 16, model: 'L16' })); s.images.push(img(960, 16, 'assets/member-cars/101_1.jpg', 0, true), img(961, 6, 'assets/cars/5_1.jpg', 5)); }));
    const ids = J(x, `CAR_IMAGES.map(i=>i.id)`); return !ids.includes(960) && !ids.includes(961) && x.R(`CAR_IMAGES.find(i=>i.id===1).carId`) === 1; });
  await tc('C8) معرّف سيارة معرض سبق أن حمله إعلان عضو محذوف: مفضلة لا يثبت أنها أحدث من السيارة تُحذف، والأحدث تبقى', async () => {
    const x = mk(null, legacyStore(s => {
      s.deleted = [111]; s.cars.push(car({ id: 111, model: 'ReusedLedger', createdAt: '2026-09-10T10:00:00.000Z' }));
      s.favs.push(fav(1, 111, '2026-09-01T10:00:00.000Z'), fav(2, 111, 'غير صالح'), fav(3, 111, null), fav(4, 111, '2026-09-12T10:00:00.000Z')); }));
    return x.R(`FavoritesRepository.getAll().map(f=>f.id).join()`) === '4'; });
  await tc('C9) لا تصادم: لا مفضلة ولا صورة تُحذف (سيارات معارض وأعضاء سليمة)', async () => {
    const x = mk(null, legacyStore(s => { s.cars.push(car({ id: 16, model: 'Fine', createdAt: '2026-09-01T10:00:00.000Z' })); s.images.push(img(970, 16, 'idb:970', 0, true));
      s.favs.push(fav(1, 16, '2026-09-02T10:00:00.000Z'), fav(2, 101, '2026-09-02T10:00:00.000Z'), fav(3, 5, '2026-09-02T10:00:00.000Z')); }));
    return x.R(`FavoritesRepository.getAll().length`) === 3 && x.R(`CAR_IMAGES.length`) === 51 && x.R(`getCarById(16).model`) === 'Fine'; });
  await tc('C10) فحص السلامة يعمل في كل تحميل: تصادم موجود رغم schemaVersion=2 يُحل أيضًا (وبلا كتابة عند عدم وجوده)', async () => {
    const s = collision(); s['najaf.schemaVersion'] = '2'; const x = mk(null, s); const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`);
    const snap = JSON.stringify(x.E.store); const y = mk(null, x.E.store);
    return sc.id !== 101 && x.R(`CAR_IMAGES.some(i=>i.id===901)`) === false && JSON.stringify(y.E.store) === snap; });
  await tc('C11) تخزين بإصدار أحدث من التطبيق: لا هجرة ولا فحص سلامة ولا أي تعديل', async () => {
    const s = collision(); s['najaf.schemaVersion'] = '99'; const x = mk(null, s);
    return x.R(`CAR_IMAGES.some(i=>i.id===901)`) === true && x.R(`FavoritesRepository.getAll().length`) === 4 && x.E.store['najaf.schemaVersion'] === '99'; });
  await tc('C12) المُصدِر العام لم يتغيّر: معرّف المعرض الجديد أكبر من كل معرّف سيارة، والعدّاد محفوظ، وحذف التصادم لا يعيد إصدار معرّف', async () => {
    const x = mk(null, collision()); const sc = J(x, `getCars().find(c=>c.model==='ShowroomClash')`); const cnt = JSON.parse(x.E.store['najaf.idCounters']);
    const d = mk('dealer1', x.E.store); const n = await mkCar(d, { model: 'AfterClash' });
    return sc.id > 110 && cnt.car >= sc.id && n.car.id > sc.id; });
  await tc('C13) تقرير الهجرة يسجّل ما حُذف/نُقل (للتدقيق)', async () => {
    const x = mk(null, collision()); const r = J(x, `StorageSchema.lastReport`); const res = r && r.applied && r.applied[0] && r.applied[0].result;
    return !!res && res.collisions === 1 && Array.isArray(res.ambiguousImagesRemoved) && res.ambiguousImagesRemoved.sort().join() === '901,903' && res.favoritesRemoved >= 3; });

  /* ======================= D) أمان توحيد الماركة/الموديل ======================= */
  console.log('\n--- D) توحيد الماركة والموديل ---');
  const opt = (x, pool, crit) => J(x, `CarFilters.options(${pool}, ${JSON.stringify(crit || {})})`);
  await tc('D1) كل تباديل الحالة لماركة معروفة تعطي قيمة فلتر واحدة وعدًّا صحيحًا', async () => {
    const d = mk('dealer1'); for (const b of ['TOYOTA', 'toyota', 'tOYoTa', ' ToYoTa ', 'Toyota']) await mkCar(d, { brand: b, model: 'Cx' + Math.random() });
    const o = opt(d, 'getCars()'); const toy = o.brands.filter(b => /toyota/i.test(b.value)); return toy.length === 1 && toy[0].value === 'Toyota' && toy[0].count === 3 + 5; });
  await tc('D2) ماركة غير معروفة (zeekr) بأي حالة: قيمة واحدة، تُخزَّن بنفس الكتابة، وتبقى صالحة وقابلة للفلترة', async () => {
    const d = mk('dealer1'); const ids = [];
    for (const b of ['zeekr', 'ZEEKR', 'Zeekr ', 'zEEkR']) ids.push((await mkCar(d, { brand: b, model: 'Z' + ids.length })).car.id);
    const stored = new Set(ids.map(id => d.R(`getCarById(${id}).brand`))); const o = opt(d, 'getCars()'); const z = o.brands.filter(b => /zeekr/i.test(b.value));
    return stored.size === 1 && z.length === 1 && z[0].count === 4 && J(d, `CarFilters.apply(getCars(), {brand:'ZEEKR'}).map(c=>c.id)`).sort().join() === ids.slice().sort().join(); });
  await tc('D3) الكتابة تتبع ما في البيانات: bmw/Bmw → BMW (موجودة)، وماركة جديدة تُوحَّد بكتابة أول إدخال لها', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { brand: 'bmw' }), b = await mkCar(d, { brand: 'Bmw' }); const c = await mkCar(d, { brand: 'byd', model: 'A' }), e = await mkCar(d, { brand: 'BYD', model: 'B' });
    const first = d.R(`getCarById(${c.car.id}).brand`);
    return d.R(`getCarById(${a.car.id}).brand`) === 'BMW' && d.R(`getCarById(${b.car.id}).brand`) === 'BMW' && d.R(`getCarById(${e.car.id}).brand`) === first && first.toLowerCase() === 'byd'; });
  await tc('D4) بيانات قديمة غير موحّدة (toyota/TOYOTA/Toyota) تعطي قيمة فلتر واحدة قبل الهجرة وبعدها، والتجريبية لا تُلمس', async () => {
    const r = mk(null); r.R(`CarsRepository.create(CarModel({sourceType:'showroom',showroomId:1,brand:'toyota',model:'a',year:2031,price:5,status:'available'}))`);
    r.R(`CarsRepository.create(CarModel({sourceType:'showroom',showroomId:1,brand:'TOYOTA',model:'b',year:2032,price:5,status:'available'}))`);
    const before = opt(r, 'getCars()').brands.filter(b => /toyota/i.test(b.value));
    const x = mk(null, legacyStore(s => { s.cars.push(car({ id: 16, brand: 'toyota', model: 'corolla ' }), car({ id: 17, brand: 'TOYOTA', model: 'COROLLA' })); }));
    const o = opt(x, 'getCars()').brands.filter(b => /toyota/i.test(b.value));
    return before.length === 1 && o.length === 1 && o[0].count === 5 && x.R(`getCarById(16).brand`) === 'Toyota' && x.R(`getCarById(17).brand`) === 'Toyota' &&
      x.R(`getCarById(16).model`) === 'Corolla' && x.R(`getCarById(17).model`) === 'Corolla' && x.R(`getCarById(1).brand`) === 'Toyota'; });
  await tc('D5) حروف عريضة (ＴＯＹＯＴＡ) ومسافات غير مرئية ورموز اتجاه تُجمَّع مع Toyota', async () => {
    const d = mk('dealer1'); const v = ['ＴＯＹＯＴＡ', 'Toyota\u200f', 'Toy\u200bota', 'Toyota\u00a0', '\ufeffToyota'];
    const keys = v.map(s => d.R(`CarFilters.key(${JSON.stringify(s)})`)); const ids = [];
    for (const b of v) ids.push((await mkCar(d, { brand: b, model: 'W' + ids.length })).car.id);
    const o = opt(d, 'getCars()').brands.filter(b => /toyota/i.test(b.value)); return keys.every(k => k === 'toyota') && o.length === 1 && ids.every(id => d.R(`getCarById(${id}).brand`) === 'Toyota'); });
  await tc('D6) فروق الشرطة والمسافة (Mercedes-Benz / mercedes benz / MERCEDES  BENZ) تُجمَّع في قيمة واحدة', async () => {
    const d = mk('dealer1'); for (const b of ['Mercedes-Benz', 'mercedes benz', 'MERCEDES  BENZ', 'mercedes_benz']) await mkCar(d, { brand: b, model: 'C' + Math.random() });
    const o = opt(d, 'getCars()').brands.filter(b => /mercedes/i.test(b.value)); return o.length === 1 && o[0].count === 4; });
  await tc('D7) الموديلات: فروق الحالة تُدمج داخل الماركة نفسها، ولا تُدمج ولا تُنسخ كتابتها بين ماركتين مختلفتين', async () => {
    const d = mk('dealer1'); for (const m of ['corolla', 'COROLLA', 'Corolla ', 'cOROLLA']) await mkCar(d, { brand: 'Toyota', model: m });
    const toy = opt(d, 'getCars()', { brand: 'Toyota' }).models.filter(m => /corolla/i.test(m.value));
    await mkCar(d, { brand: 'Nissan', model: 'SUNNY' }); await mkCar(d, { brand: 'Kia', model: 'sunny' });
    const nis = opt(d, 'getCars()', { brand: 'Nissan' }).models.filter(m => /sunny/i.test(m.value)), kia = opt(d, 'getCars()', { brand: 'Kia' }).models.filter(m => /sunny/i.test(m.value));
    const a = await mkCar(d, { brand: 'Kia', model: 'ZX' }), b = await mkCar(d, { brand: 'Nissan', model: 'zx' });   // نفس المفتاح، ماركتان: كل ماركة تتبع بياناتها فقط
    return toy.length === 1 && toy[0].value === 'Corolla' && toy[0].count === 5 && nis.length === 1 && nis[0].count === 2 && kia.length === 1 && kia[0].count === 1 &&
      d.R(`getCarById(${a.car.id}).model`) === 'ZX' && d.R(`getCarById(${b.car.id}).model`) === 'Zx'; });
  await tc('D8) العربية: تُحفظ كما أُدخلت، وماركة عربية غير معروفة صالحة وقابلة للفلترة، وفروق الهمزة/التشكيل لا تنتج قيمتين', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { brand: 'زيكر', model: 'اكس' }); const b = await mkCar(d, { brand: 'أودي', model: 'ايه' }); const c = await mkCar(d, { brand: 'اودي', model: 'ايه ٤' }); const e = await mkCar(d, { brand: 'أَودِي', model: 'ايه' });
    const o = opt(d, 'getCars()'); const aud = o.brands.filter(x => x.key === 'اودي'); const z = o.brands.filter(x => x.value === 'زيكر');
    return d.R(`getCarById(${a.car.id}).brand`) === 'زيكر' && z.length === 1 && aud.length === 1 && aud[0].count === 3 && J(d, `CarFilters.apply(getCars(), {brand:'زيكر'}).length`) === 1; });
  await tc('D9) ماركة بلا أي حرف/رقم (--- أو ###) تُرفض برسالة عربية في سيارة المعرض والعضو والتعديل', async () => {
    const d = mk('dealer1'); const r1 = await mkCar(d, { brand: '---' }); const r2 = d.R(`createDraftMemberCar({brand:'###',model:'x',year:2020,price:1000,phone:'07701234567'})`);
    const ok = await mkCar(d, { brand: 'Kia', model: 'Fine' }); const r3 = d.R(`updateShowroomCar(${ok.car.id},{brand:'!!!'})`); const r4 = await mkCar(d, { brand: 'Kia', model: '...' });
    return r1.ok === false && r2.ok === false && r3.ok === false && r4.ok === false && /[\u0600-\u06FF]/.test(r1.error) && d.R(`getCarById(${ok.car.id}).brand`) === 'Kia'; });
  await tc('D10) لا قاموس ماركات كبير مُشفَّر في الكود: لا _KNOWN_BRANDS ولا _EXTRA_ALIASES ولا أسماء ماركات حرفية', async () => {
    const src = fs.readFileSync(path.join(ROOT, 'services/carFilterService.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
    const names = ['Toyota', 'Hyundai', 'Chevrolet', 'Mitsubishi', 'Volkswagen', 'Mercedes', 'Nissan', 'Genesis', 'Lexus', 'Peugeot', 'Renault', 'Porsche'];
    const found = names.filter(n => src.includes(n)); if (found.length) console.log('   أسماء ماركات حرفية في المحرك:', found.join(','));
    return !/_KNOWN_BRANDS|_EXTRA_ALIASES|_KEY_FIX|_KNOWN_BY_KEY/.test(src) && found.length === 0; });
  await tc('D11) قيمة خيار الفلتر تصفّي كل كتابات الماركة (الاختيار من القائمة → كل المتغيرات)', async () => {
    const r = mk(null); ['toyota', 'TOYOTA'].forEach((b, i) => r.R(`CarsRepository.create(CarModel({sourceType:'showroom',showroomId:1,brand:'${b}',model:'q${i}',year:2031,price:5,status:'available'}))`));
    const v = opt(r, 'getCars()').brands.find(b => /toyota/i.test(b.value)).value; return J(r, `CarFilters.apply(getCars(), {brand:${JSON.stringify(v)}}).length`) === 5; });
  await tc('D12) تعديل الموديل وحده يتبع كتابة ماركة السيارة نفسها (COROLLA على تويوتا → Corolla)', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { brand: 'Toyota', model: 'Avalon' }); d.R(`updateShowroomCar(${a.car.id},{model:'COROLLA'})`);
    const m = d.R(`createDraftMemberCar({brand:'Toyota',model:'Camry',year:2020,price:1000,phone:'07701234567'})`); d.R(`updateMemberCar(${m.car.id},{model:'cAMRY'})`);
    return d.R(`getCarById(${a.car.id}).model`) === 'Corolla' && d.R(`getMemberCarById(${m.car.id}).model`) === 'Camry'; });
  await tc('D13) الكتابة الموحَّدة تُحفظ بعد إعادة التحميل ولا تعيد ظهور نسخة ثانية في الفلتر', async () => {
    const d = mk('dealer1'); await mkCar(d, { brand: 'zeekr', model: 'Zx' }); await mkCar(d, { brand: 'ZEEKR', model: 'Zy' }); const b = mk('dealer1', d.E.store);
    const z = opt(b, 'getCars()').brands.filter(x => /zeekr/i.test(x.value)); return z.length === 1 && z[0].count === 2; });
  await tc('D14) هجرة الأسماء idempotent ولا تلمس سجلات المستخدم التي اختلفت مفاتيحها (ماركتان مختلفتان تبقيان مختلفتين)', async () => {
    const s = legacyStore(st => { st.cars.push(car({ id: 16, brand: 'Kia', model: 'x' }), car({ id: 17, brand: 'Kio', model: 'x' })); });
    const a = mk(null, s); const snap = JSON.stringify(a.E.store); const b = mk(null, a.E.store);
    return a.R(`getCarById(16).brand`) === 'Kia' && a.R(`getCarById(17).brand`) === 'Kio' && JSON.stringify(b.E.store) === snap; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

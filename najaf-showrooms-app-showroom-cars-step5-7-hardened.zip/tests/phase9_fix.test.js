/* اختبارات «المرحلة 9 — إصلاح/تدقيق» (Phase 9 Fix/Audit).
   كُتبت قبل الإصلاح لإثبات كل مشكلة (تفشل على الكود القديم)، ثم تمر بعد الإصلاح.
   «إعادة تحميل» = بيئة جديدة كليًا (makeEnv) بنفس التخزين المحلي، كما يحدث في المتصفح.
   الأقسام: 1 المعرّفات · 2 الهجرة · 3 المحوّل · 4 ImageStore · 5 hydrate/seed ·
            6 الفلاتر · 7 إيقاف المعرض · 8 معرض التاجر · 9 فحوص ثابتة */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يشغّل الاختبار ويحوّل أي استثناء إلى فشل (حتى لا يسقط الملف على كود لم يُصلَح بعد) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, !!r, r === false ? '' : (typeof r === 'object' ? JSON.stringify(r) : '')); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 140)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer2: ['07709876543', 'dealer123'],
  dealer5: ['07715558899', 'dealer123'], pendingDealer: ['07733445566', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const reload = (x, role) => mk(role || null, x.E.store);
/** زائر حقيقي بنفس التخزين: الجلسة المحفوظة تبقى بعد إعادة التحميل، فنخرج منها صراحةً */
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const quotaErr = () => { const e = new Error('The quota has been exceeded.'); e.name = 'QuotaExceededError'; return e; };
const cardsIn = html => (String(html).match(/class="card car-card"/g) || []).length;
const showroomCardsIn = html => (String(html).match(/class="card showroom-card"/g) || []).length;

/* ---- codec وهمي + IndexedDB وهمي ---- */
let _n = 0;
const mkFile = (w = 800, h = 600) => ({ name: 'p' + (++_n) + '.jpg', type: 'image/jpeg', size: w * h * 3, width: w, height: h, complexity: 1 });
const mkCodec = () => ({ decode: async f => ({ width: f.width, height: f.height, complexity: 1, close() {} }),
  encode: async (d, w, h, mime, q) => ({ type: mime, size: Math.round(w * h * q * 0.2), compressed: true }) });
function fakeIdb({ failPut = false, blobs = {} } = {}) {
  const mkReq = fn => { const r = {}; Promise.resolve().then(() => { try { r.result = fn(); r.onsuccess && r.onsuccess(); } catch (e) { r.error = e; r.onerror && r.onerror(); } }); return r; };
  const store = {
    put: (blob, id) => mkReq(() => { if (failPut) throw quotaErr(); blobs[id] = blob; return id; }),
    delete: id => mkReq(() => { delete blobs[id]; }),
    getAllKeys: () => mkReq(() => Object.keys(blobs).map(Number)), getAll: () => mkReq(() => Object.values(blobs)),
  };
  const db = { transaction: () => ({ objectStore: () => store }), createObjectStore() {} };
  return { open: () => { const r = {}; Promise.resolve().then(() => { r.result = db; r.onsuccess && r.onsuccess(); }); return r; }, blobs };
}
const mkCar = async (x, o = {}) => (await x.R(`createShowroomCar(${JSON.stringify(Object.assign({ brand: 'Kia', model: 'Fx', year: 2020, price: 1000 }, o))})`));

/** يبني تخزينًا بصيغة «ما قبل الإصلاح» (بلا idCounters ولا schemaVersion ولا seedIds) من بيانات تجريبية + تعديلات */
function legacyStore(mutate) {
  const E0 = makeEnv(), J = c => JSON.parse(E0.run(`JSON.stringify(${c})`));
  const st = { cars: J('CARS'), members: J('MEMBER_CARS'), images: J('CAR_IMAGES'), showrooms: J('SHOWROOMS'), favs: [] };
  mutate(st);
  const store = {};
  store['najaf.showroomCars'] = JSON.stringify(st.cars); store['najaf.memberCars'] = JSON.stringify(st.members);
  store['najaf.carImages'] = JSON.stringify(st.images); store['najaf.favorites'] = JSON.stringify(st.favs);
  store['najaf.memberCarsDeleted'] = JSON.stringify([]);
  if (st.showrooms) store['najaf.showrooms'] = JSON.stringify(st.showrooms);
  return store;
}
const car = (o) => Object.assign({ sourceType: 'showroom', showroomId: 1, brand: 'Kia', model: 'Legacy', year: 2020, price: 1000, mileage: 5000,
  transmission: 'أوتوماتيك', fuelType: 'بنزين', color: '', description: '', status: 'available', mainImage: '', createdAt: '2026-09-01T10:00:00.000Z', updatedAt: '2026-09-01T10:00:00.000Z' }, o);

(async () => {
  {
    const { E } = mk(null);
    t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | '));
  }

  /* ======================= 1) المعرّفات (C1) + تنظيف المفضلة ======================= */
  console.log('\n--- 1) المعرّفات ---');
  await tc('1a) حذف آخر سيارة معرض ثم إضافة أخرى: المعرّف لا يُعاد', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'IdA' }); await d.R(`deleteShowroomCar(${a.car.id})`);
    const b = await mkCar(d, { model: 'IdB' }); return b.car.id > a.car.id; });
  await tc('1b) …ويبقى كذلك بعد إعادة التحميل (عدّاد محفوظ لا مشتق من الموجود)', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'IdA' }); await d.R(`deleteShowroomCar(${a.car.id})`);
    const d2 = reload(d, 'dealer1'); const b = await mkCar(d2, { model: 'IdB' }); return b.car.id > a.car.id; });
  await tc('1c) سيارات المعارض والأعضاء تتشاركان تسلسلًا واحدًا: لا معرّف في القائمتين معًا', async () => {
    const d = mk('dealer1');
    for (let i = 0; i < 3; i++) { await mkCar(d, { model: 'S' + i }); d.R(`createDraftMemberCar({brand:'Kia',model:'M${i}',year:2020,price:1000,phone:'07701234567'})`); }
    const ids = JSON.parse(d.R(`JSON.stringify({c:getCars().map(x=>x.id), m:MemberCarsRepository.getAll().map(x=>x.id)})`));
    return ids.c.filter(i => ids.m.includes(i)).length === 0 && new Set(ids.c.concat(ids.m)).size === ids.c.length + ids.m.length; });
  await tc('1d) 86 سيارة معرض جديدة: لا تصادم مع سيارة العضو 101 (كان يتصادم)', async () => {
    const d = mk('dealer1'); for (let i = 0; i < 86; i++) await mkCar(d, { model: 'Bulk' + i });
    const ids = JSON.parse(d.R(`JSON.stringify({c:getCars().map(x=>x.id), m:MemberCarsRepository.getAll().map(x=>x.id)})`));
    return ids.c.filter(i => ids.m.includes(i)).length === 0 && d.R(`getCarById(101).sourceType`) === 'member'; });
  await tc('1e) معرّف سيارة عضو محذوفة لا يُعاد ولا يتصادم مع سيارة معرض', async () => {
    const d = mk('dealer1'); const r = d.R(`createDraftMemberCar({brand:'Kia',model:'MDel',year:2020,price:1000,phone:'07701234567'})`);
    d.R(`deleteMemberCar(${r.car.id})`); const s = await mkCar(d, { model: 'AfterDel' });
    const m = d.R(`createDraftMemberCar({brand:'Kia',model:'MNew',year:2020,price:1000,phone:'07701234567'})`);
    return s.car.id !== r.car.id && m.car.id !== r.car.id && m.car.id !== s.car.id; });
  await tc('1f) مفضلة قديمة لا ترتبط بسيارة جديدة (المعرّف لا يُعاد)', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'OLD' });
    const u = mk('user', d.E.store); u.R(`toggleFavorite(${a.car.id})`);
    const d2 = mk('dealer1', u.E.store); await d2.R(`deleteShowroomCar(${a.car.id})`); const b = await mkCar(d2, { brand: 'BMW', model: 'NEW' });
    const u2 = mk('user', d2.E.store); return u2.R(`getFavoriteCars().length`) === 0 && u2.R(`isFavorite(${b.car.id})`) === false; });
  await tc('1g) حذف سيارة المعرض ينظّف سجلات المفضلة لكل المستخدمين', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'FavDel' });
    const u = mk('user', d.E.store); u.R(`toggleFavorite(${a.car.id})`);
    const adm = mk('admin', u.E.store); adm.R(`toggleFavorite(${a.car.id})`);
    const d2 = mk('dealer1', adm.E.store); await d2.R(`deleteShowroomCar(${a.car.id})`);
    return d2.R(`FavoritesRepository.getAll().filter(f=>f.carId===${a.car.id}).length`) === 0 &&
      JSON.parse(d2.E.store['najaf.favorites']).filter(f => f.carId === a.car.id).length === 0; });
  await tc('1h) حذف سيارة عضو ينظّف مفضلتها أيضًا', async () => {
    const d = mk('dealer1'); const m = d.R(`createDraftMemberCar({brand:'Kia',model:'MFav',year:2020,price:1000,phone:'07701234567'})`);
    const u = mk('user', d.E.store); u.R(`toggleFavorite(${m.car.id})`);
    const d2 = mk('dealer1', u.E.store); d2.R(`deleteMemberCar(${m.car.id})`);
    return d2.R(`FavoritesRepository.getAll().filter(f=>f.carId===${m.car.id}).length`) === 0; });
  await tc('1i) سلبي: حذف مرفوض (غير المالك) لا يمسّ المفضلة', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'Keep' });
    const u = mk('user', d.E.store); u.R(`toggleFavorite(${a.car.id})`);
    const d2 = mk('dealer2', u.E.store); const del = await d2.R(`deleteShowroomCar(${a.car.id})`);
    return del.ok === false && d2.R(`FavoritesRepository.getAll().filter(f=>f.carId===${a.car.id}).length`) === 1; });
  await tc('1j) صور السيارة المحذوفة تُحذف ولا ترتبط بسيارة جديدة', async () => {
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); const a = await mkCar(d, { model: 'WithImg' });
    const add = await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`);
    await d.R(`deleteShowroomCar(${a.car.id})`); const b = await mkCar(d, { model: 'Fresh' });
    return add.ok === true && d.R(`CAR_IMAGES.filter(i=>i.carId===${a.car.id}).length`) === 0 && d.R(`getCarImages(${b.car.id}).length`) === 0 && b.car.id !== a.car.id; });
  await tc('1k) معرّف الصورة لا يُعاد بعد حذف آخر صورة', async () => {
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); const a = await mkCar(d, { model: 'ImgId' });
    const i1 = await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`); await d.R(`removeCarImage(${i1.image.id})`);
    const i2 = await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`); return i2.image.id > i1.image.id; });
  await tc('1l) العدّادات تُحفظ تحت najaf.idCounters وتغطي أعلى معرّف صدر', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'Cnt' });
    const c = JSON.parse(d.E.store['najaf.idCounters'] || 'null'); return !!c && c.car >= a.car.id; });

  /* ======================= 2) الهجرة + schema version ======================= */
  console.log('\n--- 2) الهجرة ---');
  await tc('2a) تخزين قديم فيه تصادم (سيارة معرض 101 = سيارة عضو 101): يُحلّ دون فقد بيانات', async () => {
    const store = legacyStore(s => {
      s.cars.push(car({ id: 101, model: 'ShowroomClash', mainImage: 'idb:900' }));
      s.images.push({ id: 900, carId: 101, imageUrl: 'idb:900', sortOrder: 0, isMain: true }, { id: 901, carId: 101, imageUrl: 'idb:901', sortOrder: 1, isMain: false });
      s.favs.push({ id: 1, userId: 7, carId: 101, createdAt: '2026-09-29T10:00:00.000Z' });
    });
    const x = mk(null, store); const J = c => JSON.parse(x.R(`JSON.stringify(${c})`));
    const moved = J(`getCars().find(c=>c.model==='ShowroomClash')`); const m101 = J(`getMemberCarById(101)`);
    const ids = J(`{c:getCars().map(x=>x.id), m:MemberCarsRepository.getAll().map(x=>x.id)}`);
    return moved && moved.id !== 101 && m101.model === 'Corolla' && ids.c.filter(i => ids.m.includes(i)).length === 0 &&
      J(`CAR_IMAGES.find(i=>i.id===900).carId`) === moved.id && J(`CAR_IMAGES.some(i=>i.id===901)`) === false /* التحصين النهائي: الصورة المبهمة تُحذف بدل أن تبقى مع سيارة العضو 101 (كانت تبقى) */ &&
      J(`FavoritesRepository.getAll().filter(f=>f.carId===101).length`) === 0; });
  await tc('2b) تخزين قديم بلا عدّادات: مراجع يتيمة لا يُعاد إصدار معرّفها', async () => {
    const store = legacyStore(s => { s.cars.push(car({ id: 16, model: 'L16' })); s.favs.push({ id: 1, userId: 7, carId: 40, createdAt: '2026-09-02T10:00:00.000Z' }); });
    const d = mk('dealer1', store); const b = await mkCar(d, { model: 'Next' }); return b.car.id > 40; });
  await tc('2c) مفضلة يتيمة تُنظَّف؛ وقديمة سبقت إنشاء السيارة (معرّف أُعيد) تُنظَّف؛ والسليمة والتجريبية تبقى', async () => {
    const store = legacyStore(s => {
      s.cars.push(car({ id: 16, model: 'L16', createdAt: '2026-09-10T10:00:00.000Z' }));
      s.favs.push({ id: 1, userId: 7, carId: 16, createdAt: '2026-08-01T10:00:00.000Z' },   // سبقت السيارة → قديمة
                  { id: 2, userId: 7, carId: 777, createdAt: '2026-09-11T10:00:00.000Z' },   // يتيمة
                  { id: 3, userId: 7, carId: 16, createdAt: '2026-09-12T10:00:00.000Z' },   // سليمة
                  { id: 4, userId: 7, carId: 1, createdAt: '2025-12-01T10:00:00.000Z' });    // سيارة تجريبية (تاريخها ثابت) تبقى
    });
    const x = mk(null, store); const fav = JSON.parse(x.R(`JSON.stringify(FavoritesRepository.getAll().map(f=>f.id))`));
    return JSON.stringify(fav.sort()) === JSON.stringify([3, 4]); });
  await tc('2d) صور يتيمة (سيارتها غير موجودة) تُحذف وصور السيارات الموجودة تبقى', async () => {
    const store = legacyStore(s => { s.images.push({ id: 950, carId: 888, imageUrl: 'idb:950', sortOrder: 0, isMain: true }); });
    const x = mk(null, store); return x.R(`CAR_IMAGES.some(i=>i.id===950)`) === false && x.R(`CAR_IMAGES.length`) === 50; });
  await tc('2e) schemaVersion: يُكتب 3 (الهجرة 3: createdAt UTC)، و StorageSchema.CURRENT_VERSION = 3', async () => {
    const x = mk(null, legacyStore(() => {})); return x.E.store['najaf.schemaVersion'] === '3' && x.R('StorageSchema.CURRENT_VERSION') === 3; });
  await tc('2f) تخزين بإصدار أحدث من التطبيق: لا هجرة ولا خفض للإصدار', async () => {
    const store = legacyStore(s => { s.favs.push({ id: 1, userId: 7, carId: 777, createdAt: '2026-09-11T10:00:00.000Z' }); }); store['najaf.schemaVersion'] = '99';
    const x = mk(null, store); return x.E.store['najaf.schemaVersion'] === '99' && x.R(`FavoritesRepository.getAll().length`) === 1; });
  await tc('2g) الهجرة idempotent: إعادة التحميل لا تغيّر التخزين', async () => {
    const store = legacyStore(s => { s.cars.push(car({ id: 101 })); s.favs.push({ id: 1, userId: 7, carId: 777, createdAt: '2026-09-11T10:00:00.000Z' }); });
    const a = mk(null, store); const snap1 = JSON.stringify(a.E.store); const b = mk(null, a.E.store); return JSON.stringify(b.E.store) === snap1; });
  await tc('2h) مسافة 0 في سجل قديم غير تجريبي تصبح «غير معروفة» (null)، والتجريبية والقيم الحقيقية تبقى', async () => {
    const store = legacyStore(s => { s.cars.push(car({ id: 16, model: 'Z0', mileage: 0 }), car({ id: 17, model: 'Z5', mileage: 5000 })); });
    const x = mk(null, store); return x.R(`getCarById(16).mileage`) === null && x.R(`getCarById(17).mileage`) === 5000 && x.R(`getCarById(1).mileage`) === 65000; });
  await tc('2i) كتابات الماركة/الموديل القديمة تُوحَّد في السجلات المخزّنة (toyota → Toyota) دون مساس بالتجريبية', async () => {
    const store = legacyStore(s => { s.cars.push(car({ id: 16, brand: 'toyota', model: 'corolla ' }), car({ id: 17, brand: 'TOYOTA', model: 'COROLLA' })); });
    const x = mk(null, store); return x.R(`getCarById(16).brand`) === 'Toyota' && x.R(`getCarById(16).model`) === 'Corolla' && x.R(`getCarById(17).brand`) === 'Toyota' && x.R(`getCarById(1).brand`) === 'Toyota'; });

  await tc('2j) فشل استعادة أي مستودع يوقف الهجرات؛ وبوجود فشل لا تُحذف صور يتيمة (حالة غير معروفة)', async () => {
    const x = mk(null); x.R(`CarImagesRepository.create({id:950,carId:888,imageUrl:'idb:950',sortOrder:0,isMain:true})`);
    const skipped = x.R(`runStorageMigrations({failed:['cars']})`);
    x.R(`SchemaRepository.setVersion(1)`); x.E.ctx.__ctx = { hydrateFailed: ['cars'] };
    const rep = x.R(`StorageSchema.run(__ctx)`);
    return skipped.skipped === 'hydrate_failed' && x.R(`CAR_IMAGES.some(i=>i.id===950)`) === true && rep.applied[0].result.imagesRemoved === 'skipped'; });
  await tc('2k) هجرة فاشلة لا تُسقط التطبيق ولا ترفع الإصدار، وتُعاد في التحميل التالي', async () => {
    const x = mk(null); x.R(`StorageSchema.register(4, 'boom', () => { throw new Error('x'); })`);
    x.R(`SchemaRepository.setVersion(3)`); const real = x.E.ctx.console.error; x.E.ctx.console.error = () => {};
    // CURRENT_VERSION ثابت = 3: الهجرة 4 خارج النطاق فلا تُنفَّذ (لا تُسقط شيئًا) — (كانت 3 فصارت حقيقية في الجزء 7؛ فشل الهجرة 3 الفعلي مُختبَر في created_at_utc.test.js)
    const rep = x.R(`StorageSchema.run({})`); x.E.ctx.console.error = real;
    return rep.failed === null && rep.to === 3 && x.E.store['najaf.schemaVersion'] === '3'; });

  /* ======================= 3) محوّل التخزين: أسبقية القراءة (C2) ======================= */
  console.log('\n--- 3) المحوّل ---');
  await tc('3a) فشل الكتابة (quota): القراءة تعيد أحدث قيمة في الذاكرة لا القديمة من localStorage', async () => {
    const { E, R } = mk(null); R(`AppStorage.set('k', {v:1})`);
    E.ctx.localStorage.setItem = () => { throw quotaErr(); };
    const r = R(`AppStorage.set('k', {v:2})`); return r.ok === false && R(`AppStorage.get('k').v`) === 2; });
  await tc('3b) فشل الحذف: القراءة بعده تعيد القيمة الاحتياطية وليس النسخة القديمة، والمفتاح غائب عن keys()', async () => {
    const { E, R } = mk(null); R(`AppStorage.set('k2', {v:1})`); E.ctx.localStorage.removeItem = () => { throw new Error('denied'); };
    R(`AppStorage.remove('k2')`); return R(`AppStorage.get('k2', 'FB')`) === 'FB' && !R(`AppStorage.keys()`).includes('k2'); });
  await tc('3c) بعد عودة التخزين ونجاح كتابة جديدة: القراءة من التخزين الفعلي', async () => {
    const { E, R } = mk(null); R(`AppStorage.set('k3', 1)`); const real = E.ctx.localStorage.setItem; E.ctx.localStorage.setItem = () => { throw quotaErr(); };
    R(`AppStorage.set('k3', 2)`); E.ctx.localStorage.setItem = real; R(`AppStorage.set('k3', 3)`);
    return R(`AppStorage.get('k3')`) === 3 && E.store['najaf.k3'] === '3'; });
  await tc('3d) الجلسة: دخول المدير مع امتلاء التخزين وجلسة مستخدم سابقة → المستخدم الحالي المدير', async () => {
    const a = mk('user'); a.E.ctx.localStorage.setItem = () => { throw quotaErr(); };
    a.R(`AuthService.login('07700000000','admin123')`); return a.R('SessionService.getCurrentUser().role') === 'admin'; });
  await tc('3e) الجلسة: logout مع فشل removeItem يُخرج المستخدم فعلًا', async () => {
    const a = mk('user'); a.E.ctx.localStorage.removeItem = () => { throw new Error('denied'); };
    a.R('AuthService.logout()'); return a.R('SessionService.getCurrentUser()') === null; });
  await tc('3f) سلوك قائم لم يتغيّر: JSON تالف → fallback، وvalidate يرفض الشكل الخاطئ', async () => {
    const { E, R } = mk(null); E.store['najaf.bad'] = '{oops'; return R(`AppStorage.get('bad','FB')`) === 'FB' && R(`(AppStorage.set('a2',{x:1}), AppStorage.get('a2','FB',Array.isArray))`) === 'FB'; });

  /* ======================= 4) ImageStore (C3) ======================= */
  console.log('\n--- 4) ImageStore ---');
  await tc('4a) فشل حفظ IndexedDB: لا سجل صورة ولا idb:<id> ولا تغيير في mainImage', async () => {
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); d.E.ctx.indexedDB = fakeIdb({ failPut: true });
    const a = await mkCar(d, { model: 'IdbFail' }); const r = await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`);
    return r.ok === false && typeof r.error === 'string' && d.R(`getCarImages(${a.car.id}).length`) === 0 && !String(d.R(`getCarById(${a.car.id}).mainImage`)).startsWith('idb:'); });
  await tc('4b) فشل الحفظ لا يترك blob في الذاكرة', async () => {
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); d.E.ctx.indexedDB = fakeIdb({ failPut: true });
    const a = await mkCar(d, { model: 'IdbFail2' }); await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`);
    return d.R(`Object.keys(CAR_IMAGES).length`) === 50 && d.R(`ImageStore.has(51)`) === false; });
  await tc('4c) نجاح IndexedDB: سجل الصورة يُنشأ والـ blob يُخزَّن فعلًا', async () => {
    const idb = fakeIdb(); const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); d.E.ctx.indexedDB = idb;
    const a = await mkCar(d, { model: 'IdbOk' }); const r = await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`);
    return r.ok === true && r.image.imageUrl === 'idb:' + r.image.id && Object.keys(idb.blobs).length === 1; });
  await tc('4d) مسودة الصور عند إنشاء سيارة مع فشل IndexedDB: تُنشأ السيارة بلا صور وتُخبَر الواجهة', async () => {
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); d.E.ctx.indexedDB = fakeIdb({ failPut: true });
    const draft = d.R('createImageDraft(5)'); await draft.add(mkFile());
    d.E.ctx.__draft = draft; const r = await d.R(`createShowroomCar({brand:'Kia',model:'DraftFail',year:2020,price:1000}, __draft)`);
    return r.ok === true && r.imagesAdded === 0 && r.imagesFailed === 1 && d.R(`getCarImages(${r.car.id}).length`) === 0; });
  await tc('4e) عقد ImageStore.put: {ok:false} عند الفشل و{ok:true} عند النجاح', async () => {
    const a = mk(null); a.E.ctx.indexedDB = fakeIdb({ failPut: true }); const bad = await a.R(`ImageStore.put(9001, {x:1})`);
    const b = mk(null); b.E.ctx.indexedDB = fakeIdb(); const good = await b.R(`ImageStore.put(9002, {x:1})`);
    return bad && bad.ok === false && good && good.ok === true; });
  await tc('4f) بلا IndexedDB (وضع الذاكرة): الإضافة تعمل كما كانت (لا انحدار)', async () => {
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec()); const a = await mkCar(d, { model: 'MemOnly' });
    const r = await d.R(`addCarImage(${a.car.id}, ${JSON.stringify(mkFile())})`); return r.ok === true && d.R(`getCarImages(${a.car.id}).length`) === 1; });

  /* ======================= 5) hydrate / بيانات تجريبية ======================= */
  console.log('\n--- 5) hydrate ---');
  await tc('5a) تشغيل أول بلا بيانات: يكتب علامتي الترحيل فقط (schemaVersion وسجل المحذوفات الفارغ) ولا شيء غيرهما', async () => {
    const { E } = mk(null); const keys = Object.keys(E.store).sort(); return JSON.stringify(keys) === JSON.stringify(['najaf.memberCarsDeleted', 'najaf.schemaVersion']) && E.store['najaf.memberCarsDeleted'] === '[]'; });
  await tc('5b) hydrate مرتين = الحالة نفسها بلا كتابات جديدة', async () => {
    const d = mk('dealer1'); await mkCar(d, { model: 'Twice' }); const before = JSON.stringify(d.E.store); d.R('hydrateRepositories()'); d.R('hydrateRepositories()');
    return JSON.stringify(d.E.store) === before && d.R(`getCars().filter(c=>c.model==='Twice').length`) === 1; });
  await tc('5c) سياسة المصفوفة الفارغة موحّدة: معارض [] تُتجاهل، وسيارات/صور/مفضلة [] تُحترم', async () => {
    const x = mk(null, { 'najaf.showrooms': '[]', 'najaf.showroomCars': '[]', 'najaf.carImages': '[]', 'najaf.favorites': '[]' });
    return x.R(`getShowrooms().length`) === 5 && x.R(`getCars().length`) === 0 && x.R(`CAR_IMAGES.length`) === 0 && x.R(`FavoritesRepository.getAll().length`) === 0; });
  await tc('5d) السياسة موثّقة في الكود: emptyIsValid لكل مستودع', async () => {
    const x = mk(null); return x.R(`[ShowroomsRepository.emptyIsValid, CarsRepository.emptyIsValid, CarImagesRepository.emptyIsValid, FavoritesRepository.emptyIsValid].join()`) === 'false,true,true,true'; });
  await tc('5e) C6: سيارة/معرض تجريبي جديد (لم يكن في لقطة البذور) يظهر لمن حفظ سابقًا، والمحذوف والمعدَّل يبقيان', async () => {
    const d = mk('dealer1'); await mkCar(d, { model: 'Base' });                  // يكتب showroomCars و seedIds
    const s = d.E.store, cars = JSON.parse(s['najaf.showroomCars']), snap = JSON.parse(s['najaf.seedIds']);
    const c13 = cars.find(c => c.id === 13); c13.price = 123456;                 // تعديل مستخدم يبقى
    s['najaf.showroomCars'] = JSON.stringify(cars.filter(c => c.id !== 15 && c.id !== 14));   // 15: «جديد»، 14: حذفه المستخدم
    snap.cars = snap.cars.filter(i => i !== 15);                                   // اللقطة القديمة لم تكن تعرف 15
    const shows = JSON.parse(s['najaf.showrooms'] || 'null'); s['najaf.seedIds'] = JSON.stringify(snap);
    const x = mk(null, s);
    return x.R(`getCarById(15) && getCarById(15).id`) === 15 && x.R(`getCarById(14)`) === undefined && x.R(`getCarById(13).price`) === 123456 &&
      x.R(`getCars().filter(c=>c.model==='Base').length`) === 1; });
  await tc('5f) لقطة البذور التالفة تُعامل كقديمة (لا استثناء ولا إضافة خاطئة)', async () => {
    const d = mk('dealer1'); await mkCar(d, { model: 'Base2' }); d.E.store['najaf.seedIds'] = '"oops"'; const x = mk(null, d.E.store);
    return x.E.errors.length === 0 && x.R(`getCars().length`) === 16; });

  /* ======================= 6) الفلاتر (C4) ======================= */
  console.log('\n--- 6) الفلاتر ---');
  await tc('6a) توحيد الماركة: toyota/TOYOTA/ Toyota → Toyota، و bmw → BMW، والاسم العربي محفوظ', async () => {
    const x = mk(null); const c = v => x.R(`CarFilters.canonicalBrand(${JSON.stringify(v)})`);
    return c('toyota') === 'Toyota' && c('TOYOTA') === 'Toyota' && c('  Toyota  ') === 'Toyota' && c('bmw') === 'BMW' && c('mercedes benz') === 'Mercedes Benz' /* التحصين النهائي: لا قاموس ماركات مُشفَّر (كانت Mercedes-Benz من القاموس)؛ الماركة غير الموجودة في البيانات تُوحَّد بحالة أحرف آمنة، والتجميع بالمفتاح باقٍ */ && x.R(`CarFilters.key('mercedes benz') === CarFilters.key('Mercedes-Benz')`) &&
      c('تويوتا ') === 'تويوتا' && c('rolls royce') === 'Rolls Royce' && c('BYD') === 'BYD'; });
  await tc('6b) التوحيد عند الكتابة: إضافة/تعديل سيارة معرض وعضو تخزّن الاسم الموحَّد', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { brand: 'toyota', model: ' corolla ' });
    const m = d.R(`createDraftMemberCar({brand:'KIA',model:'cerato',year:2020,price:1000,phone:'07701234567'})`);
    d.R(`updateShowroomCar(${a.car.id},{brand:'hyundai'})`); d.R(`updateMemberCar(${m.car.id},{model:'SPORTAGE'})`);
    return d.R(`getCarById(${a.car.id}).brand`) === 'Hyundai' && d.R(`getCarById(${a.car.id}).model`) === 'Corolla' && d.R(`getMemberCarById(${m.car.id}).brand`) === 'Kia' && d.R(`getMemberCarById(${m.car.id}).model`) === 'Sportage'; });
  await tc('6c) خيارات الماركات ديناميكية وموحَّدة حتى لو وصلت بيانات غير موحّدة مباشرة للمستودع', async () => {
    const x = mk(null); x.R(`CarsRepository.create(CarModel({sourceType:'showroom',showroomId:1,brand:'toyota',model:'x',year:2031,price:5,status:'available'}))`);
    x.R(`CarsRepository.create(CarModel({sourceType:'showroom',showroomId:1,brand:'TOYOTA',model:'y',year:2032,price:5,status:'available'}))`);
    const o = JSON.parse(x.R(`JSON.stringify(CarFilters.options(getCars(), {}))`)); const toy = o.brands.filter(b => /toyota/i.test(b.value));
    return toy.length === 1 && toy[0].value === 'Toyota' && toy[0].count === 5 && o.years.includes(2031) && o.years.includes(2032) &&
      o.brands.some(b => b.value === 'BMW') && JSON.stringify(o.years) === JSON.stringify(o.years.slice().sort((a, b) => b - a)); });
  await tc('6d) الاسم العربي يبقى كما أُدخل ويُجمَّع مع مقابله اللاتيني ويظهر في التسمية', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { brand: 'تويوتا', model: 'كورولا' });
    const o = JSON.parse(d.R(`JSON.stringify(CarFilters.options(getCars(), {brand:'Toyota'}))`)); const toy = o.brands.find(b => b.value === 'Toyota'); const cor = o.models.find(m => m.value === 'Corolla');
    const a1 = JSON.parse(d.R(`JSON.stringify(CarFilters.apply(getCars(), {brand:'Toyota'}).map(c=>c.id))`)), a2 = JSON.parse(d.R(`JSON.stringify(CarFilters.apply(getCars(), {brand:'تويوتا'}).map(c=>c.id))`));
    return d.R(`getCarById(${a.car.id}).brand`) === 'تويوتا' && d.R(`getCarById(${a.car.id}).model`) === 'كورولا' && toy.label.includes('تويوتا') && toy.count === 4 &&
      cor && cor.label.includes('كورولا') && a1.includes(a.car.id) && JSON.stringify(a1) === JSON.stringify(a2); });
  await tc('6e) الموديلات مرتبطة بالماركة: لا موديلات Toyota عند BMW والعكس، وبلا ماركة لا موديلات', async () => {
    const x = mk(null); const M = b => JSON.parse(x.R(`JSON.stringify(CarFilters.options(getCars(), ${JSON.stringify({ brand: b })}).models.map(m=>m.value))`));
    const toy = M('Toyota'), bmw = M('BMW');
    return toy.includes('Corolla') && toy.includes('Camry') && !toy.some(v => bmw.includes(v)) && bmw.length >= 1 && !bmw.includes('Corolla') && M('').length === 0; });
  await tc('6f) السعر من–إلى بلا سقف مصطنع: 400 مليون يُلتقط، وأرقام عربية وفواصل مقبولة', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { brand: 'Rolls', model: 'Ghost', price: 400000000 });
    const F = c => JSON.parse(d.R(`JSON.stringify(CarFilters.apply(getCars(), ${JSON.stringify(c)}).map(c=>c.id))`));
    return F({ minPrice: 100000000 }).join() === String(a.car.id) && F({ minPrice: '٣٠٠٬٠٠٠٬٠٠٠', maxPrice: '500,000,000' }).join() === String(a.car.id) &&
      F({ maxPrice: 15000000 }).length > 0 && !F({ maxPrice: 15000000 }).includes(a.car.id) && F({ minPrice: 20000000, maxPrice: 10000000 }).length === 0 &&
      F({ minPrice: 12800000, maxPrice: 12800000 }).length >= 1; });
  await tc('6g) المسافة من–إلى: 0 الفعلي يدخل، والمجهول (null) لا يدخل أبدًا في أي فلتر مسافة', async () => {
    const d = mk('dealer1'); const z = await mkCar(d, { model: 'Zero', mileage: 0 }); const u = await mkCar(d, { model: 'Unknown' });
    const F = c => JSON.parse(d.R(`JSON.stringify(CarFilters.apply(getCars(), ${JSON.stringify(c)}).map(c=>c.id))`));
    return d.R(`getCarById(${u.car.id}).mileage`) === null && d.R(`getCarById(${z.car.id}).mileage`) === 0 &&
      F({ maxMileage: 1000 }).includes(z.car.id) && !F({ maxMileage: 1000 }).includes(u.car.id) && !F({ minMileage: 0 }).includes(u.car.id) &&
      !F({ minMileage: 1, maxMileage: 999999999 }).includes(u.car.id) && F({}).includes(u.car.id) && F({ minMileage: 60000, maxMileage: 70000 }).includes(1); });
  await tc('6h) مسافة غير مُدخلة = غير معروفة (null) في سيارة المعرض والعضو؛ و«0» المُدخلة صراحةً تبقى 0', async () => {
    const d = mk('dealer1'); const a = await mkCar(d, { model: 'NoKm' }); const b = await mkCar(d, { model: 'ZeroKm', mileage: '0' }); const c = await mkCar(d, { model: 'Km', mileage: '65,000' });
    const m1 = d.R(`createDraftMemberCar({brand:'Kia',model:'MNoKm',year:2020,price:1000,phone:'07701234567'})`);
    const m2 = d.R(`createDraftMemberCar({brand:'Kia',model:'MZeroKm',year:2020,price:1000,phone:'07701234567',mileage:'0'})`);
    return d.R(`getCarById(${a.car.id}).mileage`) === null && d.R(`getCarById(${b.car.id}).mileage`) === 0 && d.R(`getCarById(${c.car.id}).mileage`) === 65000 &&
      d.R(`getMemberCarById(${m1.car.id}).mileage`) === null && d.R(`getMemberCarById(${m2.car.id}).mileage`) === 0; });
  await tc('6i) محرك واحد: filterCars / filterMemberCars / searchCars / applyCarFilters تتفق مع CarFilters.apply', async () => {
    const x = mk(null); const ids = c => JSON.parse(x.R(`JSON.stringify((${c}).map(c=>c.id).sort((a,b)=>a-b))`));
    const crit = "{brand:'kia', minPrice:14000000, maxPrice:40000000}", critM = "{brand:'kia', maxMileage:120000}";
    return JSON.stringify(ids(`filterCars(${crit})`)) === JSON.stringify(ids(`CarFilters.apply(getCars(), ${crit})`)) &&
      JSON.stringify(ids(`filterMemberCars(${critM})`)) === JSON.stringify(ids(`CarFilters.apply(getActiveMemberCars(), ${critM})`)) &&
      JSON.stringify(ids(`searchCars('', 'showroom', ${crit})`)) === JSON.stringify(ids(`CarFilters.apply(getCars(), ${crit})`)) &&
      JSON.stringify(ids(`searchCars('kia', 'all', ${crit})`)) === JSON.stringify(ids(`CarFilters.apply(searchCars('kia','all'), ${crit})`)) &&
      JSON.stringify(ids(`applyCarFilters(getCars(), ${crit})`)) === JSON.stringify(ids(`CarFilters.apply(getCars(), ${crit})`)) && ids(`filterCars(${crit})`).length > 0; });
  await tc('6j) شاشة السيارات: ماركة + موديل + سنة + سعر من/إلى + مسافة من/إلى، بلا قائمة أسعار ثابتة', async () => {
    const { E, R } = mk(null); R(`go('cars')`); const h = E.screen();
    return ['carsFilterBrand', 'carsFilterModel', 'carsFilterYear', 'carsFilterMinPrice', 'carsFilterMaxPrice', 'carsFilterMinMileage', 'carsFilterMaxMileage'].every(id => h.includes(`id="${id}"`)) &&
      !h.includes('أقل من 10 مليون') && !h.includes('أقل من 50 مليون'); });
  await tc('6k) اختيار ماركة يملأ موديلاتها فقط، والفلتر بالموديل يعمل، وتغيير الماركة يُسقط موديلًا لا ينتمي لها', async () => {
    const { E, R } = mk(null); const S = o => { Object.entries({ Brand: '', Model: '', Year: '', MinPrice: '', MaxPrice: '', MinMileage: '', MaxMileage: '', ...o }).forEach(([k, v]) => E.els['carsFilter' + k] = { value: v, style: {} }); R('onCarsFilter()'); };
    R(`go('cars')`); S({ Brand: 'Toyota' }); const bar = E.els.carsFilterBar.innerHTML;
    const okBrand = bar.includes('value="Corolla"') && !bar.includes('value="Elantra"');
    S({ Brand: 'Toyota', Model: 'Corolla' }); const list = E.els.carsList.innerHTML; const okModel = cardsIn(list) >= 1 && !list.includes('Camry');
    S({ Brand: 'BMW', Model: 'Corolla' }); const bar2 = E.els.carsFilterBar.innerHTML;   // Corolla لا تنتمي لـ BMW
    return okBrand && okModel && !bar2.includes('value="Corolla"') && R('carsFilters.model') === ''; });
  await tc('6l) الكيلومترات والسعر في الواجهة: مجهول المسافة يُخفى ويُذكر عدده، و min>max رسالة واضحة، والنص غير الرقمي يُتجاهل مع تنبيه', async () => {
    const d = mk('dealer1'); await mkCar(d, { brand: 'Kia', model: 'NoKmUi' }); const { E, R } = d;
    const S = o => { Object.entries({ Brand: '', Model: '', Year: '', MinPrice: '', MaxPrice: '', MinMileage: '', MaxMileage: '', ...o }).forEach(([k, v]) => E.els['carsFilter' + k] = { value: v, style: {} }); R('onCarsFilter()'); };
    R(`go('cars')`); const all = cardsIn(E.screen());
    S({ MaxMileage: '300000' }); const withKm = E.els.carsList.innerHTML, bar = E.els.carsFilterBar.innerHTML;
    S({ MinPrice: '50000000', MaxPrice: '10000000' }); const inv = E.els.carsList.innerHTML + E.els.carsFilterBar.innerHTML;
    S({ MinPrice: 'abc' }); const bad = E.els.carsFilterBar.innerHTML, badList = cardsIn(E.els.carsList.innerHTML);
    return !withKm.includes('NoKmUi') && cardsIn(withKm) === all - 1 && bar.includes('بدون مسافة معلومة') && inv.includes('لم نعثر على سيارات مطابقة') && inv.includes('الحد الأدنى') && bad.includes('أدخل رقمًا صحيحًا') && badList === all; });
  await tc('6m) قيمة فلتر محدَّدة لم تعد موجودة تبقى ظاهرة ومحدَّدة في القائمة (لا تعارض بين الواجهة والحالة)', async () => {
    const { E, R } = mk(null); R(`go('cars')`); E.els.carsFilterBrand = { value: 'Nonexistent', style: {} }; R('onCarsFilter()');
    return E.els.carsFilterBar.innerHTML.includes('value="Nonexistent" selected') && E.els.carsList.innerHTML.includes('clearCarsFilters()'); });
  await tc('6n) سيارات الأعضاء: نفس الفلاتر (موديل + مسافة) وبلا قائمة أسعار ثابتة', async () => {
    const { E, R } = mk(null); R(`go('memberCars')`); const h = E.screen();
    E.els.memberFilterBrand = { value: 'Kia', style: {} }; R('onMemberCarsFilter()');
    return ['memberFilterModel', 'memberFilterMinPrice', 'memberFilterMaxPrice', 'memberFilterMinMileage', 'memberFilterMaxMileage'].every(id => h.includes(`id="${id}"`)) && !h.includes('أقل من 10 مليون') &&
      E.els.memberFilterBar.innerHTML.includes('value="Cerato"') && !E.els.memberFilterBar.innerHTML.includes('value="Elantra"'); });
  await tc('6o) البحث الموحّد: شريط فلاتر وينفّذه المحرك الواحد (موديل Sportage فقط)', async () => {
    const { E, R } = mk(null); R(`go('search','kia')`); const h = E.screen();
    E.els.searchFilterBrand = { value: 'Kia', style: {} }; E.els.searchFilterModel = { value: 'Sportage', style: {} }; R('onSearchFilter()');
    const res = E.els.searchResults.innerHTML;
    return h.includes('id="searchFilterBrand"') && h.includes('id="searchFilterMinPrice"') && res.includes('Sportage') && !res.includes('Cerato'); });

  /* ======================= 7) إيقاف المعرض (C7) ======================= */
  console.log('\n--- 7) إيقاف المعرض ---');
  const NAME5 = 'معرض الخليج للسيارات';   // المعرض التجريبي رقم 5 (موقوف) وله 3 سيارات
  await tc('7a) الزائر: المعرض الموقوف لا يظهر في المعارض/الرئيسية/الخريطة/البحث/نتائج البحث العام', async () => {
    const g = mk(null); const scr = r => (g.R(`go('${r}')`), g.E.screen());
    g.R(`go('showrooms')`); g.R(`onShowroomsSearch('الخليج')`); const bySearch = g.E.els.showroomsList.innerHTML;
    g.R(`go('search','الخليج')`); g.R(`onSearchScreenInput('الخليج')`); const sr = g.E.els.searchResults.innerHTML;
    return !scr('showrooms').includes(NAME5) && !scr('home').includes(NAME5) && !scr('map').includes(NAME5) && !bySearch.includes(NAME5) && !sr.includes(NAME5) && g.R(`searchShowrooms('').length`) === 3 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && g.R(`searchShowrooms('الخليج').length`) === 0; });
  await tc('7b) الزائر: سيارات المعرض الموقوف لا تظهر في السيارات/البحث/الرئيسية/المعرض نفسه', async () => {
    const g = mk(null); g.R(`go('cars')`); const n = cardsIn(g.E.screen()); const ids = JSON.parse(g.R(`JSON.stringify(getCars().filter(c=>c.showroomId===5).map(c=>c.id))`));
    const inSearch = ids.some(id => g.R(`searchCars('', 'all').some(c=>c.id===${id})`)); g.R(`go('showroomDetails',5)`); const det = g.E.screen();
    g.R(`go('carDetails',${ids[0]})`); const cd = g.E.screen();
    return ids.length === 3 && n === 9 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && !inSearch && !det.includes(NAME5) && !cd.includes('السعر') && cd.includes('غير متاح') && det.includes('غير متاح'); });
  await tc('7c) المدير يرى المعرض الموقوف وسياراته في كل الشاشات العامة', async () => {
    const a = mk('admin'); a.R(`go('showrooms')`); const s = a.E.screen(); a.R(`go('cars')`); const c = cardsIn(a.E.screen()); a.R(`go('map')`); const m = a.E.screen();
    a.R(`go('showroomDetails',5)`); const det = a.E.screen();
    return s.includes(NAME5) && c === 15 && m.includes(NAME5) && det.includes(NAME5) && !det.includes('غير متاح'); });
  await tc('7d) التاجر المالك يرى معرضه الموقوف وسياراته، وتاجر آخر لا يراه', async () => {
    const o = mk('dealer5'); o.R(`go('showrooms')`); const s = o.E.screen(); o.R(`go('cars')`); const c = cardsIn(o.E.screen()); o.R(`go('showroomDetails',5)`); const det = o.E.screen();
    const other = mk('dealer1'); other.R(`go('showrooms')`); const s2 = other.E.screen(); other.R(`go('cars')`);
    return s.includes(NAME5) && c === 12 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && det.includes(NAME5) && !s2.includes(NAME5) && cardsIn(other.E.screen()) === 9; });
  await tc('7e) المستخدم العادي: سيارة معرض يُوقَف تختفي من مفضلته دون حذف السجل، وتعود بإعادة التفعيل', async () => {
    const u = mk('user'); const model = u.R(`getCarById(10).model`); const fav1 = u.R(`toggleFavorite(10).ok`) && u.R(`getFavoriteCars().length`);
    const a = mk('admin', u.E.store); a.R(`AdminService.suspendShowroom(4)`); const u2 = mk('user', a.E.store);
    u2.R(`go('favorites')`); const scr = u2.E.screen(); const hidden = u2.R(`getFavoriteCars().length`) === 0 && !scr.includes(model) && u2.R(`FavoritesRepository.getAll().length`) === 1;
    const noToggle = u2.R(`toggleFavorite(10).ok`) === false;
    const a2 = mk('admin', u2.E.store); a2.R(`AdminService.activateShowroom(4)`); const u3 = mk('user', a2.E.store);
    return fav1 === 1 && hidden && noToggle && u3.R(`getFavoriteCars().length`) === 1; });
  await tc('7f) الإيقاف يُحفظ بعد إعادة التحميل، والمدير يعيد التفعيل فيظهر ثانية، ولا تُحذف أي بيانات', async () => {
    const a = mk('admin'); const carsBefore = a.R(`getCars().length`); const n1 = a.R(`getCarsByShowroom(1).length`);
    a.R(`AdminService.suspendShowroom(1)`); const g = asGuest(a); g.R(`go('showrooms')`); const hidden = !g.E.screen().includes('معرض النجف للسيارات');
    g.R(`go('cars')`); const n = cardsIn(g.E.screen());
    const a2 = reload(a, 'admin'); a2.R(`AdminService.activateShowroom(1)`); const g2 = asGuest(a2); g2.R(`go('showrooms')`);
    return hidden && n === 6 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && g2.E.screen().includes('معرض النجف للسيارات') && a2.R(`getCars().length`) === carsBefore && a2.R(`getCarsByShowroom(1).length`) === n1; });
  await tc('7g) سياسة الظهور العام للمعارض (تشديد): المعرض قيد المراجعة (pending) مخفي عن العامة كالموقوف (active فقط يظهر)؛ كان قرارًا موثّقًا بإبقائه ظاهرًا', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const s = g.E.screen(); g.R(`go('showroomDetails',3)`); const d = g.E.screen();
    return !s.includes('معرض العباس موتورز') && d.includes('غير متاح') && !d.includes('معرض العباس موتورز') && g.R(`getVisibleShowroomById(3)`) === undefined; });
  await tc('7h) التاجر المالك يواصل إدارة سيارات معرضه الموقوف (لا حذف ولا حجب)', async () => {
    const o = mk('dealer5'); const r = await mkCar(o, {}); return r.ok === true && o.R(`getMyShowroomCars().length`) === 4; });

  /* ======================= 8) معرض التاجر بعد الموافقة ======================= */
  console.log('\n--- 8) معرض التاجر ---');
  await tc('8a) اعتماد تاجر تجريبي معلّق (id 8): يُنشأ/يُربط معرض له ويدخل لوحته بلا رسالة «لا يوجد معرض»', async () => {
    const a = mk('admin'); const r = a.R(`approveDealer(8)`);
    const d = mk('pendingDealer', a.E.store); d.R(`go('dealerHome')`); const scr = d.E.screen();
    return r.ok === true && d.R(`AuthorizationService.getManagedShowrooms().length`) === 1 && d.R(`getShowroomById(AuthorizationService.getManagedShowrooms()[0].id).ownerId`) === 8 &&
      !scr.includes('لا يوجد معرض مرتبط بحسابك') && d.R(`currentRoute`) === 'dealerHome'; });
  await tc('8b) التاجر المعتمد يضيف سيارة لمعرضه ويديرها', async () => {
    const a = mk('admin'); a.R(`approveDealer(8)`); const d = mk('pendingDealer', a.E.store); const c = await mkCar(d, { model: 'FirstCar' });
    return c.ok === true && d.R(`getCarById(${c.car.id}).showroomId`) === d.R(`AuthorizationService.getManagedShowrooms()[0].id`) && d.R(`updateShowroomCar(${c.car.id},{price:2000}).ok`) === true && d.R(`getMyShowroomCars().length`) === 1; });
  await tc('8c) تاجر جديد يسجّل ثم يعتمده المدير: معرض واحد بحالة active وظاهر للزوار وبمعرّف فريد', async () => {
    const n = mk(null); const reg = n.R(`AuthService.register({name:'تاجر جديد تجريبي',phone:'07712345678',email:'',password:'secret1',confirmPassword:'secret1',accountType:'dealer'})`);
    const before = n.R(`getShowrooms().length`); const a = mk('admin', n.E.store); a.R(`approveDealer(${reg.user.id})`);
    const sh = JSON.parse(a.R(`JSON.stringify(getShowrooms().filter(s=>s.ownerId===${reg.user.id}))`)); const ids = JSON.parse(a.R(`JSON.stringify(getShowrooms().map(s=>s.id))`));
    const g = asGuest(a); g.R(`go('showrooms')`);
    return reg.ok && sh.length === 1 && sh[0].status === 'active' && new Set(ids).size === ids.length && a.R(`getShowrooms().length`) === before + 1 && showroomCardsIn(g.E.screen()) === 4 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ /* 1،2،4 + الجديد */; });
  await tc('8d) الاعتماد المتكرر أو إعادة الاعتماد لا تنشئ معرضًا ثانيًا', async () => {
    const a = mk('admin'); a.R(`approveDealer(8)`); a.R(`approveDealer(8)`); a.R(`rejectDealer(8)`); a.R(`approveDealer(8)`);
    return a.R(`getShowrooms().filter(s=>s.ownerId===8).length`) === 1; });
  await tc('8e) تاجر تجريبي لديه معرض أصلًا (id 1): لا معرض جديد', async () => {
    const a = mk('admin'); const before = a.R(`getShowrooms().length`); a.R(`approveDealer(1)`); return a.R(`getShowrooms().length`) === before && a.R(`getShowrooms().filter(s=>s.ownerId===1).length`) === 1; });
  await tc('8f) سلبي: غير المدير لا يعتمد ولا يُنشئ معرضًا، والتاجر المعلّق غير المعتمد بلا معرض ولا وصول', async () => {
    const u = mk('user'); const r = u.R(`approveDealer(8)`); const p = mk('pendingDealer', u.E.store);
    return r.ok === false && p.R(`getShowrooms().filter(s=>s.ownerId===8).length`) === 0 && p.R(`AuthorizationService.canAccessDealerArea()`) === false; });
  await tc('8g) معرض التاجر الجديد يُحفظ بعد إعادة التحميل ويبقى مرتبطًا بمالكه', async () => {
    const a = mk('admin'); a.R(`approveDealer(8)`); const d = mk('pendingDealer', a.E.store); return d.R(`AuthorizationService.getManagedShowrooms().length`) === 1; });
  await tc('8h) هجرة: تاجر معتمد سابقًا بلا معرض (تخزين قديم) يحصل على معرض عند أول تحميل', async () => {
    const store = legacyStore(() => {}); store['najaf.userOverrides'] = JSON.stringify({ 8: { status: 'active' } });
    const d = mk('pendingDealer', store); return d.R(`AuthorizationService.getManagedShowrooms().length`) === 1; });

  /* ======================= 9) فحوص ثابتة ======================= */
  console.log('\n--- 9) فحوص ثابتة ---');
  const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/^\s*\/\/.*$/gm, '');
  const read = f => strip(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  const jsFiles = dir => fs.readdirSync(path.join(ROOT, dir)).filter(f => f.endsWith('.js')).map(f => dir + '/' + f);
  await tc('9a) لا منطق فلترة مكرر: مقارنات brand/model/price/mileage خارج carFilterService.js غير موجودة', async () => {
    // migrationService.js يفحص الصفر القديم لتحويله (هجرة بيانات لا تصفية)، فلا يدخل في الفحص
    const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('navigation'), jsFiles('services').filter(f => !/carFilterService\.js$|migrationService\.js$/.test(f)), jsFiles('repositories'));
    const re = /\b(c|car|x|it)\.(brand|model|price|mileage)\s*(===|!==|<=|>=|<|>)/; const bad = files.filter(f => re.test(read(f))); if (bad.length) console.log('   منطق فلترة خارج المحرك في:', bad.join(', ')); return bad.length === 0; });
  await tc('9b) FILTER_PRICES (القائمة الثابتة) حُذفت من الكود', async () => !jsFiles('components').concat(jsFiles('screens'), jsFiles('services')).some(f => /FILTER_PRICES/.test(read(f))));
  await tc('9c) carFilterService مُحمَّل في index.html بعد searchService وقبل المكوّنات', async () => {
    const h = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8'); const p = s => h.indexOf(s);
    return p('services/carFilterService.js') > p('services/searchService.js') && p('services/carFilterService.js') < p('components/ui.js') && p('repositories/idAllocator.js') > p('repositories/baseRepository.js') && p('repositories/idAllocator.js') < p('repositories/usersRepository.js') && p('services/migrationService.js') > p('services/showroomService.js') && !h.includes('repositories/migrations.js'); });
  await tc('9d) الفصل بين الطبقات باقٍ: لا AppStorage/localStorage خارج repositories/storage', async () => {
    const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('navigation'), jsFiles('services').filter(f => !f.endsWith('storageService.js')), ['app.js']);
    return files.filter(f => /AppStorage|localStorage|indexedDB/.test(read(f)) && !f.endsWith('imageStore.js')).length === 0; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

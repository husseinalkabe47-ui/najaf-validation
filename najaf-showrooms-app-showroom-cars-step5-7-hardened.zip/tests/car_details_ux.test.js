/* اختبارات تحسين شاشة تفاصيل السيارة العامة (UX ج5): زر رجوع واضح + زر مفضلة مدمج بجانب الهوية.
   المصدر الوحيد: المفضلة ← handleFavoriteToggle القائم ← favoritesService (isFavorite/toggleFavorite) ← FavoritesRepository؛
   والرجوع ← goBack(fallback) في الراوتر القائم (سجل _navStack). الواجهة فقط تغيّرت: DetailBackButton/DetailFavoriteButton/DetailIdentity.
   قياسات px الحقيقية (≥ 44، عدم التراكب/الاقتصاص/overflow، Tab/Enter/Space) في Chromium على 320/360/390/412؛ هنا القواعد والسلوك والبيانات العدائية. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const CRED = { user: ['07700000001', 'user123'], dealer: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
const dec = s => s.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
function mk(role, store) {
  const E = makeEnv(store, { fullSeed: 'p3' }), R = c => E.run(c);
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); E.els.loginIdentifier = { value: c[0], style: {}, textContent: '' }; E.els.loginPassword = { value: c[1], style: {}, textContent: '' }; R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
const BAD = /undefined|NaN|\[object/, ERR = 'حدث خطأ، حاول مرة أخرى';
const btn = (html, cls) => (String(html).match(new RegExp('<button[^>]*class="' + cls + '"[^>]*>[\\s\\S]*?</button>')) || [''])[0];
const onclickOf = el => { const m = /onclick="([^"]*)"/.exec(el); return m ? dec(m[1]) : null; };
/** «نقر» حقيقي: ينفّذ شيطرة onclick المفكوكة للزر داخل بيئة التطبيق */
const click = (x, el) => { const code = onclickOf(el); if (!code) throw new Error('no onclick'); x.E.errors.length = 0; x.R(code); };
const detailsOnclick = (html, route, id) => { const m = String(html).match(new RegExp("go\\('" + route + "',\\s*" + id + "\\)")); return m ? m[0] : null; };
const idsIn = html => [...String(html).matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
const LONG = 'ماركة-طويلة-جدا-'.repeat(5) + 'Extraordinarily-Long-Brand-Name-'.repeat(3);   // > 100 حرف

(async () => {
  const ref = mk(null);
  const PUBLIC_SHOW = ref.J('getVisibleCars()'), PUBLIC_MEM = ref.J('getVisibleMemberCars()');
  const SC = PUBLIC_SHOW.find(c => c.currency === 'IQD' && c.price && c.mileage !== null), MC = PUBLIC_MEM.find(c => c.model === 'Corolla');
  const showD = (x, id = SC.id) => { x.R(`go('carDetails',${id})`); return x.E.screen(); };
  const memD = (x, id = MC.id) => { x.R(`go('memberCarDetails',${id})`); return x.E.screen(); };

  /* ======================= A) زر الرجوع ======================= */
  console.log('\n--- A) زر الرجوع ---');
  await tc('1) زر الرجوع موجود في تفاصيل سيارة المعرض والعضو (بلا تكرار)، وفي حالتي «غير موجود/غير متاح» أيضًا بنفس المكوّن', async () => {
    const g = mk(null); const a = showD(g), b = memD(g); g.R(`go('carDetails',99999)`); const m1 = g.E.screen(); g.R(`go('carDetails',13)`); const h1 = g.E.screen();
    const h2 = g.R('MemberCarDetailsScreen(103)'), m2 = g.R('MemberCarDetailsScreen(99999)');   // فرعا «غير متاح/غير موجود» للأعضاء يُرسمان بدالة العرض مباشرة (الراوتر يحرس المسار: login/accessDenied)
    return [a, b, m1, h1, h2, m2].every(h => (h.match(/class="back-pill"/g) || []).length === 1 && !h.includes('back-circle')) || 'missing back'; });
  await tc('2) زر الرجوع <button type="button"> حقيقي (لا div) وبداخله سهم aria-hidden ونص «رجوع» ظاهر', async () => {
    const g = mk(null); const h = showD(g), b = btn(h, 'back-pill');
    return (/^<button type="button" class="back-pill"/.test(b) && /<span class="bp-arrow" aria-hidden="true">→<\/span><span>رجوع<\/span>/.test(b) && !/<div[^>]*class="back-pill"/.test(h) && !/<div[^>]*onclick/.test(h.slice(h.indexOf('class="back-btn'), h.indexOf('class="detail-hero"')))) || { b }; });
  await tc('3) الاسم الوصولي «رجوع» (aria-label) ويطابق النص الظاهر، ومعالج goBack(fallback) من الراوتر القائم: cars لتفاصيل المعرض وmemberCars لتفاصيل العضو', async () => {
    const g = mk(null); const a = btn(showD(g), 'back-pill'), b = btn(memD(g), 'back-pill');
    return (/aria-label="رجوع"/.test(a) && /aria-label="رجوع"/.test(b) && onclickOf(a) === "goBack('cars')" && onclickOf(b) === "goBack('memberCars')") || { a, b }; });
  await tc('4) هدف اللمس ≥ 44×44: .back-pill بـ min-height/min-width 44px (لا ارتفاع بكسل ثابت)، والسهم بالاتجاه الصحيح لـRTL (→ يشير لليمين = للخلف)، والتركيز المرئي مفعّل', async () => {
    const css = read('theme/theme.css'); const i = css.indexOf('/* ---- (UX ج5)'); const b = i >= 0 ? css.slice(i) : '';
    return (b.length > 200 && /\.back-pill\{[^}]*min-height:\s*44px/.test(b) && /\.back-pill\{[^}]*min-width:\s*44px/.test(b) && !/(^|[;{\s])height\s*:\s*\d+px/.test(b) && /\.back-pill:focus-visible/.test(b) && read('components/carCard.js').includes('aria-hidden="true">→</span>') && /dir="rtl"/.test(read('index.html'))) || { len: b.length }; });

  /* ======================= B) زر المفضلة ======================= */
  console.log('\n--- B) زر المفضلة المدمج ---');
  await tc('5) زر المفضلة <button type="button"> حقيقي (لا div)، بالمعالج القائم handleFavoriteToggle(id)، ولا معرّف مكرر ولا زر بلا اسم في الشاشة', async () => {
    const g = mk(null); const out = [];
    for (const h of [showD(g), memD(g)]) { const f = btn(h, 'fav-inline'); const ids = idsIn(h); const unnamed = [...h.matchAll(/<button\b[^>]*>[\s\S]*?<\/button>/g)].filter(m => !/aria-label="[^"]+"/.test(m[0]) && !m[0].replace(/<[^>]+>/g, '').trim()); out.push(/^<button type="button" class="fav-inline"/.test(f) && /onclick="handleFavoriteToggle\(\d+\)"/.test(f) && !/<div[^>]*fav/.test(h) && new Set(ids).size === ids.length && unnamed.length === 0); }
    return out.every(Boolean) || out; });
  await tc('6) مدمج لا مستطيل فارغ: زر واحد في صف الهوية بجانب العنوان (قبل السعر)، بلا زر عريض سفلي (لا action-btn للمفضلة)، محتواه رمز القلب فقط، وCSS الهدف 44×44 دائرة بلا width:100% ولا تمدّد', async () => {
    const g = mk(null); const a = showD(g), b = memD(g); const css = read('theme/theme.css'); const blk = css.slice(css.indexOf('/* ---- (UX ج5)'));
    const ok = h => { const head = h.slice(h.indexOf('class="detail-head"'), h.indexOf('class="price big')); return (h.match(/handleFavoriteToggle\(/g) || []).length === 1 && head.includes('<h1>') && head.includes('class="fav-inline"') && head.indexOf('<h1>') < head.indexOf('class="fav-inline"') && !/action-btn[^>]*handleFavoriteToggle/.test(h) && btn(h, 'fav-inline').replace(/<[^>]+>/g, '').trim().length <= 2; };
    return (ok(a) && ok(b) && /\.fav-inline\{[^}]*min-width:\s*44px[^}]*min-height:\s*44px[^}]*border-radius:\s*50%/.test(blk) && !/\.fav-inline\{[^}]*(width:\s*100%|flex:\s*1|flex-grow)/.test(blk) && /\.fav-inline\{[^}]*flex:\s*0 0 auto/.test(blk) && /\.detail-id\{[^}]*flex:\s*1 1 0[^}]*min-width:\s*0/.test(blk)) || 'layout'; });
  await tc('7) الاسم الوصولي يتبع الحالة: الزائر/غير المفضّل «إضافة إلى المفضلة»، المفضّل «إزالة من المفضلة»', async () => {
    const u = mk('user'); const before = btn(showD(u), 'fav-inline'); u.R(`toggleFavorite(${SC.id})`); const after = btn(showD(u), 'fav-inline'); const g = mk(null);
    return (/aria-label="إضافة إلى المفضلة"/.test(before) && /aria-label="إزالة من المفضلة"/.test(after) && /aria-label="إضافة إلى المفضلة"/.test(btn(showD(g), 'fav-inline'))) || { before, after }; });
  await tc('8) aria-pressed يتبدّل (false ← true ← false) والرمز ♡ ← ♥ بنص (لا اعتماد على اللون وحده)، والرمز aria-hidden', async () => {
    const u = mk('user'); const s0 = btn(showD(u), 'fav-inline'); u.R(`toggleFavorite(${SC.id})`); const s1 = btn(showD(u), 'fav-inline'); u.R(`toggleFavorite(${SC.id})`); const s2 = btn(showD(u), 'fav-inline');
    return (/aria-pressed="false"/.test(s0) && s0.includes('♡') && /aria-pressed="true"/.test(s1) && s1.includes('♥') && !s1.includes('♡') && /aria-pressed="false"/.test(s2) && /<span aria-hidden="true">/.test(s1)) || { s0, s1, s2 }; });
  await tc('9) الضغط يبدّل فعليًا عبر المعالج القائم: عضو (إضافة/إزالة)، تاجر، مدير، لكل منهم مفضلته؛ والزائر يُحوَّل لتسجيل الدخول مع العودة لنفس التفاصيل', async () => {
    const out = {};
    for (const role of ['user', 'dealer', 'admin']) { const x = mk(role); const h = showD(x); click(x, btn(h, 'fav-inline')); const on = /aria-pressed="true"/.test(btn(x.E.screen(), 'fav-inline')) && x.R(`isFavorite(${SC.id})`) === true; click(x, btn(x.E.screen(), 'fav-inline')); out[role] = [on, /aria-pressed="false"/.test(btn(x.E.screen(), 'fav-inline')) && x.R(`isFavorite(${SC.id})`) === false, x.R('currentRoute') === 'carDetails', x.E.errors.length === 0]; }
    const g = mk(null); const h = showD(g); click(g, btn(h, 'fav-inline')); out.guest = [g.R('currentRoute'), g.R('currentParam.returnTo'), g.R('currentParam.returnParam')];
    return (Object.entries(out).filter(([k]) => k !== 'guest').every(([, v]) => v.every(Boolean)) && out.guest[0] === 'login' && out.guest[1] === 'carDetails' && out.guest[2] === SC.id) || out; });
  await tc('10) الحالة تبقى: بعد إعادة التحميل (نفس التخزين) والتنقل بعيدًا والعودة تبقى المفضلة (♥، aria-pressed=true) لتفاصيل المعرض والعضو، وبلا تكرار في المخزن بعد نقرات متتابعة', async () => {
    const store = {}; const u = mk('user', store); click(u, btn(showD(u), 'fav-inline')); click(u, btn(memD(u), 'fav-inline'));
    const r = mk('user', store); const s1 = /aria-pressed="true"/.test(btn(showD(r), 'fav-inline')), m1 = /aria-pressed="true"/.test(btn(memD(r), 'fav-inline'));
    r.R(`go('cars')`); r.R(`go('home')`); const s2 = /aria-pressed="true"/.test(btn(showD(r), 'fav-inline'));
    const d = mk('user', {}); const hh = showD(d); for (let i = 0; i < 5; i++) click(d, btn(d.E.screen(), 'fav-inline')); const dup = d.J(`FavoritesRepository.getAll().filter(f => f.carId === ${SC.id})`).length; const final = /aria-pressed="true"/.test(btn(d.E.screen(), 'fav-inline'));
    return (s1 && m1 && s2 && dup === 1 && final === true) || { s1, m1, s2, dup, final }; });
  await tc('11) المصدر الوحيد favoritesService: الزر يعرض isFavorite(id) في كل رسم (لا نسخة محلية)، وتبديل الخدمة مباشرة (toggleFavorite) ينعكس فورًا في الواجهة، وحالة المستودع تطابق', async () => {
    const u = mk('user'); const h0 = /aria-pressed="false"/.test(btn(showD(u), 'fav-inline')); u.R(`toggleFavorite(${SC.id})`); u.R('render()'); const h1 = /aria-pressed="true"/.test(btn(u.E.screen(), 'fav-inline'));
    const rec = u.J(`FavoritesRepository.getAll().filter(f => f.carId === ${SC.id} && f.userId === SessionService.getCurrentUser().id)`); u.R(`toggleFavorite(${SC.id})`); u.R('render()'); const h2 = /aria-pressed="false"/.test(btn(u.E.screen(), 'fav-inline'));
    return (h0 && h1 && rec.length === 1 && h2 && u.R(`isFavorite(${SC.id})`) === false) || { h0, h1, h2, rec: rec.length }; });
  await tc('12) لا نظام مفضلة ثانٍ: كود التفاصيل/المكوّن لا يلمس FavoritesRepository ولا التخزين ولا يحمل نسخة حالة، وتعريف handleFavoriteToggle وtoggleFavorite وisFavorite واحد فقط في المشروع، والزر يستعمل isFavorite + handleFavoriteToggle فقط', async () => {
    const cc = read('components/carCard.js'); const own = [strip(read('screens/carDetails.js')), strip(read('screens/memberCarDetails.js')), strip(cc.slice(cc.indexOf('(UX ج5)')))].join('\n');   // الشاشتان + مساعدات UX ج5 (بطاقة القائمة قبلها خارج النطاق)
    const all = ['screens', 'components', 'services', 'navigation', 'repositories'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => strip(read(d + '/' + f)))).join('\n');
    const def = n => (all.match(new RegExp('function ' + n + '\\(', 'g')) || []).length;
    return (!/FavoritesRepository|localStorage|AppStorage|favState|let isFav|const isFav/.test(own) && def('handleFavoriteToggle') === 1 && def('toggleFavorite') === 1 && def('isFavorite') === 1 && /isFavorite\(carId\)/.test(strip(read('components/carCard.js'))) && (own.match(/handleFavoriteToggle\(/g) || []).length === 1) || { h: def('handleFavoriteToggle'), t: def('toggleFavorite'), i: def('isFavorite') }; });
  await tc('B13) سيارة محذوفة/مخفية آمنة: تفاصيل مخفية (معرض موقوف/إعلان غير نشط) أو غير موجودة تعرض رسالتها بزر الرجوع بلا زر مفضلة، والتبديل البرمجي يعيد not_found بلا استثناء ولا سجل، والمدير/المالك يريانها كما كان', async () => {
    const u = mk('user'); u.R(`go('carDetails',13)`); const h = u.E.screen(); const r = u.J('toggleFavorite(13)'); const n = u.J('FavoritesRepository.getAll().filter(f => f.carId === 13).length');
    u.R(`go('carDetails',99999)`); const ms = u.E.screen(); const a = mk('admin'); a.R(`go('carDetails',13)`); const ah = a.E.screen(); const o = mk('user'); o.R(`go('memberCarDetails',103)`); const oh = o.E.screen(); const g = mk(null); const gh = g.R('MemberCarDetailsScreen(103)');
    g.R(`go('memberCarDetails',103)`); const guestRoute = g.R('currentRoute'); const o2 = mk('user'); o2.R(`go('memberCarDetails',109)`); const nonOwnerRoute = o2.R('currentRoute');
    return (h.includes('هذه السيارة غير متاحة حاليًا') && !h.includes('fav-inline') && h.includes('class="back-pill"') && r.ok === false && r.reason === 'not_found' && n === 0 && ms.includes('السيارة غير موجودة') && !ms.includes('fav-inline') && ah.includes('class="fav-inline"') && oh.includes('class="fav-inline"') && gh.includes('هذا الإعلان غير متاح حاليًا') && !gh.includes('fav-inline') && guestRoute === 'login' && nonOwnerRoute === 'accessDenied') || { h: h.length, r, guestRoute, nonOwnerRoute }; });

  /* ======================= C) الرجوع الفعلي عبر سجل التنقل ======================= */
  console.log('\n--- C) الرجوع الفعلي ---');
  await tc('13) السيارات ← تفاصيل ← رجوع = السيارات (بنقر الزر الحقيقي، حالة بحث/فلاتر الشاشة محفوظة)، ومن الرئيسية ← التفاصيل ← رجوع = الرئيسية، ومن المعرض ← التفاصيل ← رجوع = المعرض', async () => {
    const x = mk(null); x.R(`go('cars')`); x.R(`onCarsSearch('toyota')`); x.R(`go('carDetails',${SC.id})`); const d1 = x.R('currentRoute'); click(x, btn(x.E.screen(), 'back-pill')); const r1 = x.R('currentRoute'), q = x.R('carsSearchQuery');
    x.R(`go('home')`); x.R(`go('carDetails',${SC.id})`); click(x, btn(x.E.screen(), 'back-pill')); const r2 = x.R('currentRoute');
    x.R(`go('showroomDetails',${SC.showroomId})`); x.R(`go('carDetails',${SC.id})`); click(x, btn(x.E.screen(), 'back-pill')); const r3 = x.R('currentRoute'), p3 = x.R('currentParam');
    return (d1 === 'carDetails' && r1 === 'cars' && q === 'toyota' && r2 === 'home' && r3 === 'showroomDetails' && p3 === SC.showroomId) || { d1, r1, q, r2, r3, p3 }; });
  await tc('14) سيارات الأعضاء ← تفاصيل ← رجوع = سيارات الأعضاء (الفلاتر محفوظة)، ومن «إعلاناتي» ← التفاصيل ← رجوع = إعلاناتي (لا تُفرض شاشة الأعضاء)', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.R(`go('memberCarDetails',${MC.id})`); const d = x.R('currentRoute'); click(x, btn(x.E.screen(), 'back-pill')); const r1 = x.R('currentRoute');
    const u = mk('user'); u.R(`go('myMemberCars')`); u.R(`go('memberCarDetails',101)`); click(u, btn(u.E.screen(), 'back-pill')); const r2 = u.R('currentRoute');
    return (d === 'memberCarDetails' && r1 === 'memberCars' && r2 === 'myMemberCars') || { d, r1, r2 }; });
  await tc('15) البحث ← تفاصيل ← رجوع = البحث بنص البحث نفسه (param)، وكذلك من نتيجة عضو ببحث موحّد', async () => {
    const x = mk(null); x.R(`go('search','corolla')`); const h = x.E.screen(); const car = ids(h)[0]; x.R(`go('carDetails',${car})`); click(x, btn(x.E.screen(), 'back-pill')); const r = x.R('currentRoute'), p = x.R('currentParam');
    return (r === 'search' && p === 'corolla' && x.E.screen().includes('corolla')) || { r, p }; function ids(html) { return [...new Set([...html.matchAll(/go\('carDetails',\s*(\d+)\)/g)].map(m => Number(m[1])))]; } });
  await tc('16) المفضلة ← تفاصيل ← رجوع = المفضلة، وبعد إزالة السيارة من المفضلة داخل التفاصيل ثم الرجوع تظهر القائمة بلا تلك السيارة (بلا خطأ)', async () => {
    const u = mk('user'); u.R(`toggleFavorite(${SC.id})`); u.R(`toggleFavorite(${MC.id})`); u.R(`go('favorites')`); u.R(`go('carDetails',${SC.id})`); click(u, btn(u.E.screen(), 'back-pill')); const r1 = u.R('currentRoute'); const has1 = u.E.screen().includes(`go('carDetails',${SC.id})`);
    u.R(`go('carDetails',${SC.id})`); click(u, btn(u.E.screen(), 'fav-inline')); click(u, btn(u.E.screen(), 'back-pill')); const r2 = u.R('currentRoute'), scr = u.E.screen();
    return (r1 === 'favorites' && has1 && r2 === 'favorites' && !scr.includes(`go('carDetails',${SC.id})`) && scr.includes(`go('memberCarDetails',${MC.id})`) && !scr.includes(ERR) && u.E.errors.length === 0) || { r1, has1, r2 }; });
  await tc('17) الدخول المباشر بلا سجل: الرجوع يستعمل البديل القائم (cars لتفاصيل المعرض، memberCars لتفاصيل العضو) بلا دفع الشاشة الحالية وبلا انهيار؛ وسجل قديم لمسار إداري عند ضيف لا يكشف شيئًا (حارس الراوتر القائم يحوّل إلى تسجيل الدخول) بلا انهيار', async () => {
    const x = mk(null); x.R(`currentRoute = 'carDetails'; currentParam = ${SC.id}; _navStack = []; render();`); click(x, btn(x.E.screen(), 'back-pill')); const a = [x.R('currentRoute'), x.R('_navStack.length')];
    const y = mk(null); y.R(`currentRoute = 'memberCarDetails'; currentParam = ${MC.id}; _navStack = []; render();`); click(y, btn(y.E.screen(), 'back-pill')); const b = [y.R('currentRoute'), y.R('_navStack.length')];
    const z = mk(null); z.R(`currentRoute = 'carDetails'; currentParam = ${SC.id}; _navStack = [{ route: 'adminDashboard', param: undefined }]; render();`); click(z, btn(z.E.screen(), 'back-pill')); const c = z.R('currentRoute'), cs = z.E.screen();
    return (a[0] === 'cars' && a[1] === 0 && b[0] === 'memberCars' && b[1] === 0 && ['cars', 'login'].includes(c) && !/adminDashboard|class="stat-card"/.test(cs) && x.E.errors.length === 0 && y.E.errors.length === 0 && z.E.errors.length === 0) || { a, b, c }; });
  await tc('18) الراوتر لم يتغير: go/goBack/_navStack/_entryUsable/_samePage بمنطقها القائم، ولا إشارة للمكوّنات الجديدة فيه، وgoBack يعتمد pop السجل ثم البديل بلا دفع، والمسارات كما هي، و85 سكربتًا', async () => {
    const r = strip(read('navigation/router.js'));
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length;
    return (/function goBack\(fallback\)/.test(r) && /_navStack\.pop\(\)/.test(r) && /_entryUsable\(prev\)/.test(r) && /_samePage\(prev\.route/.test(r) && /currentRoute = fallback \|\| 'home'/.test(r) && !/DetailBackButton|back-pill|DetailFavorite|fav-inline/.test(r) && /carDetails: \{ render: CarDetailsScreen/.test(r) && /memberCarDetails: \{ render: MemberCarDetailsScreen/.test(r) && order === 85) || { order }; });

  /* ======================= D) الظهور وحالة السيارة ======================= */
  console.log('\n--- D) الظهور والحالات ---');
  await tc('19) قواعد الظهور كما هي: سيارة معرض موقوف للزائر «غير متاحة»، إعلان عضو غير نشط للزائر «غير متاح»، المالك والمدير يريانها، ومعرّف مفقود «غير موجود»؛ وتفاصيل العامة تعرض الهوية والسعر والحالة والمواصفات', async () => {
    const g = mk(null); g.R(`go('carDetails',13)`); const a = g.E.screen(); const full = showD(g);
    return (a.includes('هذه السيارة غير متاحة حاليًا') && full.includes('class="status-row"') && full.includes('⚙️ المواصفات') && full.includes('class="price big') && full.includes('<h1>') && g.R('getVisibleCarById(13)') === undefined) || 'visibility'; });
  await tc('20) لا reserved: لا ذكر لـreserved/محجوز في شاشتي التفاصيل ومساعداتهما ولا في HTML المعروض، والحالات المعروضة معرَّفة فقط', async () => {
    const g = mk(null); const hs = [showD(g), memD(g)].join('\n'); const src = [strip(read('screens/carDetails.js')), strip(read('screens/memberCarDetails.js')), strip(read('components/carCard.js'))].join('\n');
    return (!/reserved|محجوز/i.test(src + hs)) || 'reserved'; });

  /* ======================= E) نصوص وقيم عدائية ======================= */
  console.log('\n--- E) بيانات عدائية ---');
  const layoutOk = h => { const head = h.slice(h.indexOf('class="detail-head"'), h.indexOf('<p class="price')); return head.includes('class="fav-inline"') && head.includes('<h1>') && head.includes('class="detail-id"') && h.includes('class="back-pill"') && !BAD.test(h) && !h.includes(ERR); };
  await tc('21) عنوان بأكثر من 100 حرف (ماركة/موديل) لا يكسر البنية: يُهرَّب داخل h1، وزر المفضلة يبقى في صف الهوية نفسه بعد العنوان، وCSS الالتفاف (overflow-wrap:anywhere وmin-width:0) مفعّل، لتفاصيل المعرض والعضو', async () => {
    const x = mk('admin'); x.R(`CarsRepository.update(${SC.id}, { brand: ${JSON.stringify(LONG)}, model: ${JSON.stringify(LONG + '<b>x</b>')} })`); x.R(`MemberCarsRepository.update(${MC.id}, { brand: ${JSON.stringify(LONG)}, model: ${JSON.stringify(LONG)} })`);
    const a = showD(x), b = memD(x); const css = read('theme/theme.css');
    return (layoutOk(a) && layoutOk(b) && a.includes(LONG.slice(0, 30)) && !a.includes('<b>x</b>') && /\.detail-body \.detail-id h1\{[^}]*overflow-wrap:\s*anywhere/.test(css) && /\.detail-id\{[^}]*min-width:\s*0/.test(css) && /\.detail-body h1[^{]*\{[^}]*overflow-wrap|\.card-title,\.card-row,\.info-row,\.detail-body h1/.test(css)) || { a: layoutOk(a), b: layoutOk(b) }; });
  await tc('22) أسعار كبيرة جدًا: IQD ضخم وUSD ضخم يُعرضان مقروءين (أرقام ar-IQ + رمز العملة) بلا NaN/undefined ولا فقدان للمفضلة/الرجوع', async () => {
    const x = mk('admin'); x.R(`CarsRepository.update(${SC.id}, { price: 9999999999999, currency: 'IQD' })`); const a = showD(x); const pa = (a.match(/class="price big[^"]*">([^<]*)</) || [])[1];
    x.R(`CarsRepository.update(${SC.id}, { price: 9999999999, currency: 'USD' })`); const b = showD(x); const pb = (b.match(/class="price big[^"]*">([^<]*)</) || [])[1];
    return (layoutOk(a) && layoutOk(b) && /د\.ع/.test(pa) && /\$/.test(pb) && pa.length < 60 && pb.length < 60) || { pa, pb }; });
  await tc('23) قيم ناقصة آمنة: بلا سعر («السعر غير محدد»)، بلا مسافة (لا صف مسافة)، بلا نص بيانات معرض (اسم/عنوان/دوام/هاتف/واتساب فارغة ← لا صفوف ولا روابط ميتة)، واسم معرض طويل جدًا مهرَّب؛ ومعرض غير موجود يجعل السيارة «غير متاحة» بآمان (قاعدة الظهور القائمة) مع زر الرجوع — والهوية/المفضلة/الرجوع تبقى', async () => {
    const x = mk('admin'); x.R(`CarsRepository.update(${SC.id}, { price: null, mileage: null })`); const a = showD(x);
    x.R(`ShowroomsRepository.update(${SC.showroomId}, { name: ${JSON.stringify(LONG)} })`); const b = showD(x);
    x.R(`ShowroomsRepository.update(${SC.showroomId}, { name: '', address: '', workingHours: '', phone: '', whatsapp: '' })`); const c = showD(x);
    x.R(`CarsRepository.update(${SC.id}, { showroomId: 99999 })`); const d = showD(x);
    return (layoutOk(a) && a.includes('السعر غير محدد') && !a.includes('المسافة') && layoutOk(b) && b.includes(LONG.slice(0, 20)) && layoutOk(c) && !/href="tel:undefined|wa\.me\/undefined|href="tel:"/.test(c) && d.includes('هذه السيارة غير متاحة حاليًا') && d.includes('class="back-pill"') && !BAD.test(d)) || { a: layoutOk(a), b: layoutOk(b), c: layoutOk(c), d: d.slice(0, 120) }; });
  await tc('24) لا undefined/NaN/[object Object]/«حدث خطأ» في أي تفاصيل عامة (كل سيارات المعارض الظاهرة وإعلانات الأعضاء العامة) لكل الأدوار، وكل صفحة فيها زر رجوع وزر مفضلة واحد بلا معرّف مكرر', async () => {
    const bad = [];
    for (const role of [null, 'user', 'admin']) { const x = mk(role); for (const c of PUBLIC_SHOW.concat(PUBLIC_MEM)) { const h = c.sourceType === 'member' ? memD(x, c.id) : showD(x, c.id); if (BAD.test(h) || h.includes(ERR) || (h.match(/class="back-pill"/g) || []).length !== 1 || (h.match(/class="fav-inline"/g) || []).length !== 1 || new Set(idsIn(h)).size !== idsIn(h).length) bad.push((role || 'guest') + ':' + c.id); } }
    return bad.length === 0 || bad.slice(0, 6); });
  await tc('25) إجراءات التواصل والإدارة باقية: tel وwa.me والخريطة من بيانات المعرض للمعرض، ومن بيانات الإعلان للعضو، وزر المشاركة، وأزرار المالك (تعديل/تغيير الحالة/حذف) للمالك فقط، و«عرض صفحة المعرض»', async () => {
    const g = mk(null); const a = showD(g), b = memD(g); const o = mk('user'); const oh = memD(o, 101); const gh = memD(g, 101);
    return (a.includes('href="tel:') && a.includes('wa.me') && a.includes('google.com/maps') && a.includes(`go('showroomDetails',${SC.showroomId})`) && b.includes('href="tel:') && b.includes('wa.me') && b.includes(`handleShareMemberCar(${MC.id})`) && oh.includes('handleDeleteMemberCar(101)') && oh.includes("go('editMemberCar', 101)") && oh.includes('handleMemberCarStatusChange(101)') && !gh.includes('handleDeleteMemberCar(101)') && !gh.includes('editMemberCar')) || 'actions'; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

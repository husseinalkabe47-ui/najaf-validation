const { makeEnv } = require('./harness');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra || ''); } };

const E = makeEnv();
const R = c => E.run(c);
const setF = (o) => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
const login = (identifier, password) => { R(`go('login')`); setF({ loginIdentifier: identifier, loginPassword: password }); R('handleLoginSubmit()'); };
const fillMemberCarForm = (over = {}) => {
  const base = { mcBrand: 'Toyota', mcModel: 'Yaris', mcYear: '2021', mcPrice: '14000000', mcMileage: '30000',
    mcColor: 'أبيض', mcLocation: 'حي الحنانة، النجف', mcPhone: '07700000001', mcWhatsapp: '07700000001', mcDescription: 'سيارة نظيفة' };
  setF({ ...base, ...over });
  E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
};

t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | '));

/* ============ USER: 1..13 ============ */
login('07700000001', 'user123'); // user id=7
R(`go('addMemberCar')`);

// 1) user يضيف سيارة (يملأ النموذج ويضغط نشر)
fillMemberCarForm();
R('handleAddMemberCarSubmit()');
t('1) user يضيف سيارة (يفتح طلب النشر)', E.els.rewardAdOverlay.style.display === 'flex');

// 2) user لا ينشر قبل reward
t('2) user لا ينشر قبل اكتمال reward (لا سيارة Yaris بعد)', !R(`getMemberCarsByOwner(7).some(c=>c.model==='Yaris')`));
t('2b) البيانات لم تُحفظ بعد في MEMBER_CARS (إنشاء البيانات ≠ النشر)', !R(`getMemberCars().some(c=>c.brand==='Toyota' && c.model==='Yaris')`));

// 3) user يضغط مشاهدة الإعلان / 4) mock reward يبدأ
R('handleWatchRewardAd()');
t('3/4) الضغط على مشاهدة الإعلان يبدأ الـ Mock Reward (تظهر شاشة العرض)',
  E.els.rewardAdStepPlaying.style.display === 'block' && E.els.rewardAdStepIntro.style.display === 'none');
t('4b) مدة الإعلان ضمن 5-10 ثوانٍ (تبدأ العدّاد من 00:08)', E.els.rewardAdCountdown.textContent === '00:08');

// 5) العد التنازلي يعمل
E.tick(3);
t('5) العد التنازلي يعمل (لم يكتمل بعد بعد 3 ثوانٍ من أصل 8)', !R(`getMemberCarsByOwner(7).some(c=>c.model==='Yaris')`));

// 6) قبل اكتمال الإعلان لا يتم النشر
t('6) قبل اكتمال الإعلان لا يتم النشر', !R(`getMemberCars().some(c=>c.model==='Yaris')`));

// 7) إلغاء الإعلان لا ينشر السيارة (نلغي الآن باختبار منفصل، ثم نعيد المحاولة فعليًا)
R('handleCancelRewardAd()');
t('7) إلغاء الإعلان يوقف كل شيء ولا ينشر السيارة', !R(`getMemberCars().some(c=>c.model==='Yaris')`) && E.els.rewardAdOverlay.style.display === 'none');
t('7b) يمكن المحاولة مرة أخرى بعد الإلغاء (النموذج ما زال قابلًا للاستخدام)', R('AuthorizationService.canCreateMemberCar()') === true);

// إعادة المحاولة الفعلية حتى الاكتمال
R('handleAddMemberCarSubmit()'); // draft جديد (draftId مختلف عن السابق الملغى)
R('handleWatchRewardAd()');

// 8) انتهاء الإعلان يكمل reward / 9) السيارة تصبح active
E.tick(8);
const newCar = R(`getMemberCarsByOwner(7).find(c=>c.model==='Yaris')`);
t('8) انتهاء العدّاد يكمل الـ reward وينشر السيارة', !!newCar);
t('9) بعد reward تصبح السيارة active مباشرة (بلا pending)', newCar.status === 'active');
const newId = newCar.id;

// 10) السيارة تظهر للعامة
t('10) السيارة تظهر للعامة (getActiveMemberCars)', R(`getActiveMemberCars().some(c=>c.id===${newId})`));
R(`go('memberCars')`);
t('10b) وتظهر فعليًا في شاشة سيارات الأعضاء العامة', E.screen().includes(`onclick="go('memberCarDetails',${newId})"`));

// 11) السيارة تظهر في MyMemberCars
R(`go('myMemberCars')`);
t('11) السيارة تظهر في MyMemberCars بحالة نشط', E.screen().includes('Toyota Yaris') && E.screen().includes('نشط'));

// 12) السيارة تظهر في البحث
t('12) السيارة تظهر في البحث (سيارات الأعضاء)', R(`searchCars('Yaris','member').some(c=>c.id===${newId})`));
t('12b) وتظهر أيضًا في بحث all', R(`searchCars('Yaris','all').some(c=>c.id===${newId})`));

// 13) السيارة يمكن إضافتها للمفضلة
R(`handleFavoriteToggle(${newId})`);
t('13) السيارة الجديدة يمكن إضافتها للمفضلة', R(`isFavorite(${newId})`) === true);
R('handleLogout()');

/* ============ DEALER: 14..16 ============ */
login('07701234567', 'dealer123'); // dealer id=1, showroom 1
R(`go('addMemberCar')`);
fillMemberCarForm({ mcBrand: 'Kia', mcModel: 'Forte', mcPhone: '07701234567', mcWhatsapp: '07701234567' });
E.els.rewardAdOverlay = { style: { display: 'none' } }; // المتصفح الحقيقي يعيد بناء DOM عند التنقل؛ نحاكي ذلك هنا
R('handleAddMemberCarSubmit()');
// 14) dealer يضيف سيارة
const dealerCar = R(`getMemberCarsByOwner(1).find(c=>c.model==='Forte')`);
t('14) dealer يضيف سيارة بنجاح', !!dealerCar);
// 15) dealer لا يشاهد Reward
t('15) dealer لا يشاهد Reward (لا نافذة إعلان تُفتح، النشر فوري)', E.els.rewardAdOverlay.style.display !== 'flex');
t('15b) rewardService يؤكد عدم الحاجة لإعلان لدور dealer (المستخدم الحالي)', R(`isRewardRequired()`) === false);
// 16) dealer تصبح سيارته active مباشرة
t('16) سيارة dealer تصبح active مباشرة بلا انتظار', dealerCar.status === 'active');
t('16b) وتظهر للعامة فورًا', R(`getActiveMemberCars().some(c=>c.id===${dealerCar.id})`));
R('handleLogout()');

/* ============ ADMIN: 17 ============ */
login('07700000000', 'admin123');
R(`go('addMemberCar')`);
fillMemberCarForm({ mcBrand: 'Genesis', mcModel: 'GV80', mcPhone: '07700000000', mcWhatsapp: '07700000000' });
E.els.rewardAdOverlay = { style: { display: 'none' } };
R('handleAddMemberCarSubmit()');
const adminCar = R(`getMemberCarsByOwner(6).find(c=>c.model==='GV80')`);
t('17) admin لا يحتاج Reward وسيارته تُنشر فورًا active', !!adminCar && adminCar.status === 'active' && E.els.rewardAdOverlay.style.display !== 'flex' && R(`isRewardRequired()`) === false);
R('handleLogout()');

/* ============ 18) Reward واحد لا ينشر سيارتين ============ */
login('07700000001', 'user123');
R(`go('addMemberCar')`);
fillMemberCarForm({ mcBrand: 'Nissan', mcModel: 'Altima', mcPhone: '07700000001' });
R('handleAddMemberCarSubmit()');
R('handleWatchRewardAd()');
E.tick(8); // ينشر Altima ويستهلك الـ reward الخاص بطلبها
const altima = R(`getMemberCarsByOwner(7).find(c=>c.model==='Altima')`);
t('18-a) السيارة الأولى نُشرت بعد الإعلان الأول', !!altima);
// محاولة إعادة استخدام نفس آلية الاكتمال دون طلب إعلان جديد لسيارة ثانية
R(`go('addMemberCar')`);
fillMemberCarForm({ mcBrand: 'Nissan', mcModel: 'Maxima', mcPhone: '07700000001' });
R('handleAddMemberCarSubmit()'); // draftId جديد مختلف تمامًا عن draft الـ Altima
const maximaDraft = R(`_currentDraftId`);
const reuse = R(`publishMemberCarAfterReward('${maximaDraft}')`); // بلا مشاهدة إعلان جديد: الخدمة يجب أن ترفض
t('18) Reward واحد لا ينشر سيارتين: مسودة ثانية بلا إعلان جديد تُرفض',
  reuse.ok === false && !R(`getMemberCarsByOwner(7).some(c=>c.model==='Maxima')`));
t('18b) طلب النشر الأول استُهلك (لا يمكن إعادة نشره)', R(`publishMemberCarAfterReward('draft_1_7')`).ok === false);
R('handleCancelRewardAd()'); // تنظيف
R('handleLogout()');

/* ============ 19) إعادة تحميل الصفحة لا تعطي reward تلقائيًا ============ */
{
  const E2 = makeEnv();
  E2.run(`go('login')`); Object.entries({ loginIdentifier: '07700000001', loginPassword: 'user123' }).forEach(([k, v]) => E2.els[k] = { value: v, style: {} }); E2.run('handleLoginSubmit()');
  E2.run(`go('addMemberCar')`);
  Object.entries({ mcBrand: 'Kia', mcModel: 'ReloadTest', mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07700000001', mcWhatsapp: '', mcDescription: '' })
    .forEach(([k, v]) => E2.els[k] = { value: v, style: {} });
  E2.els.mcTransmission = { value: 'أوتوماتيك' }; E2.els.mcFuelType = { value: 'بنزين' };
  E2.run('handleAddMemberCarSubmit()');
  E2.run('handleWatchRewardAd()');
  E2.tick(3); // منتصف الإعلان فقط — لم يكتمل بعد
  // "إعادة تحميل الصفحة": بيئة جديدة تمامًا بنفس التخزين (drafts/reward في الذاكرة فقط ولا تُحفظ)
  const E3 = makeEnv(E2.store);
  t('19) إعادة تحميل الصفحة لا تمنح reward تلقائيًا ولا تنشر السيارة المعلّقة', !E3.run(`getMemberCars().some(c=>c.model==='ReloadTest')`));
}

/* ============ 20/21) فشل/إلغاء الإعلان ============ */
login('07700000001', 'user123');
R(`go('addMemberCar')`);
fillMemberCarForm({ mcBrand: 'Toyota', mcModel: 'FailTest', mcPhone: '07700000001' });
R('handleAddMemberCarSubmit()');
const failLoad = R(`requestPublishReward(_currentDraftId, { simulateFailure: true })`);
t('20) فشل تحميل الإعلان لا يُعتبر مكتملًا ولا ينشر السيارة', failLoad.ok === false && !R(`getMemberCars().some(c=>c.model==='FailTest')`));
R('handleCancelRewardAd()');

R(`go('addMemberCar')`);
fillMemberCarForm({ mcBrand: 'Toyota', mcModel: 'CancelTest', mcPhone: '07700000001' });
R('handleAddMemberCarSubmit()');
R('handleWatchRewardAd()');
E.tick(2);
R('handleCancelRewardAd()');
t('21) إلغاء الإعلان أثناء العرض لا ينشر السيارة', !R(`getMemberCars().some(c=>c.model==='CancelTest')`));
R('handleLogout()');

/* ============ 22/23/24) بيانات pending/rejected/suspended القديمة لا تنكسر ============ */
t('22) pending القديمة (108) لا تزال موجودة وتعمل', R(`getMemberCarById(108)`) !== null && R(`getMemberCarById(108).status`) === 'pending');
t('22b) pending القديمة لا تظهر في القائمة العامة', !R(`getActiveMemberCars().some(c=>c.id===108)`));
t('23) rejected القديمة (109) لا تزال موجودة بنفس الحالة', R(`getMemberCarById(109).status`) === 'rejected');
t('24) suspended القديمة (110) لا تزال موجودة بنفس الحالة', R(`getMemberCarById(110).status`) === 'suspended');

/* ============ 25/26/27/28) لوحة الإدارة، الصلاحيات، الراوتر ============ */
const adminRoutes = ['adminHome', 'adminDashboard', 'adminMemberCars', 'adminShowrooms', 'adminShowroomCars', 'adminUsers', 'adminDealerRequests'];
login('07700000001', 'user123');
t('26) user لا يدخل لوحة الإدارة', adminRoutes.every(r => { R(`go('${r}')`); return R('currentRoute') === 'accessDenied'; }));
R('handleLogout()');

login('07701234567', 'dealer123');
t('27) dealer لا يدخل لوحة الإدارة', adminRoutes.every(r => { R(`go('${r}')`); return R('currentRoute') === 'accessDenied'; }));
R('handleLogout()');

login('07700000000', 'admin123');
R(`go('adminHome')`);
t('28) admin يدخل لوحة الإدارة', R('currentRoute') === 'adminHome' && E.screen().includes('لوحة الإدارة'));
t('25) لوحة الإدارة ما زالت تعمل (الإحصائيات + سيارات الأعضاء الجديدة محسوبة)', getStatsOk());
function getStatsOk() {
  const s = R('getDashboardStats()');
  return s.totalMemberCars >= 14 && s.activeMemberCars >= 8; // 10 أصلية + Yaris/Forte/GV80/Altima جديدة، ناقص واحدة محذوفة لاحقًا إن وجدت
}
R(`go('adminMemberCars')`);
t('25b) شاشة إدارة سيارات الأعضاء تعمل وتعرض السيارات الجديدة أيضًا', E.screen().includes('Toyota Yaris') || E.screen().includes('Forte'));
R('handleLogout()');

/* ============ 29/30 ============ */
t('29) searchService لا يتأثر (توقيع showroom/member/all كما هو)', R(`searchCars('Toyota').every(c=>c.sourceType==='showroom')`) && R(`searchCars('Toyota','member').every(c=>c.sourceType==='member')`));
t('30) favoritesService لا يتأثر (يعمل بنفس الواجهة toggleFavorite/isFavorite/getFavoriteCars)', R("typeof toggleFavorite") === 'function' && R("typeof isFavorite") === 'function' && R("typeof getFavoriteCars") === 'function');

console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
process.exit(fail ? 1 : 0);

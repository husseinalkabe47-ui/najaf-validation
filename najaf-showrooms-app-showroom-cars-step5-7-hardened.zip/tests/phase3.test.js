const { makeEnv } = require('./harness');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra || ''); } };

let E = makeEnv();
t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | '));
const R = c => E.run(c);
const setF = (o) => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));

// 1) زائر يتصفح
['home','showrooms','cars','map','favorites','showroomDetails','carDetails'].forEach(r => {
  R(`go('${r}', ${r==='showroomDetails'||r==='carDetails' ? 1 : 'undefined'})`);
});
R(`go('home')`); const homeHtml = E.screen();
t('1) الزائر يتصفح كل الشاشات بدون خطأ', E.errors.length === 0);
t('1b) زر الرئيسية للزائر = «تسجيل الدخول»', homeHtml.includes('تسجيل الدخول'));
R(`go('cars')`); t('1c) قائمة السيارات تظهر للزائر (9 بعد سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي؛ كانت 12 بعد C7، و15)', (E.screen().match(/class="card car-card"/g)||[]).length === 9);
R(`go('favorites')`); t('1d) المفضلة للزائر تطلب تسجيل دخول', E.screen().includes('سجّل الدخول لحفظ'));

// الزائر لا يدخل المناطق المحمية
R(`go('adminHome')`); t('guard) زائر → adminHome يحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
R(`go('dealerHome')`); t('guard) زائر → dealerHome يحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
R(`go('account')`); t('guard) زائر → account يحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
R(`handleFavoriteToggle(1)`); t('5a) الزائر يضغط ❤️ → يذهب لتسجيل الدخول', R('currentRoute') === 'login');

// 2) إنشاء حساب: أخطاء
R(`go('register')`);
setF({regName:'أ', regPhone:'123', regEmail:'', regPassword:'123456', regConfirm:'123456'}); R('handleRegisterSubmit()');
t('2a) رفض اسم قصير', E.els.registerError.textContent.includes('الاسم'));
setF({regName:'سالم حسن', regPhone:'123', regEmail:'', regPassword:'123456', regConfirm:'123456'}); R('handleRegisterSubmit()');
t('2b) رفض هاتف غير صحيح', E.els.registerError.textContent.includes('الهاتف'));
setF({regName:'سالم حسن', regPhone:'07712345678', regEmail:'bad', regPassword:'123456', regConfirm:'123456'}); R('handleRegisterSubmit()');
t('2c) رفض بريد غير صحيح', E.els.registerError.textContent.includes('البريد'));
setF({regName:'سالم حسن', regPhone:'07712345678', regEmail:'', regPassword:'123', regConfirm:'123'}); R('handleRegisterSubmit()');
t('2d) رفض كلمة مرور قصيرة', E.els.registerError.textContent.includes('6'));
setF({regName:'سالم حسن', regPhone:'07712345678', regEmail:'', regPassword:'123456', regConfirm:'654321'}); R('handleRegisterSubmit()');
t('2e) رفض تأكيد غير مطابق', E.els.registerError.textContent.includes('مطابق'));
setF({regName:'سالم حسن', regPhone:'07701234567', regEmail:'', regPassword:'123456', regConfirm:'123456'}); R('handleRegisterSubmit()');
t('2f) رفض هاتف مكرر', E.els.registerError.textContent.includes('مسبقًا'));
// نجاح: مستخدم عادي (هاتف بأرقام عربية)
setF({regName:'سالم حسن', regPhone:'٠٧٧١٢٣٤٥٦٧٨', regEmail:'salem@example.com', regPassword:'123456', regConfirm:'123456'}); E.radios.accountType='user'; R('handleRegisterSubmit()');
t('2) إنشاء حساب مستخدم عادي ينجح ويدخل الحساب', R('currentRoute') === 'account' && R('SessionService.getCurrentUser().role') === 'user' && R('SessionService.getCurrentUser().status') === 'active');
t('2g) الشاشات لا تحصل على passwordHash', R('SessionService.getCurrentUser().passwordHash') === undefined);
const newUserId = R('SessionService.getCurrentUser().id');
t('11a) المستخدم الجديد بلا صلاحيات dealer/admin', !R('AuthorizationService.canAccessDealerArea()') && !R('AuthorizationService.canAccessAdmin()') && !R('AuthorizationService.canManageUsers()') && !R('AuthorizationService.canManageShowroom(1)') && !R('AuthorizationService.canManageCar(1)'));
R(`go('adminHome')`); t('11b) المستخدم العادي → adminHome = غير مصرّح', R('currentRoute') === 'accessDenied' && E.screen().includes('غير مصرّح'));
R(`go('dealerHome')`); t('11c) المستخدم العادي → dealerHome = غير مصرّح', R('currentRoute') === 'accessDenied');
R(`go('home')`); t('9a) زر الرئيسية للمستخدم = «حسابي»', E.screen().includes('حسابي'));

// 5/6) المفضلة مرتبطة بالمستخدم
R(`handleFavoriteToggle(3)`); R(`handleFavoriteToggle(5)`);
t('5) إضافة مفضلة للمستخدم', R('isFavorite(3)') && R('isFavorite(5)') && R('getFavoriteCars().length') === 2);
R(`handleFavoriteToggle(3)`);
t('5b) إزالة مفضلة', !R('isFavorite(3)') && R('getFavoriteCars().length') === 1);
// 4) خروج
R('handleLogout()');
t('4) تسجيل الخروج يعيد الحالة للزائر', !R('SessionService.isLoggedIn()') && R('currentRoute') === 'home' && E.screen().includes('تسجيل الدخول'));
t('6a) بعد الخروج: لا مفضلة ظاهرة للزائر', R('getFavoriteCars().length') === 0 && !R('isFavorite(5)'));

// 3) دخول: أخطاء ونجاح
R(`go('login')`);
setF({loginIdentifier:'07700000001', loginPassword:'wrong'}); R('handleLoginSubmit()');
t('3a) كلمة مرور خاطئة تُرفض', E.els.loginError.textContent.includes('غير صحيحة') && !R('SessionService.isLoggedIn()'));
setF({loginIdentifier:'nobody@x.com', loginPassword:'user123'}); R('handleLoginSubmit()');
t('3b) حساب غير موجود يُرفض بنفس الرسالة العامة', E.els.loginError.textContent.includes('غير صحيحة'));
setF({loginIdentifier:'07700000001', loginPassword:'user123'}); R('handleLoginSubmit()');
t('3) دخول المستخدم التجريبي بالهاتف', R('SessionService.getCurrentUser().name') === 'مستخدم تجريبي' && R('currentRoute') === 'home');
R('handleLogout()'); R(`go('login')`);
setF({loginIdentifier:'USER@example.com', loginPassword:'user123'}); R('handleLoginSubmit()');
t('3c) الدخول بالبريد (غير حساس لحالة الأحرف)', R('SessionService.isLoggedIn()'));

// 6) المفضلة منفصلة بين المستخدمين
R('handleFavoriteToggle(11)');   // (سياسة الظهور العام) كانت 7 من معرض قيد المراجعة صار مخفيًا فلا تُقبل مفضلته؛ 11 سيارة ظاهرة
R('handleLogout()'); R(`go('login')`);
setF({loginIdentifier:'07701234567', loginPassword:'dealer123'}); R('handleLoginSubmit()');
t('6) مفضلة مستخدم لا تظهر لمستخدم آخر', R('getFavoriteCars().length') === 0 && !R('isFavorite(11)'));

// 7/8/9) Dealer
t('7) دخول Dealer التجريبي', R('SessionService.getCurrentUser().role') === 'dealer');
t('9b) زر الرئيسية للتاجر = «إدارة معرضي»', (R(`go('home')`), E.screen().includes('إدارة معرضي')));
t('8) Dealer مرتبط بمعرضه عبر ownerId', R('AuthorizationService.getManagedShowrooms().map(s=>s.id).join()') === '1' && R('getShowroomById(1).ownerId') === R('SessionService.getCurrentUser().id'));
R(`go('dealerHome')`);
t('8b) شاشة إدارة معرضي تعرض معرضه فقط', R('currentRoute') === 'dealerHome' && E.screen().includes('معرض النجف للسيارات') && !E.screen().includes('معرض الفرات الذهبي'));
t('9) Dealer يدير معرضه وسياراته', R('AuthorizationService.canManageShowroom(1)') && R('AuthorizationService.canManageCar(1)') && R('AuthorizationService.canManageCar(3)'));
t('9c) Dealer لا يدير معرض Dealer آخر (2..5)', [2,3,4,5].every(id => !R(`AuthorizationService.canManageShowroom(${id})`)));
t('9d) Dealer لا يدير سيارات معارض أخرى', [4,5,6,7,10,15].every(id => !R(`AuthorizationService.canManageCar(${id})`)));
t('9e) Dealer لا يرى بيانات Dealer آخر (id=2)', R('UserService.getProfile(2)') === null && R('UserService.getProfile(1)') !== null);
t('9f) Dealer ليس admin', !R('AuthorizationService.canAccessAdmin()') && !R('AuthorizationService.canManageUsers()') && !R('AuthorizationService.canApproveDealers()'));
R(`go('adminHome')`); t('9g) Dealer → adminHome = غير مصرّح', R('currentRoute') === 'accessDenied');
// محاولة تجاوز يدوي: تغيير متغير المسار مباشرة
R(`currentRoute='adminHome'; render()`); t('9h) تجاوز currentRoute يدويًا لا ينفع', R('currentRoute') === 'accessDenied' && !E.screen().includes('لوحة الإدارة</h1>'));
// محاولة تزوير كائن مستخدم بدور admin
t('9i) تمرير كائن مستخدم مزوَّر role=admin لا يمنح صلاحية', !R(`AuthorizationService.canAccessAdmin({id:1,role:'admin',status:'active'})`));
// تلاعب بالجلسة المخزنة: تغيير الدور داخل الجلسة لا يفيد (الدور يُقرأ من السجل)
E.store['najaf.session'] = JSON.stringify({ userId: 1, role: 'admin', createdAt: Date.now(), expiresAt: Date.now() + 1e6 });
t('9j) تعديل الدور داخل الجلسة المخزنة لا يفيد', !R('AuthorizationService.canAccessAdmin()') && R('SessionService.getCurrentUser().role') === 'dealer');
R('handleLogout()');

// Dealer #2 يرى معرضه هو فقط
R(`go('login')`); setF({loginIdentifier:'07709876543', loginPassword:'dealer123'}); R('handleLoginSubmit()');
t('9k) Dealer #2 يدير معرض 2 فقط', R('AuthorizationService.getManagedShowrooms().map(s=>s.id).join()') === '2' && !R('AuthorizationService.canManageShowroom(1)') && !R('AuthorizationService.canManageCar(1)'));
R('handleLogout()');

// 10) Admin
R(`go('login')`); setF({loginIdentifier:'07700000000', loginPassword:'admin123'}); R('handleLoginSubmit()');
t('10) Admin يمتلك صلاحية admin', R('AuthorizationService.canAccessAdmin()') && R('AuthorizationService.canManageUsers()') && R('AuthorizationService.canApproveDealers()') && R('AuthorizationService.canManageShowroom(3)') && R('AuthorizationService.canManageCar(9)'));
t('9m) زر الرئيسية للمدير = «لوحة الإدارة»', (R(`go('home')`), E.screen().includes('لوحة الإدارة')));
R(`go('adminHome')`); t('10b) Admin يفتح لوحة الإدارة (واجهة أولية)', R('currentRoute') === 'adminHome');
t('10c) Admin يرى بيانات أي مستخدم', R('UserService.getProfile(2)') !== null && R('UserService.getProfile(2).passwordHash') === undefined);
R('handleLogout()');

// صاحب معرض جديد = pending
R(`go('register')`); E.radios.accountType='dealer';
setF({regName:'كرار علي', regPhone:'07723456789', regEmail:'', regPassword:'abc123', regConfirm:'abc123'}); R('handleRegisterSubmit()');
t('2h) صاحب معرض جديد حالته pending', R('SessionService.getCurrentUser().status') === 'pending' && R('SessionService.getCurrentUser().role') === 'dealer');
t('2i) الـ pending لا يملك صلاحية إدارة أبدًا', !R('AuthorizationService.canAccessDealerArea()') && !R('AuthorizationService.canManageShowroom(1)') && !R('AuthorizationService.canManageCar(1)'));
t('2j) الـ pending يرى «حسابي» لا «إدارة معرضي»', (R(`go('home')`), E.screen().includes('حسابي') && !E.screen().includes('إدارة معرضي')));
R(`go('dealerHome')`); t('2k) الـ pending → dealerHome = غير مصرّح', R('currentRoute') === 'accessDenied');
const pendingId = R('SessionService.getCurrentUser().id');
R('handleLogout()');

// التسجيل لا يمنح admin أبدًا
const r1 = R(`AuthService.register({name:'مخترق',phone:'07799999999',password:'123456',confirmPassword:'123456',accountType:'admin'})`);
t('11d) لا يمكن إنشاء admin من التسجيل', r1.ok === false && R(`UserService._findByIdentifier('07799999999')`) === null);

// 12) إعادة تحميل الصفحة
R(`go('login')`); setF({loginIdentifier:'07700000001', loginPassword:'user123'}); R('handleLoginSubmit()'); R('handleFavoriteToggle(6)'); R('handleFavoriteToggle(12)');   // (كانت 9 من المعرض 3 المخفي)
const savedStore = E.store;
const E2 = makeEnv(savedStore);   // "إعادة تحميل": بيئة جديدة بنفس التخزين
t('12a) الجلسة تبقى بعد إعادة التحميل', E2.run('SessionService.getCurrentUser() && SessionService.getCurrentUser().name') === 'مستخدم تجريبي' && E2.errors.length === 0);
t('12b) المفضلة تبقى بعد إعادة التحميل (11 من قبل + 6 و12)', E2.run('getFavoriteCars().map(c=>c.id).join()') === '11,6,12');
t('12c) الحسابات المسجَّلة تبقى (سالم + الـ pending)', E2.run(`UserService._findByIdentifier('07712345678') !== null && UserService._findByIdentifier('07723456789').status === 'pending'`));
E2.run(`handleLogout()`);
const E3 = makeEnv(savedStore);
t('12d) بعد الخروج وإعادة التحميل: زائر', E3.run('SessionService.getCurrentUser()') === null);
// انتهاء الجلسة
savedStore['najaf.session'] = JSON.stringify({ userId: 7, createdAt: 1, expiresAt: 2 });
t('12e) الجلسة المنتهية تُرفض', makeEnv(savedStore).run('SessionService.getCurrentUser()') === null);

// 13/14/15) كل الشاشات + RTL + أخطاء
const E4 = makeEnv();
['home','showrooms','cars','map','favorites','login','register','accessDenied'].forEach(r => E4.run(`go('${r}')`));
E4.run(`go('showroomDetails',5)`); E4.run(`go('carDetails',15)`);
E4.run(`go('cars')`); E4.run(`onCarsSearch('Toyota')`);
t('13) البحث ما زال يعمل (Toyota=1 بعد سياسة الظهور العام؛ كانت 2 بعد C7، و3)', (E4.els.carsList.innerHTML.match(/class="card car-card"/g)||[]).length === 1);
E4.run(`onShowroomsSearch('الفرات')`);
t('13b) بحث المعارض ما زال يعمل', E4.els.showroomsList.innerHTML.includes('الفرات الذهبي'));
E4.run(`go('home')`);
const h = E4.screen();
t('13c) مكوّنات AdSlot ما زالت موجودة', (h.match(/data-ad-slot/g)||[]).length >= 1);
t('15) لا أخطاء JavaScript في كل الشاشات', E4.errors.length === 0, E4.errors.join('|'));
const html = fs = require('fs').readFileSync(require('path').resolve(__dirname,'..') + '/index.html','utf8');
t('14) الصفحة ما زالت RTL عربية', html.includes('lang="ar" dir="rtl"'));
console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
process.exit(fail ? 1 : 0);

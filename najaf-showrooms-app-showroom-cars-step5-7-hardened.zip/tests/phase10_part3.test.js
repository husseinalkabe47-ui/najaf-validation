/* اختبارات «المرحلة 10 — الجزء 3: عرض السيارات والمعارض» (Phase 10 Part 3).
   تغطي: بيانات بطاقة السيارة · البيانات الناقصة · بديل الصورة · معلومات المعرض · حالة السيارة · الحالات الفارغة ·
         سلامة البيانات غير الصالحة · التفاصيل وتجميع المعلومات · الاستجابة للهاتف والاتساق مع التصميم الحالي.
   كُتبت قبل التنفيذ لإثبات النواقص ثم مرّت. تفحص مخرجات HTML الفعلية من الشاشات والمكوّنات. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 200)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const BAD = /undefined|\bnull\b|NaN|\[object|TypeError|ReferenceError/;
const ERR = 'حدث خطأ، حاول مرة أخرى';
const card = (x, id) => x.R(`CarCard(getCarById(${id}))`);
const push = (x, code) => x.R(code);
const idx = (h, s) => h.indexOf(s);
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const addImg = (x, carId, url, extra = '') => x.R(`CAR_IMAGES.push({ id: ${9000 + carId}, carId: ${carId}, imageUrl: ${JSON.stringify(url)}, sortOrder: 0, isMain: true${extra} })`);

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) بيانات بطاقة السيارة ======================= */
  console.log('\n--- A) بطاقة السيارة ---');
  await tc('A1) سيارة معرض كاملة: صورة/بديل، الماركة والموديل، السنة، السعر، المسافة، ناقل الحركة، الوقود، اسم المعرض، الحالة، المفضلة، وفتح التفاصيل', async () => {
    const g = mk(null); const h = card(g, 1);
    const need = ['🚘', 'Toyota Corolla', '2022', 'د.ع', g.R('km(65000)'), 'كم', 'أوتوماتيك', 'بنزين', 'معرض النجف للسيارات', 'متاحة للبيع', 'handleFavoriteToggle(1)', "go('carDetails',1)", 'عرض السيارة'];
    const missing = need.filter(s => !h.includes(s)); return missing.length === 0 || missing; });
  await tc('A2) التسلسل الهرمي: العنوان ثم السعر ثم المواصفات الموجزة ثم المسافة ثم المعرض ثم الحالة ثم زر العرض', async () => {
    const h = card(mk(null), 1); const order = ['card-title', 'class="price', 'card-sub', 'card-mileage', 'card-showroom', 'badge', 'btn-primary'].map(s => idx(h, s));
    return (order.every(i => i >= 0) && order.every((v, i) => i === 0 || v > order[i - 1])) || order; });
  await tc('A3) المواصفات الموجزة في سطر واحد بفاصل (سنة • ناقل حركة • وقود) ولا تكرار لـ«|» القديم', async () => {
    const h = card(mk(null), 1); const sub = (h.match(/<p class="card-sub">([\s\S]*?)<\/p>/) || [])[1] || '';
    return (sub.includes('2022') && sub.includes('أوتوماتيك') && sub.includes('بنزين') && sub.includes('•') && !h.includes(' | ')) || sub; });
  await tc('A4) المفضلة: الرمز يعكس الحالة (🤍/❤️) ولها aria-label وaria-pressed، وضغطها لا يفتح التفاصيل', async () => {
    const u = mk('user'); const before = card(u, 1); u.R('toggleFavorite(1)'); const after = card(u, 1);
    return before.includes('🤍') && after.includes('❤️') && before.includes('aria-pressed="false"') && after.includes('aria-pressed="true"') && /aria-label="[^"]+"/.test(before) && before.includes('event.stopPropagation();handleFavoriteToggle(1)'); });
  await tc('A5) سيارة عضو: الموقع وشارة «من عضو» والمواصفات، بلا صف معرض', async () => {
    const g = mk(null); const h = g.R(`CarCard(getCarById(101))`);
    return h.includes('Toyota Corolla') && h.includes('2019') && h.includes('حي النصر') && h.includes('من عضو') && h.includes("go('memberCarDetails',101)") && !h.includes('card-showroom') && !h.includes('🏢') && h.includes('د.ع'); });
  await tc('A6) كل بطاقة ما زالت class="card car-card" حرفيًا (تعتمد عليها اختبارات العدّ) ولا class إضافية على الجذر', async () => {
    const g = mk(null); g.R(`go('cars')`); const n = (g.E.screen().match(/class="card car-card"/g) || []).length; return n === 9 /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && !/class="card car-card[ "][^>]*is-/.test(g.E.screen()); });
  await tc('A7) البطاقة في كل المواضع (الرئيسية، السيارات، الأعضاء، البحث، المفضلة، المعرض) تحوي نفس العناصر الأساسية', async () => {
    const x = mk('user'); x.R('toggleFavorite(1)'); const bad = [];
    const check = (name, html) => { if (!['card-title', 'class="price', 'handleFavoriteToggle(', 'btn-primary'].every(s => html.includes(s))) bad.push(name); };
    x.R(`go('home')`); check('home', x.E.screen()); x.R(`go('cars')`); check('cars', x.E.screen()); x.R(`go('memberCars')`); check('memberCars', x.E.screen());
    x.R(`go('search','corolla')`); check('search', x.E.screen()); x.R(`go('favorites')`); check('favorites', x.E.screen()); x.R(`go('showroomDetails',1)`); check('showroom', x.E.screen());
    return bad.length === 0 || bad; });

  /* ======================= B) بيانات ناقصة ======================= */
  console.log('\n--- B) بيانات ناقصة ---');
  const MINIMAL = `CARS.push(CarModel({ id: 9101, sourceType:'showroom', showroomId: 1, brand:'Bare', model:'Minimal', status:'available' }))`;
  await tc('B1) سيارة بلا سنة/سعر/مسافة/ناقل/وقود: لا صفوف فارغة ولا «—» ولا فواصل يتيمة، والسعر «السعر غير محدد»', async () => {
    const x = mk(null); x.R(MINIMAL); const h = card(x, 9101);
    return (h.includes('Bare Minimal') && h.includes('السعر غير محدد') && !h.includes('—') && !h.includes('card-sub') && !h.includes('card-mileage') && !BAD.test(h) &&
      !/<p class="card-row">\s*<\/p>/.test(h) && !h.includes('💰 —') && !h.includes(' | ') && !h.includes('•')) || h; });
  await tc('B2) بيانات جزئية: تظهر الموجودة فقط (سنة فقط → «2020» بلا فاصل، ناقل فقط → بلا سنة)', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9102, sourceType:'showroom', showroomId: 1, brand:'P', model:'Y', year: 2020, status:'available' }))`);
    x.R(`CARS.push(CarModel({ id: 9103, sourceType:'showroom', showroomId: 1, brand:'P', model:'T', transmission:'يدوي', status:'available' }))`);
    const a = card(x, 9102), b = card(x, 9103); const sa = (a.match(/<p class="card-sub">([\s\S]*?)<\/p>/) || [])[1], sb = (b.match(/<p class="card-sub">([\s\S]*?)<\/p>/) || [])[1];
    return (String(sa).trim() === '2020' && String(sb).trim() === 'يدوي') || { sa, sb }; });
  await tc('B3) مسافة 0 المُدخلة صراحةً تُعرض («0 كم»)، والمجهولة (null/فارغة) لا تُعرض إطلاقًا', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9104, sourceType:'showroom', showroomId: 1, brand:'Z', model:'Zero', year: 2024, price: 5000, mileage: 0, status:'available' }))`);
    x.R(`CARS.push(CarModel({ id: 9105, sourceType:'showroom', showroomId: 1, brand:'Z', model:'Unk', year: 2024, price: 5000, mileage: null, status:'available' }))`);
    return card(x, 9104).includes('card-mileage') && card(x, 9104).includes(x.R('km(0)')) && !card(x, 9105).includes('card-mileage'); });
  await tc('B4) ماركة وموديل كلاهما ناقص: عنوان بديل «سيارة» بدل عنوان فارغ', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9106, sourceType:'showroom', showroomId: 1, price: 1000, status:'available' }))`); const h = card(x, 9106);
    return /card-title">[^<]*سيارة/.test(h) && !/card-title">\s*🚘\s*<\/p>/.test(h) && !BAD.test(h) || h; });
  await tc('B5) معرض السيارة غير موجود/مخفي: لا صف معرض ولا «—»، والبطاقة سليمة', async () => {
    const a = mk('admin'); a.R(`CARS.push(CarModel({ id: 9107, sourceType:'showroom', showroomId: 999, brand:'O', model:'Orphan', year: 2020, price: 1000, status:'available' }))`);
    const h = card(a, 9107); return (!h.includes('card-showroom') && !h.includes('🏢') && !h.includes('—') && !BAD.test(h)) || h; });
  await tc('B6) حالة غير معرَّفة أو ناقصة: لا تُعرض شارة (لا رمز خام ولا «undefined»)', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9108, sourceType:'showroom', showroomId: 1, brand:'S', model:'Weird', year: 2020, price: 1000, status:'zzz' }))`); x.R(`CARS.push(Object.assign(CarModel({ id: 9109, sourceType:'showroom', showroomId: 1, brand:'S', model:'NoStatus', year: 2020, price: 1000 }), { status: undefined }))`);   // CarModel يضيف «available» افتراضيًا، فنزيلها
    return [9108, 9109].every(id => { const h = card(x, id); return !h.includes('zzz') && !h.includes('class="badge') && !BAD.test(h); }); });
  await tc('B7) سيارة عضو بلا موقع/مسافة: لا صف موقع ولا «—»', async () => {
    const x = mk(null); x.R(`MEMBER_CARS.push(CarModel({ id: 9110, sourceType:'member', ownerId: 7, brand:'M', model:'NoLoc', year: 2020, price: 1000, status:'active' }))`);
    const h = x.R(`CarCard(getCarById(9110))`); return (!h.includes('card-location') && !h.includes('📍') && !h.includes('—') && h.includes('من عضو') && !BAD.test(h)) || h; });
  await tc('B8) تفاصيل سيارة ناقصة: لا مواصفات فارغة ولا «—» ولا كتلة وصف أو معرض فارغة، والأقسام الموجودة فقط', async () => {
    const x = mk(null); x.R(MINIMAL); x.R(`go('carDetails',9101)`); const h = x.E.screen();
    return (h.includes('Bare Minimal') && h.includes('السعر غير محدد') && !h.includes('—') && !BAD.test(h) && !h.includes('المواصفات') && !h.includes('الوصف') && h.includes('الحالة') && h.includes('متاحة للبيع')) || h; });
  await tc('B9) تفاصيل: كل مواصفة تُعرض بقيمتها فقط (ناقص اللون → لا خانة «اللون»)', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9111, sourceType:'showroom', showroomId: 1, brand:'N', model:'NoColor', year: 2021, price: 1000, mileage: 1200, transmission:'أوتوماتيك', fuelType:'بنزين', status:'available' }))`);
    x.R(`go('carDetails',9111)`); const h = x.E.screen(); return ['السنة', 'المسافة', 'ناقل الحركة', 'الوقود'].every(s => h.includes(s)) && !h.includes('اللون') && !h.includes('—'); });

  /* ======================= C) بديل الصورة ======================= */
  console.log('\n--- C) الصور ---');
  await tc('C1) بلا صورة: بديل آمن (🚘 داخل عنصر img-ph)، بلا <img> ولا رابط مكسور', async () => {
    const h = card(mk(null), 1); return (h.includes('img-ph') && h.includes('🚘') && !h.includes('<img')) || h; });
  await tc('C2) مع صورة حقيقية (رابط https): <img> بنسبتها، alt وصفي (ماركة + موديل)، loading=lazy، وonerror يستدعي imgFallback', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9201, sourceType:'showroom', showroomId: 1, brand:'Kia', model:'ImgCar', year: 2020, price: 1000, status:'available' }))`); addImg(x, 9201, 'https://example.com/car.jpg');
    const h = card(x, 9201);
    return (h.includes('<img') && h.includes('src="https://example.com/car.jpg"') && h.includes('alt="Kia ImgCar"') && h.includes('loading="lazy"') && h.includes('onerror="imgFallback(this)"') && !h.includes('img-ph')) || h; });
  await tc('C3) imgFallback موجودة: تستبدل الصورة المكسورة ببديل ولا ترمي استثناءً حتى مع مدخلات غريبة', async () => {
    const x = mk(null); const exists = x.R('typeof imgFallback') === 'function';
    const calls = ['imgFallback(null)', 'imgFallback(undefined)', 'imgFallback({})', 'imgFallback(42)', `imgFallback({ parentNode: null })`].map(c => { try { x.R(c); return true; } catch (e) { return c; } });
    x.R(`document.createElement = tag => ({ tag, className: '', textContent: '', setAttribute() {} })`);   // محاكي الاختبارات لا يوفّر createElement
    const swapped = x.R(`(function(){ let replaced = null; const img = { getAttribute(k){ return k === 'data-ph' ? '🏢' : null; }, replaceWith(n){ replaced = n; }, onerror: function(){} }; imgFallback(img); return !!replaced && replaced.className === 'img-ph' && replaced.textContent === '🏢' && img.onerror === null; })()`);
    const hidden = x.R(`(function(){ delete document.createElement; const img = { style: {}, replaceWith(){}, onerror: function(){} }; imgFallback(img); return img.style.display === 'none'; })()`);   // بلا DOM: تُخفى المكسورة ولا استثناء
    const thumb = x.R(`(function(){ let removed = false; const img = { remove(){ removed = true; }, onerror: function(){} }; imgThumbFallback(img); imgThumbFallback(null); return removed && img.onerror === null; })()`);
    return (exists && calls.every(c => c === true) && swapped === true && hidden === true && thumb === true) || { exists, calls, swapped, hidden, thumb }; });
  await tc('C4) رابط الصورة يُهرَّب: محاولة كسر الخاصية بعلامة اقتباس لا تُنتج خاصية جديدة', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9202, sourceType:'showroom', showroomId: 1, brand:'X', model:'Inj', year: 2020, price: 1000, status:'available' }))`);
    addImg(x, 9202, 'https://x.example/a.jpg" onerror="alert(1)'); const h = card(x, 9202);
    return (!/src="https:\/\/x\.example\/a\.jpg" onerror="alert/.test(h) && h.includes('&quot;')) || h; });
  await tc('C5) سجلات صور ناقصة/غريبة (رابط غير نصي، null، فارغ، assets/ وهمي، javascript:) لا تكسر البطاقة ولا التفاصيل', async () => {
    const x = mk(null); const bad = [];
    [['null', 'nul'], ['42', 'num'], ["''", 'empty'], ["'assets/cars/x.jpg'", 'asset'], ["'javascript:alert(1)'", 'js'], ['{}', 'obj']].forEach(([u, name], i) => {
      const id = 9300 + i; x.R(`CARS.push(CarModel({ id: ${id}, sourceType:'showroom', showroomId: 1, brand:'I', model:'${name}', year: 2020, price: 1000, status:'available' }))`);
      x.R(`CAR_IMAGES.push({ id: ${9400 + i}, carId: ${id}, imageUrl: ${u}, sortOrder: 0, isMain: true })`);
      try { const h = card(x, id); if (!h.includes('class="card car-card"') || BAD.test(h) || h.includes('javascript:')) bad.push('card:' + name); x.R(`go('carDetails',${id})`); const d = x.E.screen(); if (d.includes(ERR) || BAD.test(d) || d.includes('javascript:')) bad.push('details:' + name); } catch (e) { bad.push('EXC:' + name); }
    });
    return bad.length === 0 || bad; });
  await tc('C6) التفاصيل: صورة رئيسية بنسبتها أو بديل، وشريط الصور المصغّرة (≥2) مع onerror يزيل المكسور، بلا صور مكسورة', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9203, sourceType:'showroom', showroomId: 1, brand:'G', model:'Gallery', year: 2020, price: 1000, status:'available' }))`);
    addImg(x, 9203, 'https://example.com/1.jpg'); x.R(`CAR_IMAGES.push({ id: 9604, carId: 9203, imageUrl: 'https://example.com/2.jpg', sortOrder: 1, isMain: false })`);
    x.R(`go('carDetails',9203)`); const h = x.E.screen(); const none = mk(null); none.R(`go('carDetails',1)`);
    return (h.includes('class="detail-hero"') && h.includes('<img') && h.includes('img-strip') && (h.match(/onerror="imgFallback\(this\)"|onerror="imgThumbFallback\(this\)"/g) || []).length >= 3 && none.E.screen().includes('img-ph') && !none.E.screen().includes('<img')) || h; });
  await tc('C7) النظام الحالي للتخزين/الضغط لم يُمسّ: لا ملفات جديدة للصور ولا تغيير في ImageStore/imageService/carImagesService', async () => {
    const files = fs.readdirSync(path.join(ROOT, 'services')).filter(f => /image/i.test(f)).sort(); return JSON.stringify(files) === JSON.stringify(['carImagesService.js', 'imageService.js', 'imageStore.js']) || files; });

  /* ======================= D) معلومات المعرض ======================= */
  console.log('\n--- D) معلومات المعرض ---');
  await tc('D1) بطاقة سيارة المعرض: اسم المعرض في صف مميّز (card-showroom) من بيانات المعرض الفعلية، وسيارات معارض مختلفة تُظهر معارضها', async () => {
    const g = mk(null); const a = card(g, 1), b = card(g, 4), c = card(g, 10);   // سيارات من معارض ظاهرة 1 و2 و4 (سيارة المعرض 3 قيد المراجعة مخفية فلا بطاقة لها)
    const n = id => g.R(`getShowroomById(${id}).name`);
    return a.includes('card-showroom') && a.includes(n(1)) && b.includes(n(2)) && c.includes(n(4)) && !a.includes(n(2)) && !card(g, 7).includes(n(3)) && !card(g, 7).includes('card-showroom'); });   // بطاقة سيارة من معرض مخفي (3 قيد المراجعة) لا تسرّب اسم معرضها
  await tc('D2) تفاصيل سيارة المعرض: كتلة المعرض (الاسم، العنوان، الدوام، عدد السيارات، رابط صفحة المعرض) من البيانات الفعلية فقط', async () => {
    const g = mk(null); g.R(`go('carDetails',1)`); const h = g.E.screen(); const s = J(g, 'getShowroomById(1)');
    return (h.includes('🏢 المعرض') && h.includes(s.name) && h.includes(s.address) && h.includes(s.workingHours) && h.includes("go('showroomDetails',1)") && h.includes('3 سيارة')) || h.slice(0, 200); });
  await tc('D3) لا معلومات مخترعة: معرض بلا عنوان/دوام/هاتف → الكتلة تعرض الاسم فقط (بلا صفوف فارغة أو «—»)', async () => {
    const x = mk(null); x.R(`SHOWROOMS.push(ShowroomModel({ id: 77, name: 'Bare Showroom', status: 'active', ownerId: 1 }))`); x.R(`CARS.push(CarModel({ id: 9501, sourceType:'showroom', showroomId: 77, brand:'B', model:'S', year: 2020, price: 1000, status:'available' }))`);
    x.R(`go('carDetails',9501)`); const h = x.E.screen();
    return (h.includes('🏢 المعرض') && h.includes('Bare Showroom') && !h.includes('—') && !h.includes('📍') && !h.includes('🕐') && !BAD.test(h)) || h; });
  await tc('D4) بطاقة المعرض: العنوان وعدد السيارات والحالة من البيانات، ويُخفى صف العنوان إن غاب (لا «📍 —»)', async () => {
    const x = mk(null); x.R(`SHOWROOMS.push(ShowroomModel({ id: 77, name: 'Bare Showroom', status: 'active', ownerId: 1 }))`);
    const full = x.R('ShowroomCard(getShowroomById(1))'), bare = x.R('ShowroomCard(getShowroomById(77))');
    return (full.includes('📍') && full.includes('شارع الكوفة') && full.includes('3 سيارة') && full.includes('نشط') && full.includes("go('showroomDetails',1)") &&
      !bare.includes('📍') && !bare.includes('—') && bare.includes('Bare Showroom') && !BAD.test(bare)) || { full: full.slice(0, 120), bare }; });
  await tc('D5) صورة المعرض: بديل 🏢 آمن بلا صورة، وتُعرض صورته الحقيقية (رابط https) مع بديل عند الفشل', async () => {
    const x = mk(null); x.R(`SHOWROOMS.push(ShowroomModel({ id: 78, name: 'Img Showroom', status: 'active', ownerId: 1, image: 'https://example.com/s.jpg' }))`);
    const noImg = x.R('ShowroomCard(getShowroomById(1))'), withImg = x.R('ShowroomCard(getShowroomById(78))');
    return (noImg.includes('🏢') && !noImg.includes('<img') && withImg.includes('<img') && withImg.includes('src="https://example.com/s.jpg"') && withImg.includes('onerror="imgFallback(this)"') && withImg.includes('alt="Img Showroom"')) || withImg; });
  await tc('D6) تفاصيل سيارة العضو: كتلة «صاحب الإعلان» (الاسم وتاريخ النشر) والموقع، بلا كتلة معرض', async () => {
    const g = mk(null); g.R(`go('memberCarDetails',101)`); const h = g.E.screen();
    return (h.includes('صاحب الإعلان') && h.includes('تاريخ النشر') && h.includes('حي النصر') && !h.includes('🏢 المعرض') && h.includes('من عضو')) || h.slice(0, 160); });

  /* ======================= E) حالة السيارة ======================= */
  console.log('\n--- E) حالة السيارة ---');
  await tc('E1) شارات الحالة: متاحة للبيع/مباعة بالألوان الصحيحة، والمجهولة (ومنها reserved الملغاة) تُنتج نصًا فارغًا', async () => {
    const x = mk(null); const b = s => x.R(`carStatusBadge(${JSON.stringify(s)})`);
    return b('available').includes('متاحة للبيع') && b('available').includes('open') && b('reserved') === '' && b('sold').includes('مباعة') && b('sold').includes('sold') &&
      b('zzz') === '' && b(undefined) === '' && b(null) === '' && b('') === '' && b({}) === ''; });
  await tc('E2) شارات المعرض وسيارة العضو: المعرّفة بنصها العربي، والمجهولة فارغة', async () => {
    const x = mk(null); const s = v => x.R(`showroomStatusBadge(${JSON.stringify(v)})`), m = v => x.R(`memberCarStatusBadge(${JSON.stringify(v)})`);
    return s('active').includes('نشط') && s('pending').includes('قيد المراجعة') && s('suspended').includes('موقوف') && s('zzz') === '' && s(undefined) === '' &&
      m('active').includes('نشط') && m('pending').includes('قيد المراجعة') && m('sold').includes('مباعة') && m('rejected').includes('مرفوض') && m('suspended').includes('موقوف') && m('zzz') === '' && m(null) === ''; });
  await tc('E3) حالات سيارة المعرض تظهر على البطاقة بعد تغييرها من الإدارة (متاحة للبيع/مباعة)، وتُعلَّم المباعة بـ data-status للتعتيم', async () => {
    const a = mk('admin'); a.R(`AdminService.setShowroomCarStatus(2,'available')`); a.R(`AdminService.setShowroomCarStatus(3,'sold')`);
    const h2 = card(a, 2), h3 = card(a, 3), h1 = card(a, 1);
    return h2.includes('متاحة للبيع') && h3.includes('مباعة') && h1.includes('متاحة للبيع') && h3.includes('data-status="sold"') && h2.includes('data-status="available"') && h3.includes('class="card car-card"'); });
  await tc('E4) التفاصيل: صف حالة واضح (الحالة + شارة) مرة واحدة، لا خانة حالة مكررة في المواصفات', async () => {
    const g = mk(null); g.R(`go('carDetails',1)`); const h = g.E.screen(); return ((h.match(/الحالة/g) || []).length === 1 && h.includes('متاحة للبيع') && h.includes('status-row')) || (h.match(/الحالة/g) || []).length; });
  await tc('E5) سيارة عضو غير نشطة يراها مالكها: البطاقة تُظهر حالتها (قيد المراجعة) بجانب «من عضو»، والنشطة بلا شارة حالة مكررة', async () => {
    const u = mk('user'); const pending = u.R(`CarCard(getCarById(103))`), active = u.R(`CarCard(getCarById(101))`);
    return pending.includes('قيد المراجعة') && pending.includes('من عضو') && active.includes('من عضو') && !active.includes('>🟢 نشط<'); });

  /* ======================= F) الحالات الفارغة ======================= */
  console.log('\n--- F) الحالات الفارغة ---');
  const emptyStore = () => ({ 'najaf.showroomCars': '[]', 'najaf.memberCars': '[]', 'najaf.memberCarsDeleted': JSON.stringify([101, 102, 103, 104, 105, 106, 107, 108, 109, 110]), 'najaf.carImages': '[]' });
  const concise = h => { const hints = [...h.matchAll(/<p class="sub"[^>]*>([\s\S]*?)<\/p>/g)].map(m => m[1].trim()); return hints.every(s => s.length > 0 && s.length <= 90); };
  await tc('F1) لا سيارات (السيارات): العنوان الحالي + شرح موجز + أزرار تصفح مناسبة (المعارض/الأعضاء)', async () => {
    const x = mk(null, emptyStore()); x.R(`go('cars')`); const h = x.E.screen();
    return (h.includes('لا توجد سيارات حاليًا') && h.includes('class="sub"') && h.includes("go('showrooms')") && h.includes("go('memberCars')") && concise(h) && !h.includes('<img') && !h.includes('<svg')) || h; });
  await tc('F2) لا سيارات في المعرض: العنوان الحالي + شرح موجز + زر لتصفح السيارات', async () => {
    const x = mk(null, emptyStore()); x.R(`go('showroomDetails',1)`); const h = x.E.screen();
    return (h.includes('لا توجد سيارات في هذا المعرض حاليًا') && h.includes("go('cars')") && h.slice(h.indexOf('لا توجد سيارات في هذا المعرض')).includes('class="sub"') && concise(h)) || h.slice(-400); });
  await tc('F3) لا سيارات أعضاء: العنوان الحالي + دعوة موجزة + زر النشر (محفوظان) ', async () => {
    const x = mk(null, emptyStore()); x.R(`go('memberCars')`); const h = x.E.screen(); return h.includes('لا توجد سيارات أعضاء حاليًا') && h.includes("go('addMemberCar')") && h.includes('class="sub"') && concise(h); });
  await tc('F4) لا نتائج بحث: رسالة + شرح موجز في كل المواضع (السيارات، الأعضاء، المعارض، البحث الموحّد) + زر المسح', async () => {
    const x = mk(null); const bad = [];
    x.R(`go('cars')`); x.R(`onCarsSearch('zzzzqqq')`); const a = x.E.els.carsList.innerHTML; if (!(a.includes('لم نعثر على سيارات مطابقة لبحثك') && a.includes('class="sub"') && a.includes('clearCarsSearch()') && concise(a))) bad.push('cars');
    x.R(`go('memberCars')`); x.R(`onMemberCarsSearch('zzzzqqq')`); const b = x.E.els.memberCarsList.innerHTML; if (!(b.includes('لم نعثر على سيارات مطابقة لبحثك') && b.includes('class="sub"') && b.includes('clearMemberCarsSearch()') && concise(b))) bad.push('member');
    x.R(`go('showrooms')`); x.R(`onShowroomsSearch('zzzzqqq')`); const c = x.E.els.showroomsList.innerHTML; if (!(c.includes('لم نعثر على معارض مطابقة') && c.includes('class="sub"') && c.includes('clearShowroomsSearch()') && concise(c))) bad.push('showrooms');
    x.R(`go('search','zzzzqqq')`); const d = x.E.screen(); if (!(d.includes('لم نعثر على سيارات مطابقة لبحثك') && d.includes('class="sub"') && d.includes('clearSearchScreen()') && concise(d))) bad.push('search');
    return bad.length === 0 || bad; });
  await tc('F5) لا مفضلة: عنوان + شرح طريقة الإضافة + أزرار التصفح؛ والزائر: دعوة للدخول بنفس الأسلوب', async () => {
    const u = mk('user'); u.R(`go('favorites')`); const h = u.E.screen(); const g = mk(null); g.R(`go('favorites')`); const gh = g.E.screen();
    return (h.includes('لا توجد سيارات في المفضلة حاليًا') && h.includes('اضغط على أيقونة 🤍') && h.includes("go('cars')") && h.includes("go('memberCars')") && concise(h) &&
      gh.includes('سجّل الدخول لحفظ سياراتك المفضلة') && gh.includes("go('login'") && gh.includes('placeholder')) || { h: h.slice(-300), gh }; });
  await tc('F6) لا معارض: العنوان الحالي (المعارض والخريطة والرئيسية) + شرح موجز', async () => {
    const x = mk(null); x.R('SHOWROOMS.splice(0, SHOWROOMS.length)'); const bad = [];
    for (const r of ['showrooms', 'map', 'home']) { x.R(`go('${r}')`); const h = x.E.screen(); if (!h.includes('لا توجد معارض') || !h.includes('class="sub"')) bad.push(r); }
    return bad.length === 0 || bad; });
  await tc('F7) الحالات الفارغة موحَّدة: أيقونة إيموجي واحدة + عنوان + شرح اختياري + أزرار — بلا صور/SVG ولا أقسام كبيرة', async () => {
    const x = mk(null, emptyStore()); const bad = [];
    for (const r of ['cars', 'memberCars', 'home', 'favorites', 'search']) { x.R(`go('${r}')`); const h = x.E.screen(); if (/<svg|<img/.test(h)) bad.push(r); }
    return bad.length === 0 || bad; });

  /* ======================= G) سلامة البيانات غير الصالحة / الأخطاء ======================= */
  console.log('\n--- G) بيانات غير صالحة وأخطاء ---');
  const WEIRD = ["price: 'abc'", 'price: NaN', "price: {}", 'price: -5', 'price: Infinity', "year: ''", "year: 'xx'", 'year: {}', "mileage: 'x'", 'mileage: -5', 'mileage: NaN', 'brand: {}', "model: ['a']", 'brand: 12345', "transmission: {}", 'fuelType: 7', "color: null", "description: 42", "status: {}", "status: 99"];
  await tc('G1) قيم غير صالحة في كل حقل (مصفوفة 20 حالة): بطاقة وتفاصيل بلا undefined/null/NaN ولا ErrorState ولا انهيار', async () => {
    const bad = [];
    for (const [i, w] of WEIRD.entries()) {
      const x = mk(i % 3 === 0 ? 'admin' : null); const id = 9700 + i;
      x.R(`CARS.push(CarModel(Object.assign({ id: ${id}, sourceType:'showroom', showroomId: 1, brand:'W', model:'M${i}', year: 2020, price: 1000, status:'available' }, { ${w} })))`);
      try { const h = card(x, id); x.R(`go('carDetails',${id})`); const d = x.E.screen(); x.R(`go('cars')`); const l = x.E.screen();
        for (const [n, s] of [['card', h], ['details', d], ['list', l]]) if (BAD.test(s) || s.includes(ERR) || /<p class="card-row">\s*<\/p>/.test(s)) bad.push(w + '@' + n); } catch (e) { bad.push(w + '@EXC'); }
    }
    return bad.length === 0 || bad; });
  await tc('G2) سيارة عضو بقيم غير صالحة (سعر/سنة/موقع/هاتف/مالك) : بطاقة وتفاصيل آمنة', async () => {
    const bad = [];
    ["price: 'abc'", 'year: NaN', 'location: {}', 'phone: {}', 'ownerId: NaN', "brand: ''", "model: ''"].forEach((w, i) => {
      const x = mk(null); const id = 9800 + i; x.R(`MEMBER_CARS.push(CarModel(Object.assign({ id: ${id}, sourceType:'member', ownerId: 7, brand:'B', model:'M', year: 2020, price: 1000, status:'active' }, { ${w} })))`);
      try { const h = x.R(`CarCard(getCarById(${id}))`); x.R(`go('memberCarDetails',${id})`); const d = x.E.screen(); [h, d].forEach((s, k) => { if (BAD.test(s) || s.includes(ERR)) bad.push(w + '@' + k); }); } catch (e) { bad.push(w + '@EXC'); }
    });
    return bad.length === 0 || bad; });
  await tc('G3) المكوّنات تتحمّل مدخلات غريبة: CarCard/ShowroomCard/CarImageInner/CarImageStrip لا ترمي وتعيد نصًا', async () => {
    const x = mk(null); const calls = ['CarCard(null)', 'CarCard(undefined)', 'CarCard(42)', 'CarCard({})', 'CarCard("x")', 'ShowroomCard(null)', 'ShowroomCard({})', 'ShowroomCard(7)', 'CarImageInner(null)', 'CarImageInner({})', 'CarImageStrip(null)', 'CarImageStrip({})'];
    const bad = calls.filter(c => { try { return typeof x.R(c) !== 'string'; } catch (e) { return true; } }); return bad.length === 0 || bad; });
  await tc('G4) سجل واحد معطوب لا يُسقط القائمة: بطاقته تُتخطّى وبقية البطاقات تُعرض بلا ErrorState (الرئيسية، السيارات، البحث، المعرض)', async () => {
    const x = mk(null); x.R(`CARS.push(Object.defineProperty(CarModel({ id: 9900, sourceType:'showroom', showroomId: 1, brand:'Poison', model:'Card', year: 2020, price: 1000, status:'available' }), 'status', { get() { throw new Error('boom'); } }))`);
    const bad = []; const origErr = x.E.ctx.console.error; x.E.ctx.console.error = () => {};
    for (const [r, p] of [['home'], ['cars'], ['search', 'poison'], ['showroomDetails', 1]]) { x.R(`go('${r}'${p !== undefined ? ',' + JSON.stringify(p) : ''})`); const h = x.E.screen(); if (h.includes(ERR)) bad.push(r); }
    x.R(`go('cars')`); const n = (x.E.screen().match(/class="card car-card"/g) || []).length; x.E.ctx.console.error = origErr;
    return (bad.length === 0 && n === 9) || { bad, n }; });
  await tc('G5) شاشة الخطأ موحّدة وودّية: عنوان عربي + شرح موجز + زرّا «إعادة المحاولة» و«العودة للرئيسية»، بلا نص تقني', async () => {
    const x = mk(null); const h = x.R('ErrorState()');
    return (h.includes('حدث خطأ، حاول مرة أخرى') && h.includes('class="sub"') && h.includes('render()') && h.includes("go('home')") && !BAD.test(h)) || h; });
  await tc('G6) خطأ فعلي أثناء العرض يظهر برسالة ودّية موحّدة (لا استثناء للمستخدم) والتطبيق يتعافى بالتنقل', async () => {
    const x = mk(null); const orig = x.E.ctx.console.error; x.E.ctx.console.error = () => {};
    x.R(`ROUTES.__boom = { render: () => { throw new TypeError('x is undefined'); }, nav: null }`); x.R(`go('__boom')`); const h = x.E.screen(); x.R(`go('home')`); const ok = x.E.screen().includes('أحدث السيارات'); x.E.ctx.console.error = orig;
    return (h.includes('حدث خطأ، حاول مرة أخرى') && !BAD.test(h) && ok) || h; });
  await tc('G7) رسائل الانشغال/التحميل المعتمدة موحّدة بصيغة «جارٍ …» ولا رسائل تقنية', async () => {
    const files = ['components/imagePicker.js', 'navigation/dealerActions.js', 'components/ui.js'].map(f => strip(read(f))).join('\n'); const msgs = [...files.matchAll(/جار[ٍي]\s[^'"`<]*/g)].map(m => m[0].trim());
    return (msgs.length >= 2 && msgs.every(m => /^جارٍ /.test(m))) || msgs; });

  /* ======================= H) التفاصيل: تجميع المعلومات والإجراءات ======================= */
  console.log('\n--- H) التفاصيل ---');
  await tc('H1) تفاصيل سيارة المعرض مرتّبة في أقسام: الصورة ← الهوية (+ زر المفضلة المدمج بجانب العنوان، UX ج5) ← السعر ← الحالة ← المواصفات ← الوصف ← المعرض ← التواصل', async () => {
    const g = mk(null); g.R(`go('carDetails',1)`); const h = g.E.screen();
    const marks = ['detail-hero', '<h1', 'handleFavoriteToggle(1)', 'class="price', 'status-row', '⚙️ المواصفات', '📝 الوصف', '🏢 المعرض', 'contact-block'].map(s => idx(h, s));
    return (marks.every(i => i >= 0) && marks.every((v, i) => i === 0 || v > marks[i - 1])) || marks; });
  await tc('H2) الإجراءات القائمة محفوظة: اتصال وواتساب وخريطة (من بيانات المعرض)، المفضلة، وزر «عرض صفحة المعرض»', async () => {
    const g = mk(null); g.R(`go('carDetails',1)`); const h = g.E.screen(); const s = J(g, 'getShowroomById(1)');
    return h.includes('href="tel:') && h.includes('wa.me') && h.includes('google.com/maps') && h.includes('aria-label="إضافة إلى المفضلة"') && h.includes("go('showroomDetails',1)") && s.phone ? true : h.slice(0, 100); });
  await tc('H3) تفاصيل سيارة العضو: كل الأقسام + المشاركة + أزرار المالك للمالك فقط (محفوظة)', async () => {
    const o = mk('user'); o.R(`go('memberCarDetails',101)`); const h = o.E.screen(); const g = mk(null); g.R(`go('memberCarDetails',101)`); const gh = g.E.screen();
    return (h.includes('handleShareMemberCar(101)') && h.includes('go(\'editMemberCar\', 101)') && h.includes('handleDeleteMemberCar(101)') && h.includes('handleMemberCarStatusChange(101)') && h.includes('class="status-row"') && h.includes('⚙️ المواصفات') &&
      h.includes('href="tel:') && h.includes('wa.me') && h.includes('aria-label="إضافة إلى المفضلة"') && gh.includes('handleShareMemberCar(101)') && !gh.includes('handleDeleteMemberCar(101)') && !gh.includes('editMemberCar')) || h.slice(0, 100); });
  await tc('H4) الوصف: كتلة مستقلة بعنوانها فقط عند وجوده، ومهرَّب (HTML لا يُنفَّذ)', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9950, sourceType:'showroom', showroomId: 1, brand:'D', model:'Desc', year: 2020, price: 1000, status:'available', description: '<img src=x onerror=alert(1)> وصف' }))`);
    x.R(`go('carDetails',9950)`); const h = x.E.screen(); return h.includes('📝 الوصف') && h.includes('&lt;img') && !h.includes('<img src=x'); });
  await tc('H5) تفاصيل المعرض: لا تغيّر جوهري (الاسم، الوصف، العنوان، الدوام، الهاتف، الخدمات، التواصل، السيارات) وصورة المعرض مع بديل', async () => {
    const g = mk(null); g.R(`go('showroomDetails',1)`); const h = g.E.screen();
    return ['معرض النجف للسيارات', 'معرض متخصص بالسيارات', 'شارع الكوفة', '9 صباحًا - 9 مساءً', '07701234567', 'سيارات المعرض (3)', 'href="tel:', 'wa.me', 'google.com/maps'].every(s => h.includes(s)) && h.includes('🏢') && !h.includes('<img'); });

  /* ======================= I) استجابة الهاتف والاتساق مع التصميم ======================= */
  console.log('\n--- I) الهاتف والتصميم ---');
  const css = read('theme/theme.css');
  await tc('I1) لا نظام تصميم جديد: متغيرات :root هي نفسها (11 متغيرًا)، وكل ألوان القواعد الجديدة من المتغيرات أو ألوان قائمة', async () => {
    const root = (css.match(/:root\{([\s\S]*?)\}/) || [])[1] || ''; const vars = [...root.matchAll(/--([a-z-]+):/g)].map(m => m[1]).sort();
    const exp = ['border', 'gray-bg', 'green', 'navy', 'navy-dark', 'orange', 'radius', 'red', 'text', 'text-mut', 'white'];
    return (JSON.stringify(vars) === JSON.stringify(exp) && !/font-family[^;]*(?:Roboto|Inter|Poppins)/i.test(css)) || vars; });
  await tc('I2) أهداف اللمس: زر المفضلة ≥ 40px، الأزرار الأساسية ≥ 44px، وأزرار الروابط ≥ 40px', async () => {
    const fav = (css.match(/\.fav-btn\{[^}]*width:(\d+)px[^}]*height:(\d+)px/g) || []).map(r => Number((r.match(/width:(\d+)px/) || [])[1])); const last = fav[fav.length - 1];
    return (last >= 40 && /\.btn-primary,\.action-btn\{min-height:44px/.test(css) && /\.link-btn[^{]*\{min-height:40px/.test(css)) || fav; });
  await tc('I3) نص مقروء: الأحجام الجديدة للبطاقة/التفاصيل ≥ 12px، ولا خط أصغر من 11px في القواعد الجديدة', async () => {
    const block = css.slice(css.indexOf('/* ---- المرحلة 10')); const sizes = [...block.matchAll(/font-size:\s*([\d.]+)px/g)].map(m => Number(m[1]));
    return (block.length > 50 && sizes.length > 0 && sizes.every(s => s >= 11.5)) || sizes; });
  await tc('I4) منع التمرير الأفقي: عناصر البطاقة/التفاصيل ذات min-width:0 وكسر نص طويل، وصور max-width:100%', async () => {
    const block = css.slice(css.indexOf('/* ---- المرحلة 10')); return (/min-width:\s*0/.test(css) && /overflow-wrap:\s*anywhere/.test(css) && /img[^{]*\{[^}]*max-width:\s*100%/.test(css) && /\.card-sub|\.card-showroom|\.status-row/.test(block)) || block.slice(0, 100); });
  await tc('I5) الصور بلا تشويه: card-img بـ object-fit: cover، وصورة التفاصيل بـ contain، والبديل img-ph مُنسَّق', async () => {
    return /\.card-img img[^{]*\{[^}]*object-fit:\s*cover/.test(css) && /\.detail-hero img[^{]*\{[^}]*object-fit:\s*contain/.test(css) && /\.img-ph/.test(css); });
  await tc('I6) اتجاه RTL والمتغيرات: الصفحة dir=rtl، والإضافات لا تستخدم left/right ثابتة خارج ما هو قائم (استخدام logical أو قواعد قائمة)', async () => {
    const html = read('index.html'); const block = css.slice(css.indexOf('/* ---- المرحلة 10')); return /dir="rtl"/.test(html) && /viewport/.test(html) && !/margin-left|margin-right|padding-left|padding-right|text-align:\s*(left|right)/.test(block); });
  await tc('I7) نصوص البطاقات مهرَّبة (XSS): ماركة/موديل/اسم معرض/موقع بوسوم HTML تظهر كنص في البطاقة والتفاصيل وبطاقة المعرض', async () => {
    const PAY = '<img src=x onerror=alert(1)>'; const x = mk(null);
    x.R(`SHOWROOMS.push(ShowroomModel({ id: 88, name: ${JSON.stringify(PAY)}, address: ${JSON.stringify(PAY)}, status:'active', ownerId: 1 }))`);
    x.R(`CARS.push(CarModel({ id: 9960, sourceType:'showroom', showroomId: 88, brand: ${JSON.stringify(PAY)}, model: ${JSON.stringify(PAY)}, year: 2020, price: 1000, transmission: ${JSON.stringify(PAY)}, status:'available' }))`);
    x.R(`MEMBER_CARS.push(CarModel({ id: 9961, sourceType:'member', ownerId: 7, brand:'M', model:'X', location: ${JSON.stringify(PAY)}, year: 2020, price: 1000, status:'active' }))`);
    const outs = [card(x, 9960), x.R(`CarCard(getCarById(9961))`), x.R('ShowroomCard(getShowroomById(88))')]; x.R(`go('carDetails',9960)`); outs.push(x.E.screen()); x.R(`go('memberCarDetails',9961)`); outs.push(x.E.screen());
    return outs.every(h => !h.includes('<img src=x')) && outs[0].includes('&lt;img'); });

  /* ======================= J) فحوص ثابتة ======================= */
  console.log('\n--- J) فحوص ثابتة ---');
  await tc('J1) لا جلب خام ولا قاعدة ظهور في مكوّنات العرض الجديدة (visibility: الجزءان 1 و2 لم يُمَسّا)', async () => {
    const files = ['components/carCard.js', 'components/showroomCard.js', 'components/carImage.js', 'screens/carDetails.js', 'screens/memberCarDetails.js'];
    const bad = files.filter(f => /\b(getCars|getShowrooms|getActiveMemberCars|getMemberCars|getCarsByShowroom|getShowroomById|getCarById|getMemberCarById)\s*\(/.test(strip(read(f))) || /USER_STATUS|UsersRepository/.test(strip(read(f)))); return bad.length === 0 || bad; });
  await tc('J2) لا ملفات صور جديدة ولا مفتاح تخزين جديد: لا localStorage/indexedDB في مكوّنات العرض', async () => {
    const files = ['components/carCard.js', 'components/showroomCard.js', 'components/carImage.js', 'screens/carDetails.js', 'screens/memberCarDetails.js']; const bad = files.filter(f => /localStorage|indexedDB|AppStorage|FileReader|canvas/i.test(strip(read(f)))); return bad.length === 0 || bad; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

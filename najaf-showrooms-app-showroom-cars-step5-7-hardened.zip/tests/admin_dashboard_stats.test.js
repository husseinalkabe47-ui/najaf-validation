/* اختبارات إصلاح بطاقات إحصائيات لوحة الإدارة (قيد المراجعة / نشطة / مباعة / مرفوضة → «حدث خطأ، حاول مرة أخرى»).
   السبب الجذري: onclick="go('adminMemberCars',"pending")" — JSON.stringify يكتب علامتي اقتباس مزدوجتين داخل سمة محاطة بمزدوجتين،
   فتنقطع السمة وتصير go('adminMemberCars', وتنتهي بـ SyntaxError: Unexpected end of input عند النقر الحقيقي.
   الاختبارات القديمة كانت تستدعي go() مباشرة فلا تحلّل سمة onclick، لذا لم تكشفه. هنا «ننقر» فعلًا: نستخرج سمة onclick من HTML المُنتَج،
   نفكّ ترميز الكيانات كما يفعل المتصفح، ثم ننفّذ الشيفرة الناتجة داخل بيئة التطبيق.
   كل الأرقام تُشتق من الخدمات/البيانات الحالية (لا أرقام قديمة ثابتة)، وتُجرَّب على المستويات الثلاثة للبذرة (الأساسية / ج1 / الكاملة 151). */
const { makeEnv } = require('./harness');
const vm = require('vm'), fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 200)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const ERR = 'حدث خطأ، حاول مرة أخرى';
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
const LEVELS = [['الأساسية', false], ['ج1', true], ['الكاملة', 'p3']];
function mk(role, store, level) {
  const E = makeEnv(store, { fullSeed: level === undefined ? 'p3' : level }), R = c => E.run(c);
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); E.els.loginIdentifier = { value: c[0], style: {}, textContent: '' }; E.els.loginPassword = { value: c[1], style: {}, textContent: '' }; R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
/** فكّ ترميز كيانات HTML كما يفعل المتصفح لقيمة السمة */
const dec = s => s.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x27;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
/** كل سمات on* في HTML: القيمة تنتهي عند أول " غير مُرمَّزة تمامًا كما يفسّرها المتصفح */
const handlers = html => [...String(html).matchAll(/\son(?:click|change|input|keydown|keyup|focus|blur|submit|pointerdown|error|load)\s*=\s*"([^"]*)"/g)].map(m => dec(m[1]));
const brokenHandlers = html => handlers(html).filter(code => { try { new vm.Script(code); return false; } catch (e) { return true; } });
/** بطاقات الإحصاء: [{ label, num, code }] بالترتيب */
const cards = html => [...String(html).matchAll(/<div class="stat-card"[^>]*?onclick="([^"]*)"[^>]*>([\s\S]*?)<\/div><\/div>/g)].map(m => ({ code: dec(m[1]), num: (m[2].match(/class="num">([^<]*)</) || [])[1], label: (m[2].match(/class="lbl">([^<]*)/) || [])[1], hint: ((m[2].match(/class="lbl">[^<]*<\/div><div class="lbl">([^<]*)/)) || [])[1] }));
/** النقر على بطاقة: تنفيذ شيفرة onclick المفكوكة داخل بيئة التطبيق (كما يفعل المتصفح تمامًا) */
const click = (x, card) => { x.E.errors.length = 0; try { x.R(card.code); return { threw: null }; } catch (e) { return { threw: String(e && e.message) }; } };
const idsOnScreen = html => [...new Set([...String(html).matchAll(/go\('adminMemberCarDetails',\s*(\d+)\)/g)].map(m => Number(m[1])))].sort((a, b) => a - b);
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const STATUS_BY_LABEL = { 'إعلانات نشطة': 'active', 'قيد المراجعة': 'pending', 'إعلانات مرفوضة': 'rejected', 'إعلانات مباعة': 'sold', 'سيارات الأعضاء': 'all' };

(async () => {
  /* ======================= A) سمات onclick صالحة (الفئة كلها) ======================= */
  console.log('\n--- A) المعالجات المضمَّنة صالحة نحويًا ---');
  await tc('A1) لوحة الإدارة: كل سمات on* في HTML (بطاقات + قائمة) تُحلَّل بلا SyntaxError، وبطاقات الإحصاء 8 والقائمة 5', async () => {
    const a = mk('admin'); a.R(`go('adminDashboard')`); const h = a.E.screen();
    return (brokenHandlers(h).length === 0 && cards(h).length === 8 && (h.match(/class="admin-menu-item"/g) || []).length === 5 && handlers(h).length >= 13) || { broken: brokenHandlers(h), cards: cards(h).length }; });
  await tc('A2) كل الشاشات لكل الأدوار (ضيف/عضو/تاجر/مدير، 32 شاشة وحالة): لا سمة on* واحدة مكسورة (الفئة نفسها من الخلل لا تتكرر في أي مكان)', async () => {
    const bad = [];
    for (const role of [null, 'user', 'dealer1', 'admin']) {
      const x = mk(role); const list = ['home', 'cars', 'memberCars', 'showrooms', 'map', 'favorites', 'search', 'login', 'register', 'account', 'myMemberCars', 'addMemberCar', 'dealerHome', 'myShowroomCars', 'addShowroomCar', 'adminHome', 'adminDashboard', 'adminUsers', 'adminShowrooms', 'adminShowroomCars', 'adminMemberCars', 'adminDealerRequests']
        .map(r => [r]).concat([['carDetails', 1], ['carDetails', 91], ['memberCarDetails', 101], ['memberCarDetails', 160], ['showroomDetails', 1], ['adminMemberCarDetails', 103], ['adminMemberCarDetails', 109], ['adminMemberCars', 'pending'], ['adminMemberCars', 'active'], ['adminMemberCars', 'sold'], ['adminMemberCars', 'rejected']]);
      for (const [r, p] of list) { x.R(p === undefined ? `go('${r}')` : `go('${r}',${JSON.stringify(p)})`); const b = brokenHandlers(x.E.screen()); if (b.length) bad.push((role || 'guest') + ':' + r + (p !== undefined ? '(' + p + ')' : '')); }
    }
    return bad.length === 0 || bad; });
  await tc('A3) المحلّل نفسه يلتقط الخلل القديم (حتى لا يكون الاختبار فارغًا): onclick="go(\'adminMemberCars\',"pending")" يُحلَّل مكسورًا، وبصيغة &quot; سليمًا', async () => {
    const old = `<div class="stat-card" onclick="go('adminMemberCars',"pending")"><div class="num">2</div></div>`, fixed = `<div class="stat-card" onclick="go('adminMemberCars',&quot;pending&quot;)"><div class="num">2</div></div>`;
    return (brokenHandlers(old).length === 1 && brokenHandlers(fixed).length === 0 && dec(handlers(fixed)[0]) === `go('adminMemberCars',"pending")`) || 'parser'; });

  /* ======================= B) كل بطاقة: نقرة حقيقية ← الشاشة الصحيحة ← بلا خطأ ======================= */
  console.log('\n--- B) النقر على كل بطاقة (على مستويات البذرة الثلاثة) ---');
  for (const [lname, lvl] of LEVELS) {
    await tc(`B1[${lname}]) كل بطاقات الإحصاء الـ8: النقر ينفّذ بلا استثناء، ويصل لشاشة الإدارة الصحيحة، بلا «${ERR}» ولا أخطاء JS`, async () => {
      const a = mk('admin', undefined, lvl); const expect = [['adminUsers'], ['adminShowrooms'], ['adminShowroomCars'], ['adminMemberCars'], ['adminMemberCars'], ['adminMemberCars'], ['adminMemberCars'], ['adminMemberCars']];
      a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); const bad = [];
      cs.forEach((c, i) => { a.R(`go('adminDashboard')`); const r = click(a, c); const scr = a.E.screen(); if (r.threw || a.R('currentRoute') !== expect[i][0] || scr.includes(ERR) || a.E.errors.length || !scr.includes('<h1>')) bad.push({ i, label: c.label, threw: r.threw, route: a.R('currentRoute') }); });
      return (cs.length === 8 && bad.length === 0) || bad; });
    await tc(`B2[${lname}]) الفلتر الهدف صحيح: قيد المراجعة/نشطة/مباعة/مرفوضة/الكل ← تبويب الحالة المطابق (aria-pressed)، والقائمة = سيارات الأعضاء بتلك الحالة من الخدمة بالضبط، وعدد البطاقة = عدد القائمة`, async () => {
      const a = mk('admin', undefined, lvl); const all = a.J('getMemberCars()'); const bad = [];
      a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); const sel = cs.filter(c => STATUS_BY_LABEL[c.label]); if (sel.length !== 5) bad.push('cards-checked:' + sel.length);   // حارس: لا نجاح فارغ
      for (const c of sel) {
        a.R(`go('adminDashboard')`); click(a, c); const st = STATUS_BY_LABEL[c.label], scr = a.E.screen();
        const exp = all.filter(m => st === 'all' || m.status === st).map(m => m.id), got = idsOnScreen(scr);
        const pressed = [...scr.matchAll(/class="active" aria-pressed="true" onclick="onAdminMemberCarsStatus\('([a-z]+)'\)"/g)].map(m => m[1]);
        if (!same(got, exp) || Number(c.num) !== exp.length || !(pressed.length === 1 && pressed[0] === st) || (exp.length === 0 && !scr.includes('لا توجد نتائج'))) bad.push({ label: c.label, st, got: got.length, exp: exp.length, num: c.num, pressed });
      }
      return bad.length === 0 || bad; });
  }
  await tc('B3) الأرقام مشتقة من الخدمة لا ثابتة: كل رقم على البطاقة = عدّ السجلات من المستودعات، ومجموع حالات الأعضاء = إجمالي الأعضاء، وإجمالي كل السيارات = معارض + أعضاء = 151 في البذرة الكاملة', async () => {
    const a = mk('admin'); const s = a.J('getDashboardStats()'), sc = a.J('CarsRepository.getAll().length'), mc = a.J('MemberCarsRepository.getAll()');
    const n = st => mc.filter(c => c.status === st).length; a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); const by = l => Number(cs.find(c => c.label === l).num);
    return (s.totalShowroomCars === sc && s.totalMemberCars === mc.length && sc + mc.length === 151 && s.pendingMemberCars === n('pending') && s.activeMemberCars === n('active') && s.soldMemberCars === n('sold') && s.rejectedMemberCars === n('rejected') && s.suspendedMemberCars === n('suspended') &&
      n('pending') + n('active') + n('sold') + n('rejected') + n('suspended') === mc.length && by('قيد المراجعة') === n('pending') && by('إعلانات نشطة') === n('active') && by('إعلانات مباعة') === n('sold') && by('إعلانات مرفوضة') === n('rejected') && by('سيارات الأعضاء') === mc.length && by('سيارات المعارض') === sc) || { s, sc, mc: mc.length }; });
  await tc('B4) لا «حدث خطأ»: كل تبويب لكل حالة (الكل/قيد المراجعة/نشط/مباعة/مرفوض/موقوف) بعد الدخول من أي بطاقة، والعودة للّوحة، والنقر المتكرر على البطاقات، بلا أخطاء', async () => {
    const a = mk('admin'); const bad = []; a.R(`go('adminDashboard')`); const cs = cards(a.E.screen());
    for (let round = 0; round < 3; round++) for (const c of cs) { a.R(`go('adminDashboard')`); const r = click(a, c); if (r.threw || a.E.screen().includes(ERR) || a.E.errors.length) bad.push(c.label + '#' + round); }
    for (const st of ['all', 'pending', 'active', 'sold', 'rejected', 'suspended']) { a.R(`onAdminMemberCarsStatus('${st}')`); if (a.E.els.adminMemberCarsList.innerHTML.includes(ERR)) bad.push('tab:' + st); }
    a.R(`goBack('adminDashboard')`); return bad.length === 0 || bad; });
  await tc('B5) الحالة لا تتسرّب: بعد فتح «مباعة» ثم العودة والنقر على بطاقة «سيارات الأعضاء» تظهر كل السيارات (لا المباعة فقط)، وكانت قبل الإصلاح تبقى على التبويب السابق', async () => {
    const a = mk('admin'); a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); const sold = cs.find(c => c.label === 'إعلانات مباعة'), all = cs.find(c => c.label === 'سيارات الأعضاء');
    click(a, sold); const n1 = idsOnScreen(a.E.screen()).length; a.R(`go('adminDashboard')`); click(a, all); const n2 = idsOnScreen(a.E.screen()).length;
    return (n1 === Number(sold.num) && n2 === a.J('getMemberCars().length') && n2 > n1) || { n1, n2 }; });

  /* ======================= C) معنى «قيد المراجعة» اليوم ======================= */
  console.log('\n--- C) معنى «قيد المراجعة» (سجلات قديمة/معادة، لا نشر جديد) ---');
  await tc('C1) النشر الجديد بعد المكافأة = active مباشرة ولا يزيد «قيد المراجعة»: النشطة +1، المراجعة بلا تغيير، والسيارة تظهر في قائمة «نشطة» لا «قيد المراجعة»', async () => {
    const store = {}; const a0 = mk('admin', store); const s0 = a0.J('getDashboardStats()'); const u = mk('user', store);
    const d = u.J(`createDraftMemberCar(${JSON.stringify({ brand: 'Honda', model: 'Jazz', year: '2018', price: '9000000', phone: '07700000099', currency: 'IQD' })})`); u.R(`RewardService.requestPublishReward('${d.draftId}')`); u.R(`RewardService.onRewardCompleted('${d.draftId}')`); const p = u.J(`publishMemberCarAfterReward('${d.draftId}')`);
    const a = mk('admin', store); const s1 = a.J('getDashboardStats()');
    a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); click(a, cs.find(c => c.label === 'إعلانات نشطة')); const inActive = idsOnScreen(a.E.screen()).includes(p.car.id);
    a.R(`go('adminDashboard')`); click(a, cs.find(c => c.label === 'قيد المراجعة')); const inPending = idsOnScreen(a.E.screen()).includes(p.car.id);
    return (p.ok && p.car.status === 'active' && s1.activeMemberCars === s0.activeMemberCars + 1 && s1.pendingMemberCars === s0.pendingMemberCars && inActive && !inPending) || { ok: p.ok, s0, s1, inActive, inPending }; });
  await tc('C2) «قيد المراجعة» تمثل فعليًا سجلات قديمة أو أعادتها الإدارة: في البذرة هي السجلان القديمان 103 و108 فقط، وإرجاع المدير لسيارة نشطة للمراجعة (restoreMemberCar) يرفع العدّاد ويظهر السجل في قائمتها — المعنى محفوظ', async () => {
    const a = mk('admin'); const before = a.J('getPendingMemberCars().map(c=>c.id)'); const r = a.J('restoreMemberCar(102)'); const s = a.J('getDashboardStats()');
    a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); click(a, cs.find(c => c.label === 'قيد المراجعة')); const ids = idsOnScreen(a.E.screen());
    return (same(before, [103, 108]) && r.ok && s.pendingMemberCars === 3 && same(ids, [102, 103, 108])) || { before, r: r.ok, pend: s.pendingMemberCars, ids }; });
  await tc('C3) النص لا يوحي أن النشر الجديد يحتاج مراجعة: بطاقة «قيد المراجعة» تذكر «سجلات قديمة أو أعادتها الإدارة»، وعنصر القائمة صار «بانتظار قرار الإدارة» بدل «(قيد المراجعة)»، وشارة الحالة العامة لم تتغير', async () => {
    const a = mk('admin'); a.R(`go('adminDashboard')`); const h = a.E.screen(); const pc = cards(h).find(c => c.label === 'قيد المراجعة');
    return (pc && pc.hint === 'سجلات قديمة أو أعادتها الإدارة' && h.includes('سجلات الأعضاء بانتظار قرار الإدارة') && !h.includes('(قيد المراجعة)') && a.R('MEMBER_CAR_STATUS_LABEL.pending') === 'قيد المراجعة' && a.R('MEMBER_CAR_STATUS.REJECTED') === 'rejected') || { hint: pc && pc.hint }; });
  await tc('C4) تأثير السجلات القديمة على النتيجة: الـ2 pending والـ1 rejected والـ1 suspended القديمة تُعدّ وتُعرض كما هي (لا تُحذف ولا تُحوَّل)، والبطاقات لا تتأثر بها بخطأ (لا استثناء بسببها)', async () => {
    const a = mk('admin'); const mc = a.J('getMemberCars()'); const legacy = { pending: [103, 108], rejected: [109], suspended: [110] }; const bad = [];
    for (const [st, ids] of Object.entries(legacy)) if (!same(mc.filter(c => c.status === st).map(c => c.id), ids)) bad.push(st);
    a.R(`go('adminMemberCars','rejected')`); if (!same(idsOnScreen(a.E.screen()), [109])) bad.push('screen-rejected');
    return bad.length === 0 || bad; });

  /* ======================= D) الصلاحيات ======================= */
  console.log('\n--- D) الصلاحيات ---');
  for (const role of [null, 'user', 'dealer1']) {
    await tc(`D1[${role || 'guest'}]) غير المدير: لا لوحة ولا قوائم إدارية بالتنقل المباشر (go('adminDashboard') وgo('adminMemberCars', كل الحالات))، getDashboardStats() = null، وواجهات AdminService/القائمة المعلّقة فارغة، ولا بيانات إدارية في HTML`, async () => {
      const x = mk(role); const bad = []; const leak = h => /go\('adminMemberCarDetails'|class="stat-card"|إجمالي المستخدمين/.test(h);
      for (const [r, p] of [['adminDashboard'], ['adminHome'], ['adminMemberCars'], ['adminMemberCars', 'pending'], ['adminMemberCars', 'active'], ['adminMemberCars', 'sold'], ['adminMemberCars', 'rejected'], ['adminUsers'], ['adminShowroomCars']]) {
        x.R(p === undefined ? `go('${r}')` : `go('${r}',${JSON.stringify(p)})`); const h = x.E.screen(); if (leak(h) || x.R('currentRoute').startsWith('admin')) bad.push(r + (p ? '(' + p + ')' : ''));
      }
      if (x.R('getDashboardStats()') !== null || x.J('adminGetAllShowrooms()').length !== 0 || x.J('adminGetAllUsers()').length !== 0 || x.J('getPendingMemberCars()').length !== 0 || x.J('adminGetPendingMemberCars()').length !== 0) bad.push('service-data');
      return bad.length === 0 || bad; });
  }
  await tc('D2) تنفيذ شيفرة بطاقة المدير من حساب غير مدير لا يكشف شيئًا: أخذ شيفرات onclick من لوحة المدير ثم تنفيذها بعد تسجيل الخروج/ كعضو/تاجر → تُحوَّل بلا قائمة إدارية ولا استثناء ولا «حدث خطأ»', async () => {
    const a = mk('admin'); a.R(`go('adminDashboard')`); const cs = cards(a.E.screen()); const bad = [];
    for (const role of [null, 'user', 'dealer1']) { const x = mk(role); for (const c of cs) { let thrown = null; try { x.R(c.code); } catch (e) { thrown = e.message; } const h = x.E.screen(); if (thrown || /go\('adminMemberCarDetails'|class="stat-card"/.test(h) || x.R('currentRoute').startsWith('admin')) bad.push((role || 'guest') + ':' + c.label); } }
    return bad.length === 0 || bad.slice(0, 5); });
  await tc('D3) المدير الموقوف/التاجر المرفوض لا يرى اللوحة: حساب مدير موقوف (userOverrides) لا يدخل ولا يحصل على إحصاءات', async () => {
    const store = { 'najaf.userOverrides': JSON.stringify({ 6: { status: 'suspended' } }) }; const x = mk('admin', store);
    x.R(`go('adminDashboard')`); return (x.R('SessionService.isLoggedIn()') === false && x.R('getDashboardStats()') === null && !/class="stat-card"/.test(x.E.screen())) || 'suspended admin'; });

  /* ======================= E) لا محرك ثانٍ ولا تغيير خارج النطاق ======================= */
  console.log('\n--- E) بلا محرك فلترة جديد ---');
  await tc('E1) adminDashboard.js يعرض ويتنقّل فقط: لا فلترة ولا وصول لمستودعات ولا CarFilters ولا بحث، ويستعمل getDashboardStats وgo وesc الحاليين', async () => {
    const src = read('screens/adminDashboard.js').replace(/\/\*[\s\S]*?\*\//g, '');
    return (!/\.filter\(|Repository|CarFilters|searchCars|filterCars|localStorage|AppStorage/.test(src) && /getDashboardStats\(\)/.test(src) && /esc\(JSON\.stringify\(param\)\)/.test(src) && !/onclick="go\('\$\{route\}'\$\{param !== undefined \? `,\$\{JSON\.stringify\(param\)\}`/.test(src)) || 'engine'; });
  await tc('E2) لم يُغيَّر المسار القائم: شاشة adminMemberCars بتبويباتها الستة وmemberCarStatusBadge وAdminService.getDashboardStats كما هي، والحالات: لا reserved ولا حالة جديدة، و85 سكربتًا', async () => {
    const s = read('screens/adminMemberCars.js'); const tabs = (s.match(/\['(all|pending|active|sold|rejected|suspended)', '/g) || []).length;
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length; const a = mk('admin');
    const dash = read('screens/adminDashboard.js') + s;   // الشاشتان المعنيتان: لا ذكر لحالة محجوزة
    return (tabs === 6 && order === 85 && !/reserved|محجوز/i.test(dash) && JSON.stringify(a.J('SHOWROOM_CAR_STATUSES')) === '["available","sold"]' && JSON.stringify(a.J('Object.values(MEMBER_CAR_STATUS)')) === '["pending","active","sold","rejected","suspended"]') || { tabs, order }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

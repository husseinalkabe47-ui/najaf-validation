/* اختبارات «المرحلة 10 — الجزء 5: البحث والاكتشاف» (Phase 10 Part 5).
   تغطي: نص البحث (عربي/إنجليزي/أرقام/NFKC/مسافات/حالة أحرف) · الماركات والموديلات والسنوات الديناميكية من بيانات ظاهرة فقط ·
         السعر والمسافة من–إلى (المجهول ≠ 0، بلا سقف) · تركيب كل الفلاتر معًا (AND) · الظهور (لا تسريب لمخفي) ·
         «وين ألكه هاي السيارة؟» (التنقل لتفاصيل السيارة والمعرض والخريطة) · الشارات القابلة للإزالة · النتائج الفارغة · سلامة البيانات.
   كُتبت قبل التنفيذ لإثبات الفجوات ثم مرّت. تعيد استخدام محرك CarFilters وsearchService وvisibilityService (لا بديل عنها). */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const clone = o => JSON.parse(JSON.stringify(o));
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const idsOf = html => [...new Set([...String(html).matchAll(/go\('(?:carDetails|memberCarDetails)',(\d+)\)/g)].map(m => Number(m[1])))];
const BAD = /undefined|\bnull\b|NaN|\[object|TypeError|ReferenceError/;
const ERR = 'حدث خطأ، حاول مرة أخرى';
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const ids = (x, code) => J(x, `${code}.map(c=>c.id)`);
const opts = (x, pool, crit) => J(x, `CarFilters.options(${pool}, ${JSON.stringify(crit || {})})`);
const pub = "getPublicCars('showroom')";
/** يضيف سيارة معرض/عضو خامًا (بحقول كاملة قابلة للتعديل) */
/* الحقن عبر المستودع (يحفظ في التخزين) كي تبقى السيارات بعد «إعادة التحميل»؛ والسجلات الشاذة غير الصالحة تُحقن خامًا في البيئة نفسها */
const addCar = (x, o) => x.R(`CarsRepository.create(CarModel(Object.assign({ sourceType:'showroom', showroomId: 1, brand:'P', model:'M', year: 2020, price: 1000, mileage: 1000, status:'available' }, ${JSON.stringify(o)}))).ok`);
const addMember = (x, o) => x.R(`MemberCarsRepository.create(CarModel(Object.assign({ sourceType:'member', ownerId: 7, brand:'P', model:'M', year: 2020, price: 1000, mileage: 1000, status:'active' }, ${JSON.stringify(o)}))).ok`);
/** يضبط حقول شاشة (cars | member | search) كما يفعل المستخدم */
const F = c => ({ Brand: c.brand || '', Model: c.model || '', Year: c.year || '', MinPrice: c.minPrice === undefined ? '' : c.minPrice, MaxPrice: c.maxPrice === undefined ? '' : c.maxPrice, MinMileage: c.minMileage === undefined ? '' : c.minMileage, MaxMileage: c.maxMileage === undefined ? '' : c.maxMileage });
const setScr = (x, prefix, c) => Object.entries(F(c)).forEach(([k, v]) => x.E.els[prefix + 'Filter' + k] = { value: String(v), style: {} });
const chipsOf = html => [...String(html).matchAll(/<button[^>]*class="filter-chip"[^>]*aria-label="([^"]*)"[^>]*onclick="([^"]*)"[^>]*>([\s\S]*?)<\/button>/g)].map(m => ({ aria: m[1], onclick: m[2], text: m[3].replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim() }));
/* سياسة الظهور العام للمعارض: حُذفت من النتائج المتوقعة سيارات المعرض 3 قيد المراجعة (7–9) والمعرض 3 في استعلامات SH| فقط؛ كل ما عداها حرفيًا كما كان */
const REG = {"toyota|showroom":[1],"toyota|member":[101],"toyota|all":[1,101],"Toyota|showroom":[1],"Toyota|member":[101],"Toyota|all":[1,101],"تويوتا|showroom":[1],"تويوتا|member":[101],"تويوتا|all":[1,101],"تويوتا كورولا|showroom":[1],"تويوتا كورولا|member":[101],"تويوتا كورولا|all":[1,101],"كورولا ٢٠٢٢|showroom":[1],"كورولا ٢٠٢٢|member":[],"كورولا ٢٠٢٢|all":[1],"corolla 2022|showroom":[1],"corolla 2022|member":[],"corolla 2022|all":[1],"kia|showroom":[3,4],"kia|member":[106],"kia|all":[3,4,106],"كيا|showroom":[3,4],"كيا|member":[106],"كيا|all":[3,4,106],"hyundai|showroom":[2,6],"hyundai|member":[102,107],"hyundai|all":[2,6,102,107],"هيونداي|showroom":[2,6],"هيونداي|member":[102,107],"هيونداي|all":[2,6,102,107],"sportage|showroom":[4],"sportage|member":[],"sportage|all":[4],"سبورتاج|showroom":[4],"سبورتاج|member":[],"سبورتاج|all":[4],"genesis|showroom":[10],"genesis|member":[],"genesis|all":[10],"bmw|showroom":[12],"bmw|member":[],"bmw|all":[12],"lexus|showroom":[11],"lexus|member":[],"lexus|all":[11],"2022|showroom":[1,10],"2022|member":[],"2022|all":[1,10],"2020|showroom":[3,12],"2020|member":[102,107],"2020|all":[3,12,102,107],"٢٠٢٣|showroom":[4],"٢٠٢٣|member":[],"٢٠٢٣|all":[4],"سيارات معرض الفرات|showroom":[4,5,6],"سيارات معرض الفرات|member":[],"سيارات معرض الفرات|all":[4,5,6],"الفرات|showroom":[4,5,6],"الفرات|member":[],"الفرات|all":[4,5,6],"معرض النخبة|showroom":[10,11,12],"معرض النخبة|member":[],"معرض النخبة|all":[10,11,12],"النخبة|showroom":[10,11,12],"النخبة|member":[],"النخبة|all":[10,11,12],"camry|showroom":[],"camry|member":[],"camry|all":[],"accent|showroom":[6],"accent|member":[102],"accent|all":[6,102],"accent 2020|showroom":[],"accent 2020|member":[102],"accent 2020|all":[102],"kia sportage|showroom":[4],"kia sportage|member":[],"kia sportage|all":[4],"سيارات|showroom":[1,2,3,10,11,12],"سيارات|member":[],"سيارات|all":[1,2,3,10,11,12],"zzzz|showroom":[],"zzzz|member":[],"zzzz|all":[],"حي النصر|showroom":[],"حي النصر|member":[101],"حي النصر|all":[101],"النصر|showroom":[],"النصر|member":[101],"النصر|all":[101],"ممتازة|showroom":[],"ممتازة|member":[],"ممتازة|all":[],"أبيض|showroom":[],"أبيض|member":[],"أبيض|all":[],"SH|الفرات":[2],"SH|النجف":[1,2,4],"SH|السلام":[2],"SH|الكوفة":[1],"SH|toyota":[]};

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) نص البحث ======================= */
  console.log('\n--- A) نص البحث ---');
  await tc('A1) Toyota / toyota / TOYOTA / مسافات / ToYoTa / حروف عريضة (NFKC) / رموز غير مرئية: كلها نفس النتيجة (ليست ثلاث ماركات)', async () => {
    const x = mk(null); const q = ['Toyota', 'toyota', 'TOYOTA', '  toyota  ', 'ToYoTa', 'ＴＯＹＯＴＡ', 'toyota\u200f', 'Toy\u200bota']; const sets = q.map(s => ids(x, `searchCars(${JSON.stringify(s)}, 'showroom')`));
    return sets.every(s => same(s, [1])) || sets; });   /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */
  await tc('A2) مسافات زائدة/تبويب/مسافة غير منفصلة/رموز غير مرئية بين الكلمات: نفس النتيجة', async () => {
    const x = mk(null); const q = ['toyota corolla', '  toyota   corolla ', 'toyota\tcorolla', 'toyota\u00a0corolla', 'TOYOTA   COROLLA', 'Toy\u200bota Cor\u200bolla', 'ＴＯＹＯＴＡ　ＣＯＲＯＬＬＡ']; const sets = q.map(s => ids(x, `searchCars(${JSON.stringify(s)}, 'showroom')`));
    return sets.every(s => same(s, [1])) || sets; });
  await tc('A3) الأرقام العربية والإنجليزية والفارسية والعريضة: «٢٠٢٢» = «2022» = «۲۰۲۲» = «２０２２»', async () => {
    const x = mk(null); const q = ['2022', '٢٠٢٢', '۲۰۲۲', '２０２２', ' ٢٠٢٢ ']; const sets = q.map(s => ids(x, `searchCars(${JSON.stringify(s)}, 'showroom')`));
    return (sets.every(s => same(s, [1, 10])) && sets[0].length > 0) || sets; });
  await tc('A4) البحث يغطي الحقول المفيدة: الماركة، الموديل، السنة، اسم المعرض، عنوان المعرض، موقع سيارة العضو', async () => {
    const x = mk(null); const S = (q, s = 'showroom') => ids(x, `searchCars(${JSON.stringify(q)}, '${s}')`);
    return (same(S('kia'), [3, 4]) && same(S('sportage'), [4]) && same(S('2023'), [4]) && same(S('الفرات'), [4, 5, 6]) && same(S('الكوفة'), [1, 2, 3]) && same(S('كربلاء'), []) /* عنوان المعرض 3 المخفي لا يُبحث علنًا */ && same(S('حي السلام'), [4, 5, 6]) && same(S('حي الأمير'), [10, 11, 12]) &&
      same(S('النصر', 'member'), [101]) && same(S('الكوفة', 'member'), [102])) || { kia: S('kia'), kufa: S('الكوفة'), karbala: S('كربلاء') }; });
  await tc('A5) لا بحث في حقول داخلية عشوائية: الوصف/اللون/ناقل الحركة/الوقود/الحالة/المعرّف/السعر/المسافة/نوع المصدر لا تُطابق', async () => {
    const x = mk(null); addCar(x, { id: 9001, brand: 'Hidden', model: 'Fields', description: 'zzdescword', color: 'zzcolorword', transmission: 'zztransword', fuelType: 'zzfuelword', price: 7777777, mileage: 8888888 });
    const q = ['zzdescword', 'zzcolorword', 'zztransword', 'zzfuelword', '7777777', '8888888', 'available', 'sold', 'showroom', 'member', 'sourceType', '9001']; const bad = q.filter(s => ids(x, `searchCars(${JSON.stringify(s)}, 'all')`).length > 0);
    return bad.length === 0 && same(ids(x, `searchCars('fields','showroom')`), [9001]) || bad; });
  await tc('A6) قيم غير نصية لا تتسرب كنص بحث: لا «object» ولا «undefined» ولا «null» ولا «NaN» تطابق سجلات ناقصة', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9002, sourceType:'showroom', showroomId: 1, brand: {}, model: [], year: {}, price: 1, status:'available' }))`); x.R(`CARS.push(CarModel({ id: 9003, sourceType:'showroom', showroomId: 1, brand: null, model: undefined, year: NaN, price: 1, status:'available' }))`);
    const bad = ['object', 'undefined', 'null', 'nan', 'true', 'false'].filter(s => ids(x, `searchCars(${JSON.stringify(s)}, 'all')`).length > 0); return bad.length === 0 || bad; });
  await tc('A7) البحث بالعربية يعمل كما كان (مرادفات الماركات والموديلات) وكلمات «سيارات/معرض» التوقف', async () => {
    const x = mk(null); const S = q => ids(x, `searchCars(${JSON.stringify(q)}, 'showroom')`);
    return same(S('تويوتا كورولا'), [1]) && same(S('كيا'), [3, 4]) && same(S('سيارات معرض الفرات'), [4, 5, 6]) && same(S('كورولا ٢٠٢٢'), [1]); });
  await tc('A8) تعدّد الكلمات AND: كل كلمة يجب أن تطابق، وكلمة غير موجودة تُسقط النتيجة', async () => {
    const x = mk(null); const S = q => ids(x, `searchCars(${JSON.stringify(q)}, 'showroom')`);
    return same(S('kia sportage'), [4]) && S('kia corolla').length === 0 && S('toyota zzzz').length === 0 && same(S('toyota 2022'), [1]); });

  /* ======================= B) الماركات الديناميكية ======================= */
  console.log('\n--- B) الماركات الديناميكية ---');
  const brandVals = (x, pool = pub, crit) => opts(x, pool, crit).brands.map(b => b.value);
  await tc('B1) خيارات الماركة = ماركات السيارات الظاهرة فعلًا (بأعدادها)، ولا شيء آخر', async () => {
    const x = mk(null); const o = opts(x, pub); const vis = J(x, 'getVisibleCars().map(c=>c.brand)'); const uniq = [...new Set(vis)].sort();
    const cnt = Object.fromEntries(uniq.map(b => [b, vis.filter(v => v === b).length]));
    return (JSON.stringify(o.brands.map(b => b.value).sort()) === JSON.stringify(uniq) && o.brands.every(b => b.count === cnt[b.value])) || o.brands; });
  await tc('B2) الماركات المكرّرة بسبب الحالة/Unicode/الرموز غير المرئية تُدمج في خيار واحد بعدّه الصحيح', async () => {
    const x = mk(null); ['toyota', 'TOYOTA', 'Toyota ', 'ＴＯＹＯＴＡ', 'toyota\u200f'].forEach((b, i) => addCar(x, { id: 9010 + i, brand: b, model: 'Dup' + i }));
    const toy = opts(x, pub).brands.filter(b => /toyota/i.test(b.value) || b.key === 'toyota'); return (toy.length === 1 && toy[0].value === 'Toyota' && toy[0].count === 1 + 5) || toy; });   /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */
  await tc('B3) ماركة جديدة تظهر تلقائيًا (معرض وأعضاء) وتختفي بحذفها — بلا أي تعديل في الكود', async () => {
    const x = mk(null); const before = brandVals(x); addCar(x, { id: 9020, brand: 'Voyah', model: 'Free' }); addMember(x, { id: 9021, brand: 'Hongqi', model: 'H5' });
    const withNew = brandVals(x), withNewM = brandVals(x, "getPublicCars('member')"); x.R('CarsRepository.remove(9020)'); const after = brandVals(x);
    return (!before.includes('Voyah') && withNew.includes('Voyah') && withNewM.includes('Hongqi') && !after.includes('Voyah') && JSON.stringify(after) === JSON.stringify(before)) || { withNew }; });
  await tc('B4) لا ماركة بلا سيارة ظاهرة: معرض موقوف، إعلان عضو غير نشط، مالك غير فعّال — مخفية للعامة وظاهرة لمن يحق له', async () => {
    const x = mk('admin'); addCar(x, { id: 9030, showroomId: 5, brand: 'HiddenS', model: 'a' }); addMember(x, { id: 9031, brand: 'HiddenM', model: 'b', status: 'pending' }); addMember(x, { id: 9032, brand: 'HiddenO', model: 'c', ownerId: 7 });
    x.R(`UsersRepository.update(7, { status: 'suspended' })`); const g = asGuest(x);
    const pg = brandVals(g, "getPublicCars('all')"), pa = brandVals(x, pub);
    x.R(`UsersRepository.update(7, { status: 'active' })`); const back = brandVals(asGuest(x), "getPublicCars('all')");
    return (!pg.includes('HiddenS') && !pg.includes('HiddenM') && !pg.includes('HiddenO') && pa.includes('HiddenS') && back.includes('HiddenO') && !back.includes('HiddenM') && !back.includes('HiddenS')) || { pg, back }; });
  await tc('B5) كل سيارات ماركة صارت مخفية ← الماركة تختفي من الفلاتر العامة: إيقاف معرض النخبة يُسقط Genesis/Lexus/BMW؛ ورفض تاجر المعرض 2 يُسقط Nissan من سيارات المعارض ويعيدها الاعتماد', async () => {
    const a = mk('admin'); const before = brandVals(asGuest(a)); a.R('AdminService.suspendShowroom(4)'); const g = asGuest(a); const mid = brandVals(g); const adm = brandVals(a, pub);
    a.R('AdminService.activateShowroom(4)'); a.R('rejectDealer(2)'); const g2 = asGuest(a); const rej = brandVals(g2); a.R('approveDealer(2)'); const g3 = asGuest(a);
    return (['Genesis', 'Lexus', 'BMW'].every(b => before.includes(b) && !mid.includes(b) && adm.includes(b)) && before.includes('Nissan') && !rej.includes('Nissan') && brandVals(g3).includes('Nissan')) || { mid, rej }; });
  await tc('B6) شاشة السيارات: قائمة الماركات في HTML من البيانات (ماركة جديدة تظهر دون تعديل كود)، وشاشة البحث: من نتائج الاستعلام فقط', async () => {
    const x = mk(null); addCar(x, { id: 9040, brand: 'Voyah', model: 'Free' }); x.R(`go('cars')`); const h = x.E.screen(); x.R(`go('search','kia')`); const s = x.E.screen(); const sel = (s.match(/<select id="searchFilterBrand"[\s\S]*?<\/select>/) || [''])[0];
    return h.includes('value="Voyah"') && h.includes('value="Toyota"') && [...sel.matchAll(/<option value="([^"]+)"/g)].map(m => m[1]).join() === 'Kia'; });
  await tc('B7) لا قوائم مُشفَّرة: لا أسماء ماركات/موديلات ولا مصفوفات سنوات أو أسعار في ملفات الفلاتر والشاشات (ما عدا قاموس الأسماء العربية القديم في searchService)', async () => {
    const files = ['services/carFilterService.js', 'components/filters.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js']; const names = ['Toyota', 'Hyundai', 'Kia', 'Nissan', 'Chevrolet', 'Genesis', 'Lexus', 'BMW', 'Mercedes', 'Honda', 'Ford', 'Mazda', 'Corolla', 'Camry', 'Sportage'];
    const bad = []; files.forEach(f => { const s = strip(read(f)); names.filter(n => s.includes(n)).forEach(n => bad.push(f + ':' + n)); if (/\[\s*(?:19|20)\d{2}\s*,\s*(?:19|20)\d{2}/.test(s)) bad.push(f + ':years'); if (/\b(?:5|10|15|20|30|50)0{6}\b/.test(s)) bad.push(f + ':prices'); });
    return bad.length === 0 || bad; });

  /* ======================= C) الموديلات المرتبطة بالماركة ======================= */
  console.log('\n--- C) الموديلات ---');
  const modelVals = (x, brand, pool = pub) => opts(x, pool, { brand }).models.map(m => m.value);
  await tc('C1) موديلات Toyota = موديلات سيارات Toyota الظاهرة فقط (Corolla؛ Camry من المعرض 3 المخفي لا تظهر)، ولا موديل ماركة أخرى', async () => {
    const x = mk(null); const toy = modelVals(x, 'Toyota'), kia = modelVals(x, 'Kia'); const expect = [...new Set(J(x, `getVisibleCars().filter(c=>c.brand==='Toyota').map(c=>c.model)`))].sort();
    return (JSON.stringify(toy.slice().sort()) === JSON.stringify(expect) && expect.join() === 'Corolla' && !toy.some(m => kia.includes(m)) && kia.includes('Cerato') && !toy.includes('Cerato')) || { toy, kia }; });
  await tc('C2) تغيير الماركة يعيد حساب الموديلات ويُسقط الموديل غير المنتمي (حالة الشاشة + القائمة + الشارات)', async () => {
    const x = mk(null); x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Toyota', model: 'Corolla' }); x.R('onCarsFilter()'); const a = { m: x.R('carsFilters.model'), list: idsOf(x.E.els.carsList.innerHTML), bar: x.E.els.carsFilterBar.innerHTML };
    setScr(x, 'cars', { brand: 'Kia', model: 'Corolla' }); x.R('onCarsFilter()'); const bar2 = x.E.els.carsFilterBar.innerHTML;
    return (a.m === 'Corolla' && same(a.list, [1]) && a.bar.includes('value="Corolla"') && !a.bar.includes('value="Cerato"') && x.R('carsFilters.model') === '' && !bar2.includes('value="Corolla"') && bar2.includes('value="Cerato"') && bar2.includes('value="Sportage"') && !/الموديل: Corolla/.test(bar2) && chipsOf(bar2).every(c => !/Corolla/.test(c.text))) || { a: a.m, m: x.R('carsFilters.model') }; });
  await tc('C3) الموديلات المكرّرة بسبب الحالة/Unicode تُدمج في خيار واحد بعدّه الصحيح داخل الماركة', async () => {
    const x = mk(null); ['corolla', 'COROLLA', 'Corolla ', 'ＣＯＲＯＬＬＡ'].forEach((m, i) => addCar(x, { id: 9050 + i, brand: 'Toyota', model: m })); const c = opts(x, pub, { brand: 'Toyota' }).models.filter(m => m.key === 'corolla');
    return (c.length === 1 && c[0].value === 'Corolla' && c[0].count === 5) || c; });
  await tc('C4) بلا ماركة محدّدة: لا موديلات والقائمة معطّلة (الموديل مرتبط بالماركة)', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.els.carsFilterBar ? x.E.screen() : x.E.screen(); const m = (h.match(/<select id="carsFilterModel"[^>]*>/) || [''])[0];
    return opts(x, pub, {}).models.length === 0 && /disabled/.test(m); });
  await tc('C5) موديل سيارة مخفية (معرض موقوف) لا يظهر للعامة ويظهر للمدير؛ وموديل ماركة أخرى لا يدخل قائمة هذه الماركة', async () => {
    const a = mk('admin'); addCar(a, { id: 9060, showroomId: 5, brand: 'Toyota', model: 'HiddenModelX' }); addCar(a, { id: 9061, brand: 'Kia', model: 'Corolla' });
    const g = asGuest(a); const gm = modelVals(g, 'Toyota'), am = modelVals(a, 'Toyota'), km = modelVals(g, 'Kia');
    return (!gm.includes('HiddenModelX') && am.includes('HiddenModelX') && gm.join() === 'Corolla' && km.includes('Corolla') && same(ids(g, `CarFilters.apply(getPublicCars('showroom'), {brand:'Toyota', model:'Corolla'})`), [1])) || { gm, km }; });
  await tc('C6) شاشة البحث: تغيير الاستعلام بحيث لا تحوي النتائج الموديل المحدّد يمسحه بأمان (بلا ErrorState)', async () => {
    const x = mk(null); x.R(`go('search','toyota')`); setScr(x, 'search', { brand: 'Toyota', model: 'Corolla' }); x.R('onSearchFilter()'); const before = x.R('searchFilters.model');
    x.R(`onSearchScreenInput('kia')`); return before === 'Corolla' && x.R('searchFilters.model') === '' && !x.E.screen().includes(ERR) && !x.E.els.searchFilterBar.innerHTML.includes(ERR); });

  /* ======================= D) السنوات ======================= */
  console.log('\n--- D) السنوات ---');
  const yearVals = (x, pool = pub) => opts(x, pool).years;
  await tc('D1) السنوات من بيانات ظاهرة فقط، فريدة، تنازليًا (2023…2019؛ سنة 2018 كانت لسيارة المعرض 3 المخفي)', async () => {
    const x = mk(null); const y = yearVals(x); const exp = [...new Set(J(x, 'getVisibleCars().map(c=>c.year)'))].sort((a, b) => b - a);
    return (JSON.stringify(y) === JSON.stringify(exp) && y[0] === 2023 && y[y.length - 1] === 2019) || y; });
  await tc('D2) سنوات غير صالحة (null/فارغ/true/0/سالب/1/99999/نص/كائن/مصفوفة/NaN/خارج النطاق) لا تُعرض ولا تنهار التصفية، والسيارة نفسها تبقى في القائمة', async () => {
    const x = mk(null); const base = yearVals(x); const bad = ['null', "''", 'true', '0', '-5', '1', '99999', "'abc'", '{}', '[]', 'NaN', '1899', '2101', "'2020abc'", 'undefined'];
    bad.forEach((v, i) => x.R(`CARS.push(CarModel({ id: ${9100 + i}, sourceType:'showroom', showroomId: 1, brand:'Yr', model:'Y${i}', year: ${v}, price: 1000, status:'available' }))`));
    const after = yearVals(x); const ap = ids(x, `CarFilters.apply(getPublicCars('showroom'), {year: 2020})`); const none = bad.map((v, i) => 9100 + i).filter(id => ap.includes(id));
    x.R(`go('cars')`); const shown = idsOf(x.E.screen()); const okShown = bad.map((v, i) => 9100 + i).every(id => shown.includes(id)); x.R(`onCarsFilter()`);
    return (JSON.stringify(after) === JSON.stringify(base) && none.length === 0 && okShown && !x.E.screen().includes(ERR)) || { after, none }; });
  await tc('D3) سنة صالحة مخزَّنة كنص رقمي («2031») تُعرض وتُصفّى؛ وسنة جديدة تظهر تلقائيًا وتختفي إن صارت السيارة مخفية', async () => {
    const a = mk('admin'); addCar(a, { id: 9120, brand: 'Yr', model: 'S', year: '2031' }); addCar(a, { id: 9121, showroomId: 5, brand: 'Yr', model: 'H', year: 2035 });
    const g = asGuest(a); return yearVals(g).includes(2031) && !yearVals(g).includes(2035) && yearVals(a).includes(2035) && same(ids(g, `CarFilters.apply(getPublicCars('showroom'), {year: '2031'})`), [9120]); });
  await tc('D4) خيارات السنة في الواجهة: أرقام فقط بلا قيم بلا معنى، وفي السيارات والأعضاء والبحث من بياناتها', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 9130, sourceType:'showroom', showroomId: 1, brand:'Yr', model:'Z', year: 99999, price: 1000, status:'available' }))`);
    const bad = []; for (const [r, p] of [['cars'], ['memberCars'], ['search', 'kia']]) { x.R(`go('${r}'${p ? ",'" + p + "'" : ''})`); const sel = (x.E.screen().match(/<select id="\w+FilterYear"[\s\S]*?<\/select>/) || [''])[0]; const vals = [...sel.matchAll(/<option value="(\d*)"/g)].map(m => m[1]).filter(Boolean); if (vals.some(v => !/^(19|20)\d\d$/.test(v)) || vals.length === 0) bad.push(r + ':' + vals.join()); }
    return bad.length === 0 || bad; });

  /* ======================= E) نطاق السعر ======================= */
  console.log('\n--- E) السعر ---');
  const PT = x => { [[9200, 1000], [9201, 25000000], [9202, 40000000], [9203, 9999999999999]].forEach(([id, p]) => addCar(x, { id, brand: 'PriceT', model: 'P' + id, price: p })); };
  const apply = (x, crit) => ids(x, `CarFilters.apply(getPublicCars('showroom'), ${JSON.stringify(crit)})`);
  await tc('E1) من–إلى شامل الحدّين: min وحده، max وحده، والاثنان معًا', async () => {
    const x = mk(null); PT(x); const A = c => apply(x, Object.assign({ brand: 'PriceT' }, c));
    return same(A({ minPrice: 25000000, maxPrice: 40000000 }), [9201, 9202]) && same(A({ minPrice: 25000000 }), [9201, 9202, 9203]) && same(A({ maxPrice: 25000000 }), [9200, 9201]) && same(A({ minPrice: 25000001, maxPrice: 39999999 }), []) && same(A({ minPrice: 1000, maxPrice: 1000 }), [9200]); });
  await tc('E2) لا سقف مصطنع: سيارة بسعر 9,999,999,999,999 تُلتقط بالحد الأدنى وبأي حد أعلى كبير، ولا حد أعلى ثابت في الكود', async () => {
    const x = mk(null); PT(x); const A = c => apply(x, Object.assign({ brand: 'PriceT' }, c));
    return same(A({ minPrice: 9000000000000 }), [9203]) && same(A({ minPrice: 9999999999999, maxPrice: 9999999999999 }), [9203]) && same(A({ maxPrice: 999999999999999 }), [9200, 9201, 9202, 9203]) && A({ minPrice: 100000000000000 }).length === 0; });
  await tc('E3) الأرقام العربية/الفارسية/العريضة وفواصل ومسافات: كلها تعطي نتيجة الإدخال الإنجليزي نفسها', async () => {
    const x = mk(null); PT(x); const dig = (s, base) => s.replace(/\d/g, d => String.fromCharCode(base + Number(d)));
    const forms = ['25000000', dig('25000000', 0x660), dig('25000000', 0x6F0), dig('25000000', 0xFF10), '25,000,000', '25 000 000', '٢٥٬٠٠٠٬٠٠٠', '25،000،000', '25.000.000'];
    const res = forms.map(f => apply(x, { brand: 'PriceT', minPrice: f })); return res.every(r => same(r, [9201, 9202, 9203])) || res; });
  await tc('E4) السعر المجهول يبقى مجهولًا: (null/غائب/فارغ/0/سالب/نص/true/مصفوفة/NaN) لا يمرّ كصفر في أي فلتر سعر، ويظهر بلا فلتر', async () => {
    const x = mk(null); const bad = ['null', "''", '0', '-1', "'abc'", 'true', '[]', 'NaN', 'undefined']; bad.forEach((v, i) => x.R(`CARS.push(CarModel({ id: ${9210 + i}, sourceType:'showroom', showroomId: 1, brand:'NoPrice', model:'N${i}', year: 2020, price: ${v}, status:'available' }))`));
    const allIds = bad.map((v, i) => 9210 + i); const withF = [{ minPrice: 0 }, { maxPrice: 5 }, { minPrice: 0, maxPrice: 0 }, { maxPrice: 999999999999 }, { minPrice: 1 }].map(c => apply(x, Object.assign({ brand: 'NoPrice' }, c)));
    return (withF.every(r => r.length === 0) && same(apply(x, { brand: 'NoPrice' }), allIds)) || withF; });
  await tc('E5) min > max: بلا نتائج ورسالة عربية، وبلا انهيار (محرك + شاشة)', async () => {
    const x = mk(null); x.R(`go('cars')`); setScr(x, 'cars', { minPrice: '40000000', maxPrice: '25000000' }); x.R('onCarsFilter()'); const bar = x.E.els.carsFilterBar.innerHTML, list = x.E.els.carsList.innerHTML;
    return apply(x, { minPrice: 40000000, maxPrice: 25000000 }).length === 0 && bar.includes('الحد الأدنى للسعر أكبر من الحد الأعلى') && list.includes('لم نعثر على سيارات مطابقة لبحثك') && !BAD.test(bar + list) && !list.includes(ERR); });
  await tc('E6) إدخال غير صالح (abc / -5 / 12.5 / 1e6 / ٣٠ مليون) يُتجاهل برسالة «أدخل رقمًا صحيحًا» ولا يُصفّي بصمت ولا ينهار', async () => {
    const x = mk(null); x.R(`go('cars')`); const all = idsOf(x.E.screen()).length; const bad = [];
    for (const v of ['abc', '-5', '12.5', '1e6', '٣٠ مليون']) { setScr(x, 'cars', { minPrice: v }); x.R('onCarsFilter()'); const bar = x.E.els.carsFilterBar.innerHTML; if (!bar.includes('أدخل رقمًا صحيحًا') || idsOf(x.E.els.carsList.innerHTML).length !== all || BAD.test(bar) || chipsOf(bar).length !== 0) bad.push(v); }
    return bad.length === 0 || bad; });
  await tc('E7) تنبيه واضح عند وجود سيارات بلا سعر محدّد أثناء فلترة السعر (لا تظهر)، ولا تنبيه بلا فلتر أو بلا سيارات كهذه', async () => {
    const x = mk(null); x.R(`go('cars')`); setScr(x, 'cars', { minPrice: '1' }); x.R('onCarsFilter()'); const clean = x.E.els.carsFilterBar.innerHTML;
    addCar(x, { id: 9220, brand: 'NoPrice', model: 'a', price: null }); addCar(x, { id: 9221, brand: 'NoPrice', model: 'b', price: 0 }); x.R(`go('cars')`); setScr(x, 'cars', { minPrice: '1' }); x.R('onCarsFilter()'); const withNote = x.E.els.carsFilterBar.innerHTML;
    setScr(x, 'cars', {}); x.R('onCarsFilter()'); const none = x.E.els.carsFilterBar.innerHTML;
    return !/بدون سعر محدد/.test(clean) && /2 سيارة بدون سعر محدد لا تظهر عند فلترة السعر/.test(withNote) && !/بدون سعر محدد/.test(none); });

  /* ======================= F) نطاق المسافة ======================= */
  console.log('\n--- F) المسافة ---');
  const MT = x => { [[9300, 0], [9301, 1000], [9302, 50000], [9303, 999999999999]].forEach(([id, m]) => addCar(x, { id, brand: 'MileT', model: 'M' + id, mileage: m })); };
  await tc('F1) من–إلى شامل الحدّين، و0 الفعلي قيمة صالحة تدخل فلاتر المسافة وتُعرض «0 كم»', async () => {
    const x = mk(null); MT(x); const A = c => apply(x, Object.assign({ brand: 'MileT' }, c)); x.R(`go('cars')`); const card = x.R('CarCard(getCarById(9300))');
    return same(A({ minMileage: 0, maxMileage: 50000 }), [9300, 9301, 9302]) && same(A({ maxMileage: 0 }), [9300]) && same(A({ minMileage: 0, maxMileage: 0 }), [9300]) && same(A({ minMileage: 1000, maxMileage: 50000 }), [9301, 9302]) && same(A({ minMileage: 50001 }), [9303]) && card.includes('card-mileage') && card.includes(x.R('km(0)')); });
  await tc('F2) لا سقف مصطنع: 999,999,999,999 كم يُلتقط، ولا حد أعلى ثابت', async () => {
    const x = mk(null); MT(x); const A = c => apply(x, Object.assign({ brand: 'MileT' }, c));
    return same(A({ minMileage: 999999999999 }), [9303]) && same(A({ maxMileage: 99999999999999 }), [9300, 9301, 9302, 9303]); });
  await tc('F3) المسافة المجهولة (null/فارغ/نص/false/مصفوفة/NaN/سالبة) لا تتحوّل إلى 0 ولا تمرّ في أي فلتر مسافة (حتى «من 0»)، وتظهر بلا فلتر', async () => {
    const x = mk(null); const bad = ['null', "''", "'abc'", 'false', '[]', 'NaN', '-5', 'undefined', '{}']; bad.forEach((v, i) => x.R(`CARS.push(CarModel({ id: ${9310 + i}, sourceType:'showroom', showroomId: 1, brand:'NoKm', model:'K${i}', year: 2020, price: 1000, mileage: ${v}, status:'available' }))`));
    const allIds = bad.map((v, i) => 9310 + i); const withF = [{ minMileage: 0 }, { maxMileage: 100 }, { minMileage: 0, maxMileage: 0 }, { maxMileage: 99999999999 }].map(c => apply(x, Object.assign({ brand: 'NoKm' }, c)));
    return (withF.every(r => r.length === 0) && same(apply(x, { brand: 'NoKm' }), allIds)) || withF; });
  await tc('F4) المسافة السالبة المُدخلة تُرفض بأمان (رسالة ولا تصفية ولا انهيار)، والأرقام العربية/العريضة تعمل', async () => {
    const x = mk(null); MT(x); x.R(`go('cars')`); const all = idsOf(x.E.screen()).length; setScr(x, 'cars', { minMileage: '-5' }); x.R('onCarsFilter()'); const bar = x.E.els.carsFilterBar.innerHTML; const rejected = bar.includes('أدخل رقمًا صحيحًا') && idsOf(x.E.els.carsList.innerHTML).length === all && chipsOf(bar).length === 0;
    const dig = (s, base) => s.replace(/\d/g, d => String.fromCharCode(base + Number(d))); const forms = ['50000', dig('50000', 0x660), dig('50000', 0xFF10), '50,000', '٥٠٬٠٠٠', '50 000']; const res = forms.map(f => apply(x, { brand: 'MileT', maxMileage: f }));
    return rejected && res.every(r => same(r, [9300, 9301, 9302])) || { rejected, res }; });
  await tc('F5) تنبيه عدد السيارات بلا مسافة معلومة أثناء فلترة المسافة (يشمل السالب/غير الصالح كمجهول)', async () => {
    const x = mk(null); addCar(x, { id: 9320, brand: 'NoKm', model: 'a', mileage: null }); addCar(x, { id: 9321, brand: 'NoKm', model: 'b', mileage: -5 }); x.R(`go('cars')`); setScr(x, 'cars', { maxMileage: '999999' }); x.R('onCarsFilter()');
    return /2 سيارة بدون مسافة معلومة لا تظهر عند فلترة الكيلومترات/.test(x.E.els.carsFilterBar.innerHTML); });

  /* ======================= G) تركيب كل الفلاتر ======================= */
  console.log('\n--- G) تركيب الفلاتر (AND) ---');
  const COMBO = x => {
    addCar(x, { id: 9401, brand: 'Toyota', model: 'Camry', year: 2024, price: 30000000, mileage: 10000 });      // يطابق
    addCar(x, { id: 9402, brand: 'Toyota', model: 'Camry', year: 2024, price: 24999999, mileage: 10000 });      // سعر أقل
    addCar(x, { id: 9403, brand: 'Toyota', model: 'Camry', year: 2024, price: 40000001, mileage: 10000 });      // سعر أعلى
    addCar(x, { id: 9404, brand: 'Toyota', model: 'Camry', year: 2024, price: 30000000, mileage: 50001 });      // مسافة أعلى
    addCar(x, { id: 9405, brand: 'Toyota', model: 'Camry', year: 2023, price: 30000000, mileage: 10000 });      // سنة
    addCar(x, { id: 9406, brand: 'Toyota', model: 'Corolla', year: 2024, price: 30000000, mileage: 10000 });    // موديل
    addCar(x, { id: 9407, brand: 'Kia', model: 'Camry', year: 2024, price: 30000000, mileage: 10000 });        // ماركة
    addCar(x, { id: 9408, brand: 'Toyota', model: 'Camry', year: 2024, price: null, mileage: 10000 });          // سعر مجهول
    addCar(x, { id: 9409, brand: 'Toyota', model: 'Camry', year: 2024, price: 30000000, mileage: null });       // مسافة مجهولة
    addCar(x, { id: 9410, brand: 'Toyota', model: 'Camry', year: 2024, price: 25000000, mileage: 0 });          // حدّ أدنى + صفر حقيقي ← يطابق
    addCar(x, { id: 9411, brand: 'Toyota', model: 'Camry', year: 2024, price: 40000000, mileage: 50000 });      // حدّ أعلى ← يطابق
  };
  const CRIT = { brand: 'Toyota', model: 'Camry', year: 2024, minPrice: 25000000, maxPrice: 40000000, minMileage: 0, maxMileage: 50000 };
  await tc('G1) المثال المطلوب: Toyota + Camry + 2024 + سعر 25–40 مليون + مسافة 0–50,000 ← فقط ما يحقق كل الشروط (بما فيها الحدود الشاملة والصفر الحقيقي)', async () => {
    const x = mk(null); COMBO(x); return same(apply(x, CRIT), [9401, 9410, 9411]) || apply(x, CRIT); });
  await tc('G2) كل شرط يُسقط وحده: إزالة أي شرط من التركيب يُظهر السيارة التي كانت تفشل بسببه فقط', async () => {
    const x = mk(null); COMBO(x); const w = k => { const c = Object.assign({}, CRIT); k.forEach(f => delete c[f]); return apply(x, c); };
    return same(w(['maxPrice']), [9401, 9403, 9410, 9411]) && same(w(['minPrice']), [9401, 9402, 9410, 9411]) && same(w(['maxMileage']), [9401, 9404, 9410, 9411]) && same(w(['year']), [9401, 9405, 9410, 9411]) && same(w(['model']), [9401, 9406, 9410, 9411]) &&
      w(['brand']).includes(9407) && w(['minPrice', 'maxPrice']).includes(9408) && w(['minMileage', 'maxMileage']).includes(9409) && !apply(x, CRIT).includes(9408) && !apply(x, CRIT).includes(9409); });   // المجهول يُستبعد فقط ما دام فلتره فعّالًا، ويظهر عند إزالة ذلك الفلتر
  await tc('G3) نص البحث + الفلاتر معًا (AND) عبر searchCars نفسها: «camry» يطابق، «corolla» أو كلمة غريبة تُسقط الكل', async () => {
    const x = mk(null); COMBO(x); const S = q => ids(x, `searchCars(${JSON.stringify(q)}, 'showroom', ${JSON.stringify(CRIT)})`);
    return same(S('camry'), [9401, 9410, 9411]) && same(S('toyota camry 2024'), [9401, 9410, 9411]) && S('corolla').length === 0 && S('camry zzzz').length === 0 && same(S('كامري'), [9401, 9410, 9411]); });
  await tc('G4) الواجهة: ضبط الحقول الستة معًا (بأرقام عربية وفواصل) في شاشة السيارات يعرض الثلاث بالضبط مع خمس شارات', async () => {
    const x = mk(null); COMBO(x); x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Toyota', model: 'Camry', year: '2024', minPrice: '٢٥٬٠٠٠٬٠٠٠', maxPrice: '40,000,000', minMileage: '0', maxMileage: '50 000' }); x.R('onCarsFilter()');
    const list = x.E.els.carsList.innerHTML, bar = x.E.els.carsFilterBar.innerHTML; return (same(idsOf(list), [9401, 9410, 9411]) && chipsOf(bar).length === 5 && bar.includes('فلاتر فعالة (5)') && !BAD.test(bar + list)) || { ids: idsOf(list), chips: chipsOf(bar).length }; });
  await tc('G5) نفس التركيب في شاشة البحث الموحّد وسيارات الأعضاء: محرك واحد (نتائج الشاشة = searchCars)', async () => {
    const x = mk(null); COMBO(x); addMember(x, { id: 9412, brand: 'Toyota', model: 'Camry', year: 2024, price: 31000000, mileage: 20000 }); addMember(x, { id: 9413, brand: 'Toyota', model: 'Camry', year: 2024, price: 50000000, mileage: 20000 });
    x.R(`go('search','camry')`); setScr(x, 'search', { brand: 'Toyota', model: 'Camry', year: '2024', minPrice: '25000000', maxPrice: '40000000', minMileage: '0', maxMileage: '50000' }); x.R('onSearchFilter()'); const sIds = idsOf(x.E.els.searchResults.innerHTML);
    x.R(`go('memberCars')`); setScr(x, 'member', { brand: 'Toyota', model: 'Camry', year: '2024', minPrice: '25000000', maxPrice: '40000000' }); x.R('onMemberCarsFilter()'); const mIds = idsOf(x.E.els.memberCarsList.innerHTML);
    return (same(sIds, [9401, 9410, 9411, 9412]) && same(sIds, ids(x, `searchCars('camry','all', ${JSON.stringify(CRIT)})`)) && same(mIds, [9412])) || { sIds, mIds }; });

  /* ======================= H) الظهور ======================= */
  console.log('\n--- H) الظهور ---');
  const surfaces = (x, q) => { const o = {}; o.svc = ids(x, `searchCars(${JSON.stringify(q)}, 'all')`); x.R(`go('cars')`); x.R(`onCarsSearch(${JSON.stringify(q)})`); o.cars = idsOf(x.E.els.carsList.innerHTML); x.R(`go('memberCars')`); x.R(`onMemberCarsSearch(${JSON.stringify(q)})`); o.member = idsOf(x.E.els.memberCarsList.innerHTML); x.R(`go('search',${JSON.stringify(q)})`); o.search = idsOf(x.E.screen()); return o; };
  await tc('H1) معرض موقوف (الخليج 5): سياراته وموديلاتها واسمه وعنوانه لا تظهر في أي نتيجة أو خيار للزائر', async () => {
    const x = mk(null); const bad = []; for (const q of ['yaris', 'tucson', 'optima', 'الخليج', 'المدينة الصناعية', 'toyota yaris']) { const s = surfaces(x, q); [13, 14, 15].forEach(id => { if (s.svc.includes(id) || s.cars.includes(id) || s.member.includes(id) || s.search.includes(id)) bad.push(q + ':' + id); }); }
    return bad.length === 0 && !modelVals(x, 'Toyota').includes('Yaris') && !modelVals(x, 'Hyundai').includes('Tucson') && !modelVals(x, 'Kia').includes('Optima') || bad; });
  await tc('H2) إيقاف معرض فعّال من الإدارة: سياراته تختفي من البحث والفلاتر والخيارات للعامة (وتبقى للمدير)، وتعود بالتفعيل', async () => {
    const a = mk('admin'); a.R('AdminService.suspendShowroom(1)'); const g = asGuest(a); const sg = ids(g, `searchCars('', 'all')`), sa = ids(a, `searchCars('', 'all')`);
    const hidden = [1, 2, 3].every(id => !sg.includes(id) && sa.includes(id)) && !modelVals(g, 'Toyota').includes('Corolla') && modelVals(a, 'Toyota').includes('Corolla') && !surfaces(g, 'corolla').cars.includes(1) && !surfaces(g, 'النجف للسيارات').svc.some(id => [1, 2, 3].includes(id));
    a.R('AdminService.activateShowroom(1)'); return hidden && ids(asGuest(a), `searchCars('corolla','showroom')`).includes(1); });
  await tc('H3) إعلانات الأعضاء غير النشطة (pending/sold/rejected/suspended) لا تظهر في أي بحث أو خيار: 103،105،108،109،110', async () => {
    const x = mk(null); const hid = [103, 105, 108, 109, 110]; const bad = [];
    for (const q of ['rio', 'camry', 'sunny', 'sportage', 'tucson', 'حي السلام', 'المدينة الصناعية', 'toyota']) { const s = surfaces(x, q); hid.forEach(id => { if (s.svc.includes(id) || s.member.includes(id) || s.search.includes(id)) bad.push(q + ':' + id); }); }
    return bad.length === 0 && same(ids(x, `searchCars('', 'member')`), [101, 102, 104, 106, 107]) && same(ids(x, `CarFilters.apply(getPublicCars('member'), {})`), [101, 102, 104, 106, 107]) || bad; });
  await tc('H4) حساب مالك العضو غير الفعّال (الجزء 2): إعلانه الفعّال لا يظهر في البحث/الفلاتر/الخيارات (ماركة/موديل/سنة)، ويعود بإعادة التفعيل', async () => {
    const a = mk('admin'); addMember(a, { id: 9500, ownerId: 7, brand: 'Zeekr9', model: 'Z9', year: 2031, price: 5000 }); a.R(`UsersRepository.update(7, { status: 'suspended' })`); const g = asGuest(a); const s = surfaces(g, 'zeekr9');
    const o = opts(g, "getPublicCars('all')"); const hid = s.svc.length === 0 && s.member.length === 0 && s.search.length === 0 && !o.brands.some(b => b.value === 'Zeekr9') && !o.years.includes(2031) && !ids(g, `searchCars('', 'all')`).includes(101);
    a.R(`UsersRepository.update(7, { status: 'active' })`); const g2 = asGuest(a); const back = ids(g2, `searchCars('zeekr9','all')`).includes(9500) && opts(g2, "getPublicCars('all')").years.includes(2031);
    return hid && back; });
  await tc('H5) تاجر مرفوض: معرضه وإعلانه الشخصي معًا خارج كل النتائج والخيارات، وإعادة الاعتماد تعيدهما', async () => {
    const a = mk('admin'); a.R('rejectDealer(2)'); const g = asGuest(a); const all = ids(g, `searchCars('', 'all')`);
    const hid = [4, 5, 6, 104].every(id => !all.includes(id)) && !brandVals(g, "getPublicCars('showroom')").includes('Nissan');
    a.R('approveDealer(2)'); const g2 = asGuest(a); const back = [4, 5, 6, 104].every(id => ids(g2, `searchCars('', 'all')`).includes(id)); return hid && back; });
  await tc('H6) سجلات غير صالحة (نوع مجهول، بلا معرض، معرض غير موجود، حالة عضو مجهولة) لا تظهر في أي مكان ولا تُسقط الشاشات', async () => {
    const x = mk(null); x.R(`CARS.push({ id: 9601, sourceType: 'weird', showroomId: 1, brand: 'Inv', model: 'a' })`); x.R(`CARS.push({ id: 9602, sourceType: 'showroom', brand: 'Inv', model: 'b' })`); addCar(x, { id: 9603, showroomId: 9999, brand: 'Inv', model: 'c' }); addMember(x, { id: 9604, brand: 'Inv', model: 'd', status: 'zzz' });
    const bad = []; const s = surfaces(x, 'inv'); [s.svc, s.cars, s.member, s.search].forEach((l, i) => { if (l.length) bad.push('surface' + i + ':' + l.join()); }); if (brandVals(x, "getPublicCars('all')").includes('Inv')) bad.push('brand');
    for (const r of ['cars', 'memberCars', 'home', 'favorites']) { x.R(`go('${r}')`); if (x.E.screen().includes(ERR)) bad.push('screen:' + r); } return bad.length === 0 || bad; });
  await tc('H7) عدّاد النتائج لا يسرّب مخفيًا: يطابق ما يُعرض فعلًا للزائر والمدير', async () => {
    const a = mk('admin'); const g = asGuest(a); const bad = [];
    for (const [x, name] of [[g, 'guest'], [a, 'admin']]) { x.R(`go('cars')`); const html = x.E.screen(); const n = idsOf(html).length; const label = (html.match(/class="results-count"[^>]*>([^<]*)</) || [])[1]; if (label !== 'النتائج: ' + x.R(`carCountLabel(${n})`)) bad.push(name + ':' + label + '/' + n); }
    return bad.length === 0 && idsOf(g.E.screen()).length === 9 && idsOf(a.E.screen()).length === 15 || bad; });   /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */

  /* ======================= I) وين ألكه هاي السيارة؟ — التنقل ======================= */
  console.log('\n--- I) التنقل (وين ألكه هاي السيارة؟) ---');
  const clickOn = (x, h, needle) => { x.E.ctx.event = { stopPropagation() {}, key: '' }; const m = String(h).match(new RegExp(`onclick="((?:event\\.stopPropagation\\(\\);)?${needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})"`)); if (!m) return null; x.R(m[1]); return x.R('currentRoute'); };
  await tc('I1) بطاقة نتيجة البحث تفتح تفاصيل السيارة القائمة (carDetails) وتعرض السيارة نفسها', async () => {
    const x = mk(null); x.R(`go('search','corolla')`); const h = x.E.screen(); const r = clickOn(x, h, "go('carDetails',1)"); return r === 'carDetails' && x.E.screen().includes('handleFavoriteToggle(1)') && x.E.screen().includes('Corolla'); });
  await tc('I2) هوية المعرض ظاهرة وقابلة للنقر في نتيجة سيارة المعرض: اسم المعرض يفتح صفحة المعرض القائمة (showroomDetails) التي تحوي زر الخريطة', async () => {
    const x = mk(null); x.R(`go('search','corolla')`); const h = x.E.screen(); const card = x.R('CarCard(getCarById(1))');
    const r = clickOn(x, h, "go('showroomDetails',1)"); const d = x.E.screen();
    return (/<button[^>]*class="card-row card-showroom"[^>]*aria-label="عرض المعرض: معرض النجف للسيارات"/.test(card) && r === 'showroomDetails' && d.includes('معرض النجف للسيارات') && d.includes('google.com/maps') && d.includes('سيارات المعرض (3)')) || { r, hasBtn: /card-showroom/.test(card) }; });
  await tc('I3) زر الخريطة في نتائج البحث يفتح شاشة الخريطة القائمة (map) بلا نظام خرائط جديد', async () => {
    const x = mk(null); x.R(`go('search','toyota')`); const h = x.E.screen(); const r = clickOn(x, h, "go('map')"); const map = x.E.screen();
    return r === 'map' && map.includes('معرض النجف للسيارات') && !/<iframe|leaflet|mapbox|maplibre|google\.maps\.Map/i.test(read('screens/search.js') + read('components/carCard.js')); });
  await tc('I4) سيارة العضو: موقعها بدل المعرض (بلا رابط معرض) وتفتح memberCarDetails', async () => {
    const x = mk(null); const c = x.R('CarCard(getCarById(101))'); x.R(`go('memberCars')`); const r = clickOn(x, x.E.screen(), "go('memberCarDetails',101)");
    return c.includes('حي النصر') && !c.includes('showroomDetails') && !c.includes('card-showroom') && r === 'memberCarDetails'; });
  await tc('I5) الموديل نفسه في عدة معارض: كل سيارة نتيجة مستقلة بمعرضها (لا دمج)، وكل معرض يفتح صفحته', async () => {
    const x = mk(null); addCar(x, { id: 9700, showroomId: 2, brand: 'Toyota', model: 'Corolla', year: 2022, price: 17000000 }); addCar(x, { id: 9701, showroomId: 4, brand: 'Toyota', model: 'Corolla', year: 2022, price: 19000000 });
    x.R(`go('search','corolla')`); const h = x.E.screen(); const list = idsOf(h); const names = [1, 9700, 9701].map(id => x.R(`CarCard(getCarById(${id}))`).match(/card-showroom[^>]*>🏢\s*([^<]*)</)[1].trim());
    const links = [1, 2, 4].map(sid => h.includes(`go('showroomDetails',${sid})`)); return (same(list.filter(i => [1, 9700, 9701].includes(i)), [1, 9700, 9701]) && new Set(names).size === 3 && links.every(Boolean)) || { list, names, links }; });
  await tc('I6) استعلام باسم معرض/عنوان: بطاقة المعرض (ShowroomCard) وسياراته معًا، وتنقل المعرض لصفحته', async () => {
    const x = mk(null); x.R(`go('search','الفرات')`); const h = x.E.screen(); const r = clickOn(x, h, "go('showroomDetails',2)");
    x.R(`go('search','الفرات')`); return h.includes('class="card showroom-card"') && same(idsOf(h), [4, 5, 6]) && r === 'showroomDetails'; });
  await tc('I7) عنوان المعرض قابل للبحث: «شارع الكوفة» يجد سيارات معرض النجف (وسيارة العضو بموقعها)، ولا يسرّب معرضًا مخفيًا', async () => {
    const x = mk(null); const a = ids(x, `searchCars('شارع الكوفة','all')`); const b = ids(x, `searchCars('المدينة الصناعية','all')`);
    return same(a.filter(i => i < 100), [1, 2, 3]) && a.includes(102) && b.every(i => ![13, 14, 15].includes(i)) && same(b.filter(i => i < 100), []); });

  await tc('I8) شاشة السيارات (وجهة «وين ألكه هاي السيارة؟»): اختصار الخريطة يفتح route map القائم، وعدّاد النتائج سليم داخل الصف نفسه', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const r = clickOn(x, h, "go('map')");
    return (/class="results-head"[\s\S]*class="results-count"[^>]*>النتائج: /.test(h) && h.includes('aria-label="عرض مواقع المعارض على الخريطة"') && r === 'map' && x.E.screen().includes('google.com/maps')) || { r }; });
  await tc('I9) زر اسم المعرض في البطاقة يحيط بنصه لا بعرض البطاقة كلها (CSS) فيبقى ما بجانب النص ينقر للتفاصيل (قياس Chromium عند 390px: 145 من 246px بدل 222)', async () => {
    const css = read('theme/theme.css'); const rule = (css.match(/button\.card-showroom\{[^}]*\}/) || [''])[0];
    return (/width:\s*fit-content/.test(rule) && /max-width:\s*100%/.test(rule) && !/[^-]width:\s*100%/.test(rule) && /min-height:\s*40px/.test(rule)) || rule; });

  await tc('I10) كل حقل فلتر بتسمية ظاهرة تبقى بعد الكتابة (label يلفّ الحقل)، وplaceholder «بلا حد …» بلا أرقام مقترحة (لا سقف مُوحى به)، والسنة بعرض كامل', async () => {
    const x = mk(null); const bad = [];
    for (const [route, pre] of [['cars', 'cars'], ['memberCars', 'member'], ['search', 'search']]) {
      x.R(route === 'search' ? `go('search','kia')` : `go('${route}')`); setScr(x, pre, { brand: 'Kia', minPrice: 25000000, maxPrice: 40000000, minMileage: 0, maxMileage: 50000 }); x.R(route === 'cars' ? 'onCarsFilter()' : route === 'memberCars' ? 'onMemberCarsFilter()' : 'onSearchFilter()');
      const h = route === 'cars' ? x.E.els.carsFilterBar.innerHTML : route === 'memberCars' ? x.E.els.memberFilterBar.innerHTML : x.E.els.searchFilterBar.innerHTML;
      const labels = [...h.matchAll(/<label class="flt[^"]*"><span class="flt-l">([^<]*)<\/span>/g)].map(m => m[1]);
      if (labels.join('|') !== 'الماركة|الموديل|السنة|السعر من (د.ع)|السعر إلى (د.ع)|الكيلومترات من|الكيلومترات إلى') bad.push(route + ':' + labels.join('|'));
      if ([...h.matchAll(/placeholder="([^"]*)"/g)].some(m => /\d/.test(m[1]) || !/^بلا حد (أدنى|أقصى)$/.test(m[1]))) bad.push(route + ':placeholder');
      if (!/<label class="flt wide"><span class="flt-l">السنة<\/span><select id="\w+FilterYear"/.test(h)) bad.push(route + ':year-wide');
      if (!/value="25000000"/.test(h)) bad.push(route + ':value-kept');
    }
    return bad.length === 0 || bad; });

  /* ======================= J) النتائج الفارغة والمسح ======================= */
  console.log('\n--- J) نتائج فارغة ---');
  await tc('J1) السيارات: لا مطابقة ← رسالة + شرح + «مسح الفلاتر» و«مسح البحث»؛ والمسح يعيد الكل بحالة نظيفة بلا شارات', async () => {
    const x = mk(null); x.R(`go('cars')`); const all = idsOf(x.E.screen()).length; x.R(`onCarsSearch('zzzzqqq')`); setScr(x, 'cars', { brand: 'Kia', minPrice: '1' }); x.R('onCarsFilter()'); const e = x.E.els.carsList.innerHTML;
    const ok = e.includes('لم نعثر على سيارات مطابقة لبحثك') && e.includes('class="sub"') && e.includes('clearCarsFilters()') && e.includes('clearCarsSearch()') && !BAD.test(e) && !e.includes('results-count'); x.R('clearCarsFilters()'); const stillQ = x.R('carsSearchQuery') === 'zzzzqqq' && idsOf(x.E.screen()).length === 0;   // مسح الفلاتر وحده لا يمسح نص البحث (زرّان منفصلان بالتصميم القائم)
    x.R('clearCarsSearch()');
    return ok && stillQ && x.R('carsFilters.brand') === '' && x.R('carsFilters.minPrice') === '' && chipsOf(x.E.screen()).length === 0 && idsOf(x.E.screen()).length === all; });
  await tc('J2) سيارات الأعضاء: نفس السلوك (رسالة، مسح الفلاتر، العودة للكل)', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const all = idsOf(x.E.screen()).length; setScr(x, 'member', { brand: 'Kia', minPrice: '999999999' }); x.R('onMemberCarsFilter()'); const e = x.E.els.memberCarsList.innerHTML;
    const ok = e.includes('لم نعثر على سيارات مطابقة لبحثك') && e.includes('clearMemberCarsFilters()') && !BAD.test(e); x.R('clearMemberCarsFilters()'); return ok && idsOf(x.E.screen()).length === all && all === 5; });
  await tc('J3) البحث الموحّد: لا مطابقة ← الرسالة + «مسح البحث» + «مسح الفلاتر» + تصفح السيارات؛ ومسح الفلاتر يُرجع النتائج', async () => {
    const x = mk(null); x.R(`go('search','kia')`); setScr(x, 'search', { brand: 'Kia', minPrice: '999999999' }); x.R('onSearchFilter()'); const e = x.E.els.searchResults.innerHTML; const ok = e.includes('لم نعثر على سيارات مطابقة لبحثك') && e.includes('clearSearchScreen()') && e.includes('clearSearchFilters()') && e.includes("go('cars')") && !BAD.test(e);
    x.R('clearSearchFilters()'); return ok && idsOf(x.E.els.searchResults.innerHTML).length > 0 && x.R('searchFilters.minPrice') === ''; });
  await tc('J4) تركيبات متضاربة (min>max، ماركة+موديل غير متطابقين، سنة غير موجودة) ← فارغ بأمان وبلا انهيار في كل الشاشات', async () => {
    const x = mk(null); const bad = [];
    for (const c of [{ minPrice: '9', maxPrice: '1' }, { brand: 'Kia', model: 'Corolla' }, { year: '1999' }, { brand: 'Nonexistent' }, { minMileage: '9', maxMileage: '1' }]) { x.R(`go('cars')`); setScr(x, 'cars', c); x.R('onCarsFilter()'); const h = x.E.els.carsList.innerHTML + x.E.els.carsFilterBar.innerHTML; if (h.includes(ERR) || BAD.test(h)) bad.push(JSON.stringify(c)); }
    return bad.length === 0 || bad; });

  /* ======================= K) الشارات القابلة للإزالة + عدّاد النتائج ======================= */
  console.log('\n--- K) الشارات والعدّاد ---');
  const money = n => Number(n).toLocaleString('ar-IQ');
  await tc('K1) شارة لكل فلتر فعّال بنص مختصر: الماركة، الموديل، السنة، السعر «٢٥–٤٠ مليون»، المسافة «٠–٥٠٬٠٠٠ كم»', async () => {
    const x = mk(null); COMBO(x); x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Toyota', model: 'Camry', year: '2024', minPrice: '25000000', maxPrice: '40000000', minMileage: '0', maxMileage: '50000' }); x.R('onCarsFilter()');
    const c = chipsOf(x.E.els.carsFilterBar.innerHTML); const texts = c.map(k => k.text.replace(/\s*✕$/, ''));
    return (JSON.stringify(texts) === JSON.stringify(['Toyota', 'Camry', '2024', `${money(25)}–${money(40)} مليون`, `${money(0)}–${money(50000)} كم`]) && c.every(k => /^إزالة فلتر /.test(k.aria))) || texts; });
  await tc('K2) صيغ الشارات الأخرى: «من» وحده و«حتى» وحده وغير المليونية', async () => {
    const x = mk(null); const L = c => J(x, `CarFilters.chips(${JSON.stringify(c)}).map(k=>k.label)`);
    return JSON.stringify(L({ minPrice: 25000000 })) === JSON.stringify([`من ${money(25)} مليون`]) && JSON.stringify(L({ maxPrice: 40000000 })) === JSON.stringify([`حتى ${money(40)} مليون`]) && JSON.stringify(L({ minPrice: 12500000, maxPrice: 40000000 })).includes(money(12500000)) &&
      JSON.stringify(L({ minMileage: 1000 })) === JSON.stringify([`من ${money(1000)} كم`]) && JSON.stringify(L({ maxMileage: 0 })) === JSON.stringify([`حتى ${money(0)} كم`]) && L({}).length === 0 && L({ minPrice: 'abc', minMileage: '-5' }).length === 0; });
  const CRITof = f => { const c = {}; if (f.brand) c.brand = f.brand; if (f.model) c.model = f.model; if (f.year) c.year = f.year; if (f.minPrice) c.minPrice = f.minPrice; if (f.maxPrice) c.maxPrice = f.maxPrice; if (f.minMileage !== '') c.minMileage = f.minMileage; if (f.maxMileage !== '') c.maxMileage = f.maxMileage; return c; };
  await tc('K3) إزالة شارة تزيل فلترها وحده (الماركة تزيل معها الموديل لأنه تابع لها)، وبقية الفلاتر والنتائج تتبع الحالة نفسها', async () => {
    const mkState = () => { const x = mk(null); COMBO(x); x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Toyota', model: 'Camry', year: '2024', minPrice: '25000000', maxPrice: '40000000', minMileage: '0', maxMileage: '50000' }); x.R('onCarsFilter()'); return x; };
    const base = { brand: 'Toyota', model: 'Camry', year: '2024', minPrice: '25000000', maxPrice: '40000000', minMileage: '0', maxMileage: '50000' }; const out = {};
    for (const [key, cleared] of [['brand', ['brand', 'model']], ['model', ['model']], ['year', ['year']], ['price', ['minPrice', 'maxPrice']], ['mileage', ['minMileage', 'maxMileage']]]) {
      const x = mkState(); const chip = chipsOf(x.E.els.carsFilterBar.innerHTML).find(c => c.onclick === `removeCarsFilter('${key}')`); if (!chip) { out[key] = 'no chip'; continue; }
      x.R(chip.onclick); const st = J(x, 'carsFilters'); const exp = Object.assign({}, base); cleared.forEach(f => { exp[f] = ''; }); out[key] = JSON.stringify(st) === JSON.stringify(exp) && chipsOf(x.E.els.carsFilterBar.innerHTML).length === (key === 'brand' ? 3 : 4) && same(idsOf(x.E.els.carsList.innerHTML), apply(x, CRITof(exp)));
    }
    return Object.values(out).every(v => v === true) || out; });
  await tc('K4) «مسح الفلاتر» يمسح الكل بأمان، وإزالة آخر شارة تُخفي شريط الشارات؛ والشارات في سيارات الأعضاء والبحث الموحّد بنفس السلوك', async () => {
    const x = mk(null); x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Kia', year: '2020' }); x.R('onCarsFilter()'); const two = chipsOf(x.E.els.carsFilterBar.innerHTML).length; x.R(`removeCarsFilter('year')`); x.R(`removeCarsFilter('brand')`); const none = chipsOf(x.E.els.carsFilterBar.innerHTML).length === 0 && !x.E.els.carsFilterBar.innerHTML.includes('active-filters');
    x.R(`go('memberCars')`); setScr(x, 'member', { brand: 'Kia', year: '2019' }); x.R('onMemberCarsFilter()'); const mc = chipsOf(x.E.els.memberFilterBar.innerHTML); x.R(mc[0].onclick); const m1 = chipsOf(x.E.els.memberFilterBar.innerHTML).length;
    x.R(`go('search','kia')`); setScr(x, 'search', { year: '2020' }); x.R('onSearchFilter()'); const sc = chipsOf(x.E.els.searchFilterBar.innerHTML); x.R(sc[0].onclick); const s1 = chipsOf(x.E.els.searchFilterBar.innerHTML).length;
    return two === 2 && none && mc.length === 2 && mc[0].onclick === "removeMemberCarsFilter('brand')" && m1 === 1 && sc.length === 1 && sc[0].onclick === "removeSearchFilter('year')" && s1 === 0; });
  await tc('K5) تسميات الشارات مهرَّبة (XSS) وشارات غير صالحة/ناقصة لا تُعرض، وإزالة مفتاح غير معروف آمنة', async () => {
    const x = mk(null); addCar(x, { id: 9800, brand: '<img src=x onerror=alert(1)>', model: 'm' }); x.R(`go('cars')`); setScr(x, 'cars', { brand: '<img src=x onerror=alert(1)>' }); x.R('onCarsFilter()'); const bar = x.E.els.carsFilterBar.innerHTML;
    const before = x.R('JSON.stringify(carsFilters)'); x.R(`removeCarsFilter('zzz')`); x.R(`removeCarsFilter(undefined)`); x.R(`removeCarsFilter({})`);
    return !bar.includes('<img src=x') && bar.includes('&lt;img') && x.R('JSON.stringify(carsFilters)') === before; });
  await tc('K6) عدّاد النتائج: «النتائج: …» بصيغة عربية صحيحة (سيارة واحدة / سيارتان / N سيارات / N سيارة) ويتبع الفلاتر في السيارات والأعضاء', async () => {
    const x = mk(null); const L = n => x.R(`carCountLabel(${n})`); const bad = [1.5, -1, NaN, null, '', 'x', undefined, 0].map(v => x.R(`carCountLabel(${JSON.stringify(v)})`));
    x.R(`go('cars')`); const n0 = idsOf(x.E.screen()).length, l0 = (x.E.screen().match(/class="results-count"[^>]*>([^<]*)</) || [])[1]; setScr(x, 'cars', { brand: 'Kia' }); x.R('onCarsFilter()'); const l1 = (x.E.els.carsList.innerHTML.match(/class="results-count"[^>]*>([^<]*)</) || [])[1];
    x.R(`go('memberCars')`); const lm = (x.E.screen().match(/class="results-count"[^>]*>([^<]*)</) || [])[1];
    return (L(1) === 'سيارة واحدة' && L(2) === 'سيارتان' && L(3) === '3 سيارات' && L(10) === '10 سيارات' && L(11) === '11 سيارة' && L(25) === '25 سيارة' && bad.every(v => v === '') && l0 === 'النتائج: ' + L(n0) && l1 === 'النتائج: سيارتان' && lm === 'النتائج: 5 سيارات')   /* Kia الظاهرة في المعارض: 3 و4 فقط */ || { l0, l1, lm, bad }; });
  await tc('K7) شاشة البحث: عدد كل قسم في عنوانه، وزر الخريطة بجانب السيارات (route map القائم)', async () => {
    const x = mk(null); x.R(`go('search','toyota')`); const h = x.E.screen(); return /🚘 السيارات \(\d+\)/.test(h) && h.includes("go('map')") && /📍/.test(h); });

  /* ======================= L) سلامة البيانات والأداء ======================= */
  console.log('\n--- L) سلامة البيانات ---');
  await tc('L1) البحث والفلترة والمسح لا تكتب شيئًا في التخزين ولا تعدّل أي سجل، ولا مفتاح فلاتر/بحث محفوظ (كتابات = 0)', async () => {
    const init = {}; const writes = []; const store = new Proxy(init, { set(tg, k, v) { writes.push(k); tg[k] = v; return true; } }); const x = mk(null, store); writes.length = 0; const snap = () => JSON.stringify({ c: J(x, 'CARS'), m: J(x, 'MEMBER_CARS'), f: J(x, 'FavoritesRepository.getAll()'), i: J(x, 'CAR_IMAGES'), s: J(x, 'SHOWROOMS') }); const before = snap(); const keys = Object.keys(init).sort().join();
    for (const q of ['toyota', 'ＴＯＹＯＴＡ', 'كورولا ٢٠٢٢', 'zzzz', 'الكوفة', '']) { x.R(`go('cars')`); x.R(`onCarsSearch(${JSON.stringify(q)})`); x.R(`go('search',${JSON.stringify(q)})`); x.R(`go('memberCars')`); x.R(`onMemberCarsSearch(${JSON.stringify(q)})`); }
    for (const c of [{ brand: 'Toyota', model: 'Camry', year: '2020', minPrice: '1', maxPrice: '99999999', minMileage: '0', maxMileage: '999999' }, { brand: 'Kia' }, {}]) { x.R(`go('cars')`); setScr(x, 'cars', c); x.R('onCarsFilter()'); x.R('onCarsRange()'); x.R(`removeCarsFilter('year')`); x.R('clearCarsFilters()'); x.R(`go('search','kia')`); setScr(x, 'search', c); x.R('onSearchFilter()'); x.R('clearSearchFilters()'); }
    return (writes.length === 0 && snap() === before && Object.keys(init).sort().join() === keys && !Object.keys(init).some(k => /filter|search|query/i.test(k))) || { writes: writes.slice(0, 5) }; });
  await tc('L2) الفلاتر ليست حالة محفوظة: إعادة التحميل تبدأ نظيفة، وحالة كل شاشة متغيّر واحد فقط (لا حالة مكرّرة)', async () => {
    const x = mk(null); x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Kia' }); x.R('onCarsFilter()'); const y = mk(null, x.E.store); y.R(`go('cars')`);
    const states = ['screens/cars.js', 'screens/memberCars.js', 'screens/search.js'].map(f => (strip(read(f)).match(/^let \w*Filters\s*=/gm) || []).length);
    return y.R('carsFilters.brand') === '' && chipsOf(y.E.screen()).length === 0 && states.every(n => n === 1); });
  await tc('L3) الأداء: 300 سيارة إضافية ← خيارات وبحث وفلاتر بعدة معايير في زمن معقول بلا انهيار (بلا مسح تخزين)', async () => {
    const x = mk(null); for (let i = 0; i < 300; i++) addCar(x, { id: 20000 + i, brand: ['Toyota', 'KIA', 'hyundai', 'Nissan'][i % 4], model: 'M' + (i % 17), year: 2000 + (i % 24), price: 1000000 + i * 1000, mileage: i * 100 });
    const t0 = Date.now(); for (let i = 0; i < 20; i++) { opts(x, pub, { brand: 'Toyota' }); ids(x, `searchCars('toyota m3', 'showroom', ${JSON.stringify({ minPrice: 1100000, maxMileage: 25000 })})`); } const ms = Date.now() - t0; x.R(`go('cars')`); setScr(x, 'cars', { brand: 'Toyota', model: 'M4' }); x.R('onCarsFilter()');
    return (ms < 4000 && !x.E.screen().includes(ERR) && !BAD.test(x.E.els.carsList.innerHTML)) || { ms }; });

  /* ======================= M) انحدار: البحث القائم يعمل كما كان ======================= */
  console.log('\n--- M) انحدار ---');
  await tc('M1) جدول الانحدار: نتائج searchCars (3 مصادر × 35 استعلامًا) وsearchShowrooms مطابقة حرفيًا للكود السابق، عدا استعلامات العناوين التي صارت قابلة للبحث عمدًا', async () => {
    const x = mk(null); const bad = []; for (const [k, v] of Object.entries(REG)) { const [q, s] = k.split('|'); const got = k.startsWith('SH|') ? ids(x, `searchShowrooms(${JSON.stringify(k.slice(3))})`) : ids(x, `searchCars(${JSON.stringify(q)}, '${s}')`); if (JSON.stringify(got) !== JSON.stringify(v)) bad.push(k + ' ← ' + JSON.stringify(got)); }
    return bad.length === 0 && Object.keys(REG).length >= 100 || bad.slice(0, 6); });
  await tc('M2) استعلامات العناوين: النتائج القديمة محفوظة كلها (⊇) ويُضاف إليها سيارات المعرض صاحب العنوان فقط', async () => {
    const x = mk(null); const old = { 'الكوفة|all': [102], 'النجف|all': [1, 2, 3, 101, 102, 104, 106, 107], 'النصر|member': [101] }; const bad = [];
    for (const [k, v] of Object.entries(old)) { const [q, s] = k.split('|'); const got = ids(x, `searchCars(${JSON.stringify(q)}, '${s}')`); if (!v.every(i => got.includes(i))) bad.push(k); }
    const naj = ids(x, `searchCars('النجف','showroom')`); return bad.length === 0 && same(naj, J(x, 'getVisibleCars().map(c=>c.id)')) && same(ids(x, `searchCars('السلام','showroom')`), [4, 5, 6]) || bad; });
  await tc('M3) واجهات المحرك والخدمات القائمة محفوظة بأسمائها وسلوكها: searchCars/searchShowrooms/filterCars/filterMemberCars/applyCarFilters وCarFilters.*', async () => {
    const x = mk(null); const fns = ['searchCars', 'searchShowrooms', 'filterCars', 'filterMemberCars', 'applyCarFilters', 'activeFilterCount', 'newFilters', 'readFilters', 'FilterBar', 'FilterChips']; const cf = ['key', 'canonicalBrand', 'canonicalModel', 'normalize', 'activeCount', 'validate', 'apply', 'matches', 'options', 'reconcileModel', 'describe', 'sameKey'];
    const miss = fns.filter(f => x.R(`typeof ${f}`) !== 'function').concat(cf.filter(f => x.R(`typeof CarFilters.${f}`) !== 'function'));
    return miss.length === 0 && same(ids(x, `filterCars({brand:'kia'})`), [3, 4]) && same(ids(x, `filterMemberCars({brand:'kia', maxPrice: 20000000})`), [106]) && same(ids(x, `applyCarFilters(getCars(), {brand:'Toyota'})`), [1, 7, 13]) || miss; });
  await tc('M4) معرّفات حقول الفلاتر ونصوصها القائمة محفوظة (الاختبارات القديمة تعتمد عليها): الحقول السبعة، «فلاتر فعالة (n)»، «مسح الفلاتر»', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); setScr(x, 'cars', { brand: 'Toyota' }); x.R('onCarsFilter()'); const bar = x.E.els.carsFilterBar.innerHTML;
    return ['carsFilterBrand', 'carsFilterModel', 'carsFilterYear', 'carsFilterMinPrice', 'carsFilterMaxPrice', 'carsFilterMinMileage', 'carsFilterMaxMileage'].every(id => h.includes(`id="${id}"`)) && bar.includes('فلاتر فعالة (1)') && bar.includes('مسح الفلاتر') && bar.includes('value="Toyota" selected'); });

  /* ======================= N) فحوص ثابتة ======================= */
  console.log('\n--- N) فحوص ثابتة ---');
  await tc('N1) لا نظام بحث/فلترة موازٍ: الشاشات ومكوّن الفلاتر لا تفلتر بنفسها (كلها searchCars/CarFilters)، ولا قاعدة ظهور جديدة', async () => {
    const files = ['screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'components/filters.js']; const bad = files.filter(f => /\.filter\s*\(|\.sort\s*\(/.test(strip(read(f))));   // تصفية/فرز قوائم السيارات (لا .some() لتحديد الخيار المحدَّد في قائمة منسدلة)
    const vis = files.concat(['components/carCard.js']).filter(f => /canViewCar|canViewShowroom|USER_STATUS|UsersRepository/.test(strip(read(f)))); return (bad.length === 0 && vis.length === 0) || { bad, vis }; });
  await tc('N2) لا ميزات خارج النطاق: لا بحث صوتي/ذكاء اصطناعي/شبكة/موقع/بحث محفوظ/إشعارات في ملفات البحث والفلاتر', async () => {
    const files = ['services/searchService.js', 'services/carFilterService.js', 'components/filters.js', 'components/searchBox.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'screens/home.js']; const re = /fetch\s*\(|XMLHttpRequest|WebSocket|SpeechRecognition|webkitSpeechRecognition|navigator\.(geolocation|mediaDevices)|localStorage|indexedDB|AppStorage|Notification|savedSearch|saveSearch|openai|gemini|anthropic/i;
    const bad = files.filter(f => re.test(strip(read(f)))); return bad.length === 0 || bad; });
  await tc('N3) المعمارية محفوظة: لا ملفات خدمة/مستودع جديدة، ولا مساس بقواعد الظهور (visibilityService) ولا بالمستودعات والتخزين', async () => {
    const svc = fs.readdirSync(path.join(ROOT, 'services')).sort().join(); const need = ['adminService.js', 'authService.js', 'authorizationService.js', 'carFilterService.js', 'carImagesService.js', 'dataService.js', 'favoritesService.js', 'formatService.js', 'imageService.js', 'imageStore.js', 'memberCarsService.js', 'migrationService.js', 'rewardService.js', 'searchService.js', 'sessionService.js', 'showroomCarsService.js', 'showroomService.js', 'storageService.js', 'userService.js', 'visibilityService.js'].sort().join();
    return svc === need || svc; });
  await tc('N4) CSS الجزء 5 (إضافات فقط بمتغيرات التصميم): أهداف لمس ≥ 40px للشارات وحقول الفلاتر، خطوط ≥ 12px، بلا left/right ولا ألوان جديدة ولا حركات، وكسر نص طويل', async () => {
    const css = read('theme/theme.css'); const i = css.indexOf('/* ---- المرحلة 10 / الجزء 5'); const b = i >= 0 ? css.slice(i) : ''; const sizes = [...b.matchAll(/font-size:\s*([\d.]+)px/g)].map(m => Number(m[1]));
    return (b.length > 100 && /\.filter-chip\{[^}]*min-height:\s*(4\d|[5-9]\d)px/.test(b) && /\.filters-grid[^{]*\{[^}]*min-height:\s*(4\d|[5-9]\d)px/.test(b) && sizes.every(s => s >= 12) && !/margin-left|margin-right|padding-left|padding-right|text-align:\s*(left|right)|(^|[;{\s])(left|right)\s*:/.test(b) && !/#[0-9a-fA-F]{3,6}/.test(b) && !/--[a-z-]+\s*:/.test(b) && !/@keyframes|animation|transition/.test(b) && /overflow-wrap:\s*anywhere/.test(b)) || { len: b.length, sizes }; });

  await tc('N5) أسماء طويلة جدًا لا تمدّ الصفحة: شبكة الفلاتر بأعمدة minmax(0,1fr) وقوائمها بعرض 100% وmin-width:0 ونقاط قصّ، وشارة الحالة ≥ 12px (قياس Chromium بأسماء 180 حرفًا: الأساس كان يتجاوز عرض الشاشة 804px عند 320 و734px عند 390، والآن 0)', async () => {
    const css = read('theme/theme.css'); const b = css.slice(css.indexOf('/* ---- المرحلة 10 / الجزء 5'));
    return /\.filters-grid\{[^}]*grid-template-columns:\s*repeat\(2,\s*minmax\(0,\s*1fr\)\)/.test(b) && /\.filters-grid select\{[^}]*width:\s*100%[^}]*min-width:\s*0[^}]*text-overflow:\s*ellipsis/.test(b) && /\.badge\{[^}]*font-size:\s*12px/.test(b); });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

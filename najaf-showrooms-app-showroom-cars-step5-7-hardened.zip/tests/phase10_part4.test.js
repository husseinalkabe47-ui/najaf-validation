/* اختبارات «المرحلة 10 — الجزء 4: تحسين تجربة الصفحة الرئيسية» (Phase 10 Part 4).
   تغطي: عرض آمن · البطل والبحث · إجراءا الاستكشاف · قسم السيارات (ظهور/حالة/حد) · قسم المعارض · معلومات المنصة ·
         الحالات الفارغة والمحدودة · عدم تكرار منطق الظهور/الفلترة · الإعلانات · إمكانية الوصول والتصميم.
   كُتبت قبل التنفيذ لإثبات النواقص ثم مرّت. تفحص HTML الفعلي للرئيسية والتنقّل الفعلي عبر onclick نفسها. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 200)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer5: ['07715558899', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const clone = o => JSON.parse(JSON.stringify(o));
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const BAD = /undefined|\bnull\b|NaN|\[object|TypeError|ReferenceError/;
const ERR = 'حدث خطأ، حاول مرة أخرى';
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const home = x => { x.R(`go('home')`); return x.E.screen(); };
/** قسم من الرئيسية بمعرّفه (section id="…") */
const section = (h, id) => (String(h).match(new RegExp(`<section id="${id}"[\\s\\S]*?</section>`)) || [''])[0];
const ordered = (html, re) => { const out = []; for (const m of String(html).matchAll(re)) { const n = Number(m[1]); if (!out.includes(n)) out.push(n); } return out; };
const carIds = html => ordered(html, /go\('carDetails',(\d+)\)/g);
const memberIds = html => ordered(html, /go\('memberCarDetails',(\d+)\)/g);
const showroomIds = html => ordered(html, /go\('showroomDetails',(\d+)\)/g);
const sameArr = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const sameSet = (a, b) => JSON.stringify(a.slice().sort((p, q) => p - q)) === JSON.stringify(b.slice().sort((p, q) => p - q));
const buttonsOf = h => [...String(h).matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)].map(m => ({ attrs: m[1], text: m[2].replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim() }));
const emptyStore = () => ({ 'najaf.showroomCars': '[]', 'najaf.memberCars': '[]', 'najaf.memberCarsDeleted': JSON.stringify([101, 102, 103, 104, 105, 106, 107, 108, 109, 110]), 'najaf.carImages': '[]' });
const setStatus = (x, id, st) => x.R(`UsersRepository.update(${id}, { status: ${JSON.stringify(st)} }).ok`);
/** ينفّذ onclick الظاهر في HTML (نص «go('map')» …) كما يفعل المتصفح، ويعيد المسار الناتج */
const clickOnclick = (x, h, needle) => { const m = String(h).match(new RegExp(`onclick="(${needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})"`)); if (!m) return null; x.R(m[1]); return x.R('currentRoute'); };

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) البطل والبحث ======================= */
  console.log('\n--- A) البطل والبحث ---');
  await tc('A1) الرئيسية تُعرض بأمان ببيانات عادية: بلا ErrorState ولا undefined/null/NaN/[object]', async () => {
    const bad = []; for (const role of [null, 'user', 'dealer1', 'admin']) { const x = mk(role); const h = home(x); if (h.includes(ERR) || BAD.test(h) || x.E.errors.length) bad.push(role); }
    return bad.length === 0 || bad; });
  await tc('A2) رسالة المنصة: عنوان رئيسي واحد «اعثر على سيارتك بين معارض النجف» وسطر داعم موجز', async () => {
    const h = home(mk(null)); const h1s = h.match(/<h1\b[^>]*>[\s\S]*?<\/h1>/g) || [];
    return (h1s.length === 1 && h1s[0].includes('اعثر على سيارتك بين معارض النجف') && /class="home-lead"/.test(h)) || h1s; });
  await tc('A3) اسم المنصة وزر الحساب محفوظان بحسب الدور (دخول/حسابي/إدارة معرضي/لوحة الإدارة)', async () => {
    const r = { guest: "go('login')", user: "go('account')", dealer1: "go('dealerHome')", admin: "go('adminHome')" }; const bad = [];
    for (const [role, route] of Object.entries(r)) { const h = home(mk(role === 'guest' ? null : role)); if (!h.includes('🚗 معارض النجف') || !h.includes(`class="account-btn" onclick="${route}"`)) bad.push(role); }
    return bad.length === 0 || bad; });
  await tc('A4) مربع البحث الحالي محفوظ ومحسَّن: handleHomeSearch وزر «بحث» وaria-label وenterkeyhint وplaceholder موجز', async () => {
    const h = home(mk(null)); const inp = (h.match(/<div class="searchbox">[\s\S]*?<input([^>]*)\/>/) || [])[1] || '';
    return (h.includes('handleHomeSearch(this.value)') && h.includes('class="search-go"') && /aria-label="[^"]+"/.test(inp) && /enterkeyhint="search"/.test(inp) && /placeholder="[^"]{6,60}"/.test(inp)) || inp; });
  await tc('A5) البحث ينتقل لمسار البحث الموحّد القائم بنفس النص (لا نظام بحث منفصل)، والفارغ ينتقل لشاشة السيارات', async () => {
    const x = mk(null); x.R(`handleHomeSearch('  تويوتا كورولا ')`); const r1 = x.R('currentRoute'), s1 = x.E.screen().includes('Toyota') && x.E.screen().includes('Corolla');
    const y = mk(null); y.R(`go('home')`); y.R(`handleHomeSearch('')`); const r2 = y.R('currentRoute'); const z = mk(null); z.R(`handleHomeSearch('   ')`); const r3 = z.R('currentRoute');
    return (r1 === 'search' && s1 && r2 === 'cars' && r3 === 'cars') || { r1, s1, r2, r3 }; });
  await tc('A6) مدخلات بحث غريبة (null/رقم/كائن/وسوم) لا ترمي، والوسوم الضارة تظهر نصًا في نتائج البحث', async () => {
    const bad = []; for (const v of ['null', 'undefined', '42', '{}', "'<img src=x onerror=alert(1)>'"]) { const x = mk(null); try { x.R(`handleHomeSearch(${v})`); const h = x.E.screen(); if (h.includes(ERR) || h.includes('<img src=x')) bad.push(v); } catch (e) { bad.push('EXC:' + v); } }
    return bad.length === 0 || bad; });

  /* ======================= B) إجراءا الاستكشاف ======================= */
  console.log('\n--- B) إجراءا الاستكشاف ---');
  const MAPTXT = 'استكشف المعارض على الخريطة', FINDTXT = 'وين ألكه هاي السيارة؟';
  await tc('B1) «استكشف المعارض على الخريطة»: زر بارز نصّه الكامل، onclick="go(\'map\')"', async () => {
    const h = home(mk(null)); const b = buttonsOf(h).find(b => b.text.includes(MAPTXT));
    return (!!b && b.attrs.includes(`onclick="go('map')"`) && /class="home-action[ "]/.test(b.attrs) && b.attrs.includes('type="button"')) || b; });
  await tc('B2) «وين ألكه هاي السيارة؟»: زر بارز نصّه الكامل، onclick="go(\'cars\')" (مسار الاكتشاف والبحث القائم)', async () => {
    const h = home(mk(null)); const b = buttonsOf(h).find(b => b.text.includes(FINDTXT));
    return (!!b && b.attrs.includes(`onclick="go('cars')"`) && /class="home-action[ "]/.test(b.attrs) && b.attrs.includes('type="button"')) || b; });
  await tc('B3) تنفيذ onclick فعليًا: الخريطة تفتح شاشة الخريطة القائمة بمعارضها الظاهرة، والسيارات تفتح البحث والفلاتر القائمة', async () => {
    const x = mk(null); const h = home(x); const r1 = clickOnclick(x, h, "go('map')"); const map = x.E.screen();
    const y = mk(null); const h2 = home(y); const r2 = clickOnclick(y, h2, "go('cars')"); const cars = y.E.screen();
    return (r1 === 'map' && map.includes('مواقع المعارض') && sameSet(showroomIds(map), J(x, `searchShowrooms('').map(s=>s.id)`)) &&
      r2 === 'cars' && cars.includes('onCarsSearch') && cars.includes('id="carsFilterBar"') && cars.includes('id="carsFilterBrand"')) || { r1, r2 }; });
  await tc('B4) نفس محرك البحث والفلترة القائم: بعد الانتقال، البحث والفلاتر في شاشة السيارات تعمل كما في بقية التطبيق', async () => {
    const y = mk(null); home(y); y.R(`go('cars')`); y.R(`onCarsSearch('kia')`); const a = carIds(y.E.els.carsList.innerHTML);
    const want = J(y, `searchCars('kia','showroom').map(c=>c.id)`); y.R('onCarsSearch("")');
    y.E.els.carsFilterBrand = { value: 'Toyota', style: {} }; y.R('onCarsFilter()'); const b = carIds(y.E.els.carsList.innerHTML); const wantB = J(y, `searchCars('', 'showroom', {brand:'Toyota'}).map(c=>c.id)`);
    return (a.length > 0 && sameSet(a, want) && b.length > 0 && sameSet(b, wantB)) || { a, want, b, wantB }; });
  await tc('B5) الترتيب: البطل ← إجراءا الاستكشاف ← وصول سريع ← قسم السيارات ← قسم المعارض', async () => {
    const h = home(mk(null)); const marks = ['home-hero', 'home-actions', 'homeQuickTitle', 'id="homeCars"', 'id="homeShowrooms"'].map(s => h.indexOf(s));
    return (marks.every(i => i >= 0) && marks.every((v, i) => i === 0 || v > marks[i - 1])) || marks; });
  await tc('B6) التنقّل السفلي لم يتغيّر: العناصر الخمسة نفسها (الرئيسية، المعارض، السيارات، الخريطة، المفضلة) والرئيسية نشطة', async () => {
    const x = mk(null); home(x); const nav = J(x, 'NAV_ITEMS').map(i => i.key + ':' + i.label); const bn = x.E.els.bottomnav.innerHTML;
    return (JSON.stringify(nav) === JSON.stringify(['home:الرئيسية', 'showrooms:المعارض', 'cars:السيارات', 'map:الخريطة', 'favorites:المفضلة']) && /navbtn active" onclick="go\('home'\)"/.test(bn)) || { nav, bn: bn.slice(0, 120) }; });
  await tc('B7) الوصول السريع القائم محفوظ كما هو: السيارات/المعارض/الخريطة/المفضلة/سيارات الأعضاء/حسابي', async () => {
    const h = home(mk(null)); const miss = ["go('cars')", "go('showrooms')", "go('map')", "go('favorites')", "go('memberCars')", "go('login')"].filter(x => !h.includes(`onclick="${x}"`));
    return (miss.length === 0 && (h.match(/class="explore-btn"/g) || []).length === 6) || miss; });

  /* ======================= C) قسم السيارات ======================= */
  console.log('\n--- C) قسم السيارات ---');
  await tc('C1) قسم السيارات: عنوانه «أحدث السيارات» وزر «عرض الكل» بمسار السيارات القائم وaria-label، وبطاقات CarCard الحالية', async () => {
    const h = home(mk(null)); const s = section(h, 'homeCars');
    return (s.includes('id="homeCarsTitle"') && s.includes('أحدث السيارات') && /<button[^>]*onclick="go\('cars'\)"[^>]*aria-label="[^"]+"[^>]*>عرض الكل<\/button>/.test(s) && (s.match(/class="card car-card"/g) || []).length === 4) || s.slice(0, 300); });
  await tc('C2) الزائر: السيارات = أحدث 4 من المسار العام فقط (12،11،10،6: لا سيارات المعرض 3 قيد المراجعة 7–9) بترتيب الأحدث، ولا سيارات المعرض الموقوف رغم أنها الأحدث (13–15)', async () => {
    const x = mk(null); const ids = carIds(section(home(x), 'homeCars'));
    return (sameArr(ids, [12, 11, 10, 6]) /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ && !ids.some(i => i >= 13 || [7, 8, 9].includes(i))) || ids; });
  await tc('C3) الرئيسية = خدمة getHomeFeed = المسار العام: القائمة نفسها تمامًا وبنفس الترتيب', async () => {
    const x = mk(null); const ids = carIds(section(home(x), 'homeCars')); const feed = J(x, 'getHomeFeed().cars.map(c=>c.id)'); const pool = J(x, `getPublicCars('showroom').map(c=>c.id)`);
    return (x.R('typeof getHomeFeed') === 'function' && sameArr(ids, feed) && feed.every(i => pool.includes(i))) || { ids, feed }; });
  await tc('C4) المدير يرى سيارات المعرض الموقوف (الأحدث) في الرئيسية، ومالك المعرض يراها، وتاجر آخر لا', async () => {
    const a = carIds(section(home(mk('admin')), 'homeCars')), o = carIds(section(home(mk('dealer5')), 'homeCars')), other = carIds(section(home(mk('dealer1')), 'homeCars'));
    return (sameArr(a, [15, 14, 13, 12]) && sameArr(o, [15, 14, 13, 12]) && sameArr(other, [12, 11, 10, 6])) || { a, o, other }; });
  await tc('C5) إيقاف المعرض أو رفض مالكه يُخفي سياراته من الرئيسية فورًا ويعيدها بالتفعيل', async () => {
    const a = mk('admin'); a.R('AdminService.suspendShowroom(4)'); const g1 = carIds(section(home(asGuest(a)), 'homeCars'));
    a.R('AdminService.activateShowroom(4)'); a.R('rejectDealer(4)'); const g2 = carIds(section(home(asGuest(a)), 'homeCars')); a.R('approveDealer(4)'); const g3 = carIds(section(home(asGuest(a)), 'homeCars'));
    return (sameArr(g1, [6, 5, 4, 3]) && sameArr(g2, [6, 5, 4, 3]) && sameArr(g3, [12, 11, 10, 6])) || { g1, g2, g3 }; });   /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */
  await tc('C6) حالة السيارة تُحترم: المباعة تظهر بشارتها (مباعة) لا كمتاحة للبيع، وتعتيم المباعة (data-status)', async () => {
    const x = mk(null); const s = section(home(x), 'homeCars'); const card10 = (s.match(/<div class="card car-card"[^>]*data-status="sold"[\s\S]*?<\/div>\s*<\/div>/) || [''])[0];
    return (s.includes('data-status="sold"') && card10.includes('مباعة') && !card10.includes('متاحة للبيع') && s.includes('data-status="available"') && s.includes('متاحة للبيع')) || card10.slice(0, 200); });
  await tc('C7) سيارات الأعضاء: النشطة بمالك فعّال فقط (101،102،104،106)، ولا pending/sold/rejected/suspended (103،105،108،109،110)', async () => {
    const s = section(home(mk(null)), 'homeMembers'); const ids = memberIds(s);
    return (sameArr(ids, [101, 102, 104, 106]) && ![103, 105, 108, 109, 110].some(i => ids.includes(i)) && /onclick="go\('memberCars'\)"[^>]*>عرض الكل/.test(s)) || ids; });
  await tc('C8) حساب مالك العضو غير الفعّال يُخفي إعلاناته من الرئيسية، وإعادة التفعيل تعيدها (قاعدة الجزء 2 تصل للرئيسية)', async () => {
    const a = mk('admin'); setStatus(a, 7, 'suspended'); const g1 = memberIds(section(home(asGuest(a)), 'homeMembers')); setStatus(a, 7, 'active'); const g2 = memberIds(section(home(asGuest(a)), 'homeMembers'));
    return (sameArr(g1, [102, 104, 106, 107]) && sameArr(g2, [101, 102, 104, 106])) || { g1, g2 }; });
  await tc('C9) تاجر مرفوض: معرضه وإعلانه الشخصي معًا لا يظهران في الرئيسية', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); const g = home(asGuest(a)); return !carIds(section(g, 'homeCars')).some(i => [1, 2, 3].includes(i)) && !memberIds(section(g, 'homeMembers')).includes(102) && !showroomIds(section(g, 'homeShowrooms')).includes(1); });
  await tc('C10) الحد الأقصى للهاتف: 4 بطاقات سيارات و4 أعضاء حتى مع عشرات السجلات، والحدود غير الصالحة تعود للافتراضي', async () => {
    const x = mk(null); for (let i = 0; i < 20; i++) x.R(`CARS.push(CarModel({ id: ${5000 + i}, sourceType:'showroom', showroomId: 1, brand:'B', model:'M${i}', year: 2020, price: 1000, status:'available', createdAt:'2031-01-${String(i + 1).padStart(2, '0')}T00:00:00' }))`);
    for (let i = 0; i < 12; i++) x.R(`MEMBER_CARS.push(CarModel({ id: ${5100 + i}, sourceType:'member', ownerId: 7, brand:'B', model:'MM${i}', year: 2020, price: 1000, status:'active' }))`);
    const h = home(x); const cars = carIds(section(h, 'homeCars')), mem = memberIds(section(h, 'homeMembers'));
    const lens = [0, -1, NaN, "'x'", 'null', 'undefined', '2.5', '{}'].map(v => J(x, `getHomeFeed(${v}).cars.length`)); const two = J(x, 'getHomeFeed(2)'); 
    return (cars.length === 4 && mem.length === 4 && cars[0] === 5019 && lens.every(n => n === 4) && two.cars.length === 2 && two.showrooms.length === 2 && two.memberCars.length === 2) || { cars: cars.length, mem: mem.length, lens, c0: cars[0] }; });

  /* ======================= D) قسم المعارض ======================= */
  console.log('\n--- D) قسم المعارض ---');
  await tc('D1) قسم المعارض: عنوانه «معارض النجف» وزر «عرض الكل» بمسار المعارض القائم وaria-label، وبطاقات ShowroomCard الحالية', async () => {
    const h = home(mk(null)); const s = section(h, 'homeShowrooms');
    return (s.includes('id="homeShowroomsTitle"') && /<h2[^>]*>[^<]*معارض النجف<\/h2>/.test(s) && /<button[^>]*onclick="go\('showrooms'\)"[^>]*aria-label="[^"]+"[^>]*>عرض الكل<\/button>/.test(s) && (s.match(/class="card showroom-card"/g) || []).length === 3) || s.slice(0, 260); });   /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ // 1،2،4
  await tc('D2) المعارض الظاهرة فقط: الزائر 1،2،4 (3 قيد المراجعة و5 موقوف مخفيان)، والمدير 1،2،3،4 (أول أربعة)، ومعرض موقوف يُخفى عن الزائر ويظهر للمدير', async () => {
    const g = showroomIds(section(home(mk(null)), 'homeShowrooms')); const a = mk('admin'); a.R('AdminService.suspendShowroom(1)');
    const g2 = showroomIds(section(home(asGuest(a)), 'homeShowrooms')), a2 = showroomIds(section(home(a), 'homeShowrooms'));
    return (sameArr(g, [1, 2, 4]) && sameArr(g2, [2, 4]) && sameArr(a2, [1, 2, 3, 4])) || { g, g2, a2 }; });
  await tc('D3) رفض مالك المعرض يُخفيه من الرئيسية، وإعادة اعتماده تعيده', async () => {
    const a = mk('admin'); a.R('rejectDealer(2)'); const g1 = showroomIds(section(home(asGuest(a)), 'homeShowrooms')); a.R('approveDealer(2)'); const g2 = showroomIds(section(home(asGuest(a)), 'homeShowrooms'));
    return (sameArr(g1, [1, 4]) && sameArr(g2, [1, 2, 4])) || { g1, g2 }; });
  await tc('D4) الرئيسية = getHomeFeed.showrooms = searchShowrooms (نفس القائمة والترتيب) ولا تُكرَّر بطاقة المعرض يدويًا', async () => {
    const x = mk(null); const ids = showroomIds(section(home(x), 'homeShowrooms')); const feed = J(x, 'getHomeFeed().showrooms.map(s=>s.id)'); const srch = J(x, `searchShowrooms('').slice(0,4).map(s=>s.id)`);
    return (sameArr(ids, feed) && sameArr(feed, srch)) || { ids, feed, srch }; });
  await tc('D5) «عرض الكل» (معارض/سيارات/أعضاء) تفتح المسارات القائمة بقوائمها الكاملة المتسقة مع الرئيسية', async () => {
    const x = mk(null); const h = home(x); const bad = [];
    for (const [id, route, ids] of [['homeCars', 'cars', carIds], ['homeShowrooms', 'showrooms', showroomIds], ['homeMembers', 'memberCars', memberIds]]) {
      const s = section(h, id); const m = s.match(new RegExp(`onclick="(go\\('${route}'\\))"[^>]*>عرض الكل`)); if (!m) { bad.push(id); continue; }
      x.R(m[1]); const full = ids(x.E.screen()); const feedIds = ids(s); if (x.R('currentRoute') !== route || !feedIds.every(i => full.includes(i))) bad.push(id + ':route'); x.R(`go('home')`); }
    return bad.length === 0 || bad; });

  /* ======================= E) معلومات المنصة ======================= */
  console.log('\n--- E) معلومات المنصة ---');
  await tc('E1) قسم القيمة: العنوان والأسطر الأربعة المطلوبة نصًّا، في قائمة دلالية (ul/li) والأيقونات مخفية عن قارئ الشاشة', async () => {
    const h = home(mk(null)); const s = section(h, 'homeValue');
    const lines = ['تصفح سيارات المعارض في النجف', 'قارن السيارات والأسعار والمواصفات', 'اعرف بأي معرض موجودة السيارة', 'تواصل مباشرة مع المعرض'];
    return (s.length > 0 && lines.every(l => s.includes(l)) && /<ul class="value-list">/.test(s) && (s.match(/<li>/g) || []).length === 4 && /aria-hidden="true"/.test(s) && s.includes('id="homeValueTitle"')) || s.slice(0, 200); });
  await tc('E2) لا ادعاءات غير مدعومة في الرئيسية: لا «موثّق/مضمون/آمن/معتمد/أفضل سعر/ضمان» ولا ما يشبهها', async () => {
    const h = home(mk(null)); const claims = ['موثق', 'موثوق', 'موثّق', 'مضمون', 'ضمان', 'معتمد', 'آمن', 'آمنة', 'أفضل سعر', 'أفضل الأسعار', 'أرخص', 'مصدّق', 'مصدق', 'تحقق', 'احتيال', 'دفع'];
    const found = claims.filter(w => h.includes(w)); return found.length === 0 || found; });

  /* ======================= F) حالات فارغة ومحدودة ======================= */
  console.log('\n--- F) حالات فارغة ومحدودة ---');
  await tc('F1) لا سيارات: «لا توجد سيارات حاليًا» + شرح موجز في قسم السيارات، بلا زر «عرض الكل» الفارغ، وبقية الأقسام سليمة', async () => {
    const x = mk(null, emptyStore()); const h = home(x); const s = section(h, 'homeCars'); const m = section(h, 'homeMembers');
    return (s.includes('لا توجد سيارات حاليًا') && s.includes('class="sub"') && !s.includes('عرض الكل') && !s.includes('card car-card') && m.includes('لا توجد سيارات أعضاء نشطة بعد') && !h.includes(ERR) && !BAD.test(h) && section(h, 'homeShowrooms').includes('showroom-card')) || s; });
  await tc('F2) لا معارض: «لا توجد معارض» + شرح موجز بنمط الحالة الفارغة الموحّد، بلا «عرض الكل»، وسيارات هذه المعارض (مخفية) لا تظهر', async () => {
    const x = mk(null); x.R('SHOWROOMS.splice(0, SHOWROOMS.length)'); const h = home(x); const s = section(h, 'homeShowrooms');
    return (s.includes('لا توجد معارض') && s.includes('class="sub"') && !s.includes('عرض الكل') && !s.includes('showroom-card') && section(h, 'homeCars').includes('لا توجد سيارات حاليًا') && !h.includes(ERR) && !BAD.test(h)) || s; });
  await tc('F3) سيارة واحدة ومعرض واحد فقط: بطاقة واحدة لكل قسم بلا انهيار ولا فراغات غريبة', async () => {
    const a = mk('admin'); [1, 2, 3].forEach(id => a.R(`AdminService.suspendShowroom(${id})`)); const x = asGuest(a);   // يبقى المعرض 4 وحده ظاهرًا (5 موقوف أصلًا)
    x.R(`CARS.splice(0, CARS.length, ...CARS.filter(c => c.id === 11))`); x.R(`MEMBER_CARS.splice(0, MEMBER_CARS.length, ...MEMBER_CARS.filter(c => c.id === 101))`);
    const h = home(x); return (sameArr(carIds(section(h, 'homeCars')), [11]) && sameArr(showroomIds(section(h, 'homeShowrooms')), [4]) && sameArr(memberIds(section(h, 'homeMembers')), [101]) && !h.includes(ERR) && !BAD.test(h)) || h.length; });
  await tc('F4) بيانات ناقصة (بلا صورة/سعر/سنة/مسافة، معرض بلا عنوان أو معلومات): الرئيسية سليمة بلا undefined/null/NaN/[object]', async () => {
    const x = mk(null); x.R(`CARS.push(CarModel({ id: 7001, sourceType:'showroom', showroomId: 77, brand:'Bare', model:'Minimal', status:'available', createdAt:'2032-01-01T00:00:00' }))`);
    x.R(`SHOWROOMS.push(ShowroomModel({ id: 77, name: 'Bare Showroom', status: 'active', ownerId: 1 }))`); x.R(`MEMBER_CARS.push(CarModel({ id: 7002, sourceType:'member', ownerId: 7, brand:'Bare', model:'Member', status:'active' }))`);
    x.R(`CAR_IMAGES.push({ id: 7003, carId: 7001, imageUrl: 42, sortOrder: 0, isMain: true })`); const h = home(x);
    return (h.includes('Bare Minimal') && h.includes('Bare Showroom') && h.includes('السعر غير محدد') && !h.includes(ERR) && !BAD.test(h) && !h.includes('—')) || { err: h.includes(ERR), bad: (h.match(BAD) || [])[0] }; });
  await tc('F5) أسماء طويلة جدًا (معرض وسيارة وعضو): تُعرض بلا انهيار والـCSS يكسر النص الطويل في بطاقات الرئيسية', async () => {
    const L = 'ط'.repeat(180); const x = mk(null);
    x.R(`SHOWROOMS.push(ShowroomModel({ id: 78, name: ${JSON.stringify(L)}, address: ${JSON.stringify(L)}, status: 'active', ownerId: 1 }))`); x.R(`CARS.push(CarModel({ id: 7010, sourceType:'showroom', showroomId: 78, brand: ${JSON.stringify(L)}, model: ${JSON.stringify(L)}, year: 2020, price: 1000, status:'available', createdAt:'2033-01-01T00:00:00' }))`);
    const h = home(x); const css = read('theme/theme.css');
    return (h.includes(L) && !h.includes(ERR) && /\.card-title,\.card-row[^{]*\{[^}]*overflow-wrap:\s*anywhere/.test(css) && /\.card-body[^{]*\{[^}]*min-width:\s*0/.test(css)) || h.length; });
  await tc('F6) سجل واحد معطوب (يرمي عند القراءة) لا يُسقط الرئيسية: تُعرض بقية البطاقات والأقسام', async () => {
    const x = mk(null); x.R(`CARS.push(Object.defineProperty(CarModel({ id: 7020, sourceType:'showroom', showroomId: 1, brand:'Poison', model:'Card', year: 2020, price: 1000, status:'available', createdAt:'2034-01-01T00:00:00' }), 'price', { get() { throw new Error('boom'); } }))`);
    const orig = x.E.ctx.console.error; x.E.ctx.console.error = () => {}; const h = home(x); x.E.ctx.console.error = orig;
    return (!h.includes(ERR) && section(h, 'homeCars').includes('card car-card') && section(h, 'homeShowrooms').includes('showroom-card') && section(h, 'homeValue').length > 0) || h.length; });
  await tc('F7) نصوص ضارة (HTML) في أسماء السيارة والمعرض والموقع تظهر نصًا في الرئيسية', async () => {
    const PAY = '<img src=x onerror=alert(1)>'; const x = mk(null);
    x.R(`SHOWROOMS.push(ShowroomModel({ id: 79, name: ${JSON.stringify(PAY)}, address: ${JSON.stringify(PAY)}, status:'active', ownerId: 1 }))`); x.R(`CARS.push(CarModel({ id: 7030, sourceType:'showroom', showroomId: 79, brand: ${JSON.stringify(PAY)}, model: ${JSON.stringify(PAY)}, year: 2020, price: 1000, status:'available', createdAt:'2035-01-01T00:00:00' }))`);
    x.R(`MEMBER_CARS.push(CarModel({ id: 7031, sourceType:'member', ownerId: 7, brand: ${JSON.stringify(PAY)}, model:'X', location: ${JSON.stringify(PAY)}, year: 2020, price: 1000, status:'active' }))`);
    x.R(`MEMBER_CARS.unshift(MEMBER_CARS.pop())`); const h = home(x); return !h.includes('<img src=x') && h.includes('&lt;img'); });
  await tc('F8) كل السيارات مباعة أو مخفية: الرئيسية سليمة (تعرض المباعة بشارتها، أو الحالة الفارغة)', async () => {
    const a = mk('admin'); J(a, 'getCars().map(c=>c.id)').forEach(id => a.R(`AdminService.setShowroomCarStatus(${id}, 'sold')`)); const g = asGuest(a); const h = home(g);
    const e = mk(null, emptyStore()); const eh = home(e);
    return (!h.includes(ERR) && !BAD.test(h) && section(h, 'homeCars').includes('مباعة') && !section(h, 'homeCars').includes('متاحة للبيع') && !eh.includes(ERR)) || h.length; });

  /* ======================= G) لا تكرار لمنطق الظهور/الفلترة ======================= */
  console.log('\n--- G) لا تكرار للمنطق ---');
  const homeSrc = strip(read('screens/home.js'));
  await tc('G1) home.js بلا جالبات خام ولا قاعدة ظهور/حالة/مالك ولا فلترة أو فرز: كله عبر getHomeFeed', async () => {
    const bad = []; const chk = (re, name) => { if (re.test(homeSrc)) bad.push(name); };
    chk(/\b(getCars|getShowrooms|getActiveMemberCars|getMemberCars|getPendingMemberCars|getCarsByShowroom|getShowroomById|getCarById|getMemberCarById)\s*\(/, 'raw'); chk(/USER_STATUS|UsersRepository|ownerId|CAR_SOURCE|MEMBER_CAR_STATUS/, 'rule');
    chk(/\.status\b|'suspended'|'active'|'available'|canView|canManage/, 'status'); chk(/\.(filter|sort|find|reduce)\s*\(/, 'array-logic'); chk(/CarFilters|applyCarFilters|searchCars\s*\(|searchShowrooms\s*\(/, 'engine');
    return bad.length === 0 || bad; });
  await tc('G2) getHomeFeed معرَّفة مرة واحدة في searchService.js وتعتمد searchCars/searchShowrooms فقط (بلا جلب خام ولا قاعدة ظهور)', async () => {
    const defs = fs.readdirSync(path.join(ROOT, 'services')).filter(f => f.endsWith('.js') && /function\s+getHomeFeed\s*\(/.test(read('services/' + f)));
    const src = strip(read('services/searchService.js')); const body = (src.match(/function getHomeFeed\s*\([\s\S]*?\n}\n/) || [''])[0];
    return (defs.length === 1 && defs[0] === 'searchService.js' && /searchCars\(/.test(body) && /searchShowrooms\(/.test(body) && !/\b(getCars|getShowrooms|getActiveMemberCars|getMemberCars|getCarById|canView|USER_STATUS|UsersRepository|ownerId)\b/.test(body)) || { defs, body: body.slice(0, 120) }; });
  await tc('G3) HomeScreen يعيد استخدام المكوّنات القائمة: CarCard وShowroomCard وEmptyState وAdSlot وSearchBox وAccountButton، ولا يبني بطاقة يدويًا', async () => {
    const need = ['CarCard', 'ShowroomCard', 'EmptyState', 'AdSlot', 'SearchBox', 'AccountButton', 'getHomeFeed']; const miss = need.filter(n => !new RegExp(`\\b${n}\\b`).test(homeSrc));
    return (miss.length === 0 && !/card car-card|card showroom-card|showroom-card|car-card/.test(homeSrc)) || miss; });
  await tc('G4) لا خدمات/مستودعات جديدة للرئيسية: لا ملف باسم home/discover/feed، ونظام ظهور واحد ومحرك فلترة واحد', async () => {
    const files = ['services', 'repositories'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).map(f => d + '/' + f)).filter(f => /home|discover|feed|landing/i.test(f));
    const count = (re) => fs.readdirSync(path.join(ROOT, 'services')).filter(f => f.endsWith('.js') && re.test(read('services/' + f))).length;
    return (files.length === 0 && count(/const\s+VisibilityService\s*=/) === 1 && count(/const\s+CarFilters\s*=/) === 1) || files; });
  await tc('G5) لا تغيير على الظهور والفلاتر: visibilityService/carFilterService لا يحويان أي إشارة للرئيسية', async () => !/home/i.test(strip(read('services/visibilityService.js'))) && !/home/i.test(strip(read('services/carFilterService.js'))));

  /* ======================= H) الإعلانات ======================= */
  console.log('\n--- H) الإعلانات ---');
  await tc('H1) مساحة الإعلان القائمة محفوظة بلا تغيير: home_banner واحدة بمخرج AdSlot نفسه، وبعد الوصول السريع وقبل السيارات، ولا مساحات جديدة', async () => {
    const x = mk(null); const h = home(x); const ad = x.R(`AdSlot('home_banner')`); const slots = h.match(/data-ad-slot="[^"]+"/g) || [];
    return (h.includes(ad) && slots.length === 1 && slots[0] === 'data-ad-slot="home_banner"' && h.indexOf('homeQuickTitle') < h.indexOf(ad) && h.indexOf(ad) < h.indexOf('id="homeCars"')) || slots; });
  await tc('H2) AdSlot ومكوّناته لم تتغيّر: المخرج الحرفي القديم، والمساحة مخفية بـ CSS (display:none) ولا منطق إعلاني في الرئيسية', async () => {
    const x = mk(null); const css = read('theme/theme.css');
    return x.R(`AdSlot('x')`) === '<div class="ad-slot" data-ad-slot="x">مساحة إعلان (x)</div>' && x.R(`AdSlot('y', true)`) === '<div class="ad-slot inline" data-ad-slot="y">مساحة إعلان (y)</div>' && /\.ad-slot\{\s*display:none/.test(css) && !/reward|admob|interstitial/i.test(homeSrc); });

  /* ======================= I) إمكانية الوصول والتصميم ======================= */
  console.log('\n--- I) إمكانية الوصول والتصميم ---');
  const css = read('theme/theme.css'); const block = css.slice(css.indexOf('/* ---- المرحلة 10 / الجزء 4'));
  await tc('I1) كل قسم له aria-labelledby يشير لعنوان موجود فعلًا، والعناوين h2 متسلسلة تحت h1 واحد', async () => {
    const h = home(mk(null)); const refs = [...h.matchAll(/aria-labelledby="([^"]+)"/g)].map(m => m[1]); const missing = refs.filter(id => !new RegExp(`id="${id}"`).test(h));
    return (refs.length >= 5 && missing.length === 0 && (h.match(/<h1\b/g) || []).length === 1 && !/<h3\b/.test(h)) || { refs, missing }; });
  await tc('I2) كل زر وروابط الرئيسية (4 «عرض الكل» بعد قسم المضافة حديثًا) باسم وصول واضح (نص ظاهر أو aria-label)، وأزرار الإجراءات type="button"', async () => {
    const h = home(mk(null)); const empty = buttonsOf(h).filter(b => !b.text && !/aria-label="[^"]+"/.test(b.attrs)); const links = (h.match(/>عرض الكل<\/button>/g) || []).length;
    return (empty.length === 0 && links === 4 && buttonsOf(h).filter(b => /home-action/.test(b.attrs)).every(b => b.attrs.includes('type="button"'))) || empty; });
  await tc('I3) CSS الجزء 4: أهداف لمس ≥ 44px للإجراءات، تركيز مرئي (focus-visible)، كسر نص طويل، بلا حركات/انتقالات', async () => {
    const mh = block.match(/\.home-action\{[^}]*min-height:\s*(\d+)px/); const mhv = mh ? Number(mh[1]) : 0;
    return (block.length > 200 && mhv >= 44 && /:focus-visible/.test(block) && /overflow-wrap:\s*anywhere/.test(block) && !/@keyframes|animation|transition/.test(block)) || { mhv, len: block.length }; });
  await tc('I4) CSS: خطوط ≥ 12px، بلا left/right ثابتة (خصائص منطقية)، بلا متغيرات :root جديدة ولا ألوان خارج التصميم', async () => {
    const sizes = [...block.matchAll(/font-size:\s*([\d.]+)px/g)].map(m => Number(m[1])); const root = (css.match(/:root\{([\s\S]*?)\}/) || [])[1] || ''; const vars = [...root.matchAll(/--([a-z-]+):/g)].length;
    return (sizes.length > 0 && sizes.every(s => s >= 12) && !/margin-left|margin-right|padding-left|padding-right|text-align:\s*(left|right)|(^|[;{\s])(left|right)\s*:/.test(block) && vars === 11 && !/--[a-z-]+\s*:/.test(block)) || { sizes, vars }; });
  await tc('I5) لا تمرير أفقي للصفحة: الأقسام بحشوة قائمة، والتمرير الأفقي داخل hscroll فقط، وعناصر الإجراءات بعرض 100% وmin-width:0', async () => {
    return /\.hscroll\{[^}]*overflow-x:auto/.test(css) && /\.home-action\{[^}]*width:100%/.test(block) && /min-width:\s*0/.test(block) && !/width:\s*\d{3,}px/.test(block.replace(/\.home-action[^{]*\{[^}]*\}/g, m => m)) ; });
  await tc('I6) اتجاه RTL: الصفحة dir=rtl وviewport، ولا عنصر في الرئيسية يفرض dir=ltr', async () => {
    const html = read('index.html'); const h = home(mk(null)); return /dir="rtl"/.test(html) && /name="viewport"/.test(html) && !/dir="ltr"/.test(h); });
  await tc('I7) التصميم: الأزرار الجديدة تستخدم ألوان --navy/--white/الحدود القائمة، وتتبّع radius القائم (var(--radius))', async () => {
    const act = (block.match(/\.home-action\{[^}]*\}/) || [''])[0]; return /var\(--radius\)/.test(act) && /var\(--navy\)/.test(block) && !/#[0-9a-fA-F]{3,6}/.test(block.replace(/#fff\b/gi, '')); });

  await tc('I8) التباين (WCAG AA ≥ 4.5 للنص العادي) محسوب من قيم المتغيرات الفعلية: عناصر الرئيسية الجديدة كلها فوق 4.5 على خلفياتها', async () => {
    const css = read('theme/theme.css'); const root = (css.match(/:root\{([\s\S]*?)\}/) || [])[1] || '';
    const V = {}; [...root.matchAll(/--([a-z-]+):\s*(#[0-9A-Fa-f]{6})/g)].forEach(m => { V[m[1]] = m[2]; });
    const hex = s => { let c = s.startsWith('var(') ? V[s.slice(6, -1)] : s; c = c.replace('#', ''); if (c.length === 3) c = c.split('').map(d => d + d).join(''); const n = parseInt(c, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
    const L = ([r, g, b]) => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
    const ratio = (a, b) => { const x = L(hex(a)), y = L(hex(b)); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
    const prop = (sel, p) => { const m = css.slice(css.indexOf('/* ---- المرحلة 10 / الجزء 4')).match(new RegExp(sel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\{(?:[^}]*?[;\\s])?' + p + ':\\s*([^;}]+)')); return m ? m[1].trim() : null; };
    const pairs = { 'hero.lead': [prop('.home-lead', 'color'), 'var(--gray-bg)'], 'hero.brand': [prop('.home-brand', 'color'), 'var(--gray-bg)'],
      'action.primary': ['#fff', prop('.home-action.primary', 'background')], 'action': [prop('.home-action', 'color'), prop('.home-action', 'background')] };
    const out = {}; for (const [k, [fg, bg]] of Object.entries(pairs)) { const f = fg && fg.replace(/\s*\/\*.*$/, ''), b = bg && bg.replace(/\s*\/\*.*$/, ''); out[k] = (f && b && (V[f.slice(6, -1)] || f.startsWith('#')) && (V[b.slice(6, -1)] || b.startsWith('#'))) ? Math.round(ratio(f, b) * 100) / 100 : null; }
    return (Object.values(out).every(v => v !== null && v >= 4.5)) || out; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

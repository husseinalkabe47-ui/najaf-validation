/* اختبارات تحصين واجهة خدمة سيارات الأعضاء (تفويض عند حدّ الخدمة — دفاع متعدد الطبقات إضافةً إلى حارس الراوتر).
   كان getMemberCars() يعيد كل السجلات (60 في البذرة الكاملة بما فيها pending/rejected/suspended وهواتف/أسباب رفض) لأي مستدعٍ حتى الزائر،
   وكذلك getMemberCarsByOwner(ownerId) لأي ownerId. القاعدة الآن (تعيد استخدام AuthorizationService/SessionService، بلا نظام ثانٍ):
     • مدير فعّال  ← كل السجلات      • أي مستخدم مسجّل آخر (عضو/تاجر) ← السجلات التي تجيزها canManageMemberCar له = إعلاناته هو فقط
     • زائر/جلسة منتهية أو مفقودة أو تالفة/حساب موقوف/مدير غير فعّال ← لا شيء
   الهوية من الجلسة فقط (لا معامل مقبول)، والدور يُقرأ من السجل الحقيقي في كل استدعاء. العرض العام لا يمر من هنا (visibilityService يقرأ المستودع).
   كل الاختبارات تستدعي الخدمة مباشرةً: دخول بـ SessionService.login(id) دون أي go() — أي بلا راوتر ولا شاشات (إلا فحوص الشاشات الصريحة). */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const ID = { admin: 6, user: 7, dealer1: 1, dealer2: 2 };           // معرّفات المستخدمين التجريبية (7 عضو، 1 و2 تاجران، 6 مدير)
/** بيئة بلا راوتر: دخول مباشر بمعرّف مستخدم (أو زائر) */
function mk(who, store, level) {
  const E = makeEnv(store, { fullSeed: level === undefined ? 'p3' : level }), R = c => E.run(c);
  R('SessionService.logout()'); if (who) R(`SessionService.login(${ID[who] || who})`);
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const ERR = 'حدث خطأ، حاول مرة أخرى';
const idsOn = (html, re) => [...new Set([...String(html).matchAll(re)].map(m => Number(m[1])))];
const memberCardIds = html => idsOn(html, /go\('memberCarDetails',\s*(\d+)\)/g);
const adminCardIds = html => idsOn(html, /go\('adminMemberCarDetails',\s*(\d+)\)/g);

(async () => {
  const ref = mk(null); const ALL = ref.J('MemberCarsRepository.getAll()'); const allIds = ALL.map(c => c.id);
  const ownedBy = id => ALL.filter(c => c.ownerId === id).map(c => c.id);
  const PUBLIC = ALL.filter(c => c.status === 'active').map(c => c.id);   // مرجع مستقل من المستودع (كل الملّاك فعّالون في البذرة): العام = النشط فقط

  /* ======================= A) العقد لكل دور (المباشر بلا راوتر) ======================= */
  console.log('\n--- A) العقد لكل دور ---');
  await tc('A0) الأساس: البذرة الكاملة 60 إعلان عضو بحالات متنوعة (فيها غير عامة)، والعام 51 — الأرقام كلها مشتقة من المستودع لا ثابتة', async () =>
    (ALL.length === 60 && ALL.some(c => c.status === 'pending') && ALL.some(c => c.status === 'rejected') && ALL.some(c => c.status === 'suspended') && PUBLIC.length === 51 && same(ref.J('getVisibleMemberCars().map(c=>c.id)'), PUBLIC) && same(allIds, ref.J('MemberCarsRepository.getAll().map(c=>c.id)'))) || { n: ALL.length, pub: PUBLIC.length });
  await tc('A1) الزائر: getMemberCars() = [] و getMemberCarsByOwner(أي مالك) = []، وJSON الناتج لا يحوي أي حقل حساس (هاتف/واتساب/سبب رفض)', async () => {
    const g = mk(null); const a = g.J('getMemberCars()'), svc = g.J('MemberCarsService.getMemberCars()'); const owners = [...new Set(ALL.map(c => c.ownerId))];
    const bad = owners.filter(o => g.J(`getMemberCarsByOwner(${o})`).length !== 0);
    const dump = JSON.stringify([a, svc, owners.map(o => g.J(`getMemberCarsByOwner(${o})`))]);
    return (Array.isArray(a) && a.length === 0 && svc.length === 0 && bad.length === 0 && !/phone|whatsapp|rejectionReason|suspensionReason|ownerId/.test(dump)) || { a: a.length, bad }; });
  await tc('A2) العضو (7): getMemberCars() = إعلاناته هو فقط (ما يحق له إدارته) بما فيها غير العامة (pending/sold)، لا إعلان واحد لغيره؛ وgetMemberCarsByOwner لمالك آخر = []', async () => {
    const u = mk('user'); const mine = ownedBy(7), got = u.J('getMemberCars().map(c=>c.id)');
    const nonPublicOwn = mine.filter(i => !PUBLIC.includes(i));
    return (same(got, mine) && mine.length >= 4 && nonPublicOwn.length >= 2 && same(u.J('getMemberCarsByOwner(7).map(c=>c.id)'), mine) && [1, 2, 3, 4, 5].every(o => u.J(`getMemberCarsByOwner(${o})`).length === 0) && got.length < allIds.length) || { got: got.length, mine: mine.length }; });
  await tc('A3) التاجر (1): لا يحصل على كل إعلانات الأعضاء — إعلاناته الشخصية فقط (صلاحية معرضه لا تمنحه شيئًا هنا)، ولا يرى إعلانات العضو 7 ولا تاجر آخر', async () => {
    const d = mk('dealer1'); const mine = ownedBy(1), got = d.J('getMemberCars().map(c=>c.id)');
    return (same(got, mine) && mine.length >= 4 && got.length < allIds.length && got.every(i => !ownedBy(7).includes(i) && !ownedBy(2).includes(i)) && d.J('getMemberCarsByOwner(7)').length === 0 && d.J('getMemberCarsByOwner(2)').length === 0 && same(d.J('getMemberCarsByOwner(1).map(c=>c.id)'), mine)) || { got: got.length, mine: mine.length }; });
  await tc('A4) المدير: getMemberCars() = كل السجلات (60) بكل الحالات، وgetMemberCarsByOwner(أي مالك) = كل إعلانات ذلك المالك (بما فيها pending/rejected/suspended)', async () => {
    const a = mk('admin'); const got = a.J('getMemberCars().map(c=>c.id)'); const owners = [...new Set(ALL.map(c => c.ownerId))];
    const bad = owners.filter(o => !same(a.J(`getMemberCarsByOwner(${o}).map(c=>c.id)`), ownedBy(o)));
    return (same(got, allIds) && got.length === 60 && bad.length === 0) || { n: got.length, bad }; });
  await tc('A5) لا كشف للمجموعة الكاملة لغير المدير: لا يستطيع أي غير مدير إعادة بناء المجموعة بحلقة على المالكين أو بمرور على المعرّفات عبر الدوال المحروسة (الاتحاد عبر كل الأدوار غير المدير = إعلانات كل منهم فقط)', async () => {
    const seen = new Set(); for (const who of [null, 'user', 'dealer1', 'dealer2', 3, 4, 5]) { const x = mk(who); x.J('getMemberCars().map(c=>c.id)').forEach(i => { if (!ownedBy(typeof who === 'number' ? who : ID[who] || -1).includes(i)) seen.add('foreign:' + i); }); for (const o of [1, 2, 3, 4, 5, 6, 7]) x.J(`getMemberCarsByOwner(${o}).map(c=>c.id)`).forEach(i => { if (!ownedBy(typeof who === 'number' ? who : ID[who] || -1).includes(i)) seen.add('foreign:' + i); }); }
    return seen.size === 0 || [...seen].slice(0, 5); });
  await tc('A6) النتيجة لغير المدير نسخة مستقلة: تعديل المصفوفة المُعادة (push/splice) لا يغيّر المستودع', async () => {
    const u = mk('user'); const n0 = u.J('MemberCarsRepository.getAll().length'); u.R('(function(){ const a = getMemberCars(); a.splice(0, a.length); a.push({ id: 999999 }); })()');
    return (u.J('MemberCarsRepository.getAll().length') === n0 && u.J('MemberCarsRepository.getById(999999)') === null && u.J('getMemberCars().length') === ownedBy(7).length) || 'live array'; });

  /* ======================= B) العرض العام لا يتأثر ======================= */
  console.log('\n--- B) العرض العام ---');
  for (const who of [null, 'user', 'dealer1', 'admin']) {
    await tc(`B1[${who || 'guest'}]) المسار العام يعمل كما كان: getVisibleMemberCars/getPublicCars/searchCars/filterMemberCars = الإعلانات العامة (${PUBLIC.length}) بغض النظر عن الدور، وشاشة الأعضاء تعرضها كلها بلا «${ERR}»`, async () => {
      const x = mk(who); x.R(`go('memberCars')`); const scr = x.E.screen();
      const sets = [x.J('getVisibleMemberCars().map(c=>c.id)'), x.J(`getPublicCars('member').map(c=>c.id)`), x.J(`searchCars('', 'member').map(c=>c.id)`), x.J('filterMemberCars({}).map(c=>c.id)')];
      return (sets.every(s => same(s, PUBLIC)) && same(memberCardIds(scr), PUBLIC) && !scr.includes(ERR) && x.E.errors.length === 0) || { sets: sets.map(s => s.length), cards: memberCardIds(scr).length }; });
  }
  await tc('B2) تفاصيل إعلان عام تفتح للزائر (101) وإعلان غير عام (103 pending) مخفي عنه، والمفضلة والبحث والرئيسية تعمل (بلا أخطاء)', async () => {
    const g = mk(null); g.R(`go('memberCarDetails',101)`); const ok = g.E.screen().includes('Corolla') && !g.E.screen().includes(ERR); g.R(`go('memberCarDetails',103)`); const hidden = !g.E.screen().includes('handleFavoriteToggle(103)');
    g.R(`go('home')`); const home = !g.E.screen().includes(ERR); g.R(`go('search','toyota')`); const sr = !g.E.screen().includes(ERR) && memberCardIds(g.E.screen()).every(i => PUBLIC.includes(i));
    return (ok && hidden && home && sr && g.R('getVisibleCarById(103)') === undefined && g.J('getMemberCarAccess(103).status') === 'hidden') || { ok, hidden, home, sr }; });
  await tc('B3) الإعلان العام المضاف يظهر للعامة فورًا بعد النشر (مسار المكافأة سليم) وللمالك في getMemberCars()، وبلا ظهور لغير المالك في getMemberCars()', async () => {
    const store = {}; const u = mk('user', store); const d = u.J(`createDraftMemberCar(${JSON.stringify({ brand: 'Honda', model: 'Jazz', year: '2018', price: '9000000', phone: '07700000099', currency: 'IQD' })})`);
    u.R(`RewardService.requestPublishReward('${d.draftId}')`); u.R(`RewardService.onRewardCompleted('${d.draftId}')`); const p = u.J(`publishMemberCarAfterReward('${d.draftId}')`);
    const ownerSees = u.J('getMemberCars().map(c=>c.id)').includes(p.car.id);                       // الجلسة مشتركة عبر الـstore: يُقاس كل دور مباشرةً بعد دخوله
    const g = mk(null, store); const guestPublic = g.J('getVisibleMemberCars().map(c=>c.id)').includes(p.car.id), guestRaw = g.J('getMemberCars().length');
    const o = mk('dealer1', store); const dealerSees = o.J('getMemberCars().map(c=>c.id)').includes(p.car.id);
    return (p.ok && p.car.status === 'active' && ownerSees && guestPublic && guestRaw === 0 && !dealerSees) || { p: p.ok, ownerSees, guestPublic, guestRaw, dealerSees }; });

  /* ======================= C) إدارة المالك ما زالت تعمل ======================= */
  console.log('\n--- C) تدفقات المالك والمدير ---');
  await tc('C1) «إعلاناتي» للعضو: الشاشة تعرض إعلاناته كلها (المحروسة تعمل للمالك)، لا إعلان غيره، وبلا خطأ', async () => {
    const u = mk('user'); u.R(`go('myMemberCars')`); const scr = u.E.screen(); const mine = ownedBy(7);
    const ids = idsOn(scr, /(?:memberCarDetails|editMemberCar|handleDeleteMemberCar|handleMemberCarStatusChange)(?:'|\()\s*,?\s*(\d+)/g);
    return (!scr.includes(ERR) && mine.every(i => ids.includes(i)) && ids.every(i => mine.includes(i)) && scr.includes('Corolla')) || { ids: ids.length, mine: mine.length }; });
  await tc('C2) تعديل/تغيير حالة/حذف إعلان المالك يعمل (الصلاحية الفعلية لم تتغير)، ولا يعمل لإعلان غيره (ولا يظهر له أصلًا)', async () => {
    const u = mk('user'); const up = u.J(`updateMemberCar(101,{price:'16,500,000'})`), st = u.J(`changeMemberCarStatus(101,'sold')`), st2 = u.J(`changeMemberCarStatus(101,'active')`);
    const other = ownedBy(2)[0]; const bad = u.J(`updateMemberCar(${other},{price:'1'})`).ok || u.J(`deleteMemberCar(${other})`).ok || u.J(`changeMemberCarStatus(${other},'sold')`).ok;
    const del = u.J('deleteMemberCar(105)');
    return (up.ok && st.ok && st2.ok && !bad && del.ok && !u.J('getMemberCars().map(c=>c.id)').includes(105) && u.J('MemberCarsRepository.getById(105)') === null && u.J('getMemberCars().length') === ownedBy(7).length - 1) || { up: up.ok, st: st.ok, bad, del: del.ok }; });
  await tc('C3) التاجر يدير إعلاناته الشخصية كالعضو ولا يديرها لغيره، ومعرضه وسيارات المعرض لم تتأثر (getMyShowroomCars وgetCars كما هي)', async () => {
    const d = mk('dealer1'); const mine = ownedBy(1)[0], other = ownedBy(7)[0];
    return (d.J(`updateMemberCar(${mine},{color:'x'})`).ok && !d.J(`updateMemberCar(${other},{color:'x'})`).ok && d.J('getMyShowroomCars().length') === ref.J('getCars().filter(c=>c.showroomId===1).length') && d.J('getCars().length') === 91) || 'dealer'; });
  await tc('C4) شاشة إدارة الأعضاء للمدير تعرض كل الـ60 (بكل التبويبات)، وتبويب الحالة يطابق السجلات، والموافقة/الرفض/الإيقاف/الاستعادة تعمل (الإحصاءات الإدارية كما كانت)', async () => {
    const a = mk('admin'); a.R(`go('adminMemberCars')`); const all = adminCardIds(a.E.screen()); const stats = a.J('getDashboardStats()');
    const act = [a.J('approveMemberCar(103)').ok, a.J(`rejectMemberCar(108,'x')`).ok, a.J(`suspendMemberCarAdmin(102,'x')`).ok, a.J('restoreMemberCar(102)').ok];
    a.R(`go('adminMemberCars','pending')`); const pend = adminCardIds(a.E.screen());
    return (same(all, allIds) && stats.totalMemberCars === 60 && stats.pendingMemberCars === 2 && act.every(Boolean) && same(pend, [102]) && !a.E.screen().includes(ERR)) || { all: all.length, act, pend }; });
  await tc('C5) صفحة تفاصيل المستخدم الإدارية تعرض للمدير كل إعلانات المالك (صفوفها = عدد إعلاناته)، ولغير المدير لا صفوف ولا وصول (حارس الراوتر) فلا تسرّب إعلانات مالك', async () => {
    const a = mk('admin'); a.R(`go('adminUserDetails',2)`); const adm = a.E.screen(); const g = mk(null); g.R(`go('adminUserDetails',2)`); const gs = g.E.screen(); const u = mk('user'); u.R(`go('adminUserDetails',2)`);
    const own2 = ownedBy(2); const rows = h => (String(h).match(/class="ad-row"/g) || []).length;
    return (!adm.includes(ERR) && rows(adm) === own2.length && own2.length >= 4 && rows(gs) === 0 && rows(u.E.screen()) === 0 && g.R('currentRoute') !== 'adminUserDetails' && u.R('currentRoute') !== 'adminUserDetails') || { adm: rows(adm), own2: own2.length, g: rows(gs), u: rows(u.E.screen()) }; });

  /* ======================= D) حالات عدائية ======================= */
  console.log('\n--- D) حالات عدائية ---');
  const FAR = Date.now() + 86400000;
  await tc('D1) جلسة منتهية (مدير بجلسة expiresAt ماضٍ): [] وتُمسح الجلسة؛ جلسة مفقودة: []؛ جلسة تالفة (نص/معرّف غير رقمي/كائن بلا userId): []', async () => {
    const out = {};
    const e = mk(null); e.E.store['najaf.session'] = JSON.stringify({ userId: 6, createdAt: 1, expiresAt: Date.now() - 1000 }); out.expired = [e.J('getMemberCars().length'), e.J('getMemberCarsByOwner(7).length'), e.E.store['najaf.session'] === undefined];
    const m = mk(null); out.missing = [m.J('getMemberCars().length')];
    out.corrupt = ['"oops"', '{"userId":"6"}', '{"userId":null}', '{"foo":1}', '[6]', 'not json'].map(s => { const x = mk(null); x.E.store['najaf.session'] = s; return x.J('getMemberCars().length'); });
    return (out.expired[0] === 0 && out.expired[1] === 0 && out.expired[2] === true && out.missing[0] === 0 && out.corrupt.every(n => n === 0)) || out; });
  await tc('D2) دور/حالة غير صالحة: مدير حالته pending لا يحصل على الكل؛ مدير موقوف = زائر؛ مستخدم بدور مجهول (superuser/admin ' + "'ADMIN'" + '/فارغ/كائن) لا يحصل على الكل أبدًا (على الأكثر إعلاناته)', async () => {
    const out = {}; const total = allIds.length;
    const p = mk('admin'); p.R(`UsersRepository.update(6, { status: 'pending' })`); out.pendingAdmin = [p.R('AuthorizationService.canAccessAdmin()'), p.J('getMemberCars().length') < total];
    const s = mk('admin'); s.R(`UsersRepository.update(6, { status: 'suspended' })`); out.suspAdmin = [s.R('SessionService.isLoggedIn()'), s.J('getMemberCars().length')];
    out.roles = ['superuser', 'ADMIN', ' admin ', '', 'root', 'admin\u0000'].map(r => { const x = mk('user'); x.R(`UsersRepository.update(7, { role: ${JSON.stringify(r)} })`); return [x.R('SessionService.getCurrentUser().role') === r, x.R('AuthorizationService.canAccessAdmin()'), x.J('getMemberCars().length') < total, x.J('getMemberCars().every(c => c.ownerId === 7)')]; });
    return (out.pendingAdmin[0] === false && out.pendingAdmin[1] && out.suspAdmin[0] === false && out.suspAdmin[1] === 0 && out.roles.every(r => r[0] && r[1] === false && r[2] && r[3])) || out; });
  await tc('D3) كائن مزوَّر: تمرير دور/مستخدم/معرّف للدالتين لا يغيّر شيئًا (المعاملات الزائدة تُهمَل): زائر يمرّر {role:admin} أو {id:6} أو true أو معرّف المدير، وعضو يمرّر معرّف مدير', async () => {
    const forged = ["{ role: 'admin' }", '{ id: 6, role: "admin", status: "active" }', 'true', '6', '"admin"', '{ user: { role: "admin" } }', '[6]'];
    const g = mk(null), u = mk('user'); const bad = [];
    forged.forEach(f => { if (g.J(`getMemberCars(${f})`).length !== 0 || g.J(`MemberCarsService.getMemberCars(${f})`).length !== 0 || g.J(`getMemberCarsByOwner(7, ${f})`).length !== 0 || g.J(`getMemberCarsByOwner(${f})`).length !== 0) bad.push('guest:' + f); if (!same(u.J(`getMemberCars(${f}).map(c=>c.id)`), ownedBy(7)) || u.J(`getMemberCarsByOwner(2, ${f})`).length !== 0) bad.push('user:' + f); });
    return bad.length === 0 || bad; });
  await tc('D4) جلسة مزوَّرة الحقول: session = { userId: 7, role: "admin", isAdmin: true } لا تمنح شيئًا (الدور يُقرأ من سجل المستخدم)، وجلسة المدير المنتهية لا تُحيى بحقل createdAt/expiresAt مستقبلي لمستخدم آخر', async () => {
    const x = mk(null); x.E.store['najaf.session'] = JSON.stringify({ userId: 7, role: 'admin', isAdmin: true, admin: true, createdAt: 1, expiresAt: FAR });
    return (x.R('SessionService.getCurrentUser().role') === 'user' && x.R('AuthorizationService.canAccessAdmin()') === false && same(x.J('getMemberCars().map(c=>c.id)'), ownedBy(7)) && x.J('getDashboardStats()') === null) || 'session'; });
  await tc('D5) الدور يُقرأ في كل استدعاء (بلا تخزين مؤقت): مدير ← getMemberCars=60 ثم يُخفَّض دوره إلى user في السجل ← فورًا إعلاناته فقط؛ وتسجيل الخروج ← [] ثم دخول عضو ← إعلاناته', async () => {
    const x = mk('admin'); const a1 = x.J('getMemberCars().length'); x.R(`UsersRepository.update(6, { role: 'user' })`); const a2 = x.J('getMemberCars().length');
    x.R('SessionService.logout()'); const a3 = x.J('getMemberCars().length'); x.R('SessionService.login(7)'); const a4 = x.J('getMemberCars().length');
    return (a1 === 60 && a2 === ownedBy(6).length && a2 < 60 && a3 === 0 && a4 === ownedBy(7).length) || { a1, a2, a3, a4 }; });
  await tc('D6) استدعاء مباشر بلا راوتر: كل مداخل الخدمة (global getMemberCars، MemberCarsService.getMemberCars، AdminService.getDashboardStats/getAllUsers/getAllShowrooms، getPendingMemberCars) متسقة للزائر — لا بيانات إدارية — دون أي go()', async () => {
    const g = mk(null); const routeBefore = g.R('typeof currentRoute === "undefined" ? null : currentRoute');
    const r = [g.J('getMemberCars().length'), g.J('MemberCarsService.getMemberCars().length'), g.R('AdminService.getDashboardStats()'), g.J('AdminService.getAllUsers().length'), g.J('AdminService.getAllShowrooms().length'), g.J('getPendingMemberCars().length'), g.J('AdminService.getPendingMemberCars().length')];
    return (r[0] === 0 && r[1] === 0 && r[2] === null && r[3] === 0 && r[4] === 0 && r[5] === 0 && r[6] === 0 && g.E.errors.length === 0) || r; });
  await tc('D7) مستودع مستبدَل/مصفوفة عامة مباشرة ليست مسارًا للمدير: تعديل MEMBER_CARS من الخارج لا يغيّر العقد (الزائر ما زال [])، والتفويض لا يعتمد على حقول السجل المعدَّلة (ownerId مزوَّر في كائن مُمرَّر لا يُمنح)', async () => {
    const u = mk('user'); const other = ownedBy(2)[0]; const forged = u.R(`AuthorizationService.canManageMemberCar(undefined, { id: ${other}, sourceType: 'member', ownerId: 7 })`);
    const g = mk(null); g.R(`MEMBER_CARS.push(CarModel({ id: 777777, sourceType: 'member', ownerId: 7, status: 'active', brand: 'X', model: 'Y', year: 2020, price: 1 }))`);
    return (forged === false && g.J('getMemberCars().length') === 0) || { forged }; });

  /* ======================= E) محرك الفلاتر: لا تأثر بالمشاهد ======================= */
  console.log('\n--- E) توافق محرك التوحيد ---');
  await tc('E1) توحيد الماركة/الموديل مستقل عن المشاهد: كتابة غير قياسية موجودة في إعلان عضو فقط (McLaren/GrandTourer-X) تُوحَّد بالشكل نفسه للزائر والعضو والتاجر والمدير (قبل إصلاح مصدر _allCars كان الزائر يحصل Mclaren)', async () => {
    const store = {}; const a = mk('admin', store); a.R("MemberCarsRepository.create(CarModel({ sourceType:'member', ownerId:2, brand:'McLaren', model:'GrandTourer-X', year:2020, price:5, currency:'IQD', status:'active', createdAt:'2026-01-01T00:00:00', updatedAt:'2026-01-01T00:00:00' }))");
    const res = [null, 'user', 'dealer1', 'admin'].map(w => { const x = mk(w, store); return [x.R("CarFilters.canonicalBrand('MCLAREN')"), x.R("CarFilters.canonicalModel('GRANDTOURER-X','mclaren')")]; });
    return res.every(r => r[0] === 'McLaren' && r[1] === 'GrandTourer-X') || res; });
  await tc('E2) نشر عضو بكتابة مختلفة يُوحَّد على الأغلبية الموجودة في كل البيانات (بما فيها إعلانات غيره) كما كان: «toyota» ← Toyota، و«mazda» ← Mazda (ماركة أعضاء فقط)، و«land cruiser» ← Land Cruiser', async () => {
    const out = []; for (const w of [null, 'user', 'dealer1', 'admin']) { const x = mk(w); out.push([x.R("CarFilters.canonicalBrand('toyota')"), x.R("CarFilters.canonicalBrand('mazda')"), x.R("CarFilters.canonicalModel('land cruiser','Toyota')"), x.J('CarFilters.options(undefined, {}).brands.map(b=>b.value)').join()]); }
    return (out.every(o => o[0] === 'Toyota' && o[1] === 'Mazda' && o[2] === 'Land Cruiser') && out.every(o => o[3] === out[0][3])) || out; });

  /* ======================= F) فحوص ثابتة: لا نظام تفويض ثانٍ ولا مسار عام عبر الدالة المحروسة ======================= */
  console.log('\n--- F) فحوص ثابتة ---');
  await tc('F1) خدمة الأعضاء تعيد استخدام AuthorizationService فقط (canAccessAdmin + canManageMemberCar) بلا فحص أدوار مكرر (لا role === ولا ROLES.ADMIN في الخدمة)، وgetMemberCars/getMemberCarsByOwner تمرّان من _authorizedRecords', async () => {
    const src = strip(read('services/memberCarsService.js'));
    return (/AuthorizationService\.canAccessAdmin\(\)/.test(src) && /AuthorizationService\.canManageMemberCar\(undefined, c\)/.test(src) && !/\brole\s*===|ROLES\.ADMIN|\.role\b/.test(src) && /function getMemberCars\(\) \{ return _authorizedRecords\(MemberCarsRepository\.getAll\(\)\); \}/.test(src) && /_authorizedRecords\(MemberCarsRepository\.getByOwner\(ownerId\)\)/.test(src)) || 'service'; });
  await tc('F2) المسار العام لا يستعمل الدالة المحروسة: visibilityService وcarFilterService يقرآن المستودع، وشاشات/مكوّنات العرض العام (الرئيسية، السيارات، الأعضاء، البحث، المفضلة، الخريطة، المعارض، التفاصيل) لا تستدعي getMemberCars()/getMemberCarsByOwner()', async () => {
    const v = strip(read('services/visibilityService.js')), cf = strip(read('services/carFilterService.js'));
    const PUB = ['screens/home.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'screens/showrooms.js', 'screens/map.js', 'screens/showroomDetails.js', 'screens/carDetails.js', 'screens/memberCarDetails.js', 'screens/favorites.js', 'components/carCard.js', 'components/showroomCard.js', 'components/filters.js'];
    const bad = PUB.filter(f => /\bgetMemberCars\s*\(|\bgetMemberCarsByOwner\s*\(/.test(strip(read(f))));
    return (/MemberCarsRepository\.getAll\(\)\.filter\(c => c && _memberPublic\(c\)\)/.test(v) && !/\bgetMemberCars\s*\(/.test(v) && /MemberCarsRepository\.getAll\(\)/.test(cf) && !/\bgetMemberCars\s*\(/.test(cf) && bad.length === 0) || { bad }; });
  await tc('F3) المستدعون الباقون مشروعون: المدير (adminMemberCars، adminUserDetails، AdminService.getDashboardStats بعد _requireAdmin) والمالك (myMemberCars) فقط — لا مستدعٍ غير مصرّح في الشيفرة', async () => {
    const files = []; for (const d of ['screens', 'components', 'services', 'navigation']) for (const f of fs.readdirSync(path.join(ROOT, d)).filter(x => x.endsWith('.js'))) { const s = strip(read(d + '/' + f)); if (/\bgetMemberCars\s*\(|\bgetMemberCarsByOwner\s*\(/.test(s) && !(d === 'services' && f === 'memberCarsService.js')) files.push(d + '/' + f); }
    return (JSON.stringify(files.sort()) === JSON.stringify(['screens/adminMemberCars.js', 'screens/adminUserDetails.js', 'screens/myMemberCars.js', 'services/adminService.js'])) || files; });
  await tc('F4) لا تغيير خارج النطاق: 85 سكربتًا، لا reserved، حالات الأعضاء الخمس كما هي، وbundle الاختبارات يحمّل بلا أخطاء JS', async () => {
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length; const a = mk('admin');
    return (order === 85 && a.E.errors.length === 0 && JSON.stringify(a.J('Object.values(MEMBER_CAR_STATUS)')) === '["pending","active","sold","rejected","suspended"]' && JSON.stringify(a.J('SHOWROOM_CAR_STATUSES')) === '["available","sold"]') || { order }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

/* اختبارات «التدقيق النهائي قبل الباكند» (المرحلة 10 — الجزء 8): لكل خلل حقيقي وُجد وأُصلح اختبار، ومصفوفتا المسارات والصلاحيات كفحوص دائمة.
   الأخلال الستة: (1) removeAllCarImages بلا صلاحية، (2) مفضلة مكررة، (3) createdAt غير نصي/تاريخ UTC بدل العراق في 6 شاشات،
   (4) بحث الإدارة ينهار على null، (5) نجاح التسجيل الصامت عند فشل الحفظ، (6) بلا حدود لأطوال النصوص. المراجع مستقلة من البيانات والحساب المباشر. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 260)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const clone = o => JSON.parse(JSON.stringify(o));
const ID = { user: 7, user8: 8, dealer1: 1, dealer2: 2, dealer3: 3, admin: 6 };
const ERRSTATE = 'حدث خطأ، حاول مرة أخرى', BAD = /undefined|NaN|\[object/;
/** بيئة مع التقاط كل console.error (استثناءات الرسم [render error]) */
function view(who, store, raw) {   // raw=true: المتجر يُمرَّر كما هو (مثلًا Proxy لعدّ الكتابات) بلا استنساخ
  const E = makeEnv(store ? (raw ? store : clone(store)) : undefined, { fullSeed: 'p3' }), traces = [];
  E.ctx.console.error = (...a) => traces.push(String(a[0]).slice(0, 40) + ' ' + String((a[a.length - 1] && a[a.length - 1].message) || '').slice(0, 90));
  const R = c => { try { return E.run(c); } catch (e) { traces.push('THROW ' + c.slice(0, 40) + ' ' + String(e.message).slice(0, 60)); } };
  const RA = async c => { try { return await E.run(c); } catch (e) { traces.push('THROW ' + c.slice(0, 40)); return { __throw: String(e.message).slice(0, 80) }; } };
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  R('SessionService.logout()'); if (who) R(`SessionService.login(${ID[who]})`);
  return { E, R, RA, J, traces };
}
const BASE = clone(makeEnv(undefined, { fullSeed: 'p3' }).store);
const snap = E => JSON.stringify(Object.fromEntries(Object.entries(E.store).filter(([k]) => k !== 'najaf.session').sort()));
const mk = (who, store, raw) => view(who, store || BASE, raw);

(async () => {
  const probe = mk('admin'); const cars = probe.J('CarsRepository.getAll()'), mem = probe.J('MemberCarsRepository.getAll()'), imgs = probe.J('CarImagesRepository.getAll()');
  const car1 = cars.find(c => c.showroomId === 1 && imgs.some(i => i.carId === c.id)), car4 = cars.find(c => c.showroomId === 2), m101 = mem.find(c => c.id === 101);

  /* ======================= 1) removeAllCarImages ======================= */
  console.log('\n--- 1) removeAllCarImages: الصلاحية ---');
  await tc('1a) ضيف/عضو/تاجر غير مالك لا يستطيع مسح صور سيارة موجودة: لا تغيير في المخزن إطلاقًا (سيارة معرض 1، وإعلان العضو 101 لغير مالكه)', async () => {
    const bad = [];
    for (const [who, id] of [[null, car1.id], ['user', car1.id], ['dealer2', car1.id], ['user8', car1.id], [null, 101], ['dealer2', 101], ['user8', 101]]) { const x = mk(who); const s0 = snap(x.E), n0 = x.J(`CarImagesRepository.getByCar(${id}).length`); await x.RA(`removeAllCarImages(${id})`); if (snap(x.E) !== s0 || x.J(`CarImagesRepository.getByCar(${id}).length`) !== n0) bad.push((who || 'guest') + ':' + id); }
    return (bad.length === 0 && probe.J(`CarImagesRepository.getByCar(${car1.id}).length`) > 0 && probe.J('CarImagesRepository.getByCar(101).length') > 0) || bad; });
  await tc('1b) المالك والمدير يمسحان (الاستدعاء المشروع): تاجر المعرض 1 لصور سيارته، ومالك الإعلان 101، والمدير لأي سيارة', async () => {
    const d = mk('dealer1'); await d.RA(`removeAllCarImages(${car1.id})`); const u = mk('user'); await u.RA('removeAllCarImages(101)'); const a = mk('admin'); await a.RA(`removeAllCarImages(${car4.id})`);
    return (d.J(`CarImagesRepository.getByCar(${car1.id}).length`) === 0 && u.J('CarImagesRepository.getByCar(101).length') === 0 && a.J(`CarImagesRepository.getByCar(${car4.id}).length`) === 0) || 'owner'; });
  await tc('1c) مسار الحذف لم يتأثر: حذف التاجر لسيارته وحذف العضو لإعلانه يزيلان صورهما ولا يبقى صور يتيمة، وحذف سيارة غيره مرفوض ولا يمس صورها، والنداء لمعرّف غير موجود (تنظيف يتيم) بلا استثناء', async () => {
    const d = mk('dealer1'); const r = await d.RA(`deleteShowroomCar(${car1.id})`); const u = mk('user'); const r2 = await u.RA('deleteMemberCar(101)');
    const o = mk('dealer2'); const before = o.J(`CarImagesRepository.getByCar(${car1.id}).length`); const r3 = await o.RA(`deleteShowroomCar(${car1.id})`); const after = o.J(`CarImagesRepository.getByCar(${car1.id}).length`);
    const g = mk(null); const n = await g.RA('removeAllCarImages(99999)');
    return (r.ok && d.J(`CarImagesRepository.getByCar(${car1.id}).length`) === 0 && r2.ok && u.J('CarImagesRepository.getByCar(101).length') === 0 && r3.ok === false && before === after && !g.traces.length) || { r: r.ok, r2: r2.ok, r3, before, after }; });
  await tc('1d) سائر دوال الصور بقيت محروسة: removeCarImage/setMainImage لغير المالك ترفض بلا تغيير (لم تتغير)', async () => {
    const img = imgs.find(i => i.carId === car1.id); const bad = [];
    for (const who of [null, 'user', 'dealer2']) { const x = mk(who); const s0 = snap(x.E); const a = await x.RA(`removeCarImage(${img.id})`), b = await x.RA(`setMainImage(${img.id})`); if (a.ok || b.ok || snap(x.E) !== s0) bad.push(who || 'guest'); }
    return bad.length === 0 || bad; });

  /* ======================= 2) المفضلة المكررة ======================= */
  console.log('\n--- 2) المفضلة المكررة ---');
  const dupWorld = () => { const w = mk('user'); for (let i = 0; i < 3; i++) w.R(`FavoritesRepository.create(FavoriteModel({ id: FavoritesRepository.allocateId(), userId: 7, carId: 1, createdAt: '2026-05-0${i + 1}T10:00:00.000Z' }))`); w.R(`FavoritesRepository.create(FavoriteModel({ id: FavoritesRepository.allocateId(), userId: 7, carId: 2, createdAt: '2026-05-05T10:00:00.000Z' }))`); w.R(`FavoritesRepository.create(FavoriteModel({ id: FavoritesRepository.allocateId(), userId: 8, carId: 1, createdAt: '2026-05-06T10:00:00.000Z' }))`); return w; };
  await tc('2a) صفوف مكررة (3 لنفس المستخدم والسيارة): القائمة تعرض السيارة مرة واحدة، والتبديل يزيلها كلها فيصدق isFavorite:false فعلًا (isFavorite تعود false)، والتبديل التالي يضيف صفًا واحدًا فقط، ومفضلة غير المكرر والمستخدم الآخر لا تتأثر', async () => {
    const w = dupWorld(); const listIds = w.J('getFavoriteCars().map(c=>c.id)'); const t1 = w.J('toggleFavorite(1)'); const afterOff = { is: w.R('isFavorite(1)'), rows: w.J('FavoritesRepository.getAll().filter(f=>f.userId===7&&f.carId===1).length') };
    const t2 = w.J('toggleFavorite(1)'); const rows2 = w.J('FavoritesRepository.getAll().filter(f=>f.userId===7&&f.carId===1).length');
    return (same(listIds.sort(), [1, 2]) && t1.ok && t1.isFavorite === false && afterOff.is === false && afterOff.rows === 0 && t2.isFavorite === true && rows2 === 1 && w.R('isFavorite(2)') === true && w.J('FavoritesRepository.getAll().filter(f=>f.userId===8&&f.carId===1).length') === 1) || { listIds, t1, afterOff, rows2 }; });
  function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
  await tc('2b) تنظيف التخزين عند التحميل: المكررات تُحذف (يبقى الأول/الأقدم)، يُكتب مفتاح المفضلة وحده، idempotent (تحميل ثانٍ بلا كتابة)، والتخزين النظيف بلا كتابة، ولا تُدمج صفوف مستخدمين/سيارات مختلفة', async () => {
    const w = dupWorld(); const st = clone(w.E.store); delete st['najaf.session'];
    const before = JSON.parse(st['najaf.favorites']); const writes = []; const prox = new Proxy(clone(st), { set(tg, k, v) { writes.push(k); tg[k] = v; return true; }, deleteProperty(tg, k) { writes.push('-' + k); delete tg[k]; return true; } });
    const x = mk(null, prox, true); const after = JSON.parse(prox['najaf.favorites']); const keep = before.filter(f => f.userId === 7 && f.carId === 1).sort((a, b) => a.id - b.id)[0];
    const w2 = []; const prox2 = new Proxy(clone(prox), { set(tg, k, v) { w2.push(k); tg[k] = v; return true; }, deleteProperty(tg, k) { w2.push('-' + k); delete tg[k]; return true; } }); mk(null, prox2, true);
    const clean = []; const prox3 = new Proxy(clone(BASE), { set(tg, k, v) { clean.push(k); tg[k] = v; return true; }, deleteProperty(tg, k) { clean.push('-' + k); delete tg[k]; return true; } }); const c = mk(null, prox3, true); c.R('1'); const cw = clean.filter(k => k !== 'najaf.schemaVersion' && k !== 'najaf.memberCarsDeleted');
    return (before.length === 5 && after.length === 3 && after.filter(f => f.userId === 7 && f.carId === 1).length === 1 && after.find(f => f.userId === 7 && f.carId === 1).id === keep.id && after.some(f => f.userId === 7 && f.carId === 2) && after.some(f => f.userId === 8 && f.carId === 1) && same([...new Set(writes.filter(k => k !== '-najaf.session'))], ['najaf.favorites']) && w2.filter(k => k !== '-najaf.session').length === 0 && cw.filter(k => k !== '-najaf.session').length === 0) || { b: before.length, a: after.length, writes: [...new Set(writes)], w2, cw }; });   // '-najaf.session' = تسجيل خروج المساعد نفسه لا التطبيق
  await tc('2c) الإصلاح لا يتعارض مع هجرة المفضلة اليتيمة/القديمة (الهجرة 2) ولا مع مقارنة التاريخ: مجموعات phase9_fix/phase9_hardening/created_at_utc تمر (تُشغَّل هنا)', async () => {
    const { spawnSync } = require('child_process'); const bad = [];
    for (const f of ['phase9_fix', 'phase9_hardening', 'created_at_utc']) { const r = spawnSync('node', [path.join(ROOT, 'tests', f + '.test.js')], { cwd: ROOT, encoding: 'utf8', timeout: 120000 }); if (!/0 فشل/.test(r.stdout || '')) bad.push(f); }
    return bad.length === 0 || bad; });

  /* ======================= 3) createdAt في الشاشات ======================= */
  console.log('\n--- 3) createdAt: العرض ---');
  await tc('3a) createdDateText: اليوم بتوقيت العراق من الطابع القانوني (21:00Z وما بعده يوم تالٍ؛ قبله يوم نفسه)، والقديم بلا منطقة يبقى يومه، والتالف/غير النصي → فارغ بلا استثناء', async () => {
    const x = mk(null); const T = v => x.R(`createdDateText(${JSON.stringify(v)})`);
    const ok = T('2026-09-30T20:59:59.999Z') === '2026-09-30' && T('2026-09-30T21:00:00.000Z') === '2026-10-01' && T('2026-09-30T23:30:00') === '2026-09-30' && T('2026-12-31T21:30:00.000Z') === '2027-01-01' && T('2026-09-30T12:00:00+03:00') === '2026-09-30' && T('2026-09-30') === '2026-09-30';
    const inval = [undefined, null, '', 'garbage', '2026-02-30T10:00:00', 12, {}, [], true].map(v => x.R(`createdDateText(${v === undefined ? 'undefined' : JSON.stringify(v)})`));
    return (ok && inval.every(v => v === '')) || { ok, inval }; });
  const weirdWorld = () => { const w = view('admin'); const W = [{}, [], 42, null, true];
    W.forEach((v, i) => { w.R(`MemberCarsRepository.create(CarModel(${JSON.stringify({ id: 9300 + i, sourceType: 'member', ownerId: 7, brand: 'Weird', model: 'M' + i, year: 2020, price: 1000000, currency: 'IQD', mileage: 1, status: 'active', phone: '07700000001', location: 'x', createdAt: v === null ? null : v, updatedAt: '2027-01-01T00:00:00.000Z' })}))`); });
    w.R(`UsersRepository.create(UserModel(${JSON.stringify({ id: 9400, name: 'Pending Dealer', phone: '07700940000', email: 'pd@x.test', role: 'dealer', status: 'pending', passwordHash: 'x', createdAt: {} })}))`);
    w.R(`UsersRepository.create(UserModel(${JSON.stringify({ id: 9401, name: 'Weird User', phone: '07700940001', email: 'wu@x.test', role: 'user', status: 'active', passwordHash: 'x', createdAt: 42 })}))`);
    w.R(`MemberCarsRepository.create(CarModel(${JSON.stringify({ id: 9310, sourceType: 'member', ownerId: 7, brand: 'Late', model: 'Night', year: 2020, price: 1000000, currency: 'IQD', mileage: 1, status: 'active', phone: '07700000001', location: 'x', createdAt: '2027-01-01T21:30:00.000Z', updatedAt: '2027-01-01T21:30:00.000Z' })}))`); return clone(w.E.store); };
  await tc('3b) شاشات تعرض createdAt لا تنهار لقيمة غير نصية (كائن/مصفوفة/رقم/null/true): إعلاناتي، إدارة إعلانات الأعضاء وتفاصيلها، تفاصيل المستخدم، طلبات التجار، وتفاصيل إعلان العضو العامة — بلا ErrorState ولا استثناء ولا نص معطوب', async () => {
    const S = weirdWorld(); const bad = [];
    for (const [who, route, p] of [['user', 'myMemberCars'], ['admin', 'adminMemberCars'], ['admin', 'adminMemberCarDetails', 9300], ['admin', 'adminMemberCarDetails', 9301], ['admin', 'adminMemberCarDetails', 9302], ['admin', 'adminUserDetails', 9400], ['admin', 'adminUserDetails', 9401], ['admin', 'adminDealerRequests'], [null, 'memberCarDetails', 9300], [null, 'memberCarDetails', 9302], [null, 'memberCars']]) {
      const x = mk(who, S); x.R(`go('${route}'${p !== undefined ? ',' + p : ''})`); const h = x.E.screen(); if (x.traces.length || h.includes(ERRSTATE) || BAD.test(h)) bad.push(`${who}:${route}:${p}:${x.traces[0] || 'html'}`); }
    return bad.length === 0 || bad.slice(0, 5); });
  await tc('3c) التاريخ المعروض بتوقيت العراق في الشاشات: إعلان أُنشئ 2027-01-01T21:30Z يظهر «2027-01-02» في إعلاناتي وإدارة الإعلانات وتفاصيله، وسجلات التجربة تعرض يومها كما كان (لا فرق مرئي)', async () => {
    const S = weirdWorld(); const a = mk('admin', S); a.R(`go('adminMemberCars')`); a.R("onAdminMemberCarsSearch('Late')"); const list = a.E.els.adminMemberCarsList ? a.E.els.adminMemberCarsList.innerHTML : a.E.screen(); a.R(`go('adminMemberCarDetails', 9310)`); const det = a.E.screen();
    const u = mk('user', S); u.R(`go('myMemberCars')`); const mine = u.E.screen(); const g = mk(null, S); g.R(`go('memberCarDetails', 9310)`); const pub = g.E.screen();
    const seed = mk('admin'); seed.R(`go('adminMemberCarDetails', 101)`); const sd = seed.E.screen();
    return ([a.E.screen(), det, mine, pub].some(h => h.includes('2027-01-02')) && !det.includes('2027-01-01') && sd.includes('2026-06-01') && list !== undefined) || { det: /🗓️[^<]*/.exec(det), mine: /🗓️[^<]*/.exec(mine) }; });

  /* ======================= 4) بحث الإدارة ======================= */
  console.log('\n--- 4) بحث الإدارة والحقول الناقصة ---');
  await tc('4a) بحث الإدارة لا ينهار لحقل null/غير نصي: معارض (name/address)، سيارات معارض (brand/model)، إعلانات أعضاء (brand/model/اسم مالك)؛ والبحث الصحيح ما زال يجد (kia)', async () => {
    const w = view('admin');
    w.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify({ id: 9500, name: null, address: 42, status: 'active', ownerId: 1, createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' })}))`);
    w.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify({ id: 9501, name: { x: 1 }, address: null, status: 'active', ownerId: 1, createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' })}))`);
    [[null, {}], [{}, null], [42, []]].forEach(([b, m], i) => w.R(`CarsRepository.create(CarModel(${JSON.stringify({ id: 9510 + i, sourceType: 'showroom', showroomId: 1, brand: b, model: m, year: 2020, price: 1, currency: 'IQD', mileage: 1, status: 'available', createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' })}))`));
    [[null, {}], [{}, null]].forEach(([b, m], i) => w.R(`MemberCarsRepository.create(CarModel(${JSON.stringify({ id: 9520 + i, sourceType: 'member', ownerId: 7, brand: b, model: m, year: 2020, price: 1, currency: 'IQD', mileage: 1, status: 'active', phone: '07700000001', location: 'x', createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' })}))`));
    w.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify({ id: 9502, name: 'Elite Motors', address: 'Najaf', status: 'active', ownerId: 1, createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' })}))`);
    w.R(`UsersRepository.create(UserModel(${JSON.stringify({ id: 9530, name: null, phone: '07700953000', email: 'n@x.test', role: 'user', status: 'active', passwordHash: 'x', createdAt: '2027-01-01T00:00:00.000Z' })}))`); w.R(`MemberCarsRepository.update(9520, { ownerId: 9530 })`);
    const S = clone(w.E.store); const x = mk('admin', S); const bad = [];
    for (const [route, fn] of [['adminShowrooms', 'onAdminShowroomsSearch'], ['adminShowroomCars', 'onAdminShowroomCarsSearch'], ['adminMemberCars', 'onAdminMemberCarsSearch']]) { x.R(`go('${route}')`); for (const q of ['a', 'kia', '42', 'x', '']) { const n = x.traces.length; x.R(`${fn}(${JSON.stringify(q)})`); if (x.traces.length > n) bad.push(`${route}:${q}:${x.traces[n]}`); } }
    // البحث الصحيح ما زال يجد (بحروف صغيرة لنص كبير الأول: يثبت أن التصغير يعمل لا أن الدالة لا تنهار فقط)
    x.R(`go('adminShowroomCars')`); x.R("onAdminShowroomCarsSearch('kia')"); const l1 = x.E.els.adminShowroomCarsList.innerHTML;
    x.R(`go('adminMemberCars')`); x.R("onAdminMemberCarsSearch('kia')"); const l2 = x.E.els.adminMemberCarsList.innerHTML;
    x.R(`go('adminShowrooms')`); x.R("onAdminShowroomsSearch('elite')"); const l3 = x.E.els.adminShowroomsList.innerHTML; x.R("onAdminShowroomsSearch('zzzz')"); const l4 = x.E.els.adminShowroomsList.innerHTML;
    return (bad.length === 0 && l1.includes('Kia') && !l1.includes('Toyota') && l2.includes('Kia') && !l2.includes('Toyota') && l3.includes('Elite Motors') && !l3.includes('الفرات') && !l4.includes('Elite Motors')) || { bad: bad.slice(0, 4), k1: l1.includes('Kia'), k2: l2.includes('Kia'), k3: l3.includes('Elite Motors') }; });

  /* ======================= 5) التسجيل وفشل الحفظ ======================= */
  console.log('\n--- 5) التسجيل: فشل الحفظ لا يمرّ صامتًا ---');
  const regForm = x => { const vals = { regName: 'عضو جديد تجريبي', regPhone: '07766655512', regEmail: '', regPassword: 'secret1', regConfirm: 'secret1' }; Object.entries(vals).forEach(([k, v]) => { x.E.els[k] = { value: v, style: {}, textContent: '' }; }); x.E.ctx.document.querySelector = sel => (String(sel).includes('accountType') ? { value: 'user' } : null); x.R('globalThis.__notes = []; notify = function (m, k) { __notes.push([m, k]); }'); };
  await tc('5a) AuthService.register يُرجع persisted: true عند الحفظ السليم، وfalse عند فشله (quota)، والمستخدم يُنشأ في الذاكرة في الحالتين (السلوك القائم)، والحقول الحساسة لا تخرج', async () => {
    const ok = mk(null); const r1 = ok.J(`AuthService.register({name:'عضو جديد',phone:'07766655501',email:'',password:'secret1',confirmPassword:'secret1',accountType:'user'})`);
    const bad = mk(null); bad.E.ctx.localStorage.setItem = () => { const e = new Error('q'); e.name = 'QuotaExceededError'; throw e; }; const r2 = bad.J(`AuthService.register({name:'عضو جديد',phone:'07766655502',email:'',password:'secret1',confirmPassword:'secret1',accountType:'user'})`);
    return (r1.ok && r1.persisted === true && r2.ok && r2.persisted === false && bad.R(`UsersRepository.getAll().some(u => u.phone === '07766655502')`) === true && !/passwordHash/.test(JSON.stringify(r1) + JSON.stringify(r2))) || { r1, r2 }; });
  await tc('5b) واجهة التسجيل تُنبّه عند فشل الحفظ بالرسالة المركزية (NOT_SAVED_MSG) كبقية المعالجات، ولا تنبّه عند الحفظ السليم، وتنتقل للحساب في الحالتين', async () => {
    const bad = mk(null); regForm(bad); bad.E.ctx.localStorage.setItem = () => { const e = new Error('q'); e.name = 'QuotaExceededError'; throw e; }; bad.R('handleRegisterSubmit()'); const n1 = bad.J('__notes'), msg = bad.R('NOT_SAVED_MSG'), route1 = bad.R('currentRoute');
    const ok = mk(null); regForm(ok); ok.R('handleRegisterSubmit()'); const n2 = ok.J('__notes'), route2 = ok.R('currentRoute');
    return (n1.length === 1 && n1[0][0] === msg && n1[0][1] === 'error' && route1 === 'account' && n2.length === 0 && route2 === 'account') || { n1, n2, route1, route2 }; });

  /* ======================= 6) حدود الأطوال ======================= */
  console.log('\n--- 6) حدود أطوال النصوص ---');
  const LIM = { brand: 50, model: 80, color: 40, transmission: 40, fuelType: 40, description: 2000, location: 200 };
  await tc('6a) إعلان عضو: كل حقل نصي بحدّه بالضبط يُقبل، وبحدّه+1 يُرفض برسالة عربية تسمّي الحقل بلا إنشاء مسودة ولا تغيير في المخزن؛ والنص الضخم (3 ملايين حرف) يُرفض فورًا', async () => {
    const base = { brand: 'Kia', model: 'Rio', year: '2020', price: '1000000', phone: '07700000001', currency: 'IQD' }; const bad = []; const labels = { brand: 'الماركة', model: 'الموديل', color: 'اللون', transmission: 'ناقل الحركة', fuelType: 'نوع الوقود', description: 'الوصف', location: 'الموقع' };
    for (const [k, n] of Object.entries(LIM)) { const ok = mk('user'); const r = ok.J(`createDraftMemberCar(${JSON.stringify(Object.assign({}, base, { [k]: 'a'.repeat(n) }))})`); const x = mk('user'); const s0 = snap(x.E); const r2 = x.J(`createDraftMemberCar(${JSON.stringify(Object.assign({}, base, { [k]: 'a'.repeat(n + 1) }))})`); if (!r.ok || r2.ok || !String(r2.error).includes(labels[k]) || snap(x.E) !== s0) bad.push(k + ':' + JSON.stringify([r.ok, r2.ok, r2.error])); }
    const h = mk('user'); const t0 = Date.now(); const rh = h.J(`createDraftMemberCar(${JSON.stringify(Object.assign({}, base, { description: 'd'.repeat(3000000) }))})`); return (bad.length === 0 && rh.ok === false && Date.now() - t0 < 2000) || bad; });
  await tc('6b) سيارة المعرض (إنشاء وتعديل جزئي): نفس الحدود، والتعديل الجزئي يفحص الحقول المُمرَّرة فقط (حقل غير مُمرَّر لا يُرفض)، ورفض التعديل لا يغيّر السجل', async () => {
    const bad = []; const d = mk('dealer1');
    for (const [k, n] of Object.entries(LIM).filter(([k]) => k !== 'location')) { const r = await d.RA(`createShowroomCar(${JSON.stringify({ brand: 'Kia', model: 'Z', year: '2020', price: '1000', [k]: 'a'.repeat(n) })})`); const x = mk('dealer1'); const s0 = snap(x.E); const r2 = await x.RA(`createShowroomCar(${JSON.stringify({ brand: 'Kia', model: 'Z', year: '2020', price: '1000', [k]: 'a'.repeat(n + 1) })})`); if (!r.ok || r2.ok || snap(x.E) !== s0) bad.push('create:' + k); }
    const e = mk('dealer1'); const before = e.J('CarsRepository.getById(1)'); const u1 = await e.RA(`updateShowroomCar(1, { description: 'a'.repeat(2001) })`); const afterBad = e.J('CarsRepository.getById(1)'); const u2 = await e.RA(`updateShowroomCar(1, { description: 'وصف جديد قصير' })`);
    return (bad.length === 0 && u1.ok === false && same(before, afterBad) && u2.ok === true && e.J('CarsRepository.getById(1).description') === 'وصف جديد قصير') || { bad, u1: u1.ok, u2: u2.ok }; });
  await tc('6c) التسجيل: الاسم >100 والبريد >254 وكلمة المرور >128 ترفض برسالة عربية بلا إنشاء حساب، وبحدّها بالضبط تُقبل؛ والبيانات التجريبية كلها أقصر بكثير من كل حدّ (لا رفض لشيء مشروع)', async () => {
    const reg = (o) => `AuthService.register(${JSON.stringify(Object.assign({ name: 'عضو جديد', phone: '07766655590', email: '', password: 'secret1', confirmPassword: 'secret1', accountType: 'user' }, o))})`;
    const x1 = mk(null), x2 = mk(null), x3 = mk(null), x4 = mk(null), x5 = mk(null), x6 = mk(null);
    const r1 = x1.J(reg({ name: 'ا'.repeat(101) })), r2 = x2.J(reg({ email: 'a'.repeat(250) + '@x.co' })), r3 = x3.J(reg({ password: 'p'.repeat(129), confirmPassword: 'p'.repeat(129) }));
    const ok1 = x4.J(reg({ name: 'ا'.repeat(100) })), ok2 = x5.J(reg({ password: 'p'.repeat(128), confirmPassword: 'p'.repeat(128), phone: '07766655591' }));
    const seeds = [...cars, ...mem]; const maxes = Object.fromEntries(Object.keys(LIM).map(k => [k, Math.max(0, ...seeds.map(c => String(c[k] == null ? '' : c[k]).length))]));
    return (!r1.ok && /الاسم/.test(r1.error) && !r2.ok && !r3.ok && /كلمة المرور/.test(r3.error) && x1.J('UsersRepository.getAll().length') === 8 && ok1.ok && ok2.ok && Object.entries(maxes).every(([k, m]) => m * 2 < LIM[k]) && x6.J('TEXT_LIMITS.description') === 2000) || { r1, r2: r2.error, r3: r3.error, ok1: ok1.ok, maxes }; });

  await tc('6d) رسالة الخطأ السابقة تُمسح عند نجاح التحقق: إرسال بوصف 2001 يُظهر «طويل جدًا»، ثم تصحيحه وإعادة الإرسال يمسحها ويفتح نافذة الإعلان (لا تبقى رسالة قديمة خلفها أو بعد إلغائها)', async () => {
    const x = mk('user'); const el = { textContent: '', style: {} }; const ov = { style: {} };
    const form = d => ({ mcBrand: 'Kia', mcModel: 'Rio', mcYear: '2020', mcPrice: '9000000', mcCurrency: 'IQD', mcPhone: '07700000001', mcDescription: d });
    const setForm = d => Object.entries(form(d)).forEach(([k, v]) => { x.E.els[k] = { value: v, style: {}, textContent: '' }; });
    x.E.els.addMemberCarError = el; x.E.els.rewardAdOverlay = ov; x.R('ModalFocus.activate = function () {}; _rewardStepLabel = function () {}');
    setForm('d'.repeat(2001)); x.R('handleAddMemberCarSubmit()'); const first = { msg: el.textContent, shown: el.style.display, draft: x.R('_currentDraftId') };
    setForm('d'.repeat(2000)); x.R('handleAddMemberCarSubmit()'); const second = { msg: el.textContent, shown: el.style.display, overlay: ov.style.display, draft: !!x.R('_currentDraftId') };
    return (first.msg.includes('الوصف') && first.shown === 'block' && !first.draft && second.msg === '' && second.shown === 'none' && second.overlay === 'flex' && second.draft) || { first, second }; });

  /* ======================= 7) مصفوفة المسارات ======================= */
  console.log('\n--- 7) مسارات × أدوار × معاملات ---');
  await tc('7) كل مسارات الراوتر (31) × 5 أدوار × 9 معاملات (غير موجود/سالب/NaN/Infinity/نص/كائن/حقن…): لا استثناء رسم ولا ErrorState ولا نص معطوب، ولا شاشة إدارة/تاجر/حساب لمن لا يحق له (الحراسة تُحوّل أو ترفض)', async () => {
    const roles = [null, 'user', 'dealer1', 'dealer2', 'admin']; const routes = JSON.parse(mk(null).R('JSON.stringify(Object.keys(ROUTES))'));
    const PARAMS = ['undefined', '1', '101', '99999', '-1', 'NaN', '"abc"', '"<img src=x onerror=alert(1)>"', '{}']; const bad = []; let cells = 0;
    for (const who of roles) { const x = mk(who); for (const route of routes) for (const p of PARAMS) { cells++; const n = x.traces.length; x.R(`currentRoute='home';currentParam=null;_navStack=[];go('${route}',${p})`); const fin = x.R('currentRoute'), h = x.E.screen();
      if (x.traces.length > n || h.includes(ERRSTATE) || BAD.test(h)) bad.push(`${who || 'guest'}:${route}:${p}:err`);
      if (/^admin/.test(route) && who !== 'admin' && !['login', 'accessDenied'].includes(fin)) bad.push(`${who || 'guest'}:${route}:admin-leak:${fin}`);
      if (['dealerHome', 'myShowroomCars', 'addShowroomCar'].includes(route) && !x.R('AuthorizationService.canAccessDealerArea()') && !['login', 'accessDenied'].includes(fin)) bad.push(`${who || 'guest'}:${route}:dealer-leak`);
      if (['account', 'addMemberCar', 'myMemberCars'].includes(route) && !who && fin !== 'login') bad.push(`${route}:guest-leak`); if (['login', 'register'].includes(route) && who && fin !== 'account') bad.push(`${route}:logged-in-shows-login`); } }
    return (bad.length === 0 && cells === roles.length * routes.length * PARAMS.length) || { cells, bad: bad.slice(0, 5) }; });

  /* ======================= 8) مصفوفة الصلاحيات والملكية ======================= */
  console.log('\n--- 8) صلاحيات الخدمات والملكية ---');
  await tc('8a) كل دوال الإدارة (13) مرفوضة لضيف/عضو/تاجرين بلا أي تغيير في المخزن (لقطة قبل/بعد)، ومسموحة للمدير', async () => {
    const pend = mem.find(c => c.status === 'pending'); const ADM = [`approveMemberCar(${pend.id})`, `rejectMemberCar(${pend.id},'x')`, `suspendMemberCarAdmin(101,'x')`, `restoreMemberCar(101)`, 'suspendShowroom(1)', 'activateShowroom(5)', `setShowroomCarStatus(${car1.id},'sold')`, 'approveDealer(3)', 'rejectDealer(2)', 'getDashboardStats()', 'adminGetAllUsers()', 'adminGetAllShowrooms()', 'adminGetPendingMemberCars()']; const bad = [];
    for (const who of [null, 'user', 'dealer1', 'dealer2']) for (const e of ADM) { const x = mk(who); const s0 = snap(x.E); const r = await x.RA(e); await new Promise(r => setTimeout(r, 2)); const deny = r === undefined || r === null || r === false || (Array.isArray(r) && !r.length) || (r && typeof r === 'object' && (r.ok === false || r.__throw)); if (!deny || snap(x.E) !== s0) bad.push(`${who || 'guest'}:${e}`); }
    for (const e of ADM.filter(e => !e.startsWith('restore'))) { const a = mk('admin'); const r = await a.RA(e); if (!(Array.isArray(r) || (r && typeof r === 'object' && r.__throw === undefined && r.ok !== false))) bad.push('admin-denied:' + e); }
    return bad.length === 0 || bad.slice(0, 5); });
  await tc('8b) ملكية السيارات: ضيف/عضو آخر/تاجر آخر لا يعدّل ولا يحذف ولا يغيّر حالة إعلان العضو 101 ولا سيارة المعرض 1 (ولا العكس: تاجر 1 لسيارة المعرض 2)، بلا أي تغيير في المخزن', async () => {
    const MO = [`updateMemberCar(101,{brand:'Hacked',model:'X',year:'2020',price:'1000',phone:'07700000001'})`, 'deleteMemberCar(101)', `changeMemberCarStatus(101,'sold')`]; const SO = id => [`updateShowroomCar(${id},{brand:'Hacked',model:'X',year:'2020',price:'1'})`, `deleteShowroomCar(${id})`, `changeShowroomCarStatus(${id},'sold')`]; const bad = [];
    const attempts = []; for (const who of [null, 'dealer2', 'user8']) MO.forEach(e => attempts.push([who, e])); for (const who of [null, 'user', 'user8', 'dealer2']) SO(car1.id).forEach(e => attempts.push([who, e])); SO(car4.id).forEach(e => attempts.push(['dealer1', e])); attempts.push([null, "createShowroomCar({brand:'Kia',model:'Z',year:2020,price:1})"], ['user', "createShowroomCar({brand:'Kia',model:'Z',year:2020,price:1})"], [null, 'toggleFavorite(1)']);
    for (const [who, e] of attempts) { const x = mk(who); const s0 = snap(x.E); const r = await x.RA(e); await new Promise(r => setTimeout(r, 2)); if ((r && r.ok === true) || snap(x.E) !== s0) bad.push(`${who || 'guest'}:${e.slice(0, 40)}`); }
    return bad.length === 0 || bad.slice(0, 5); });
  await tc('8c) تسجيل جديد لا يتصعّد: حقول role/status/id الزائدة في register تُتجاهل (حساب user/dealer فقط، التاجر pending، ولا تغيير على حساب المدير)', async () => {
    const x = mk(null); x.R(`AuthService.register({name:'مخترق',phone:'07799988877',email:'',password:'secret1',confirmPassword:'secret1',accountType:'user',role:'admin',status:'active',id:6})`); const u = x.J(`UsersRepository.getAll().find(u=>u.phone==='07799988877')`);
    const y = mk(null); y.R(`AuthService.register({name:'مخترق٢',phone:'07799988866',email:'',password:'secret1',confirmPassword:'secret1',accountType:'dealer',status:'active',id:6})`); const d = y.J(`UsersRepository.getAll().find(u=>u.phone==='07799988866')`);
    const z = mk(null); const adm = z.J('AuthService.register({name:"مخترق٣",phone:"07799988855",email:"",password:"secret1",confirmPassword:"secret1",accountType:"admin"})');
    return (u.role === 'user' && u.id !== 6 && d.role === 'dealer' && d.status === 'pending' && d.id !== 6 && adm.ok === false && y.R('UsersRepository.getById(6).role') === 'admin') || { u, d, adm: adm.ok }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

/* اختبارات «المرحلة 10 — الجزء 1: أساس البيانات والظهور العام» (Phase 10 Part 1).
   تغطي: ظهور عام موحّد · حالة حساب التاجر · حالة المعرض · اتساق جلب السيارة (مصفوفة أدوار × سيارات × أسطح) ·
         اتساق الفلاتر · سجلات غير صالحة/محذوفة · مجموعات فارغة · فحوص ثابتة.
   كُتبت قبل التنفيذ لإثبات الثغرات (22 نجحت و64 فشلت على الكود السابق)، ثم مرّت. «إعادة تحميل» = بيئة جديدة بنفس التخزين. */
const { makeEnv } = require('./harness');
makeEnv.fullSeedDefault = true;   // (6.2-C ج2) هذا الملف يعمل على بيانات الـDemo الموسّعة الكاملة (كل بيئاته)
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** الاختبار يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 180)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer2: ['07709876543', 'dealer123'],
  dealer3: ['07711223344', 'dealer123'], dealer4: ['07705566778', 'dealer123'], dealer5: ['07715558899', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const clone = o => JSON.parse(JSON.stringify(o));
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
// (6.2-C ج2) جداول البذرة الكاملة، مكتوبة صراحةً من نص data/cars.js وdata/memberCars.js (لا تُحسب من كود التطبيق) لتبقى مرجعًا مستقلًا:
//   سيارات المعارض: المعرض 1 = 1–3 و16–21 و43–44 · 2 = 4–6 و22–27 و45–46 · 3 = 7–9 و28–30 و47 · 4 = 10–12 و31–38 · 5 (موقوف) = 13–15 و39–42
//   إعلانات الأعضاء (المالك): 101(7) 102(1) 103(7,pending) 104(2) 105(7,sold) 106(3) 107(4) 108(7,pending) 109(5,rejected) 110(2,suspended)
//   + الموسّعة 111(2) 112(3) 113(4) 114(7) 115(5) 116(1) 117(2) 118(3) 119(4) 120(5,sold) 121(1) 122(3) 123(2) 124(4) 125(5) 126(1) 127(3) 128(2,sold) 129(4) 130(5) 131(3)
const SH_CARS = { 1: [1, 2, 3].concat(range(16, 21), [43, 44]), 2: [4, 5, 6].concat(range(22, 27), [45, 46]), 3: [7, 8, 9].concat(range(28, 30), [47]), 4: [10, 11, 12].concat(range(31, 38)), 5: [13, 14, 15].concat(range(39, 42)) };
const ALL_SHOW = range(1, 47), PUB_SHOW = ALL_SHOW.filter(id => !SH_CARS[5].includes(id) && !SH_CARS[3].includes(id));   // كل سيارات المعارض | العامة: لا الموقوف 5 ولا قيد المراجعة 3 (سياسة الظهور العام للمعارض: active فقط)
const MEMBER_ALL = range(101, 131);
const MEMBER_PUBLIC = [101, 102, 104, 106, 107].concat(range(111, 119), range(121, 127), range(129, 131));   // نشطة (active) لأي مالك فعّال: 24 إعلانًا
const MEMBER_PUBLIC_NO_OWNER2 = [101, 102, 106, 107, 112, 113, 114, 115, 116, 118, 119, 121, 122, 124, 125, 126, 127, 129, 130, 131];   // بعد رفض التاجر 2 (مالك 104/111/117/123): 20 إعلانًا
const idsOf = html => [...new Set([...String(html).matchAll(/go\('(?:carDetails|memberCarDetails)',(\d+)\)/g)].map(m => Number(m[1])))];
const showroomIdsOf = html => [...new Set([...String(html).matchAll(/go\('showroomDetails',(\d+)\)/g)].map(m => Number(m[1])))];
const hasFavBtn = (html, id) => String(html).includes(`handleFavoriteToggle(${id})`);
const mkCar = async (x, o = {}) => x.R(`createShowroomCar(${JSON.stringify(Object.assign({ brand: 'Kia', model: 'Fx', year: 2020, price: 1000 }, o))})`);
const ERR = 'حدث خطأ، حاول مرة أخرى';   // عنوان ErrorState: أي استثناء داخل render يظهر به

/** السيناريو: المعرض 4 موقوف + تاجر المعرض 2 مرفوض (+ المعرض 5 موقوف في البيانات التجريبية أصلًا) */
function scenario() { const a = mk('admin'); a.R('AdminService.suspendShowroom(4)'); a.R('rejectDealer(2)'); return clone(a.E.store); }

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) مسار عام موحّد + ظهور عام ======================= */
  console.log('\n--- A) المسار العام الموحّد ---');
  await tc('A1) واجهة المسار العام موجودة: showrooms/cars/member cars + byId + access', async () => {
    const x = mk(null);
    const fns = ['getVisibleShowrooms', 'getVisibleShowroomById', 'getVisibleCars', 'getVisibleMemberCars', 'getPublicCars', 'getVisibleCarById', 'getVisibleCarsByShowroom', 'getCarAccess', 'getShowroomAccess', 'getMemberCarAccess', 'canViewCar', 'canViewShowroom'];
    const missing = fns.filter(f => x.R(`typeof ${f}`) !== 'function'); return missing.length === 0 || missing; });
  await tc('A2) الزائر: المعارض العامة = الفعّالة (active) فقط، وسياراتها فقط، وسيارات الأعضاء النشطة فقط', async () => {
    const g = mk(null);
    return same(J(g, 'getVisibleShowrooms().map(s=>s.id)'), [1, 2, 4])   /* 3 قيد المراجعة و5 موقوف مخفيان */ && same(J(g, 'getVisibleCars().map(c=>c.id)'), PUB_SHOW) &&
      same(J(g, 'getVisibleMemberCars().map(c=>c.id)'), MEMBER_PUBLIC); });
  await tc('A3) getPublicCars: showroom/member/all (والقيم الغريبة = showroom كالسابق)', async () => {
    const g = mk(null); const P = s => J(g, `getPublicCars(${JSON.stringify(s)}).map(c=>c.id)`);
    return same(P('showroom'), PUB_SHOW) && same(P('member'), MEMBER_PUBLIC) && same(P('all'), PUB_SHOW.concat(MEMBER_PUBLIC)) && same(P('bogus'), PUB_SHOW) && same(J(g, 'getPublicCars().map(c=>c.id)'), PUB_SHOW); });
  await tc('A4) المدير يرى كل المعارض وسياراتها في المسار نفسه، وسيارات الأعضاء العامة تبقى النشطة (الإدارة لها شاشاتها)', async () => {
    const a = mk('admin'); return same(J(a, 'getVisibleShowrooms().map(s=>s.id)'), range(1, 5)) && same(J(a, 'getVisibleCars().map(c=>c.id)'), ALL_SHOW) &&
      same(J(a, 'getVisibleMemberCars().map(c=>c.id)'), MEMBER_PUBLIC) && a.R('AdminService.getAllShowrooms().length') === 5 && a.R('getMemberCars().length') === MEMBER_ALL.length; });
  await tc('A5) التاجر المالك لمعرض موقوف يرى معرضه وسياراته في المسار العام ويديرها، وتاجر آخر لا', async () => {
    const o = mk('dealer5'), other = mk('dealer1');
    return same(J(o, 'getVisibleCars().map(c=>c.id)'), ALL_SHOW.filter(id => !SH_CARS[3].includes(id))) && o.R('getVisibleShowroomById(5).id') === 5 && o.R('getMyShowroomCars().length') === SH_CARS[5].length &&
      same(J(other, 'getVisibleCars().map(c=>c.id)'), PUB_SHOW) && other.R('getVisibleShowroomById(5)') === undefined; });
  await tc('A6) getVisibleCarsByShowroom: معرض ظاهر ← سياراته؛ موقوف ← [] للعامة وسياراته للمدير/المالك', async () => {
    const g = mk(null), a = mk('admin'), o = mk('dealer5');
    return same(J(g, 'getVisibleCarsByShowroom(1).map(c=>c.id)'), SH_CARS[1]) && J(g, 'getVisibleCarsByShowroom(5)').length === 0 &&
      same(J(a, 'getVisibleCarsByShowroom(5).map(c=>c.id)'), SH_CARS[5]) && same(J(o, 'getVisibleCarsByShowroom(5).map(c=>c.id)'), SH_CARS[5]); });
  await tc('A7) getVisibleCarById/getVisibleShowroomById: السجل إن كان ظاهرًا وإلا undefined (لا استثناء)', async () => {
    const g = mk(null);
    return g.R('getVisibleCarById(1).id') === 1 && g.R('getVisibleCarById(13)') === undefined && g.R('getVisibleCarById(101).id') === 101 && g.R('getVisibleCarById(103)') === undefined &&
      g.R('getVisibleShowroomById(1).id') === 1 && g.R('getVisibleShowroomById(5)') === undefined; });
  await tc('A8) getCarAccess/getShowroomAccess يميّزان ok / hidden / missing', async () => {
    const g = mk(null); const A = (f, id) => g.R(`${f}(${id}).status`);
    return A('getCarAccess', 1) === 'ok' && A('getCarAccess', 13) === 'hidden' && A('getCarAccess', 103) === 'hidden' && A('getCarAccess', 999999) === 'missing' &&
      A('getShowroomAccess', 1) === 'ok' && A('getShowroomAccess', 5) === 'hidden' && A('getShowroomAccess', 999) === 'missing' && g.R('getCarAccess(1).car.id') === 1 && g.R('getCarAccess(13).car') === undefined; });

  /* ======================= B) حالة حساب التاجر ======================= */
  console.log('\n--- B) حالة حساب التاجر ---');
  const hiddenEverywhere = (x, sid, cids) => ({
    sh: x.R(`getVisibleShowrooms().some(s=>s.id===${sid})`) === false, byId: x.R(`getVisibleShowroomById(${sid})`) === undefined,
    cars: cids.every(c => x.R(`getVisibleCars().every(k=>k.id!==${c})`) && x.R(`getVisibleCarById(${c})`) === undefined && x.R(`searchCars('', 'all').every(k=>k.id!==${c})`)),
    byShowroom: J(x, `getVisibleCarsByShowroom(${sid})`).length === 0, search: x.R(`searchShowrooms('').every(s=>s.id!==${sid})`), access: x.R(`getShowroomAccess(${sid}).status`) === 'hidden' });
  await tc('B1) رفض التاجر: معرضه وسياراته مخفية في كل الواجهات العامة', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); const g = asGuest(a); const h = hiddenEverywhere(g, 1, [1, 2, 3]); return Object.values(h).every(Boolean) || h; });
  await tc('B2) أي حالة حساب غير active (suspended/pending/disabled/rejected) تخفي معرض مالكه بنفس المسار', async () => {
    const out = {};
    for (const st of ['suspended', 'pending', 'disabled', 'rejected']) {
      const x = mk(null, { 'najaf.userOverrides': JSON.stringify({ 2: { status: st } }) });
      out[st] = Object.values(hiddenEverywhere(x, 2, [4, 5, 6])).every(Boolean);
    }
    return Object.values(out).every(Boolean) || out; });
  await tc('B3) المدير يرى معرض التاجر المرفوض وسياراته ويديرها (المسار العام + الإدارة)', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)');
    return a.R('getVisibleShowroomById(1).id') === 1 && same(J(a, 'getVisibleCarsByShowroom(1).map(c=>c.id)'), SH_CARS[1]) && a.R('getCarAccess(1).status') === 'ok' &&
      a.R(`AdminService.getAllShowrooms().some(s=>s.id===1)`) === true && a.R(`AdminService.setShowroomCarStatus(1,'sold').ok`) === true; });
  await tc('B4) إعادة اعتماد التاجر تعيد ظهور معرضه وسياراته حسب قواعد المعرض (المعرض الموقوف يبقى مخفيًا)', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); a.R('rejectDealer(4)'); a.R('AdminService.suspendShowroom(4)'); a.R('approveDealer(1)'); a.R('approveDealer(4)'); const g = asGuest(a);
    return g.R('getVisibleShowroomById(1).id') === 1 && same(J(g, 'getVisibleCarsByShowroom(1).map(c=>c.id)'), SH_CARS[1]) && g.R('getVisibleShowroomById(4)') === undefined; });
  await tc('B5) التاجر المرفوض لا يستعيد رؤية معرضه بنفسه (يُعامل كزائر)', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); const d = mk('dealer1', asGuest(a).E.store);
    return d.R('SessionService.isLoggedIn()') === false && d.R('getVisibleShowroomById(1)') === undefined && d.R('AuthorizationService.canManageShowroom(1)') === false; });
  await tc('B6) [محدَّث في الجزء 2] سيارات الأعضاء الشخصية لحساب موقوف: كانت تبقى عامة (قاعدة المرحلة 4)؛ صارت مخفية ما دام الحساب غير فعّال وتعود باعتماده', async () => {
    const a = mk('admin'); a.R('rejectDealer(2)'); const g = asGuest(a);
    const hidden = g.R('getVisibleMemberCars().some(c=>c.id===104)') === false && g.R('getVisibleCarById(104)') === undefined; a.R('approveDealer(2)');
    return hidden && asGuest(a).R('getVisibleCarById(104).id') === 104; });
  await tc('B7) معرض موقوف + مالكه مرفوض: يبقى مخفيًا حتى بعد إعادة اعتماد المالك، ويظهر بعد تفعيل المعرض', async () => {
    const a = mk('admin'); a.R('AdminService.suspendShowroom(1)'); a.R('rejectDealer(1)'); a.R('approveDealer(1)');
    const hidden = asGuest(a).R('getVisibleShowroomById(1)') === undefined; a.R('AdminService.activateShowroom(1)'); return hidden && asGuest(a).R('getVisibleShowroomById(1).id') === 1; });

  /* ======================= C) حالة المعرض ======================= */
  console.log('\n--- C) حالة المعرض ---');
  await tc('C1) سياسة الظهور العام للمعارض: قيد المراجعة (pending) والموقوف مخفيان عن الزائر والمستخدم والتاجر الآخر (كان pending ظاهرًا)؛ ويراهما المدير، ويرى مالك كل منهما معرضه (تفويض لا ظهور عام)', async () => {
    const g = mk(null), u = mk('user'), d = mk('dealer1');
    const hiddenFor = [g, u, d].every(x => [3, 5].every(id => x.R(`getVisibleShowroomById(${id})`) === undefined && x.R(`getShowroomAccess(${id}).status`) === 'hidden' && x.R(`canViewShowroom(${id})`) === false) && x.R(`searchShowrooms('').every(s=>s.id!==3&&s.id!==5)`) && J(x, 'getVisibleCarsByShowroom(3)').length === 0);
    const a = mk('admin'), o3 = mk('dealer3'), o5 = mk('dealer5');
    return hiddenFor && [3, 5].every(id => a.R(`getVisibleShowroomById(${id}).id`) === id) && o3.R('getVisibleShowroomById(3).id') === 3 && o3.R('getVisibleShowroomById(5)') === undefined && o5.R('getVisibleShowroomById(5).id') === 5 && o5.R('getVisibleShowroomById(3)') === undefined; });
  await tc('C2) إيقاف معرض فعّال يخفيه وسياراته فورًا، وإعادة التفعيل تعيدهما، بلا حذف', async () => {
    const a = mk('admin'); const n = a.R('getCars().length'); a.R('AdminService.suspendShowroom(1)'); const g1 = asGuest(a);
    const hid = g1.R('getVisibleShowroomById(1)') === undefined && J(g1, 'getVisibleCarsByShowroom(1)').length === 0; a.R('AdminService.activateShowroom(1)'); const g2 = asGuest(a);
    return hid && g2.R('getVisibleShowroomById(1).id') === 1 && J(g2, 'getVisibleCarsByShowroom(1)').length === SH_CARS[1].length && g2.R('getCars().length') === n; });
  await tc('C3) الإيقاف يُحفظ بعد إعادة التحميل ويطبَّق بنفس المسار', async () => {
    const a = mk('admin'); a.R('AdminService.suspendShowroom(2)'); const g = asGuest(asGuest(a)); return g.R('getVisibleShowroomById(2)') === undefined && same(J(g, 'getVisibleShowrooms().map(s=>s.id)'), [1, 4]); });

  /* ======================= D) اتساق جلب السيارة (أدوار × سيارات × أسطح) ======================= */
  console.log('\n--- D) اتساق جلب السيارة ---');
  const store = scenario();
  // الجزء 2 من المرحلة 10: 104 إعلان فعّال مالكه التاجر 2 المرفوض في هذا السيناريو ← مخفي عن العامة (كان ظاهرًا قبل قرار «حساب المالك غير الفعّال يخفي إعلاناته»)
  const BASE = SH_CARS[1], ACTIVE = MEMBER_PUBLIC_NO_OWNER2;   // المعرض العام الوحيد في السيناريو 1 (2 مرفوض مالكه، 3 قيد المراجعة، 4 و5 موقوفان) وإعلانات الأعضاء النشطة لمالك غير مرفوض
  const ROLES = {
    guest:     { show: BASE, det: ACTIVE },
    rejected2: { show: BASE, det: ACTIVE },                                   // تاجر مرفوض = زائر
    user:      { show: BASE, det: ACTIVE.concat([103, 105, 108]) },            // مالك 101/103/105/108/114 (114 نشط أصلًا في ACTIVE)
    dealer1:   { show: BASE, det: ACTIVE },
    dealer3:   { show: BASE.concat(SH_CARS[3]), det: ACTIVE },               // معرضه قيد المراجعة (غير عام): يراه ويدير سياراته بالتفويض
    dealer4:   { show: BASE.concat(SH_CARS[4]), det: ACTIVE },               // معرضه الموقوف
    dealer5:   { show: BASE.concat(SH_CARS[5]), det: ACTIVE.concat([109, 120]) },   // مالك 109/115/120/125/130 (120 مباعة: المالك يرى إعلانه)
    admin:     { show: ALL_SHOW, det: MEMBER_ALL },
  };
  // rejected2: يخرج أولًا (الجلسة المحفوظة للمدير) ثم يحاول التاجر المرفوض الدخول فلا ينجح
  const env = r => r === 'guest' ? asGuest({ E: { store: clone(store) } }) : r === 'rejected2' ? mk('dealer2', asGuest({ E: { store: clone(store) } }).E.store) : mk(r, clone(store));
  const ALLC = ALL_SHOW.concat(MEMBER_ALL);
  for (const [role, exp] of Object.entries(ROLES)) {
    const visible = id => id < 100 ? exp.show.includes(id) : exp.det.includes(id);
    const listing = exp.show.concat(ACTIVE);   // القوائم العامة: سيارات المعارض الظاهرة + النشطة من الأعضاء
    await tc(`D1[${role}]) لكل سيارة: canViewCar وgetVisibleCarById وgetCarAccess متفقة مع القاعدة`, async () => {
      const x = env(role); const bad = ALLC.filter(id => {
        const v = visible(id); return x.R(`canViewCar(${id})`) !== v || (x.R(`getVisibleCarById(${id})`) !== undefined) !== v || x.R(`getCarAccess(${id}).status`) !== (v ? 'ok' : 'hidden'); });
      return bad.length === 0 || bad; });
    await tc(`D2[${role}]) القوائم العامة: searchCars/getPublicCars/filterCars/filterMemberCars لا تضم إلا ما يحق عرضه`, async () => {
      const x = env(role);
      return same(J(x, `searchCars('', 'all').map(c=>c.id)`), listing) && same(J(x, `getPublicCars('all').map(c=>c.id)`), listing) && same(J(x, `searchCars('', 'showroom').map(c=>c.id)`), exp.show) &&
        same(J(x, `searchCars('', 'member').map(c=>c.id)`), ACTIVE) && same(J(x, `filterCars({}).map(c=>c.id)`), exp.show) && same(J(x, `filterMemberCars({}).map(c=>c.id)`), ACTIVE); });
    await tc(`D3[${role}]) شاشتا carDetails وmemberCarDetails: تُعرض التفاصيل لمن يحق له فقط (وإلا غير متاح/رفض)`, async () => {
      const x = env(role); const bad = [];
      for (const id of ALLC) {
        const v = visible(id); x.R(`go('carDetails',${id})`); const shown = hasFavBtn(x.E.screen(), id); if (shown !== v) bad.push('carDetails:' + id);
        if (id > 100) { x.R(`go('memberCarDetails',${id})`); const ok = x.R('currentRoute') === 'memberCarDetails' && hasFavBtn(x.E.screen(), id); if (ok !== v) bad.push('memberCarDetails:' + id); }
        if (x.E.screen().includes(ERR)) bad.push('ERR:' + id);
      }
      return bad.length === 0 || bad; });
    if (role !== 'guest' && role !== 'rejected2') await tc(`D4[${role}]) المفضلة: تُقبل لما يحق عرضه فقط، والقائمة لا تضم غيره`, async () => {
      const x = env(role); const accepted = ALLC.filter(id => x.R(`toggleFavorite(${id}).ok`) === true); const favs = J(x, 'getFavoriteCars().map(c=>c.id)');
      x.R(`go('favorites')`); const scr = x.E.screen();
      return (same(accepted, ALLC.filter(visible)) && same(favs, accepted) && same(idsOf(scr), accepted)) || { accepted, favs }; });
    await tc(`D5[${role}]) الرئيسية والسيارات وسيارات الأعضاء والبحث: لا بطاقة لسيارة غير مسموحة`, async () => {
      const x = env(role); const bad = [];
      x.R(`go('home')`); idsOf(x.E.screen()).forEach(id => { if (!listing.includes(id)) bad.push('home:' + id); });
      x.R(`go('cars')`); const c = idsOf(x.E.screen()); if (!same(c, exp.show)) bad.push('cars');
      x.R(`go('memberCars')`); const m = idsOf(x.E.screen()); if (!same(m, ACTIVE)) bad.push('memberCars');
      for (const q of ['corolla', 'kia', 'toyota', 'hyundai', 'accent']) { x.R(`go('search','${q}')`); idsOf(x.E.screen()).forEach(id => { if (!listing.includes(id)) bad.push('search:' + q + ':' + id); }); }
      return bad.length === 0 || bad; });
  }
  await tc('D6) مرجع تاريخي: ثغرتا الكود السابق (زائر يفتح إعلان عضو غير نشط عبر carDetails، ومستخدم يضيف إعلانًا مرفوضًا للمفضلة) مغلقتان', async () => {
    const g = mk(null); g.R(`go('carDetails',109)`); const closed1 = !hasFavBtn(g.E.screen(), 109);
    const u = mk('user'); const closed2 = u.R('toggleFavorite(109).ok') === false && u.R('getFavoriteCars().length') === 0; return (closed1 && closed2) || { closed1, closed2 }; });
  await tc('D7) التنقل للخلف يتجاوز تفاصيل لم تعد متاحة لهذا المشاهد ولا يتجاوز ما يحق له', async () => {
    const g = mk(null), o = mk('user');
    return g.R(`_entryUsable({route:'memberCarDetails',param:103})`) === false && g.R(`_entryUsable({route:'memberCarDetails',param:101})`) === true &&
      g.R(`_entryUsable({route:'carDetails',param:13})`) === false && g.R(`_entryUsable({route:'carDetails',param:1})`) === true &&
      o.R(`_entryUsable({route:'memberCarDetails',param:103})`) === true && g.R(`_entryUsable({route:'memberCarDetails',param:99999})`) === false; });
  await tc('D8) تزييف الكائن لا يرفع الصلاحية: canViewCar يعتمد السجل المخزَّن بمعرّفه لا حقول الكائن الممرَّر', async () => {
    const g = mk(null);
    return g.R(`canViewCar({id:13,sourceType:'showroom',showroomId:1,status:'available'})`) === false && g.R(`canViewCar({id:103,sourceType:'member',status:'active'})`) === false &&
      g.R(`canViewCar({id:99999,sourceType:'member',status:'active'})`) === false && g.R(`canViewCar({id:1,sourceType:'member',status:'pending'})`) === true; });

  /* ======================= E) اتساق الفلاتر ======================= */
  console.log('\n--- E) اتساق الفلاتر ---');
  const CRITS = [{}, { brand: 'kia' }, { brand: 'Toyota', model: 'corolla' }, { minPrice: 12000000, maxPrice: 20000000 }, { year: 2020 }, { minMileage: 50000 }, { maxMileage: 100000 }, { brand: 'hyundai', year: 2021 }, { brand: 'nissan', minPrice: 1 }];
  const F = c => ({ Brand: c.brand || '', Model: c.model || '', Year: c.year || '', MinPrice: c.minPrice || '', MaxPrice: c.maxPrice || '', MinMileage: c.minMileage || '', MaxMileage: c.maxMileage || '' });
  const setScr = (x, prefix, c) => Object.entries(F(c)).forEach(([k, v]) => x.E.els[prefix + 'Filter' + k] = { value: String(v), style: {} });
  for (const role of ['guest', 'admin', 'dealer4']) {
    await tc(`E1[${role}]) نفس النتائج من: المحرك على المسار العام = searchCars = filterCars/filterMemberCars = شاشة السيارات/الأعضاء`, async () => {
      const x = env(role); const bad = [];
      for (const c of CRITS) {
        const cj = JSON.stringify(c);
        const eng = J(x, `CarFilters.apply(getPublicCars('showroom'), ${cj}).map(k=>k.id)`), sc = J(x, `searchCars('', 'showroom', ${cj}).map(k=>k.id)`), fc = J(x, `filterCars(${cj}).map(k=>k.id)`);
        if (!same(eng, sc) || !same(eng, fc)) bad.push('showroom:' + cj);
        x.R(`go('cars')`); setScr(x, 'cars', c); x.R('onCarsFilter()'); if (!same(idsOf(x.E.els.carsList.innerHTML), eng)) bad.push('screen-cars:' + cj);
        const engM = J(x, `CarFilters.apply(getPublicCars('member'), ${cj}).map(k=>k.id)`), scM = J(x, `searchCars('', 'member', ${cj}).map(k=>k.id)`), fcM = J(x, `filterMemberCars(${cj}).map(k=>k.id)`);
        if (!same(engM, scM) || !same(engM, fcM)) bad.push('member:' + cj);
        x.R(`go('memberCars')`); setScr(x, 'member', c); x.R('onMemberCarsFilter()'); if (!same(idsOf(x.E.els.memberCarsList.innerHTML), engM)) bad.push('screen-member:' + cj);
      }
      return bad.length === 0 || bad; });
    await tc(`E2[${role}]) البحث الموحّد: نتائج الشاشة = searchCars(q,'all',criteria) لكل معيار`, async () => {
      const x = env(role); const bad = [];
      for (const q of ['kia', 'toyota']) for (const c of CRITS) {
        const cj = JSON.stringify(c); x.R(`go('search','${q}')`); setScr(x, 'search', c); x.R('onSearchFilter()');
        const want = J(x, `searchCars('${q}', 'all', ${cj}).map(k=>k.id)`); const got = idsOf(x.E.els.searchResults.innerHTML);
        if (!same(got, want)) bad.push(q + ':' + cj);
      }
      return bad.length === 0 || bad; });
  }
  await tc('E3) خيارات الفلتر (ماركات/موديلات) تأتي من المسار العام: ماركة سيارة معرض مخفي لا تظهر للزائر وتظهر للمدير', async () => {
    const a = mk('admin'); a.R(`updateShowroomCar(13,{brand:'Zeekr',model:'Hiddenmodel'})`); const st = clone(a.E.store);
    const g = asGuest({ E: { store: clone(st) } }), a2 = mk('admin', clone(st));
    g.R(`go('cars')`); const gb = g.E.screen(); a2.R(`go('cars')`); const ab = a2.E.screen();
    a2.E.els.carsFilterBrand = { value: 'Zeekr', style: {} }; a2.R('onCarsFilter()'); const withBrand = a2.E.els.carsFilterBar.innerHTML;
    return !gb.includes('Zeekr') && ab.includes('Zeekr') && withBrand.includes('value="Hiddenmodel"') &&
      J(g, `CarFilters.options(getPublicCars('all'), {}).brands.map(b=>b.value)`).includes('Zeekr') === false; });
  await tc('E4) الرئيسية: بطاقات السيارات = أحدث 4 من المسار العام (معارض) و4 من الأعضاء النشطة و«المضافة حديثًا» (6 من المسار العام الموحّد)، بلا غيرها', async () => {
    const x = env('guest'); const pool = J(x, `searchCars('', 'showroom')`).sort((p, q) => String(q.createdAt).localeCompare(String(p.createdAt))).slice(0, 4).map(c => c.id);
    const mem = J(x, `searchCars('', 'member')`).slice(0, 4).map(c => c.id); const rec = J(x, `getRecentCars({ limit: RECENT_CARS_HOME_LIMIT }).map(c => c.id)`); x.R(`go('home')`);   // (ميزة المضافة حديثًا) قسم رابع من المسار العام نفسه
    return same(idsOf(x.E.screen()), [...new Set(pool.concat(mem, rec))]); });
  await tc('E5) الخريطة: المعارض نفسها التي تعيدها الشاشة/البحث العام (لا معرض مخفي) ولا سيارات هناك', async () => {
    for (const role of ['guest', 'admin', 'dealer5']) {
      const x = env(role); x.R(`go('map')`); const m = showroomIdsOf(x.E.screen()); x.R(`go('showrooms')`); const s = showroomIdsOf(x.E.screen());
      if (!same(m, s) || !same(m, J(x, `searchShowrooms('').map(k=>k.id)`)) || !same(m, J(x, 'getVisibleShowrooms().map(k=>k.id)'))) return { role, m, s };
    }
    return true; });

  /* ======================= F) سجلات غير صالحة/محذوفة ======================= */
  console.log('\n--- F) سجلات غير صالحة أو محذوفة ---');
  const GARBAGE = ['undefined', 'null', 'NaN', "'abc'", "''", '0', '-1', '1.5', '{}', '[]', 'true', '999999', "'1'", 'Infinity'];
  await tc('F1) معرّفات غير صالحة: كل دوال المسار العام تعيد نتيجة آمنة بلا استثناء', async () => {
    const g = mk(null), bad = [];
    for (const v of GARBAGE) {
      const r = {
        byId: g.R(`getVisibleCarById(${v})`), sh: g.R(`getVisibleShowroomById(${v})`), cs: g.R(`canViewCar(${v})`), ss: g.R(`canViewShowroom(${v})`),
        ca: g.R(`getCarAccess(${v}).status`), sa: g.R(`getShowroomAccess(${v}).status`), ma: g.R(`getMemberCarAccess(${v}).status`), bs: J(g, `getVisibleCarsByShowroom(${v})`),
      };
      if (!(r.byId === undefined && r.sh === undefined && r.cs === false && r.ss === false && ['missing', 'hidden'].includes(r.ca) && ['missing', 'hidden'].includes(r.sa) && ['missing', 'hidden'].includes(r.ma) && Array.isArray(r.bs) && r.bs.length === 0)) bad.push(v + ':' + JSON.stringify(r));
    }
    return bad.length === 0 || bad; });
  await tc('F1b) دوال ById/Access تقبل معرّفًا رقميًا فقط: كائن بمعرّف صالح لا يُفسَّر معرّفًا (لكن canViewCar يقبل سجلًا ويعيد جلبه)', async () => {
    const g = mk(null);
    return g.R('getVisibleCarById({id:1})') === undefined && g.R('getCarAccess({id:1}).status') === 'missing' && g.R('getVisibleShowroomById({id:1})') === undefined && g.R('getShowroomAccess({id:1}).status') === 'missing' &&
      J(g, 'getVisibleCarsByShowroom({id:1})').length === 0 && g.R('getMemberCarAccess({id:101}).status') === 'missing' && g.R('canViewCar({id:1})') === true && g.R('canViewShowroom({id:1})') === true; });
  await tc('F2) معاملات بحث/فلاتر غريبة لا تُسقط: searchCars/searchShowrooms/filterCars/CarFilters بقيم null/أرقام/كائنات', async () => {
    const g = mk(null); const calls = [`searchCars(null)`, `searchCars(undefined,'all')`, `searchCars(2022,'member')`, `searchCars({}, 'bogus', 'abc')`, `searchCars('', 'all', null)`, `searchCars('x','all',{brand:{},year:[],minPrice:{}})`,
      `searchShowrooms(null)`, `searchShowrooms(123)`, `searchShowrooms({})`, `filterCars(null)`, `filterCars('x')`, `filterMemberCars(undefined)`, `CarFilters.apply(null, null)`, `CarFilters.options(undefined, 7)`, `getPublicCars(null)`, `getPublicCars({})`];
    const bad = calls.filter(c => { try { const r = g.R(c); return !(Array.isArray(r) || (r && typeof r === 'object')); } catch (e) { return true; } });
    return bad.length === 0 || bad; });
  await tc('F3) سيارة محذوفة (معرض وعضو): تختفي من كل مسارات العرض، والتفاصيل «غير موجودة»، والمفضلة لا تقبلها', async () => {
    const d = mk('dealer1'); const c = await mkCar(d, { model: 'ToDelete' }); const id = c.car.id; await d.R(`deleteShowroomCar(${id})`);
    const m = d.R(`createDraftMemberCar({brand:'Kia',model:'MDelete',year:2020,price:1000,phone:'07701234567'})`); d.R(`deleteMemberCar(${m.car.id})`);
    const u = mk('user', d.E.store); const out = [];
    for (const k of [id, m.car.id]) {
      u.R(`go('carDetails',${k})`); const s1 = u.E.screen(); u.R(`go('memberCarDetails',${k})`); const s2 = u.E.screen();
      out.push(u.R(`getVisibleCarById(${k})`) === undefined && u.R(`getCarAccess(${k}).status`) === 'missing' && u.R(`searchCars('', 'all').every(c=>c.id!==${k})`) && u.R(`toggleFavorite(${k}).ok`) === false && !hasFavBtn(s1, k) && !hasFavBtn(s2, k) && !s1.includes(ERR) && !s2.includes(ERR));
    }
    return out.every(Boolean) || out; });
  await tc('F4) سيارة معرضها غير موجود: مخفية عن الجميع (حتى المدير في المسار العام) بلا انهيار، وشاشة الإدارة تعرضها', async () => {
    const a = mk('admin'); a.R(`CarsRepository.create(CarModel({sourceType:'showroom',showroomId:9999,brand:'Orph',model:'NoShowroom',year:2021,price:5,status:'available'}))`);
    const id = a.R(`getCars().find(c=>c.model==='NoShowroom').id`); const g = asGuest(a); a.R(`go('adminShowroomCars')`); const adm = a.E.screen(); g.R(`go('cars')`); const cs = g.E.screen(); a.R(`go('cars')`); const acs = a.E.screen();
    return [g, a].every(x => x.R(`getVisibleCarById(${id})`) === undefined && x.R(`getCarAccess(${id}).status`) === 'hidden') && adm.includes('NoShowroom') && !cs.includes(ERR) && !acs.includes('NoShowroom') && !adm.includes(ERR); });
  await tc('F5) مالك المعرض غير موجود أو غير معرَّف: لا انهيار، والمعرض يبقى ظاهرًا (لا حساب يُعلَّق) وبطاقته تُعرض', async () => {
    const x = mk(null); x.R(`SHOWROOMS.push(ShowroomModel({ id: 77, name: 'NoOwnerShowroom', status: 'active', ownerId: 9999 }))`); x.R(`SHOWROOMS.push(ShowroomModel({ id: 78, name: 'UndefOwnerShowroom', status: 'active' }))`);
    x.R(`go('showrooms')`); const s = x.E.screen(); x.R(`go('map')`); const m = x.E.screen();
    return x.R('getVisibleShowroomById(77).id') === 77 && x.R('getVisibleShowroomById(78).id') === 78 && s.includes('NoOwnerShowroom') && s.includes('UndefOwnerShowroom') && m.includes('NoOwnerShowroom') && !s.includes(ERR) && !m.includes(ERR); });
  await tc('F6) نوع مصدر غير معروف أو سجل ناقص الحقول: مخفي/آمن بلا استثناء في كل الشاشات العامة', async () => {
    const a = mk('admin'); a.R(`CarsRepository.create({ id: 8001, sourceType: 'weird', showroomId: 1, brand: 'W', model: 'Weird' })`);
    a.R(`CarsRepository.create({ id: 8002, sourceType: 'showroom', showroomId: 1 })`); const g = asGuest(a); const bad = [];
    if (g.R('getVisibleCarById(8001)') !== undefined || g.R('getCarAccess(8001).status') !== 'hidden') bad.push('weird-source');
    for (const r of ['home', 'cars', 'memberCars', 'showrooms', 'map', 'favorites']) { g.R(`go('${r}')`); if (g.E.screen().includes(ERR)) bad.push('screen:' + r); }
    g.R(`go('showroomDetails',1)`); if (g.E.screen().includes(ERR)) bad.push('showroomDetails'); g.R(`go('carDetails',8002)`); if (g.E.screen().includes(ERR)) bad.push('carDetails-incomplete');
    return bad.length === 0 || bad; });
  await tc('F7) شاشات التفاصيل بمعرّفات غير صالحة لا تنهار', async () => {
    const g = mk(null), bad = [];
    for (const v of GARBAGE) for (const r of ['carDetails', 'memberCarDetails', 'showroomDetails']) { g.R(`go('${r}',${v})`); const s = g.E.screen(); if (s.includes(ERR)) bad.push(r + ':' + v); }
    return bad.length === 0 || bad.slice(0, 5); });

  /* ======================= G) مجموعات فارغة ======================= */
  console.log('\n--- G) مجموعات فارغة ---');
  const cardsFree = h => idsOf(h).length === 0;
  const SEED_MEMBERS = MEMBER_ALL;   // (6.2-C ج2) كل إعلانات الأعضاء التجريبية (101–131) تُعدّ محذوفة ليبقى المخزن فارغًا
  const emptyStore = () => ({ 'najaf.showroomCars': '[]', 'najaf.memberCars': '[]', 'najaf.memberCarsDeleted': JSON.stringify(SEED_MEMBERS), 'najaf.carImages': '[]' });
  await tc('G1) لا سيارات (معارض/أعضاء/صور): كل دوال المسار العام تعيد [] وبلا استثناء', async () => {
    const x = mk(null, emptyStore());
    return x.R('getCars().length') === 0 && x.R('getMemberCars().length') === 0 && x.R('CAR_IMAGES.length') === 0 && ['getVisibleCars()', 'getVisibleMemberCars()', `getPublicCars('all')`, `searchCars('', 'all')`, `searchCars('kia','member')`, `filterCars({brand:'kia'})`, `filterMemberCars({})`, 'getVisibleCarsByShowroom(1)'].every(c => J(x, c).length === 0); });
  await tc('G2) لا سيارات: كل الشاشات العامة تعرض حالة فارغة واضحة بلا ErrorState', async () => {
    const x = mk(null, emptyStore()); const bad = [];
    for (const r of ['home', 'cars', 'memberCars', 'search', 'favorites', 'map', 'showrooms']) { x.R(`go('${r}')`); const s = x.E.screen(); if (s.includes(ERR)) bad.push(r); }
    x.R(`go('cars')`); const c = x.E.screen(); x.R(`go('memberCars')`); const m = x.E.screen(); x.R(`go('showroomDetails',1)`); const d = x.E.screen();
    return (bad.length === 0 && c.includes('لا توجد سيارات حاليًا') && m.includes('لا توجد سيارات أعضاء حاليًا') && d.includes('لا توجد سيارات في هذا المعرض') && cardsFree(c)) || { bad }; });
  await tc('G3) لا معارض: القوائم فارغة والخريطة والمعارض والرئيسية تعرض حالة فارغة بلا انهيار', async () => {
    const x = mk(null); x.R('SHOWROOMS.splice(0, SHOWROOMS.length)'); const bad = [];
    for (const r of ['home', 'showrooms', 'map', 'cars', 'search']) { x.R(`go('${r}')`); if (x.E.screen().includes(ERR)) bad.push(r); }
    x.R(`go('map')`); const m = x.E.screen(); x.R(`go('showrooms')`); const s = x.E.screen(); x.R(`go('cars')`);
    return (bad.length === 0 && J(x, 'getVisibleShowrooms()').length === 0 && J(x, 'getVisibleCars()').length === 0 && m.includes('لا توجد معارض') && s.includes('لا توجد معارض') && idsOf(x.E.screen()).length === 0) || { bad }; });
  await tc('G4) فلاتر بلا بيانات: خيارات فارغة وتطبيق على قائمة فارغة آمن، وشريط الفلاتر يُرسم', async () => {
    const x = mk(null, emptyStore()); const o = J(x, `CarFilters.options(getPublicCars('all'), {brand:'kia'})`); x.R(`go('cars')`); x.E.els.carsFilterBrand = { value: 'Kia', style: {} }; x.R('onCarsFilter()');
    return o.brands.length === 0 && o.models.length === 0 && o.years.length === 0 && J(x, `CarFilters.apply([], {brand:'kia',minPrice:1})`).length === 0 && !x.E.els.carsList.innerHTML.includes(ERR) && x.E.els.carsList.innerHTML.includes('مسح الفلاتر'); });
  await tc('G5) مفضلة يتيمة لسيارات لم تعد موجودة: المفضلة تعرض فارغة بلا انهيار', async () => {
    const x = mk('user', emptyStore()); x.R(`FavoritesRepository.create(FavoriteModel({ userId: ${x.R('SessionService.getCurrentUser().id')}, carId: 5555, createdAt: new Date().toISOString() }))`);
    x.R(`go('favorites')`); return x.R('getFavoriteCars().length') === 0 && !x.E.screen().includes(ERR) && x.E.screen().includes('لا توجد سيارات في المفضلة'); });
  await tc('G6) مدير على مجموعات فارغة: لا استثناء في أي شاشة عامة أو إدارية ذات صلة', async () => {
    const x = mk('admin', emptyStore()); const bad = [];
    for (const r of ['home', 'cars', 'memberCars', 'search', 'favorites', 'map', 'showrooms', 'adminShowroomCars', 'adminMemberCars', 'adminShowrooms']) { x.R(`go('${r}')`); if (x.E.screen().includes(ERR)) bad.push(r); }
    return bad.length === 0 || bad; });

  /* ======================= H) فحوص ثابتة: لا التفاف على المسار العام ======================= */
  console.log('\n--- H) فحوص ثابتة ---');
  const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
  const read = f => strip(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  const RAW = /\b(getCars|getShowrooms|getActiveMemberCars|getMemberCars|getPendingMemberCars|getCarsByShowroom|getShowroomById|getCarById|getMemberCarById)\s*\(/;
  const PUBLIC_UI = ['screens/home.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'screens/showrooms.js', 'screens/map.js', 'screens/showroomDetails.js', 'screens/carDetails.js', 'screens/memberCarDetails.js', 'screens/favorites.js', 'components/carCard.js', 'components/showroomCard.js', 'components/filters.js'];
  await tc('H1) الشاشات والمكوّنات العامة لا تستدعي الجالبات الخام (كلها عبر المسار العام): ' + PUBLIC_UI.length + ' ملفًا', async () => {
    const bad = PUBLIC_UI.filter(f => RAW.test(read(f))); return bad.length === 0 || bad; });
  await tc('H2) لا شاشة/مكوّن يطبّق الفلاتر بنفسه: CarFilters.apply/applyCarFilters غير مستخدمة خارج الخدمات (كلها عبر searchCars)', async () => {
    const files = fs.readdirSync(path.join(ROOT, 'screens')).map(f => 'screens/' + f).concat(fs.readdirSync(path.join(ROOT, 'components')).map(f => 'components/' + f)).filter(f => f.endsWith('.js') && f !== 'components/filters.js');   // filters.js يحوي الغلاف القديم applyCarFilters (يعتمد عليه phase9_fix 6i) ولا تستدعيه أي شاشة
    const bad = files.filter(f => /\bCarFilters\.apply\s*\(/.test(read(f)) || /\bapplyCarFilters\s*\(/.test(read(f))); return bad.length === 0 || bad; });
  await tc('H3) قاعدة ظهور سيارات الأعضاء لا تتكرر في الشاشات: لا «status === active» ولا canManageMemberCar في الشاشات العامة', async () => {
    // memberCarDetails.js يستخدم canManageMemberCar لأزرار الإدارة (ملكية) لا للظهور، فهو خارج هذا الفحص
    const bad = PUBLIC_UI.filter(f => f !== 'screens/memberCarDetails.js' && /MEMBER_CAR_STATUS\.ACTIVE|status\s*===\s*'active'|canManageMemberCar/.test(read(f))); return bad.length === 0 || bad; });
  await tc('H4) الجلب الخام لا تستخدمه خدمتا البحث والمفضلة (باستثناء نص البحث عن اسم المعرض): كلتاهما عبر المسار العام', async () => {
    const bad = ['services/searchService.js', 'services/favoritesService.js'].filter(f => /\b(getCars|getActiveMemberCars|getMemberCars|getCarById)\s*\(/.test(read(f).replace(/function _carSearchText[\s\S]*?\n}\n/, ''))); return bad.length === 0 || bad; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

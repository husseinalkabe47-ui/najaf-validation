/* اختبارات «المرحلة 10 — الجزء 6.1: تحصين المعمارية والأمان وسلامة البيانات» (Phase 10 Part 6.1).
   تدقيق على الكود الفعلي ثم إصلاحات صغيرة. الاختبارات تثبّت: (أ) ما أُصلح (ثغرات وُجدت بالتدقيق)، و(ب) ما بقي سليمًا ويجب ألا يتراجع.
   الإصلاحات: القرار الإداري لا يتجاوزه المالك · واجهات القراءة الإدارية للمدير فقط · الصلاحيات تعيد قراءة السجل المخزَّن (كائن مزوَّر لا يمنح شيئًا) ·
   معرّفات لا تتصادم بين تبويبين + مزامنة التبويبات · أرقام مخزَّنة صارمة (مسافة نصية فارغة ≠ 0، بلا 1e3/0x10، ولا فوق الحد الآمن) ·
   هاتف/واتساب الإعلان بصيغة صالحة فقط · esc يهرّب الفاصلة العليا · سعر الصرف موسوم «تجريبي ثابت». */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 240)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  R('AuthService.logout()'); if (role) login(role);   /* جلسة نظيفة أولًا (التخزين المشترك قد يحمل جلسة من بيئة سابقة) */
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J, setF, login };
}
const same = (a, b) => JSON.stringify(a.slice().sort((x, y) => x - y)) === JSON.stringify(b.slice().sort((x, y) => x - y));
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const jsFiles = d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => d + '/' + f);
const car = (id, o) => `CarModel(Object.assign({ id: ${id}, sourceType:'member', ownerId: 7, brand:'T', model:'M', year:2020, price:1000, currency:'IQD', mileage:1, status:'active' }, ${JSON.stringify(o || {})}))`;
const scar = (id, o) => car(id, Object.assign({ sourceType: 'showroom', ownerId: undefined, showroomId: 1, status: 'available' }, o));
/** نشر إعلان عضو عادي كاملًا (مسودة ← مكافأة ← نشر) */
const publish = (u, data) => { const d = u.J(`createDraftMemberCar(${JSON.stringify(data)})`); if (!d.ok || d.published) return d; u.R(`RewardService.requestPublishReward('${d.draftId}')`); u.R(`RewardService.onRewardCompleted('${d.draftId}')`); return Object.assign({ draftId: d.draftId }, u.J(`publishMemberCarAfterReward('${d.draftId}')`)); };
const memberData = o => Object.assign({ brand: 'Aud', model: 'It', year: '2020', price: '1000', phone: '07700000099', currency: 'IQD' }, o || {});
const keysDiff = (a, b) => Object.keys(Object.assign({}, a, b)).filter(k => a[k] !== b[k]);

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) المعمارية ======================= */
  console.log('\n--- A) المعمارية (Screens → Services → Repositories → AppStorage → localStorage) ---');
  await tc('A1) لا localStorage/sessionStorage/indexedDB/AppStorage خارج storage/ وrepositories/ وimageStore (IndexedDB) وغلاف storageService الرقيق — في الشاشات والمكوّنات والخدمات والتنقل وapp.js', async () => {
    const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('navigation'), jsFiles('services'), jsFiles('models'), ['app.js']).filter(f => !/services\/(imageStore|storageService)\.js$/.test(f));
    const bad = files.filter(f => /\b(localStorage|sessionStorage|indexedDB|AppStorage)\b/.test(strip(read(f)))); return bad.length === 0 || bad; });
  await tc('A2) IndexedDB في imageStore.js وحده (والصور تصل إليه عبر الخدمات: لا indexedDB في أي ملف آخر)', async () => {
    const all = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('services'), jsFiles('navigation'), jsFiles('repositories'), jsFiles('storage'), ['app.js']).filter(f => /indexedDB/.test(strip(read(f)))); return (all.length === 1 && /imageStore\.js$/.test(all[0])) || all; });
  await tc('A3) الشاشات والمكوّنات والتنقل لا تلمس Repository ولا SeedSnapshot ولا IdAllocator مباشرة (كل شيء عبر الخدمات)', async () => {
    const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('navigation'), ['app.js']); const bad = files.filter(f => /\b\w+Repository\b|SeedSnapshot|IdAllocator/.test(strip(read(f)))); return bad.length === 0 || bad; });
  await tc('A4) الشاشات العامة تجلب السيارات والمعارض عبر مسار الظهور فقط: لا getCars/getShowrooms/getMemberCars/getCarById الخام فيها (الإدارية المحروسة بحارس الراوتر وتحرير سيارة التاجر المحروس بـcanManageCar مستثناة)', async () => {
    const pub = ['home', 'cars', 'memberCars', 'search', 'map', 'favorites', 'showrooms', 'showroomDetails', 'carDetails', 'memberCarDetails'].map(n => `screens/${n}.js`).concat(jsFiles('components').filter(f => !/imagePicker\.js$/.test(f)));   // منتقي الصور مكوّن نموذج (تحرير سيارة محروس بـcanManageCar)
    const bad = pub.filter(f => /\b(getCars|getShowrooms|getMemberCars|getCarById|getShowroomById|getActiveMemberCars|getCarsByShowroom|getMemberCarById)\(/.test(strip(read(f)))); return bad.length === 0 || bad; });
  await tc('A5) لا محرك بحث/فلترة ثانٍ ولا محرك تحويل عملة ثانٍ: التحويل في models.js ويُستدعى من carFilterService فقط، والشاشات لا تفلتر السيارات بنفسها', async () => {
    const all = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('services'), jsFiles('navigation')); const conv = all.filter(f => /convertCurrency|getUsdToIqdRate|EXCHANGE_RATE_CONFIG/.test(strip(read(f))));
    const scr = ['cars', 'memberCars', 'search', 'home'].map(n => `screens/${n}.js`).concat(['components/filters.js']).filter(f => /\.filter\s*\(|\.sort\s*\(/.test(strip(read(f))));
    return (JSON.stringify(conv) === '["services/carFilterService.js"]' && scr.length === 0) || { conv, scr }; });
  await tc('A6) لا منطق ظهور ثانٍ: canViewCar/canViewShowroom/_accountBlocked/USER_STATUS لا تظهر في الشاشات والمكوّنات؛ والصلاحيات في AuthorizationService (الشاشات لا تقرر من يدير)', async () => {
    const files = [].concat(jsFiles('screens'), jsFiles('components')); const vis = files.filter(f => /canViewCar|canViewShowroom|_accountBlocked|_memberPublic|\.ownerId\s*===/.test(strip(read(f)))); return vis.length === 0 || vis; });
  await tc('A7) لا ملفات جديدة: عدد السكربتات 85 والخدمات/المستودعات/المكوّنات كما كانت', async () => {
    const ls = d => fs.readdirSync(path.join(ROOT, d)).length; return ((read('index.html').match(/<script src=/g) || []).length === 85 && ls('services') === 20 && ls('repositories') === 11 && ls('components') === 11) || [ls('services'), ls('repositories'), ls('components')]; });

  /* ======================= B) المعرّفات ======================= */
  console.log('\n--- B) سلامة المعرّفات ---');
  await tc('B1) إنشاء سيارة ← حذفها ← reload ← سيارة جديدة: المعرّف مختلف وأكبر (عضو) — ثلاث دورات متتالية بلا إعادة استخدام', async () => {
    const a = mk('admin'); let store = a.E.store; const seen = []; for (let i = 0; i < 3; i++) { const u = mk('user', store); const p = publish(u, memberData({ model: 'C' + i })); seen.push(p.car.id); u.R(`deleteMemberCar(${p.car.id})`); store = u.E.store; }
    return (new Set(seen).size === 3 && seen[0] < seen[1] && seen[1] < seen[2]) || seen; });
  await tc('B2) نفس الاختبار لسيارة معرض (تاجر): إنشاء ← حذف ← reload ← إنشاء: معرّف جديد، ولا يتصادم مع سيارات الأعضاء', async () => {
    const a = mk('dealer1'); const c1 = await a.R(`createShowroomCar({ brand: 'S', model: 'One', year: '2021', price: '1000', currency: 'IQD' })`); await a.R(`deleteShowroomCar(${c1.car.id})`);
    const b = mk('dealer1', a.E.store); const c2 = await b.R(`createShowroomCar({ brand: 'S', model: 'Two', year: '2021', price: '1000', currency: 'IQD' })`);
    const all = b.J('CarsRepository.getAll().map(c=>c.id).concat(MemberCarsRepository.getAll().map(c=>c.id))'); return (c2.car.id !== c1.car.id && c2.car.id > c1.car.id && new Set(all).size === all.length) || { c1: c1.car.id, c2: c2.car.id }; });
  await tc('B3) تسلسل واحد للسيارات (معارض + أعضاء): لا تصادم؛ والمفضلة والصور والمستخدمون والمعارض بتسلسلات خاصة بلا تكرار', async () => {
    const x = mk('admin'); const ids = []; for (let i = 0; i < 3; i++) { ids.push(x.R('MemberCarsRepository.allocateId()')); x.R(`MemberCarsRepository.create(${car('__', {})})`.replace('id: __', 'id: ' + ids[i])); ids.push(x.R('CarsRepository.allocateId()')); x.R(`CarsRepository.create(${scar(ids[ids.length - 1])})`); }
    const f = [x.R('FavoritesRepository.allocateId()'), x.R('FavoritesRepository.allocateId()')], im = [x.R('CarImagesRepository.allocateId()'), x.R('CarImagesRepository.allocateId()')], us = [x.R('UsersRepository.allocateId()'), x.R('UsersRepository.allocateId()')], sh = [x.R('ShowroomsRepository.allocateId()'), x.R('ShowroomsRepository.allocateId()')];
    return (new Set(ids).size === ids.length && [f, im, us, sh].every(p => p[0] !== p[1]) && us[0] > x.J('Math.max(...UsersRepository.getAll().map(u=>u.id))') - 0 - 1) || { ids, f, im, us, sh }; });
  await tc('B4) بيانات قديمة بلا عدّادات: معرّف إعلان عضو محذوف لا يعود (سجل المحذوفات) ومعرّفات الصور/المفضلة لا تتصادم مع الموجود', async () => {
    const a = mk('admin'); a.R(`MemberCarsRepository.create(${car(5000)})`); a.R('deleteMemberCar(5000)'); delete a.E.store['najaf.idCounters'];
    const b = mk('user', a.E.store); const next = b.R('IdAllocator.next("car")'); const fav = b.R('FavoritesRepository.allocateId()'); return (next > 5000 && fav >= 1) || { next }; });
  await tc('B5) تبويبان على التخزين نفسه لا يصدران المعرّف نفسه (العدّاد يُعاد قراءته من التخزين عند كل إصدار)', async () => {
    const A = mk('admin'); const B = mk('admin', A.E.store); const ids = [A.R('IdAllocator.next("car")'), B.R('IdAllocator.next("car")'), A.R('IdAllocator.next("car")'), B.R('IdAllocator.next("car")')]; return new Set(ids).size === 4 || ids; });
  await tc('B6) لا تصادم صور/مفضلة بعد إعادة التحميل: مفضلة سيارة محذوفة لا تنتقل إلى سيارة جديدة بالمعرّف نفسه', async () => {
    const a = mk('user'); const p = publish(a, memberData()); a.R(`toggleFavorite(${p.car.id})`); const oldId = p.car.id; a.R(`deleteMemberCar(${oldId})`);
    const b = mk('user', a.E.store); const p2 = publish(b, memberData({ model: 'New' })); const favs = b.J('getFavoriteCars().map(c=>c.id)'); return (p2.car.id !== oldId && !favs.includes(p2.car.id) && !favs.includes(oldId)) || { oldId, new: p2.car.id, favs }; });

  /* ======================= C) التخزين ======================= */
  console.log('\n--- C) التخزين والمزامنة ---');
  await tc('C1) تخزين تالف/فارغ/ناقص (12 صيغة): لا استثناء في التحميل، ولا «undefined/NaN/[object» في الشاشات العامة، والبيانات التجريبية تبقى ظاهرة', async () => {
    const base = mk('admin'); const clean = JSON.stringify(base.E.store); const bad = [];
    const variants = { mc_malformed: { 'najaf.memberCars': '{bad' }, mc_obj: { 'najaf.memberCars': '{"a":1}' }, mc_null: { 'najaf.memberCars': 'null' }, sc_arr: { 'najaf.showroomCars': '[[[' }, sh_str: { 'najaf.showrooms': '"x"' }, users_num: { 'najaf.users': '12345' }, sess: { 'najaf.session': '{"userId":"abc"}' },
      fav: { 'najaf.favorites': '"oops"' }, cnt: { 'najaf.idCounters': '{"car":"x"}' }, schema: { 'najaf.schemaVersion': '"two"' }, seed: { 'najaf.seedIds': '[1,2]' }, mixed: { 'najaf.memberCars': JSON.stringify([null, 5, 'x', { id: 'a' }, base.J(car(8001)), []]) }, empty: {} };
    for (const [n, patch] of Object.entries(variants)) { try { const st = Object.assign({}, n === 'empty' ? {} : JSON.parse(clean), patch); const x = mk(null, st); if (x.E.errors.length) bad.push(n + ':load'); for (const r of ['home', 'cars', 'memberCars', 'showrooms', 'map', 'favorites']) { x.R(`go('${r}')`); if (/undefined|NaN|\[object|حدث خطأ/.test(x.E.screen())) bad.push(n + ':' + r); } if (!(x.J('getVisibleCars().length') > 0)) bad.push(n + ':no-cars'); } catch (e) { bad.push(n + ' EXC ' + e.message.slice(0, 60)); } }
    return bad.length === 0 || bad; });
  await tc('C2) get/update/delete لا تفقد بيانات غير مقصودة: تعديل سجل لا يغيّر الآخرين، وحذف سجل لا يحذف غيره، والباقي كما هو بعد reload', async () => {
    const a = mk('admin'); a.R(`MemberCarsRepository.create(${car(8301)})`); a.R(`MemberCarsRepository.create(${car(8302)})`); a.R(`MemberCarsRepository.update(8301, { color: 'red' })`); a.R(`MemberCarsRepository.remove(8302)`);
    const before = a.J('MemberCarsRepository.getAll().map(c=>c.id)'); const b = mk('admin', a.E.store); const after = b.J('MemberCarsRepository.getAll().map(c=>c.id)');
    return (same(before, after) && b.J('MemberCarsRepository.getById(8301).color') === 'red' && b.J('MemberCarsRepository.getById(8302)') === null && b.J('MemberCarsRepository.getAll().length') === 10 + 1) || { before, after }; });
  await tc('C3) السجل الصالح وسط سجلات تالفة يُحتفظ به ولا يختفي بعد reload، ولا يظهر منها ما هو غير صالح', async () => {
    const a = mk('admin'); const raw = a.J('MemberCarsRepository.getAll()'); raw.push(null, 7, 'x', { id: 'a' }, a.J(car(8401)), []); a.E.store['najaf.memberCars'] = JSON.stringify(raw); const b = mk('admin', a.E.store);
    return (b.J('MemberCarsRepository.getById(8401)') !== null && b.J('MemberCarsRepository.getAll().every(c => c && typeof c === "object" && Number.isFinite(c.id))')) || 'سجل'; });
  await tc('C4) مزامنة التبويبات: تغيير من تبويب آخر ثم حدث storage ← هذا التبويب يعيد التحميل، فلا يكتب فوق نسخة قديمة (لا تحديث مفقود)', async () => {
    const A = mk('admin'); const B = mk('admin', A.E.store); B.R(`MemberCarsRepository.create(${car(8501)})`);
    t('C4.0) قبل الحدث: التبويب A لا يرى إعلان B (نسخة الذاكرة قديمة)', A.J('MemberCarsRepository.getById(8501)') === null);
    A.E.winHandlers.storage({ key: 'najaf.memberCars' }); A.R(`MemberCarsRepository.create(${car(8502)})`);
    const stored = JSON.parse(A.E.store['najaf.memberCars']).map(c => c.id); return (stored.includes(8501) && stored.includes(8502) && A.J('MemberCarsRepository.getById(8501)') !== null) || stored; });
  await tc('C5) المزامنة: مفتاح لا يخص التطبيق يُتجاهل، ومسح كامل (key=null) يُعالَج، ولا إعادة رسم فوق نموذج مفتوح، وتُعاد رسم الشاشات العادية', async () => {
    const A = mk('admin'); const B = mk('admin', A.E.store); B.R(`MemberCarsRepository.create(${car(8601)})`);
    A.E.winHandlers.storage({ key: 'other.app' }); const ignored = A.J('MemberCarsRepository.getById(8601)') === null;
    A.R(`go('addMemberCar')`); A.E.els.screen.innerHTML = 'MARK'; A.E.winHandlers.storage({ key: 'najaf.memberCars' }); const formKept = A.E.els.screen.innerHTML === 'MARK';
    A.R(`go('cars')`); A.E.els.screen.innerHTML = 'MARK'; A.E.winHandlers.storage({ key: null }); const rerendered = A.E.els.screen.innerHTML !== 'MARK' && A.J('MemberCarsRepository.getById(8601)') !== null;
    return (ignored && formKept && rerendered) || { ignored, formKept, rerendered }; });
  await tc('C6) المزامنة آمنة: معالج storage لا يرمي مع حدث فاسد (undefined/{}/key رقم)، وبياناته لا تُتلَف', async () => {
    const A = mk('admin'); const n = A.J('MemberCarsRepository.getAll().length'); try { A.E.winHandlers.storage(undefined); A.E.winHandlers.storage({}); A.E.winHandlers.storage({ key: 5 }); } catch (e) { return 'EXC ' + e.message; } return A.J('MemberCarsRepository.getAll().length') === n || 'تغيّر'; });

  /* ======================= D) الهجرة ======================= */
  console.log('\n--- D) الهجرة ---');
  await tc('D1) reserved القديمة: معرض → available وعضو → active (مع المسافات والحالة)، بلا مساس بالسعر/المالك/الطوابع، ولا تعود reserved إلى النظام (لا في الواجهة ولا في المفردات)', async () => {
    const a = mk('admin'); const p0 = a.J('CarsRepository.getById(1).price'), u0 = a.J('CarsRepository.getById(1).updatedAt'); a.R(`CarsRepository.update(1, { status: ' Reserved ' })`); a.R(`MemberCarsRepository.update(101, { status: 'RESERVED' })`);
    const b = mk('admin', a.E.store); const c = b.J('CarsRepository.getById(1)'); const m = b.J('MemberCarsRepository.getById(101)');
    b.R(`go('cars')`); const h1 = b.E.screen(); b.R(`go('memberCars')`); const h2 = b.E.screen();
    return (c.status === 'available' && m.status === 'active' && c.price === p0 && c.updatedAt === u0 && b.J('SHOWROOM_CAR_STATUSES').join() === 'available,sold' && !/محجوز|reserved/i.test(h1 + h2) && b.J(`[CarsRepository, MemberCarsRepository].every(r => r.getAll().every(c => !/reserved/i.test(String(c.status))))`)) || { c, m }; });
  await tc('D2) الهجرة/فحص السلامة قابلة لإعادة التشغيل بلا إفساد: تشغيلات متكررة لا تغيّر التخزين (عدا تجديد الجلسة)، وبيانات سليمة لا تُعدَّل بلا سبب', async () => {
    const a = mk('admin'); const s1 = Object.assign({}, a.E.store); const b = mk('admin', a.E.store); b.R('StorageIntegrity.run()'); b.R('StorageIntegrity.run()'); const s2 = Object.assign({}, b.E.store); const c = mk('admin', b.E.store); const s3 = Object.assign({}, c.E.store);
    const d1 = keysDiff(s1, s2).filter(k => k !== 'najaf.session'), d2 = keysDiff(s2, s3).filter(k => k !== 'najaf.session'); return (d1.length === 0 && d2.length === 0) || { d1, d2 }; });
  await tc('D3) رقم المخطط: الحالي 3 (الهجرة 3: createdAt بصيغة UTC)؛ مخطط أحدث من التطبيق لا يُخفَّض ولا يُمسّ؛ ومخطط تالف لا يُسقط التحميل', async () => {
    const a = mk('admin'); const cur = a.J('StorageSchema.CURRENT_VERSION'); a.E.store['najaf.schemaVersion'] = '99'; const b = mk('admin', a.E.store); const kept = b.E.store['najaf.schemaVersion'] === '99';
    const c = mk('admin'); c.E.store['najaf.schemaVersion'] = '"x"'; const d = mk('admin', c.E.store); return (cur === 3 && kept && d.E.errors.length === 0 && d.J('getVisibleCars().length') > 0) || { cur, kept }; });
  await tc('D4) سيارات تجريبية محذوفة (معرض وعضو) لا تعود بعد reload ولا بعد إعادة تشغيل الهجرة', async () => {
    const a = mk('admin'); a.R('CarsRepository.remove(3)'); a.R('MemberCarsRepository.remove(101)'); const b = mk('admin', a.E.store); b.R('StorageIntegrity.run()'); const c = mk('admin', b.E.store);
    return (c.J('CarsRepository.getById(3)') === null && c.J('MemberCarsRepository.getById(101)') === null) || 'عادت'; });
  await tc('D5) سجلات قديمة معطوبة (null/نص/سعر نصي/عملة EUR/حالة غريبة/مالك غير موجود/سنة نصية) لا تُسقط أي شاشة، وتفاصيلها بلا undefined/NaN، ولا تُعدَّل بلا سبب (السعر النصي يبقى كما خُزِّن)', async () => {
    const a = mk('admin'); const raw = a.J('MemberCarsRepository.getAll()'); raw.push(null, 7, 'x', { id: 9100, sourceType: 'member', ownerId: 7, brand: 'Mal', model: 'a', year: 2020, price: '15000000', status: 'active' }, { id: 9101, sourceType: 'member', ownerId: 7, brand: 'Mal', model: 'b', year: 'abc', price: -5, mileage: -9, status: 'active', currency: 'EUR' }, { id: 9102, sourceType: 'member', ownerId: 99999, brand: 'Mal', model: 'c', year: 2020, price: 1000, status: 'active' }, { id: 9103, sourceType: 'member', brand: 'Mal', model: 'd', year: 2020, price: 1000, status: 'zzz' });
    a.E.store['najaf.memberCars'] = JSON.stringify(raw); const x = mk(null, a.E.store); const bad = []; if (x.E.errors.length) bad.push('load');
    for (const r of ['home', 'cars', 'memberCars']) { x.R(`go('${r}')`); if (/undefined|NaN|\[object|حدث خطأ/.test(x.E.screen())) bad.push(r); } x.R(`go('search','mal')`); if (/undefined|NaN|\[object|حدث خطأ/.test(x.E.screen())) bad.push('search');
    for (const id of [9100, 9101, 9102, 9103]) { x.R(`go('memberCarDetails', ${id})`); if (/undefined|NaN|\[object|TypeError/.test(x.E.screen())) bad.push('d' + id); }
    const stored = JSON.parse(x.E.store['najaf.memberCars']).find(c => c && c.id === 9100); return (bad.length === 0 && (!stored || stored.price === '15000000')) || { bad, stored }; });
  await tc('D6) سجل قديم بلا currency: لا هجرة ولا كتابة (يُقرأ دينارًا) ويظهر بالدينار ويدخل البحث بالدينار', async () => {
    const a = mk('admin'); a.R(`(function(){ const c = ${car(9200, { brand: 'Leg', price: 20000000 })}; delete c.currency; return MemberCarsRepository.create(c).ok; })()`); const b = mk('admin', a.E.store);
    const raw = JSON.parse(b.E.store['najaf.memberCars']).find(c => c.id === 9200); return (!('currency' in raw) && b.R('carCurrency(MemberCarsRepository.getById(9200))') === 'IQD' && b.R('carPriceText(MemberCarsRepository.getById(9200))').endsWith('د.ع')) || raw; });

  /* ======================= E) الظهور ======================= */
  console.log('\n--- E) الظهور ---');
  await tc('E1) دوال الظهور لا ترمي استثناء لمدخلات فاسدة (undefined/null/NaN/Infinity/سالب/نص/كائن/مصفوفة/كسر/معرّف غير موجود) وتعيد فارغًا آمنًا', async () => {
    const g = mk(null); const bad = []; const vals = ['undefined', 'null', 'NaN', 'Infinity', '-1', '0', '"1"', '"1abc"', '{}', '[]', 'true', '1.5', '99999999'];
    for (const v of vals) for (const fn of ['getVisibleCarById', 'getVisibleShowroomById', 'getVisibleCarsByShowroom', 'getCarAccess', 'getShowroomAccess', 'getMemberCarAccess', 'canViewCar', 'canViewShowroom']) { const r = g.R(`(function(){ try { ${fn}(${v}); return 'ok'; } catch (e) { return 'THROW ' + e.message; } })()`); if (/THROW/.test(r)) bad.push(fn + '(' + v + ') ' + r); }
    return bad.length === 0 || bad.slice(0, 4); });
  await tc('E2) مصفوفة الظهور: معرض موقوف / مالك إعلان غير فعّال / إعلان غير نشط / محذوف / سجل معطوب — مخفي عن الزائر، ويراه المدير، والمالك يرى إعلانه حسب الصلاحيات؛ وإعادة تفعيل الحساب تُعيد النشط فقط', async () => {
    const a = mk('admin'); a.R(`ShowroomsRepository.update(2, { status: 'suspended' })`); a.R(`UsersRepository.update(7, { status: 'suspended' })`); a.R(`CarsRepository.remove(2)`); a.R(`MemberCarsRepository.update(102, { status: 'suspended' })`); a.R(`MemberCarsRepository.create(${car(9301, { ownerId: 6 })})`); a.R(`MemberCarsRepository.create(${car(9302, { ownerId: 6, status: 'pending' })})`);
    const sus = a.J('getCars().filter(c=>c.showroomId===2).map(c=>c.id)'), own7 = a.J('getMemberCars().filter(c=>c.ownerId===7).map(c=>c.id)'); const g = mk(null, a.E.store); const pub = g.J(`getPublicCars('all').map(c=>c.id)`);
    const guestOk = !pub.some(i => sus.includes(i) || own7.includes(i) || i === 2 || i === 102 || i === 9302) && pub.includes(9301) && g.J('getVisibleCarById(2)') == null;
    const adm = mk('admin', a.E.store); const adminSees = adm.J('getCarAccess(1).status') && adm.J(`getMemberCarAccess(9302).status`) === 'ok' && adm.J(`getMemberCarAccess(102).status`) === 'ok';
    const owner = mk('user', a.E.store); /* user = الحساب 7 (موقوف) لا يدخل أصلًا */ const ownerBlocked = owner.J('SessionService.getCurrentUser()') === null;
    a.R(`UsersRepository.update(7, { status: 'active' })`); const g2 = mk(null, a.E.store); const pub2 = g2.J(`getPublicCars('all').map(c=>c.id)`); const back = own7.filter(i => i !== 102).every(i => pub2.includes(i) || g2.J(`getMemberCarById(${i})`).status !== 'active');
    return (guestOk && adminSees && ownerBlocked && back) || { guestOk, adminSees, ownerBlocked, back }; });

  /* ======================= F) الصلاحيات على مستوى الخدمة ======================= */
  console.log('\n--- F) الصلاحيات (على مستوى الخدمة لا الواجهة) ---');
  await tc('F1) (إصلاح) المالك لا يعيد تفعيل إعلان أوقفه/رفضه المدير أو ما زال قيد المراجعة: suspended/rejected/pending تبقى كما هي', async () => {
    const a = mk('admin'); const uid = mk('user', a.E.store).J('SessionService.getCurrentUser().id'); [[7001, 'suspended'], [7002, 'rejected'], [7003, 'pending']].forEach(([id, st]) => a.R(`MemberCarsRepository.create(${car(id, { ownerId: uid, status: st })})`));
    const u = mk('user', a.E.store); const out = []; for (const [id, st] of [[7001, 'suspended'], [7002, 'rejected'], [7003, 'pending']]) for (const to of ['active', 'sold']) { const r = u.J(`changeMemberCarStatus(${id}, '${to}')`); if (r.ok || u.J(`getMemberCarById(${id}).status`) !== st) out.push([id, to, r]); } return out.length === 0 || out; });
  await tc('F2) المالك يبدّل active ↔ sold لإعلانه الطبيعي (يبقى يعمل)، والمدير يغيّر أي حالة ويعيد التفعيل بعد الإيقاف، والمالك لا يضع حالة إدارية', async () => {
    const a = mk('admin'); const uid = mk('user', a.E.store).J('SessionService.getCurrentUser().id'); a.R(`MemberCarsRepository.create(${car(7101, { ownerId: uid })})`); a.R(`MemberCarsRepository.create(${car(7102, { ownerId: uid, status: 'suspended' })})`);
    const u = mk('user', a.E.store); const ok = u.J(`changeMemberCarStatus(7101,'sold')`).ok && u.J('getMemberCarById(7101).status') === 'sold' && u.J(`changeMemberCarStatus(7101,'active')`).ok && u.J('getMemberCarById(7101).status') === 'active';
    const noAdminStatus = ['suspended', 'rejected', 'pending', 'zzz'].every(s => u.J(`changeMemberCarStatus(7101,'${s}')`).ok === false);
    const adm = mk('admin', a.E.store); const adminOk = adm.J(`approveMemberCar(7102)`).ok && adm.J('getMemberCarById(7102).status') === 'active' && adm.J(`suspendMemberCarAdmin(7102,'x')`).ok && adm.J('getMemberCarById(7102).suspensionReason') === 'x';
    return (ok && noAdminStatus && adminOk) || { ok, noAdminStatus, adminOk }; });
  await tc('F3) (إصلاح) واجهات القراءة الإدارية للمدير فقط: adminGetAllUsers/adminGetAllShowrooms/getDashboardStats/getPendingMemberCars لا تُعيد شيئًا للزائر والعضو والتاجر، وتعمل للمدير (والمستخدمون بلا passwordHash)', async () => {
    const out = {}; for (const role of [null, 'user', 'dealer1']) { const x = mk(role); out[role || 'guest'] = [x.J('adminGetAllUsers().length'), x.J('adminGetAllShowrooms().length'), x.J('getDashboardStats()'), x.J('adminGetPendingMemberCars().length'), x.J('getPendingMemberCars().length')]; }
    const a = mk('admin'); const au = a.J('adminGetAllUsers()'); const adminOk = au.length === 8 && au.every(u => !('passwordHash' in u)) && a.J('adminGetAllShowrooms().length') === 5 && a.J('getDashboardStats().totalUsers') === 8 && a.J('adminGetPendingMemberCars()') !== undefined;
    const denied = Object.values(out).every(v => v[0] === 0 && v[1] === 0 && v[2] === null && v[3] === 0 && v[4] === 0); return (denied && adminOk) || { out, adminOk }; });
  await tc('F4) كل إجراءات المدير مرفوضة لغير المدير (عضو/تاجر/زائر) بلا أي تغيير في البيانات', async () => {
    const a = mk('admin'); const snap = () => JSON.stringify(a.E.store); const s0 = snap(); const fns = ['suspendShowroom(1)', 'activateShowroom(1)', "setShowroomCarStatus(1,'sold')", 'approveDealer(5)', 'rejectDealer(5)', 'approveMemberCar(103)', "rejectMemberCar(103,'x')", "suspendMemberCarAdmin(103,'x')", 'restoreMemberCar(103)']; const bad = [];
    for (const role of [null, 'user', 'dealer1']) { const x = mk(role, a.E.store); const before = JSON.stringify(Object.assign({}, x.E.store, { 'najaf.session': 0 })); for (const f of fns) { const r = x.J(f); if (!r || r.ok !== false) bad.push(`${role}:${f}`); } const after = JSON.stringify(Object.assign({}, x.E.store, { 'najaf.session': 0 })); if (before !== after) bad.push(role + ':state-changed'); } return bad.length === 0 || bad; });
  await tc('F5) (إصلاح) الصلاحية تعيد قراءة السجل المخزَّن: كائن مزوَّر (ownerId=أنا لإعلان غيري) لا يمنح تعديلًا ولا صلاحية صور؛ ومعرّف غير موجود ← false', async () => {
    const a = mk('admin'); const u = mk('user', a.E.store); const me = u.J('SessionService.getCurrentUser().id'); const notMine = u.J(`MemberCarsRepository.getAll().filter(c => c.ownerId !== ${me})[0].id`);
    const forged = [u.R(`AuthorizationService.canEditMemberCar(undefined, { id: ${notMine}, sourceType: 'member', ownerId: ${me} })`), u.R(`AuthorizationService.canDeleteMemberCar(undefined, { id: ${notMine}, sourceType: 'member', ownerId: ${me} })`), u.R(`AuthorizationService.canChangeMemberCarStatus(undefined, { id: ${notMine}, sourceType: 'member', ownerId: ${me} })`), u.R(`AuthorizationService.canManageCarImages({ id: ${notMine}, sourceType: 'member', ownerId: ${me} })`), u.R(`AuthorizationService.canEditMemberCar(undefined, { id: 99999, sourceType: 'member', ownerId: ${me} })`), u.R(`AuthorizationService.canEditMemberCar(undefined, null)`), u.R(`AuthorizationService.canEditMemberCar(undefined, { sourceType: 'member', ownerId: ${me} })`)];
    const real = u.J(`getMemberCars().filter(c => c.ownerId === ${me})[0]`); const own = real ? [u.R(`AuthorizationService.canEditMemberCar(undefined, ${JSON.stringify(real)})`), u.R(`AuthorizationService.canManageCarImages(${JSON.stringify(real)})`)] : [true, true];
    return (forged.every(v => v === false) && own.every(v => v === true)) || { forged, own }; });
  await tc('F6) العضو: يعدّل/يحذف إعلانه فقط؛ لا يعدّل/يحذف إعلان عضو آخر ولا سيارة معرض ولا يغيّر معرضًا ولا ينفّذ إجراءات التاجر', async () => {
    const a = mk('admin'); const u = mk('user', a.E.store); const me = u.J('SessionService.getCurrentUser().id'); const other = u.J(`MemberCarsRepository.getAll().filter(c => c.ownerId !== ${me})[0].id`); const bad = [];
    if (u.J(`updateMemberCar(${other}, { price: '1' })`).ok) bad.push('edit-other'); if (u.J(`deleteMemberCar(${other})`).ok) bad.push('delete-other'); if (u.J(`changeMemberCarStatus(${other}, 'sold')`).ok) bad.push('status-other');
    if ((await u.R(`updateShowroomCar(1, { price: '1' })`)).ok) bad.push('edit-showroom'); if ((await u.R(`deleteShowroomCar(1)`)).ok) bad.push('delete-showroom'); if (u.J(`changeShowroomCarStatus(1, 'sold')`).ok) bad.push('status-showroom'); if ((await u.R(`createShowroomCar({ brand:'X', model:'Y', year:'2020', price:'1000' })`)).ok) bad.push('create-showroom');
    if (u.R('AuthorizationService.canManageShowroom(1)') !== false) bad.push('manage-showroom'); if (u.R('AuthorizationService.canAccessDealerArea()') !== false) bad.push('dealer-area'); if (u.R('AuthorizationService.canAccessAdmin()') !== false) bad.push('admin');
    return bad.length === 0 || bad; });
  await tc('F7) التاجر المعتمد: يدير معرضه وسياراته فقط (تعديل/حذف/حالة/إنشاء)، ولا يدير معرضًا أو سيارة تاجر آخر ولا إعلان عضو غيره، ولا ينفّذ إجراءات المدير', async () => {
    const d = mk('dealer1'); const mine = d.J('AuthorizationService.getManagedShowrooms().map(s=>s.id)'); const mineCar = d.J('getMyShowroomCars()[0].id'); const otherCar = d.J(`getCars().filter(c => !${JSON.stringify(mine)}.includes(c.showroomId))[0].id`); const did = d.J('SessionService.getCurrentUser().id'); const notMineMember = d.J(`MemberCarsRepository.getAll().filter(c => c.ownerId !== ${did})[0].id`); const bad = [];
    if (!(await d.R(`updateShowroomCar(${mineCar}, { color: 'x' })`)).ok) bad.push('edit-mine'); if (!d.J(`changeShowroomCarStatus(${mineCar}, 'sold')`).ok) bad.push('status-mine');
    if ((await d.R(`updateShowroomCar(${otherCar}, { price: '1' })`)).ok) bad.push('edit-other'); if ((await d.R(`deleteShowroomCar(${otherCar})`)).ok) bad.push('delete-other'); if (d.J(`changeShowroomCarStatus(${otherCar}, 'sold')`).ok) bad.push('status-other');
    if (d.R(`AuthorizationService.canManageShowroom(${[1, 2, 3, 4, 5].find(i => !mine.includes(i))})`) !== false) bad.push('manage-other-showroom'); if (d.J(`updateMemberCar(${notMineMember}, { price: '1' })`).ok || d.J(`deleteMemberCar(${notMineMember})`).ok) bad.push('member-other'); if (d.J('suspendShowroom(1)').ok || d.J('approveDealer(5)').ok) bad.push('admin-actions');
    return bad.length === 0 || bad; });
  await tc('F8) تاجر pending: بلا صلاحيات تاجر (لا منطقة تاجر ولا إنشاء ولا إدارة معرض)؛ وبعد اعتماد المدير يملك معرضه فقط', async () => {
    const a = mk('admin'); const r = mk(null, a.E.store); r.R(`go('register')`); r.setF({ regName: 'تاجر جديد', regPhone: '07709998877', regEmail: '', regPassword: 'secret1', regConfirm: 'secret1' }); r.E.radios.accountType = 'dealer'; r.R('handleRegisterSubmit()');
    const me = r.J('SessionService.getCurrentUser()'); if (!me || me.role !== 'dealer' || me.status !== 'pending') return { me };
    const pend = [r.R('AuthorizationService.canAccessDealerArea()'), (await r.R(`createShowroomCar({ brand:'P', model:'D', year:'2020', price:'1000' })`)).ok, r.J('AuthorizationService.getManagedShowrooms().length'), r.R('AuthorizationService.canManageShowroom(1)')];
    const adm = mk('admin', a.E.store); const ap = adm.J(`approveDealer(${me.id})`); const r2 = mk(null, a.E.store); r2.R('AuthService.logout()'); r2.R(`go('login')`); r2.setF({ loginIdentifier: '07709998877', loginPassword: 'secret1' }); r2.R('handleLoginSubmit()');
    const sh = r2.J('AuthorizationService.getManagedShowrooms().map(s=>s.id)'); const created = await r2.R(`createShowroomCar({ brand:'P', model:'D', year:'2020', price:'1000', currency:'IQD' })`);
    return (pend[0] === false && pend[1] === false && pend[2] === 0 && pend[3] === false && ap.ok && sh.length === 1 && created.ok && created.car.showroomId === sh[0] && r2.R('AuthorizationService.canManageShowroom(1)') === false) || { pend, ap: ap.ok, sh, created: created.ok }; });
  await tc('F9) الزائر: لا يضيف/يعدّل/يحذف/يغيّر حالة، ولا مفضلة دائمة، ولا يصل لمسارات الإدارة/التاجر/إدارة الأعضاء (الراوتر يحوّل للدخول أو يرفض) ولا يرى التفاصيل المخفية', async () => {
    const a = mk('admin'); const g = mk(null, a.E.store); const before = a.J('FavoritesRepository.getAll().length'); const bad = [];
    if (g.J(`createDraftMemberCar(${JSON.stringify(memberData())})`).ok) bad.push('draft'); if ([g.J(`updateMemberCar(101,{price:'1'})`), g.J(`deleteMemberCar(101)`), g.J(`changeMemberCarStatus(101,'sold')`)].some(r => r.ok)) bad.push('member-ops'); if (g.J('toggleFavorite(1)').ok || g.J('FavoritesRepository.getAll().length') !== before || g.J('getFavoriteCars().length') !== 0) bad.push('favorite');
    for (const r of ['adminHome', 'adminDashboard', 'adminUsers', 'adminShowrooms', 'adminMemberCars', 'adminShowroomCars', 'adminDealerRequests', 'dealerHome', 'myShowroomCars', 'addShowroomCar', 'addMemberCar', 'myMemberCars', 'account']) { g.R(`go('${r}')`); const route = g.R('currentRoute'); if (route !== 'login' && route !== 'accessDenied' && !/تسجيل الدخول|غير مصرّح|غير مصرح/.test(g.E.screen())) bad.push('route:' + r); if (/إحصائيات|لوحة الإدارة/.test(g.E.screen()) && route.startsWith('admin')) bad.push('leak:' + r); }
    a.R(`MemberCarsRepository.update(103, { status: 'pending' })`); const g2 = mk(null, a.E.store); g2.R(`go('memberCarDetails', 103)`); if (g2.R('currentRoute') === 'memberCarDetails' && /Kia|Rio/.test(g2.E.screen())) bad.push('hidden-details');
    return bad.length === 0 || bad; });
  await tc('F10) لا ترقية دور من التسجيل (admin مرفوض) ولا تزوير ownerId/status/sourceType/id في الإنشاء والتعديل (المالك من الجلسة، الحالة والنوع من النظام)', async () => {
    const g = mk(null); g.R(`go('register')`); g.setF({ regName: 'مخترق', regPhone: '07708887766', regEmail: '', regPassword: 'secret1', regConfirm: 'secret1' }); g.E.radios.accountType = 'admin'; g.R('handleRegisterSubmit()'); const noAdmin = g.J('UsersRepository.getAll().filter(u => u.phone === "07708887766").length') === 0;
    const u = mk('user'); const me = u.J('SessionService.getCurrentUser().id'); const p = publish(u, memberData({ ownerId: 1, status: 'pending', sourceType: 'showroom', id: 5, showroomId: 2, reviewedBy: 1 }));
    const c = p.car; const up = u.J(`updateMemberCar(${c.id}, { ownerId: 1, status: 'suspended', sourceType: 'showroom', id: 7, showroomId: 2, reviewedBy: 1 })`); const after = u.J(`getMemberCarById(${c.id})`);
    return (noAdmin && c.ownerId === me && c.status === 'active' && c.sourceType === 'member' && c.id !== 5 && c.showroomId === undefined && after && after.ownerId === me && after.status === 'active' && after.sourceType === 'member' && after.showroomId === undefined && after.reviewedBy === undefined) || { noAdmin, c, after }; });

  /* ======================= G) دورة حياة إعلان العضو ======================= */
  console.log('\n--- G) إعلان العضو ---');
  await tc('G1) المسودة لا تُنشأ كسجل ولا تظهر للعامة، ولا تُنشر بلا مكافأة، والمكافأة تُستهلك مرة واحدة، ومكافأة مسودة لا تنشر مسودة أخرى، ومستخدم آخر لا ينشر مسودة غيره، والمسودة تضيع بعد reload', async () => {
    const a = mk('admin'); const u = mk('user', a.E.store); const d1 = u.J(`createDraftMemberCar(${JSON.stringify(memberData({ brand: 'Dr1' }))})`); const d2 = u.J(`createDraftMemberCar(${JSON.stringify(memberData({ brand: 'Dr2' }))})`); const bad = [];
    if (!d1.ok || d1.published !== false || u.J(`MemberCarsRepository.getAll().filter(c=>c.brand==='Dr1').length`) !== 0 || mk(null, u.E.store).J(`getPublicCars('all').filter(c=>c.brand==='Dr1').length`) !== 0) bad.push('draft-visible');
    if (u.J(`publishMemberCarAfterReward('${d1.draftId}')`).ok) bad.push('no-reward');
    u.R(`RewardService.requestPublishReward('${d1.draftId}')`); u.R(`RewardService.onRewardCompleted('${d1.draftId}')`); if (u.J(`publishMemberCarAfterReward('${d2.draftId}')`).ok) bad.push('cross-draft');
    const other = mk('dealer1', u.E.store); if (other.J(`publishMemberCarAfterReward('${d1.draftId}')`).ok) bad.push('other-user'); const u2 = mk('user', u.E.store); u2.R(`RewardService.requestPublishReward('${d1.draftId}')`); u2.R(`RewardService.onRewardCompleted('${d1.draftId}')`);
    if (u2.J(`publishMemberCarAfterReward('${d1.draftId}')`).ok) bad.push('draft-survives-reload');
    const u3 = mk('user', a.E.store); const ok = publish(u3, memberData({ brand: 'Ok1' })); if (!ok.ok) bad.push('publish-fail'); else if (u3.J(`publishMemberCarAfterReward('${ok.draftId}')`).ok) bad.push('reward-reuse');
    return bad.length === 0 || bad; });
  await tc('G2) التاجر والمدير ينشران إعلانهما الشخصي مباشرة (بلا إعلان مكافأ) ونشر الأعضاء العاديين يتطلب مكافأة؛ ولا موافقة إدارية لكل سيارة', async () => {
    const d = mk('dealer1'); const r = d.J(`createDraftMemberCar(${JSON.stringify(memberData())})`); const u = mk('user'); const r2 = u.J(`createDraftMemberCar(${JSON.stringify(memberData())})`);
    return (r.ok && r.published === true && r.car.status === 'active' && r2.ok && r2.published === false && r2.requiresReward === true) || { r, r2 }; });
  await tc('G3) حذف إعلان العضو: لا يعود بعد reload ولا يعود معرّفه ولا تبقى مفضلته؛ والإعلان المحذوف لا يظهر لأحد', async () => {
    const u = mk('user'); const p = publish(u, memberData()); u.R(`toggleFavorite(${p.car.id})`); const id = p.car.id; const del = u.J(`deleteMemberCar(${id})`); const b = mk('user', u.E.store);
    return (del.ok && b.J(`getMemberCarById(${id})`) === null && b.J(`getVisibleCarById(${id})`) == null && b.J('getFavoriteCars().every(c=>c.id!==' + id + ')') && b.J(`FavoritesRepository.getAll().filter(f=>f.carId===${id}).length`) === 0 && b.R('IdAllocator.next("car")') > id) || { del }; });
  await tc('G4) حساب المالك غير الفعّال (suspended/pending/disabled/…): إعلاناته مخفية عن العامة بلا حذف، وتعود النشطة منها بإعادة التفعيل، وتبقى المعلّقة/المباعة مخفية', async () => {
    const a = mk('admin'); a.R(`MemberCarsRepository.create(${car(9401, { ownerId: 6 })})`); a.R(`MemberCarsRepository.create(${car(9402, { ownerId: 6, status: 'sold' })})`); const res = {};
    for (const st of ['suspended', 'pending', 'disabled', 'ACTIVE', ' active ']) { a.R(`UsersRepository.update(6, { status: ${JSON.stringify(st)} })`); const g = mk(null, a.E.store); res[st] = g.J(`getPublicCars('member').map(c=>c.id)`).includes(9401); }
    a.R(`UsersRepository.update(6, { status: 'active' })`); const g2 = mk(null, a.E.store); const pub = g2.J(`getPublicCars('member').map(c=>c.id)`); const kept = a.J('getMemberCars().filter(c=>c.ownerId===6).length') >= 2;
    return (Object.values(res).every(v => v === false) && pub.includes(9401) && !pub.includes(9402) && kept) || { res, pub }; });

  /* ======================= H) سيارات المعرض ======================= */
  console.log('\n--- H) سيارات المعرض ---');
  await tc('H1) سيارة المعرض تُنشأ بـshowroomId من حساب التاجر (لا من الإدخال) وsourceType=showroom وstatus=available، ولا يتغيّر المعرض/المالك/النوع/المعرّف بالتعديل', async () => {
    const d = mk('dealer1'); const sid = d.J('AuthorizationService.getManagedShowrooms()[0].id'); const r = await d.R(`createShowroomCar({ brand:'Q', model:'R', year:'2020', price:'1000', currency:'IQD', showroomId: 2, ownerId: 1, sourceType: 'member', status: 'sold', id: 9999 })`);
    const up = await d.R(`updateShowroomCar(${r.car.id}, { showroomId: 99, sourceType: 'member', ownerId: 1, status: 'sold', id: 8888, color: 'blue' })`); const c = d.J(`CarsRepository.getById(${r.car.id})`);
    return (r.ok && r.car.showroomId === sid && r.car.sourceType === 'showroom' && r.car.status === 'available' && r.car.id !== 9999 && up.ok && c.showroomId === sid && c.sourceType === 'showroom' && c.status === 'available' && c.ownerId === undefined && c.color === 'blue') || { r: r.car, c }; });
  await tc('H2) حالات سيارة المعرض: available/sold فقط؛ reserved وأي حالة أخرى تُرفض في خدمة التاجر وخدمة المدير؛ والتغيير بين الاثنين يعمل', async () => {
    const d = mk('dealer1'); const id = d.J('getMyShowroomCars()[0].id'); const bad = ['reserved', 'RESERVED', 'pending', 'active', '', 'zzz'].filter(s => d.J(`changeShowroomCarStatus(${id}, ${JSON.stringify(s)})`).ok); const ok = d.J(`changeShowroomCarStatus(${id}, 'sold')`).ok && d.J(`changeShowroomCarStatus(${id}, 'available')`).ok;
    const a = mk('admin', d.E.store); const adminBad = ['reserved', 'pending', 'zzz'].filter(s => a.J(`setShowroomCarStatus(${id}, ${JSON.stringify(s)})`).ok); const adminOk = a.J(`setShowroomCarStatus(${id}, 'sold')`).ok;
    return (bad.length === 0 && ok && adminBad.length === 0 && adminOk && a.J('SHOWROOM_CAR_STATUSES').join() === 'available,sold') || { bad, adminBad }; });

  /* ======================= I) المفضلة ======================= */
  console.log('\n--- I) المفضلة ---');
  await tc('I1) المفضلة: لا تكرار (3 نقرات = سجل واحد أو لا شيء)، والعضو يفضّل المرئي فقط، والمخفي (معرض موقوف/إعلان غير نشط لغير مالكه) مرفوض، والزائر بلا مفضلة', async () => {
    const a = mk('admin'); a.R(`ShowroomsRepository.update(2, { status: 'suspended' })`); a.R(`MemberCarsRepository.update(102, { status: 'suspended' })`); const u = mk('user', a.E.store); const me = u.J('SessionService.getCurrentUser().id'); u.R('toggleFavorite(1)'); u.R('toggleFavorite(1)'); u.R('toggleFavorite(1)');
    const n = u.J(`FavoritesRepository.getAll().filter(f => f.carId === 1 && f.userId === ${me}).length`); const hidden = [u.J('toggleFavorite(5)'), u.J('toggleFavorite(102)')].every(r => r.ok === false); const g = mk(null, a.E.store); return (n <= 1 && hidden && g.J('toggleFavorite(1)').ok === false && g.J('getFavoriteCars().length') === 0) || { n, hidden }; });
  await tc('I2) مفضلة قديمة/تالفة في التخزين (سيارة غير موجودة، carId نص، سجل null/رقم، بلا userId، مكررة) لا تسبب crash ولا بيانات خاطئة، وشاشة المفضلة نظيفة', async () => {
    const a = mk('user'); const uid = a.J('SessionService.getCurrentUser().id'); a.R('toggleFavorite(1)'); const raw = JSON.parse(a.E.store['najaf.favorites']); raw.push({ id: 9901, userId: uid, carId: 424242 }, { id: 9902, userId: uid, carId: 'x' }, null, 5, { id: 9903, userId: uid }, { id: 9904, carId: 1 }, { id: 9905, userId: uid, carId: 1 }); a.E.store['najaf.favorites'] = JSON.stringify(raw);
    const b = mk('user', a.E.store); if (b.E.errors.length) return b.E.errors; b.R(`go('favorites')`); const h = b.E.screen(); const ids = b.J('getFavoriteCars().map(c=>c.id)'); b.R('toggleFavorite(2)'); b.R('toggleFavorite(2)'); return (!/undefined|NaN|\[object|حدث خطأ/.test(h) && ids.every(i => Number.isFinite(i) && i !== 424242)) || { ids }; });
  await tc('I3) سيارة محذوفة أو مخفية لا تظهر في المفضلة بعد reload، وسجلها لا يُحذف عند الإخفاء ويعود بإعادة التفعيل', async () => {
    const a = mk('user'); a.R('toggleFavorite(4)'); a.R('toggleFavorite(5)'); const adm = mk('admin', a.E.store); adm.R('CarsRepository.remove(4)'); adm.R(`ShowroomsRepository.update(2, { status: 'suspended' })`); const b = mk('user', adm.E.store); const hid = b.J('getFavoriteCars().map(c=>c.id)'); const keep = b.J('FavoritesRepository.getAll().filter(f=>f.carId===5).length') === 1;
    adm.R(`ShowroomsRepository.update(2, { status: 'active' })`); const c = mk('user', adm.E.store); const back = c.J('getFavoriteCars().map(c=>c.id)'); return (!hid.includes(4) && !hid.includes(5) && keep && back.includes(5) && !back.includes(4)) || { hid, back }; });

  /* ======================= J) العملة وسلامة الأرقام ======================= */
  console.log('\n--- J) سلامة بيانات العملة والأرقام ---');
  await tc('J1) السعر رقم وcurrency منفصلة ومدعومة فقط (IQD/USD): الإنشاء والتعديل بعملة غير مدعومة (EUR/usd بلا ترميز/فارغ/null/رقم) يُرفض، والافتراضي للسيارة الجديدة دينار صريح، والسجل القديم بلا عملة يُقرأ دينارًا', async () => {
    const d = mk('dealer1'); const iq = await d.R(`createShowroomCar({ brand: 'J', model: 'a', year: '2020', price: '25,000' })`); const us = await d.R(`createShowroomCar({ brand: 'J', model: 'b', year: '2020', price: '٢٥٬٠٠٠', currency: 'USD' })`);
    const rej = []; for (const v of ['EUR', 'U$D', null, 5, {}, 'دينار']) if ((await d.R(`createShowroomCar({ brand: 'J', model: 'c', year: '2020', price: '1000', currency: ${JSON.stringify(v)} })`)).ok) rej.push(v);
    return (iq.ok && iq.car.currency === 'IQD' && iq.car.price === 25000 && typeof iq.car.price === 'number' && us.ok && us.car.currency === 'USD' && us.car.price === 25000 && rej.length === 0 && d.J('["EUR","usd",""].map(v => carCurrency({ price: 1, currency: v }))').join() === ',,IQD') || { iq: iq.car, us: us.car, rej, cc: d.J('["EUR","usd",""].map(v => carCurrency({ price: 1, currency: v }))') }; });
  await tc('J2) سعر الصرف: مصدر واحد (EXCHANGE_RATE_CONFIG) = 1 USD = 1300 IQD، موسوم صراحةً «تجريبي ثابت» في الكود وREADME (ليس حيًّا ولا سوقًا ولا رسميًّا)، بلا جلب خارجي', async () => {
    const x = mk(null); const m = read('models/models.js'), rd = read('README.md'); const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('services'), jsFiles('navigation'), jsFiles('repositories'), jsFiles('storage'), jsFiles('models'), ['app.js']); const net = files.filter(f => /fetch\s*\(|XMLHttpRequest|WebSocket|navigator\.sendBeacon/.test(strip(read(f))));
    return (x.R('getUsdToIqdRate()') === 1300 && x.R('EXCHANGE_RATE_CONFIG.kind') === 'prototype' && /Prototype static exchange rate/i.test(x.R('EXCHANGE_RATE_CONFIG.note')) && /PROTOTYPE STATIC EXCHANGE RATE/.test(m) && /Prototype static exchange rate/i.test(rd) && net.length === 0) || { net }; });
  await tc('J3) (إصلاح) المسافة النصية الفارغة/المسافات لا تصير 0 (المجهول ≠ 0)، والصيغ غير العشرية العادية («1e3»، «0x10»، «Infinity») ليست أرقامًا مخزَّنة صالحة، و0 الحقيقية صالحة', async () => {
    const x = mk(null); const m = v => x.R(`validMileage(${JSON.stringify(v)})`), p = v => x.R(`validPrice(${JSON.stringify(v)})`);
    return (m(' ') === null && m('   ') === null && m('') === null && m(null) === null && m(0) === 0 && m('0') === 0 && m(65000) === 65000 && m('65000') === 65000 && m('1e3') === null && m('0x10') === null && m('Infinity') === null && m(-1) === null &&
      p(' ') === null && p('1e3') === null && p('0x10') === null && p('5e-1') === null && p(0) === null && p(-5) === null && p('15000000') === 15000000 && p(18500000) === 18500000 && p(12.5) === 12.5) || 'validators'; });
  await tc('J4) (إصلاح) أرقام فوق أكبر عدد صحيح آمن ليست أسعارًا ولا مسافات صالحة (لا 1e+40)، وتُرفض عند الإدخال، وبيانات مخزَّنة بها تُعامَل مجهولة؛ والقيم الكبيرة المعقولة (500 مليار) تُقبل بلا سقف', async () => {
    const d = mk('dealer1'); const big = ['9'.repeat(40), '٣٥' + '٠'.repeat(30), '9007199254740992']; const rej = []; for (const v of big) { if ((await d.R(`createShowroomCar({ brand: 'B', model: 'p', year: '2020', price: ${JSON.stringify(v)}, currency: 'IQD' })`)).ok) rej.push('price:' + v); if ((await d.R(`createShowroomCar({ brand: 'B', model: 'm', year: '2020', price: '1000', mileage: ${JSON.stringify(v)}, currency: 'IQD' })`)).ok) rej.push('mileage:' + v); }
    const huge = d.R('validPrice(1e40)') === null && d.R('validMileage(1e30)') === null; const ok = (await d.R(`createShowroomCar({ brand: 'B', model: 'ok', year: '2020', price: '500000000000', currency: 'IQD' })`)).ok; return (rej.length === 0 && huge && ok && d.R('parseWholeNumber("9007199254740991")') === 9007199254740991) || { rej, huge, ok }; });
  await tc('J5) التحقق من الإدخال لا يكسر البيانات الصحيحة: 0 كم، الأرقام العربية/الفارسية، فواصل الآلاف، «25,000»، سنة 1980–2100، وهاتف +964 وعربي، والواتساب الدولي 964… يُطبَّع محليًا', async () => {
    const d = mk('dealer1'); const r = await d.R(`createShowroomCar({ brand: 'V', model: 'ok', year: '١٩٩٩', price: '٣٥٬٠٠٠٬٠٠٠', mileage: '٠', currency: 'IQD' })`); const m = mk('user'); const p1 = publish(m, memberData({ phone: '+9647700000099', whatsapp: '٠٧٧٠٠٠٠٠٠٩٩', mileage: '0', price: '1,500,000' })); const p2 = publish(mk('user'), memberData({ phone: '٠٧٧٠٠٠٠٠٠٩٩', whatsapp: '9647700000099' }));
    return (r.ok && r.car.year === 1999 && r.car.price === 35000000 && r.car.mileage === 0 && p1.ok && p1.car.phone === '07700000099' && p1.car.whatsapp === '07700000099' && p1.car.mileage === 0 && p1.car.price === 1500000 && p2.ok && p2.car.phone === '07700000099' && p2.car.whatsapp === '07700000099') || { r: r.car, p1: p1.car, p2: p2.car, e: [r.error, p1.error, p2.error] }; });
  await tc('J6) بيانات فاسدة مرفوضة بلا crash: سعر NaN/Infinity/سالب/0/1e3/0x10/12.5/abc، سنة 1979/2101/20/abc، كيلومترات سالبة/1e3/NaN، ماركة/موديل فارغ أو بلا حروف، (الشاشات والخدمات)', async () => {
    const d = mk('dealer1'); const u = mk('user', d.E.store); const bad = []; const sc = async o => (await d.R(`createShowroomCar(${JSON.stringify(Object.assign({ brand: 'V', model: 'k', year: '2020', price: '1000', currency: 'IQD' }, o))})`)).ok; const mem = o => u.J(`createDraftMemberCar(${JSON.stringify(memberData(o))})`).ok;
    for (const v of ['NaN', 'Infinity', '-5', '0', '1e3', '0x10', '12.5', 'abc', '']) { if (await sc({ price: v }) || mem({ price: v })) bad.push('price:' + v); }
    for (const v of ['1979', '2101', '20', 'abc', '-2020', '2020.5', 'NaN']) { if (await sc({ year: v }) || mem({ year: v })) bad.push('year:' + v); }
    for (const v of ['-5', '1e3', 'NaN', 'Infinity', '12.5', 'abc', '0x10']) { if (await sc({ mileage: v }) || mem({ mileage: v })) bad.push('km:' + v); }
    for (const v of ['', '   ', '---', '!!!', '<>', '\u200b\u200b']) { if (await sc({ brand: v }) || mem({ brand: v })) bad.push('brand:' + JSON.stringify(v)); if (await sc({ model: v }) || mem({ model: v })) bad.push('model:' + JSON.stringify(v)); }
    return bad.length === 0 || bad; });
  await tc('J7) (إصلاح) هاتف/واتساب إعلان العضو: نصوص حرّة (javascript:، وسوم، قصير) تُرفض في الإنشاء والتعديل ولا تُخزَّن؛ الصيغ الصالحة تُطبَّع', async () => {
    const u = mk('user'); const bad = []; for (const v of ['abc', '123', '<script>alert(1)</script>', 'javascript:alert(1)', '0770', '0770000009900000000', '"><img src=x onerror=alert(1)>']) { if (u.J(`createDraftMemberCar(${JSON.stringify(memberData({ phone: v }))})`).ok) bad.push('phone:' + v); if (u.J(`createDraftMemberCar(${JSON.stringify(memberData({ whatsapp: v }))})`).ok) bad.push('wa:' + v); }
    const p = publish(mk('user', u.E.store), memberData()); const up = []; if (p.ok) for (const v of ['javascript:alert(1)', '12']) { const idu = mk('user', u.E.store); if (idu.J(`updateMemberCar(${p.car.id}, { phone: ${JSON.stringify(v)} })`).ok) up.push('edit-phone:' + v); if (idu.J(`updateMemberCar(${p.car.id}, { whatsapp: ${JSON.stringify(v)} })`).ok) up.push('edit-wa:' + v); }
    const stored = JSON.stringify(u.J('MemberCarsRepository.getAll().map(c=>[c.phone,c.whatsapp])')); return (bad.length === 0 && up.length === 0 && !/javascript|<script|<img/.test(stored)) || { bad, up }; });
  await tc('J8) معرّفات فاسدة (null/undefined/NaN/نص/كائن/مصفوفة/سالب/كسر/Infinity) في كل دوال الخدمات لا ترمي استثناء ولا تنجح عملية', async () => {
    const d = mk('dealer1'); const bad = []; for (const code of ['null', 'undefined', 'NaN', '""', '"1"', '"1; DROP"', '{}', '[]', '[1]', 'true', '-1', '0', '1.5', 'Infinity']) for (const fn of [`updateShowroomCar(${code}, {price:'5'})`, `changeShowroomCarStatus(${code}, 'sold')`, `updateMemberCar(${code}, {price:'5'})`, `deleteMemberCar(${code})`, `changeMemberCarStatus(${code},'sold')`, `toggleFavorite(${code})`, `getVisibleCarById(${code})`, `getMemberCarAccess(${code})`]) {
      const r = d.R(`(function(){ try { const r = ${fn}; return r && typeof r.then === 'function' ? 'PROMISE' : JSON.stringify(r === undefined ? null : r); } catch (e) { return 'THROW ' + e.message; } })()`); if (/THROW/.test(r)) bad.push(fn + ' ' + r); if (/"ok":true/.test(r || '')) bad.push('OK:' + fn); }
    return bad.length === 0 || bad.slice(0, 4); });

  /* ======================= K) XSS ======================= */
  console.log('\n--- K) XSS / الأمان ---');
  const PAY = ['"><img src=x onerror=alert(1)>', "');alert(1);//", '<script>alert(1)</script>', '</textarea><svg onload=alert(1)>', 'javascript:alert(1)', "' onmouseover='alert(1)"];
  await tc('K1) esc يهرّب & < > " والفاصلة العليا \' (دفاع إضافي)، ولا يُخرج [object Object] ولا NaN', async () => {
    const x = mk(null); return (x.R(`esc(${JSON.stringify(`<a href="x" onclick='y'>&`)})`) === '&lt;a href=&quot;x&quot; onclick=&#39;y&#39;&gt;&amp;' && x.R('esc({})') === '' && x.R('esc(NaN)') === '' && x.R('esc(null)') === '' && x.R('esc("O\'Brien")') === 'O&#39;Brien') || 'esc'; });
  await tc('K2) حقن حمولات XSS في كل حقل يدخله المستخدم (ماركة/موديل/لون/وصف/موقع/هاتف/أسباب/اسم معرض/عنوان/اسم مستخدم…) ثم رسم كل الشاشات لكل الأدوار: لا وسم خام ولا حمولة داخل معالج on* ولا javascript: في href/src ولا فاصلة عليا خام تكسر سمة', async () => {
    const a = mk('admin'); a.R(`(function(){ const pay = ${JSON.stringify(PAY)}; let i = 0; const p = () => pay[i++ % pay.length];
      ShowroomsRepository.getAll().forEach(s => { s.name = p(); s.description = p(); s.address = p(); s.phone = p(); s.whatsapp = p(); s.workingHours = p(); s.image = p(); }); ShowroomsRepository.save();
      CarsRepository.getAll().forEach(c => { c.brand = p(); c.model = p(); c.color = p(); c.description = p(); c.transmission = p(); c.fuelType = p(); c.mainImage = p(); }); CarsRepository.save();
      MemberCarsRepository.getAll().forEach(c => { c.brand = p(); c.model = p(); c.color = p(); c.description = p(); c.location = p(); c.phone = p(); c.whatsapp = p(); c.rejectionReason = p(); c.suspensionReason = p(); c.mainImage = p(); }); MemberCarsRepository.save();
      UsersRepository.getAll().forEach(u => { u.name = p(); u.email = p() + '@x.com'; }); UsersRepository.save(); })()`);
    const screens = [['home'], ['showrooms'], ['cars'], ['memberCars'], ['map'], ['favorites'], ['account'], ['dealerHome'], ['adminHome'], ['adminMemberCars'], ['adminShowrooms'], ['adminShowroomCars'], ['adminUsers'], ['adminDealerRequests'], ['myMemberCars'], ['myShowroomCars'], ['addMemberCar'], ['addShowroomCar']];
    for (const i of a.J('ShowroomsRepository.getAll().map(s=>s.id)')) screens.push(['showroomDetails', i]); for (const i of a.J('CarsRepository.getAll().map(c=>c.id)')) { screens.push(['carDetails', i]); screens.push(['editShowroomCar', i]); } for (const i of a.J('MemberCarsRepository.getAll().map(c=>c.id)')) { screens.push(['memberCarDetails', i]); screens.push(['adminMemberCarDetails', i]); screens.push(['editMemberCar', i]); } for (const i of a.J('UsersRepository.getAll().map(u=>u.id)')) screens.push(['adminUserDetails', i]); for (const q of PAY) screens.push(['search', q]);
    const bad = new Set(); let n = 0;
    const scan = (html, where) => { n++; if (/<img src=x onerror=alert\(1\)>|<script>alert\(1\)<\/script>|<svg onload=alert\(1\)>/.test(html)) bad.add(where + ':raw-tag'); if (/onmouseover='alert\(1\)/.test(html)) bad.add(where + ':raw-single-quote'); for (const m of html.matchAll(/\son\w+="([^"]*)"/g)) if (/alert\(1\)/.test(m[1])) bad.add(where + ':in-handler'); for (const m of html.matchAll(/\s(?:href|src)="([^"]*)"/g)) if (/^\s*javascript:/i.test(m[1])) bad.add(where + ':js-url'); };
    for (const role of [null, 'user', 'dealer1', 'admin']) { const x = mk(role, a.E.store); if (role) x.R('getVisibleCars().slice(0,6).forEach(c => toggleFavorite(c.id)); getVisibleMemberCars().slice(0,4).forEach(c => toggleFavorite(c.id));');
      for (const [r, param] of screens) { try { x.R(param === undefined ? `go('${r}')` : `go('${r}', ${JSON.stringify(param)})`); scan(x.E.screen(), `${role}:${r}`); } catch (e) { bad.add(`${role}:${r}:EXC`); } }
      for (const pay of PAY) { x.R(`go('cars')`); x.R(`onCarsSearch(${JSON.stringify(pay)})`); scan(x.E.screen(), role + ':cars-q'); x.R(`go('memberCars')`); x.R(`onMemberCarsSearch(${JSON.stringify(pay)})`); scan(x.E.screen(), role + ':member-q'); x.R(`go('cars')`); x.E.els.carsFilterBrand = { value: pay, style: {} }; x.R('onCarsFilter()'); scan((x.E.els.carsFilterBar || {}).innerHTML || '', role + ':filters'); } }
    return (bad.size === 0 && n > 400) || { n, bad: [...bad].slice(0, 6) }; });
  await tc('K3) روابط التواصل: tel: وwa.me وخرائط فقط ومن أرقام خالصة — هاتف/واتساب/إحداثيات معطوبة (javascript:، وسوم، نصوص) لا تنتج رابطًا ولا مخطط آخر', async () => {
    const x = mk(null); const L = c => x.R(c); const links = [L(`telLink('javascript:alert(1)')`), L(`telLink('"><img src=x onerror=alert(1)>')`), L(`waLink('javascript:alert(1)')`), L(`waLink('<script>')`), L(`mapLink('javascript:1','2')`), L(`mapLink('<b>', '1')`)];
    const ok = [L(`telLink('07700000099')`), L(`waLink('07700000099')`), L(`mapLink(31.99, 44.32)`)]; return (links.every(v => v === '') && /^tel:\+?\d+$/.test(ok[0]) && /^https:\/\/wa\.me\/\d+$/.test(ok[1]) && /^https:\/\/www\.google\.com\/maps\?q=[\d.\-]+,[\d.\-]+$/.test(ok[2])) || { links, ok }; });
  await tc('K4) رسائل الخدمات والإشعارات لا تُدرج مدخلات المستخدم الخام (لا حمولة في error)، وكل innerHTML في التطبيق يعيد قالبًا مهرَّبًا (لا إسناد innerHTML من نص مستخدم مباشر)', async () => {
    const u = mk('user'); const leaks = []; for (const pay of PAY) { const r = u.J(`createDraftMemberCar({ brand: ${JSON.stringify(pay)}, model: ${JSON.stringify(pay)}, year: ${JSON.stringify(pay)}, price: ${JSON.stringify(pay)}, phone: ${JSON.stringify(pay)}, currency: ${JSON.stringify(pay)} })`); if (r && r.error && /alert\(1\)|<script|<img/.test(r.error)) leaks.push(r.error); }
    const direct = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('navigation'), ['app.js']).filter(f => /innerHTML\s*=\s*(?:_val|value|e\.|event\.|this\.value)/.test(strip(read(f)))); return (leaks.length === 0 && direct.length === 0) || { leaks, direct }; });

  /* ======================= L) توثيق ======================= */
  console.log('\n--- L) التوثيق ---');
  await tc('L1) README: قسم الجزء 6.1 موجود ويذكر الإصلاحات والقيود وسعر الصرف التجريبي الثابت؛ ولم يُذكر الجزء 6.2/6.3 كمُنفَّذ', async () => {
    const rd = read('README.md'); const i = rd.indexOf('الجزء 6.1'); const rest = i >= 0 ? rd.slice(i) : ''; const nx = rest.indexOf('\n## ', 4); const sec = nx > 0 ? rest.slice(0, nx) : rest;   /* قسم 6.1 وحده: الأقسام اللاحقة (6.2-A…) تُضاف بعده في README ولا تخصّه */ return (sec.length > 400 && /Prototype static exchange rate/i.test(sec) && /storage/.test(sec) && !/الجزء 6\.2|الجزء 6\.3/.test(sec.replace(/لم يُبدأ[^\n]*/g, ''))) || { len: sec.length }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

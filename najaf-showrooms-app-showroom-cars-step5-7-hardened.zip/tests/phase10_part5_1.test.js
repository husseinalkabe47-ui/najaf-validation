/* اختبارات «المرحلة 10 — الجزء 5.1: اقتراحات السعر والكيلومترات» (Phase 10 Part 5.1).
   الاقتراحات طبقة راحة فقط فوق حقول من/إلى القائمة: اختيار اقتراح يكتب الحقلين ثم يستدعي معالج النطاق القائم (readFilters ← CarFilters)،
   فلا حالة ثانية ولا محرك بحث/فلترة ثانٍ ولا تخزين. كل نقر هنا يُنفَّذ من نص onclick الفعلي في HTML المُولَّد (كما يفعل المتصفح).
   تغطي: القيم الدقيقة للنطاقات · الحالة والشارات والنتائج · مسح الفلاتر/إزالة الشارة · الإدخال المخصص بعد الاقتراح · قيم كبيرة بلا سقف ·
         الأرقام العربية · 0 كم والمجهول · min>max والإدخال غير الصالح · الظهور · الشاشات الثلاث · الإغلاق (نقرة خارجية/Escape/Enter) · الوصول · CSS · فحوص ثابتة. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const idsOf = html => [...new Set([...String(html).matchAll(/go\('(?:carDetails|memberCarDetails)',(\d+)\)/g)].map(m => Number(m[1])))];
const BAD = /undefined|\bnull\b|NaN|\[object|TypeError|ReferenceError/;
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const money = n => Number(n).toLocaleString('ar-IQ');
const addCar = (x, o) => x.R(`CarsRepository.create(CarModel(Object.assign({ sourceType:'showroom', showroomId: 1, brand:'P', model:'M', year: 2020, price: 1000, mileage: 1000, status:'available' }, ${JSON.stringify(o)}))).ok`);
const addMember = (x, o) => x.R(`MemberCarsRepository.create(CarModel(Object.assign({ sourceType:'member', ownerId: 7, brand:'P', model:'M', year: 2020, price: 1000, mileage: 1000, status:'active' }, ${JSON.stringify(o)}))).ok`);

/** يضبط حقلًا كما يكتب المستخدم (عنصر وهمي في الحزام) */
const setFld = (x, prefix, k, v) => { x.E.els[prefix + 'Filter' + k] = Object.assign(x.E.els[prefix + 'Filter' + k] || { style: {} }, { value: String(v) }); };
const fld = (x, prefix, k) => (x.E.els[prefix + 'Filter' + k] || {}).value;
/** خيارات لوحة اقتراحات من HTML الشاشة: [{ min, max, pressed, aria, onclick, text }] (الأخير «إدخال مخصص» لا يدخل لأنه بلا data-min) */
const OPT_RE = /<button type="button" class="sugg-opt" data-min="(\d*)" data-max="(\d*)" aria-pressed="(true|false)" aria-label="([^"]*)" onmousedown="[^"]*" onclick="([^"]*)">([\s\S]*?)<\/button>/g;
const panelHtml = (html, id) => (String(html).match(new RegExp(`<div class="flt-sugg" id="${id}"[\\s\\S]*?<\\/div>`)) || [''])[0];
const optsOf = (html, id) => [...panelHtml(html, id).matchAll(OPT_RE)].map(m => ({ min: m[1], max: m[2], pressed: m[3] === 'true', aria: m[4], onclick: m[5], text: m[6].replace(/<[^>]*>/g, '').trim() }));
/** ينقر الاقتراح (min,max) في لوحة id بتنفيذ نص onclick الفعلي؛ detail=1 نقر/لمس، detail=0 لوحة مفاتيح */
const clickOpt = (x, id, min, max, detail = 1) => {
  const o = optsOf(x.E.screen(), id).find(p => p.min === String(min) && p.max === String(max));
  if (!o) throw new Error(`لا اقتراح ${min}–${max} في ${id}`);
  x.R(`var event = { detail: ${detail} };`); x.R(o.onclick); return o;
};
const chipsHtml = (x, prefix) => (x.E.els[prefix + 'FilterChips'] || {}).innerHTML || '';
const chipTexts = html => [...String(html).matchAll(/<button type="button" class="filter-chip"[^>]*>\s*<span>([\s\S]*?)<\/span>/g)].map(m => m[1]);
const listIds = (x, listId) => idsOf((x.E.els[listId] || {}).innerHTML);

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) اللوحات والقيم ======================= */
  console.log('\n--- A) اللوحات والقيم ---');
  const PRICE_EXPECT = [['', 10000000], [10000000, 20000000], [20000000, 30000000], [30000000, 40000000], [40000000, 60000000], [60000000, 100000000], [100000000, '']];
  const MILE_EXPECT = [[0, 10000], [10000, 30000], [30000, 50000], [50000, 100000], [100000, 150000], [150000, 200000], [200000, '']];
  await tc('A1) اقتراحات السعر: أقل من 10 مليون، 10–20، 20–30، 30–40، 40–60، 60–100، 100 فأكثر + «إدخال مخصص» (القيم دقيقة، والأخير بلا حد أقصى)', async () => {
    const x = mk(null); x.R(`go('cars')`); const html = x.E.screen(), o = optsOf(html, 'carsSuggPrice');
    const got = o.map(p => [p.min, p.max]); const want = PRICE_EXPECT.map(p => [String(p[0]), String(p[1])]);
    return (JSON.stringify(got) === JSON.stringify(want) && panelHtml(html, 'carsSuggPrice').includes('إدخال مخصص')) || { got }; });
  await tc('A2) اقتراحات الكيلومترات: 0–10 ألف، 10–30، 30–50، 50–100، 100–150، 150–200، 200 ألف فأكثر + «إدخال مخصص» (0 قيمة حقيقية، والأخير بلا حد أقصى)', async () => {
    const x = mk(null); x.R(`go('cars')`); const html = x.E.screen(), o = optsOf(html, 'carsSuggMileage');
    const got = o.map(p => [p.min, p.max]); const want = MILE_EXPECT.map(p => [String(p[0]), String(p[1])]);
    return (JSON.stringify(got) === JSON.stringify(want) && panelHtml(html, 'carsSuggMileage').includes('إدخال مخصص')) || { got }; });
  await tc('A3) نص كل اقتراح بصيغة الشارات نفسها (أرقام ar-IQ): «أقل من ١٠ مليون» «١٠–٢٠ مليون» «١٠٠ مليون فأكثر» «٠–١٠٬٠٠٠ كم» «٢٠٠٬٠٠٠ كم فأكثر»', async () => {
    const x = mk(null); x.R(`go('cars')`); const html = x.E.screen(); const P = optsOf(html, 'carsSuggPrice').map(p => p.text.replace(/^✓\s*/, '')), M = optsOf(html, 'carsSuggMileage').map(p => p.text.replace(/^✓\s*/, ''));
    return (P[0] === `أقل من ${money(10)} مليون` && P[1] === `${money(10)}–${money(20)} مليون` && P[6] === `${money(100)} مليون فأكثر` &&
      M[0] === `${money(0)}–${money(10000)} كم` && M[3] === `${money(50000)}–${money(100000)} كم` && M[6] === `${money(200000)} كم فأكثر`) || { P, M }; });
  await tc('A4) الشاشات الثلاث (السيارات/الأعضاء/البحث) فيها لوحتا السعر والكيلومترات فقط (لا لوحة لماركة/موديل/سنة)، بمعرّفات فريدة لكل شاشة، ومخفية افتراضيًا', async () => {
    const x = mk(null); const out = {};
    [['cars', `go('cars')`], ['member', `go('memberCars')`], ['search', `go('search','toyota')`]].forEach(([p, c]) => { x.R(c); const h = x.E.screen(); const ids = [...h.matchAll(/<div class="flt-sugg" id="([^"]+)"[^>]*\bhidden>/g)].map(m => m[1]); out[p] = ids; });
    return (JSON.stringify(out.cars) === '["carsSuggPrice","carsSuggMileage"]' && JSON.stringify(out.member) === '["memberSuggPrice","memberSuggMileage"]' && JSON.stringify(out.search) === '["searchSuggPrice","searchSuggMileage"]') || out; });
  await tc('A5) حقول السعر والكيلومترات تفتح اللوحة عند التركيز والنقر (data-sugg + onfocus + onclick)؛ بقية الحقول بلا ذلك؛ ولا datalist', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const inp = id => (h.match(new RegExp(`<input id="${id}"[^>]*>`)) || [''])[0];
    const sug = ['MinPrice', 'MaxPrice'].map(k => inp('carsFilter' + k)).concat(['MinMileage', 'MaxMileage'].map(k => inp('carsFilter' + k)));
    const okS = sug.every((s, i) => { const kind = i < 2 ? 'Price' : 'Mileage'; return s.includes(`data-sugg="${kind}"`) && s.includes(`onfocus="openFilterSuggestions('cars','${kind}')"`) && s.includes(`onclick="openFilterSuggestions('cars','${kind}')"`); });
    const sels = [...h.matchAll(/<select[^>]*>/g)].map(m => m[0]);
    return (okS && sels.length === 4 && sels.filter(s => /id="carsPriceCurrency"/.test(s)).length === 1 && sels.every(s => !/data-sugg|onfocus/.test(s)) && !/<datalist/i.test(h)) || { sug, sels }; });   // الجزء 5.2: قائمة «عملة البحث» (carsPriceCurrency) أضافت قائمة رابعة؛ لا اقتراحات عليها
  await tc('A6) الحقول القائمة محفوظة: المعرّفات والتسميات «السعر من/إلى (د.ع)» «الكيلومترات من/إلى» وplaceholder «بلا حد أدنى/أقصى» وترتيب الحقول (ماركة ← موديل ← سنة ← سعر ← كيلومترات)', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen();
    const order = ['carsFilterBrand', 'carsFilterModel', 'carsFilterYear', 'carsFilterMinPrice', 'carsFilterMaxPrice', 'carsFilterMinMileage', 'carsFilterMaxMileage'].map(i => h.indexOf(`id="${i}"`));
    return (order.every((v, i) => v > 0 && (i === 0 || v > order[i - 1])) && h.includes('السعر من (د.ع)') && h.includes('السعر إلى (د.ع)') && h.includes('الكيلومترات من') && h.includes('الكيلومترات إلى') &&
      (h.match(/placeholder="بلا حد أدنى"/g) || []).length === 2 && (h.match(/placeholder="بلا حد أقصى"/g) || []).length === 2) || order; });
  await tc('A7) لا «null/undefined/NaN» في HTML أي شريط فلاتر (الحد المفتوح يُكتب نصًا فارغًا)', async () => {
    const x = mk(null); const bad = [];
    [`go('cars')`, `go('memberCars')`, `go('search','toyota')`].forEach(c => { x.R(c); const h = x.E.screen(); if (BAD.test(h)) bad.push(c + ':' + (h.match(BAD) || [])[0]); });
    return bad.length === 0 || bad; });

  /* ======================= B) السلوك: القيم والحالة ======================= */
  console.log('\n--- B) اختيار اقتراح ← الحقول والحالة ---');
  await tc('B1) اقتراح السعر «١٠–٢٠ مليون» ← min = 10000000 و max = 20000000 في الحقلين وفي carsFilters', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); const st = J(x, 'carsFilters');
    return (fld(x, 'cars', 'MinPrice') === '10000000' && fld(x, 'cars', 'MaxPrice') === '20000000' && st.minPrice === '10000000' && st.maxPrice === '20000000') || { st, f: [fld(x, 'cars', 'MinPrice'), fld(x, 'cars', 'MaxPrice')] }; });
  await tc('B2) اقتراح السعر «١٠٠ مليون فأكثر» ← min = 100000000 و max فارغ (بلا حد = تمثيل المحرك: null)', async () => {
    const x = mk(null); x.R(`go('cars')`); setFld(x, 'cars', 'MaxPrice', '5'); clickOpt(x, 'carsSuggPrice', 100000000, '');   // max كان مكتوبًا: يُفرَّغ
    const st = J(x, 'carsFilters'), n = J(x, 'CarFilters.normalize(carsFilters)');
    return (fld(x, 'cars', 'MinPrice') === '100000000' && fld(x, 'cars', 'MaxPrice') === '' && st.maxPrice === '' && n.minPrice === 100000000 && n.maxPrice === null) || { st, n }; });
  await tc('B3) اقتراح السعر «أقل من ١٠ مليون» ← min فارغ (لا 0) و max = 10000000', async () => {
    const x = mk(null); x.R(`go('cars')`); setFld(x, 'cars', 'MinPrice', '99'); clickOpt(x, 'carsSuggPrice', '', 10000000); const n = J(x, 'CarFilters.normalize(carsFilters)');
    return (fld(x, 'cars', 'MinPrice') === '' && n.minPrice === null && n.maxPrice === 10000000) || n; });
  await tc('B4) اقتراح الكيلومترات «٥٠٬٠٠٠–١٠٠٬٠٠٠ كم» ← min = 50000 و max = 100000', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggMileage', 50000, 100000); const st = J(x, 'carsFilters');
    return (fld(x, 'cars', 'MinMileage') === '50000' && fld(x, 'cars', 'MaxMileage') === '100000' && st.minMileage === '50000' && st.maxMileage === '100000') || st; });
  await tc('B5) اقتراح الكيلومترات «٢٠٠٬٠٠٠ كم فأكثر» ← min = 200000 و max فارغ (null في المحرك)', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggMileage', 200000, ''); const n = J(x, 'CarFilters.normalize(carsFilters)');
    return (fld(x, 'cars', 'MinMileage') === '200000' && fld(x, 'cars', 'MaxMileage') === '' && n.minMileage === 200000 && n.maxMileage === null) || n; });
  await tc('B6) اختيار اقتراح يحدّث حالة الشاشة القائمة carsFilters فقط: الحقول الأخرى (ماركة/موديل/سنة) بلا تغيير، والاقتراح السعري لا يمسّ حقول الكيلومترات والعكس', async () => {
    const x = mk(null); x.R(`go('cars')`); setFld(x, 'cars', 'Brand', 'Toyota'); setFld(x, 'cars', 'Year', '2022'); x.R('onCarsFilter()');
    clickOpt(x, 'carsSuggPrice', 20000000, 30000000); const a = J(x, 'carsFilters'); clickOpt(x, 'carsSuggMileage', 10000000 / 1000, 30000); const b = J(x, 'carsFilters');
    return (a.brand === 'Toyota' && a.year === '2022' && a.minMileage === '' && b.minPrice === '20000000' && b.maxPrice === '30000000' && b.minMileage === '10000' && b.maxMileage === '30000') || { a, b }; });
  await tc('B7) شارات الفلاتر القائمة تعكس النطاق المختار فورًا (سعر: «١٠–٢٠ مليون»، كيلومترات: «٥٠٬٠٠٠–١٠٠٬٠٠٠ كم») وهي نفسها شارات CarFilters', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); clickOpt(x, 'carsSuggMileage', 50000, 100000);
    const tx = chipTexts(chipsHtml(x, 'cars')), eng = J(x, 'CarFilters.chips(carsFilters).map(k=>k.label)');
    return (JSON.stringify(tx) === JSON.stringify([`${money(10)}–${money(20)} مليون`, `${money(50000)}–${money(100000)} كم`]) && JSON.stringify(tx) === JSON.stringify(eng)) || { tx, eng }; });
  await tc('B8) نتائج القائمة بعد الاختيار = السيارات الظاهرة التي سعرها ضمن النطاق (حدّان شاملان) محسوبةً يدويًا من البركة العامة، لا من المحرك', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9101, price: 10000000 }); addCar(x, { id: 9102, price: 20000000 }); addCar(x, { id: 9103, price: 20000001 }); addCar(x, { id: 9104, price: 9999999 });
    clickOpt(x, 'carsSuggPrice', 10000000, 20000000); const got = listIds(x, 'carsList'), want = J(x, `getPublicCars('showroom').filter(c => c.price >= 10000000 && c.price <= 20000000).map(c => c.id)`);
    return (same(got, want) && got.includes(9101) && got.includes(9102) && !got.includes(9103) && !got.includes(9104) && got.length > 2) || { got, want }; });
  await tc('B9) «أقل من ١٠ مليون» و«١٠٠ مليون فأكثر» و«٠–١٠٬٠٠٠ كم» و«٢٠٠٬٠٠٠ كم فأكثر»: النتائج تطابق الحساب اليدوي (والسعر المجهول لا يظهر كصفر)', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9111, price: 5000000 }); addCar(x, { id: 9112, price: 100000000 }); addCar(x, { id: 9113, price: 450000000 }); addCar(x, { id: 9114, price: 0 }); addCar(x, { id: 9115, price: null });
    addCar(x, { id: 9116, mileage: 0 }); addCar(x, { id: 9117, mileage: 200000 }); addCar(x, { id: 9118, mileage: 1500000 }); addCar(x, { id: 9119, mileage: null });
    /* في الحزام الحقول عناصر وهمية دائمة (المتصفح يعيد بناءها من الحالة عند كل رسم): نفرّغها يدويًا بعد المسح */
    const run = (id, a, b, listBrute) => { x.R('clearCarsFilters()'); ['MinPrice', 'MaxPrice', 'MinMileage', 'MaxMileage'].forEach(k => setFld(x, 'cars', k, '')); clickOpt(x, id, a, b); return [listIds(x, 'carsList'), J(x, `getPublicCars('showroom').filter(${listBrute}).map(c => c.id)`)]; };
    const r1 = run('carsSuggPrice', '', 10000000, 'c => typeof c.price === "number" && c.price > 0 && c.price <= 10000000');
    const r2 = run('carsSuggPrice', 100000000, '', 'c => typeof c.price === "number" && c.price >= 100000000');
    const r3 = run('carsSuggMileage', 0, 10000, 'c => typeof c.mileage === "number" && c.mileage >= 0 && c.mileage <= 10000');
    const r4 = run('carsSuggMileage', 200000, '', 'c => typeof c.mileage === "number" && c.mileage >= 200000');
    return (same(r1[0], r1[1]) && r1[0].includes(9111) && !r1[0].includes(9114) && !r1[0].includes(9115) && same(r2[0], r2[1]) && r2[0].includes(9112) && r2[0].includes(9113) &&
      same(r3[0], r3[1]) && r3[0].includes(9116) && !r3[0].includes(9119) && same(r4[0], r4[1]) && r4[0].includes(9117) && r4[0].includes(9118)) || { r1, r2, r3, r4 }; });

  /* ======================= C) المسح والإزالة ======================= */
  console.log('\n--- C) مسح الفلاتر وإزالة الشارة ---');
  await tc('C1) «مسح الفلاتر» يمسح أثر الاقتراح: carsFilters نظيفة، حقلا السعر والكيلومترات فارغان في HTML، لا شارات، ولا اقتراح مضغوط (aria-pressed=false)', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); clickOpt(x, 'carsSuggMileage', 0, 10000);
    t('C1.0) قبل المسح: شارتان فعّالتان', chipTexts(chipsHtml(x, 'cars')).length === 2);
    x.R('clearCarsFilters()'); const h = x.E.screen(), st = J(x, 'carsFilters'), pr = optsOf(h, 'carsSuggPrice'), mi = optsOf(h, 'carsSuggMileage');
    const vals = ['MinPrice', 'MaxPrice', 'MinMileage', 'MaxMileage'].map(k => (h.match(new RegExp(`<input id="carsFilter${k}"[^>]*value="([^"]*)"`)) || [])[1]);
    return (J(x, 'CarFilters.activeCount(carsFilters)') === 0 && st.minPrice === '' && st.maxPrice === '' && st.minMileage === '' && st.maxMileage === '' && vals.every(v => v === '') && pr.length === 7 && mi.length === 7 && pr.concat(mi).every(o => !o.pressed) && !h.includes('active-filters')) || { st, vals }; });
  await tc('C2) إزالة شارة «السعر» (×) تُفرّغ حقلي السعر وتلغي تمييز الاقتراح وتُبقي نطاق الكيلومترات كما هو', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); clickOpt(x, 'carsSuggMileage', 50000, 100000);
    x.R(`removeCarsFilter('price')`); const bar = x.E.els.carsFilterBar.innerHTML, st = J(x, 'carsFilters'); const pr = optsOf(bar, 'carsSuggPrice'), mi = optsOf(bar, 'carsSuggMileage');
    return (st.minPrice === '' && st.maxPrice === '' && st.minMileage === '50000' && pr.every(o => !o.pressed) && mi.find(o => o.min === '50000' && o.max === '100000').pressed) || { st }; });
  await tc('C3) لا حالة محفوظة: الاقتراح لا يكتب شيئًا في التخزين، وإعادة التحميل تبدأ نظيفة (لا يُستعاد الاقتراح)', async () => {
    const x = mk(null); x.R(`go('cars')`); const before = JSON.stringify(x.E.store);
    clickOpt(x, 'carsSuggPrice', 10000000, 20000000); clickOpt(x, 'carsSuggMileage', 50000, 100000); const after = JSON.stringify(x.E.store);
    const y = mk(null, x.E.store); y.R(`go('cars')`); const st = J(y, 'carsFilters');
    return (before === after && st.minPrice === '' && st.maxMileage === '' && optsOf(y.E.screen(), 'carsSuggPrice').every(o => !o.pressed)) || { same: before === after, st }; });
  await tc('C4) إعادة رسم الشريط (تغيير الماركة) تُبقي النطاق المختار ويُميَّز الاقتراح الموافق له (aria-pressed=true مع ✓) دون أي حالة إضافية', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 20000000, 30000000); setFld(x, 'cars', 'Brand', 'Toyota'); x.R('onCarsFilter()');
    const bar = x.E.els.carsFilterBar.innerHTML, ph = panelHtml(bar, 'carsSuggPrice'), pr = optsOf(bar, 'carsSuggPrice'), on = pr.filter(o => o.pressed);
    const shown = (ph.match(/<span class="sugg-check" aria-hidden="true">✓<\/span>/g) || []).length, hiddenChk = (ph.match(/<span class="sugg-check" aria-hidden="true" hidden>✓<\/span>/g) || []).length;
    return (on.length === 1 && on[0].min === '20000000' && on[0].max === '30000000' && shown === 1 && hiddenChk === 6) || { on, shown, hiddenChk }; });

  /* ======================= D) الإدخال اليدوي بعد الاقتراح ======================= */
  console.log('\n--- D) الإدخال المخصص ---');
  await tc('D1) بعد اختيار اقتراح يعدّل المستخدم «إلى» فقط: min من الاقتراح يبقى، max الجديد يُعتمد، والنتائج والشارة تتبع القيمة المخصصة', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9201, price: 25000000 }); clickOpt(x, 'carsSuggPrice', 10000000, 20000000);
    t('D1.0) 25 مليون خارج 10–20', !listIds(x, 'carsList').includes(9201));
    setFld(x, 'cars', 'MaxPrice', '25000000'); x.R('onCarsRange()'); const st = J(x, 'carsFilters');
    return (st.minPrice === '10000000' && st.maxPrice === '25000000' && listIds(x, 'carsList').includes(9201) && chipTexts(chipsHtml(x, 'cars'))[0] === `${money(10)}–${money(25)} مليون`) || st; });
  await tc('D2) تعديل «من» فقط بعد الاقتراح، ثم تعديل الاثنين بقيم غير مليونية (12٬٥٠٠٬٠٠٠–١٧٬٢٥٠٬٠٠٠) يعمل ويعطي الشارة بالأرقام الكاملة', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); setFld(x, 'cars', 'MinPrice', '12500000'); x.R('onCarsRange()');
    const a = J(x, 'carsFilters'); setFld(x, 'cars', 'MaxPrice', '17250000'); x.R('onCarsRange()'); const b = J(x, 'carsFilters');
    return (a.minPrice === '12500000' && a.maxPrice === '20000000' && b.maxPrice === '17250000' && chipTexts(chipsHtml(x, 'cars'))[0].includes(money(12500000))) || { a, b }; });
  await tc('D3) أسعار أكبر من كل الاقتراحات تُقبل بلا سقف: 150٬000٬000 و250٬000٬000 و500٬000٬000 و5 مليار (حقل «من» و«إلى»)، بلا رسالة خطأ، والنتائج صحيحة', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9211, price: 150000000 }); addCar(x, { id: 9212, price: 250000000 }); addCar(x, { id: 9213, price: 500000000 }); addCar(x, { id: 9214, price: 5000000000 });
    const probe = (lo, hi) => { setFld(x, 'cars', 'MinPrice', lo); setFld(x, 'cars', 'MaxPrice', hi); x.R('onCarsRange()'); return [listIds(x, 'carsList'), J(x, `CarFilters.validate(carsFilters)`), chipsHtml(x, 'cars')]; };
    const a = probe('150000000', ''), b = probe('250000000', '500000000'), c = probe('', '5000000000'), d = probe('5000000000', '');
    return (a[0].includes(9211) && a[0].includes(9214) && a[1].length === 0 && b[0].includes(9212) && b[0].includes(9213) && !b[0].includes(9214) && b[1].length === 0 && c[0].includes(9214) && c[1].length === 0 && d[0].includes(9214) && !d[0].includes(9213) && d[1].length === 0 &&
      !a[2].includes('filter-note')) || { a, b, c, d }; });
  await tc('D4) بعد اقتراح «١٠٠ مليون فأكثر» يمكن كتابة «إلى» مخصصًا كبيرًا (٣٠٠٬٠٠٠٬٠٠٠) فيُعتمد بلا سقف', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9221, price: 250000000 }); addCar(x, { id: 9222, price: 350000000 }); clickOpt(x, 'carsSuggPrice', 100000000, '');
    setFld(x, 'cars', 'MaxPrice', '300000000'); x.R('onCarsRange()'); const got = listIds(x, 'carsList');
    return (got.includes(9221) && !got.includes(9222) && J(x, 'carsFilters').maxPrice === '300000000') || got; });
  await tc('D5) كيلومترات أكبر من كل الاقتراحات تُقبل بلا سقف: 350٬000 و1٬500٬000 كم، بلا رسالة خطأ', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9231, mileage: 350000 }); addCar(x, { id: 9232, mileage: 1500000 }); clickOpt(x, 'carsSuggMileage', 200000, '');
    setFld(x, 'cars', 'MinMileage', '300000'); setFld(x, 'cars', 'MaxMileage', '1500000'); x.R('onCarsRange()'); const got = listIds(x, 'carsList'), v = J(x, 'CarFilters.validate(carsFilters)');
    setFld(x, 'cars', 'MinMileage', '1500001'); setFld(x, 'cars', 'MaxMileage', ''); x.R('onCarsRange()'); const none = listIds(x, 'carsList');
    return (got.includes(9231) && got.includes(9232) && v.length === 0 && !none.includes(9232)) || { got, v, none }; });
  await tc('D6) الأرقام العربية والفارسية والفواصل تعمل بعد الاقتراح وفي الحقول: «٢٥٬٠٠٠٬٠٠٠» و«۳۰۰۰۰۰۰۰» و«٠» كيلومتر', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9241, price: 27000000, mileage: 0 }); clickOpt(x, 'carsSuggPrice', 20000000, 30000000);
    setFld(x, 'cars', 'MinPrice', '٢٥٬٠٠٠٬٠٠٠'); setFld(x, 'cars', 'MaxPrice', '۳۰۰۰۰۰۰۰'); setFld(x, 'cars', 'MinMileage', '٠'); setFld(x, 'cars', 'MaxMileage', '٥٠٠٠'); x.R('onCarsRange()');
    const n = J(x, 'CarFilters.normalize(carsFilters)'), got = listIds(x, 'carsList');
    return (n.minPrice === 25000000 && n.maxPrice === 30000000 && n.minMileage === 0 && n.maxMileage === 5000 && got.includes(9241)) || { n, got }; });
  await tc('D7) تمييز الاقتراح يفهم الأرقام العربية: النطاق المكتوب «١٠٠٠٠٠٠٠–٢٠٠٠٠٠٠٠» بأرقام عربية يُميِّز اقتراح 10–20 عند فتح اللوحة (قراءة الحقلين عبر CarFilters.normalize)', async () => {
    const x = mk(null); x.R(`go('cars')`); const btn = (min, max, pressed) => { const attrs = { 'aria-pressed': String(pressed) }; return { dataMin: min, dataMax: max, attrs, chk: { hidden: !pressed }, getAttribute(n) { return n === 'data-min' ? this.dataMin : this.dataMax; }, setAttribute(n, v) { this.attrs[n] = v; }, querySelector() { return this.chk; } }; };
    const bs = [btn('10000000', '20000000', false), btn('20000000', '30000000', false), btn('', '10000000', false)];
    x.E.els.carsSuggPrice = { hidden: true, querySelectorAll: () => bs, scrollIntoView() {} };
    setFld(x, 'cars', 'MinPrice', '١٠٠٠٠٠٠٠'); setFld(x, 'cars', 'MaxPrice', '٢٠٠٠٠٠٠٠'); x.R(`openFilterSuggestions('cars','Price')`);
    const r = bs.map(b => b.attrs['aria-pressed']), chk = bs.map(b => b.chk.hidden);
    return (JSON.stringify(r) === '["true","false","false"]' && JSON.stringify(chk) === '[false,true,true]' && x.E.els.carsSuggPrice.hidden === false) || { r, chk }; });
  await tc('D8) 0 كم قيمة حقيقية: اقتراح «٠–١٠٬٠٠٠ كم» يكتب min=0 (لا يُفرَّغ)، الشارة «٠–١٠٬٠٠٠ كم»، وسيارة بـ0 كم تظهر؛ والمسافة المجهولة (null) ليست 0 وتُستبعد مع تنبيه', async () => {
    const x = mk(null); x.R(`go('cars')`); addCar(x, { id: 9251, mileage: 0 }); addCar(x, { id: 9252, mileage: null }); clickOpt(x, 'carsSuggMileage', 0, 10000);
    const n = J(x, 'CarFilters.normalize(carsFilters)'), got = listIds(x, 'carsList'), chips = chipsHtml(x, 'cars');
    return (fld(x, 'cars', 'MinMileage') === '0' && n.minMileage === 0 && chipTexts(chips)[0] === `${money(0)}–${money(10000)} كم` && got.includes(9251) && !got.includes(9252) && chips.includes('بدون مسافة معلومة')) || { n, got }; });
  await tc('D9) min > max بعد الاقتراح: يبقى سلوك المحرك — لا نتائج + «الحد الأدنى للسعر أكبر من الحد الأعلى.» وحالة فارغة؛ والكيلومترات كذلك', async () => {
    const x = mk(null); x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); setFld(x, 'cars', 'MinPrice', '30000000'); x.R('onCarsRange()');
    const p = [listIds(x, 'carsList'), chipsHtml(x, 'cars'), (x.E.els.carsList || {}).innerHTML];
    clickOpt(x, 'carsSuggMileage', 50000, 100000); setFld(x, 'cars', 'MinMileage', '120000'); x.R('onCarsRange()');
    const m = [listIds(x, 'carsList'), chipsHtml(x, 'cars')];
    return (p[0].length === 0 && p[1].includes('الحد الأدنى للسعر أكبر من الحد الأعلى.') && p[2].includes('لم نعثر على سيارات مطابقة لبحثك') && m[0].length === 0 && m[1].includes('الحد الأدنى للكيلومترات أكبر من الحد الأعلى.')) || { p, m }; });
  await tc('D10) إدخال غير صالح بعد اقتراح (abc / -5 / 12.5) يُعالج بأمان: رسالة «أدخل رقمًا صحيحًا» وبلا انهيار أو تصفية صامتة', async () => {
    const x = mk(null); x.R(`go('cars')`); const bad = [];
    for (const v of ['abc', '-5', '12.5']) { clickOpt(x, 'carsSuggPrice', 10000000, 20000000); setFld(x, 'cars', 'MinPrice', v); x.R('onCarsRange()'); if (!chipsHtml(x, 'cars').includes('أدخل رقمًا صحيحًا') || BAD.test(chipsHtml(x, 'cars'))) bad.push(v); }
    return bad.length === 0 || bad; });
  await tc('D11) الاقتراح لا يخفي مسار النتائج القائم: بحث نصي + اقتراح سعر = تقاطع النص مع السعر محسوبًا يدويًا (toyota × 20–30 مليون)', async () => {
    const x = mk(null); x.R(`go('cars')`); x.R(`onCarsSearch('toyota')`); clickOpt(x, 'carsSuggPrice', 20000000, 30000000);
    const got = listIds(x, 'carsList'), want = J(x, `searchCars('toyota', 'showroom').filter(c => c.price >= 20000000 && c.price <= 30000000).map(c => c.id)`);
    return (same(got, want)) || { got, want }; });

  /* ======================= E) الظهور ======================= */
  console.log('\n--- E) الظهور (بلا تغيير) ---');
  await tc('E1) معرض موقوف: سيارته ضمن النطاق لا تظهر للزائر بعد اختيار الاقتراح، وتظهر للمدير (نفس قاعدة الظهور)، والنتائج = الحساب اليدوي من البركة العامة لكل منهما', async () => {
    const a = mk('admin'); addCar(a, { id: 9301, showroomId: 2, price: 15000000 }); addCar(a, { id: 9302, showroomId: 1, price: 15000000 }); a.R(`ShowroomsRepository.update(2, { status: 'suspended' })`);
    const hidden = !J(a, 'getVisibleShowrooms().map(s => s.id)').includes(2) || 'المعرض 2 لم يُوقَف'; const g = asGuest(a);
    const run = x => { x.R(`go('cars')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); return [listIds(x, 'carsList'), J(x, `getPublicCars('showroom').filter(c => c.price >= 10000000 && c.price <= 20000000).map(c => c.id)`)]; };
    const gr = run(g), ar = run(a);
    return (hidden === true || hidden) && (same(gr[0], gr[1]) && !gr[0].includes(9301) && gr[0].includes(9302) && same(ar[0], ar[1])) || { hidden, gr, ar }; });
  await tc('E2) إعلان عضو مالكه غير فعّال لا يظهر في سيارات الأعضاء بعد الاقتراح، والفعّال يظهر؛ والنتائج = الحساب اليدوي من البركة العامة', async () => {
    const a = mk('admin'); addMember(a, { id: 9311, ownerId: 7, price: 15000000 }); addMember(a, { id: 9312, ownerId: 6, price: 15000000 }); a.R(`UsersRepository.update(7, { status: 'suspended' })`); const g = asGuest(a);
    g.R(`go('memberCars')`); clickOpt(g, 'memberSuggPrice', 10000000, 20000000); const got = listIds(g, 'memberCarsList'), want = J(g, `getPublicCars('member').filter(c => c.price >= 10000000 && c.price <= 20000000).map(c => c.id)`);
    return (same(got, want) && !got.includes(9311) && !got.includes(101)) || { got, want }; });
  await tc('E3) الاقتراحات نفسها لا تُسرّب شيئًا: لا تُغيّر بركة السيارات العامة ولا عدد السجلات ولا التخزين (قراءة فقط) حتى بعد عدة اقتراحات متتالية', async () => {
    const x = mk(null); x.R(`go('cars')`); const pool = () => JSON.stringify(J(x, `getPublicCars('all').map(c => [c.id, c.price, c.mileage, c.status])`)), cnt = () => J(x, 'CarsRepository.getAll().length') + '/' + J(x, 'MemberCarsRepository.getAll().length');
    const p0 = pool(), c0 = cnt(), s0 = JSON.stringify(x.E.store);
    PRICE_EXPECT.forEach(p => clickOpt(x, 'carsSuggPrice', p[0], p[1])); MILE_EXPECT.forEach(p => clickOpt(x, 'carsSuggMileage', p[0], p[1]));
    return (pool() === p0 && cnt() === c0 && JSON.stringify(x.E.store) === s0) || 'تغيّر شيء'; });

  /* ======================= F) الشاشات الثلاث ======================= */
  console.log('\n--- F) الشاشات الثلاث (نفس المكوّن) ---');
  await tc('F1) سيارات الأعضاء: الاقتراح يعمل عبر onMemberCarsRange وحالة memberCarsFilters وشاراتها ونتائجها', async () => {
    const x = mk(null); x.R(`go('memberCars')`); clickOpt(x, 'memberSuggPrice', 10000000, 20000000); clickOpt(x, 'memberSuggMileage', 50000, 100000);
    const st = J(x, 'memberCarsFilters'), got = listIds(x, 'memberCarsList'), want = J(x, `getPublicCars('member').filter(c => c.price >= 10000000 && c.price <= 20000000 && typeof c.mileage === 'number' && c.mileage >= 50000 && c.mileage <= 100000).map(c => c.id)`);
    return (st.minPrice === '10000000' && st.maxMileage === '100000' && same(got, want) && chipTexts(chipsHtml(x, 'member')).length === 2 && J(x, 'carsFilters').minPrice === '') || { st, got, want }; });
  await tc('F2) البحث الموحّد: الاقتراح يعمل عبر onSearchRange وحالة searchFilters وشاراتها ونتائجها (ولا يمسّ حالة شاشة السيارات)', async () => {
    const x = mk(null); x.R(`go('search','toyota')`); clickOpt(x, 'searchSuggPrice', 20000000, 30000000);
    const st = J(x, 'searchFilters'), got = idsOf((x.E.els.searchResults || {}).innerHTML), want = J(x, `searchCars('toyota', 'all').filter(c => c.price >= 20000000 && c.price <= 30000000).map(c => c.id)`);
    return (st.minPrice === '20000000' && st.maxPrice === '30000000' && same(got, want) && chipTexts(chipsHtml(x, 'search')).length === 1 && J(x, 'carsFilters').minPrice === '') || { st, got, want }; });
  await tc('F3) «مسح الفلاتر» و×الشارة في الأعضاء والبحث تمسح أثر الاقتراح كذلك', async () => {
    const x = mk(null); x.R(`go('memberCars')`); clickOpt(x, 'memberSuggPrice', 10000000, 20000000); x.R('clearMemberCarsFilters()'); const m = J(x, 'memberCarsFilters');
    x.R(`go('search','toyota')`); clickOpt(x, 'searchSuggMileage', 50000, 100000); x.R(`removeSearchFilter('mileage')`); const s = J(x, 'searchFilters'), bar = x.E.els.searchFilterBar.innerHTML;
    return (m.minPrice === '' && m.maxPrice === '' && s.minMileage === '' && s.maxMileage === '' && optsOf(bar, 'searchSuggMileage').every(o => !o.pressed)) || { m, s }; });

  /* ======================= G) فتح/إغلاق اللوحة ======================= */
  console.log('\n--- G) فتح وإغلاق اللوحة وإمكانية الوصول ---');
  const mkPanels = () => {
    const x = mk(null); x.R(`go('cars')`); const P = { carsSuggPrice: { id: 'carsSuggPrice', hidden: true, scrollIntoView() { this.scrolled = true; } }, carsSuggMileage: { id: 'carsSuggMileage', hidden: true, scrollIntoView() {} } };
    Object.assign(x.E.els, P); x.E.ctx.setTimeout = fn => { fn(); return 0; };   /* التمرير مؤجَّل في الشيفرة (setTimeout وهمي في الحزام): نشغّله فورًا */
    const doc = x.E.ctx.document; doc.querySelectorAll = () => Object.values(P).filter(p => !p.hidden); doc.querySelector = () => Object.values(P).find(p => !p.hidden) || null;
    const focused = []; ['carsFilterMinPrice', 'carsFilterMinMileage'].forEach(id => { x.E.els[id] = { value: '', style: {}, focus() { focused.push(id); x.R('0'); } }; });
    return { x, P, doc, focused };
  };
  await tc('G1) نقر/تركيز حقل السعر يفتح لوحة السعر (وتُمرَّر إلى المجال المرئي)، ثم حقل الكيلومترات يفتح لوحته ويغلق الأولى (لوحة واحدة مفتوحة)', async () => {
    const { x, P } = mkPanels(); x.R(`openFilterSuggestions('cars','Price')`); const a = [P.carsSuggPrice.hidden, P.carsSuggMileage.hidden, P.carsSuggPrice.scrolled === true];
    x.R(`openFilterSuggestions('cars','Mileage')`); const b = [P.carsSuggPrice.hidden, P.carsSuggMileage.hidden];
    return (JSON.stringify(a) === '[false,true,true]' && JSON.stringify(b) === '[true,false]') || { a, b }; });
  await tc('G2) اختيار اقتراح يغلق اللوحة', async () => {
    const { x, P } = mkPanels(); x.R(`openFilterSuggestions('cars','Price')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000); return (P.carsSuggPrice.hidden === true && P.carsSuggMileage.hidden === true) || [P.carsSuggPrice.hidden, P.carsSuggMileage.hidden]; });
  await tc('G3) «إدخال مخصص» يغلق اللوحة ويركّز حقل «من» دون أن يعيد فتحها (منع الفتح البرمجي)، وحقول القيم لا تُمسح', async () => {
    const { x, P, focused } = mkPanels(); x.R(`openFilterSuggestions('cars','Price')`); setFld(x, 'cars', 'MinPrice', '12345');
    x.E.els.carsFilterMinPrice.focus = function () { focused.push('carsFilterMinPrice'); x.R(`openFilterSuggestions('cars','Price')`); };   // المتصفح يطلق onfocus عند التركيز
    x.R(`focusFilterCustom('cars','Price')`); return (P.carsSuggPrice.hidden === true && focused.length === 1 && x.E.els.carsFilterMinPrice.value === '12345') || { hidden: P.carsSuggPrice.hidden, focused }; });
  await tc('G4) تفعيل الاقتراح بلوحة المفاتيح (detail=0) يعيد التركيز إلى حقل «من» دون إعادة فتح اللوحة؛ ونقر اللمس (detail=1) لا يركّز الحقل (لا لوحة مفاتيح هاتف)', async () => {
    const { x, P, focused } = mkPanels(); x.E.els.carsFilterMinPrice.focus = function () { focused.push('min'); x.R(`openFilterSuggestions('cars','Price')`); };
    x.R(`openFilterSuggestions('cars','Price')`); clickOpt(x, 'carsSuggPrice', 10000000, 20000000, 0); const kb = [focused.length, P.carsSuggPrice.hidden];
    x.R(`openFilterSuggestions('cars','Price')`); clickOpt(x, 'carsSuggPrice', 20000000, 30000000, 1); const touch = [focused.length, P.carsSuggPrice.hidden];
    return (JSON.stringify(kb) === '[1,true]' && JSON.stringify(touch) === '[1,true]') || { kb, touch }; });
  await tc('G5) الإغلاق: نقرة/تركيز خارج الحقول واللوحة، Escape (مع إعادة التركيز لحقل «من» إن كان التركيز داخل اللوحة)، Enter في حقل رقم؛ والنقر داخل اللوحة أو في الحقل لا يغلقها', async () => {
    const { x, P, doc, focused } = mkPanels(); const H = {}; doc.addEventListener = (n, f) => { H[n] = f; };
    const src = read('components/filters.js'); const iife = (src.match(/\(function bindFilterSuggestionDismiss\(\) \{[\s\S]*?\n\}\)\(\);/) || [])[0]; if (!iife) return 'لم يوجد مُسجِّل الإغلاق';
    x.R(iife); const out = (e) => ({ target: { closest: () => null, getAttribute: () => null }, ...e }), inP = { closest: s => (s === '.flt-sugg' ? {} : null), getAttribute: () => null }, inF = { closest: s => (s === '[data-sugg]' ? {} : null), getAttribute: n => (n === 'data-sugg' ? 'Price' : null) };
    const open = () => x.R(`openFilterSuggestions('cars','Price')`); const hid = () => P.carsSuggPrice.hidden;
    const r = {}; open(); H.click({ target: inP }); r.clickInPanel = hid(); H.click({ target: inF }); r.clickInField = hid(); H.click(out({})); r.clickOutside = hid();
    open(); H.focusin({ target: inP }); r.focusInPanel = hid(); H.focusin(out({})); r.focusOutside = hid();
    open(); doc.activeElement = null; H.keydown({ key: 'Escape' }); r.escape = hid(); r.escFocus = focused.length;
    open(); doc.activeElement = { closest: s => (s === '.flt-sugg' ? {} : null) }; H.keydown({ key: 'Escape' }); r.escFromPanel = [hid(), focused.length];
    open(); H.keydown({ key: 'Enter', target: inF }); r.enter = hid(); open(); H.keydown({ key: 'Enter', target: { getAttribute: () => null } }); r.enterElsewhere = hid(); H.keydown({ key: 'a' }); r.otherKey = hid();
    return (r.clickInPanel === false && r.clickInField === false && r.clickOutside === true && r.focusInPanel === false && r.focusOutside === true && r.escape === true && r.escFocus === 0 && JSON.stringify(r.escFromPanel) === '[true,1]' &&
      r.enter === true && r.enterElsewhere === false && r.otherKey === false) || r; });
  await tc('G6) الوصول: كل اقتراح <button type="button"> بـaria-label عربي يتضمن نصه، aria-pressed، علامة ✓ مخفية عن القارئ (aria-hidden) لا لون فقط؛ اللوحة role="group" بتسمية عربية؛ لا tabindex سالب', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const bad = [];
    ['Price', 'Mileage'].forEach(k => { const id = 'cars' + 'Sugg' + k, ph = panelHtml(h, id), o = optsOf(h, id);
      if (!/role="group" aria-label="اقتراحات [^"]+"/.test(ph) || !/\bhidden>/.test(ph)) bad.push(id + ':group');
      if (o.length !== 7 || o.some(p => !/^اقتراح (السعر|الكيلومترات): /.test(p.aria) || !p.aria.includes(p.text.replace(/^✓\s*/, '')))) bad.push(id + ':aria');
      if (!/<span class="sugg-check" aria-hidden="true" hidden>✓<\/span>/.test(ph)) bad.push(id + ':check');
      if (!/<button type="button" class="sugg-opt sugg-custom" aria-label="إدخال [^"]+ مخصص"[^>]*>إدخال مخصص<\/button>/.test(ph)) bad.push(id + ':custom'); });
    if (/tabindex="-/.test(h)) bad.push('tabindex'); return bad.length === 0 || bad; });
  await tc('G7) خيارات الاقتراح لا تسرق التركيز بالنقر (onmousedown يمنع blur) كي لا تختفي اللوحة قبل تسجيل النقرة على الهاتف', async () => {
    const x = mk(null); x.R(`go('cars')`); const ph = panelHtml(x.E.screen(), 'carsSuggPrice'); const m = ph.match(/<button type="button" class="sugg-opt" [^>]*onmousedown="event.preventDefault\(\)"/g) || [];
    return m.length === 7 || m.length; });

  /* ======================= H) CSS ======================= */
  console.log('\n--- H) CSS (إضافات فقط) ---');
  await tc('H1) كتلة CSS الجزء 5.1: لوحة بعرض الشبكة (grid-column 1 / -1) تلتف (flex-wrap)، مخفية عند hidden، أزرار ≥ 40px، خط ≥ 12px، تمييز pressed، حلقة تركيز؛ بلا left/right ولا ألوان hex ولا متغيرات جديدة ولا حركات', async () => {
    const css = read('theme/theme.css'), i = css.indexOf('/* ---- المرحلة 10 / الجزء 5.1'), b = i >= 0 ? css.slice(i) : '';
    const sizes = [...b.matchAll(/font-size:\s*([\d.]+)px/g)].map(m => Number(m[1]));
    return (b.length > 100 && /\.flt-sugg\{[^}]*grid-column:\s*1 \/ -1[^}]*flex-wrap:\s*wrap/.test(b) && /\.flt-sugg\[hidden\]\{display:none/.test(b) && /\.sugg-opt\{[^}]*min-height:\s*(4\d|[5-9]\d)px/.test(b) && sizes.length > 0 && sizes.every(s => s >= 12) &&
      /\.sugg-opt\[aria-pressed="true"\]/.test(b) && /\.sugg-opt:focus-visible\{outline:\s*3px/.test(b) && /overflow-wrap:\s*anywhere/.test(b) && /min-width:\s*0/.test(b) &&
      !/margin-left|margin-right|padding-left|padding-right|text-align:\s*(left|right)|(^|[;{\s])(left|right)\s*:/.test(b) && !/#[0-9a-fA-F]{3,6}/.test(b) && !/--[a-z-]+\s*:/.test(b) && !/@keyframes|animation|transition/.test(b)) || { len: b.length, sizes }; });
  await tc('H2) CSS إضافات فقط: كتلة الجزء 5.1 في آخر الملف بعد كتلة الجزء 5 (لا تعديل على ما قبلها: ترتيب العلامتين)', async () => {
    const css = read('theme/theme.css'); const i5 = css.indexOf('/* ---- المرحلة 10 / الجزء 5:'), i51 = css.indexOf('/* ---- المرحلة 10 / الجزء 5.1'); return (i5 > 0 && i51 > i5 && css.indexOf('/* ---- المرحلة 10 / الجزء 5.1', i51 + 1) === -1) || { i5, i51 }; });

  /* ======================= N) فحوص ثابتة ======================= */
  console.log('\n--- N) فحوص ثابتة: لا محرك ثانٍ ولا ميزات خارج النطاق ---');
  await tc('N1) الاقتراحات لا تفلتر ولا تبحث ولا تتحقق بنفسها: لا .filter/.sort/.reduce في مكوّن الفلاتر، ولا استدعاء searchCars/getPublicCars/visibility/Repositories، ولا مقارنة بسيارات؛ وعملية التطبيق تمرّ عبر معالج النطاق القائم', async () => {
    const s = strip(read('components/filters.js')); const bad = [];
    if (/\.filter\s*\(|\.sort\s*\(|\.reduce\s*\(/.test(s)) bad.push('array-ops'); if (/searchCars|getPublicCars|getVisible|canView|Repository|UsersRepository|AppStorage/.test(s)) bad.push('data-access');
    if (!/applyFilterPreset[\s\S]*?onRange\(\)/.test(s)) bad.push('no-onRange'); if (!/CarFilters\.normalize/.test(s)) bad.push('no-normalize');
    return bad.length === 0 || bad; });
  await tc('N2) لا سقف سعر/كيلومترات مُشفَّر: لا ثوابت تحقق (max/limit/cap) في مكوّن الفلاتر؛ آخر اقتراح في كل لوحة مفتوح من أعلى (null)؛ والأرقام مكتوبة بالملايين/الآلاف مضروبة بوحدة', async () => {
    const s = strip(read('components/filters.js')); const P = J(mk(null), 'FILTER_PRESETS');
    return (!/MAX_PRICE|MAX_MILEAGE|maxAllowed|\bcap\b|Math\.min\(/.test(s) && P.Price.ranges[P.Price.ranges.length - 1][1] === null && P.Mileage.ranges[P.Mileage.ranges.length - 1][1] === null && P.Price.unit === 1000000 && P.Mileage.unit === 1000) || P; });
  await tc('N3) لا ميزات خارج النطاق في ملفات الفلاتر: لا fetch/تخزين/إشعارات/ذكاء اصطناعي، ولا datalist (والعملة/سعر الصرف دخلتا في الجزء 5.2 عبر models.js وCarFilters؛ وتبقى الشاشات الثلاث بلا أي منطق عملة)', async () => {
    const files = ['components/filters.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'services/carFilterService.js'], re = /fetch\s*\(|XMLHttpRequest|WebSocket|localStorage|indexedDB|AppStorage|Notification|openai|gemini|anthropic|datalist/i;
    const bad = files.filter(f => re.test(strip(read(f)))); const scr = ['screens/cars.js', 'screens/memberCars.js', 'screens/search.js'].filter(f => /currency|\bIQD\b|\bUSD\b|exchange|سعر الصرف/i.test(strip(read(f))));
    return (bad.length === 0 && scr.length === 0) || { bad, scr }; });
  await tc('N4) المعمارية محفوظة: لا ملفات خدمة ولا مستودع ولا مكوّن جديدة (نفس القوائم السابقة)، ولا ملف سكربت جديد في index.html', async () => {
    const ls = d => fs.readdirSync(path.join(ROOT, d)).sort().join();
    const comps = ['accountButton.js', 'accountCard.js', 'adSlot.js', 'carCard.js', 'carImage.js', 'contactButtons.js', 'filters.js', 'imagePicker.js', 'searchBox.js', 'showroomCard.js', 'ui.js'].sort().join();
    const repos = ['baseRepository.js', 'carImagesRepository.js', 'carsRepository.js', 'favoritesRepository.js', 'idAllocator.js', 'index.js', 'memberCarsRepository.js', 'schemaRepository.js', 'sessionRepository.js', 'showroomsRepository.js', 'usersRepository.js'].sort().join();
    const svc = ['adminService.js', 'authService.js', 'authorizationService.js', 'carFilterService.js', 'carImagesService.js', 'dataService.js', 'favoritesService.js', 'formatService.js', 'imageService.js', 'imageStore.js', 'memberCarsService.js', 'migrationService.js', 'rewardService.js', 'searchService.js', 'sessionService.js', 'showroomCarsService.js', 'showroomService.js', 'storageService.js', 'userService.js', 'visibilityService.js'].sort().join();
    const scripts = (read('index.html').match(/<script src=/g) || []).length;
    return (ls('components') === comps && ls('repositories') === repos && ls('services') === svc && scripts === 85) || { components: ls('components'), scripts }; });
  await tc('N5) المحرك لم يُمسّ: CarFilters يعرض الواجهة نفسها ولا دالة جديدة (بلا presets/suggest داخل carFilterService/searchService)', async () => {
    const x = mk(null); const keys = x.R('Object.keys(CarFilters).sort().join()'); const want = ['key', 'canonicalBrand', 'canonicalModel', 'normalize', 'activeCount', 'validate', 'apply', 'matches', 'options', 'reconcileModel', 'describe', 'chips', 'without', 'sameKey'].sort().join();
    const src = strip(read('services/carFilterService.js') + read('services/searchService.js')); return (J(x, 'typeof CarFilters.apply') === 'function' && keys === want && !/preset|suggest|اقتراح/i.test(src)) || { keys, want }; });
  await tc('N6) الاقتراحات تُعرَّف في مكان واحد (FILTER_PRESETS في مكوّن الفلاتر) وتُستخدم من الشاشات الثلاث عبر FilterBar نفسه (لا نسخ في الشاشات)', async () => {
    const scr = ['screens/cars.js', 'screens/memberCars.js', 'screens/search.js'].filter(f => /FILTER_PRESETS|FilterSuggestions|applyFilterPreset|sugg/i.test(strip(read(f))));
    return (scr.length === 0 && (strip(read('components/filters.js')).match(/\$\{FilterSuggestions\(prefix,/g) || []).length === 2) || scr; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

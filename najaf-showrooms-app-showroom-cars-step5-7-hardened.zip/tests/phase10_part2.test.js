/* اختبارات «المرحلة 10 — الجزء 2: ظهور إعلانات العضو حسب حالة حسابه» (Phase 10 Part 2).
   القاعدة: إعلانات العضو الشخصية تظهر للعامة فقط إذا كان حساب مالكه active وحالة الإعلان active.
   حساب غير active (suspended / مرفوض / pending / disabled / أي حالة أخرى) ← كل إعلاناته مخفية عن العامة، لا تُحذف،
   وتعود بإعادة التفعيل حسب حالة كل إعلان. المدير يرى ويدير دائمًا، والمالك يدير ما يملكه وفق قواعد الصلاحيات القائمة.
   كُتبت قبل التنفيذ لإثبات الثغرة ثم مرّت. «إعادة تحميل» = بيئة جديدة بنفس التخزين. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 180)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer2: ['07709876543', 'dealer123'], dealer4: ['07705566778', 'dealer123'],
  pendingDealer: ['07733445566', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const clone = o => JSON.parse(JSON.stringify(o));
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const idsOf = html => [...new Set([...String(html).matchAll(/go\('(?:carDetails|memberCarDetails)',(\d+)\)/g)].map(m => Number(m[1])))];
const hasFavBtn = (html, id) => String(html).includes(`handleFavoriteToggle(${id})`);
const ERR = 'حدث خطأ، حاول مرة أخرى';
/** يضبط حالة حساب (المستخدم 7 عضو عادي ليس له واجهة تعليق في الإدارة؛ نكتب الحالة عبر المستودع كما تفعل اختبارات الخدمات) */
const setStatus = (x, id, st) => x.R(`UsersRepository.update(${id}, { status: ${JSON.stringify(st)} }).ok`);
/** بعد تعليق/تعديل نعيد الحالة كتخزين مستقل لكل مشاهد */
const withStatus = (id, st) => { const a = mk('admin'); setStatus(a, id, st); return clone(a.E.store); };

/** كل أسطح العرض لسيارة عضو لمشاهد واحد */
function surfaces(x, id, model) {
  const o = {};
  o.list = J(x, 'getVisibleMemberCars().map(c=>c.id)').includes(id);
  o.pool = J(x, `getPublicCars('all').map(c=>c.id)`).includes(id);
  o.search = J(x, `searchCars('', 'all').map(c=>c.id)`).includes(id);
  o.searchQ = J(x, `searchCars(${JSON.stringify(model)}, 'all').map(c=>c.id)`).includes(id);
  o.filter = J(x, `filterMemberCars({}).map(c=>c.id)`).includes(id);
  o.byId = x.R(`getVisibleCarById(${id})`) !== undefined;
  x.R(`go('memberCars')`); o.memberScreen = idsOf(x.E.screen()).includes(id);
  x.R(`go('home')`); o.home = idsOf(x.E.screen()).includes(id);
  x.R(`go('search','${model}')`); o.searchScreen = idsOf(x.E.screen()).includes(id);
  x.R(`go('cars')`); o.carsScreen = idsOf(x.E.screen()).includes(id);
  return o;
}
const details = (x, id) => {
  x.R(`go('carDetails',${id})`); const a = hasFavBtn(x.E.screen(), id);
  x.R(`go('memberCarDetails',${id})`); const b = x.R('currentRoute') === 'memberCarDetails' && hasFavBtn(x.E.screen(), id);
  return { carDetails: a, memberDetails: b, access: x.R(`getCarAccess(${id}).status`), errA: x.E.screen().includes(ERR) };
};
const allTrue = o => Object.entries(o).filter(([k]) => k !== 'carsScreen' && k !== 'access' && k !== 'errA').every(([, v]) => v === true);
const allFalse = o => Object.entries(o).filter(([k]) => k !== 'access' && k !== 'errA').every(([, v]) => v === false);

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) القاعدة الأساسية ======================= */
  console.log('\n--- A) قاعدة الظهور ---');
  await tc('A1) عضو فعّال + إعلان فعّال (101) → عام على كل الأسطح (قوائم، بحث، رئيسية، تفاصيل)', async () => {
    const g = mk(null); const s = surfaces(g, 101, 'corolla'), d = details(g, 101);
    return (allTrue(s) && s.carsScreen === false && d.carDetails && d.memberDetails && d.access === 'ok') || { s, d }; });
  const hiddenFor = async (name, makeStore, id, model, ownerWord) => tc(name, async () => {
    const store = makeStore(); const bad = {};
    for (const role of ['guest', 'dealer1', 'dealer4']) {
      const x = role === 'guest' ? asGuest({ E: { store: clone(store) } }) : mk(role, clone(store));
      const s = surfaces(x, id, model), d = details(x, id);
      if (!allFalse(s) || d.carDetails || d.memberDetails || d.access !== 'hidden' || d.errA) bad[role] = { s, d };
    }
    return Object.keys(bad).length === 0 || bad; });
  await hiddenFor('A2) عضو موقوف (suspended) + إعلان فعّال → مخفي عن الزائر وعن المستخدمين الآخرين على كل الأسطح', () => withStatus(7, 'suspended'), 101, 'corolla');
  await hiddenFor('A3a) عضو مرفوض (حالة rejected) + إعلان فعّال → مخفي', () => withStatus(7, 'rejected'), 101, 'corolla');
  await tc('A3b) تاجر مرفوض فعليًا (rejectDealer) + إعلانه الفعّال 104 → مخفي، ويعود باعتماده', async () => {
    const a = mk('admin'); a.R('rejectDealer(2)'); const st = clone(a.E.store); const bad = {};
    for (const role of ['guest', 'dealer1']) { const x = role === 'guest' ? asGuest({ E: { store: clone(st) } }) : mk(role, clone(st)); const s = surfaces(x, 104, 'sentra'), d = details(x, 104); if (!allFalse(s) || d.carDetails || d.memberDetails || d.access !== 'hidden') bad[role] = { s, d }; }
    a.R('approveDealer(2)'); const g = asGuest(a); const back = surfaces(g, 104, 'sentra');
    return (Object.keys(bad).length === 0 && allTrue(back)) || { bad, back }; });
  await tc('A4) عضو معلّق (pending) + إعلان فعّال: تاجر معلّق ينشر إعلانًا فيُخفى عن العامة، ويظهر باعتماده', async () => {
    const p = mk('pendingDealer'); const r = p.R(`createDraftMemberCar({brand:'Kia',model:'Pendingmodel',year:2020,price:1000,phone:'07733445566'})`); const id = r.car.id;
    const g = asGuest(p); const hid = allFalse(surfaces(g, id, 'pendingmodel')); const d = details(g, id);
    const a = mk('admin', g.E.store); a.R('approveDealer(8)'); const g2 = asGuest(a); const s2 = surfaces(g2, id, 'pendingmodel');
    const top4 = J(g2, `searchCars('', 'member').slice(0, 4).map(c=>c.id)`).includes(id);   // الرئيسية تعرض أول 4 فقط من البركة العامة
    const inRecent = J(g2, `getRecentCars({ limit: RECENT_CARS_HOME_LIMIT }).map(c=>c.id)`).includes(id);   // قسم «المضافة حديثًا» (ميزة جديدة) يعرض الأحدث أيضًا
    const vis = s2.list && s2.pool && s2.search && s2.searchQ && s2.filter && s2.byId && s2.memberScreen && s2.searchScreen && s2.home === (top4 || inRecent);
    return (r.ok && r.car.status === 'active' && hid && !d.carDetails && !d.memberDetails && d.access === 'hidden' && vis) || { hid, d, s2 }; });
  await hiddenFor('A5) عضو معطّل (disabled) + إعلان فعّال → مخفي', () => withStatus(7, 'disabled'), 101, 'corolla');
  await hiddenFor('A5b) أي حالة حساب أخرى غير معرَّفة (weird) → مخفي أيضًا', () => withStatus(7, 'weird'), 101, 'corolla');
  await tc('A6) إعادة تفعيل العضو (من كل الحالات غير الفعّالة) → الإعلان عام ثانيةً على كل الأسطح', async () => {
    const bad = {};
    for (const st of ['suspended', 'rejected', 'pending', 'disabled']) {
      const a = mk('admin'); setStatus(a, 7, st); const hid = allFalse(surfaces(asGuest(a), 101, 'corolla')); setStatus(a, 7, 'active');
      const g = asGuest(a); const s = surfaces(g, 101, 'corolla'), d = details(g, 101); const g2 = asGuest(g);  // بعد إعادة تحميل أيضًا
      if (!hid || !allTrue(s) || !d.carDetails || !d.memberDetails || !allTrue(surfaces(g2, 101, 'corolla'))) bad[st] = { hid, s, d };
    }
    return Object.keys(bad).length === 0 || bad; });
  await tc('A7) قواعد حالة الإعلان القائمة لم تتغيّر: pending/sold/rejected/suspended مخفية عن العامة حتى مع مالك فعّال', async () => {
    const g = mk(null); const hidden = [103, 105, 108, 109, 110].every(id => !surfaces(g, id, 'x').list && g.R(`getCarAccess(${id}).status`) === 'hidden');
    return hidden && same(J(g, 'getVisibleMemberCars().map(c=>c.id)'), [101, 102, 104, 106, 107]); });
  await tc('A8) مالك غير فعّال + إعلان غير فعّال: يبقى مخفيًا، وبعد إعادة التفعيل يعود الفعّال فقط (حسب حالة كل إعلان)', async () => {
    const a = mk('admin'); setStatus(a, 7, 'suspended'); const g1 = asGuest(a); const during = J(g1, 'getVisibleMemberCars().map(c=>c.id)');
    setStatus(a, 7, 'active'); const g2 = asGuest(a); const after = J(g2, 'getVisibleMemberCars().map(c=>c.id)');
    return same(during, [102, 104, 106, 107]) && same(after, [101, 102, 104, 106, 107]) && [103, 105, 108].every(id => g2.R(`getVisibleCarById(${id})`) === undefined); });
  await tc('A9) النطاق: تعليق عضو يخفي إعلاناته فقط، لا إعلانات الآخرين ولا سيارات المعارض', async () => {
    const x = asGuest({ E: { store: withStatus(7, 'suspended') } });
    return same(J(x, 'getVisibleMemberCars().map(c=>c.id)'), [102, 104, 106, 107]) && same(J(x, 'getVisibleCars().map(c=>c.id)'), [1, 2, 3, 4, 5, 6, 10, 11, 12]); /* سياسة الظهور العام: المعرض 3 قيد المراجعة مخفي */ });
  await tc('A10) مالك غير موجود في المستخدمين أو بلا ownerId: لا حساب يُعلَّق ← القاعدة حسب حالة الإعلان فقط، ولا انهيار (كما في المعارض)', async () => {
    const x = mk(null); x.R(`MEMBER_CARS.push(CarModel({ id: 970, sourceType:'member', ownerId: 50, brand:'Orphanbrand', model:'NoOwner', year:2020, price:1000, status:'active' }))`);
    x.R(`MEMBER_CARS.push(CarModel({ id: 971, sourceType:'member', brand:'Orphanbrand', model:'UndefOwner', year:2020, price:1000, status:'active' }))`);
    x.R(`go('memberCars')`); const s = x.E.screen();
    return x.R('getVisibleCarById(970).id') === 970 && x.R('getVisibleCarById(971).id') === 971 && idsOf(s).includes(970) && idsOf(s).includes(971) && !s.includes(ERR); });
  await tc('A11) خيارات الفلتر: ماركة إعلان مالكه غير فعّال لا تظهر للعامة (بركة الفلاتر عامة)', async () => {
    const a = mk('admin'); a.R(`updateMemberCar(101,{brand:'Zeekr',model:'Hiddenmodel'})`); setStatus(a, 7, 'suspended'); const st = clone(a.E.store);
    const g = asGuest({ E: { store: clone(st) } }), a2 = mk('admin', clone(st));
    g.R(`go('memberCars')`); const gb = g.E.screen(); g.R(`go('search','zeekr')`); const gs = g.E.screen();
    return !gb.includes('Zeekr') && !gs.includes('Zeekr') && J(g, `CarFilters.options(getPublicCars('member'), {}).brands.map(b=>b.value)`).includes('Zeekr') === false &&
      a2.R('getCarAccess(101).status') === 'ok'; });

  /* ======================= B) المفضلة ======================= */
  console.log('\n--- B) المفضلة ---');
  await tc('B1) إعلان مخفي بسبب مالكه لا يظهر في نتائج المفضلة العامة (قائمة وشاشة)', async () => {
    const d = mk('dealer1'); d.R('toggleFavorite(101)'); d.R('toggleFavorite(1)'); const a = mk('admin', d.E.store); setStatus(a, 7, 'suspended');
    const d2 = mk('dealer1', a.E.store); d2.R(`go('favorites')`); const scr = d2.E.screen();
    return same(J(d2, 'getFavoriteCars().map(c=>c.id)'), [1]) && same(idsOf(scr), [1]) && !scr.includes(ERR); });
  await tc('B2) سجل المفضلة لا يُحذف لمجرد إخفاء السيارة مؤقتًا (المستودع والتخزين وبعد إعادة التحميل ومرور الهجرة)', async () => {
    const d = mk('dealer1'); d.R('toggleFavorite(101)'); const rec = J(d, `FavoritesRepository.getAll().find(f=>f.carId===101)`); const a = mk('admin', d.E.store); setStatus(a, 7, 'suspended');
    const d2 = mk('dealer1', a.E.store); const d3 = mk('dealer1', d2.E.store);   // إعادة تحميلان (الهجرة وفحص السلامة يعملان)
    const stored = JSON.parse(d3.E.store['najaf.favorites']).filter(f => f.carId === 101);
    return rec && J(d3, `FavoritesRepository.getAll().filter(f=>f.carId===101)`).length === 1 && stored.length === 1 && stored[0].id === rec.id && stored[0].userId === rec.userId; });
  await tc('B3) إعادة تفعيل المالك تُعيد المفضلة ظاهرة بنفس السجل (لا يُعاد إنشاؤه) و isFavorite صحيحة', async () => {
    const d = mk('dealer1'); d.R('toggleFavorite(101)'); const rec = J(d, `FavoritesRepository.getAll().find(f=>f.carId===101)`); const a = mk('admin', d.E.store); setStatus(a, 7, 'suspended');
    const mid = mk('dealer1', a.E.store); const hid = J(mid, 'getFavoriteCars()').length === 0 && mid.R('isFavorite(101)') === true;   // السجل قائم وإن كانت السيارة مخفية
    const a2 = mk('admin', mid.E.store); setStatus(a2, 7, 'active'); const back = mk('dealer1', a2.E.store); back.R(`go('favorites')`);
    return hid && same(J(back, 'getFavoriteCars().map(c=>c.id)'), [101]) && same(idsOf(back.E.screen()), [101]) && J(back, `FavoritesRepository.getAll().find(f=>f.carId===101)`).id === rec.id && back.R('isFavorite(101)') === true; });
  await tc('B4) مفضلة عدة مستخدمين للإعلان نفسه تُحفظ كلها أثناء الإخفاء، ولا تُضاف مفضلة جديدة لإعلان مخفي', async () => {
    const d = mk('dealer1'); d.R('toggleFavorite(101)'); const d4 = mk('dealer4', d.E.store); d4.R('toggleFavorite(101)'); const a = mk('admin', d4.E.store); setStatus(a, 7, 'suspended');
    const g = mk('dealer1', a.E.store); const n = g.R(`FavoritesRepository.getAll().filter(f=>f.carId===101).length`);
    const r = g.R('toggleFavorite(101)');   // المستخدم نفسه لا يستطيع إزالة سجل لا يراه ولا يُحذف السجل
    return n === 2 && r.ok === false && g.R(`FavoritesRepository.getAll().filter(f=>f.carId===101).length`) === 2; });
  await tc('B5) حذف الإعلان فعليًا ما زال ينظّف مفضلته (القاعدة القائمة)', async () => {
    const d = mk('dealer1'); d.R('toggleFavorite(101)'); const u = mk('user', d.E.store); u.R('deleteMemberCar(101)');
    return u.R(`FavoritesRepository.getAll().filter(f=>f.carId===101).length`) === 0; });
  await tc('B6) المالك نفسه (تاجر معلّق) يستطيع إضافة إعلانه المخفي للمفضلة ويراه (قواعد الصلاحيات القائمة)', async () => {
    const p = mk('pendingDealer'); const id = p.R(`createDraftMemberCar({brand:'Kia',model:'OwnFav',year:2020,price:1000,phone:'07733445566'})`).car.id;
    return p.R(`toggleFavorite(${id}).ok`) === true && same(J(p, 'getFavoriteCars().map(c=>c.id)'), [id]); });

  /* ======================= C) المدير ======================= */
  console.log('\n--- C) المدير ---');
  await tc('C1) المدير يصل للسيارة المخفية: المسار العام (getCarAccess/ById) والتفاصيل والإدارة', async () => {
    const a = asGuest({ E: { store: withStatus(7, 'suspended') } }); const x = mk('admin', a.E.store); const d = details(x, 101);
    return x.R('getCarAccess(101).status') === 'ok' && x.R('getVisibleCarById(101).id') === 101 && d.carDetails && d.memberDetails && !d.errA; });
  await tc('C2) شاشات الإدارة ترى الحساب غير الفعّال وإعلاناته وحالتها (المستخدمون، تفاصيل المستخدم، سيارات الأعضاء، تفاصيل الإعلان)', async () => {
    const x = mk('admin', withStatus(7, 'suspended')); x.R(`go('adminUsers')`); const users = x.E.screen(); x.R(`go('adminUserDetails',7)`); const ud = x.E.screen();
    x.R(`go('adminMemberCars')`); const list = x.E.screen(); x.R(`go('adminMemberCarDetails',101)`); const det = x.E.screen();
    const u7 = J(x, `AdminService.getAllUsers().find(u=>u.id===7)`);
    return u7 && u7.status === 'suspended' && [users, ud, list, det].every(s => !s.includes(ERR)) && ud.includes('Corolla') && ud.includes('Rio') && list.includes('Corolla') && det.includes('Corolla') &&
      x.R('getMemberCarsByOwner(7).length') === 4 && x.R('getMemberCars().length') === 10; });
  await tc('C3) المدير يدير حالة الإعلان المخفي (تعليق/استعادة/اعتماد) والحالة تُحفظ وتبقى مخفية للعامة حتى يُفعَّل المالك', async () => {
    const x = mk('admin', withStatus(7, 'suspended')); const r1 = x.R(`suspendMemberCarAdmin(101,'x')`), st1 = x.R('getMemberCarById(101).status'); const r2 = x.R('restoreMemberCar(101)'), st2 = x.R('getMemberCarById(101).status');   // الاستعادة تعيده إلى pending (سلوك قائم)
    const r3 = x.R('approveMemberCar(103)'), r4 = x.R('approveMemberCar(101)'); const g = asGuest(x); const still = same(J(g, 'getVisibleMemberCars().map(c=>c.id)'), [102, 104, 106, 107]);   // 101 و103 فعّالان الآن لكن مالكهما موقوف
    const a2 = mk('admin', g.E.store); setStatus(a2, 7, 'active'); const g2 = asGuest(a2);
    return r1.ok && st1 === 'suspended' && r2.ok && st2 === 'pending' && r3.ok && r4.ok && still && same(J(g2, 'getVisibleMemberCars().map(c=>c.id)'), [101, 102, 103, 104, 106, 107]); });
  await tc('C4) إحصاءات لوحة الإدارة وقوائمها الخام لا تتأثر بحالة المالك (بيانات الإدارة لا تُخفى)', async () => {
    const a = mk('admin'); const before = J(a, 'getDashboardStats()'); setStatus(a, 7, 'suspended'); const after = J(a, 'getDashboardStats()');
    return JSON.stringify(before) === JSON.stringify(after) && a.R('getMemberCars().length') === 10 && a.R('getActiveMemberCars().length') === 5; });
  await tc('C5) قوائم المسار العام لا تُظهر للمدير إعلانات المالك غير الفعّال (القوائم العامة لا تتبع المشاهد؛ يديرها من شاشات الإدارة والتفاصيل)', async () => {
    const x = mk('admin', withStatus(7, 'suspended')); return same(J(x, 'getVisibleMemberCars().map(c=>c.id)'), [102, 104, 106, 107]) && same(J(x, `searchCars('', 'member').map(c=>c.id)`), [102, 104, 106, 107]); });
  await tc('C6) إعادة اعتماد/رفض التاجر من لوحة الإدارة تؤثر على إعلاناته فورًا (ربط حقيقي بالحالة)', async () => {
    const a = mk('admin'); a.R('rejectDealer(1)'); const h = same(J(asGuest(a), 'getVisibleMemberCars().map(c=>c.id)'), [101, 104, 106, 107]);
    a.R('approveDealer(1)'); return h && same(J(asGuest(a), 'getVisibleMemberCars().map(c=>c.id)'), [101, 102, 104, 106, 107]); });

  /* ======================= D) المالك ======================= */
  console.log('\n--- D) المالك ---');
  await tc('D1) مالك معلّق (تاجر pending) يدير إعلانه المخفي: يراه في «إعلاناتي»، يفتح تفاصيله، يعدّله ويغيّر حالته ويحذفه', async () => {
    const p = mk('pendingDealer'); const id = p.R(`createDraftMemberCar({brand:'Kia',model:'OwnerCar',year:2020,price:1000,phone:'07733445566'})`).car.id;
    p.R(`go('myMemberCars')`); const mine = p.E.screen(); const d = details(p, id); const up = p.R(`updateMemberCar(${id},{price:2000})`); const st = p.R(`changeMemberCarStatus(${id},'sold')`);
    const g = asGuest(p); const hidden = g.R(`getVisibleCarById(${id})`) === undefined;
    const p2 = mk('pendingDealer', g.E.store); const del = p2.R(`deleteMemberCar(${id})`);
    return mine.includes('OwnerCar') && d.carDetails && d.memberDetails && d.access === 'ok' && up.ok && st.ok && hidden && del.ok && p2.R('getMemberCarsByOwner(8).length') === 0; });
  await tc('D2) مالك حسابه disabled (يستطيع الدخول وفق القواعد القائمة): إعلاناته مخفية للعامة لكنها قابلة للإدارة', async () => {
    const x = mk('user', withStatus(7, 'disabled')); x.R(`go('myMemberCars')`); const mine = x.E.screen(); const up = x.R(`updateMemberCar(101,{price:15900000})`); const d = details(x, 101);
    const g = asGuest(x);
    return x.R('SessionService.isLoggedIn()') === true && mine.includes('Corolla') && up.ok && d.access === 'ok' && d.memberDetails && g.R('getVisibleCarById(101)') === undefined && g.R('getMemberCarById(101).price') === 15900000; });
  await tc('D3) مالك موقوف (suspended) لا يدخل وفق القواعد القائمة، وإعلاناته محفوظة كما هي بالتفصيل (لا حذف ولا تعديل)', async () => {
    const a = mk('admin'); const before = J(a, 'getMemberCarsByOwner(7)'); setStatus(a, 7, 'suspended'); const x = mk('user', asGuest(a).E.store);
    const stored = JSON.parse(x.E.store['najaf.memberCars'] || '[]');
    return x.R('SessionService.isLoggedIn()') === false && JSON.stringify(J(x, 'MemberCarsRepository.getByOwner(7)')) === JSON.stringify(before) && before.length === 4 && stored.filter(c => c.ownerId === 7).every(c => before.some(b => b.id === c.id)); });
  await tc('D4) إعادة تفعيل المالك: يدخل وتعود كل إعلاناته بحالاتها كما كانت (فعّال يظهر، والمعلّق/المباع كما هو)', async () => {
    const a = mk('admin'); setStatus(a, 7, 'suspended'); setStatus(a, 7, 'active'); const x = mk('user', asGuest(a).E.store); x.R(`go('myMemberCars')`); const mine = x.E.screen();
    const st = J(x, `getMemberCarsByOwner(7).map(c=>c.id+':'+c.status)`);
    return x.R('SessionService.isLoggedIn()') === true && mine.includes('Corolla') && mine.includes('Rio') && same(st.map(s => Number(s.split(':')[0])), [101, 103, 105, 108]) && st.includes('101:active') && st.includes('103:pending') && st.includes('105:sold'); });
  await tc('D5) الصلاحيات القائمة لم تتغيّر: غير المالك لا يعدّل/يحذف الإعلان المخفي ولا يغيّر حالته', async () => {
    const st = withStatus(7, 'suspended'); const d = mk('dealer1', clone(st));
    return d.R(`updateMemberCar(101,{price:1})`).ok === false && d.R('deleteMemberCar(101)').ok === false && d.R(`changeMemberCarStatus(101,'sold')`).ok === false && d.R('getMemberCarById(101).price') === 15800000; });
  await tc('D6) المسار العام لا يمنح المالك غير الفعّال صلاحية جديدة: التفاصيل لمن يملك القواعد القائمة فقط', async () => {
    const x = mk('pendingDealer'); const own = x.R(`createDraftMemberCar({brand:'Kia',model:'Mine2',year:2020,price:1000,phone:'07733445566'})`).car.id;
    return x.R(`getCarAccess(${own}).status`) === 'ok' && x.R('getCarAccess(101).status') === 'ok' && x.R('canViewCar(103)') === false; });

  /* ======================= E) سلامة البيانات ======================= */
  console.log('\n--- E) سلامة البيانات ---');
  await tc('E1) دورة تعليق → إعادة تفعيل: لا شيء يُحذف أو يتغيّر (السيارات، الصور، المفضلة، الحالات) بما فيها بعد إعادة التحميل', async () => {
    const a = mk('admin'); const snap = () => JSON.stringify({ m: J(a, 'getMemberCars()'), i: J(a, 'CAR_IMAGES'), f: J(a, 'FavoritesRepository.getAll()') });
    a.R('toggleFavorite(101)'); const before = snap(); setStatus(a, 7, 'suspended'); const b = mk('admin', a.E.store); const mid = JSON.stringify({ m: J(b, 'getMemberCars()'), i: J(b, 'CAR_IMAGES'), f: J(b, 'FavoritesRepository.getAll()') });
    setStatus(b, 7, 'active'); const c = mk('admin', b.E.store); const after = JSON.stringify({ m: J(c, 'getMemberCars()'), i: J(c, 'CAR_IMAGES'), f: J(c, 'FavoritesRepository.getAll()') });
    return before === mid && mid === after && c.R('getCarImages(101).length') === 2; });
  await tc('E2) الحالات غير المعرَّفة لا تُسقط ولا تُحذف شيئًا (قيمة غريبة/فارغة/غير نصية لحالة الحساب)', async () => {
    const bad = [];
    for (const v of ["''", 'null', '0', '{}', "'ACTIVE'", "' active '"]) {
      const a = mk('admin'); a.R(`UsersRepository.update(7, { status: ${v} })`); const g = asGuest(a); const n = g.R('MemberCarsRepository.getAll().length');
      let hidden; try { hidden = g.R('getVisibleCarById(101)') === undefined; } catch (e) { hidden = 'EXC'; }
      if (n !== 10 || hidden !== true) bad.push(v + ':' + hidden);
    }
    return bad.length === 0 || bad; });
  await tc('E3) حدود آمنة: إعلان عضو سجل ناقص (بلا ownerId/حالة) أو ownerId نصي/NaN لا يرمي استثناءً في أي سطح عام', async () => {
    const x = mk(null); ['{ownerId:"7"}', '{ownerId:NaN}', '{ownerId:null}', '{}'].forEach((o, i) => x.R(`MEMBER_CARS.push(CarModel(Object.assign({ id: ${980 + i}, sourceType:'member', brand:'Edge', model:'E${i}', year:2020, price:1000, status:'active' }, ${o})))`));
    const bad = []; for (const r of ['home', 'cars', 'memberCars', 'favorites', 'map']) { x.R(`go('${r}')`); if (x.E.screen().includes(ERR)) bad.push(r); }
    for (const id of [980, 981, 982, 983]) { try { x.R(`getCarAccess(${id}).status`); x.R(`canViewCar(${id})`); } catch (e) { bad.push('id' + id); } }
    x.R(`go('search','edge')`); if (x.E.screen().includes(ERR)) bad.push('search');
    return bad.length === 0 || bad; });
  await tc('E4) تعليق حساب تاجر يخفي معًا: معرضه + سياراته (الجزء 9) وإعلانات الأعضاء الشخصية (هذا الجزء)، وإعادة اعتماده يعيد الاثنين', async () => {
    const a = mk('admin'); a.R('rejectDealer(2)'); const g = asGuest(a);
    const hidden = g.R('getVisibleShowroomById(2)') === undefined && g.R('getVisibleCarById(104)') === undefined && g.R('getVisibleCarById(4)') === undefined;
    a.R('approveDealer(2)'); const g2 = asGuest(a); return hidden && g2.R('getVisibleShowroomById(2).id') === 2 && g2.R('getVisibleCarById(104).id') === 104 && g2.R('getVisibleCarById(4).id') === 4; });

  /* ======================= F) فحوص ثابتة ======================= */
  console.log('\n--- F) فحوص ثابتة ---');
  const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
  const read = f => strip(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  const PUBLIC_UI = ['screens/home.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'screens/showrooms.js', 'screens/map.js', 'screens/showroomDetails.js', 'screens/carDetails.js', 'screens/memberCarDetails.js', 'screens/favorites.js', 'components/carCard.js', 'components/showroomCard.js', 'components/filters.js'];
  await tc('F1) لا نظام ظهور ثانٍ: تعريف VisibilityService واحد فقط، ولا ملف ظهور آخر في services', async () => {
    const defs = fs.readdirSync(path.join(ROOT, 'services')).filter(f => f.endsWith('.js') && /const\s+VisibilityService\s*=/.test(fs.readFileSync(path.join(ROOT, 'services', f), 'utf8')));
    const others = fs.readdirSync(path.join(ROOT, 'services')).filter(f => /visib|public/i.test(f));
    return (defs.length === 1 && defs[0] === 'visibilityService.js' && others.length === 1) || { defs, others }; });
  await tc('F2) قاعدة حالة الحساب لا تتكرر خارج visibilityService: الشاشات العامة وخدمتا البحث والمفضلة بلا USER_STATUS/UsersRepository', async () => {
    const bad = PUBLIC_UI.concat(['services/searchService.js', 'services/favoritesService.js']).filter(f => /USER_STATUS|UsersRepository|getPublicById\([^)]*\)\.status/.test(read(f))); return bad.length === 0 || bad; });
  await tc('F3) visibilityService هو الوحيد بين خدمات العرض الذي يربط الإعلان بحساب مالكه (قاعدة واحدة للمعارض والأعضاء)', async () => {
    const v = read('services/visibilityService.js');
    return /_accountBlocked\s*\(/.test(v) && (v.match(/_accountBlocked\s*\(/g) || []).length >= 3 && /ownerId/.test(v); });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

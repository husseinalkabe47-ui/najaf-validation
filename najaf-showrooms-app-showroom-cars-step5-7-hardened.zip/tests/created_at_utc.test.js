/* اختبارات «المرحلة 10 — الجزء 7: اتساق createdAt والطوابع الزمنية».
   الصيغة القانونية المخزَّنة: UTC بصيغة toISOString (YYYY-MM-DDTHH:mm:ss.sssZ). طابع قديم بلا منطقة = توقيت العراق +03:00.
   المصدر الوحيد: Timestamps (models/models.js) ← الهجرة 3 (utc-created-at) وisSeedRecord وترتيب الأحدث والمفضلة.
   كل حسابات «المتوقع» هنا مستقلة عن الكود المختبَر (حساب +3 ساعات بـDate مباشرةً)، وكل متجر قديم يُبنى بسجلات حقيقية عبر المستودعات. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 260)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const clone = o => JSON.parse(JSON.stringify(o));
const CANON = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
const ID = { user: 7, dealer1: 1, dealer2: 2, admin: 6 };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const BAD = /undefined|NaN|\[object/;
/** البيئة: store اختياري (قد يكون Proxy لعدّ الكتابات)، بذرة كاملة */
function view(who, store) {
  const E = makeEnv(store, { fullSeed: 'p3' }), R = c => E.run(c);
  if (who) { R('SessionService.logout()'); R(`SessionService.login(${ID[who]})`); } else R('SessionService.logout()');
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
function spy(initial, failKeys = []) {
  const writes = [], deletes = []; const p = new Proxy(initial, { set(tg, k, v) { if (failKeys.includes(k)) throw new Error('quota ' + k); writes.push(k); tg[k] = v; return true; }, deleteProperty(tg, k) { deletes.push(k); delete tg[k]; return true; } });   // حذف مفتاح الجلسة عند الإقلاع بلا جلسة سلوك قائم، ليس كتابة
  return { store: p, raw: initial, writes, deletes };
}
/** حساب مستقل: طابع قانوني ← صيغته القديمة بلا منطقة (توقيت العراق = UTC+3) */
const toNaive = iso => new Date(Date.parse(iso) + 3 * 3600 * 1000).toISOString().slice(0, 19);
const expUtc = s => (/(Z|[+-]\d{2}:?\d{2})$/.test(s) ? new Date(s).toISOString() : new Date(Date.parse(s + 'Z') - 3 * 3600 * 1000).toISOString());   // للمدخلات الصالحة المعروفة فقط

/* ---- متجر قديم حقيقي: بذور بصيغة قديمة + سجلات إضافية بصيغ متنوعة وتالفة ومفقودة ---- */
const EXTRA_CARS = [[9001, '2027-03-01T12:00:00', '2027-03-01T09:00:00.000Z'], [9002, '2027-03-01T10:00:00Z', '2027-03-01T10:00:00.000Z'], [9003, '2027-03-01T12:00:00+03:00', '2027-03-01T09:00:00.000Z'],
  [9010, '2027-03-01T12:00:00-05:30', '2027-03-01T17:30:00.000Z'], [9009, '2027-03-01T09:00:00.000Z', '2027-03-01T09:00:00.000Z'], [9011, '2027-03-01', '2027-02-28T21:00:00.000Z'],
  [9004, undefined, undefined], [9005, null, null], [9006, '', ''], [9007, 'garbage', 'garbage'], [9008, '2026-02-30T10:00:00', '2026-02-30T10:00:00'], [9012, '0', '0'], [9013, '2026-06-14T24:00:00', '2026-06-14T24:00:00']];
const EXTRA_MEM = [[9101, '2027-03-02T08:30:00', '2027-03-02T05:30:00.000Z'], [9102, 'garbage', 'garbage'], [9103, undefined, undefined], [9104, '2027-03-02T05:30:00.000Z', '2027-03-02T05:30:00.000Z']];
const EXTRA_SH = [[9201, '2027-03-01T12:00:00', '2027-03-01T09:00:00.000Z'], [9202, undefined, undefined], [9203, 'x', 'x']];
function legacyWorld({ version = '2', legacySeeds = true } = {}) {
  const E = makeEnv(undefined, { fullSeed: 'p3' }), R = c => E.run(c), J = c => JSON.parse(E.run(`JSON.stringify(${c})`));
  const seedExp = { cars: Object.fromEntries(J('CARS').map(c => [c.id, c.createdAt])), members: Object.fromEntries(J('MEMBER_CARS').map(c => [c.id, c.createdAt])), showrooms: Object.fromEntries(J('SHOWROOMS').map(c => [c.id, c.createdAt])), users: Object.fromEntries(J('USERS').map(c => [c.id, c.createdAt])) };
  const mustHave = (repo, id) => { if (!R(`${repo}.getById(${id})`)) throw new Error(`${repo} ${id} لم يُنشأ`); };
  EXTRA_CARS.forEach(([id, v]) => { R(`CarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'showroom', showroomId: 1, brand: 'Zeekr', model: 'L' + id, year: 2024, price: 10000000, currency: 'IQD', mileage: 1000, status: 'available', updatedAt: '2027-03-01T12:00:00' }, v === undefined ? {} : { createdAt: v }))}))`); mustHave('CarsRepository', id); });
  EXTRA_MEM.forEach(([id, v]) => { R(`MemberCarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'member', ownerId: 7, brand: 'Zeekr', model: 'LM' + id, year: 2024, price: 9000000, currency: 'IQD', mileage: 2000, status: 'active', phone: '07700000001', whatsapp: '9647700000001', location: 'حي النصر', updatedAt: '2027-03-02T08:30:00' }, v === undefined ? {} : { createdAt: v }))}))`); mustHave('MemberCarsRepository', id); });
  EXTRA_SH.forEach(([id, v]) => { R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify(Object.assign({ id, name: 'Legacy SH ' + id, address: 'Addr ' + id, status: 'active', ownerId: 2, updatedAt: '2027-03-01T12:00:00' }, v === undefined ? {} : { createdAt: v }))}))`); mustHave('ShowroomsRepository', id); });
  R(`UsersRepository.create(UserModel({ id: 9301, name: 'Legacy User', phone: '07700099301', email: 'l@x.test', role: 'user', status: 'active', passwordHash: 'x', createdAt: '2025-05-05T10:00:00' }))`); mustHave('UsersRepository', 9301);
  R(`FavoritesRepository.create(FavoriteModel({ id: FavoritesRepository.allocateId(), userId: 7, carId: 1, createdAt: '2026-05-05T10:00:00' }))`);
  ['CarsRepository', 'MemberCarsRepository', 'ShowroomsRepository', 'UsersRepository', 'FavoritesRepository'].forEach(r => R(`${r}.save()`));
  const st = clone(E.store);
  if (legacySeeds) ['najaf.showroomCars', 'najaf.memberCars', 'najaf.showrooms'].forEach(k => { const a = JSON.parse(st[k]); a.forEach(r => { if (r.id < 9000 && CANON.test(String(r.createdAt))) r.createdAt = toNaive(r.createdAt); }); st[k] = JSON.stringify(a); });   // البذور المخزَّنة بالصيغة القديمة
  if (version === null) delete st['najaf.schemaVersion']; else st['najaf.schemaVersion'] = version;
  return { store: st, seedExp };
}
const getStored = (st, key) => JSON.parse(st[key] || '[]');

(async () => {
  /* ======================= A) التطبيع والصيغة ======================= */
  console.log('\n--- A) التطبيع ---');
  const ref = view(null); const N = v => ref.J(`Timestamps.normalize(${JSON.stringify(v)})`);
  await tc('A1) طابع بلا منطقة (تاريخ تاريخي) = توقيت العراق +03:00: مثال المهمة «2026-09-30T12:00:00» ← «2026-09-30T09:00:00.000Z»؛ وحدود اليوم/السنة، وبلا فرق صيفي/شتوي (العراق UTC+3 دائمًا)', async () => {
    const cases = [['2026-09-30T12:00:00', '2026-09-30T09:00:00.000Z'], ['2026-01-01T01:00:00', '2025-12-31T22:00:00.000Z'], ['2026-03-01T00:30:00', '2026-02-28T21:30:00.000Z'], ['2024-02-29T02:59:59', '2024-02-28T23:59:59.000Z'], ['2026-07-15T12:00:00', '2026-07-15T09:00:00.000Z'], ['2026-12-15T12:00:00', '2026-12-15T09:00:00.000Z'], ['2026-09-30 12:00', '2026-09-30T09:00:00.000Z'], ['2026-09-30T12:00', '2026-09-30T09:00:00.000Z']];
    const bad = cases.filter(([i, o]) => N(i) !== o); return bad.length === 0 || bad; });
  await tc('A2) Z وإزاحات تحتفظ بلحظتها الفعلية وتُطبَّع إلى UTC: Z، +03:00، +0300، +03، -05:30، +05:45، -12:00، +14:00', async () => {
    const cases = [['2026-09-30T12:00:00Z', '2026-09-30T12:00:00.000Z'], ['2026-09-30T12:00:00+03:00', '2026-09-30T09:00:00.000Z'], ['2026-09-30T12:00:00+0300', '2026-09-30T09:00:00.000Z'], ['2026-09-30T12:00:00+03', '2026-09-30T09:00:00.000Z'],
      ['2026-09-30T12:00:00-05:30', '2026-09-30T17:30:00.000Z'], ['2026-09-30T12:00:00+05:45', '2026-09-30T06:15:00.000Z'], ['2026-09-30T12:00:00-12:00', '2026-10-01T00:00:00.000Z'], ['2026-09-30T12:00:00+14:00', '2026-09-29T22:00:00.000Z'], ['2026-09-30T00:00:00+03:00', '2026-09-29T21:00:00.000Z']];
    const bad = cases.filter(([i, o]) => N(i) !== o && (console.log('   ', i, N(i), o), true)); return bad.length === 0 || bad; });
  await tc('A3) الصيغة القانونية للمخرج دائمًا YYYY-MM-DDTHH:mm:ss.sssZ: لكل مدخل صالح (500 مدخل متنوع: بلا منطقة/Z/إزاحة/كسور ثواني/فاصل مسافة/تاريخ فقط) المخرج يطابق النمط ويساوي new Date(x).toISOString()، ويعيد نفسه عند التطبيع ثانيةً (idempotent)', async () => {
    const forms = [d => d + 'T10:15:30', d => d + 'T10:15:30Z', d => d + 'T10:15:30+03:00', d => d + 'T10:15:30.5', d => d + 'T10:15:30.123456', d => d + ' 10:15', d => d + 'T10:15:30-07:00', d => d]; const bad = [];
    for (let i = 0; i < 500; i++) { const day = new Date(Date.UTC(2020 + (i % 8), i % 12, 1 + (i * 7) % 28)).toISOString().slice(0, 10), v = forms[i % forms.length](day); const o = N(v), o2 = N(o); if (!CANON.test(o) || o !== new Date(o).toISOString() || o2 !== o || ref.J(`Timestamps.isCanonical(${JSON.stringify(o)})`) !== true) bad.push([v, o]); }
    const notCanon = ['2026-06-14T06:00:00Z', '2026-06-14T09:00:00', 'x'].map(v => ref.J(`Timestamps.isCanonical(${JSON.stringify(v)})`));
    return (bad.length === 0 && !notCanon.some(Boolean)) || { bad: bad.slice(0, 3), notCanon }; });
  await tc('A4) تفاصيل الصيغة: التاريخ وحده = منتصف ليل العراق، الكسر يُقصّ إلى ms (.5 ← .500، 9 أرقام ← 3)، المسافات الطرفية تُزال، فاصل المسافة مقبول', async () => {
    return (N('2026-09-30') === '2026-09-29T21:00:00.000Z' && N('2026-09-30T12:00:00.5') === '2026-09-30T09:00:00.500Z' && N('2026-09-30T12:00:00.123456789') === '2026-09-30T09:00:00.123Z' && N('  2026-09-30T12:00:00  ') === '2026-09-30T09:00:00.000Z' && N('2026-09-30T12:00:00.07') === '2026-09-30T09:00:00.070Z') || 'details'; });

  /* ======================= B) غير الصالح/المفقود ======================= */
  console.log('\n--- B) غير الصالح والمفقود ---');
    await tc('B1) المدخلات المفقودة/الفارغة/التالفة/غير النصية (بما فيها مصفوفة أو String أو Date يلفّ تاريخًا صالحًا): parseMs = NaN، وnormalize يعيد المدخل نفسه حرفيًا (نفس القيمة والنوع والمرجع) بلا استثناء — لا تاريخ مخترع', async () => {
    const out = ref.J(`(function(){ const IN = [undefined, null, '', '   ', 'garbage', '0', '12', '2026-02-30T10:00:00', '2026-13-01', '2026-00-10', '2026-06-14T24:00:00', '2026-06-14T10:61:00', '2026-06-14T10:00:61', '2026-06-14T10:00:00+25:00', '2026-06-14T10:00:00+03:75', '1969-12-31T23:59:59', '٢٠٢٦-٠٦-١٤', '2026-06-14t10:00:00', '2026-06-14T10:00:00 UTC', 12, -5, NaN, true, false, {}, [], ['2026-06-14T10:00:00'], new String('2026-06-14T10:00:00'), new Date(1781427600000), { toString: () => '2026-06-14T10:00:00' }]; return { n: IN.length, r: IN.map(v => { let r; try { r = Timestamps.normalize(v); } catch (e) { return 'THROW'; } return [Number.isNaN(Timestamps.parseMs(v)), Object.is(r, v)]; }) }; })()`);
    const bad = out.r.map((x, i) => [i, x]).filter(([, x]) => x === 'THROW' || !x[0] || !x[1]); return (out.n === 30 && bad.length === 0) || bad; });
  await tc('B2) المفقود/التالف لا يُكتب له تاريخ في أي مكان: سجل بلا createdAt يبقى بلا مفتاح بعد الهجرة والحفظ، وnull/«»/النص التالف يبقى كما هو حرفيًا في الذاكرة والتخزين (انظر D1)، ولا NaN/undefined في أي شاشة تعرضه', async () => {
    const w = legacyWorld(); const x = view('admin', clone(w.store)); const recs = x.J('CarsRepository.getAll()'); const get = id => recs.find(r => r.id === id); const st = getStored(x.E.store, 'najaf.showroomCars'); const sget = id => st.find(r => r.id === id);
    const pages = ['home', 'recentCars', 'cars', 'memberCars', 'showrooms', 'adminMemberCars', 'adminShowrooms']; const bad = []; pages.forEach(p => { x.R(`go('${p}')`); const h = x.E.screen(); if (BAD.test(h) || h.includes('حدث خطأ')) bad.push(p); });
    return (!('createdAt' in get(9004)) && !('createdAt' in sget(9004)) && get(9005).createdAt === null && sget(9005).createdAt === null && get(9006).createdAt === '' && get(9007).createdAt === 'garbage' && get(9008).createdAt === '2026-02-30T10:00:00' && get(9012).createdAt === '0' && get(9013).createdAt === '2026-06-14T24:00:00' && bad.length === 0 && x.E.errors.length === 0) || { bad, c4: get(9004) }; });

  /* ======================= C) البذور ======================= */
  console.log('\n--- C) بيانات التجربة ---');
  await tc('C1) كل createdAt في بيانات التجربة (91 سيارة معرض + 60 إعلان عضو + 5 معارض + 8 مستخدمين = 164) بالصيغة القانونية وصالح في الذاكرة وفي نصوص ملفات البيانات نفسها؛ وطوابع السيارات فريدة (151)', async () => {
    const all = { cars: ref.J('CARS'), members: ref.J('MEMBER_CARS'), showrooms: ref.J('SHOWROOMS'), users: ref.J('USERS') }; const n = Object.values(all).reduce((s, a) => s + a.length, 0);
    const bad = Object.entries(all).flatMap(([k, a]) => a.filter(r => !CANON.test(r.createdAt) || Number.isNaN(Date.parse(r.createdAt))).map(r => k + ':' + r.id));
    // ملفات البيانات نفسها (قبل أي هجرة: الهجرة 3 تُصلح الذاكرة عند الإقلاع فتخفي بذرة بقيت بالصيغة القديمة): كل createdAt حرفي فيها قانوني
    const files = ['data/cars.js', 'data/memberCars.js', 'data/showrooms.js', 'data/users.js'].map(f => [...read(f).matchAll(/createdAt:\s*"([^"]*)"/g)].map(m => m[1])); const fileBad = files.flat().filter(v => !CANON.test(v) || ref.J(`Timestamps.normalize(${JSON.stringify(v)})`) !== v);
    return (n === 164 && bad.length === 0 && files.flat().length === 164 && fileBad.length === 0 && new Set(all.cars.concat(all.members).map(c => c.createdAt)).size === 151 && all.cars.length === 91 && all.members.length === 60) || { n, bad: bad.slice(0, 4), fileBad: fileBad.slice(0, 3), files: files.map(a => a.length) }; });
  await tc('C2) قيم مرجعية صريحة (قبل ← بعد، +3 ساعات): سيارة 1 «2026-01-05T10:00:00» ← 07:00Z، سيارة 48 «2026-07-01T11:48:07» ← 08:48:07Z، سيارة 91 «2026-09-03T23:41:07» ← 20:41:07Z (لا يتغير اليوم)، إعلان 101 «2026-06-01T09:00:00» ← 06:00Z، 160 ← 11:10:21Z، مستخدم 1 «2024-01-10T09:00:00» ← 06:00Z', async () => {
    const car = id => ref.J(`getCarById(${id}).createdAt`), mem = id => ref.J(`getMemberCarById(${id}).createdAt`);
    return (car(1) === '2026-01-05T07:00:00.000Z' && car(48) === '2026-07-01T08:48:07.000Z' && car(91) === '2026-09-03T20:41:07.000Z' && mem(101) === '2026-06-01T06:00:00.000Z' && mem(160) === '2026-09-26T11:10:21.000Z' && ref.J('UsersRepository.getById(1).createdAt') === '2024-01-10T06:00:00.000Z') || { c1: car(1), c48: car(48), c91: car(91) }; });
  await tc('C3) حدود النطاق موثَّقة: updatedAt في بيانات التجربة لم يُطبَّع (خارج نطاق الجزء 7، ما زال بصيغة قديمة)، وكل سجلات التجربة بقية حقولها كما هي (الأعداد 91/60/5/8 والمعرّفات المتصلة)', async () => {
    const cars = ref.J('CARS'), mem = ref.J('MEMBER_CARS'); return (cars.every(c => /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(c.updatedAt)) && mem.every(c => /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(c.updatedAt)) && cars.length === 91 && mem.length === 60 && ref.J('SHOWROOMS.length') === 5 && ref.J('USERS.length') === 8) || 'scope'; });

  /* ======================= D) الهجرة ======================= */
  console.log('\n--- D) الهجرة 3 ---');
  const W = legacyWorld();
  await tc('D1) تخزين قديم (إصدار 2: بذور بلا منطقة + سجلات بصيغ متنوعة): بعد التحميل كل طابع صالح قانوني في الذاكرة وفي التخزين بالقيمة المتوقعة المستقلة (بلا منطقة +3، Z، إزاحات، تاريخ وحده)، وغير الصالح كما هو، وإصدار المخطط 3، وتقرير الهجرة يحصي كل مجموعة', async () => {
    const x = view(null, clone(W.store)); const keys = { cars: 'najaf.showroomCars', members: 'najaf.memberCars', showrooms: 'najaf.showrooms' }; const bad = [];
    const chk = (label, mem, stored, seedMap, extras) => { mem.forEach(r => { const exp = r.id < 9000 ? seedMap[r.id] : (extras.find(e => e[0] === r.id) || [])[2]; const st = stored.find(s => s.id === r.id); if (r.id < 9000 ? (r.createdAt !== exp || st.createdAt !== exp) : (extras.some(e => e[0] === r.id) && (r.createdAt !== exp || st.createdAt !== exp))) bad.push(label + ':' + r.id); }); };
    chk('car', x.J('CarsRepository.getAll()'), getStored(x.E.store, keys.cars), W.seedExp.cars, EXTRA_CARS); chk('member', x.J('MemberCarsRepository.getAll()'), getStored(x.E.store, keys.members), W.seedExp.members, EXTRA_MEM); chk('showroom', x.J('ShowroomsRepository.getAll()'), getStored(x.E.store, keys.showrooms), W.seedExp.showrooms, EXTRA_SH);
    const u = x.J('UsersRepository.getById(9301).createdAt'), us = getStored(x.E.store, 'najaf.registeredUsers').find(r => r.id === 9301), f = getStored(x.E.store, 'najaf.favorites')[0]; const rep = x.J('StorageSchema.lastReport');
    return (bad.length === 0 && u === '2025-05-05T07:00:00.000Z' && us.createdAt === '2025-05-05T07:00:00.000Z' && f.createdAt === '2026-05-05T07:00:00.000Z' && x.E.store['najaf.schemaVersion'] === '3' && rep.applied.some(a => a.name === 'utc-created-at') && rep.applied.find(a => a.name === 'utc-created-at').result.cars >= 91 && rep.applied.find(a => a.name === 'utc-created-at').result.users === 1 && rep.applied.find(a => a.name === 'utc-created-at').result.favorites === 1 && rep.failed === null && x.E.errors.length === 0) || { bad: bad.slice(0, 5), u, rep: rep.applied && rep.applied.map(a => a.name) }; });
  await tc('D2) الهجرة لا تمسّ إلا createdAt: كل حقل آخر (المعرّفات، السعر، العملة، الحالة، المالك، المعرض، المسافة، updatedAt…) متطابق قبل/بعد (مقابل نفس التخزين بإصدار أحدث 99 الذي لا يُمَسّ)، والظهور متطابق (معارض/سيارات/أعضاء)، والأعداد كما هي', async () => {
    const before = clone(W.store); before['najaf.schemaVersion'] = '99'; const raw = view('admin', before), mig = view('admin', clone(W.store));
    const strip = a => a.map(r => { const c = clone(r); delete c.createdAt; return c; }); const bad = [];
    [['CarsRepository', 'cars'], ['MemberCarsRepository', 'members'], ['ShowroomsRepository', 'showrooms'], ['UsersRepository', 'users'], ['FavoritesRepository', 'favs']].forEach(([r, l]) => { if (!same(strip(raw.J(`${r}.getAll()`)), strip(mig.J(`${r}.getAll()`)))) bad.push(l); });
    const gv = v => ({ c: v.J('getVisibleCars().map(c=>c.id)'), m: v.J('getVisibleMemberCars().map(c=>c.id)'), s: v.J('getVisibleShowrooms().map(s=>s.id)') });
    const g1 = gv(view(null, clone(before))), g2 = gv(view(null, clone(W.store)));
    return (bad.length === 0 && same(g1, g2) && raw.E.store['najaf.schemaVersion'] === '99' && g1.c.length > 20) || { bad, vis: same(g1, g2) }; });
  await tc('D3) idempotent: إعادة تحميل التخزين المُرحَّل = لا كتابة أبدًا ولا هجرات مطبَّقة؛ وإعادة تشغيل الهجرة نفسها (إرجاع الإصدار 2 يدويًا) لا تغيّر شيئًا ولا تكتب سوى علامة الإصدار', async () => {
    const first = view(null, clone(W.store)); const mig = clone(first.E.store); const s = spy(clone(mig)); const second = view(null, s.store);
    const rep = second.J('StorageSchema.lastReport'); const s2 = spy(clone(mig)); const third = view(null, s2.store); third.R('SchemaRepository.setVersion(2)'); s2.writes.length = 0; const r3 = third.J('StorageSchema.run({})'); const norm = r3.applied.find(a => a.name === 'utc-created-at');
    return (s.writes.length === 0 && rep.applied.length === 0 && norm && Object.values(norm.result).every(n => n === 0) && same([...new Set(s2.writes)], ['najaf.schemaVersion']) && same(first.E.store['najaf.showroomCars'], second.E.store['najaf.showroomCars'])) || { w: s.writes, r3: norm && norm.result, w2: s2.writes }; });
  await tc('D4) لا كتابة غير لازمة: تثبيت جديد = المفتاحان المعروفان فقط (memberCarsDeleted + schemaVersion)، وتخزين قانوني بإصدار 2 = علامة الإصدار وحدها، وتخزين بإصدار 3 = لا شيء، وتخزين قديم يكتب المجموعات التي تغيّرت فقط (لا مفتاح مفضلة/مستخدمين إن لم يتغير)', async () => {
    const fresh = spy({}); view(null, fresh.store); const canon = legacyWorld({ legacySeeds: false });   // سجلات قانونية (الإضافات غير القانونية ستُكتب؛ لذا نبني قانونيًا خالصًا بدونها)
    const E0 = makeEnv(undefined, { fullSeed: 'p3' }); ['CarsRepository', 'MemberCarsRepository', 'ShowroomsRepository'].forEach(r => E0.run(`${r}.save()`)); const pure = clone(E0.store); pure['najaf.schemaVersion'] = '2';
    const s2 = spy(clone(pure)); view(null, s2.store); const v3 = clone(pure); v3['najaf.schemaVersion'] = '3'; const s3 = spy(v3); view(null, s3.store);
    const old = spy(clone(W.store)); view(null, old.store); const oldKeys = [...new Set(old.writes)].sort();
    return (same([...new Set(fresh.writes)].sort(), ['najaf.memberCarsDeleted', 'najaf.schemaVersion']) && same([...new Set(s2.writes)], ['najaf.schemaVersion']) && s3.writes.length === 0 && same(oldKeys, ['najaf.favorites', 'najaf.memberCars', 'najaf.registeredUsers', 'najaf.schemaVersion', 'najaf.showrooms', 'najaf.showroomCars'].sort())) || { fresh: fresh.writes, v2: s2.writes, v3: s3.writes, old: oldKeys }; });
  await tc('D5) فشل الحفظ لا يُقدِّم الإصدار: حفظ مجموعة السيارات يفشل (quota) ← يبقى الإصدار 2 وتقرير الهجرة failed، والتطبيق يحمّل ويعمل بلا استثناء؛ ثم التحميل التالي (حفظ سليم) يُعيد المحاولة وينجح (الإصدار 3 والقيم قانونية)', async () => {
    const s = spy(clone(W.store), ['najaf.showroomCars']); const a = view(null, s.store); const rep = a.J('StorageSchema.lastReport'); const verAfterFail = s.raw['najaf.schemaVersion'];
    const usable = a.J('getVisibleCars().length') > 20 && a.E.errors.length === 0; const b = view(null, clone(s.raw)); const rep2 = b.J('StorageSchema.lastReport');
    return (verAfterFail === '2' && rep.failed && rep.failed.name === 'utc-created-at' && usable && b.E.store['najaf.schemaVersion'] === '3' && rep2.failed === null && getStored(b.E.store, 'najaf.showroomCars').every(r => r.id >= 9000 || CANON.test(r.createdAt))) || { verAfterFail, failed: rep.failed, usable, v2: b.E.store['najaf.schemaVersion'] }; });
  await tc('D6) isSeedRecord يقارن اللحظة لا النص: بذرة مخزَّنة بالصيغة القديمة تُعرَف كبذرة، وسجل تغيّر لحظته لا؛ ولترقية من الإصدار 1 (بلا علامة) لا تُعامَل البذور كسجلات مستخدم (مسافة 0 لسيارة تجريبية لا تصير null)، وكل createdAt قانوني بعدها', async () => {
    const raw = clone(W.store); raw['najaf.schemaVersion'] = '99'; const x = view(null, raw); const carsStored = x.J('CarsRepository.getAll()');
    const seedOld = carsStored.find(c => c.id === 1), extra = carsStored.find(c => c.id === 9001);
    const isSeed = id => x.R(`CarsRepository.isSeedRecord(CarsRepository.getById(${id}))`); const shifted = x.R(`CarsRepository.isSeedRecord(Object.assign({}, CarsRepository.getById(1), { createdAt: '2020-01-01T00:00:00' }))`);
    const v1 = clone(W.store); delete v1['najaf.schemaVersion']; { const fv = JSON.parse(v1['najaf.favorites']); [1, 101].forEach(id => fv.push({ id: 9800 + id, userId: 8, carId: id, createdAt: '2020-01-01T00:00:00.000Z' })); v1['najaf.favorites'] = JSON.stringify(fv); } const up = view(null, v1); const m45 = up.J('getCarById(45).mileage'); const mem = up.J('getMemberCarById(101)'); const favKept = [1, 101].every(id => up.J(`FavoritesRepository.getAll().some(f => f.id === ${9800 + id} && f.carId === ${id})`));   // مفضلة (لمستخدم آخر، كي لا تكون مكررة) أقدم من بذرة سيارة/إعلان تبقى (سجلات التجربة تُستثنى من مقارنة التاريخ) — يختبر isSeedRecord للمستودعين
    return (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(seedOld.createdAt) && isSeed(1) === true && isSeed(9001) === false && shifted === false && m45 === 0 && favKept && up.E.store['najaf.schemaVersion'] === '3' && up.E.errors.length === 0 && up.J('StorageSchema.lastReport.applied.map(a=>a.name).join()') === 'unified-ids-and-cleanup,utc-created-at' && CANON.test(mem.createdAt) && getStored(up.E.store, 'najaf.showroomCars').every(r => r.id >= 9000 || CANON.test(r.createdAt))) || { isSeed1: isSeed(1), shifted, m45, ver: up.E.store['najaf.schemaVersion'] }; });
  await tc('D7) المخطط الأحدث لا يُمَسّ: تخزين بإصدار 99 يبقى بطوابعه القديمة حرفيًا بلا كتابة وبلا هجرة (قاعدة قائمة)، ولا استثناء', async () => {
    const raw = clone(W.store); raw['najaf.schemaVersion'] = '99'; const s = spy(raw); const x = view(null, s.store); const sc = getStored(raw, 'najaf.showroomCars').find(r => r.id === 1);
    return (s.writes.length === 0 && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(sc.createdAt) && x.E.errors.length === 0 && x.J('StorageSchema.lastReport') === null && raw['najaf.schemaVersion'] === '99') || { w: s.writes.slice(0, 4) }; });

  /* ======================= E) السجلات الجديدة ======================= */
  console.log('\n--- E) السجلات الجديدة ---');
  await tc('E1) كل سجل جديد يُكتب بصيغة UTC القانونية وبلحظة صحيحة (±15 ثانية من الآن): مستخدم مسجَّل، معرض تاجر (عند الاعتماد)، سيارة معرض، إعلان عضو (بعد المكافأة)، مفضلة — وتبقى قانونية بعد إعادة التحميل بلا هجرة ولا كتابة', async () => {
    const x = view(null); const reg = x.R(`AuthService.register({name:'تاجر زمن',phone:'07766677788',email:'',password:'secret1',confirmPassword:'secret1',accountType:'dealer'})`);
    const a = view('admin', clone(x.E.store)); a.R(`approveDealer(${reg.user.id})`); const shw = a.J(`ShowroomsRepository.getAll().filter(s=>s.ownerId===${reg.user.id})[0]`);
    const d = view('dealer1', clone(a.E.store)); const car = await d.R(`createShowroomCar({ brand: 'Kia', model: 'TimeTest', year: '2021', price: '1000', currency: 'IQD' })`);
    const u = view('user', clone(d.E.store)); const dr = u.J(`createDraftMemberCar(${JSON.stringify({ brand: 'Honda', model: 'Jazz', year: '2018', price: '9000000', phone: '07700000099', currency: 'IQD' })})`); u.R(`RewardService.requestPublishReward('${dr.draftId}')`); u.R(`RewardService.onRewardCompleted('${dr.draftId}')`); const pub = u.J(`publishMemberCarAfterReward('${dr.draftId}')`);
    const fav = u.J('toggleFavorite(1)'); const favRec = u.J('FavoritesRepository.getAll().filter(f=>f.userId===7&&f.carId===1)[0]');
    const vals = { user: x.J(`UsersRepository.getById(${reg.user.id}).createdAt`), showroom: shw && shw.createdAt, showCar: car.car && car.car.createdAt, member: pub.car && pub.car.createdAt, fav: favRec && favRec.createdAt }; const now = Date.now();
    const bad = Object.entries(vals).filter(([, v]) => !CANON.test(v) || Math.abs(Date.parse(v) - now) > 15000).map(([k]) => k);
    const reload = spy(clone(u.E.store)); const r = view(null, reload.store);
    return (reg.ok && car.ok && pub.ok && fav.ok && bad.length === 0 && reload.writes.filter(k => k !== 'najaf.session').length === 0 && r.J('StorageSchema.lastReport.applied.length') === 0) || { bad, vals }; });
  await tc('E2) لا نظام تاريخ ثانٍ في الكتابة: كل createdAt لسجل يُكتب بـnew Date().toISOString() (أو قيمة مُمرَّرة)، لا Date.now() لسجل (الجلسة ومسودة الذاكرة فقط، وهما ليستا سجلات مخزَّنة بـcreatedAt نصي)، ولا تنسيق يدوي', async () => {
    const files = ['services/userService.js', 'services/showroomService.js', 'services/showroomCarsService.js', 'services/memberCarsService.js', 'services/favoritesService.js'].map(f => strip(read(f))).join('\n');
    const sets = [...files.matchAll(/createdAt:\s*([^,}]+)/g)].map(m => m[1].trim()); const nowVars = [...files.matchAll(/const now = ([^;]+);/g)].map(m => m[1].trim());
    return (sets.every(s => /^(now|new Date\(\)\.toISOString\(\)|Date\.now\(\))$/.test(s)) && sets.filter(s => s === 'Date.now()').length === 1 && /_drafts\[draftId\] = \{ ownerId: owner\.id, data: v\.data, createdAt: Date\.now\(\) \}/.test(files) && nowVars.every(v => v === 'new Date().toISOString()') && !/toLocale|getTimezoneOffset|\.getTime\(\) *\+/.test(files)) || { sets, nowVars }; });

  /* ======================= F) الترتيب (الأحدث) ======================= */
  console.log('\n--- F) ترتيب المضافة حديثًا ---');
  const mkW = fn => { const w = view('admin'); fn(w); return clone(w.E.store); };
  const addCar = (w, id, v, o = {}) => { w.R(`CarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'showroom', showroomId: 1, brand: 'Zeekr', model: 'R' + id, year: 2024, price: 1, currency: 'IQD', mileage: 1, status: 'available' }, v === undefined ? {} : { createdAt: v }, o))}))`); if (!w.R(`CarsRepository.getById(${id})`)) throw new Error('car ' + id); };
  const addMem = (w, id, v, o = {}) => { w.R(`MemberCarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'member', ownerId: 7, brand: 'Zeekr', model: 'M' + id, year: 2024, price: 1, currency: 'IQD', mileage: 1, status: 'active', phone: '07700000001', location: 'x' }, v === undefined ? {} : { createdAt: v }, o))}))`); if (!w.R(`MemberCarsRepository.getById(${id})`)) throw new Error('member ' + id); };
  await tc('F1) صيغ مختلطة تُقارَن بلحظتها لا بنصها: «2027-06-14T12:00:00» (بلا منطقة=09:00Z) و«…T12:00:00+03:00» (09:00Z) و«…T10:00:00Z» و«…T09:30:00.000Z» و«…T13:00:00+05:00» (08:00Z) ← الترتيب 10:00Z ثم 09:30Z ثم التعادل 09:00Z بالمعرّف تنازليًا ثم 08:00Z', async () => {
    const s = mkW(w => { addCar(w, 9501, '2027-06-14T12:00:00'); addCar(w, 9502, '2027-06-14T12:00:00+03:00'); addCar(w, 9503, '2027-06-14T10:00:00Z'); addMem(w, 9504, '2027-06-14T09:30:00.000Z'); addCar(w, 9505, '2027-06-14T13:00:00+05:00'); });
    const g = view(null, s); const ids = g.J('getRecentCars({limit:5}).map(c=>c.id)'); g.R(`go('home')`); const sec = g.E.screen(); const hs = sec.slice(sec.indexOf('id="homeRecent"'), sec.indexOf('id="homeCars"')); const hIds = [...new Set([...hs.matchAll(/go\('(?:memberCarDetails|carDetails)',\s*(\d+)\)/g)].map(m => +m[1]))];
    return (same(ids, [9503, 9504, 9502, 9501, 9505]) && same(hIds.slice(0, 5), ids)) || { ids, hIds: hIds.slice(0, 5) }; });
  await tc('F2) تعادل اللحظة والمعرّف الثانوي: سيارة معرض وإعلان عضو بلحظة واحدة ← الأكبر معرّفًا أولًا (ثانويًا فقط)، وتعادل ثلاثة سجلات بصيغ مختلفة يُحسم كذلك، والمعرّف لا يتحكم بالترتيب حين تختلف اللحظات (الأصغر معرّفًا الأحدث لحظةً يتصدّر)', async () => {
    const s = mkW(w => { addCar(w, 9520, '2027-07-01T12:00:00'); addMem(w, 9521, '2027-07-01T09:00:00Z'); addCar(w, 9519, '2027-07-01T12:00:00+03:00'); addCar(w, 9999, '2027-06-30T12:00:00Z'); addCar(w, 9001, '2027-07-02T00:00:00Z'); });
    const g = view(null, s); const ids = g.J('getRecentCars({limit:5}).map(c=>c.id)'); return same(ids, [9001, 9521, 9520, 9519, 9999]) || ids; });
  await tc('F3) المفقود/التالف أخيرًا بعد كل المؤرَّخ (وبينها بالمعرّف تنازليًا)، لا NaN في الواجهة: سجلات بلا createdAt/null/«»/تالف/تاريخ مستحيل مع سجلات مؤرَّخة قديمة جدًا (2000 لا تُعدّ، 1990 ← تالف) — المؤرَّخ الأقدم يسبق غير المؤرَّخ', async () => {
    const s = mkW(w => { addCar(w, 9531, '2027-08-01T00:00:00Z'); addCar(w, 9532, undefined); addCar(w, 9533, 'garbage'); addCar(w, 9534, null); addCar(w, 9535, '2026-02-30T10:00:00'); addMem(w, 9536, ''); addCar(w, 9537, '2027-01-01T00:00:00Z'); });
    const g = view(null, s); const ids = g.J('getRecentCars().map(c=>c.id)'); const bad = [9532, 9533, 9534, 9535, 9536]; const lastDated = Math.max(...ids.filter(i => !bad.includes(i)).map(i => ids.indexOf(i))); const posBad = bad.map(i => ids.indexOf(i)).sort((a, b) => a - b);
    g.R(`go('recentCars')`); const scr = g.E.screen();
    return (ids[0] === 9531 && ids.indexOf(9537) < ids.indexOf(9532) && posBad.every(p => p > lastDated) && same(bad.slice().sort((a, b) => b - a), posBad.map(p => ids[p])) && !BAD.test(scr)) || { first: ids.slice(0, 3), posBad, lastDated }; });
  await tc('F4) الأحدث بعد الهجرة على تخزين قديم: ترتيب getRecentCars الكامل = ترتيب مرجع مستقل من اللحظات المتوقعة (بذور بلا منطقة +3 وإضافات بصيغ مختلفة)، والتالف/المفقود في الآخر، وقسم الرئيسية أعلى 6 منها، والظهور (سيارات المعارض الفعّالة + الأعضاء النشطون) كما هو، وgetHomeFeed للمعارض الأحدث أولًا', async () => {
    const x = view(null, clone(W.store)); const full = x.J('getRecentCars()'); const pub = new Set(full.map(c => c.id));
    const expMs = c => { const e = c.id < 9000 ? (c.sourceType === 'member' ? W.seedExp.members[c.id] : W.seedExp.cars[c.id]) : ((EXTRA_CARS.concat(EXTRA_MEM).find(z => z[0] === c.id) || [])[2]); return typeof e === 'string' && CANON.test(e) ? Date.parse(e) : -Infinity; };
    const oracle = full.slice().sort((a, b) => (expMs(b) - expMs(a)) || (b.id - a.id)).map(c => c.id);
    const feed = x.J('getHomeFeed(500).cars'); const feedOracle = feed.slice().sort((a, b) => (expMs(b) - expMs(a)) || (b.id - a.id)).map(c => c.id);
    x.R(`go('home')`); const h = x.E.screen(); const hs = h.slice(h.indexOf('id="homeRecent"'), h.indexOf('id="homeCars"')); const hIds = [...new Set([...hs.matchAll(/go\('(?:memberCarDetails|carDetails)',\s*(\d+)\)/g)].map(m => +m[1]))];
    const stored = full.every(c => c.id >= 9000 || CANON.test(c.createdAt));
    return (same(full.map(c => c.id), oracle) && same(hIds, oracle.slice(0, 6)) && same(feed.map(c => c.id), feedOracle) && full.length > 100 && stored && !full.some(c => c.sourceType === 'showroom' && c.showroomId > 5 && c.showroomId !== 9201)) || { first: full.map(c => c.id).slice(0, 5), oracle: oracle.slice(0, 5) }; });
  await tc('F5) سلوك المضافة حديثًا لم يتغيّر: يعتمد visibilityService (سيارات معرض مخفي/أعضاء غير عامة لا تظهر)، المصدر موحَّد (معارض + أعضاء)، limit/query/criteria كما كانت، والمجموعة تساوي getPublicCars("all", null)', async () => {
    const s = mkW(w => { w.R(`ShowroomsRepository.create(ShowroomModel({ id: 9601, name: 'Hid', address: 'x', status: 'pending', ownerId: 4, createdAt: '2027-01-01T00:00:00Z', updatedAt: '2027-01-01T00:00:00Z' }))`); addCar(w, 9602, '2027-12-31T00:00:00Z', { showroomId: 9601 }); addMem(w, 9603, '2027-12-31T00:00:00Z', { status: 'pending' }); addCar(w, 9604, '2027-12-30T00:00:00Z'); addMem(w, 9605, '2027-12-29T00:00:00Z'); });
    const g = view(null, s); const ids = g.J('getRecentCars().map(c=>c.id)'); const srt = a => a.slice().sort((x, y) => x - y);
    return (!ids.includes(9602) && !ids.includes(9603) && same(ids.slice(0, 2), [9604, 9605]) && same(srt(ids), srt(g.J(`getPublicCars('all', null).map(c=>c.id)`))) && g.J('getRecentCars({limit:3}).length') === 3 && g.J(`getRecentCars({ query: 'Zeekr' }).map(c=>c.id)`).slice(0, 2).join() === '9604,9605' && g.J(`getRecentCars({ criteria: { brand: 'Zeekr' } }).length`) === 2) || { ids: ids.slice(0, 4) }; });

  /* ======================= G) فحوص ثابتة ======================= */
  console.log('\n--- G) نظام تاريخ واحد ---');
  await tc('G1) نظام تاريخ واحد: Timestamps معرَّف مرة واحدة (models.js)، ولا Date.parse ولا regex تاريخ ثانٍ في كود التطبيق، وترتيب الأحدث والهجرة وisSeedRecord والمفضلة كلها تستعمله، وgetHomeFeed يستعمل ترتيب الأحدث نفسه', async () => {
    const dirs = ['screens', 'services', 'repositories', 'components', 'navigation', 'models', 'storage']; const files = dirs.flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => d + '/' + f)); const src = Object.fromEntries(files.map(f => [f, strip(read(f))]));
    const all = Object.values(src).join('\n'); const withParse = files.filter(f => /\bDate\.parse\(/.test(src[f]));
    return ((all.match(/const Timestamps = /g) || []).length === 1 && src['models/models.js'].includes('const Timestamps = ') && withParse.length === 0 && !/_ISO_TS/.test(all) && /Timestamps\.parseMs\(v\)/.test(src['services/searchService.js']) && /const newest = _byCreatedDesc/.test(src['services/searchService.js']) && /Timestamps\.parseMs\(f\.createdAt\)/.test(src['services/migrationService.js']) && /Timestamps\.normalize\(SEED_CREATED/.test(src['repositories/carsRepository.js']) && /Timestamps\.normalize\(SEED_CREATED/.test(src['repositories/memberCarsRepository.js']) && /Timestamps\.normalize\(r\.createdAt\)/.test(src['services/migrationService.js'])) || { withParse }; });
  await tc('G2) النطاق: الهجرة 3 فقط تُضاف (CURRENT_VERSION 3)، تغطي سيارات المعارض والأعضاء والمعارض والمستخدمين والمفضلة، 85 سكربتًا بلا ملف جديد، ولا Timestamps في الشاشات/المكوّنات (لا تغيير واجهة)، ولا ذكر لـreserved', async () => {
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length; const mig = strip(read('services/migrationService.js')); const ui = ['screens', 'components'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => strip(read(d + '/' + f)))).join('\n');
    return (order === 85 && ref.R('StorageSchema.CURRENT_VERSION') === 3 && /StorageSchema\.register\(3, 'utc-created-at'/.test(mig) && ['cars', 'memberCars', 'showrooms', 'users', 'favorites'].every(n => mig.includes(`['${n}'`)) && !/Timestamps/.test(ui) && !/reserved|محجوز/i.test(strip(read('models/models.js')).match(/const Timestamps[\s\S]*$/)[0])) || { order }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

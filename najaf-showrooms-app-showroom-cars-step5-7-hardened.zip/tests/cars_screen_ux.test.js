/* اختبارات تبسيط شاشة «السيارات» العامة (UX ج3): بحث بارز + زر «تصفية» + لوحة الفلاتر المتقدمة مطويّة افتراضيًا.
   الطيّ واجهة فقط: لوحة الفلاتر هي FilterBar نفسه (حالته carsFilters ومعالجاته القائمة)، والنتائج من searchCars نفسه، فلا محرك ثانٍ.
   الفحوص البصرية (عدم التراكب/الاقتصاص/overflow، حجم اللمس، التركيز الفعلي، Escape الحقيقي) في Chromium على 320/360/390/412 (انظر التقرير)؛
   هنا نثبّت آليًا ما يمكن تثبيته: الحالة الافتراضية، التبديل والإغلاق بلا مسح، المؤشرات، التفاعل بين البحث والفلاتر، قواعد الظهور، ومنطق Escape. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const CRED = { user: ['07700000001', 'user123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store, { fullSeed: 'p3' }), R = c => E.run(c);
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); E.els.loginIdentifier = { value: c[0], style: {}, textContent: '' }; E.els.loginPassword = { value: c[1], style: {}, textContent: '' }; R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  /** يكتب قيم حقول الفلاتر كما يكتبها المستخدم ثم يستدعي المعالج القائم */
  const setF = o => { const map = { brand: 'Brand', model: 'Model', year: 'Year', minPrice: 'MinPrice', maxPrice: 'MaxPrice', minMileage: 'MinMileage', maxMileage: 'MaxMileage', cur: 'PriceCurrency' };
    Object.entries(map).forEach(([k, v]) => { const id = k === 'cur' ? 'carsPriceCurrency' : 'carsFilter' + v; E.els[id] = { value: o[k] === undefined ? '' : String(o[k]), style: {} }; }); };
  return { E, R, J, setF };
}
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const ids = html => [...new Set([...String(html).matchAll(/go\('carDetails',\s*(\d+)\)/g)].map(m => Number(m[1])))];
const tag = (html, id) => (String(html).match(new RegExp('<[a-z]+[^>]*id="' + id + '"[^>]*>')) || [''])[0];
const isHidden = (html, id) => /\shidden(\s|>|=)/.test(tag(html, id));
const ERR = 'حدث خطأ، حاول مرة أخرى';

(async () => {
  const ref = mk(null); const VIS = ref.J('getVisibleCars()');            // المرجع المستقل: السيارات الظاهرة للزائر من الخدمة العامة
  const hiddenIds = ref.J('CarsRepository.getAll()').map(c => c.id).filter(i => !VIS.some(v => v.id === i));

  /* ======================= A) الحالة الافتراضية ======================= */
  console.log('\n--- A) الحالة الافتراضية: بحث + سيارات، واللوحة مطويّة ---');
  await tc('A1) عند فتح «السيارات»: مربع بحث بارز في الأعلى، وزر «تصفية» بجواره، والسيارات تحتهما مباشرة (الترتيب: بحث/زر ← ملخص ← لوحة ← قائمة)', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen();
    const pos = s => h.indexOf(s);
    return (/class="cars-tools"[\s\S]*class="searchbox"[\s\S]*id="carsRefineToggle"/.test(h) && pos('class="searchbox"') < pos('id="carsRefineToggle"') && pos('id="carsRefineToggle"') < pos('id="carsRefineSummary"') && pos('id="carsRefineSummary"') < pos('id="carsRefinePanel"') && pos('id="carsRefinePanel"') < pos('id="carsList"') && />\s*تصفية\s*</.test(h) && ids(h).length === VIS.length && !h.includes(ERR)) || { len: h.length }; });
  await tc('A2) لوحة الفلاتر المتقدمة مطويّة افتراضيًا (hidden)، والزر aria-expanded="false" بلا شارة، وملخص الفلاتر مخفي، وكل حقول FilterBar القائمة (ماركة/موديل/سنة/عملة/سعر/كيلومترات) موجودة داخل اللوحة لا خارجها', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const panel = h.slice(h.indexOf('id="carsRefinePanel"'), h.indexOf('id="carsList"'));
    const fields = ['carsFilterBrand', 'carsFilterModel', 'carsFilterYear', 'carsPriceCurrency', 'carsFilterMinPrice', 'carsFilterMaxPrice', 'carsFilterMinMileage', 'carsFilterMaxMileage'];
    return (isHidden(h, 'carsRefinePanel') && /aria-expanded="false"/.test(tag(h, 'carsRefineToggle')) && isHidden(h, 'carsRefineBadge') && isHidden(h, 'carsRefineSummary') && fields.every(f => panel.includes('id="' + f + '"') && h.split('id="' + f + '"').length === 2) && panel.includes('id="carsFilterBar"')) || { hiddenPanel: isHidden(h, 'carsRefinePanel') }; });
  await tc('A3) سمات الوصول: الزر type=button وaria-controls يشير للوحة موجودة، والاسم يحوي النص الظاهر «تصفية»، واللوحة role=group بتسمية، ولا معرّف مكرر في الشاشة', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const b = tag(h, 'carsRefineToggle'); const all = [...h.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
    return (/type="button"/.test(b) && /aria-controls="carsRefinePanel"/.test(b) && h.includes('id="carsRefinePanel"') && /aria-label="تصفية السيارات"/.test(b) && /role="group"/.test(tag(h, 'carsRefinePanel')) && /aria-label="تصفية السيارات"/.test(tag(h, 'carsRefinePanel')) && new Set(all).size === all.length) || { b }; });
  await tc('A4) كل سيارات المسار العام تظهر مباشرة بلا فتح اللوحة (قواعد الظهور): الزائر = الظاهرة فقط (سيارات المعرض الموقوف مخفية)، والمدير يرى كل سيارات المعارض', async () => {
    const g = mk(null); g.R(`go('cars')`); const a = mk('admin'); a.R(`go('cars')`);
    return (same(ids(g.E.screen()), VIS.map(v => v.id)) && hiddenIds.length >= 7 && hiddenIds.every(i => !ids(g.E.screen()).includes(i)) && ids(a.E.screen()).length === ref.J('CarsRepository.getAll().length')) || { g: ids(g.E.screen()).length, vis: VIS.length, a: ids(a.E.screen()).length }; });
  await tc('A5) البحث الأساسي والنتائج والخريطة كما كانت: «النتائج: N» بصيغتها، واختصار الخريطة موجود، وحقل البحث ما زال بمعالج onCarsSearch', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const n = x.J('carCountLabel(getVisibleCars().length)');
    return (h.includes(`النتائج: ${n}`) && /onclick="go\('map'\)"[^>]*aria-label="عرض مواقع المعارض على الخريطة"/.test(h) && h.includes('oninput="onCarsSearch(this.value)"')) || { n }; });

  /* ======================= B) فتح/إغلاق اللوحة بلا مسح ======================= */
  console.log('\n--- B) التبديل والإغلاق ---');
  await tc('B1) «تصفية» يفتح اللوحة ويُحدّث الزر؛ والإغلاق (زر التبديل أو «عرض النتائج») يطويها دون مسح أي فلتر، وlا استثناء في أي منها', async () => {
    const x = mk(null); x.R(`go('cars')`); const open0 = x.R('carsFiltersOpen');
    x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onCarsFilter()'); const f1 = x.R('JSON.stringify(carsFilters)');
    x.R('toggleCarsFilterPanel()'); const o1 = x.R('carsFiltersOpen'), p1 = x.E.els.carsRefinePanel.hidden;
    x.R('toggleCarsFilterPanel()'); const o2 = x.R('carsFiltersOpen'), p2 = x.E.els.carsRefinePanel.hidden, f2 = x.R('JSON.stringify(carsFilters)');
    x.R('toggleCarsFilterPanel()'); x.R('closeCarsFilterPanel()'); const o3 = x.R('carsFiltersOpen'), p3 = x.E.els.carsRefinePanel.hidden, f3 = x.R('JSON.stringify(carsFilters)');
    return (open0 === false && o1 === true && p1 === false && o2 === false && p2 === true && f1 === f2 && f2 === f3 && o3 === false && p3 === true && JSON.parse(f3).brand === 'Toyota' && JSON.parse(f3).model === 'Corolla' && x.E.errors.length === 0) || { open0, o1, p1, o2, p2, o3, p3, f1, f3 }; });
  await tc('B2) إعادة فتح اللوحة تحفظ الاختيارات: بعد الإغلاق وإعادة رسم الشاشة تظهر الماركة/الموديل/السنة/السعر/الكيلومترات المختارة في الحقول نفسها (selected/value)', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Toyota', model: 'Corolla', year: '2019', minPrice: '5000000', maxMileage: '100000' }); x.R('onCarsFilter()');
    x.R('toggleCarsFilterPanel()'); x.R('closeCarsFilterPanel()'); x.R('toggleCarsFilterPanel()'); x.R('render()'); const h = x.E.screen();
    const sel = id => (h.match(new RegExp('id="' + id + '"[\\s\\S]*?</select>')) || [''])[0];
    return (/<option value="Toyota" selected>/.test(sel('carsFilterBrand')) && /<option value="Corolla" selected>/.test(sel('carsFilterModel')) && /<option value="2019" selected>/.test(sel('carsFilterYear')) && /id="carsFilterMinPrice"[^>]*value="5000000"/.test(h) && /id="carsFilterMaxMileage"[^>]*value="100000"/.test(h) && !isHidden(h, 'carsRefinePanel')) || 'selections'; });
  await tc('B3) إعادة رسم الشاشة نفسها (مثل ضغط ♡ على سيارة) تحفظ حالة الفتح؛ والدخول الجديد للشاشة (من الرئيسية أو الرجوع من تفاصيل سيارة) يبدأ مطويًّا مع بقاء الفلاتر', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Kia' }); x.R('onCarsFilter()'); x.R('toggleCarsFilterPanel()'); x.R('render()'); const reopen = !isHidden(x.E.screen(), 'carsRefinePanel');
    x.R(`go('home')`); x.R(`go('cars')`); const fresh1 = isHidden(x.E.screen(), 'carsRefinePanel'), kept1 = x.R('carsFilters.brand');
    x.R('toggleCarsFilterPanel()'); x.R(`go('carDetails', 4)`); x.R(`goBack('cars')`); const fresh2 = isHidden(x.E.screen(), 'carsRefinePanel'), kept2 = x.R('carsFilters.brand');
    return (reopen && fresh1 && kept1 === 'Kia' && fresh2 && kept2 === 'Kia') || { reopen, fresh1, kept1, fresh2, kept2 }; });
  await tc('B4) Escape: يطوي اللوحة المفتوحة فقط عند مسار cars، ولا يطويها إن كانت نافذة اقتراحات السعر مفتوحة (أول Escape يغلق النافذة كما كان) أو نافذة حوار نشطة، ولا لمفتاح آخر، ولا يمسح فلاتر', async () => {
    const x = mk(null); x.R(`go('cars')`); const handlers = []; x.E.ctx.document.addEventListener = (type, fn, cap) => handlers.push({ type, fn, cap });
    const src = read('screens/cars.js'); const m = src.match(/\(function bindCarsFilterPanelEscape\(\) \{[\s\S]*?\}\)\(\);/); if (!m) return 'IIFE not found'; x.R(m[0]);
    const h = handlers.find(z => z.type === 'keydown'); if (!h) return 'no keydown listener';
    const fire = key => h.fn({ key }); const open = () => { x.R('carsFiltersOpen = true'); };
    x.setF({ brand: 'Toyota' }); x.R('onCarsFilter()');
    open(); fire('Enter'); const keyOther = x.R('carsFiltersOpen');
    open(); fire('Escape'); const closed = x.R('carsFiltersOpen');
    open(); x.E.ctx.document.querySelector = sel => (String(sel).includes('flt-sugg') ? {} : null); fire('Escape'); const popup = x.R('carsFiltersOpen'); x.E.ctx.document.querySelector = sel => null;
    open(); x.R('ModalFocus.isActive = () => true'); fire('Escape'); const modal = x.R('carsFiltersOpen'); x.R('ModalFocus.isActive = () => false');
    open(); x.R(`currentRoute = 'home'`); fire('Escape'); const other = x.R('carsFiltersOpen'); x.R(`currentRoute = 'cars'`);
    x.R('carsFiltersOpen = false'); fire('Escape'); const already = x.R('carsFiltersOpen');
    return (handlers.length === 1 && h.cap === true && keyOther === true && closed === false && popup === true && modal === true && other === true && already === false && x.R('carsFilters.brand') === 'Toyota') || { n: handlers.length, cap: h.cap, keyOther, closed, popup, modal, other, already }; });

  /* ======================= C) الفلاتر الفعالة والمسح ======================= */
  console.log('\n--- C) مؤشر الفلاتر الفعالة والمسح ---');
  await tc('C1) فلاتر فعالة واللوحة مطويّة: شارة بعدد الفلاتر على الزر (has-filters)، واسم الزر يذكر العدد، وملخص ظاهر خارج اللوحة بـ«فلاتر فعالة (N)» وشاراتها و«مسح الفلاتر»، ولا تكرار للظاهر (نسخة اللوحة المخفية فقط)', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onCarsFilter()'); x.R('render()'); const h = x.E.screen();
    const sum = h.slice(h.indexOf('id="carsRefineSummary"'), h.indexOf('id="carsRefinePanel"'));
    return (/class="filter-toggle has-filters"/.test(tag(h, 'carsRefineToggle')) && /aria-label="تصفية السيارات، فلتران فعّالان"/.test(tag(h, 'carsRefineToggle')) && !isHidden(h, 'carsRefineBadge') && /id="carsRefineBadge"[^>]*>2</.test(h) && !isHidden(h, 'carsRefineSummary') && sum.includes('فلاتر فعالة (2)') && sum.includes('onclick="clearCarsFilters()"') && sum.includes("removeCarsFilter('brand')") && (h.replace(h.slice(h.indexOf('id="carsRefinePanel"'), h.indexOf('id="carsList"')), '').match(/فلاتر فعالة \(2\)/g) || []).length === 1 && isHidden(h, 'carsRefinePanel')) || { sum: sum.slice(0, 200) }; });
  await tc('C2) فلاتر فعالة واللوحة مفتوحة: الملخص الخارجي فارغ ومخفي (الشارات داخل اللوحة فقط) فلا تكرار، والشارة على الزر باقية', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Kia', year: '2015' }); x.R('onCarsFilter()'); x.R('toggleCarsFilterPanel()'); x.R('render()'); const h = x.E.screen();
    const sum = h.slice(h.indexOf('id="carsRefineSummary"'), h.indexOf('id="carsRefinePanel"'));
    return (isHidden(h, 'carsRefineSummary') && !sum.includes('filter-chip') && (h.match(/فلاتر فعالة \(2\)/g) || []).length === 1 && /id="carsRefineBadge"[^>]*>2</.test(h) && !isHidden(h, 'carsRefinePanel')) || { sum: sum.slice(0, 120) }; });
  await tc('C3) إزالة فلتر واحد من الملخص (شارة ×) تحدّث القائمة والشارة بحالة الشاشة نفسها؛ والمسح الكامل يعيد القائمة العادية الكاملة، ويطوي اللوحة، ويزيل المؤشرات، ولا يمسّ نص البحث', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onCarsFilter()'); x.R('onCarsSearch("")');
    x.R(`removeCarsFilter('model')`); const afterOne = x.R('JSON.stringify(carsFilters)'), listOne = ids(x.E.els.carsList.innerHTML);
    x.R('onCarsSearch("toyota")'); x.R('toggleCarsFilterPanel()'); x.R('clearCarsFilters()'); const h = x.E.screen();
    return (JSON.parse(afterOne).model === '' && JSON.parse(afterOne).brand === 'Toyota' && same(listOne, x.J("searchCars('', 'showroom', { brand: 'Toyota' }).map(c=>c.id)")) && x.R('carsFiltersOpen') === false && isHidden(h, 'carsRefinePanel') && isHidden(h, 'carsRefineBadge') && isHidden(h, 'carsRefineSummary') && !/has-filters/.test(tag(h, 'carsRefineToggle')) && !h.includes('فلاتر فعالة') && x.R('activeFilterCount(carsFilters)') === 0 && x.R('carsSearchQuery') === 'toyota') || { afterOne }; });
  await tc('C4) بعد المسح الكامل ومسح البحث تعود القائمة العادية: كل السيارات الظاهرة (بلا فلاتر ولا بحث) بالترتيب والعدد نفسيهما', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Kia', minPrice: '1' }); x.R('onCarsFilter()'); x.R('onCarsSearch("x")'); x.R('clearCarsFilters()'); x.R('clearCarsSearch()');
    return (same(ids(x.E.screen()), VIS.map(v => v.id)) && x.R('carsSearchQuery') === '' && x.R('activeFilterCount(carsFilters)') === 0) || 'not normal list'; });

  await tc('C5) المزامنة الحية بلا إعادة رسم: الشارة تتبع عدد الفلاتر بعد تغيير القوائم (onCarsFilter) وكتابة الأرقام (onCarsRange) وإزالة شارة؛ وملخص الفلاتر يمتلئ عند الطيّ (closeCarsFilterPanel) ويفرغ ويُخفى عند الفتح، وزر «عرض النتائج» يتبع العدد', async () => {
    const x = mk(null); x.R(`go('cars')`); const badge = () => [x.E.els.carsRefineBadge.textContent, x.E.els.carsRefineBadge.hidden];
    x.R('toggleCarsFilterPanel()'); x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onCarsFilter()'); const b2 = badge(), cls2 = x.E.els.carsRefineToggle.className, d2 = x.E.els.carsRefineDone.textContent;
    x.setF({ brand: 'Toyota', model: 'Corolla', minPrice: '1000' }); x.R('onCarsRange()'); const b3 = badge();
    x.R(`removeCarsFilter('model')`); const b2b = badge();
    const openSum = [x.E.els.carsRefineSummary.innerHTML, x.E.els.carsRefineSummary.hidden];
    x.R('closeCarsFilterPanel()'); const closedSum = [x.E.els.carsRefineSummary.innerHTML, x.E.els.carsRefineSummary.hidden], panelHidden = x.E.els.carsRefinePanel.hidden;
    x.R('toggleCarsFilterPanel()'); const reopenSum = [x.E.els.carsRefineSummary.innerHTML, x.E.els.carsRefineSummary.hidden];
    x.R(`removeCarsFilter('brand')`); x.R(`removeCarsFilter('price')`); const b0 = badge(), cls0 = x.E.els.carsRefineToggle.className;
    const n = x.J("searchCars('', 'showroom', carsFilters).length");
    return (b2[0] === '2' && b2[1] === false && /has-filters/.test(cls2) && d2.startsWith('عرض النتائج (') && b3[0] === '3' && b2b[0] === '2' && openSum[0] === '' && openSum[1] === true && closedSum[0].includes('فلاتر فعالة (2)') && closedSum[1] === false && panelHidden === true && reopenSum[0] === '' && reopenSum[1] === true && b0[0] === '0' && b0[1] === true && !/has-filters/.test(cls0) && x.E.els.carsRefineDone.textContent === `عرض النتائج (${x.J(`carCountLabel(${n})`)})`) || { b2, cls2, d2, b3, b2b, openSum: openSum[0].length, closedSum: closedSum[0].slice(0, 80), b0, cls0 }; });

  /* ======================= D) البحث والفلاتر معًا ======================= */
  console.log('\n--- D) البحث + الفلاتر ---');
  const toy = VIS.find(v => v.brand === 'Toyota'), toyYear = String(toy.year), ar = v => String(v).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);   // توليفات مشتقة من بيانات المعارض الظاهرة (لا افتراض يدوي)
  const cor = VIS.find(v => v.model === 'Corolla');
  const COMBOS = [
    { q: 'toyota', f: { year: toyYear }, check: c => c.brand === 'Toyota' && c.year === toy.year, nonEmpty: true },
    { q: 'كورولا', f: {}, check: c => c.model === 'Corolla', nonEmpty: true },
    { q: 'Corolla', f: { year: String(cor.year) }, check: c => c.model === 'Corolla' && c.year === cor.year, nonEmpty: true },
    { q: ar(toy.year), f: { brand: 'Toyota' }, check: c => c.brand === 'Toyota' && c.year === toy.year, nonEmpty: true },
    { q: 'ＴＯＹＯＴＡ', f: { brand: 'Toyota' }, check: c => c.brand === 'Toyota', nonEmpty: true },
    { q: '', f: { brand: 'Mercedes-Benz', model: '190 E' }, check: c => c.brand === 'Mercedes-Benz' && c.model === '190 E', nonEmpty: true },
    { q: 'kia', f: { minPrice: '١٠٬٠٠٠٬٠٠٠', maxPrice: '20,000,000' }, check: c => c.brand === 'Kia' && c.currency === 'IQD' && c.price >= 10e6 && c.price <= 20e6, nonEmpty: true },
    { q: '', f: { cur: 'USD', minPrice: '30000' }, check: c => (c.currency === 'USD' ? c.price : c.price / 1300) >= 30000 - 1e-6, nonEmpty: true },
    { q: '', f: { minMileage: '٢٠٠٬٠٠٠' }, check: c => c.mileage >= 200000, nonEmpty: true },
    { q: 'toyota', f: { brand: 'Kia' }, check: c => false, nonEmpty: false },                // تعارض: لا نتائج (الحالة الفارغة بلا استثناء)
  ];
  await tc('D1) البحث مع الفلاتر معًا = searchCars(q, معايير) نفسه للقائمة المعروضة (بلا منطق مكرر)، وكل نتيجة تحقق الشرطين بمعيار مستقل (ماركة/موديل/سنة/سعر بالدينار والدولار/كيلومترات، أرقام عربية/لاتينية، NFKC)', async () => {
    const x = mk(null); const bad = [];
    for (const c of COMBOS) {
      x.R(`go('home')`); x.R(`go('cars')`); x.setF(c.f); x.R('onCarsFilter()'); x.R(`onCarsSearch(${JSON.stringify(c.q)})`);
      const shown = ids(x.E.els.carsList.innerHTML), eng = x.J(`searchCars(${JSON.stringify(c.q)}, 'showroom', carsFilters).map(r=>r.id)`);
      const objs = shown.map(i => VIS.find(v => v.id === i));
      if (!same(shown, eng) || !objs.every(o => o && c.check(o))) bad.push({ q: c.q, f: c.f, shown: shown.length, eng: eng.length });
      if (c.nonEmpty ? shown.length === 0 : shown.length !== 0) bad.push({ emptiness: c.q, f: c.f, n: shown.length });
    }
    return bad.length === 0 || bad; });
  await tc('D2) عدّاد النتائج وزر «عرض النتائج» يتبعان البحث والفلاتر معًا: «النتائج: N» بعدد القائمة، وزر العرض يحمل العدد نفسه، والحالة الفارغة (تعارض) تعرض رسالة بمسح البحث والفلاتر بلا استثناء', async () => {
    const x = mk(null); x.R(`go('cars')`); x.setF({ brand: 'Toyota', year: String(cor.year) }); x.R('onCarsFilter()'); x.R('onCarsSearch("corolla")');
    const n = x.J("searchCars('corolla', 'showroom', carsFilters).length"), label = x.J(`carCountLabel(${n})`); const countTxt = x.E.els.carsList.innerHTML, done = x.E.els.carsRefineDone.textContent;
    x.setF({ brand: 'Kia' }); x.R('onCarsFilter()'); const empty = x.E.els.carsList.innerHTML;
    return (n >= 1 && countTxt.includes(`النتائج: ${label}`) && done === `عرض النتائج (${label})` && ids(countTxt).length === n && empty.includes('لم نعثر على سيارات مطابقة لبحثك') && empty.includes('clearCarsSearch()') && empty.includes('clearCarsFilters()') && x.E.errors.length === 0) || { n, done, label }; });
  await tc('D3) الفلاتر الديناميكية كما هي: ماركات اللوحة = ماركات السيارات الظاهرة فعلًا (من البيانات، لا قائمة ثابتة)، وموديلات Toyota = موديلات Toyota الظاهرة فقط، والسنوات = السنوات الظاهرة، وعملة البحث دينار/دولار', async () => {
    const x = mk(null); x.R(`go('cars')`); const h = x.E.screen(); const opts = id => [...((h.match(new RegExp('id="' + id + '"[\\s\\S]*?</select>')) || [''])[0].matchAll(/<option value="([^"]+)"/g))].map(m => m[1]);
    const uni = a => [...new Set(a)].sort();
    const brands = uni(opts('carsFilterBrand')), years = opts('carsFilterYear').map(Number).sort((a, b) => b - a);
    x.setF({ brand: 'Toyota' }); x.R('onCarsFilter()'); const models = uni([...(x.E.els.carsFilterBar.innerHTML.match(/id="carsFilterModel"[\s\S]*?<\/select>/) || [''])[0].matchAll(/<option value="([^"]+)"/g)].map(m => m[1]));
    return (JSON.stringify(brands) === JSON.stringify(uni(VIS.map(v => v.brand))) && JSON.stringify(years) === JSON.stringify(uni(VIS.map(v => v.year)).map(Number).sort((a, b) => b - a)) && JSON.stringify(models) === JSON.stringify(uni(VIS.filter(v => v.brand === 'Toyota').map(v => v.model))) && !brands.includes('Geely') && opts('carsPriceCurrency').sort().join() === 'IQD,USD') || { brands: brands.length, models }; });

  /* ======================= E) لا محرك ثانٍ ولا تأثر بالشاشات الأخرى ======================= */
  console.log('\n--- E) فحوص ثابتة ---');
  await tc('E1) الشاشة تعيد استخدام المكوّنات والمحرك القائمين فقط: FilterBar وFilterChips وactiveFilterCount وsearchCars وreadFilters، بلا فلترة/مقارنة أرقام/بيانات ثابتة (لا .filter() على السيارات، لا CarFilters.apply، لا أسماء ماركات أو أرقام سنوات)', async () => {
    const s = strip(read('screens/cars.js'));
    return (/FilterBar\('cars'/.test(s) && /FilterChips\('cars'/.test(s) && /activeFilterCount\(carsFilters\)/.test(s) && /searchCars\(carsSearchQuery, 'showroom', carsFilters\)/.test(s) && /readFilters\('cars'\)/.test(s) && !/\.filter\(|CarFilters\.apply|applyCarFilters|\.sort\(|Repository|localStorage/.test(s) && !/'(Toyota|Kia|Hyundai|Nissan|BMW|Mercedes)/i.test(s) && !/\b(19|20)\d\d\b/.test(s) && !/sugg/i.test(s)) || 'engine'; });
  await tc('E2) كود الطيّ الخاص بالسيارات لا يتسرّب لغيرها: شاشة البحث بشريطها المرئي بلا لوحة مطويّة، وملفات البحث/الرئيسية/المعارض/الأعضاء لا تحوي معرّفات carsRefine، وشاشة السيارات لا تحوي memberRefine؛ وشاشة الأعضاء (UX ج4) لها لوحتها بمعرّفاتها المستقلة memberRefine (لا carsRefine)', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const m = x.E.screen(); x.R(`go('search','kia')`); const s = x.E.screen(); x.R(`go('cars')`); const c = x.E.screen();
    const files = ['screens/memberCars.js', 'screens/search.js', 'screens/home.js', 'screens/showrooms.js'].filter(f => /carsRefine|CarsFilterPanel/.test(read(f)));
    return (m.includes('id="memberFilterBar"') && m.includes('id="memberFilterBrand"') && m.includes('id="memberRefinePanel"') && !/carsRefine/.test(m) && s.includes('id="searchFilterBrand"') && !/id="[a-zA-Z]*Refine/.test(s) && !/filter-panel|filter-toggle/.test(s) && !/memberRefine/.test(c) && files.length === 0 && !/memberRefine|MemberFilterPanel/.test(read('screens/cars.js'))) || { files }; });
  await tc('E3) إضافة filterPopupOpen في مكوّن الفلاتر قراءة فقط (لا تغيّر FilterBar لباقي الشاشات): دالة واحدة جديدة، و FilterBar ما زال يولّد الحقول والشارات نفسها لشاشة الأعضاء', async () => {
    const f = strip(read('components/filters.js')); const x = mk(null); x.R(`go('memberCars')`); const m = x.E.screen();
    return ((f.match(/function filterPopupOpen\(\)/g) || []).length === 1 && /querySelector\('\.flt-sugg:not\(\[hidden\]\)'\)/.test(f) && !/carsRefine|carsFilter/.test(f) && ['memberFilterBrand', 'memberFilterModel', 'memberFilterYear', 'memberFilterMinPrice', 'memberFilterMaxPrice', 'memberFilterMinMileage', 'memberFilterMaxMileage', 'memberPriceCurrency'].every(i => m.includes('id="' + i + '"'))) || 'filters.js'; });
  await tc('E4) CSS: هدف لمس الزر ≥ 44×44، وhidden لا يُلغى بـdisplay (قواعد [hidden] للوحة/الملخص/الشارة)، وبلا ألوان hex ولا white-space:nowrap ولا height ثابت للنص في كتلة UX ج3', async () => {
    const css = read('theme/theme.css'); const i = css.indexOf('/* ---- (UX ج3)'); const b = i >= 0 ? css.slice(i) : '';
    return (b.length > 200 && /\.filter-toggle\{[^}]*min-height:\s*44px/.test(b) && /\.filter-toggle\{[^}]*min-width:\s*44px/.test(b) && /\.ft-badge\[hidden\],\.filter-summary\[hidden\],\.filter-panel\[hidden\]\{display:none;\}/.test(b) && !/#[0-9a-fA-F]{3,6}\b/.test(b) && !/white-space/.test(b) && !/(^|[;{\s])height\s*:/.test(b) && /\.cars-tools\{[^}]*display:flex/.test(b) && /\.cars-tools \.searchbox\{[^}]*min-width:0/.test(b)) || { len: b.length }; });
  await tc('E5) لا تغيير في المعمارية: 85 سكربتًا بلا ملفات جديدة، لا مسار جديد (ROUTES.cars كما هو)، ولا reserved، والتحميل بلا أخطاء JS', async () => {
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length; const x = mk(null);
    return (order === 85 && /cars: \{ render: CarsScreen, nav: 'cars' \}/.test(read('navigation/router.js')) && x.E.errors.length === 0 && x.R("typeof ROUTES.cars.render") === 'function') || { order }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

const { makeEnv } = require('./harness');
const { execSync } = require('child_process');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };

/* ---- codec وهمي يحاكي سلوك المتصفح (أبعاد/صيغة/جودة) ويسجّل ترتيب العمليات ---- */
let _n = 0;
function mkFile(w, h, o = {}) { return { name: 'p' + (++_n) + '.jpg', type: o.type || 'image/jpeg', size: w * h * 3, width: w, height: h, complexity: o.complexity || 1, ORIG: 'ORIGINAL_PIXELS_MARKER_' + _n }; }
function mkCodec(o = {}) {
  const c = { supportsWebp: o.supportsWebp !== false, log: [], encodes: [] };
  c.decode = async (file) => { c.log.push('decode'); return { width: file.width, height: file.height, complexity: file.complexity, close() { c.log.push('close'); } }; };
  c.encode = async (d, w, h, mime, q) => {
    c.log.push('encode'); c.encodes.push({ w, h, mime, q });
    const type = (mime === 'image/webp' && !c.supportsWebp) ? 'image/png' : mime;
    return { type, size: Math.round(w * h * q * 0.2 * d.complexity * (type === 'image/jpeg' ? 1.3 : 1)), compressed: true };
  };
  return c;
}

(async () => {
  const E = makeEnv();
  const R = c => E.run(c);
  const setF = (o) => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = (id, pw) => { R(`go('login')`); setF({ loginIdentifier: id, loginPassword: pw }); R('handleLoginSubmit()'); };
  const codec = mkCodec(); R('ImageService').setCodec(codec);
  const store = R('ImageStore'); const putLog = []; const origPut = store.put;
  store.put = async (id, blob) => { putLog.push({ id, blob, encodesBefore: codec.encodes.length, logBefore: codec.log.slice() }); return origPut(id, blob); };
  const carForm = (o = {}) => { setF({ scBrand: 'Toyota', scModel: 'Avalon', scYear: '2021', scPrice: '31000000', scMileage: '40000', scColor: 'أبيض', scDescription: 'وصف', ...o }); E.els.scTransmission = { value: 'أوتوماتيك' }; E.els.scFuelType = { value: 'بنزين' }; };
  const DEALER1 = ['07701234567', 'dealer123'], DEALER2 = ['07709876543', 'dealer123'];

  t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | '));

  /* ===== 1-3) إضافة سيارة ===== */
  login(...DEALER1);
  R(`go('addShowroomCar')`);
  t('1-pre) التاجر يفتح شاشة إضافة سيارة', R('currentRoute') === 'addShowroomCar');
  carForm();
  await R('handleAddShowroomCarSubmit()');
  const car = R(`getCars().find(c=>c.model==='Avalon')`);
  t('1) التاجر يضيف سيارة إلى معرضه', !!car && car.showroomId === 1 && car.sourceType === 'showroom');
  t('2) السيارة الجديدة تصبح متاحة (active) مباشرة بلا pending', car.status === 'available');
  t('2b) تظهر فورًا في سيارات المعرض وفي القائمة العامة والبحث', R(`getCarsByShowroom(1).some(c=>c.id===${car.id})`) && R(`searchCars('Avalon').some(c=>c.id===${car.id})`) && (R(`go('cars')`), E.screen().includes('Toyota Avalon')));
  t('3) لا Rewarded Ad للتاجر (لا طلب مكافأة ولا نافذة)', R('isRewardRequired()') === false && (R('_currentDraftId') == null));
  const manual = await R(`createShowroomCar({brand:'Kia',model:'ManualShowroom',year:'2020',price:'9000000',showroomId:2})`);
  t('3b) لا يمكن اختيار showroomId يدويًا (يُشتق من حساب التاجر)', manual.ok && manual.car.showroomId === 1);
  const bad = await R(`createShowroomCar({brand:'',model:'',year:'',price:''})`);
  t('3c) التحقق من الحقول المطلوبة', bad.ok === false);

  /* ===== 4-6) تعديل/حذف/حالة ===== */
  const up = R(`updateShowroomCar(${car.id},{price:'32000000',color:'أسود',year:'2022',mileage:'100',showroomId:2,sourceType:'member',status:'sold'})`);
  t('4) التاجر يعدّل سيارته والتعديل يظهر فورًا', up.ok && R(`getCarById(${car.id}).price`) === 32000000 && R(`getCarById(${car.id}).color`) === 'أسود' && R(`getCarById(${car.id}).year`) === 2022);
  t('4b) التعديل لا يغيّر showroomId/sourceType/status', R(`getCarById(${car.id}).showroomId`) === 1 && R(`getCarById(${car.id}).sourceType`) === 'showroom' && R(`getCarById(${car.id}).status`) === 'available');
  t('6) التاجر يغيّر حالة سيارته (sold ثم available — لا حالة reserved بعد الإلغاء)', ['sold', 'available'].every(s => R(`changeShowroomCarStatus(${car.id},'${s}').ok`) === true && R(`getCarById(${car.id}).status`) === s));
  t('6b) حالات غير مسموحة للتاجر تُرفض (suspended/active/عشوائية)', ['suspended', 'active', 'x'].every(s => R(`changeShowroomCarStatus(${car.id},'${s}').ok`) === false));
  R(`go('myShowroomCars')`);
  t('15) شاشة «سيارات معرضي» تعرض سيارات معرضه فقط مع تعديل/حذف/تغيير الحالة وزر إضافة',
    E.screen().includes('Toyota Avalon') && E.screen().includes('+ إضافة سيارة') && E.screen().includes('handleDeleteShowroomCar') && E.screen().includes('handleShowroomCarStatusChange') && !E.screen().includes('Nissan Sunny') && !E.screen().includes('Genesis'));

  /* ===== 7-9) الحماية ===== */
  const foreign = 4; // سيارة معرض 2 (التاجر 2)
  const priceBefore = R(`getCarById(${foreign}).price`);
  t('7) التاجر لا يستطيع تعديل سيارة معرض آخر', R(`updateShowroomCar(${foreign},{price:'1'})`).ok === false && R(`getCarById(${foreign}).price`) === priceBefore);
  t('8) التاجر لا يستطيع حذف سيارة معرض آخر', (await R(`deleteShowroomCar(${foreign})`)).ok === false && R(`getCarById(${foreign})`) !== undefined);
  t('8b) ولا تغيير حالتها ولا تعديل صورها', R(`changeShowroomCarStatus(${foreign},'sold').ok`) === false && (await R(`addCarImage(${foreign}, ${JSON.stringify({})})`)).ok === false);
  t('9) التاجر لا يستطيع تعديل/حذف/تغيير member car', R(`updateShowroomCar(101,{price:'1'})`).ok === false && (await R(`deleteShowroomCar(101)`)).ok === false && R(`changeShowroomCarStatus(101,'sold').ok`) === false && R(`AuthorizationService.canManageCar(101)`) === false);
  R(`go('editShowroomCar',${foreign})`); const r1 = R('currentRoute');
  R(`go('editShowroomCar',101)`); const r2 = R('currentRoute');
  R(`go('editShowroomCar',${car.id})`); const r3 = R('currentRoute');
  t('9b) الراوتر يمنع فتح تعديل سيارة معرض آخر أو سيارة عضو، ويسمح بسيارته', r1 === 'accessDenied' && r2 === 'accessDenied' && r3 === 'editShowroomCar');
  t('9c) الصور: التاجر لا يملك صلاحية صور سيارة معرض آخر ولا سيارة عضو', !R(`AuthorizationService.canManageCarImages(getCarById(${foreign}))`) && !R(`AuthorizationService.canManageCarImages(getCarById(101))`) && R(`AuthorizationService.canManageCarImages(getCarById(${car.id}))`));
  R('handleLogout()');

  login(...DEALER2);
  const d2 = await R(`createShowroomCar({brand:'Kia',model:'D2Car',year:'2021',price:'8000000'})`);
  t('9d) التاجر 2 لا يستطيع ربط سيارة بمعرض التاجر 1 (تُربط بمعرضه هو)', d2.ok && d2.car.showroomId === 2);
  t('9e) التاجر 2 لا يملك صلاحية على سيارة التاجر 1', R(`updateShowroomCar(${car.id},{price:'1'})`).ok === false && (await R(`deleteShowroomCar(${car.id})`)).ok === false);
  R('handleLogout()');

  R(`go('myShowroomCars')`); t('9f) الزائر يُحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
  login('07700000001', 'user123');
  ['myShowroomCars', 'addShowroomCar'].forEach(r => { R(`go('${r}')`); });
  t('28) المستخدم العادي لا يدخل شاشات التاجر ولا يدير سيارات معارض', (R(`go('myShowroomCars')`), R('currentRoute')) === 'accessDenied' && (R(`go('addShowroomCar')`), R('currentRoute')) === 'accessDenied' && R(`updateShowroomCar(${car.id},{price:'1'})`).ok === false && R(`changeShowroomCarStatus(${car.id},'sold').ok`) === false && !(await R(`createShowroomCar({brand:'a',model:'b',year:'2020',price:'1'})`)).ok);
  R('handleLogout()');
  login('07733445566', 'dealer123'); // تاجر pending
  t('9g) تاجر لم تتم الموافقة عليه لا يدخل إدارة السيارات', (R(`go('myShowroomCars')`), R('currentRoute')) === 'accessDenied' && !(await R(`createShowroomCar({brand:'a',model:'b',year:'2020',price:'1'})`)).ok);
  R('handleLogout()');

  /* ===== الصور: الحدود ===== */
  login(...DEALER1);
  const fresh = await R(`createShowroomCar({brand:'Hyundai',model:'Sonata',year:'2021',price:'22000000'})`);
  const fid = fresh.car.id;
  // إضافة 5 صور فعلية عبر الخدمة
  const addImg = (id, f) => { E.ctx.__f = f; return R(`addCarImage(${id}, __f)`); };
  const res = []; for (let i = 0; i < 5; i++) res.push(await addImg(fid, mkFile(4000, 3000)));
  t('10) التاجر يضيف 5 صور كحد أقصى', res.every(r => r.ok) && R(`getCarImages(${fid}).length`) === 5);
  const encBefore = codec.encodes.length;
  const r6 = await addImg(fid, mkFile(4000, 3000));
  t('11) الصورة السادسة تُرفض برسالة الحد الأقصى', r6.ok === false && r6.error === 'تم الوصول إلى الحد الأقصى للصور' && R(`getCarImages(${fid}).length`) === 5);
  t('11b) الرفض يحدث قبل أي معالجة/ضغط للصورة السادسة', codec.encodes.length === encBefore);
  t('12) الصورة الرئيسية محسوبة ضمن الخمس (5 إجمالًا، واحدة رئيسية)', R(`getCarImages(${fid}).length`) === 5 && R(`getCarImages(${fid}).filter(i=>i.isMain).length`) === 1);
  R(`go('editShowroomCar',${fid})`);
  t('12b) العدّاد «الصور 5 / 5» ورسالة الحد ولا زر إضافة', E.screen().includes('الصور 5 / 5') && E.screen().includes('تم الوصول إلى الحد الأقصى للصور') && !E.screen().includes('id="imgFileInput"'));
  const fin = { files: [mkFile(1000, 800)], value: 'C:\\fakepath\\x.jpg' };
  await R('handlePickImages')(fin);
  t('12c) عبر المنتقي: الصورة الزائدة تُرفض ويُفرَّغ حقل الملف الأصلي', R(`getCarImages(${fid}).length`) === 5 && fin.value === '');
  // مسودة (إضافة سيارة جديدة)
  R(`go('addShowroomCar')`);
  const dr = R('_imageCtx').draft; let dOk = 0; for (let i = 0; i < 6; i++) { const r = await dr.add(mkFile(2000, 1500)); if (r.ok) dOk++; }
  t('10b/11c) مسودة صور سيارة المعرض: 5 مقبولة والسادسة مرفوضة', dOk === 5 && dr.count() === 5 && R('_imageCtx').max === 5);
  R('_imageCtx').draft.setMain(2);
  carForm({ scModel: 'DraftCar' }); await R('handleAddShowroomCarSubmit()');
  const dc = R(`getCars().find(c=>c.model==='DraftCar')`);
  t('12d) حفظ السيارة يخزّن صور المسودة المضغوطة (5) بصورة رئيسية واحدة فقط', R(`getCarImages(${dc.id}).length`) === 5 && R(`getCarImages(${dc.id}).filter(i=>i.isMain).length`) === 1);

  /* ===== حد المستخدم 4 ===== */
  R('handleLogout()'); login('07700000001', 'user123');
  const before101 = R(`getCarImages(101).length`); // صورتان تجريبيتان
  const u1 = await addImg(101, mkFile(3000, 2000)), u2 = await addImg(101, mkFile(3000, 2000)), u3 = await addImg(101, mkFile(3000, 2000));
  t('13) المستخدم العادي محدود بـ4 صور (الثالثة المضافة فوق الحد تُرفض)', before101 === 2 && u1.ok && u2.ok && !u3.ok && R(`getCarImages(101).length`) === 4 && R('getMaxImagesForCar(getCarById(101))') === 4);
  R(`go('addMemberCar')`);
  t('13b) شاشة نشر عضو: حد 4 في المنتقي', R('_imageCtx').max === 4);
  const mi = { files: [1, 2, 3, 4, 5].map(() => mkFile(2500, 1800)), value: 'x' };
  await R('handlePickImages')(mi);
  t('13c) اختيار 5 صور دفعة واحدة: تُقبل 4 وتُرفض الخامسة برسالة', R('_imageCtx').draft.count() === 4 && E.screen().length > 0 && R('ImagePickerInner()').includes('الصور 4 / 4') && R('ImagePickerInner()').includes('تم الوصول إلى الحد الأقصى للصور'));
  // تدفق النشر الكامل (Rewarded Ad) مع صورتين: النظام القديم لم يتغير
  R('_imageCtx').draft.remove(3); R('_imageCtx').draft.remove(2);
  setF({ mcBrand: 'Kia', mcModel: 'PhotoCar', mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07700000001', mcWhatsapp: '', mcDescription: '' });
  E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
  R('handleAddMemberCarSubmit()');
  t('13d) مستخدم عادي ما زال يمر بنافذة الإعلان ولا تُنشر السيارة قبل اكتماله', E.els.rewardAdOverlay.style.display === 'flex' && !R(`getMemberCars().some(c=>c.model==='PhotoCar')`));
  R('handleWatchRewardAd()'); E.tick(8);
  await new Promise(r => setTimeout(r, 0));
  const pc = R(`getMemberCars().find(c=>c.model==='PhotoCar')`);
  t('13e) بعد الإعلان تُنشر السيارة active وتُحفظ صورها المضغوطة (2) مع رئيسية واحدة', pc && pc.status === 'active' && R(`getCarImages(${pc.id}).length`) === 2 && R(`getCarImages(${pc.id}).filter(i=>i.isMain).length`) === 1);
  R('handleLogout()');

  /* ===== الضغط ===== */
  const cdc = mkCodec(); R('ImageService').setCodec(cdc);
  const C = async (f, o) => { E.ctx.__f = f; return R('ImageService').compressImage(E.ctx.__f, o); };
  const big = await C(mkFile(4000, 3000));
  t('14) 4000×3000 تُصغَّر إلى 1600×1200 (نسبة الأبعاد محفوظة)', big.ok && big.width === 1600 && big.height === 1200 && cdc.encodes[0].w === 1600 && cdc.encodes[0].h === 1200);
  const port = await C(mkFile(3000, 4000));
  t('14b) الصورة الطولية 3000×4000 → 1200×1600، وأطول ضلع ≤ 1600 دائمًا', port.width === 1200 && port.height === 1600 && [big, port].every(r => Math.max(r.width, r.height) <= 1600));
  const small = await C(mkFile(800, 600)), edge = await C(mkFile(1600, 1600));
  t('15) الصور الصغيرة لا تُكبَّر (800×600 تبقى كما هي، و1600 لا تتغير)', small.width === 800 && small.height === 600 && small.resized === false && edge.width === 1600 && edge.height === 1600);
  t('16) التحويل إلى WebP بجودة 0.8 مبدئيًا', big.type === 'image/webp' && cdc.encodes[0].mime === 'image/webp' && cdc.encodes[0].q === 0.8 && big.quality === 0.8);
  const nw = mkCodec({ supportsWebp: false }); R('ImageService').setCodec(nw);
  const fb = await C(mkFile(4000, 3000));
  t('16b) إن لم يدعم المتصفح ترميز WebP: بديل JPEG مضغوط', fb.ok && fb.type === 'image/jpeg' && nw.encodes[0].mime === 'image/webp' && nw.encodes[1].mime === 'image/jpeg');
  const heavy = mkCodec(); R('ImageService').setCodec(heavy);
  const h2 = await C(mkFile(4000, 3000, { complexity: 2 })), h3 = await C(mkFile(4000, 3000, { complexity: 3 }));
  t('16c) إن زاد الحجم عن 500KB تُخفَّض الجودة تدريجيًا (لا تقل عن 0.6)', h2.ok && h2.quality < 0.8 && h2.quality >= 0.6 && h2.size <= 500 * 1024);
  t('16d) 500KB هدف لا حدّ صارم: صورة معقدة جدًا تُقبل بأدنى جودة بدل الرفض', h3.ok && h3.quality === 0.6 && h3.size > 500 * 1024);
  const notImg = await C({ type: 'application/pdf', name: 'x.pdf' });
  t('16e) ملف ليس صورة يُرفض', notImg.ok === false);
  R('ImageService').setCodec(codec);

  /* ===== عدم الاحتفاظ بالأصل ===== */
  const clog = mkCodec(); R('ImageService').setCodec(clog);
  putLog.length = 0;
  login(...DEALER1);
  const oc = await R(`createShowroomCar({brand:'Kia',model:'OrigTest',year:'2021',price:'5000000'})`);
  const origFile = mkFile(4000, 3000);
  await addImg(oc.car.id, origFile);
  const pl = putLog[putLog.length - 1];
  t('17) الضغط يتم قبل التخزين (decode → encode → close → put)', clog.log.join(',') === 'decode,encode,close' && pl && pl.blob.compressed === true && pl.encodesBefore >= 1);
  t('20) لا تُخزَّن/تُرفع الصورة الأصلية: المخزن استلم النسخة المضغوطة فقط', putLog.length === 1 && pl.blob !== origFile && pl.blob.size < origFile.size && pl.blob.type === 'image/webp');
  t('19) الملف الأصلي غير موجود في بيانات السيارات/الصور ولا في التخزين المحلي', (() => {
    const dump = JSON.stringify([R('CARS'), R('MEMBER_CARS'), R('CAR_IMAGES')]) + Object.values(E.store).join('');
    return !dump.includes('ORIGINAL_PIXELS_MARKER') && !dump.includes(origFile.name);
  })());
  t('18) لا originalImageUrl/originalUrl/originalImage: سجلات الصور بحقولها الخمسة فقط', R('CAR_IMAGES').every(i => Object.keys(i).sort().join() === 'carId,id,imageUrl,isMain,sortOrder') && R('CARS').concat(R('MEMBER_CARS')).every(c => !Object.keys(c).some(k => /^original/i.test(k))));
  t('18b) لا يوجد في الشيفرة أي معرّف originalUrl/originalImage (بعد تجاهل التعليقات)', (() => {
    const root = path.resolve(__dirname, '..'); let bad = [];
    const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => { const p = path.join(d, e.name); if (e.isDirectory()) { if (e.name !== 'tests' && e.name !== 'node_modules') walk(p); } else if (p.endsWith('.js')) { const src = fs.readFileSync(p, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, ''); if (/original(Image|Url|ImageUrl)\b/i.test(src)) bad.push(p); } });
    walk(root); return bad.length === 0;
  })(), 'found');
  t('21) المخزَّن هو المضغوط فقط: imageUrl يشير إلى idb والمخزن يحمل Blob مضغوطًا', R(`getCarImages(${oc.car.id})[0].imageUrl`).startsWith('idb:') && R('ImageStore').has(R(`getCarImages(${oc.car.id})[0].id`)));

  /* ===== حذف/رئيسية ===== */
  const gid = (await R(`createShowroomCar({brand:'Kia',model:'Gallery',year:'2021',price:'5000000'})`)).car.id;
  for (let i = 0; i < 4; i++) await addImg(gid, mkFile(2400, 1800));
  let imgs = R(`getCarImages(${gid})`); const [i1, i2, i3, i4] = imgs.map(i => i.id);
  t('12e) أول صورة تُضاف تصبح رئيسية تلقائيًا', imgs[0].isMain && imgs.filter(i => i.isMain).length === 1 && R(`getCarById(${gid}).mainImage`) === imgs[0].imageUrl);
  const putsBefore = putLog.length;
  t('23) تعيين الصورة الرئيسية يعمل', R(`setMainImage(${i3}).ok`) === true && R(`getCarImages(${gid}).find(i=>i.id===${i3}).isMain`) === true);
  t('24) الرئيسية الجديدة تُلغي السابقة، بلا نسخ ولا رفع مرة ثانية', R(`getCarImages(${gid}).find(i=>i.id===${i1}).isMain`) === false && R(`getCarImages(${gid}).length`) === 4 && putLog.length === putsBefore);
  t('25) لا أكثر من رئيسية واحدة بعد أي سلسلة عمليات', [i2, i4, i1, i3].every(id => { R(`setMainImage(${id})`); return R(`getCarImages(${gid}).filter(i=>i.isMain).length`) === 1; }) && R(`getCarById(${gid}).mainImage`) === R(`getCarImages(${gid}).find(i=>i.isMain).imageUrl`));
  R(`setMainImage(${i2})`);
  const del = await R(`removeCarImage(${i2})`);
  t('22) حذف الصورة يعمل: تُحدَّث القائمة والعدد ويُحذف المضغوط من المخزن', del.ok && R(`getCarImages(${gid}).length`) === 3 && !R('ImageStore').has(i2));
  t('22b) حذف الرئيسية يعيّن صورة أخرى رئيسية تلقائيًا (واحدة فقط)', R(`getCarImages(${gid}).filter(i=>i.isMain).length`) === 1 && R(`getCarImages(${gid}).some(i=>i.isMain)`));
  R(`go('editShowroomCar',${gid})`); t('22c) العدّاد يتحدّث «الصور 3 / 5» ويظهر زر الإضافة', E.screen().includes('الصور 3 / 5') && E.screen().includes('id="imgFileInput"'));
  for (const im of R(`getCarImages(${gid})`).map(i => i.id)) await R(`removeCarImage(${im})`);
  t('22d) بعد حذف كل الصور لا تبقى رئيسية وmainImage فارغ', R(`getCarImages(${gid}).length`) === 0 && R(`getCarById(${gid}).mainImage`) === '');
  t('25b) كل سيارة لها صور لديها رئيسية واحدة بالضبط (بما فيها البيانات التجريبية)', [...new Set(R('CAR_IMAGES').map(i => i.carId))].every(cid => R(`getCarImages(${cid}).filter(i=>i.isMain).length`) === 1));
  // حذف سيارة يحذف صورها
  const delCarId = oc.car.id; const delImgId = R(`getCarImages(${delCarId})[0].id`);
  t('5) التاجر يحذف سيارته، وتُحذف صورها المضغوطة معها', (await R(`deleteShowroomCar(${delCarId})`)).ok && R(`getCarById(${delCarId})`) === undefined && R(`getCarImages(${delCarId}).length`) === 0 && !R('ImageStore').has(delImgId));
  R('handleLogout()');

  /* ===== البحث/Admin/الاستمرارية ===== */
  t('26) البحث الحالي لا يتأثر (showroom/member/all)', R(`searchCars('Toyota').every(c=>c.sourceType==='showroom')`) && R(`searchCars('Toyota','member').every(c=>c.sourceType==='member')`) && R(`searchCars('Toyota','all').some(c=>c.sourceType==='member') && searchCars('Toyota','all').some(c=>c.sourceType==='showroom')`) && R(`searchCars('الفرات').length`) >= 3 && R(`searchCars('Avalon').some(c=>c.id===${car.id})`) && !R(`searchCars('Avalon','member').length`));
  login('07700000000', 'admin123');
  t('27) صلاحيات Admin: يدير أي سيارة معرض وصورها ولوحة الإدارة تعمل', R(`AuthorizationService.canManageCar(${foreign})`) && R(`AuthorizationService.canManageCarImages(getCarById(${foreign}))`) && R(`updateShowroomCar(${foreign},{color:'أحمر'}).ok`) === true && (R(`go('adminHome')`), R('currentRoute')) === 'adminHome' && R(`AuthorizationService.canAccessAdmin()`));
  t('27b) Admin لا يُنشئ سيارة معرض (ليس تاجرًا) ولا تتأثر رسائله', !(await R(`createShowroomCar({brand:'a',model:'b',year:'2020',price:'1'})`)).ok);
  R('handleLogout()');
  t('28b) المستخدم العادي: المفضلة وتفاصيل السيارات ما زالت تعمل', (login('07700000001', 'user123'), R(`handleFavoriteToggle(${car.id})`), R(`isFavorite(${car.id})`)));
  R('handleLogout()');

  // استمرارية بعد إعادة التحميل (سجلات وصفية؛ blobs في IndexedDB بالمتصفح الحقيقي)
  const E2 = makeEnv(E.store);
  t('30) إعادة التحميل: السيارات المضافة والمعدّلة والمحذوفة وسجلات الصور تبقى', E2.run(`getCars().some(c=>c.id===${car.id} && c.price===32000000)`) && !E2.run(`getCars().some(c=>c.id===${delCarId})`) && E2.run(`getCarImages(${fid}).length`) === 5 && E2.errors.length === 0);

  /* ===== الـ codec الحقيقي (BrowserImageCodec) مقابل واجهات متصفح مُحاكاة ===== */
  {
    const B = makeEnv(); const calls = []; let closed = 0, revoked = 0;
    const mkCanvas = (webp) => ({ width: 0, height: 0, getContext() { return { fillRect: () => calls.push('fillRect'), set imageSmoothingQuality(v) { calls.push('smooth:' + v); }, drawImage: (s, x, y, w, h) => calls.push(`draw:${w}x${h}`) }; },
      toBlob(cb, mime, q) { calls.push(`toBlob:${mime}:${q}`); cb({ size: 250000, type: (mime === 'image/webp' && !webp) ? 'image/png' : mime }); } });
    B.ctx.createImageBitmap = async () => ({ width: 4000, height: 3000, close() { closed++; } });
    B.ctx.document.createElement = () => mkCanvas(true);
    const r = await B.run('ImageService').compressImage({ type: 'image/jpeg', name: 'a.jpg' });
    t('31) BrowserImageCodec: createImageBitmap → رسم 1600×1200 → toBlob(webp, 0.8) وتحرير البِتماب الأصلي', r.ok && r.width === 1600 && r.height === 1200 && r.type === 'image/webp' && calls.includes('draw:1600x1200') && calls.includes('toBlob:image/webp:0.8') && closed === 1);
    calls.length = 0; B.ctx.document.createElement = () => mkCanvas(false);
    const r2 = await B.run('ImageService').compressImage({ type: 'image/jpeg', name: 'a.jpg' });
    t('31b) بلا دعم WebP في canvas: يعيد المحاولة JPEG بخلفية بيضاء', r2.ok && r2.type === 'image/jpeg' && calls.includes('toBlob:image/jpeg:0.8') && calls.includes('fillRect'));
    B.ctx.createImageBitmap = undefined; calls.length = 0;
    B.ctx.URL = { createObjectURL: () => 'blob:tmp-original', revokeObjectURL: () => { revoked++; } };
    B.ctx.Image = function () { const self = this; Object.defineProperty(this, 'src', { set() { self.naturalWidth = 3000; self.naturalHeight = 2000; Promise.resolve().then(() => self.onload()); } }); };
    B.ctx.document.createElement = () => mkCanvas(true);
    const r3 = await B.run('ImageService').compressImage({ type: 'image/png', name: 'a.png' });
    t('31c) المتصفحات القديمة: الرابط المؤقت للأصل يُلغى فورًا بعد التحميل', r3.ok && r3.width === 1600 && r3.height === 1067 && revoked >= 1);
  }

  /* ===== المراحل السابقة (تشغيل فعلي) ===== */
  for (const n of [3, 4, 5, 6]) {
    let ok = true; try { execSync(`node ${path.join(__dirname, `phase${n}.test.js`)}`, { stdio: 'pipe' }); } catch (e) { ok = false; }
    t(`29) اختبارات المرحلة ${n} تستمر بالنجاح`, ok);
  }

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('خطأ غير متوقع في الاختبار:', e); process.exit(2); });

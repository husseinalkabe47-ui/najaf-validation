/* اختبارات المرحلة 9: طبقة Repository + محوّل التخزين.
   «إعادة تحميل» = بيئة جديدة كليًا (makeEnv) بنفس التخزين المحلي، كما يحدث في المتصفح. */
const { makeEnv } = require('./harness');
const { execSync } = require('child_process');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer2: ['07709876543', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const reload = (x, role) => mk(role || null, x.E.store);
const quotaErr = () => { const e = new Error('The quota has been exceeded.'); e.name = 'QuotaExceededError'; return e; };
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/^\s*\/\/.*$/gm, '');
const publishAsUser = (x, model) => { x.R(`go('addMemberCar')`); x.setF({ mcBrand: 'Kia', mcModel: model, mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07700000001', mcWhatsapp: '', mcDescription: '' }); x.E.els.mcTransmission = { value: 'أوتوماتيك' }; x.E.els.mcFuelType = { value: 'بنزين' }; x.R('handleAddMemberCarSubmit()'); x.R('handleWatchRewardAd()'); x.E.tick(8); return x.R(`getMemberCars().find(c=>c.model==='${model}')`); };

(async () => {
  /* ============ 1) محوّل التخزين ============ */
  {
    const { E, R } = mk(null); const A = 'AppStorage';
    t('1) المحوّل: مفتاح غير موجود → القيمة الاحتياطية', R(`AppStorage.get('nope')`) === null && R(`AppStorage.get('nope', 42)`) === 42 && R(`AppStorage.get('nope', [])`).length === 0);
    R(`AppStorage.set('k', {a:[1,2]})`);
    t('1b) كتابة/قراءة تحفظ القيمة وتُخزَّن بالبادئة najaf.', R(`AppStorage.get('k').a.length`) === 2 && E.store['najaf.k'] === '{"a":[1,2]}');
    E.store['najaf.bad'] = '{oops'; const corrupted = R(`AppStorage.get('bad', 'FB')`);
    t('1c) JSON تالف → القيمة الاحتياطية بلا استثناء + تسجيل السبب', corrupted === 'FB' && R('AppStorage.getLastError()') === 'corrupted_data');
    t('1d) validate: قيمة بغير الشكل المتوقع تُرفض', R(`AppStorage.set('arr', {x:1}); AppStorage.get('arr', 'FB', Array.isArray)`) === 'FB' && R('AppStorage.getLastError()') === 'invalid_data' && R(`AppStorage.set('arr2', [1]); AppStorage.get('arr2', 'FB', Array.isArray).length`) === 1);
    E.ctx.localStorage.getItem = () => { throw new Error('SecurityError'); };
    t('1e) تخزين غير متاح عند القراءة: لا استثناء، والقيمة من نسخة الذاكرة', R(`AppStorage.get('k').a.length`) === 2 && R(`AppStorage.get('never-set', 'FB')`) === 'FB');
    E.ctx.localStorage.getItem = k => (k in E.store ? E.store[k] : null);
    E.ctx.localStorage.setItem = () => { throw quotaErr(); };
    const q = R(`AppStorage.set('big', {z:1})`);
    t('1f) امتلاء التخزين: {ok:false, error:quota_exceeded}، والقيمة تبقى في الذاكرة', q.ok === false && q.error === 'quota_exceeded' && R(`AppStorage.get('big').z`) === 1);
    E.ctx.localStorage.setItem = () => { throw new Error('denied'); };
    t('1g) تخزين محظور: error = storage_unavailable', R(`AppStorage.set('x', 1)`).error === 'storage_unavailable');
    E.ctx.localStorage.setItem = (k, v) => { E.store[k] = String(v); };
    const circ = R(`(() => { const o = {}; o.self = o; return AppStorage.set('circ', o); })()`);
    t('1h) قيمة غير قابلة للتسلسل: serialize_failed ولا تُخزَّن', circ.ok === false && circ.error === 'serialize_failed' && !('najaf.circ' in E.store));
    R(`AppStorage.set('toRemove', 1)`); const rm = R(`AppStorage.remove('toRemove')`);
    t('1i) remove يحذف من التخزين والذاكرة', rm.ok && R(`AppStorage.get('toRemove', 'gone')`) === 'gone' && !('najaf.toRemove' in E.store));
    // clear(prefix): يحذف مفاتيح التطبيق المطابقة فقط، ولا يلمس مفاتيح غيره
    const ls = E.ctx.localStorage; Object.defineProperty(ls, 'length', { get: () => Object.keys(E.store).length }); ls.key = i => Object.keys(E.store)[i];
    E.store['other.app'] = 'keep'; E.store['najaf.grpA1'] = '1'; E.store['najaf.grpA2'] = '2'; E.store['najaf.keepMe'] = '3';
    const c = R(`AppStorage.clear('grpA')`);
    t('1j) clear(prefix) يحذف مفاتيح التطبيق المطابقة فقط (حتى المكتوبة في جلسة سابقة) ولا يلمس غيرها', c.removed >= 2 && !('najaf.grpA1' in E.store) && !('najaf.grpA2' in E.store) && E.store['najaf.keepMe'] === '3' && E.store['other.app'] === 'keep');
    t('1k) keys() تُظهر مفاتيح التطبيق بلا البادئة', R('AppStorage.keys()').includes('keepMe') && !R('AppStorage.keys()').some(k => k.startsWith('najaf.')));
    // الواجهة القديمة (للتوافق) غلاف فوق المحوّل
    R(`storageSet('legacy', [9])`); t('1l) storageGet/storageSet القديمة تعمل كغلاف فوق المحوّل', R(`storageGet('legacy')[0]`) === 9 && R(`AppStorage.get('legacy')[0]`) === 9 && R(`storageSet('q', 1)`) === true);
  }

  /* ============ 2) عقد الـ Repository ============ */
  {
    const { R } = mk(null);
    const names = R('Object.keys(Repositories)');
    t('2) ستة Repositories (مستخدمون، معارض، سيارات معارض، سيارات أعضاء، صور، مفضلة) تطبّق عقد getAll/getById/create/update/remove/hydrate', names.length === 6 && names.every(n => R(`assertRepository(Repositories.${n})`).length === 0), names.join());
    t('2b) فاحص العقد يكتشف النقص فعلًا', R(`assertRepository({ getAll(){}, getById(){} }).join()`) === 'create,update,remove,hydrate' && R('assertRepository(null).length') === 6);
    t('2c) الامتدادات الخاصة بكل مستودع موجودة', R(`assertRepository(MemberCarsRepository, ['getByOwner','allocateId','getDeletedIds']).length`) === 0 && R(`assertRepository(CarsRepository, ['getByShowroom']).length`) === 0 && R(`assertRepository(CarImagesRepository, ['getByCar','removeByCar','applyLayout']).length`) === 0 && R(`assertRepository(FavoritesRepository, ['getByUser','findByUserAndCar']).length`) === 0);
    t('2d) مستودع الجلسة: get/save/clear', ['get', 'save', 'clear'].every(m => R(`typeof SessionRepository.${m}`) === 'function'));
  }

  /* ============ 3) CRUD لكل Repository (getAll/getById/create/update/remove + السلبية) ============ */
  {
    const specs = [
      ['showrooms', 'ShowroomsRepository', `ShowroomModel({ name: 'معرض اختبار', status: 'active', ownerId: 1, address: 'x' })`, 'showrooms', { status: 'suspended' }, 5, 1],
      ['cars', 'CarsRepository', `CarModel({ sourceType: 'showroom', showroomId: 1, brand: 'T', model: 'R', year: 2020, price: 1, status: 'available' })`, 'showroomCars', { price: 777 }, 15, 1],
      ['memberCars', 'MemberCarsRepository', `CarModel({ sourceType: 'member', ownerId: 7, brand: 'T', model: 'R', year: 2020, price: 1, status: 'active' })`, 'memberCars', { price: 888 }, 10, 101],
      ['carImages', 'CarImagesRepository', `CarImageModel({ carId: 1, imageUrl: 'idb:900' })`, 'carImages', { isMain: true }, 50, null],
      ['favorites', 'FavoritesRepository', `FavoriteModel({ userId: 7, carId: 1, createdAt: 'x' })`, 'favorites', { carId: 2 }, 0, null],
      ['users', 'UsersRepository', `UserModel({ name: 'جديد', phone: '07799990001', role: 'user', status: 'active', passwordHash: 'h' })`, 'registeredUsers', { name: 'مُعدَّل' }, 8, 1],
    ];
    for (const [label, repo, itemExpr, key, patch, seedCount, existingId] of specs) {
      const { E, R } = mk(null);
      const N = `${repo}`;
      const all = R(`${N}.getAll()`);
      const okGetAll = Array.isArray(all) && all.length === seedCount;
      const ex = existingId !== null ? R(`${N}.getById(${existingId})`) : (all[0] || null);
      const okGetById = (existingId === null && seedCount === 0 ? true : !!ex && ex.id !== undefined) && R(`${N}.getById(99999)`) === null && R(`${N}.getById(undefined)`) === null && R(`${N}.getById('x')`) === null && R(`${N}.getById(null)`) === null;
      t(`3) ${label}: getAll وgetById (وعنصر غير موجود/غير صالح → null)`, okGetAll && okGetById, all.length);
      const cr = R(`${N}.create(${itemExpr})`);
      t(`3b) ${label}: create يمنح معرّفًا ويحفظ ويُرجع persisted`, cr.ok && Number.isFinite(cr.item.id) && cr.persisted === true && R(`${N}.getById(${cr.item.id})`) !== null && (key ? (key in {} || true) : true) && ('najaf.' + key in E.store));
      const bads = [R(`${N}.create(null)`), R(`${N}.create('str')`), R(`${N}.create([1])`), R(`${N}.create(undefined)`)];
      t(`3c) ${label}: create ببيانات غير صالحة → invalid_data (لا استثناء)`, bads.every(b => b.ok === false && b.error === 'invalid_data'));
      t(`3d) ${label}: create بمعرّف مكرَّر → duplicate_id`, R(`${N}.create(Object.assign({}, ${N}.getById(${cr.item.id}), {}))`).error === 'duplicate_id');
      const up = R(`${N}.update(${cr.item.id}, ${JSON.stringify(patch)})`);
      const field = Object.keys(patch)[0];
      t(`3e) ${label}: update يدمج التعديل ويحفظ ولا يغيّر المعرّف`, up.ok && up.item[field] === patch[field] && R(`${N}.update(${cr.item.id}, { id: 424242 }).item.id`) === cr.item.id && R(`${N}.getById(424242)`) === null);
      t(`3f) ${label}: update لعنصر غير موجود → not_found، وبمحتوى غير صالح → invalid_data`, R(`${N}.update(99999, {a:1})`).error === 'not_found' && R(`${N}.update(${cr.item.id}, null)`).error === 'invalid_data' && R(`${N}.update(${cr.item.id}, 'x')`).error === 'invalid_data');
      const rmv = R(`${N}.remove(${cr.item.id})`);
      t(`3g) ${label}: remove يحذف ويحفظ، وتكراره/غير الموجود → not_found`, rmv.ok && R(`${N}.getById(${cr.item.id})`) === null && R(`${N}.remove(${cr.item.id})`).error === 'not_found' && R(`${N}.remove(99999)`).error === 'not_found');
    }
    // خصوصيات
    const u = mk(null);
    t('3h) users: حذف مستخدم تجريبي محمي (protected_record)، والمسجَّل يُحذف', u.R(`UsersRepository.remove(1)`).error === 'protected_record' && u.R(`UsersRepository.getById(1)`) !== null);
    const f = mk(null);
    t('3i) favorites: create بلا userId/carId رقميين → invalid_data', f.R(`FavoritesRepository.create({ id: 1 })`).error === 'invalid_data' && f.R(`FavoritesRepository.create({ userId: 'a', carId: 1 })`).error === 'invalid_data');
    const im = mk(null);
    t('3j) carImages: create بلا carId/imageUrl → invalid_data', im.R(`CarImagesRepository.create({ imageUrl: 'x' })`).error === 'invalid_data' && im.R(`CarImagesRepository.create({ carId: 1 })`).error === 'invalid_data');
    t('3k) الجلسة: save/get/clear، وجلسة بلا userId رقمي تُعدّ غير موجودة', (() => { const s = mk(null); s.R(`SessionRepository.save({ userId: 7, createdAt: 1, expiresAt: 9e15 })`); const a = s.R('SessionRepository.get().userId') === 7; s.R('SessionRepository.clear()'); const b = s.R('SessionRepository.get()') === null; s.R(`AppStorage.set('session', { userId: '7' })`); return a && b && s.R('SessionRepository.get()') === null; })());
  }

  /* ============ 4) سيارات الأعضاء: حفظ، سجل المحذوفات، المعرّفات ============ */
  {
    const a = mk('user'); const car = publishAsUser(a, 'Ph9Add');
    t('4) نشر سيارة عضو بعد الإعلان المكافأ (active) ويُحفظ عبر المستودع', car && car.status === 'active' && a.R(`MemberCarsRepository.getById(${car.id}) !== null`) && JSON.parse(a.E.store['najaf.memberCars']).some(c => c.id === car.id));
    const r1 = a.R(`updateMemberCar(101, { price: '17,250,000' })`);
    t('4b) تعديل سيارة تجريبية عبر الخدمة: persisted=true والقيمة مخزَّنة', r1.ok && r1.persisted === true && JSON.parse(a.E.store['najaf.memberCars']).find(c => c.id === 101).price === 17250000);
    a.E.ctx.confirm = () => true; const del = a.R(`deleteMemberCar(103)`);
    t('4c) حذف سيارة تجريبية يُسجَّل صراحةً في najaf.memberCarsDeleted', del.ok && JSON.parse(a.E.store['najaf.memberCarsDeleted']).includes(103) && !JSON.parse(a.E.store['najaf.memberCars']).some(c => c.id === 103));
    const b = reload(a, 'user');
    t('4d) بعد إعادة التحميل: الجديدة باقية، والمعدَّلة باقية، والمحذوفة لا تعود', b.R(`getMemberCarById(${car.id})`) !== null && b.R('getMemberCarById(101).price') === 17250000 && b.R('getMemberCarById(103)') === null && b.R('MemberCarsRepository.getAll().length') === 10);
    a.E.ctx.confirm = () => true; const gone = a.R(`deleteMemberCar(${car.id})`);
    const c = reload(a, 'user'); const next = publishAsUser(c, 'Ph9Next');
    t('4e) حذف السيارة الجديدة ثم إعادة التحميل: لا تعود، والمعرّف المحذوف لا يُعاد استخدامه', gone.ok && c.R(`getMemberCarById(${car.id})`) === null && next.id > car.id);
    const ids = [c.R('MemberCarsRepository.allocateId()'), c.R('MemberCarsRepository.allocateId()'), c.R('MemberCarsRepository.allocateId()')];
    t('4f) allocateId تصاعدي صارم (لا تكرار ولا تراجع)', ids[0] < ids[1] && ids[1] < ids[2]);
    const legacy = mk('admin'); const arr = legacy.R('JSON.parse(JSON.stringify(MemberCarsRepository.getAll()))').filter(x => x.id !== 110);
    const L = mk(null, { 'najaf.memberCars': JSON.stringify(arr) });
    t('4g) ترحيل محفوظات قديمة (بلا سجل): السيارة الغائبة تُعدّ محذوفة ويُكتب السجل ولا تُمسح مفاتيح أخرى', L.R('getMemberCarById(110)') === null && JSON.parse(L.E.store['najaf.memberCarsDeleted']).join() === '110' && L.R('MemberCarsRepository.getAll().length') === 9);
    const G = mk(null, { 'najaf.memberCars': '[{"x":1},null,"y"]' });
    t('4h) محفوظات كلها تالفة بلا سجل: لا يُستنتج منها أي حذف (10 سيارات)', G.R('MemberCarsRepository.getAll().length') === 10 && JSON.parse(G.E.store['najaf.memberCarsDeleted']).length === 0);
    const d = mk('dealer1');
    t('4i) التاجر ينشر سيارة عضو مباشرة active بلا إعلان (سلوك المرحلة 6 كما هو)', (() => { d.R(`go('addMemberCar')`); d.setF({ mcBrand: 'Kia', mcModel: 'DealerPh9', mcYear: '2021', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07701234567', mcWhatsapp: '', mcDescription: '' }); d.E.els.mcTransmission = { value: 'أوتوماتيك' }; d.E.els.mcFuelType = { value: 'بنزين' }; d.R('handleAddMemberCarSubmit()'); return d.R(`getMemberCars().find(c=>c.model==='DealerPh9').status`) === 'active' && d.R('isRewardRequired()') === false; })());
    const own = mk('user');
    t('4j) المستخدم لا يعدّل/يحذف سيارة عضو آخر، والزائر لا يفعل شيئًا (الصلاحيات كما هي)', own.R(`updateMemberCar(102,{price:'1'})`).ok === false && own.R(`deleteMemberCar(102)`).ok === false && mk(null).R(`deleteMemberCar(101)`).ok === false && own.R('getMemberCarById(102).price') !== 1);
  }

  /* ============ 5) سيارات المعارض والمعارض ============ */
  {
    const dl = mk('dealer1'); dl.R('ImageService').setCodec({ decode: async f => ({ width: f.width, height: f.height, close() {} }), encode: async (d, w, h, m, q) => ({ type: m, size: 1000, compressed: true }) });
    const created = await dl.R(`createShowroomCar({ brand: 'Kia', model: 'Ph9Show', year: '2021', price: '9,000,000', mileage: '5,000' })`);
    t('5) التاجر يضيف سيارة لمعرضه عبر CarsRepository (showroomId من حسابه، available، persisted)', created.ok && created.car.showroomId === 1 && created.car.status === 'available' && created.persisted === true && JSON.parse(dl.E.store['najaf.showroomCars']).some(c => c.id === created.car.id));
    const up = dl.R(`updateShowroomCar(${created.car.id}, { price: '9,500,000' })`), st = dl.R(`changeShowroomCarStatus(${created.car.id}, 'sold')`);
    const r = reload(dl, 'dealer1');
    t('5b) بعد إعادة التحميل: السيارة وتعديلها وحالتها باقية', up.ok && st.ok && r.R(`getCarById(${created.car.id}).price`) === 9500000 && r.R(`getCarById(${created.car.id}).status`) === 'sold' && r.R('getCars().length') === 16);
    const del = await r.R(`deleteShowroomCar(${created.car.id})`); const r2 = reload(r, 'dealer1');
    t('5c) حذف سيارة المعرض يبقى بعد إعادة التحميل (لا تعود)', del.ok && del.persisted === true && r2.R(`getCarById(${created.car.id})`) === undefined && r2.R('getCars().length') === 15);
    t('5d) التاجر لا يدير سيارات معرض تاجر آخر (تعديل/حذف/حالة/صور) ولا يربط سيارة بمعرضه', dl.R(`updateShowroomCar(4,{price:'1'})`).ok === false && (await dl.R(`deleteShowroomCar(4)`)).ok === false && dl.R(`changeShowroomCarStatus(4,'sold')`).ok === false && !dl.R(`AuthorizationService.canManageCarImages(getCarById(4))`) && dl.R(`getCarById(4).price`) !== 1 && dl.R(`getMyShowroomCars().every(c => c.showroomId === 1)`));
    t('5e) التاجر لا يدير سيارة عضو، ولا معرضًا آخر', dl.R(`updateShowroomCar(101,{price:'1'})`).ok === false && dl.R(`AuthorizationService.canManageShowroom(2)`) === false && dl.R(`AuthorizationService.getManagedShowrooms().map(s=>s.id).join()`) === '1');
    const foreign = mk('dealer1'); foreign.R(`go('editShowroomCar', 4)`);
    t('5f) الراوتر يمنع التاجر من فتح تعديل سيارة معرض آخر', foreign.R('currentRoute') === 'accessDenied');
    t('5g) المدير يدير أي سيارة معرض (تعديل/حالة) — سلوك كما هو', (() => { const a = mk('admin'); return a.R(`updateShowroomCar(4,{color:'أحمر'}).ok`) && a.R(`setShowroomCarStatus(4,'sold').ok`) && a.R('getCarById(4).color') === 'أحمر'; })());
    // المعارض
    const ad = mk('admin'); const sus = ad.R(`suspendShowroom(2)`);
    t('5h) المدير يوقف معرضًا عبر ShowroomsRepository (persisted)', sus.ok && sus.persisted === true && ad.R('getShowroomById(2).status') === 'suspended' && JSON.parse(ad.E.store['najaf.showrooms']).find(s => s.id === 2).status === 'suspended');
    const after = reload(ad, 'admin');
    t('5i) الإيقاف يبقى بعد إعادة التحميل (كان يضيع قبل المرحلة 9)', after.R('getShowroomById(2).status') === 'suspended');
    const act = after.R(`activateShowroom(2)`); const again = reload(after, 'admin');
    t('5j) إعادة التفعيل تبقى أيضًا', act.ok && again.R('getShowroomById(2).status') === 'active');
    const dd = mk('dealer1');
    t('5k) التاجر لا يوقف/يفعّل معرضًا (إجراء إداري)، والمعرض غير الموجود → رسالة عربية', dd.R(`suspendShowroom(1)`).ok === false && dd.R('getShowroomById(1).status') === 'active' && mk('admin').R(`suspendShowroom(999)`).error === 'المعرض غير موجود.');
    const badShow = mk(null, { 'najaf.showrooms': '[{"id":"x"},null]' }); const emptyShow = mk(null, { 'najaf.showrooms': '[]' }); const jsonBad = mk(null, { 'najaf.showrooms': '{bad' });
    t('5l) معارض محفوظة تالفة/فارغة/JSON تالف: تبقى المعارض التجريبية (5)', [badShow, emptyShow, jsonBad].every(x => x.R('getShowrooms().length') === 5 && x.E.errors.length === 0));
  }

  /* ============ 6) المستخدمون والجلسة ============ */
  {
    const r = mk(null); r.R(`go('register')`); r.setF({ regName: 'سالم حسن', regPhone: '07712345678', regEmail: 's@example.com', regPassword: 'pass123', regConfirm: 'pass123' }); r.R('handleRegisterSubmit()');
    t('6) التسجيل ينشئ حسابًا عبر UsersRepository ويسجّل الدخول (الجلسة في SessionRepository)', r.R('SessionService.getCurrentUser().name') === 'سالم حسن' && r.R('SessionRepository.get().userId') === r.R('SessionService.getCurrentUser().id'));
    const b = reload(r);
    t('6b) بعد إعادة التحميل: الحساب والجلسة باقيان', b.R('SessionService.getCurrentUser().name') === 'سالم حسن' && b.R(`UserService._findByIdentifier('07712345678') !== null`));
    b.R('handleLogout()'); const c = reload(b);
    t('6c) الخروج يمسح الجلسة من التخزين فيبقى الزائر بعد إعادة التحميل', !c.R('SessionService.isLoggedIn()') && !('najaf.session' in c.E.store));
    t('6d) الأرقام العربية والبريد بحروف كبيرة في الدخول كما كانت', (() => { const x = mk(null); x.R(`go('login')`); x.setF({ loginIdentifier: 'USER@example.com', loginPassword: 'user123' }); x.R('handleLoginSubmit()'); return x.R('SessionService.isLoggedIn()'); })());
    const pub = mk('admin');
    t('6e) كلمة المرور لا تخرج من طبقة البيانات عبر الخدمات (adminGetAllUsers/getPublicById/getProfile)', pub.R('adminGetAllUsers().every(u => u.passwordHash === undefined)') && pub.R('UserService.getPublicById(1).passwordHash') === undefined && pub.R('UserService.getProfile(2).passwordHash') === undefined && pub.R('UsersRepository.getById(1).passwordHash') !== undefined);
    // موافقة/رفض تاجر: تُحفظ
    const ad = mk('admin'); const ap = ad.R(`approveDealer(8)`);
    t('6f) الموافقة على تاجر (مستخدم تجريبي pending) تمر عبر UsersRepository وتُحفظ كتعديل (userOverrides)', ap.ok && ap.persisted === true && JSON.parse(ad.E.store['najaf.userOverrides'])['8'].status === 'active' && !('passwordHash' in JSON.parse(ad.E.store['najaf.userOverrides'])['8']));
    const origHash = ad.R('UsersRepository.getById(8).passwordHash');
    const evil = ad.R(`UsersRepository.update(8, { status: 'active', passwordHash: 'evil', id: 999 })`);
    const ovr = JSON.parse(ad.E.store['najaf.userOverrides'])['8'];
    const afterEvil = reload(ad, 'admin');
    t('6f2) تعديلات المستخدم التجريبي لا تحمل passwordHash/id في التخزين، ولا يتغير معرّفه ولا كلمة مروره بعد إعادة التحميل', evil.ok && evil.item.id === 8 && !('passwordHash' in ovr) && !('id' in ovr) && afterEvil.R('UsersRepository.getById(8).passwordHash') === origHash && afterEvil.R('UsersRepository.getById(999)') === null);
    const re = reload(ad, 'admin');
    t('6g) الموافقة تبقى بعد إعادة التحميل (كانت تضيع قبل المرحلة 9)، والتاجر يدخل', re.R('UsersRepository.getById(8).status') === 'active' && (() => { const d8 = mk(null, re.E.store); d8.R('handleLogout()'); d8.R(`go('login')`); d8.setF({ loginIdentifier: '07733445566', loginPassword: 'dealer123' }); d8.R('handleLoginSubmit()'); return d8.R('SessionService.getCurrentUser().status') === 'active' && d8.R('AuthorizationService.canAccessDealerArea()'); })());
    re.R('handleLogout()'); re.login('admin');   // الجلسة مشتركة عبر التخزين: الخطوة السابقة دخلت كتاجر في نفس التخزين
    const rj = re.R(`rejectDealer(8)`); const re2 = reload(re, 'admin');
    t('6h) رفض التاجر يبقى، ولا يستطيع الدخول (حساب موقوف)', rj.ok && re2.R('UsersRepository.getById(8).status') === 'suspended' && (() => { const d8 = mk(null, re2.E.store); d8.R('handleLogout()'); d8.R(`go('login')`); d8.setF({ loginIdentifier: '07733445566', loginPassword: 'dealer123' }); d8.R('handleLoginSubmit()'); return !d8.R('SessionService.isLoggedIn()'); })());
    const reg = mk(null); reg.R(`go('register')`); reg.setF({ regName: 'تاجر جديد', regPhone: '07766666666', regEmail: '', regPassword: 'abc123', regConfirm: 'abc123' }); reg.E.radios.accountType = 'dealer'; reg.R('handleRegisterSubmit()');
    const newId = reg.R('SessionService.getCurrentUser().id'); const adm = mk('admin', reg.E.store); adm.R(`approveDealer(${newId})`); const after = reload(adm, 'admin');
    t('6i) تاجر مسجَّل حديثًا: الموافقة تُحفظ ضمن سجله، لا كتعديل تجريبي', after.R(`UsersRepository.getById(${newId}).status`) === 'active' && !(String(newId) in JSON.parse(after.E.store['najaf.userOverrides'] || '{}')));
    const u1 = mk('user'); t('6j) المستخدم والتاجر لا يوافقان على تجار (الصلاحيات كما هي)', u1.R(`approveDealer(8)`).ok === false && mk('dealer1').R(`approveDealer(8)`).ok === false && u1.R('UsersRepository.getById(8).status') === 'pending');
    t('6k) الأدوار والصلاحيات كما هي: زائر/مستخدم/تاجر/مدير', !mk(null).R('AuthorizationService.canAccessAdmin()') && !u1.R('AuthorizationService.canAccessDealerArea()') && mk('dealer1').R('AuthorizationService.canAccessDealerArea()') && mk('admin').R('AuthorizationService.canAccessAdmin()'));
    // الجلسة
    const exp = mk(null, { 'najaf.session': JSON.stringify({ userId: 7, createdAt: 1, expiresAt: 2 }) });
    const badS = mk(null, { 'najaf.session': '{bad' }); const strS = mk(null, { 'najaf.session': JSON.stringify({ userId: '7', expiresAt: 9e15 }) }); const ghost = mk(null, { 'najaf.session': JSON.stringify({ userId: 9999, expiresAt: 9e15 }) });
    t('6l) جلسة منتهية/تالفة/بمعرّف نصي/لمستخدم غير موجود → زائر بلا أخطاء', [exp, badS, strS, ghost].every(x => !x.R('SessionService.isLoggedIn()') && x.E.errors.length === 0));
    const badUsers = mk(null, { 'najaf.registeredUsers': '[{"id":"x"},null,"z",{"id":77,"name":"ok","phone":"07700000077","role":"user","passwordHash":"h"}]' });
    t('6m) مستخدمون محفوظون بعضهم تالف: يُتجاهل التالف ويُستعاد الصالح', badUsers.R('UsersRepository.getById(77) !== null') && badUsers.R('UsersRepository.getAll().length') === 9 && badUsers.E.errors.length === 0);
    const dup = mk(null); dup.R(`go('register')`); dup.setF({ regName: 'سالم حسن', regPhone: '07712345678', regEmail: '', regPassword: 'pass123', regConfirm: 'pass123' }); dup.R('handleRegisterSubmit()'); dup.R('handleRegisterSubmit()');
    t('6n) تسجيل مكرر لنفس الرقم لا ينشئ حسابين', dup.R(`UsersRepository.getAll().filter(u => u.phone === '07712345678').length`) === 1);
  }

  /* ============ 7) المفضلة ============ */
  {
    const u = mk('user'); u.R('handleFavoriteToggle(1)'); u.R('handleFavoriteToggle(104)');
    u.R('handleLogout()'); u.login('dealer1'); u.R('handleFavoriteToggle(2)');
    const dealerFavs = u.R('getFavoriteCars().map(c=>c.id).join()');
    u.R('handleLogout()'); u.login('user');
    const userFavs = u.R('getFavoriteCars().map(c=>c.id).sort((a,b)=>a-b).join()');
    t('7) مفضلة كل مستخدم منفصلة (المستخدم: 1 و104، التاجر: 2)', userFavs === '1,104' && dealerFavs === '2' && u.R('FavoritesRepository.getByUser(7).length') === 2 && u.R('FavoritesRepository.getByUser(1).length') === 1 && u.R('FavoritesRepository.getAll().length') === 3);
    const r = reload(u, 'user');
    t('7b) تبقى بعد إعادة التحميل (3 سجلات، ومعرّفاتها فريدة)', r.R('getFavoriteCars().map(c=>c.id).sort((a,b)=>a-b).join()') === '1,104' && r.R('FavoritesRepository.getAll().length') === 3 && r.R('new Set(FavoritesRepository.getAll().map(f=>f.id)).size') === 3);
    r.R('handleFavoriteToggle(1)'); const r2 = reload(r, 'user');
    t('7c) إزالة مفضلة تبقى بعد إعادة التحميل، والأخرى باقية', !r2.R('isFavorite(1)') && r2.R('isFavorite(104)') && r2.R('FavoritesRepository.getAll().length') === 2);
    const adm = mk('admin', r2.E.store); adm.E.ctx.confirm = () => true; adm.R('deleteMemberCar(104)'); const r3 = reload(adm, 'user');
    t('7d) مفضلة سيارة حُذفت لا تظهر للمستخدم، وسجلها يُنظَّف عند الحذف (بند «تنظيف Favorites» في المرحلة 9 Fix؛ كان السجل يبقى)', !r3.R('getFavoriteCars().some(c => c.id === 104)') && !r3.R('FavoritesRepository.getByUser(7).some(f => f.carId === 104)'));
    const g = mk(null); t('7e) الزائر لا يضيف مفضلة (login_required)', g.R('toggleFavorite(1)').reason === 'login_required' && g.R('FavoritesRepository.getAll().length') === 0);
    const bad = mk('user'); bad.R(`AppStorage.set('favorites', 'oops')`); const b2 = mk(null, { 'najaf.favorites': '[{"id":1},null,{"userId":7,"carId":2,"id":5}]' });
    t('7f) مفضلة محفوظة تالفة: تُهمل غير الصالحة وتبقى الصالحة', b2.R('FavoritesRepository.getAll().length') === 1 && b2.E.errors.length === 0);
    const ok = mk('user').R('toggleFavorite(1)');
    t('7g) نتيجة الإضافة تحمل persisted=true، والسيارة غير الموجودة not_found', ok.ok && ok.persisted === true && mk('user').R('toggleFavorite(99999)').reason === 'not_found');
  }

  /* ============ 8) الصور ============ */
  {
    const a = mk('dealer1');
    t('8) المستودع يرتّب صور السيارة ويضمن رئيسية واحدة (البيانات التجريبية)', a.R('CarImagesRepository.getByCar(1).map(i=>i.sortOrder).join()') === '0,1' && a.R('CarImagesRepository.getByCar(1).filter(i=>i.isMain).length') === 1);
    a.R(`CarImagesRepository.getByCar(1)[1].isMain = true`); const lay = a.R('CarImagesRepository.applyLayout(1)');
    t('8b) applyLayout يُبقي رئيسية واحدة بالضبط ويرقّم من جديد', lay.ok && a.R('CarImagesRepository.getByCar(1).filter(i=>i.isMain).length') === 1 && a.R('CarImagesRepository.getByCar(1).map(i=>i.sortOrder).join()') === '0,1');
    const rem = a.R('CarImagesRepository.removeByCar(2)');
    t('8c) removeByCar يحذف ويعيد السجلات المحذوفة ويحفظ', rem.length === 2 && a.R('CarImagesRepository.getByCar(2).length') === 0 && JSON.parse(a.E.store['najaf.carImages']).every(i => i.carId !== 2));
    const rl = reload(a, 'dealer1'); t('8d) بعد إعادة التحميل صور السيارة المحذوفة لا تعود', rl.R('getCarImages(2).length') === 0 && rl.R('getCarImages(1).length') === 2);
    const bad = mk(null, { 'najaf.carImages': '[{"id":"a"},null]' }); const empty = mk(null, { 'najaf.carImages': '[]' });
    t('8e) صور محفوظة تالفة تُتجاهل (50 سجلًا تجريبيًا)، و[] المقصودة تُطبَّق', bad.R('getCarImages(1).length') === 2 && bad.R('CarImagesRepository.getAll().length') === 50 && empty.R('CarImagesRepository.getAll().length') === 0);
    const srcs = ['services/imageService.js', 'services/imageStore.js', 'services/rewardService.js'].map(f => strip(fs.readFileSync(path.join(ROOT, f), 'utf8')));
    t('8f) ImageService وImageStore وRewardService لا تعتمد على الـ Repositories ولا المحوّل (بقيت كما هي)', srcs.every(s => !/Repository|AppStorage|storageGet|storageSet/.test(s)));
    const ml = mk('user'); ml.R('ImageService').setCodec({ decode: async f => ({ width: f.width, height: f.height, close() {} }), encode: async (d, w, h, m, q) => ({ type: m, size: 1, compressed: true }) });
    ml.E.ctx.__f = { type: 'image/jpeg', name: 'a.jpg', size: 9, width: 4000, height: 3000 }; const i1 = await ml.R(`addCarImage(101, __f)`), i2 = await ml.R(`addCarImage(101, __f)`), i3 = await ml.R(`addCarImage(101, __f)`);
    t('8g) حدّ صور العضو 4 ما زال سليمًا عبر المستودع (2 تجريبية + 2 جديدة، والثالثة ترفض)', i1.ok && i2.ok && !i3.ok && ml.R('getCarImages(101).length') === 4 && ml.R('getCarImages(101).filter(i=>i.isMain).length') === 1);
  }

  /* ============ 9) فصل الطبقات (فحص ثابت للشيفرة) ============ */
  {
    const read = (dir) => fs.readdirSync(path.join(ROOT, dir)).filter(f => f.endsWith('.js')).map(f => [dir + '/' + f, strip(fs.readFileSync(path.join(ROOT, dir, f), 'utf8'))]);
    const services = read('services'), repos = read('repositories'), ui = read('components').concat(read('screens'), read('navigation'), [['app.js', strip(fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8'))]]);
    const direct = /\blocalStorage\b|\bsessionStorage\b|\bstorageGet\b|\bstorageSet\b|\bstorageRemove\b|\bAppStorage\b|\bLocalStorageAdapter\b/;
    const badSvc = services.filter(([f, s]) => f !== 'services/storageService.js' && direct.test(s)).map(([f]) => f);
    t('9) لا خدمة تلمس التخزين مباشرة (localStorage/storageGet/AppStorage) — فقط الـ Repositories', badSvc.length === 0, badSvc.join());
    const badUi = ui.filter(([f, s]) => direct.test(s) || /\bindexedDB\b/.test(s)).map(([f]) => f);
    t('9b) لا شاشة ولا مكوّن ولا تنقل ولا app.js يلمس التخزين', badUi.length === 0, badUi.join());
    const raw = /\b(USERS|SHOWROOMS|CARS|MEMBER_CARS|CAR_IMAGES|FAVORITES)\b/;
    const badRaw = services.concat(ui).filter(([f, s]) => raw.test(s)).map(([f]) => f);
    t('9c) لا خدمة ولا واجهة تقرأ/تكتب المصفوفات الخام (USERS/CARS/MEMBER_CARS/...) — كله عبر الـ Repositories', badRaw.length === 0, badRaw.join());
    const adapterOnly = []; const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => { const p = path.join(d, e.name); if (e.isDirectory()) { if (!['tests', 'node_modules'].includes(e.name)) walk(p); } else if (p.endsWith('.js') && /\blocalStorage\b/.test(strip(fs.readFileSync(p, 'utf8')))) adapterOnly.push(path.relative(ROOT, p)); });
    walk(ROOT);
    t('9d) الملف الوحيد الذي يذكر localStorage هو محوّل التخزين', adapterOnly.join() === 'storage/localStorageAdapter.js', adapterOnly.join());
    const badRepo = repos.filter(([f, s]) => /\bdocument\b|\balert\b|\bnotify\b|\bconfirm\b|\bprompt\b|\bgo\(|\brender\(|Service\b|AuthorizationService|SessionService/.test(s) && !/index\.js$/.test(f)).map(([f]) => f);
    t('9e) الـ Repositories بلا منطق واجهة ولا صلاحيات ولا اعتماد على الخدمات (وصول للبيانات فقط)', badRepo.length === 0, badRepo.join());
    const uiText = repos.filter(([f, s]) => /[\u0600-\u06FF]/.test(s.replace(/\/\/.*$/gm, ''))).map(([f]) => f);
    t('9f) لا نصوص واجهة عربية داخل الـ Repositories (الرسائل في الخدمات عبر repoErrorText)', uiText.length === 0, uiText.join());
    const idx = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
    const order = [...idx.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);
    const pos = f => order.indexOf(f);
    t('9g) ترتيب التحميل: المحوّل ← النماذج ← البيانات ← الـ Repositories ← الخدمات', pos('storage/localStorageAdapter.js') < pos('models/models.js') && pos('data/cars.js') < pos('repositories/baseRepository.js') && pos('repositories/index.js') < pos('services/dataService.js') && pos('repositories/baseRepository.js') < pos('repositories/memberCarsRepository.js'));
    t('9h) لا Firebase/Supabase/Backend/AdMob/دفع/طلبات شبكة في الشيفرة التنفيذية', !services.concat(repos, ui).some(([f, s]) => /firebase|supabase|admob|adsbygoogle|stripe|paypal|\bfetch\(|XMLHttpRequest|axios/i.test(s)) && !/firebase|supabase|adsbygoogle|googlesyndication/i.test(strip(idx)));
  }

  /* ============ 10) الاستبدال ممكن فعلًا: محوّل بديل، ومستودع بديل ============ */
  {
    // (أ) محوّل بديل في الذاكرة: لا شيء يصل إلى localStorage، والتطبيق يعمل
    const x = mk(null); let lsWrites = 0; const realSet = x.E.ctx.localStorage.setItem; x.E.ctx.localStorage.setItem = (...a) => { lsWrites++; return realSet(...a); };
    const mem = {}, A = x.R('AppStorage');
    A.get = (k, fb = null, v) => { if (!(k in mem)) return fb; const val = JSON.parse(JSON.stringify(mem[k])); return (typeof v === 'function' && !v(val)) ? fb : val; };
    A.set = (k, val) => { mem[k] = JSON.parse(JSON.stringify(val)); return { ok: true }; };
    A.remove = k => { delete mem[k]; return { ok: true }; };
    x.login('user'); x.R('handleFavoriteToggle(1)'); const pub = publishAsUser(x, 'SwapAdapter'); x.E.ctx.confirm = () => true; x.R(`deleteMemberCar(${pub.id})`);
    t('10) استبدال محوّل التخزين بآخر (في الذاكرة): التسجيل/المفضلة/النشر/الحذف تعمل، وlocalStorage لا يُكتب إطلاقًا', lsWrites === 0 && 'session' in mem && 'favorites' in mem && 'memberCars' in mem && mem.memberCarsDeleted.includes(pub.id) && x.R('isFavorite(1)'));
    // (ب) مستودع بديل: الخدمة تقرأ منه فقط (بدل المصفوفات الخام)
    const y = mk('user');
    const fake = { id: 5001, sourceType: 'member', ownerId: 7, brand: 'Fake', model: 'Repo', year: 2020, price: 1, status: 'active', mileage: 1, transmission: 'x', fuelType: 'y' };
    y.E.ctx.__fake = fake; y.R('MemberCarsRepository.getAll = () => [__fake]; MemberCarsRepository.getById = id => id === 5001 ? __fake : null;');
    t('10b) استبدال MemberCarsRepository: خدمة سيارات الأعضاء ودالة dataService تقرآن منه (لا من المصفوفة الخام)', y.R('getMemberCars().length') === 1 && y.R('getActiveMemberCars()[0].brand') === 'Fake' && y.R('getMemberCarById(5001).model') === 'Repo' && y.R('getCarById(5001).brand') === 'Fake');
    const z = mk('user'); z.E.ctx.__s = { id: 9, name: 'FakeShow', status: 'active' }; z.R('ShowroomsRepository.getAll = () => [__s]; ShowroomsRepository.getById = id => id === 9 ? __s : null;');
    t('10c) استبدال ShowroomsRepository: getShowrooms/getShowroomById تقرآن منه', z.R('getShowrooms().length') === 1 && z.R('getShowroomById(9).name') === 'FakeShow' && z.R('getShowroomById(1)') === undefined);
    /* الجزء 6.1: واجهات القراءة الإدارية صارت للمدير فقط (كانت تُعاد لأي مستدعٍ حتى الزائر، وهذا الاختبار كان يعتمد على ذلك). النية محفوظة: الخدمات تقرأ من المستودع المستبدَل؛ بجلسة مدير. */
    const w = mk('admin'); const aid = w.R('SessionService.getCurrentUser().id'); w.E.ctx.__aid = aid; w.E.ctx.__u = { id: aid, name: 'FromRepo', phone: '1', email: null, role: 'admin', status: 'active', createdAt: 'x' }; w.R('UsersRepository.getAll = () => [__u]; UsersRepository.getById = id => id === __aid ? __u : null;');
    t('10d) استبدال UsersRepository: adminGetAllUsers وUserService يقرآن منه ويُخرجان نسخة عامة', w.R('adminGetAllUsers().length') === 1 && w.R(`UserService.getPublicById(${aid}).name`) === 'FromRepo' && w.R('getDashboardStats().totalUsers') === 1);
    const v = mk('user'); v.R(`SessionRepository.get = () => null`);
    t('10e) استبدال SessionRepository: الجلسة تُقرأ منه فقط (زائر بعد استبداله رغم وجود جلسة مخزنة)', !v.R('SessionService.isLoggedIn()') && v.E.store['najaf.session'] !== undefined);
  }

  /* ============ 11) أخطاء التخزين في مسارات التطبيق الفعلية ============ */
  {
    const a = mk('dealer1'); a.E.ctx.localStorage.setItem = () => { throw quotaErr(); };
    a.R(`go('addMemberCar')`); a.setF({ mcBrand: 'Kia', mcModel: 'QuotaCar', mcYear: '2021', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07701234567', mcWhatsapp: '', mcDescription: '' }); a.E.els.mcTransmission = { value: 'أوتوماتيك' }; a.E.els.mcFuelType = { value: 'بنزين' };
    const r = a.R(`createDraftMemberCar({brand:'Kia',model:'Quota2',year:'2021',price:'9000000',phone:'07701234567'})`);
    t('11) امتلاء التخزين عند النشر: ok مع persisted=false، والسيارة في الذاكرة، بلا استثناء', r.ok === true && r.persisted === false && a.R(`getMemberCars().some(c => c.model === 'Quota2')`));
    a.R('handleAddMemberCarSubmit()');
    t('11b) الواجهة تعرض تنبيهًا عربيًا غير تقني (لا يضيع التغيير بصمت)', a.E.els.toast.textContent === 'تعذّر حفظ التغييرات على جهازك؛ قد تختفي عند إغلاق التطبيق.' && !/quota|error|exception/i.test(a.E.els.toast.textContent));
    const up = a.R(`updateShowroomCar(1, { price: '19,000,000' })`), fv = a.R('toggleFavorite(1)'), ch = a.R(`changeShowroomCarStatus(1,'sold')`);
    t('11c) التعديل/المفضلة/تغيير الحالة عند امتلاء التخزين: تنجح في الذاكرة مع persisted=false', up.ok && up.persisted === false && fv.ok && fv.persisted === false && ch.ok && ch.persisted === false && a.R('getCarById(1).price') === 19000000);
    a.R('handleFavoriteToggle(2)'); t('11d) زر المفضلة يُظهر نفس التنبيه', a.E.els.toast.textContent.startsWith('تعذّر حفظ التغييرات'));
    const ad = mk('admin'); ad.E.ctx.localStorage.setItem = () => { throw quotaErr(); }; const sus = ad.R('suspendShowroom(3)'), ap = ad.R('approveDealer(8)');
    t('11e) إجراءات الإدارة عند امتلاء التخزين: تنجح مع persisted=false', sus.ok && sus.persisted === false && ap.ok && ap.persisted === false);
    const reloaded = reload(a, 'dealer1');
    t('11f) بعد إعادة التحميل (لم يُحفظ شيء): يعود التطبيق للبيانات التجريبية بلا انهيار', reloaded.E.errors.length === 0 && reloaded.R('MemberCarsRepository.getAll().length') === 10 && reloaded.R('getCarById(1).price') !== 19000000);
    t('11g) تخزين محظور: التطبيق يعمل في الذاكرة (دخول ومفضلة) بلا أخطاء', (() => { const E = makeEnv(); E.ctx.localStorage.getItem = () => { throw new Error('x'); }; E.ctx.localStorage.setItem = () => { throw new Error('y'); }; E.run('hydrateRepositories()'); E.run(`go('login')`); E.els.loginIdentifier = { value: '07700000001', style: {} }; E.els.loginPassword = { value: 'user123', style: {} }; E.run('handleLoginSubmit()'); E.run('handleFavoriteToggle(1)'); return E.run('SessionService.isLoggedIn()') && E.run('isFavorite(1)') && E.errors.length === 0; })());
    const a2 = mk('dealer1'); a2.E.ctx.localStorage.setItem = () => { throw new Error('denied'); };
    const br = a2.R(`changeShowroomCarStatus(1,'sold')`);
    t('11h) تخزين محظور (غير الامتلاء): persisted=false أيضًا وبلا استثناء', br.ok && br.persisted === false);
  }

  /* ============ 12) بيانات تالفة لكل مفتاح تخزين: لا انهيار ولا فقدان للبيانات التجريبية ============ */
  {
    const keys = ['session', 'favorites', 'memberCars', 'memberCarsDeleted', 'showroomCars', 'carImages', 'registeredUsers', 'userOverrides', 'showrooms'];
    const variants = ['{bad json', '42', '"str"', 'null', '{"a":1}', '[1,null,"x"]', '[{}]', '[{"id":"x"}]'];
    let bad = [], total = 0;
    for (const k of keys) for (const v of variants) {
      total++; const x = mk(null, { ['najaf.' + k]: v });
      const counts = [x.R('UsersRepository.getAll().length'), x.R('getShowrooms().length'), x.R('getCars().length'), x.R('MemberCarsRepository.getAll().length'), x.R('CarImagesRepository.getAll().length')].join();
      x.R(`go('home')`); x.R(`go('cars')`); x.R(`go('memberCars')`); x.R(`go('showrooms')`);
      if (x.E.errors.length || counts !== '8,5,15,10,50' || x.E.screen().includes('حدث خطأ، حاول مرة أخرى')) bad.push(`${k}=${v} → ${counts}`);
    }
    t(`12) ${total} حالة (9 مفاتيح × 8 أشكال تالفة): لا انهيار وتبقى كل البيانات التجريبية (8 مستخدمين، 5 معارض، 15+10 سيارة، 50 صورة)`, bad.length === 0, bad.slice(0, 3).join(' | '));
  }

  {
    const x = mk(null, { 'najaf.memberCarsDeleted': JSON.stringify([101]), 'najaf.favorites': JSON.stringify([{ id: 1, userId: 7, carId: 1 }]) });
    const y = makeEnv(); const logged = []; y.ctx.console = { error: (...a) => logged.push(a.join(' ')), log() {}, warn() {} };
    y.store['najaf.memberCarsDeleted'] = JSON.stringify([101]); y.run('CarsRepository.hydrate = () => { throw new Error("broken"); }');
    let threw = false; try { y.run('hydrateRepositories()'); } catch (e) { threw = true; }
    t('12b) فشل استعادة مستودع واحد لا يُسقط البقية: تُسجَّل المشكلة في Console وتُطبَّق باقي المجموعات', !threw && logged.some(l => l.includes('[hydrate failed]') && l.includes('cars')) && x.R('getMemberCarById(101)') === null);
  }

  /* ============ 13) التوافق مع بيانات المراحل السابقة ============ */
  {
    const hashOld = mk(null).R(`hashPassword('old123')`);
    const store = {
      'najaf.registeredUsers': JSON.stringify([{ id: 20, name: 'مستخدم قديم', phone: '07700000020', email: null, role: 'user', passwordHash: hashOld }]),     // المرحلة 3: بلا status/createdAt
      'najaf.session': JSON.stringify({ userId: 20, createdAt: Date.now(), expiresAt: Date.now() + 1e9 }),
      'najaf.favorites': JSON.stringify([{ id: 1, userId: 20, carId: 1 }, { id: 2, userId: 20, carId: 101 }]),                                              // بلا createdAt
      'najaf.memberCars': JSON.stringify(mk('admin').R('JSON.parse(JSON.stringify(MemberCarsRepository.getAll()))').filter(c => c.id !== 105)),             // صيغة المرحلة 4-7 (بلا سجل محذوفات)
      'najaf.showroomCars': JSON.stringify(mk('admin').R('JSON.parse(JSON.stringify(CarsRepository.getAll()))').filter(c => c.id !== 15)),
      'najaf.unknownKey': '"keep-me"', 'other.app.key': 'keep-me-too',
    };
    const x = mk(null, store);
    t('13) بيانات قديمة: المستخدم بلا status يُستعاد (active) ويدخل بكلمة مروره، والجلسة القديمة صالحة', x.R('SessionService.getCurrentUser().name') === 'مستخدم قديم' && x.R('SessionService.getCurrentUser().status') === 'active' && (() => { const y = mk(null, store); y.R('handleLogout()'); y.R(`go('login')`); y.setF({ loginIdentifier: '07700000020', loginPassword: 'old123' }); y.R('handleLoginSubmit()'); return y.R('SessionService.isLoggedIn()'); })());
    t('13b) المفضلة القديمة (بلا createdAt) تعمل ومعزولة', x.R('getFavoriteCars().map(c=>c.id).sort((a,b)=>a-b).join()') === '1,101' && x.E.errors.length === 0);
    t('13c) سيارات أعضاء بصيغة قديمة: الغائبة (105) تُرحَّل كمحذوفة، وسيارات المعارض المحفوظة (15 غائبة) تُطبَّق', x.R('getMemberCarById(105)') === null && x.R('MemberCarsRepository.getAll().length') === 9 && x.R('getCarById(15)') === undefined && x.R('getCars().length') === 14);
    (() => { x.R(`go('home')`); x.R(`go('cars')`); x.R(`go('memberCars')`); x.R(`go('favorites')`); x.R('handleFavoriteToggle(2)'); })();
    const after = Object.keys(x.E.store);
    t('13d) لا يُمسح أي مفتاح تخزين: المجهولة وغير التطبيق باقية بعد الاستعادة والعمل', x.E.store['najaf.unknownKey'] === '"keep-me"' && x.E.store['other.app.key'] === 'keep-me-too' && Object.keys(store).every(k => after.includes(k)));
    const back = reload(x, null);
    t('13e) بعد إعادة التحميل بصيغ الحديثة والقديمة معًا: كل شيء ثابت (9 سيارات أعضاء، 14 سيارة معرض، المفضلة)', back.R('MemberCarsRepository.getAll().length') === 9 && back.R('getCars().length') === 14 && back.R('isFavorite(2)') && back.R('getFavoriteCars().length') === 3 && back.R('SessionService.isLoggedIn()') && back.E.store['najaf.unknownKey'] === '"keep-me"');
    t('13f) حسابات وبيانات المراحل 3–8 التجريبية سليمة (8 مستخدمين، 5 معارض، 15/10 سيارات، 50 صورة)', mk(null).R('[UsersRepository.getAll().length, getShowrooms().length, getCars().length, MemberCarsRepository.getAll().length, CarImagesRepository.getAll().length].join()') === '8,5,15,10,50');
    const noKeys = mk(null); t('13g) تثبيت جديد بلا أي مفاتيح: يعمل، ولا يكتب مفاتيح بيانات ما لم يحدث تغيير (سجل المحذوفات الفارغ فقط)', noKeys.R('getCars().length') === 15 && Object.keys(noKeys.E.store).every(k => ['najaf.memberCarsDeleted', 'najaf.schemaVersion' /* المرحلة 9 Fix: رقم إصدار المخطط */].includes(k)), Object.keys(noKeys.E.store).join());
  }

  /* ============ 14) صلاحيات: مراجعة سلبية شاملة عبر الـ Repositories ============ */
  {
    const g = mk(null); const calls = ['createShowroomCar({brand:"a",model:"b",year:"2020",price:"1"})', 'updateShowroomCar(1,{price:"1"})', 'deleteShowroomCar(1)', 'changeShowroomCarStatus(1,"sold")', 'createDraftMemberCar({brand:"a",model:"b",year:"2020",price:"1",phone:"07700000000"})', 'updateMemberCar(101,{price:"1"})', 'deleteMemberCar(101)', 'changeMemberCarStatus(101,"sold")', 'approveMemberCar(103)', 'suspendShowroom(1)', 'activateShowroom(1)', 'approveDealer(8)', 'rejectDealer(8)', 'setShowroomCarStatus(1,"sold")', 'toggleFavorite(1)', 'removeCarImage(1)', 'setMainImage(1)'];
    let denied = true, leaked = []; const snapshot = g.R('JSON.stringify([getCars(), MemberCarsRepository.getAll(), getShowrooms(), UsersRepository.getAll()])');
    for (const c of calls) { const r = await g.R(c); if (r.ok) { denied = false; leaked.push(c); } }
    t('14) الزائر: كل عمليات الكتابة (' + calls.length + ') مرفوضة والبيانات لم تتغير', denied && g.R('JSON.stringify([getCars(), MemberCarsRepository.getAll(), getShowrooms(), UsersRepository.getAll()])') === snapshot, leaked.join());
    const u = mk('user');
    t('14b) المستخدم العادي: لا إدارة ولا تاجر ولا عضو آخر ولا معارض', ['approveMemberCar(103)', 'suspendShowroom(1)', 'approveDealer(8)', 'setShowroomCarStatus(1,"sold")', 'updateShowroomCar(1,{price:"1"})', 'updateMemberCar(102,{price:"1"})', 'deleteMemberCar(102)'].every(c => !u.R(c).ok));
    const d1 = mk('dealer1');
    t('14c) التاجر: لا مدير ولا معرض آخر ولا سيارة عضو آخر، ويدير معرضه', ['approveMemberCar(103)', 'suspendShowroom(2)', 'approveDealer(8)', 'updateShowroomCar(4,{price:"1"})', 'updateMemberCar(101,{price:"1"})'].every(c => !d1.R(c).ok) && d1.R(`updateShowroomCar(1,{price:'20,000,000'}).ok`));
    const d2 = mk('dealer2'); t('14d) التاجر 2 لا يمس سيارات التاجر 1 والعكس', !d2.R(`updateShowroomCar(1,{price:"1"})`).ok && d2.R(`updateShowroomCar(4,{price:'8,100,000'}).ok`) && d2.R('getCarById(1).price') !== 1);
    const a = mk('admin');
    t('14e) المدير يعمل طبيعيًا: موافقة إعلان، إيقاف/تفعيل معرض، حالة سيارة معرض، موافقة تاجر، تعديل أي سيارة', a.R('approveMemberCar(103).ok') && a.R('suspendShowroom(4).ok') && a.R('activateShowroom(4).ok') && a.R(`setShowroomCarStatus(10,'sold').ok`) && a.R('approveDealer(8).ok') && a.R(`updateMemberCar(101,{price:'2,000,000'}).ok`) && a.R('getDashboardStats().totalUsers') === 8);
    t('14f) مسارات الإدارة/التاجر: زائر → دخول، مستخدم → غير مصرّح، مدير يدخل', (() => { const gg = mk(null); gg.R(`go('adminHome')`); const a1 = gg.R('currentRoute'); u.R(`go('adminHome')`); const a2 = u.R('currentRoute'); a.R(`go('adminHome')`); return a1 === 'login' && a2 === 'accessDenied' && a.R('currentRoute') === 'adminHome'; })());
  }

  /* ============ 15) الانحدار: المراحل السابقة بأرقامها ============ */
  {
    if (process.env.PHASE9_SKIP_REGRESSION) { console.log('(تجارب الطفرات: تخطّي تشغيل المراحل السابقة)'); } else
    {
    const expected = [['phase3', 63], ['phase4', 63], ['phase5', 44], ['phase6', 41], ['phase7', 73], ['phase8', 127], ['phase8_persistence', 26]];
    for (const [name, n] of expected) {
      let out = '', ok = true; try { out = execSync(`node ${path.join(__dirname, name + '.test.js')}`, { stdio: 'pipe' }).toString(); } catch (e) { ok = false; out = String((e.stdout || '') + (e.stderr || '')); }
      const m = out.match(/النتيجة: (\d+) نجح، (\d+) فشل/);
      t(`15) الانحدار ${name}: ${n}/${n} بلا أي إخفاق`, ok && m && Number(m[1]) === n && Number(m[2]) === 0, m ? m[0] : out.slice(-120));
    }
    }
  }

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('خطأ غير متوقع في الاختبار:', e); process.exit(2); });

const fs = require('fs'), vm = require('vm'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const order = [...fs.readFileSync(ROOT + '/index.html', 'utf8').matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);

// (6.2-C ج1) بيانات الـDemo الموسّعة محاطة في data/cars.js وdata/memberCars.js بعلامتي BEGIN/END (6.2C).
// الافتراضي هنا «البذرة الأساسية» (15 سيارة معرض + 10 سيارات أعضاء) لأن الاختبارات القديمة تثبّت أعدادها ومعرّفاتها حرفيًا،
// فتبقى بلا أي تعديل في تأكيداتها. makeEnv(storage, { fullSeed: true }) يحمّل البيانات الموسّعة كما يراها التطبيق فعليًا.
const SEED_BLOCK = /\/\*6\.2C-BEGIN\*\/[\s\S]*?\/\*6\.2C-END\*\//g;
const SEED_BLOCK_P3 = /\/\*6\.2C3-BEGIN\*\/[\s\S]*?\/\*6\.2C3-END\*\//g;   // (6.2-C ج3) كتلة التوسعة الثانية: نماذج أوسع + مركبات أقدم
function makeEnv(sharedStorage, opts) {
  const seedOpt = (opts && opts.fullSeed !== undefined) ? opts.fullSeed : makeEnv.fullSeedDefault;
  // مستويات البذرة: false = الأساسية (15+10) | true = + توسعة الجزء 1 (47+31) | 'p3' = + توسعة الجزء 3 (الكاملة الحالية)
  const fullSeed = !!seedOpt, withP3 = seedOpt === 'p3';
  const store = sharedStorage || {};
  const els = {};
  const errors = [];
  const getEl = id => els[id] || (els[id] = { id, value: '', innerHTML: '', textContent: '', style: {}, remove(){} });
  const radios = { accountType: 'user' };
  let _timers = {}, _timerSeq = 1;
  const winHandlers = {};
  const sandbox = {
    console, Math, Date, JSON, Object, Array, String, Number, RegExp, Set, Map, parseInt,
    localStorage: { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
    document: { getElementById: getEl, querySelector: sel => sel.includes('accountType') ? { value: radios.accountType } : null },
    window: { scrollTo() {}, location: { href: 'http://test.local/' }, addEventListener: (t, f) => { winHandlers[t] = f; } },
    setTimeout: () => 0, clearTimeout: () => {},
    setInterval: (fn) => { const id = _timerSeq++; _timers[id] = fn; return id; },
    clearInterval: (id) => { delete _timers[id]; },
    alert: () => {}, confirm: () => true, prompt: () => null,
    navigator: {}, location: { href: 'http://test.local/' },
  };
  const ctx = vm.createContext(sandbox);
  order.forEach(f => {
    try { let src = fs.readFileSync(path.join(ROOT, f), 'utf8');
      if (f === 'data/cars.js' || f === 'data/memberCars.js') { if (!fullSeed) src = src.replace(SEED_BLOCK, ''); if (!withP3) src = src.replace(SEED_BLOCK_P3, ''); }
      vm.runInContext(src, ctx, { filename: f }); }
    catch (e) { errors.push(f + ': ' + e.message); }
  });
  const run = code => vm.runInContext(code, ctx);
  /** يحاكي مرور "ثانية" واحدة (أو times ثانية) لكل عدّادات setInterval الحالية — تستدعي كل دالة مسجّلة مرة لكل tick. */
  const tick = (times = 1) => { for (let i = 0; i < times; i++) Object.keys(_timers).forEach(id => { if (_timers[id]) _timers[id](); }); };
  return { ctx, run, els, store, radios, errors, tick, winHandlers, screen: () => getEl('screen').innerHTML };
}
makeEnv.fullSeedDefault = false;                // ملف الاختبار الذي يريد البذرة الكاملة لكل بيئاته يضبطه true في أوله (6.2-C ج2)
module.exports = { makeEnv, order };

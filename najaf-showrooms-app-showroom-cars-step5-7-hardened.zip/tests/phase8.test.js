const { makeEnv } = require('./harness');
const { execSync } = require('child_process');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };

const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer5: ['07715558899', 'dealer123'], pending: ['07733445566', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role) {
  const E = makeEnv(); const R = c => E.run(c);
  const setF = (o) => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = (r) => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
let _n = 0;
const mkFile = (w, h) => ({ name: 'p' + (++_n) + '.jpg', type: 'image/jpeg', size: w * h * 3, width: w, height: h });
const mkCodec = () => ({ decode: async f => ({ width: f.width, height: f.height, close() {} }), encode: async (d, w, h, m, q) => ({ type: m, size: Math.round(w * h * q * 0.2), compressed: true }) });
const ids = list => list.map(c => c.id).sort((a, b) => a - b).join(',');
const BAD = /undefined|\bnull\b|NaN|\[object|TypeError|ReferenceError/;

(async () => {
  /* ================= 1/20) لا undefined/null/NaN ولا شاشة خطأ: كل الشاشات × كل الأدوار ================= */
  {
    const routes = ['home', 'showrooms', 'cars', 'map', 'favorites', 'login', 'register', 'account', 'memberCars', 'search', 'accessDenied', 'dealerHome', 'adminHome', 'adminMemberCars', 'adminShowrooms', 'adminShowroomCars', 'adminUsers', 'adminDealerRequests', 'myMemberCars', 'addMemberCar', 'myShowroomCars', 'addShowroomCar'];
    const withParam = [['showroomDetails', [1, 5, 999]], ['carDetails', [1, 15, 999]], ['memberCarDetails', [101, 103, 105, 109, 110, 999]], ['editMemberCar', [101, 102, 999]], ['editShowroomCar', [1, 4, 999]], ['adminMemberCarDetails', [101, 109, 999]], ['adminUserDetails', [1, 7, 8, 999]], ['search', ['تويوتا', 'zzzz', '']]];
    const leaks = []; let screens = 0, loadErrs = 0;
    for (const role of [null, 'user', 'dealer1', 'pending', 'admin']) {
      const { E, R } = mk(role);
      const visit = (r, p) => { R(`go('${r}', ${JSON.stringify(p)})`); screens++; const h = E.screen(); if (BAD.test(h) || h.includes('حدث خطأ، حاول مرة أخرى')) leaks.push(`${role}:${r}(${p})`); };
      routes.forEach(r => visit(r)); withParam.forEach(([r, ps]) => ps.forEach(p => visit(r, p))); loadErrs += E.errors.length;
    }
    t('1) كل الشاشات لكل الأدوار (' + screens + ' عرضًا) بلا undefined/null/NaN ولا شاشة خطأ', leaks.length === 0 && loadErrs === 0, leaks.slice(0, 5).join(' | '));
  }
  {
    // سجلات ناقصة عمدًا: لا يجوز أن يرى المستخدم undefined/NaN أو ينهار العرض
    const leaks = [];
    for (const role of [null, 'user', 'dealer1', 'admin']) {
      const { E, R } = mk(role);
      R(`CARS.push(CarModel({ id: 901, sourceType:'showroom', showroomId: 1, brand:'Ghost', model:'Bare', price: undefined, status:'available' }))`);
      R(`CARS.push(CarModel({ id: 902, sourceType:'showroom', showroomId: 999, brand:'Orphan', model:'NoShowroom', year:2020, price:1000, status:'available' }))`);
      R(`MEMBER_CARS.push(CarModel({ id: 903, sourceType:'member', ownerId: 7, brand:'Ghost', model:'Member', status:'active', price:'abc' }))`);
      R(`MEMBER_CARS.push(CarModel({ id: 904, sourceType:'member', ownerId: 12345, brand:'Ghost', model:'NoOwner', year:2021, price:5000, status:'pending' }))`);
      R(`SHOWROOMS.push(ShowroomModel({ id: 77, name:'Bare Showroom', status:'active', ownerId: 1 }))`);
      const visit = (r, p) => { R(`go('${r}', ${JSON.stringify(p)})`); const h = E.screen(); if (BAD.test(h) || h.includes('حدث خطأ، حاول مرة أخرى')) leaks.push(`${role}:${r}(${p})`); };
      ['home', 'showrooms', 'cars', 'map', 'memberCars', 'myMemberCars', 'myShowroomCars', 'adminMemberCars', 'adminShowrooms', 'adminShowroomCars'].forEach(r => visit(r));
      [901, 902].forEach(i => visit('carDetails', i)); [903, 904].forEach(i => { visit('memberCarDetails', i); visit('adminMemberCarDetails', i); visit('editMemberCar', i); });
      visit('editShowroomCar', 901); visit('showroomDetails', 77); visit('search', 'ghost');
    }
    t('20) سجلات ناقصة (بلا سنة/مسافة/عنوان/مالك...) لا تُظهر undefined/null/NaN ولا تنهار الشاشات', leaks.length === 0, leaks.slice(0, 6).join(' | '));
  }

  /* ================= 2) الرئيسية ================= */
  {
    const { E, R } = mk(null);
    R(`go('home')`); const h = E.screen();
    t('2) الرئيسية: وصول سريع للسيارات/المعارض/الخريطة/المفضلة/حسابي/سيارات الأعضاء', ["go('cars')", "go('showrooms')", "go('map')", "go('favorites')", "go('memberCars')", "go('login')"].every(x => h.includes(`onclick="${x}"`)));
    t('2b) مربع البحث في الرئيسية فعّال (Enter وزر «بحث»)', h.includes("handleHomeSearch(this.value)") && h.includes('class="search-go"'));
    R(`handleHomeSearch('  تويوتا كورولا ')`);
    t('2c) البحث من الرئيسية ينقل لنتائج البحث بنفس النص', R('currentRoute') === 'search' && E.screen().includes('Toyota') && E.screen().includes('Corolla'));
    const u = mk('user'); u.R(`go('home')`);
    t('2d) زر «حسابي» في الرئيسية حسب الدور (مستخدم: account / تاجر: إدارة معرضي / مدير: لوحة الإدارة)', u.E.screen().includes(`go('account')`) && (() => { const d = mk('dealer1'); d.R(`go('home')`); const a = mk('admin'); a.R(`go('home')`); return d.E.screen().includes(`go('dealerHome')`) && a.E.screen().includes(`go('adminHome')`); })());
    const { E: E2, R: R2 } = mk(null);
    R2(`CARS.push(CarModel({ id: 950, sourceType:'showroom', showroomId: 1, brand:'Newest', model:'One', year:2024, price:1, status:'available', createdAt:'2030-01-01T00:00:00' }))`);
    R2(`go('home')`);
    t('2e) «أحدث السيارات» مرتبة بالأحدث فعلًا', E2.screen().indexOf('Newest One') > -1 && E2.screen().indexOf('Newest One') < E2.screen().indexOf('Toyota Corolla'));
  }

  /* ================= 3) البحث ================= */
  {
    const { E, R } = mk(null);
    const S = (q, src) => ids(R(`searchCars(${JSON.stringify(q)}, ${JSON.stringify(src || 'showroom')})`));
    t('3) «تويوتا كورولا» بالعربية تجد Toyota Corolla (معرض وعضو)', S('تويوتا كورولا', 'all') === '1,101' && S('تويوتا كورولا') === '1');
    t('3b) «كورولا 2022» تجد سيارة 2022 فقط', S('كورولا 2022', 'all') === '1');
    t('3c) «سيارات معرض الفرات» تجد سيارات معرض الفرات فقط، والمعرض نفسه', S('سيارات معرض الفرات') === '4,5,6' && ids(R(`searchShowrooms('سيارات معرض الفرات')`)) === '2');
    t('3d) الإنجليزية ما زالت تعمل (Toyota / toyota corolla)', S('Toyota') === '1' /* سياسة الظهور العام: كانت 1,7 بعد C7، و1,7,13 */ && S('toyota corolla') === '1' && S('Kia Cerato', 'all') === '3,106' /* كانت 'Kia Rio' = 9 من المعرض 3 المخفي؛ Cerato: سيارة المعرض 3 الظاهرة + إعلان العضو 106 */);
    t('3e) الأرقام الهندية والهمزات: «كورولا ٢٠٢٢» و«الأمير»', S('كورولا ٢٠٢٢', 'all') === '1' && ids(R(`searchShowrooms('الأمير')`)) === '4' && ids(R(`searchCars('الأمير','member')`)) === '104,107');
    t('3f) كتابة جزئية للاسم العربي («تويو») وكلمة «معرض» وحدها', S('تويو') === '1' /* سياسة الظهور العام: كانت 1,7 بعد C7 */ && R(`searchShowrooms('معرض').length`) === 3 /* سياسة الظهور العام: كانت 4 بعد C7، و5 */);
    t('3g) نتيجة فارغة عند عدم التطابق', S('xyzxyz', 'all') === '' && S('تويوتا 1900', 'all') === '');
    R(`go('cars')`); R(`onCarsSearch('xyzxyz')`);
    const empty = E.els.carsList.innerHTML;
    t('3h) لا نتائج: رسالة واضحة + زر «مسح البحث»', empty.includes('لم نعثر على سيارات مطابقة لبحثك') && empty.includes('مسح البحث') && empty.includes('clearCarsSearch()'));
    R('clearCarsSearch()');
    t('3i) «مسح البحث» يعيد القائمة كاملة (9 بعد سياسة الظهور العام؛ كانت 12 بعد C7، و15)', (E.screen().match(/class="card car-card"/g) || []).length === 9);
    R(`go('search','kkkkk')`);
    t('3j) شاشة نتائج البحث الموحّد: رسالة + زر مسح عند عدم وجود نتائج', E.screen().includes('لم نعثر على سيارات مطابقة لبحثك') && E.screen().includes('clearSearchScreen()'));
    R('clearSearchScreen()'); t('3k) مسح بحث الشاشة الموحدة يعرض إرشاد البحث', E.screen().includes('ابحث عن سيارة أو معرض'));
    R(`go('search','الفرات')`);
    t('3l) الموحّد يعرض المعارض والسيارات معًا', E.screen().includes('المعارض (1)') && E.screen().includes('السيارات (3)'));
    R(`go('showrooms')`); R(`onShowroomsSearch('لا_يوجد')`);
    t('3m) بحث المعارض بلا نتيجة: رسالة + مسح البحث', E.els.showroomsList.innerHTML.includes('لم نعثر على معارض مطابقة') && E.els.showroomsList.innerHTML.includes('clearShowroomsSearch()'));
    t('3n) توقيع searchCars(query, sourceType) سليم لكل القيم', S('Toyota', 'member') === '101' && S('Toyota', 'all').split(',').length === 2 /* سياسة الظهور العام: كانت 3 بعد C7، و4 */);
  }

  /* ================= 4) الفلاتر ================= */
  {
    const { E, R, setF } = mk(null);
    const setFilters = (o) => { E.els.carsFilterBrand = { value: o.brand || '', style: {} }; E.els.carsFilterYear = { value: o.year || '', style: {} }; E.els.carsFilterMaxPrice = { value: o.maxPrice || '', style: {} }; R('onCarsFilter()'); };
    R(`go('cars')`); const before = E.screen();
    t('4) لا أزرار ميتة «قريبًا» في السيارات/المعارض، وفلاتر الماركة والسنة والسعر موجودة', !before.includes('قريبًا') && before.includes('id="carsFilterBrand"') && before.includes('id="carsFilterYear"') && before.includes('id="carsFilterMaxPrice"') && (R(`go('showrooms')`), !E.screen().includes('قريبًا')));
    R(`go('cars')`); setFilters({ brand: 'Toyota' });
    t('4b) الفلتر يعمل ويُظهر أنه فعّال مع «مسح الفلاتر»', (E.els.carsList.innerHTML.match(/class="card car-card"/g) || []).length === 1 /* سياسة الظهور العام: كانت 2 بعد C7، و3 */ && E.els.carsFilterBar.innerHTML.includes('فلاتر فعالة (1)') && E.els.carsFilterBar.innerHTML.includes('مسح الفلاتر') && E.els.carsFilterBar.innerHTML.includes('value="Toyota" selected'));
    setFilters({ brand: 'Toyota', year: '2022', maxPrice: '10000000' });
    t('4c) فلاتر بلا نتائج: رسالة واضحة + «مسح الفلاتر»، والعدّ 3', E.els.carsList.innerHTML.includes('لم نعثر على سيارات مطابقة لبحثك') && E.els.carsList.innerHTML.includes('clearCarsFilters()') && E.els.carsFilterBar.innerHTML.includes('فلاتر فعالة (3)'));
    R('clearCarsFilters()');
    t('4d) مسح الفلاتر يعيد كل السيارات ويخفي شريط الفلاتر الفعالة', (E.screen().match(/class="card car-card"/g) || []).length === 9 /* سياسة الظهور العام: كانت 12 بعد C7، و15 */ && !E.screen().includes('فلاتر فعالة'));
    // سيارات الأعضاء: نفس المكوّن
    R(`go('memberCars')`);
    E.els.memberFilterBrand = { value: 'Kia', style: {} }; E.els.memberFilterYear = { value: '', style: {} }; E.els.memberFilterMaxPrice = { value: '', style: {} }; R('onMemberCarsFilter()');
    t('4e) فلاتر سيارات الأعضاء تعمل وتُظهر الفلتر الفعّال', E.els.memberCarsList.innerHTML.includes('Kia') && !E.els.memberCarsList.innerHTML.includes('Toyota') && E.els.memberFilterBar.innerHTML.includes('فلاتر فعالة (1)'));
    E.els.memberFilterYear = { value: '2010', style: {} }; R('onMemberCarsFilter()');
    t('4f) سيارات الأعضاء بلا نتائج: رسالة + مسح الفلاتر', E.els.memberCarsList.innerHTML.includes('لم نعثر على سيارات مطابقة لبحثك') && E.els.memberCarsList.innerHTML.includes('clearMemberCarsFilters()'));
    R('clearMemberCarsFilters()'); t('4g) مسح فلاتر الأعضاء', !E.screen().includes('فلاتر فعالة') && E.screen().includes('Toyota'));
    t('4h) فلاتر الخدمة الأصلية لم تتغيّر (filterCars/filterMemberCars)', R(`filterCars({brand:'Kia'}).length`) === 2 /* سياسة الظهور العام: كانت 3 بعد C7، و4 */ && R(`filterMemberCars({brand:'Kia'}).length`) >= 1);
  }

  /* ================= 5-8) بطاقات، تفاصيل، تواصل، موقع ================= */
  {
    const { E, R } = mk(null);
    R(`go('cars')`); const card = E.screen();
    t('5) بطاقة السيارة: الصورة (أو البديل 🚘) والماركة والموديل والسنة والسعر والحالة، وتفتح التفاصيل', card.includes('🚘') && card.includes('Toyota Corolla') && card.includes('2022') && card.includes('د.ع') && card.includes('متاحة للبيع') && card.includes(`go('carDetails',1)`));
    R(`go('carDetails',1)`); const d = E.screen();
    t('6) تفاصيل السيارة: المواصفات الثمانية + معلومات المعرض + الوصف', ['السنة', 'المسافة', 'ناقل الحركة', 'الوقود', 'اللون', 'الحالة'].every(x => d.includes(x)) && d.includes('معرض النجف للسيارات') && d.includes('شارع الكوفة') && d.includes('9 صباحًا') && d.includes('صيانة دورية'));
    t('7) اتصال وواتساب حقيقيان (tel: و wa.me بصيغة دولية) بلا أزرار ميتة', d.includes('href="tel:07701234567"') && d.includes('href="https://wa.me/9647701234567"') && !/<button class="action-btn (call|whatsapp)">/.test(d));
    t('8) «الموقع على الخريطة» برابط إحداثيات حقيقية بلا Maps API', d.includes('href="https://www.google.com/maps?q=31.9986,44.3134"') && !d.includes('maps.googleapis'));
    R(`go('memberCarDetails',101)`); const m = E.screen();
    t('6b) تفاصيل سيارة عضو: الصاحب وتاريخ النشر والمواصفات والموقع', m.includes('مستخدم تجريبي') && m.includes('2026-06-01') && m.includes('حي النصر') && m.includes('من عضو'));
    t('7b) تواصل العضو: رقم 07700000001 يتحول لـ wa.me/9647700000001 ويظهر الموقع', m.includes('href="tel:07700000001"') && m.includes('href="https://wa.me/9647700000001"') && m.includes('maps?q=31.9901,44.3202'));
    // بيانات ناقصة: لا أزرار بروابط فارغة ولا أرقام وهمية
    R(`MEMBER_CARS.push(CarModel({ id: 960, sourceType:'member', ownerId: 7, brand:'No', model:'Contact', year:2020, price:1000, status:'active' }))`);
    R(`MEMBER_CARS.push(CarModel({ id: 961, sourceType:'member', ownerId: 7, brand:'Only', model:'Phone', year:2020, price:1000, status:'active', phone:'07701112223' }))`);
    R(`go('memberCarDetails',960)`); const nc = E.screen();
    t('7c) بلا هاتف/واتساب/إحداثيات: لا يظهر أي زر تواصل ولا رابط فارغ', !nc.includes('href="tel:') && !nc.includes('wa.me') && !nc.includes('google.com/maps') && !nc.includes('href=""') && !nc.includes('📞 اتصال'));
    R(`go('memberCarDetails',961)`); const op = E.screen();
    t('7d) هاتف فقط: زر «اتصال» وحده (لا واتساب ولا موقع)', op.includes('href="tel:07701112223"') && !op.includes('wa.me') && !op.includes('الموقع على الخريطة'));
    t('7e) مساعدات الروابط: تُرجع فارغًا للمدخلات غير الصالحة', telLinkOk());
    function telLinkOk() { return R(`telLink('')`) === '' && R(`telLink(null)`) === '' && R(`telLink('12')`) === '' && R(`waLink('')`) === '' && R(`waLink(undefined)`) === '' && R(`waLink('0770')`) === '' && R(`mapLink(null,null)`) === '' && R(`mapLink('','')`) === '' && R(`mapLink('x',1)`) === '' && R(`waLink('07701234567')`) === 'https://wa.me/9647701234567' && R(`waLink('+964 770 123 4567')`) === 'https://wa.me/9647701234567' && R(`waLink('9647701234567')`) === 'https://wa.me/9647701234567'; }
  }

  /* ================= 17) تفاصيل المعرض ================= */
  {
    const { E, R } = mk(null);
    R(`go('showroomDetails',1)`); const s = E.screen();
    t('17) تفاصيل المعرض: الاسم والوصف والعنوان والدوام والهاتف والخدمات وأزرار اتصال/واتساب/الموقع والسيارات', s.includes('معرض النجف للسيارات') && s.includes('معرض متخصص بالسيارات') && s.includes('شارع الكوفة') && s.includes('9 صباحًا - 9 مساءً') && s.includes('07701234567') && s.includes('فحص فني') && s.includes('تسهيلات دفع') && s.includes('href="tel:') && s.includes('wa.me/9647701234567') && s.includes('google.com/maps?q=') && s.includes('سيارات المعرض (3)') && !/<button class="action-btn (call|whatsapp)">/.test(s));
    R(`SHOWROOMS.push(ShowroomModel({ id: 77, name:'Bare Showroom', status:'active', ownerId: 1 }))`);
    R(`go('showroomDetails',77)`); const b = E.screen();
    t('17b) معرض بلا هاتف/واتساب/موقع/سيارات: لا أزرار فارغة، وحالة فارغة واضحة للسيارات', !b.includes('href="tel:') && !b.includes('wa.me') && !b.includes('google.com/maps') && b.includes('لا توجد سيارات في هذا المعرض حاليًا') && !BAD.test(b));
    R(`go('map')`); const mp = E.screen();
    t('8b) شاشة الخريطة: قائمة بمواقع المعارض بروابط خرائط عادية (بلا API) وصياغة واضحة لمن لا موقع له', mp.includes('google.com/maps?q=31.9986,44.3134') && mp.includes('الموقع غير متوفر لهذا المعرض') && !mp.includes('ستظهر هنا خريطة'));
  }

  /* ================= 9) المفضلة ================= */
  {
    const { E, R } = mk(null);
    R(`go('favorites')`); t('9a) الزائر: دعوة لتسجيل الدخول', E.screen().includes('سجّل الدخول لحفظ سياراتك المفضلة'));
    const u = mk('user'); const { E: EU, R: RU } = u;
    RU(`go('favorites')`); const e = EU.screen();
    t('9b) فارغة: «لا توجد سيارات في المفضلة حاليًا» + شرح طريقة الإضافة + زر تصفح', e.includes('لا توجد سيارات في المفضلة حاليًا') && e.includes('اضغط على أيقونة 🤍') && e.includes(`go('cars')`));
    RU(`go('carDetails',2)`); RU(`handleFavoriteToggle(2)`); RU(`handleFavoriteToggle(104)`);
    RU(`go('favorites')`);
    t('9c) إضافة سيارتين (معرض وعضو) تظهران في المفضلة مع العدد، وتفتحان التفاصيل', EU.screen().includes('2 سيارة محفوظة') && EU.screen().includes(`go('carDetails',2)`) && EU.screen().includes(`go('memberCarDetails',104)`));
    RU(`handleFavoriteToggle(2)`); RU(`go('favorites')`);
    t('9d) إزالة سيارة من المفضلة', !EU.screen().includes(`go('carDetails',2)`) && EU.screen().includes(`go('memberCarDetails',104)`));
    // سيارة عضو أُوقفت بعد إضافتها للمفضلة: لا تظهر (فتحها سيُرفض)، وتعود للظهور عند إعادة تفعيلها
    const X = mk('user'); X.R(`handleFavoriteToggle(104)`);
    X.R(`handleLogout()`); X.login('admin'); X.R(`suspendMemberCarAdmin(104,'مخالفة')`);
    X.R(`handleLogout()`); X.login('user'); X.R(`go('favorites')`);
    const hidden = !X.E.screen().includes(`go('memberCarDetails',104)`) && X.R(`isFavorite(104)`) === true;
    X.R(`handleLogout()`); X.login('admin'); X.R(`approveMemberCar(104)`);
    X.R(`handleLogout()`); X.login('user'); X.R(`go('favorites')`);
    t('9e) سيارة عضو أُوقفت بعد إضافتها للمفضلة لا تظهر (بدل رابط يُرفض)، وتعود عند إعادة تفعيلها', hidden && X.E.screen().includes(`go('memberCarDetails',104)`));
    const Y = mk('user'); Y.R(`go('account')`); const acc = Y.E.screen();
    t('10) حسابي: بيانات الحساب + سياراتي + إضافة سيارة + المفضلة + تسجيل الخروج', acc.includes('مستخدم تجريبي') && acc.includes('07700000001') && acc.includes(`go('myMemberCars')`) && acc.includes(`go('addMemberCar')`) && acc.includes(`go('favorites')`) && acc.includes('handleLogout()'));
  }

  /* ================= 11-13) سياراتي وإضافة/تعديل سيارة المستخدم ================= */
  {
    const { E, R, setF } = mk('user');
    R(`go('myMemberCars')`); const my = E.screen();
    t('11) سياراتي: سيارات المستخدم فقط مع الماركة والموديل والسنة والسعر والحالة وأزرار تعديل/حذف', my.includes('Toyota Corolla') && my.includes('2019') && my.includes('نشط') && my.includes('handleDeleteMemberCar(101)') && my.includes(`go('editMemberCar', 101)`) && !my.includes('Hyundai Accent') && !my.includes('Hyundai Elantra'));
    const empty = mk('admin'); empty.R(`go('myMemberCars')`);
    t('18) سياراتي بلا سيارات: حالة فارغة + زر إضافة', empty.E.screen().includes('لا توجد سيارات مضافة') && empty.E.screen().includes(`go('addMemberCar')`));

    // تعديل: كل الحقول + إدارة الصور
    R(`go('editMemberCar',101)`); const ed = E.screen();
    t('13) تعديل سيارة المستخدم: الماركة/الموديل/السنة/السعر/القير/الوقود/... + منتقي الصور (حتى 4)', ['mcBrand', 'mcModel', 'mcYear', 'mcPrice', 'mcMileage', 'mcTransmission', 'mcFuelType', 'mcColor', 'mcLocation', 'mcPhone', 'mcWhatsapp', 'mcDescription'].every(x => ed.includes(`id="${x}"`)) && ed.includes('الصور 2 / 4') && R('getMaxImagesForCar(getCarById(101))') === 4);
    setF({ mcBrand: 'Toyota', mcModel: 'Corolla', mcYear: 'abc', mcPrice: '15800000', mcMileage: '90000', mcColor: 'أبيض', mcLocation: 'حي النصر، النجف', mcPhone: '07700000001', mcWhatsapp: '07700000001', mcDescription: 'x' });
    E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
    R(`handleEditMemberCarSubmit(101)`);
    t('13b) قيمة غير صالحة تُرفض برسالة عربية ولا تُخزَّن NaN', E.els.editMemberCarError.textContent === 'سنة الصنع غير صحيحة.' && R(`getMemberCarById(101).year`) === 2019);
    setF({ mcYear: '2020', mcModel: 'Corolla Cross' }); R(`handleEditMemberCarSubmit(101)`);
    t('13c) التعديل الصالح (موديل/سنة) يُحفظ ويعيد لتفاصيل الإعلان', R(`getMemberCarById(101).year`) === 2020 && R(`getMemberCarById(101).model`) === 'Corolla Cross' && R('currentRoute') === 'memberCarDetails');
    R(`updateMemberCar(101,{model:'Corolla',year:'2019'})`);

    // حذف مع تأكيد
    const msgs = []; E.ctx.confirm = (m) => { msgs.push(m); return false; };
    R(`go('myMemberCars')`); R(`handleDeleteMemberCar(101)`);
    t('21) حذف سيارة: يطلب تأكيدًا باسم السيارة، والرفض لا يحذف شيئًا', msgs.length === 1 && msgs[0].includes('Toyota Corolla') && msgs[0].includes('لا يمكن التراجع') && R(`getMemberCarById(101)`) !== null);
    E.ctx.confirm = () => true;
  }

  /* ================= 12/14/15/19) حفظ وحالات التحميل وعدم التكرار ================= */
  {
    // تاجر: إضافة سيارة بصور، ضغطتان متتاليتان → سيارة واحدة فقط وزر معطّل أثناء الحفظ
    const { E, R, setF } = mk('dealer1');
    R('ImageService').setCodec(mkCodec());
    R(`go('addShowroomCar')`);
    const dr = R('_imageCtx').draft; for (let i = 0; i < 2; i++) await dr.add(mkFile(3000, 2000));
    setF({ scBrand: 'Kia', scModel: 'DoubleTap', scYear: '2021', scPrice: '9000000', scMileage: '1', scColor: '', scDescription: '' });
    E.els.scTransmission = { value: 'أوتوماتيك' }; E.els.scFuelType = { value: 'بنزين' };
    E.els.addShowroomCarBtn = { textContent: 'نشر السيارة', disabled: false, style: {} };
    const p1 = R('handleAddShowroomCarSubmit()'), midDisabled = E.els.addShowroomCarBtn.disabled, midLabel = E.els.addShowroomCarBtn.textContent;
    const p2 = R('handleAddShowroomCarSubmit()');
    await Promise.all([p1, p2]);
    t('19) ضغطتان متتاليتان على «نشر» تُنشئان سيارة واحدة فقط', R(`getCars().filter(c=>c.model==='DoubleTap').length`) === 1);
    t('19b) الزر يُعطَّل ويعرض «جارٍ الحفظ…» أثناء الحفظ ثم يعود', midDisabled === true && midLabel === 'جارٍ الحفظ…' && E.els.addShowroomCarBtn.disabled === false && E.els.addShowroomCarBtn.textContent === 'نشر السيارة');
    t('15) التاجر: السيارة تصبح متاحة (active) مباشرة بلا إعلان ولا موافقة', R(`getCars().find(c=>c.model==='DoubleTap').status`) === 'available' && R('isRewardRequired()') === false);
    t('16) صور المعرض: 5 كحد أقصى وضغط 1600px/WebP/0.8 كما هي', R('IMAGE_LIMITS.SHOWROOM_MAX_IMAGES') === 5 && R('IMAGE_LIMITS.MAX_SIDE') === 1600 && R('IMAGE_LIMITS.QUALITY') === 0.8 && R('getCarImages(getCars().find(c=>c.model==="DoubleTap").id).length') === 2);
    // حذف سيارة المعرض: تأكيد + قفل
    const msgs = []; E.ctx.confirm = (m) => { msgs.push(m); return false; };
    const did = R(`getCars().find(c=>c.model==='DoubleTap').id`);
    await R(`handleDeleteShowroomCar(${did})`);
    t('21b) حذف سيارة المعرض: تأكيد باسمها، والرفض لا يحذف', msgs.length === 1 && msgs[0].includes('Kia DoubleTap') && R(`getCarById(${did})`) !== undefined);
    E.ctx.confirm = () => true;
    const d1 = R(`handleDeleteShowroomCar(${did})`), d2 = R(`handleDeleteShowroomCar(${did})`); await Promise.all([d1, d2]);
    t('19c) حذف متكرر سريع لا يسبب خطأ ولا رسالة «غير موجود»', R(`getCarById(${did})`) === undefined && !/غير موجود/.test(E.els.toast ? E.els.toast.textContent : ''));
    // منتقي الصور: معالجة متداخلة مرفوضة
    R(`go('addShowroomCar')`); R('_imageCtx').busy = true;
    const inp = { files: [mkFile(1000, 1000)], value: 'x' }; await R('handlePickImages')(inp);
    t('19d) اختيار صور أثناء معالجة جارية لا يبدأ معالجة متداخلة (ويُفرَّغ الحقل)', R('_imageCtx').draft.count() === 0 && inp.value === '');
    R('_imageCtx').busy = false;
    // عضو (dealer) مع صور: ضغطتان → سيارة واحدة
    R(`go('addMemberCar')`); const d3 = R('_imageCtx').draft; await d3.add(mkFile(2000, 2000));
    setF({ mcBrand: 'Kia', mcModel: 'MemberTap', mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07701234567', mcWhatsapp: '', mcDescription: '' });
    E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
    R('handleAddMemberCarSubmit()'); R('handleAddMemberCarSubmit()');
    await new Promise(r => setTimeout(r, 0)); await new Promise(r => setTimeout(r, 0));
    t('19e) نشر سيارة عضو مع صور: ضغطتان → سيارة واحدة، وصورها محفوظة', R(`getMemberCars().filter(c=>c.model==='MemberTap').length`) === 1 && R(`getCarImages(getMemberCars().find(c=>c.model==='MemberTap').id).length`) === 1);
  }
  {
    // مستخدم عادي: نافذة الإعلان — ضغطة ثانية أثناء فتحها لا تُنشئ مسودة ثانية، والإعلان المكافأ كما هو
    const { E, R, setF } = mk('user');
    R('ImageService').setCodec(mkCodec());
    R(`go('addMemberCar')`);
    setF({ mcBrand: 'Kia', mcModel: 'RewardTap', mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07700000001', mcWhatsapp: '', mcDescription: '' });
    E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
    R('handleAddMemberCarSubmit()'); const first = R('_currentDraftId'); R('handleAddMemberCarSubmit()');
    t('12) المستخدم العادي: نافذة الإعلان تُفتح وتبقى مسودة واحدة عند الضغط المتكرر', E.els.rewardAdOverlay.style.display === 'flex' && first && R('_currentDraftId') === first);
    t('12b) حد صور المستخدم 4 والرئيسية ضمنها، والمنتقي يُظهر «الصور 0 / 4»', R('_imageCtx').max === 4 && R('ImagePickerInner()').includes('الصور 0 / 4'));
    R('handleWatchRewardAd()'); E.tick(8);
    t('12c) بعد اكتمال الإعلان تُنشر السيارة active مباشرة بلا موافقة', R(`getMemberCars().find(c=>c.model==='RewardTap').status`) === 'active');
  }

  /* ================= 14) سيارات معرضي ================= */
  {
    const { E, R } = mk('dealer1');
    R(`go('myShowroomCars')`); const s = E.screen();
    t('14) سيارات معرضي: بطاقة بالصورة/الماركة/الموديل/السنة/السعر/الحالة + تعديل/حذف/تغيير الحالة + «+ إضافة سيارة»، وسيارات معرضه فقط',
      s.includes('Toyota Corolla') && s.includes('2022') && s.includes('د.ع') && s.includes('متاحة للبيع') && s.includes('+ إضافة سيارة') && s.includes(`go('editShowroomCar', 1)`) && s.includes('handleDeleteShowroomCar(1)') && s.includes('handleShowroomCarStatusChange(1') && !s.includes('Sportage') && !s.includes('Genesis'));
    const d = mk('dealer5'); d.R(`getCars().filter(c=>c.showroomId===5).map(c=>c.id)`).forEach(id => d.R(`deleteShowroomCar(${id})`));
    d.R(`go('myShowroomCars')`);
    t('18b) سيارات معرضي بلا سيارات: حالة فارغة مفسَّرة', d.E.screen().includes('لا توجد سيارات مضافة') && d.E.screen().includes('أضف أول سيارة'));
    const m = mk('user'); m.R(`go('memberCars')`);
    const all = m.R('getMemberCars().length'); m.R(`MEMBER_CARS.forEach(c => { c.status = 'sold'; })`); m.R(`go('memberCars')`);
    t('18c) سيارات الأعضاء بلا نشطة: «لا توجد سيارات أعضاء حاليًا» + زر نشر', m.E.screen().includes('لا توجد سيارات أعضاء حاليًا') && m.E.screen().includes(`go('addMemberCar')`) && all > 0);
    const h = mk(null); h.R(`CARS.length = 0`); h.R(`go('cars')`); const hc = h.E.screen(); h.R(`go('home')`);
    t('18d) لا سيارات إطلاقًا: «لا توجد سيارات حاليًا» في السيارات والرئيسية', hc.includes('لا توجد سيارات حاليًا') && h.E.screen().includes('لا توجد سيارات حاليًا'));
  }

  /* ================= التنقل ================= */
  {
    const { E, R } = mk(null);
    R(`go('cars')`); R(`go('carDetails',1)`); R('goBack("cars")');
    t('التنقل 1) الرجوع من تفاصيل السيارة يعود للقائمة التي جاء منها', R('currentRoute') === 'cars');
    R(`go('home')`); R(`go('search','تويوتا')`); R(`go('carDetails',1)`); R('goBack("cars")');
    t('التنقل 2) من نتائج البحث → تفاصيل → رجوع يعود للبحث (لا لقائمة ثابتة) ويحتفظ بالنص', R('currentRoute') === 'search' && R('currentParam') === 'تويوتا');
    R(`go('showroomDetails',2)`); R('goBack("showrooms")'); R('goBack("home")');
    t('التنقل 3) سلسلة رجوع متتالية تمرّ بالشاشات السابقة بالترتيب (بحث ثم الرئيسية)', R('currentRoute') === 'home');
    const f = mk(null); f.R('goBack("showrooms")');
    t('التنقل 4) رجوع بلا سجل يذهب إلى المسار الاحتياطي', f.R('currentRoute') === 'showrooms');
    const u = mk('user'); u.R(`go('favorites')`); u.R(`go('carDetails',1)`); u.R('goBack("cars")');
    t('التنقل 5) من المفضلة → تفاصيل → رجوع يعود للمفضلة', u.R('currentRoute') === 'favorites');
    const g = mk(null); g.R(`go('favorites')`); g.R(`go('login')`); g.R(`go('register')`); g.R(`go('home')`);
    t('التنقل 6) شاشتا الدخول/التسجيل لا تدخلان سجل الرجوع', g.R('_navStack.every(e => e.route !== "login" && e.route !== "register")'));
    const need = { guest: [['login', 'goBack'], ['register', 'goBack'], ['memberCars', 'goBack'], ['search', 'goBack']], user: [['account', 'goBack'], ['myMemberCars', 'goBack'], ['addMemberCar', 'goBack']], dealer1: [['dealerHome', 'goBack'], ['myShowroomCars', 'goBack'], ['addShowroomCar', 'goBack']], admin: [['adminMemberCars', 'goBack'], ['adminShowrooms', 'goBack'], ['adminShowroomCars', 'goBack'], ['adminUsers', 'goBack'], ['adminDealerRequests', 'goBack']] };
    let missing = [];
    for (const [role, list] of Object.entries(need)) { const x = mk(role === 'guest' ? null : role); for (const [r] of list) { x.R(`go('${r}')`); if (!x.E.screen().includes('goBack(')) missing.push(r); } }
    const ee = mk('dealer1'); ee.R(`go('editShowroomCar',1)`); if (!ee.E.screen().includes('goBack(')) missing.push('editShowroomCar');
    const em = mk('user'); em.R(`go('editMemberCar',101)`); if (!em.E.screen().includes('goBack(')) missing.push('editMemberCar');
    t('التنقل 7) شريط رجوع في كل شاشات الحساب/التاجر/الإدارة/الدخول', missing.length === 0, missing.join(','));
    const b = mk(null); b.R(`go('cars')`); const nav = b.E.els.bottomnav.innerHTML;
    t('التنقل 8) الشريط السفلي سليم (5 أزرار، الحالي مفعّل)', (nav.match(/navbtn/g) || []).length >= 5 && nav.includes('navbtn active'));
  }

  /* ================= 20) الأخطاء ================= */
  {
    t('20b) userMsg يمنع الرسائل التقنية/الفارغة ويُبقي العربية', R0(`userMsg(undefined)`) === 'حدث خطأ، حاول مرة أخرى' && R0(`userMsg('')`) === 'حدث خطأ، حاول مرة أخرى' && R0(`userMsg('TypeError: x is not a function')`) === 'حدث خطأ، حاول مرة أخرى' && R0(`userMsg('ReferenceError: y')`) === 'حدث خطأ، حاول مرة أخرى' && R0(`userMsg('undefined')`) === 'حدث خطأ، حاول مرة أخرى' && R0(`userMsg('السعر غير صحيح.')`) === 'السعر غير صحيح.');
    function R0(c) { return mk(null).R(c); }
    const { E, R } = mk(null);
    R(`notify(undefined)`); const t1 = E.els.toast.textContent;
    R(`notify('TypeError: a is not a function','error')`); const t2 = E.els.toast.textContent;
    R(`notify('تم حفظ التعديلات')`); const t3 = E.els.toast.textContent;
    t('20c) الرسائل العابرة: نص عربي واضح دائمًا (لا undefined ولا TypeError)', t1 === 'حدث خطأ، حاول مرة أخرى' && t2 === 'حدث خطأ، حاول مرة أخرى' && t3 === 'تم حفظ التعديلات' && E.els.toast.style.display === 'block');
    // انهيار شاشة: رسالة عربية وأزرار، والتفاصيل في console
    const logged = []; E.ctx.console = { error: (...a) => logged.push(a.join(' ')), log() {}, warn() {} };
    R(`ROUTES.cars.render = () => { throw new TypeError('secret technical boom'); }`);
    R(`go('cars')`); const h = E.screen();
    t('20d) انهيار شاشة: لا يُعرض خطأ تقني بل رسالة عربية مع «إعادة المحاولة» و«العودة للرئيسية»', h.includes('حدث خطأ، حاول مرة أخرى') && h.includes('إعادة المحاولة') && h.includes("go('home')") && !h.includes('TypeError') && !h.includes('secret technical boom'));
    t('20e) التفاصيل التقنية تُترك في Console للمطوّر', logged.some(l => l.includes('[render error]') && l.includes('cars')));
    // معالجات الأخطاء العامة
    const pre = E.els.toast.textContent; E.els.toast.textContent = '';
    E.winHandlers.error({ message: 'ResizeObserver loop limit exceeded' });
    const ignored = E.els.toast.textContent === '';
    E.winHandlers.error({ message: 'x', error: new Error('internal') });
    const afterErr = E.els.toast.textContent; E.els.toast.textContent = '';
    E.winHandlers.unhandledrejection({ reason: new Error('async internal') });
    t('20f) أي خطأ غير متوقع (error/unhandledrejection): رسالة عربية فقط، وضجيج ResizeObserver يُتجاهل', ignored && afterErr === 'حدث خطأ، حاول مرة أخرى' && E.els.toast.textContent === 'حدث خطأ، حاول مرة أخرى' && !/internal/.test(E.els.toast.textContent) && logged.some(l => l.includes('[app error]')) && logged.some(l => l.includes('[app rejection]')));
    // رسالة خدمة فارغة/سيئة لا تظهر كما هي
    const u = mk('user'); u.R(`deleteMemberCar = () => ({ ok: false })`);
    u.E.ctx.confirm = () => true; u.R(`handleDeleteMemberCar(101)`);
    t('20g) فشل عملية بلا رسالة: يظهر «حدث خطأ، حاول مرة أخرى» وليس undefined', u.E.els.toast.textContent === 'حدث خطأ، حاول مرة أخرى');
  }

  /* ================= قيود المراحل السابقة لم تتغير ================= */
  {
    const { E, R } = mk('user');
    t('قيود) Rewarded Ad للمستخدم كما هو، وحدود الصور 4/5، وضغط الصور 1600/WebP', R('isRewardRequired()') === true && R('IMAGE_LIMITS.USER_MAX_IMAGES') === 4 && R('IMAGE_LIMITS.SHOWROOM_MAX_IMAGES') === 5 && R('IMAGE_LIMITS.MAX_SIDE') === 1600);
    t('قيود) صلاحيات user: لا إدارة ولا لوحة ولا سيارات معارض', ['adminHome', 'dealerHome', 'myShowroomCars', 'addShowroomCar'].every(r => { R(`go('${r}')`); return R('currentRoute') === 'accessDenied'; }));
    const d = mk('dealer1'); t('قيود) صلاحيات dealer: معرضه فقط ولا لوحة إدارة', d.R(`AuthorizationService.canManageCar(4)`) === false && (d.R(`go('adminHome')`), d.R('currentRoute')) === 'accessDenied' && d.R(`AuthorizationService.canManageCar(1)`));
    const a = mk('admin'); t('قيود) صلاحيات admin كما هي', a.R(`AuthorizationService.canAccessAdmin()`) && (a.R(`go('adminHome')`), a.R('currentRoute')) === 'adminHome');
    const src = fs.readFileSync(path.resolve(__dirname, '../index.html'), 'utf8');
    t('قيود) لا Firebase/Supabase/AdMob/AdSense/Maps API في الصفحة', !/firebase|supabase|googlesyndication|adsbygoogle|maps\.googleapis|admob/i.test(src));
  }

  /* ================= تدقيق البنود 22–28 (الجزء المقطوع من المواصفات) ================= */
  const fillMember = (x, o = {}) => { x.setF({ mcBrand: 'Kia', mcModel: 'Aud', mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07700000001', mcWhatsapp: '', mcDescription: '', ...o }); x.E.els.mcTransmission = { value: 'أوتوماتيك' }; x.E.els.mcFuelType = { value: 'بنزين' }; };
  const fillShowroom = (x, o = {}) => { x.setF({ scBrand: 'Kia', scModel: 'Aud', scYear: '2021', scPrice: '9000000', scMileage: '1', scColor: '', scDescription: '', ...o }); x.E.els.scTransmission = { value: 'أوتوماتيك' }; x.E.els.scFuelType = { value: 'بنزين' }; };
  {
    /* --- 22: منع النقر المتكرر --- */
    const x = mk('user'); x.R('ImageService').setCodec(mkCodec()); x.R(`go('addMemberCar')`); fillMember(x, { mcModel: 'Dbl' });
    x.R('handleAddMemberCarSubmit()'); x.E.els.rewardAdError = { textContent: '', style: { display: 'none' } };
    x.R('handleWatchRewardAd()'); x.R('handleWatchRewardAd()'); x.E.tick(8); x.E.tick(8);
    t('22) نقرتان على «مشاهدة الإعلان»: سيارة واحدة فقط وبلا رسالة خطأ متأخرة بعد النجاح', x.R(`getMemberCars().filter(c=>c.model==='Dbl').length`) === 1 && x.E.els.rewardAdError.textContent === '');
    x.R(`go('addMemberCar')`); fillMember(x, { mcModel: 'Dbl2' }); x.R('handleAddMemberCarSubmit()'); x.R('handleWatchRewardAd()'); x.E.tick(3); x.R('handleCancelRewardAd()'); x.E.tick(8);
    t('22b) بعد إلغاء الإعلان لا يكتمل عدّاد قديم ولا تُنشر السيارة', !x.R(`getMemberCars().some(c=>c.model==='Dbl2')`));
    // حفظ/حذف/رفع صور — أزرار غير فورية محمية (مغطّاة في فحوصات 19–19e أعلاه)؛ تسجيل الدخول والتسجيل فوريان (لا نقرة ثانية ممكنة بعد إعادة الرسم)
    const r = mk(null); r.R(`go('register')`); r.setF({ regName: 'سالم حسن', regPhone: '07712345678', regEmail: '', regPassword: '123456', regConfirm: '123456' }); r.R('handleRegisterSubmit()'); r.R('handleRegisterSubmit()');
    t('22c) تسجيل مزدوج سريع لا ينشئ حسابين بنفس الرقم', r.R(`USERS.filter(u=>u.phone==='07712345678').length`) === 1);
  }
  {
    /* --- 23: الصلاحيات — كل مسار × كل دور (150 حالة) --- */
    const all = Object.keys(mk(null).R('ROUTES'));
    const param = { showroomDetails: 1, carDetails: 1, memberCarDetails: 101, editMemberCar: 102, editShowroomCar: 4, adminMemberCarDetails: 101, adminUserDetails: 1, search: '' };
    const isAdminRoute = r => r.startsWith('admin') && r !== 'accessDenied';
    const expect = (role, r) => {
      if (['login', 'register'].includes(r)) return role === 'guest' ? r : 'account';
      if (isAdminRoute(r)) return role === 'admin' ? r : role === 'guest' ? 'login' : 'accessDenied';
      if (['dealerHome', 'myShowroomCars', 'addShowroomCar'].includes(r)) return role === 'dealer1' ? r : role === 'guest' ? 'login' : 'accessDenied';
      if (r === 'editShowroomCar') return role === 'guest' ? 'login' : role === 'admin' ? r : 'accessDenied'; // سيارة 4 = معرض آخر
      if (r === 'editMemberCar') return role === 'guest' ? 'login' : (role === 'admin' || role === 'dealer1') ? r : 'accessDenied'; // 102 مملوكة للتاجر 1
      if (['account', 'myMemberCars', 'addMemberCar'].includes(r)) return role === 'guest' ? 'login' : r;
      return r;
    };
    const bad = []; let cells = 0;
    for (const role of ['guest', 'user', 'pending', 'dealer1', 'admin']) for (const r of all) {
      const x = mk(role === 'guest' ? null : role); x.R(`go('${r}', ${JSON.stringify(param[r])})`); cells++;
      if (x.R('currentRoute') !== expect(role, r)) bad.push(`${role}->${r}:${x.R('currentRoute')}`);
    }
    t('23) مصفوفة الصلاحيات: ' + cells + ' حالة (كل مسار × كل دور) مطابقة للمتوقع', bad.length === 0 && cells >= 150, bad.slice(0, 4).join(' | '));
    const y = mk('user'); y.R(`currentRoute='adminHome'; currentParam=undefined; render()`);
    t('23b) تعديل currentRoute يدويًا لا يفتح شاشة محمية', y.R('currentRoute') === 'accessDenied');
    const z = mk('user'); z.R(`go('myMemberCars')`); z.R(`go('account')`); z.R('handleLogout()'); z.R('goBack("home")'); z.R('goBack("home")');
    t('23c) بعد تسجيل الخروج الرجوع إلى شاشات المستخدم لا يعرض بياناتها', ['login', 'home'].includes(z.R('currentRoute')) && !z.E.screen().includes('07700000001'));
    const a1 = mk(null); a1.R(`go('editMemberCar',101)`); a1.setF({ loginIdentifier: '07700000001', loginPassword: 'user123' }); a1.R('handleLoginSubmit()');
    const a2 = mk(null); a2.R(`go('adminHome')`); a2.setF({ loginIdentifier: '07700000001', loginPassword: 'user123' }); a2.R('handleLoginSubmit()');
    const a3 = mk(null); a3.R(`go('editMemberCar',102)`); a3.setF({ loginIdentifier: '07700000001', loginPassword: 'user123' }); a3.R('handleLoginSubmit()');
    t('23d) بعد الدخول: المالك يصل لوجهته، والمستخدم العادي لا يدخل الإدارة، وغير المالك يُرفض', a1.R('currentRoute') === 'editMemberCar' && a2.R('currentRoute') === 'accessDenied' && a3.R('currentRoute') === 'accessDenied');
    const g = mk(null); const svc = ['createShowroomCar({brand:"a",model:"b",year:"2020",price:"1"})', 'updateShowroomCar(1,{price:"1"})', 'deleteShowroomCar(1)', 'changeShowroomCarStatus(1,"sold")', 'createDraftMemberCar({brand:"a",model:"b",year:"2020",price:"1",phone:"07700000000"})', 'updateMemberCar(101,{price:"1"})', 'deleteMemberCar(101)', 'changeMemberCarStatus(101,"sold")', 'approveMemberCar(103)', 'suspendShowroom(1)', 'approveDealer(8)', 'setShowroomCarStatus(1,"sold")', 'toggleFavorite(1)', 'removeCarImage(1)', 'setMainImage(1)'];
    let allDenied = true; for (const c of svc) { const r = await g.R(c); if (r.ok) allDenied = false; }
    t('23e) كل خدمات التعديل تُرفض للزائر حتى بدون واجهة (' + svc.length + ' خدمة)', allDenied);
  }
  {
    /* --- 24: سجل التنقل بعد النماذج --- */
    const d = mk('dealer1'); d.R('ImageService').setCodec(mkCodec());
    d.R(`go('dealerHome')`); d.R(`go('myShowroomCars')`); d.R(`go('addShowroomCar')`); fillShowroom(d, { scModel: 'HistA' }); await d.R('handleAddShowroomCarSubmit()'); d.R('goBack("dealerHome")');
    t('24) بعد إضافة سيارة وحفظها: الرجوع يتجاوز النموذج ويعود للشاشة التي قبله', d.R('currentRoute') === 'dealerHome');
    d.R(`go('myShowroomCars')`); d.R(`go('editShowroomCar',1)`); d.R('handleEditShowroomCarSubmit(1)'); d.R('goBack("dealerHome")');
    t('24b) بعد تعديل سيارة وحفظها: الرجوع لا يعيد إلى نموذج التعديل', d.R('currentRoute') === 'dealerHome');
    t('24c) النماذج لا تدخل سجل الرجوع أبدًا', d.R('_navStack.every(e => !/^(add|edit)(Member|Showroom)Car$/.test(e.route))'));
    const u = mk('user'); u.E.ctx.confirm = () => true; u.R(`go('account')`); u.R(`go('myMemberCars')`); u.R(`go('memberCarDetails',101)`); u.R('handleDeleteMemberCar(101)'); u.R('goBack("account")');
    t('24d) بعد حذف إعلان من صفحته: الرجوع لا يهبط على صفحة «غير موجود»', !u.E.screen().includes('الإعلان غير موجود') && u.R('currentRoute') !== 'memberCarDetails');
    const st = mk(null); for (let i = 0; i < 60; i++) { st.R(`go('carDetails',${(i % 15) + 1})`); st.R(`go('cars')`); }
    t('24e) سجل التنقل محدود الحجم (≤ 30) ولا يتضخم', st.R('_navStack.length') <= 30);
  }
  {
    /* --- 25: الهاتف (فحص ثابت لـ CSS + الصفحة) --- */
    const css = fs.readFileSync(path.resolve(__dirname, '../theme/theme.css'), 'utf8'), html = fs.readFileSync(path.resolve(__dirname, '../index.html'), 'utf8');
    t('25) meta viewport مع viewport-fit=cover وحواف آمنة (safe-area)', /width=device-width, initial-scale=1, viewport-fit=cover/.test(html) && (css.match(/safe-area-inset/g) || []).length >= 3);
    t('25b) الحقول 16px على الهاتف (يمنع تكبير iOS عند التركيز)', /@media \(max-width:600px\)\{[^}]*\.field input[^}]*font-size:16px/.test(css));
    t('25c) أهداف لمس مريحة: 44px للأزرار الأساسية و40px للثانوية', /\.btn-primary,\.action-btn\{min-height:44px;\}/.test(css) && /\.link-btn[^{]*\{min-height:40px;\}/.test(css));
    t('25d) النص الطويل بلا مسافات يلتف بدل كسر البطاقة', /overflow-wrap:anywhere/.test(css));
    t('25e) الشريط السفلي ثابت مع مساحة سفلية للمحتوى وتجاوز الحواف الآمنة', /\.bottomnav\{[^}]*position:fixed/.test(css) && /padding-bottom:76px/.test(css) && /env\(safe-area-inset-bottom/.test(css));
  }
  {
    /* --- 26: RTL والعربية --- */
    const idx = fs.readFileSync(path.resolve(__dirname, '../index.html'), 'utf8'), bundle = fs.existsSync('/mnt/user-data/outputs/najaf-showrooms.html') ? fs.readFileSync('/mnt/user-data/outputs/najaf-showrooms.html', 'utf8') : idx;
    t('26) الصفحة عربية RTL (lang="ar" dir="rtl") وعنوانها عربي', /<html lang="ar" dir="rtl">/.test(idx) && /<html lang="ar" dir="rtl">/.test(bundle) && /<title>[^<]*[\u0600-\u06FF]/.test(idx));
    const dataWords = new Set(); const base = mk(null);
    JSON.stringify([base.R('CARS'), base.R('MEMBER_CARS'), base.R('SHOWROOMS'), base.R('USERS')]).match(/[A-Za-z][A-Za-z0-9@._-]{2,}/g).forEach(w => dataWords.add(w.toLowerCase()));
    ['toyota', 'corolla', 'camry', 'hyundai', 'kia', 'nissan', 'genesis', 'lexus', 'bmw', 'haidar', 'najaf', 'showrooms', 'showroom', 'example', 'com'].forEach(w => dataWords.add(w));
    const english = new Set();
    for (const role of [null, 'user', 'dealer1', 'admin']) {
      const x = mk(role); x.R(`go('addMemberCar')`);
      const visit = (r, p) => { x.R(`go('${r}', ${JSON.stringify(p)})`); let h = x.E.screen(); if (r === 'addMemberCar') h += ' ' + R_modal(x);
        h.replace(/<script[\s\S]*?<\/script>/g, ' ').replace(/<div class="ad-slot[\s\S]*?<\/div>/g, ' ').replace(/<[^>]+>/g, ' ').match(/[A-Za-z]{3,}/g)?.forEach(w => { if (!dataWords.has(w.toLowerCase())) english.add(w); }); };
      ['home', 'showrooms', 'cars', 'map', 'favorites', 'login', 'register', 'account', 'memberCars', 'search', 'dealerHome', 'adminHome', 'adminMemberCars', 'adminShowrooms', 'adminUsers', 'myMemberCars', 'addMemberCar', 'myShowroomCars', 'addShowroomCar'].forEach(r => visit(r));
      [['showroomDetails', 1], ['carDetails', 1], ['memberCarDetails', 101], ['editMemberCar', 101], ['editShowroomCar', 1], ['adminMemberCarDetails', 103], ['adminUserDetails', 1]].forEach(([r, p]) => visit(r, p));
    }
    function R_modal(x) { return x.R('RewardAdModal()'); }
    t('26b) لا نصوص إنجليزية ظاهرة في الواجهة (عدا أسماء الماركات/البيانات)، بما فيها نافذة الإعلان', english.size === 0, [...english].join(','));
  }
  {
    /* --- 27: حالات خاصة --- */
    const PAY = '<img src=x onerror=alert(1)>', leaks = [];
    for (const role of [null, 'user', 'dealer1', 'admin']) {
      const x = mk(role);
      x.R(`USERS.push(UserModel({id:50,name:${JSON.stringify(PAY)},phone:'07790000050',email:${JSON.stringify(PAY)},role:'dealer',status:'pending',passwordHash:'x',createdAt:'2026-01-01'}))`);
      x.R(`MEMBER_CARS.push(CarModel({id:970,sourceType:'member',ownerId:50,brand:${JSON.stringify(PAY)},model:${JSON.stringify(PAY)},year:2020,price:1000,status:'active',color:${JSON.stringify(PAY)},location:${JSON.stringify(PAY)},description:${JSON.stringify(PAY)},phone:'07790000050',rejectionReason:${JSON.stringify(PAY)}}))`);
      x.R(`MEMBER_CARS.push(CarModel({id:971,sourceType:'member',ownerId:7,brand:'X',model:'Y',year:2020,price:1000,status:'rejected',rejectionReason:${JSON.stringify(PAY)},location:'z'}))`);
      x.R(`CARS.push(CarModel({id:972,sourceType:'showroom',showroomId:1,brand:${JSON.stringify(PAY)},model:${JSON.stringify(PAY)},year:2020,price:1000,status:'available',color:${JSON.stringify(PAY)},description:${JSON.stringify(PAY)}}))`);
      x.R(`SHOWROOMS.push(ShowroomModel({id:88,name:${JSON.stringify(PAY)},address:${JSON.stringify(PAY)},description:${JSON.stringify(PAY)},workingHours:${JSON.stringify(PAY)},services:[${JSON.stringify(PAY)}],phone:'07790000088',status:'active',ownerId:1}))`);
      const visit = (r, p) => { x.R(`go('${r}',${JSON.stringify(p)})`); if (x.E.screen().includes('<img src=x')) leaks.push(role + ':' + r); };
      ['home', 'showrooms', 'cars', 'map', 'memberCars', 'account', 'myMemberCars', 'dealerHome', 'adminHome', 'adminMemberCars', 'adminShowrooms', 'adminShowroomCars', 'adminUsers', 'adminDealerRequests', 'myShowroomCars'].forEach(r => visit(r));
      [['showroomDetails', 88], ['carDetails', 972], ['memberCarDetails', 970], ['adminMemberCarDetails', 970], ['adminMemberCarDetails', 971], ['adminUserDetails', 50], ['editMemberCar', 970], ['editShowroomCar', 972], ['search', PAY]].forEach(([r, p]) => visit(r, p));
      x.R(`go('cars')`); x.R(`onCarsSearch(${JSON.stringify(PAY)})`); if (x.E.els.carsList.innerHTML.includes('<img src=x')) leaks.push(role + ':carsSearch');
    }
    t('27) نص ضارّ (HTML) في أي حقل يُدخله المستخدم لا يُنفَّذ في أي شاشة، بما فيها شاشات الإدارة', leaks.length === 0, [...new Set(leaks)].join(','));
    const rg = mk(null); rg.R(`go('register')`); rg.setF({ regName: PAY, regPhone: '07788888888', regEmail: '', regPassword: '123456', regConfirm: '123456' }); rg.R('handleRegisterSubmit()'); rg.R(`go('account')`);
    const adm = mk('admin'); adm.R(`USERS.push(UserModel({id:60,name:${JSON.stringify(PAY)},phone:'07788888889',role:'user',status:'active',passwordHash:'x',createdAt:'2026-01-01'}))`); adm.R(`go('adminUsers')`);
    t('27a) اسم مسجَّل بوسوم HTML يظهر كنص في «حسابي» وقائمة المستخدمين', !rg.E.screen().includes('<img src=x') && rg.E.screen().includes('&lt;img') && !adm.E.screen().includes('<img src=x'));

    const storeBad = { 'najaf.session': '{bad json', 'najaf.favorites': '42', 'najaf.memberCars': '"oops"', 'najaf.showroomCars': '{"a":1}', 'najaf.carImages': 'null', 'najaf.registeredUsers': '[{"id":"x"}]' };
    const cs = makeEnv(storeBad); cs.run(`go('cars')`);
    t('27b) تخزين محلي تالف لا يُسقط التطبيق (9 سيارات ظاهرة للزائر بعد سياسة الظهور العام؛ كانت 12 بعد C7، و15 وزائر)', cs.errors.length === 0 && (cs.screen().match(/class="card car-card"/g) || []).length === 9 && !cs.run('SessionService.isLoggedIn()'));
    const th = makeEnv(); th.ctx.localStorage.setItem = () => { throw new Error('Quota'); }; th.ctx.localStorage.getItem = () => { throw new Error('Security'); };
    th.run(`go('login')`); th.els.loginIdentifier = { value: '07700000001', style: {} }; th.els.loginPassword = { value: 'user123', style: {} }; th.run('handleLoginSubmit()'); th.run('handleFavoriteToggle(1)');
    t('27c) تخزين غير متاح/ممتلئ: الدخول والمفضلة يعملان في الذاكرة بلا أخطاء', th.run('SessionService.isLoggedIn()') && th.run('isFavorite(1)') && th.errors.length === 0);
    const ex = mk('user'); ex.R(`storageSet('session',{userId:7,createdAt:1,expiresAt:2})`); ex.E.ctx.confirm = () => true; ex.R(`handleDeleteMemberCar(101)`);
    t('27d) انتهاء الجلسة ثم تنفيذ إجراء: يُرفض برسالة عربية ولا يُحذف شيء', ex.R('getMemberCarById(101)') !== null && ex.E.els.toast.textContent === 'لا تملك صلاحية حذف هذا الإعلان.');
    const n = mk('user'); const dr = d => n.R(`createDraftMemberCar(${JSON.stringify({ brand: 'K', model: 'M', year: '2020', price: '1000', phone: '07700000001', ...d })})`);
    t('27e) أرقام كما يكتبها الناس: «15,000,000» و«١٥٠٠٠٠٠٠» و«15.000.000» و«٢٠٢٠» تُقبل', ['15,000,000', '15٬000٬000', '١٥٠٠٠٠٠٠', '15.000.000'].every(v => dr({ price: v }).ok) && dr({ year: '٢٠٢٠' }).ok && n.R(`parseWholeNumber('15,000,000')`) === 15000000 && n.R(`parseWholeNumber('١٥٠٠٠٠٠٠')`) === 15000000);
    t('27f) «1e3» و«2020abc» و«-5» و«0» والكيلومترات السالبة واسم فارغ تُرفض (بدل سعر خاطئ بصمت)', ['1e3', '2020abc', '-5', '0'].every(v => !dr({ price: v }).ok) && !dr({ year: '2020abc' }).ok && !dr({ mileage: '-500' }).ok && !dr({ brand: '   ' }).ok && dr({ price: '15,000,000' }).ok);
    const dd = mk('dealer1'); const sc = await dd.R(`createShowroomCar({brand:'Kia',model:'Num',year:'٢٠٢١',price:'15,000,000',mileage:'65,000'})`);
    t('27g) سيارة المعرض: نفس قراءة الأرقام (السعر 15,000,000 والممشى 65,000 والسنة بأرقام عربية)', sc.ok && sc.car.price === 15000000 && sc.car.mileage === 65000 && sc.car.year === 2021 && !(await dd.R(`createShowroomCar({brand:'K',model:'M',year:'2020',price:'1e3'})`)).ok);
    const ue = mk('user'); t('27h) تعديل سيارة العضو بفواصل/أرقام عربية يُحفظ صحيحًا ويرفض النص', ue.R(`updateMemberCar(101,{price:'16,500,000',mileage:'٩٥٠٠٠'}).ok`) && ue.R('getMemberCarById(101).price') === 16500000 && ue.R('getMemberCarById(101).mileage') === 95000 && !ue.R(`updateMemberCar(101,{price:'abc'}).ok`));
    const ids = mk(null); ids.R(`go('carDetails','1')`); const s1 = ids.E.screen().includes('غير موجودة'); ids.R(`go('carDetails',null)`); const s2 = ids.E.screen().includes('غير موجودة'); ids.R(`go('memberCarDetails',NaN)`);
    t('27i) معرّفات غير صالحة (نص/null/NaN) تعرض «غير موجود» بدل الانهيار', s1 && s2 && ids.E.screen().includes('غير موجود') && ids.E.errors.length === 0);
  }
  {
    /* --- 28: عدم كسر الإعلان المكافأ وضغط الصور وتخزينها والحدود --- */
    const x = mk('user'); const cdc = { encodes: [], decode: async f => ({ width: f.width, height: f.height, close() {} }), encode: async (d, w, h, m, q) => { cdc.encodes.push({ w, h, mime: m, q }); return { type: m, size: Math.round(w * h * q * 0.2), compressed: true }; } }; x.R('ImageService').setCodec(cdc);
    t('28) الإعلان المكافأ: مطلوب للمستخدم فقط، وغير مطلوب للتاجر والمدير', x.R('isRewardRequired()') === true && mk('dealer1').R('isRewardRequired()') === false && mk('admin').R('isRewardRequired()') === false);
    x.R(`go('addMemberCar')`); fillMember(x, { mcModel: 'Gate' }); x.R('handleAddMemberCarSubmit()');
    const before = !x.R(`getMemberCars().some(c=>c.model==='Gate')`); x.R('handleWatchRewardAd()'); x.E.tick(7); const mid = !x.R(`getMemberCars().some(c=>c.model==='Gate')`); x.E.tick(1);
    t('28b) لا نشر قبل اكتمال العدّاد (8 ثوانٍ) وبعده تُنشر active مباشرة', before && mid && x.R(`getMemberCars().find(c=>c.model==='Gate').status`) === 'active');
    const pl = []; const st = x.R('ImageStore'); const op = st.put; st.put = async (id, b) => { pl.push(b); return op(id, b); };
    x.R(`go('editMemberCar',101)`); const f = mkFile(4000, 3000); x.E.ctx.__f = f; const r1 = await x.R(`addCarImage(101, __f)`), r2 = await (async () => { x.E.ctx.__f = mkFile(4000, 3000); return x.R(`addCarImage(101, __f)`); })(), r3 = await (async () => { x.E.ctx.__f = mkFile(4000, 3000); return x.R(`addCarImage(101, __f)`); })();
    t('28c) الضغط قبل التخزين: المخزن يستلم نسخة مضغوطة WebP ≤1600px ولا يستلم الأصل', pl.length === 2 && pl.every(b => b.compressed && b.type === 'image/webp' && b !== f) && cdc.encodes[0].w === 1600 && cdc.encodes[0].h === 1200 && cdc.encodes[0].q === 0.8);
    t('28d) حد صور العضو 4 (2 تجريبية + 2 جديدة) والخامسة تُرفض، وللتاجر 5', r1.ok && r2.ok && !r3.ok && r3.error === 'تم الوصول إلى الحد الأقصى للصور' && x.R('getMaxImagesForCar(getCarById(101))') === 4 && mk('dealer1').R('getMaxImagesForCar(getCarById(1))') === 5);
    const srcDir = path.resolve(__dirname, '..'); const fresh = ['services/imageService.js', 'services/imageStore.js', 'services/rewardService.js', 'services/carImagesService.js'].map(f => fs.readFileSync(path.join(srcDir, f), 'utf8'));
    t('28e) لا أثر للأصل في الشيفرة (originalUrl/originalImage) ولا SDK إعلانات في الصفحة', !fresh.some(s => /original(Image|Url|ImageUrl)\b/i.test(s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, ''))) && !/googlesyndication|adsbygoogle|admob|firebase|supabase/i.test(fs.readFileSync(path.join(srcDir, 'index.html'), 'utf8')));
  }

  /* ================= المراحل السابقة ================= */
  for (const n of [3, 4, 5, 6, 7]) {
    let ok = true; try { execSync(`node ${path.join(__dirname, `phase${n}.test.js`)}`, { stdio: 'pipe' }); } catch (e) { ok = false; }
    t(`اختبارات المرحلة ${n} تستمر بالنجاح`, ok);
  }

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('خطأ غير متوقع في الاختبار:', e); process.exit(2); });

const { makeEnv } = require('./harness');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra || ''); } };

let E = makeEnv();
const R = c => E.run(c);
const setF = (o) => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
const login = (identifier, password) => { R(`go('login')`); setF({ loginIdentifier: identifier, loginPassword: password }); R('handleLoginSubmit()'); };

t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | '));

// 29/30/31) سلامة بيانات البذر لسيارات الأعضاء
t('29/30) كل سيارة عضو لها ownerId رقمي (لا يوجد بدون ownerId)', R('MEMBER_CARS.every(c=>typeof c.ownerId==="number")'));
t('31) لا يوجد ownerId يشير إلى مستخدم غير موجود', R('MEMBER_CARS.every(c=>!!UserService._findById(c.ownerId))'));
t('19-seed) البيانات التجريبية 10 سيارات أعضاء', R('MEMBER_CARS.length') === 10);
t('19b) توجد حالات active/pending/sold على الأقل', ['active','pending','sold'].every(s => R(`MEMBER_CARS.filter(c=>c.status==='${s}').length`) > 0));

// 20/22/23) الفصل بين النوعين
t('20a) كل سيارات CARS مصدرها showroom', R(`getCars().every(c=>c.sourceType==='showroom')`));
t('20b) كل سيارات MEMBER_CARS مصدرها member', R(`MEMBER_CARS.every(c=>c.sourceType==='member')`));
t('22) سيارات المعارض لا تظهر في getActiveMemberCars', R(`getActiveMemberCars().every(c=>c.sourceType==='member')`));
t('23) سيارات الأعضاء لا تظهر في getCars (قائمة المعارض)', R(`getCars().every(c=>c.sourceType!=='member')`));
t('20c) سيارة معرض تملك showroomId ولا تملك ownerId', R(`getCarById(1).showroomId===1 && getCarById(1).ownerId===undefined`));
t('20d) سيارة عضو تملك ownerId ولا تملك showroomId', R(`getMemberCarById(101).ownerId===7 && getMemberCarById(101).showroomId===undefined`));

// 21) سيارات المعارض تستمر تعمل
R(`go('cars')`); t('21) شاشة السيارات (المعارض) لا تزال 9 للزائر (سياسة الظهور العام؛ كانت 12 بعد C7، و15)', (E.screen().match(/class="card car-card"/g)||[]).length === 9);
R(`go('carDetails',1)`); t('21b) تفاصيل سيارة معرض تعمل', E.screen().includes('Toyota Corolla') && E.errors.length===0);
R(`go('showroomDetails',1)`); t('21c) تفاصيل معرض تعمل', E.screen().includes('معرض النجف للسيارات'));

// 1) الزائر يشاهد النشطة
R(`go('memberCars')`);
const activeCount = R('getActiveMemberCars().length');
t('1) الزائر يشاهد سيارات الأعضاء النشطة فقط', (E.screen().match(/class="card car-card"/g)||[]).length === activeCount && activeCount > 0);
t('8) pending لا تظهر في القائمة العامة', !E.screen().includes(`onclick="go('memberCarDetails',103)"`));
t('17) rejected لا تظهر في القائمة العامة', !E.screen().includes(`onclick="go('memberCarDetails',109)"`));
t('18) suspended لا تظهر في القائمة العامة', !E.screen().includes(`onclick="go('memberCarDetails',110)"`));
t('15) sold لا تظهر ضمن النشطة', !E.screen().includes(`onclick="go('memberCarDetails',105)"`));
t('16) active تظهر (101)', E.screen().includes(`onclick="go('memberCarDetails',101)"`));

// الرئيسية: قسم سيارات الأعضاء
R(`go('home')`); t('7) الرئيسية تعرض قسم سيارات الأعضاء', E.screen().includes('سيارات الأعضاء') && E.screen().includes(`onclick="go('memberCars')"`));

// 2) الزائر لا يستطيع إضافة سيارة
R(`go('addMemberCar')`); t('2) الزائر → addMemberCar يُحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
// الزائر لا يصل لإعلاناتي أو تعديل
R(`go('myMemberCars')`); t('34a) الزائر → myMemberCars يُحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
R(`go('editMemberCar',101)`); t('34b) الزائر → editMemberCar يُحوَّل لتسجيل الدخول', R('currentRoute') === 'login');
// الزائر لا يرى تفاصيل إعلان pending عبر ID مباشر
R(`go('memberCarDetails',103)`); t('35a) الزائر لا يفتح تفاصيل إعلان pending عبر ID مباشر', R('currentRoute') === 'login');

// دخول مستخدم تجريبي (user، id=7 — نفس مالك عدة سيارات أعضاء تجريبية)
login('07700000001', 'user123');
t('3) المستخدم يستطيع فتح شاشة إضافة سيارة', (R(`go('addMemberCar')`), R('currentRoute')) === 'addMemberCar');

// 4/5/6/7) إنشاء سيارة جديدة — محدَّث للمرحلة 6: إنشاء البيانات لا يساوي النشر.
// الضغط على «نشر السيارة» لمستخدم (role=user) يفتح بوابة الإعلان المكافأ فورًا
// بدل إنشاء السيارة مباشرة كـ pending (السلوك القديم أُلغي عمدًا في هذه المرحلة).
setF({ mcBrand: 'Toyota', mcModel: 'Yaris', mcYear: '2021', mcPrice: '14000000', mcMileage: '30000',
       mcColor: 'أبيض', mcLocation: 'حي الحنانة، النجف', mcPhone: '07700000001', mcWhatsapp: '07700000001', mcDescription: 'سيارة نظيفة' });
E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
R('handleAddMemberCarSubmit()');
t('4-pre) نشر user يفتح بوابة الإعلان ولا يُنشئ السيارة فورًا (قاعدة المرحلة 6)',
  E.els.rewardAdOverlay.style.display === 'flex' && !R(`getMemberCarsByOwner(7).some(c=>c.model==='Yaris')`));
R('handleWatchRewardAd()');
E.tick(8); // محاكاة اكتمال العدّاد التنازلي (٨ ثوانٍ ضمن المدى 5-10)
t('4) بعد اكتمال الإعلان تُنشأ السيارة وتُنشر فعليًا', R(`getMemberCarsByOwner(7).some(c=>c.model==='Yaris')`));
const newCar = R(`getMemberCarsByOwner(7).find(c=>c.model==='Yaris')`);
t('5) السيارة الجديدة sourceType=member', newCar.sourceType === 'member');
t('6) السيارة الجديدة ownerId=currentUser.id', newCar.ownerId === 7);
t('7) السيارة الجديدة status=active مباشرة (لا pending/موافقة إدارية بعد المرحلة 6)', newCar.status === 'active');
const newId = newCar.id;

// 8/9) تظهر فورًا للعامة ولصاحبها (لا حاجة لموافقة إدارية بعد الآن)
t('8b) السيارة الجديدة تظهر فورًا في getActiveMemberCars', R(`getActiveMemberCars().some(c=>c.id===${newId})`));
R(`go('myMemberCars')`);
t('9) السيارة الجديدة تظهر داخل إعلاناتي لصاحبها', E.screen().includes('Toyota Yaris'));

// نموذج ناقص يُرفض
R(`go('addMemberCar')`);
setF({ mcBrand: '', mcModel: '', mcYear: '', mcPrice: '', mcMileage: '', mcColor:'', mcLocation:'', mcPhone:'', mcWhatsapp:'', mcDescription:'' });
E.els.mcTransmission = { value: 'أوتوماتيك' }; E.els.mcFuelType = { value: 'بنزين' };
R('handleAddMemberCarSubmit()');
t('4b) نموذج ناقص يُرفض', E.els.addMemberCarError.textContent.length > 0 && R('currentRoute') === 'addMemberCar');

// 10) صاحب السيارة يعدّل سيارته
R(`go('editMemberCar', ${newId})`);
t('10a) الراوتر يسمح للمالك بفتح شاشة التعديل', R('currentRoute') === 'editMemberCar');
setF({ mcPrice: '13500000', mcMileage: '31000', mcColor: 'فضي', mcLocation: 'حي الحنانة، النجف', mcPhone: '07700000001', mcWhatsapp: '07700000001', mcDescription: 'محدّث', mcImage: '' });
R(`handleEditMemberCarSubmit(${newId})`);
t('10b) صاحب السيارة يستطيع تعديل سيارته فعليًا', R(`getMemberCarById(${newId}).price`) === 13500000 && R(`getMemberCarById(${newId}).color`) === 'فضي');

// 11) لا يستطيع تعديل سيارة عضو آخر (103 مملوكة أيضًا لنفس sessions؟ لا، ownerId 7 كذلك -> استخدم سيارة مملوكة لغيره: 102 ownerId=1)
R(`go('editMemberCar', 102)`);
t('11) المستخدم لا يفتح شاشة تعديل سيارة عضو آخر (يُرفض)', R('currentRoute') === 'accessDenied');
const before102 = R('getMemberCarById(102).price');
const rForbiddenEdit = R(`updateMemberCar(102, { price: '999' })`);
t('11b) الخدمة نفسها ترفض تعديل سيارة عضو آخر حتى بنداء مباشر', rForbiddenEdit.ok === false && R('getMemberCarById(102).price') === before102);

// 13/14) تغيير الحالة (owner) بنداء مباشر على الخدمة (الشاشة تستخدم prompt وهو غير متاح هنا)
t('14) صاحب السيارة يستطيع تغيير حالة سيارته إلى active', R(`changeMemberCarStatus(${newId}, 'active').ok`) === true && R(`getMemberCarById(${newId}).status`) === 'active');
t('13b) وتظهر الآن ضمن getActiveMemberCars', R(`getActiveMemberCars().some(c=>c.id===${newId})`));
const rOwnerToRejected = R(`changeMemberCarStatus(${newId}, 'rejected')`);
t('14b) المالك لا يستطيع تعيين حالة rejected (محصور بـ active/sold)', rOwnerToRejected.ok === false);
t('14c) المالك يستطيع تعيين sold', R(`changeMemberCarStatus(${newId}, 'sold').ok`) === true);
t('15) بعد sold لا تظهر ضمن النشطة', !R(`getActiveMemberCars().some(c=>c.id===${newId})`));

// 12/13) الحذف
const r13Forbidden = R(`deleteMemberCar(102)`);
t('13) المستخدم لا يستطيع حذف سيارة عضو آخر', r13Forbidden.ok === false && R(`getMemberCarById(102)`) !== null);
t('12) صاحب السيارة يستطيع حذف سيارته', R(`deleteMemberCar(${newId}).ok`) === true && R(`getMemberCarById(${newId})`) === null);

// 27) المفضلة تعمل مع سيارات الأعضاء
R(`handleFavoriteToggle(104)`);
t('27) المفضلة تعمل مع سيارة عضو', R('isFavorite(104)') === true && R('getFavoriteCars().some(c=>c.id===104)'));
R(`handleFavoriteToggle(104)`);
t('27b) إزالة مفضلة سيارة عضو', R('isFavorite(104)') === false);
// 28) المفضلة تعمل أيضًا مع سيارات المعارض لنفس المستخدم
R(`handleFavoriteToggle(2)`);
t('28) المفضلة تعمل مع سيارة معرض لنفس المستخدم', R('isFavorite(2)') === true);
R('handleLogout()');

// 20) dealer لا يدير سيارة عضو آخر (تسجيل دخول dealer id=1)
login('07701234567', 'dealer123');
t('20e) dealer يستطيع إنشاء سيارة عضو شخصية له', R(`AuthorizationService.canCreateMemberCar()`) === true);
t('20) dealer لا يستطيع إدارة سيارة عضو آخر (owner=7)', R(`AuthorizationService.canManageMemberCar(undefined, getMemberCarById(101))`) === false);
t('20f) dealer يدير سيارته الشخصية (102, ownerId=1)', R(`AuthorizationService.canManageMemberCar(undefined, getMemberCarById(102))`) === true);
t('20g) صلاحيات dealer على معرضه لم تتأثر', R(`AuthorizationService.canManageShowroom(1)`) === true && R(`AuthorizationService.canManageCar(1)`) === true);
const rDealerDeleteOther = R(`deleteMemberCar(101)`);
t('20h) الخدمة ترفض حذف dealer لسيارة عضو آخر', rDealerDeleteOther.ok === false && R('getMemberCarById(101)') !== null);
R('handleLogout()');

// 19) admin يدير كل سيارات الأعضاء
login('07700000000', 'admin123');
t('19) admin يستطيع تغيير أي حالة (101 → suspended)', R(`changeMemberCarStatus(101,'suspended').ok`) === true);
R(`changeMemberCarStatus(101,'active')`); // إرجاعها كما كانت
t('19b) admin يستطيع الموافقة على إعلان pending (103 → active)', R(`changeMemberCarStatus(103,'active').ok`) === true);
R(`changeMemberCarStatus(103,'pending')`); // إرجاعها كما كانت
t('19c) admin يستطيع تعديل أي سيارة عضو', R(`updateMemberCar(102, { color: 'أحمر' }).ok`) === true);
t('19d) admin يستطيع حذف أي سيارة عضو (تجربة ثم عدم التأكيد الفعلي على بيانات مهمة، نستخدم سيارة مؤقتة)', (() => {
  const c = R(`createDraftMemberCar({brand:'Kia',model:'Test',year:'2020',price:'1000000',phone:'07700000000'})`);
  return c.ok && c.published === true && R(`deleteMemberCar(${c.car.id}).ok`) === true;
})());
R('handleLogout()');

// 24/25/26) البحث
R(`go('cars')`); // يضمن تحميل الشاشة (لا يؤثر على searchCars نفسه)
t('25) البحث في سيارات المعارض (افتراضي) لم يتغير', R(`searchCars('Toyota').length`) === 1 /* سياسة الظهور العام: كانت 2 بعد C7، و3 */ && R(`searchCars('Toyota').every(c=>c.sourceType==='showroom')`));
t('24) البحث في سيارات الأعضاء يعمل', R(`searchCars('Toyota','member').length`) === 1 && R(`searchCars('Toyota','member')[0].sourceType`) === 'member'); // 101 فقط (105 مباعة)
t('24b) البحث بالموقع في سيارات الأعضاء', R(`searchCars('السلام','member').some(c=>c.id===104) === false && searchCars('الأمير','member').some(c=>c.id===104)`) === true);
t('26) البحث all يعرض النوعين', (() => {
  const res = R(`searchCars('a','all')`); // مطابقة فضفاضة عبر السنة أو الاسم
  const res2 = R(`searchCars('Toyota','all')`);
  return res2.some(c=>c.sourceType==='showroom') && res2.some(c=>c.sourceType==='member');
})());

// 32/33) لا أخطاء JS + الراوتر يعمل للمسارات الجديدة
const E5 = makeEnv();
['memberCars','addMemberCar','myMemberCars'].forEach(r => E5.run(`go('${r}')`)); // addMemberCar/myMemberCars للزائر تُحوَّل لتسجيل الدخول (متوقع، بلا أخطاء)
E5.run(`go('memberCarDetails',101)`);
t('33) الراوتر يعمل لكل المسارات الجديدة بلا استثناءات', E5.errors.length === 0, E5.errors.join('|'));
t('32) لا أخطاء JavaScript إجمالًا', E.errors.length === 0 && E5.errors.length === 0);

console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
process.exit(fail ? 1 : 0);

/* اختبارات «المرحلة 10 — الجزء 6.2-B: إمكانية الوصول + التحقق النهائي من التجربة» (Phase 10 Part 6.2-B).
   الفحوص البصرية والتركيز الحقيقي (Tab/Escape/Enter، حبس التركيز، overflow على 320/360/390/412) تتطلب متصفحًا فعليًا وتُجرى في Chromium (انظر التقرير).
   هنا نثبّت آليًا ما يمكن تثبيته بلا متصفح كي لا يتراجع:
   (أ) سمات الوصول: ربط label بكل حقل، aria-required، inputmode/autocomplete، role=alert، المعالم (main/nav/aria-current)، عناوين h1، حالات aria-pressed
   (ب) إدارة التركيز: ModalFocus (حبس Tab، Escape، إعادة التركيز) بعناصر وهمية، ونافذة المكافأة (role/aria/Escape لا ينشر)
   (ج) نوافذ الحوار الداخلية بدل confirm/prompt: HTML، التراجع التلقائي إلى confirm/prompt الأصلية عند غياب DOM (فتبقى الاختبارات القديمة صحيحة)، عدم التكديس، الإغلاق قبل التنفيذ
   (د) اقتراحات السعر/الكيلومترات، منتقي الصور (alt/aria-label/fallback/تركيز)، التباين WCAG لألوان الحالة، قواعد CSS للتركيز والحقول على الهاتف
   (هـ) الفلاتر ديناميكية: الماركات/الموديلات/السنوات من البيانات الفعلية فقط، ولا قوائم ثابتة في الشيفرة، ولا بيانات جديدة في هذا الجزء. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 260)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const jsFiles = d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => d + '/' + f);
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => { E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, textContent: '' }); E.els[k].style = E.els[k].style || {}; });
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J, setF };
}
const html = (x, route, param) => { x.R(param === undefined ? `go('${route}')` : `go('${route}', ${JSON.stringify(param)})`); return x.E.screen(); };
/** عنصر DOM وهمي قابل للتركيز لاختبار ModalFocus بلا متصفح */
function fakeDoc(E) {
  const doc = E.ctx.document; doc.activeElement = null; doc.contains = el => !el || !el._detached;
  const mkEl = (name, extra) => Object.assign({ name, disabled: false, _detached: false, getClientRects() { return [1]; }, focus() { doc.activeElement = this; }, attrs: {}, setAttribute(k, v) { this.attrs[k] = v; }, getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; } }, extra || {});
  return { doc, mkEl };
}
const key = (k, o) => Object.assign({ key: k, prevented: false, stopped: false, preventDefault() { this.prevented = true; }, stopPropagation() { this.stopped = true; } }, o || {});

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) النماذج: label/required/inputmode/autocomplete ======================= */
  console.log('\n--- A) إمكانية الوصول في النماذج ---');
  const formScreens = async () => {
    const u = mk('user'), d = mk('dealer1'), g = mk(null);
    const mid = u.J('getMemberCarsByOwner(SessionService.getCurrentUser().id)[0].id'), sid = d.J('getMyShowroomCars()[0].id');
    return { login: html(g, 'login'), register: html(g, 'register'), addMember: html(u, 'addMemberCar'), editMember: html(u, 'editMemberCar', mid), addShowroom: html(d, 'addShowroomCar'), editShowroom: html(d, 'editShowroomCar', sid) };
  };
  const FS = await formScreens();
  const controlsOf = h => [...h.matchAll(/<(input|select|textarea)\b[^>]*>/g)].map(m => m[0]).filter(tag => !/type="(hidden|radio|checkbox|file)"/.test(tag));
  await tc('A1) كل حقل (input/select/textarea) في الشاشات الست له <label for> مطابق لمعرّفه (placeholder ليس بديلًا عن label) — لا حقل بلا اسم', async () => {
    const bad = []; Object.entries(FS).forEach(([n, h]) => controlsOf(h).forEach(tag => { const id = (tag.match(/\sid="([^"]+)"/) || [])[1]; if (!id) bad.push(n + ':no-id'); else if (!h.includes(`<label for="${id}"`)) bad.push(n + ':' + id); })); return bad.length === 0 || bad; });
  await tc('A2) كل <label for> يشير إلى حقل موجود فعلًا في الشاشة نفسها (لا for يتيم)، ولا معرّف مكرر', async () => {
    const bad = []; Object.entries(FS).forEach(([n, h]) => { const ids = [...h.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]); [...h.matchAll(/<label for="([^"]+)"/g)].forEach(m => { if (!ids.includes(m[1])) bad.push(n + ':' + m[1]); }); if (new Set(ids).size !== ids.length) bad.push(n + ':dup-id'); }); return bad.length === 0 || bad; });
  await tc('A3) الحقول الإلزامية (وسم * في النص) مُعلَنة aria-required="true" (حقول النص لا القوائم: القائمة تحمل قيمة دائمًا)', async () => {
    const bad = []; ['addMember', 'editMember', 'addShowroom', 'editShowroom'].forEach(n => { const h = FS[n]; [...h.matchAll(/<label for="([^"]+)">([^<]*)<\/label>/g)].forEach(m => { const star = /\*\s*$/.test(m[2]); const tag = (h.match(new RegExp(`<(input|select|textarea)\\b[^>]*\\sid="${m[1]}"[^>]*>`)) || [''])[0]; const isSel = /^<select/.test(tag); if (star && !isSel && !/aria-required="true"/.test(tag)) bad.push(n + ':' + m[1]); if (star && isSel && /aria-required/.test(tag)) bad.push(n + ':select-' + m[1]); if (!star && /aria-required/.test(tag)) bad.push(n + ':extra-' + m[1]); }); }); return bad.length === 0 || bad; });
  await tc('A4) لوحة مفاتيح الهاتف مناسبة: السنة/السعر/الكيلومترات numeric، والهاتف/الواتساب tel (+autocomplete=tel)، والبريد email؛ التسجيل: name/tel/email/new-password؛ الدخول: username/current-password', async () => {
    const tag = (n, id) => (FS[n].match(new RegExp(`<(?:input|textarea)\\b[^>]*\\sid="${id}"[^>]*>`)) || [''])[0]; const bad = [];
    [['addMember', 'mc'], ['editMember', 'mc'], ['addShowroom', 'sc'], ['editShowroom', 'sc']].forEach(([n, p]) => { ['Year', 'Price', 'Mileage'].forEach(f => { if (!/inputmode="numeric"/.test(tag(n, p + f))) bad.push(n + p + f); }); });
    ['addMember', 'editMember'].forEach(n => ['mcPhone', 'mcWhatsapp'].forEach(id => { const g = tag(n, id); if (!/inputmode="tel"/.test(g) || !/autocomplete="tel"/.test(g)) bad.push(n + id); }));
    const r = id => tag('register', id); if (!/autocomplete="name"/.test(r('regName')) || !/inputmode="tel"/.test(r('regPhone')) || !/autocomplete="tel"/.test(r('regPhone')) || !/inputmode="email"/.test(r('regEmail')) || !/autocomplete="email"/.test(r('regEmail')) || !/autocomplete="new-password"/.test(r('regPassword')) || !/autocomplete="new-password"/.test(r('regConfirm'))) bad.push('register');
    if (!/autocomplete="username"/.test(tag('login', 'loginIdentifier')) || !/autocomplete="current-password"/.test(tag('login', 'loginPassword'))) bad.push('login'); return bad.length === 0 || bad; });
  await tc('A5) لا سمة مكررة داخل أي وسم حقل (autocomplete/inputmode/aria-required/id) في الشاشات الست', async () => {
    const bad = []; Object.entries(FS).forEach(([n, h]) => [...h.matchAll(/<(?:input|select|textarea)\b[^>]*>/g)].forEach(m => ['autocomplete', 'inputmode', 'aria-required', 'id', 'type'].forEach(a => { if ((m[0].match(new RegExp('\\s' + a + '="', 'g')) || []).length > 1) bad.push(n + ':' + a); }))); return bad.length === 0 || bad; });
  await tc('A6) رسائل الخطأ في النماذج role="alert" (تُقرأ عند ظهورها)، وملاحظة الدخول role="status"، وأخطاء المنتقي/خطأ الإعلان كذلك', async () => {
    const miss = []; Object.entries(FS).forEach(([n, h]) => [...h.matchAll(/<div[^>]*class="form-error"[^>]*>/g)].forEach(m => { if (!/role="alert"/.test(m[0])) miss.push(n); })); const note = /<div id="loginNote"[^>]*role="status"/.test(FS.login);
    return (miss.length === 0 && note && (FS.addMember.match(/class="form-error"/g) || []).length >= 2) || { miss, note }; });
  await tc('A7) مجموعتا الصور ونوع الحساب مسمّاتان: role=group/radiogroup مع aria-labelledby يشير إلى عنوان موجود', async () => {
    const chk = (h, role) => { const m = h.match(new RegExp(`role="${role}" aria-labelledby="([^"]+)"`)); return !!m && h.includes(`id="${m[1]}"`); };
    return (chk(FS.addMember, 'group') && chk(FS.editMember, 'group') && chk(FS.addShowroom, 'group') && chk(FS.editShowroom, 'group') && chk(FS.register, 'radiogroup')) || 'groups'; });
  await tc('A8) _setMsg: رسالة خطأ ظاهرة ← ينتقل إليها التركيز ويُمرَّر إليها (tabindex=-1)، ورسالة فارغة (مسح) لا تسرق التركيز', async () => {
    const x = mk(null); const calls = []; x.E.els.loginError = { style: {}, textContent: '', attrs: {}, setAttribute(k, v) { this.attrs[k] = v; calls.push('attr:' + k); }, scrollIntoView() { calls.push('scroll'); }, focus() { calls.push('focus'); } };
    x.R(`_setMsg('loginError', 'بيانات خاطئة')`); const shown = calls.slice(); calls.length = 0; x.R(`_setMsg('loginError', '')`);
    return (shown.includes('focus') && shown.includes('scroll') && x.E.els.loginError.attrs.tabindex === '-1' && x.E.els.loginError.style.display === 'none' && calls.length === 0) || { shown, calls }; });

  /* ======================= B) المعالم والعناوين وحالات aria ======================= */
  console.log('\n--- B) المعالم والعناوين وحالات ARIA ---');
  await tc('B1) index.html: main للمحتوى (قابل للتركيز برمجيًا)، nav بتسمية للتنقل السفلي، ومضيف نوافذ الحوار #dialogRoot، وlang=ar dir=rtl', async () => {
    const h = read('index.html'); return (/<main id="screen" tabindex="-1">/.test(h) && /<nav class="bottomnav" id="bottomnav" aria-label="التنقل الرئيسي">/.test(h) && /<div id="dialogRoot"><\/div>/.test(h) && /<html lang="ar" dir="rtl">/.test(h) && /role="status"/.test(h)) || 'index'; });
  await tc('B2) التنقل السفلي: العنصر النشط وحده aria-current="page"، والأيقونات aria-hidden، وسمات الصف الواحد القديمة محفوظة (class ثم onclick)', async () => {
    const g = mk(null); html(g, 'cars'); const nav = g.E.els.bottomnav.innerHTML; const cur = [...nav.matchAll(/aria-current="page"/g)].length;
    return (cur === 1 && /navbtn active" onclick="go\('cars'\)" aria-current="page"/.test(nav) && (nav.match(/class="ic" aria-hidden="true"/g) || []).length === 5) || nav.slice(0, 200); });
  await tc('B3) زر المفضلة: aria-label يتبع الحالة وaria-pressed يتبدّل (ضيف: غير مضغوط، عضو بعد الإضافة: مضغوط)', async () => {
    const u = mk('user'); const id = u.J('getVisibleCars()[0].id'); const before = html(u, 'cars'); u.R(`toggleFavorite(${id})`); const after = html(u, 'cars');
    return (/aria-label="إضافة إلى المفضلة" aria-pressed="false"/.test(before) && /aria-label="إزالة من المفضلة" aria-pressed="true"/.test(after)) || 'fav'; });
  await tc('B4) شاشات «غير موجود/غير متاح» بعنوان مستوى 1 لقارئ الشاشة (role=heading aria-level=1)، وتفاصيل مستخدم الإدارة h1 لا h2، وكل شاشة رئيسية فيها عنوان h1 واحد', async () => {
    const g = mk(null), a = mk('admin'); const miss = ['carDetails', 'memberCarDetails', 'showroomDetails'].filter(r => !/role="heading" aria-level="1"/.test(html(g, r, 99999)));
    const au = html(a, 'adminUserDetails', a.J('adminGetAllUsers()[1].id')); const onlyOne = ['home', 'cars', 'memberCars', 'showrooms', 'favorites', 'map'].filter(r => (html(g, r).match(/<h1\b/g) || []).length !== 1);
    return (miss.length === 0 && /<h1>👤/.test(au) && !/<h2>👤/.test(au) && onlyOne.length === 0) || { miss, onlyOne }; });
  await tc('B5) تبويبات الإدارة (الأعضاء/المستخدمون): aria-pressed يطابق التبويب النشط، وتسمية «مباعة» موحّدة مع شارة الحالة وقائمة الاختيار (لا «مباع» هنا و«مباعة» هناك)', async () => {
    const a = mk('admin'); const h = html(a, 'adminMemberCars'); const u = html(a, 'adminUsers'); const on = s => (s.match(/class="active" aria-pressed="true"/g) || []).length, off = s => (s.match(/aria-pressed="false"/g) || []).length;
    return (on(h) === 1 && off(h) === 5 && on(u) === 1 && off(u) === 3 && /aria-pressed="false"[^>]*>مباعة</.test(h) && a.J('MEMBER_CAR_STATUS_LABEL.sold') === a.J('CAR_STATUS_LABEL.sold')) || 'tabs'; });
  await tc('B6) عناصر الإدارة القابلة للنقر (بطاقات الإحصاء وقائمة الإدارة وصفوف المستخدمين وبطاقات إعلانات الأعضاء) role=button وtabindex=0 فتصل إليها لوحة المفاتيح', async () => {
    const a = mk('admin'); const d = html(a, 'adminDashboard'), us = html(a, 'adminUsers'), mc = html(a, 'adminMemberCars');
    const dOk = (d.match(/class="stat-card" role="button" tabindex="0"/g) || []).length >= 1 && (d.match(/class="admin-menu-item" role="button" tabindex="0"/g) || []).length === 5;
    return (dOk && /class="ad-row" role="button" tabindex="0"/.test(us) && /class="card car-card" role="button" tabindex="0"/.test(mc)) || 'roles'; });
  await tc('B7) activateRoleButton: Enter وSpace على role=button غير أصلي ينفّذان click ويمنعان التمرير؛ الأزرار الأصلية والمفاتيح الأخرى لا تُعالَج', async () => {
    const x = mk(null); const mkTarget = (role, native) => { const el = { clicks: 0, getAttribute: k => k === 'role' ? role : null, matches: () => native, click() { this.clicks++; } }; return el; };
    const run = (k, tg) => { const ev = key(k, { target: tg }); const r = x.J.length ? null : null; return { ev, handled: x.E.ctx.activateRoleButton(ev) }; };
    const a = mkTarget('button', false), b = mkTarget('button', false), c = mkTarget('button', true), d = mkTarget(null, false), e = mkTarget('button', false);
    const ra = run('Enter', a), rb = run(' ', b), rc = run('Enter', c), rd = run('Enter', d), re = run('a', e);
    return (a.clicks === 1 && ra.ev.prevented && b.clicks === 1 && rb.ev.prevented && c.clicks === 0 && !rc.handled && d.clicks === 0 && e.clicks === 0 && !re.handled) || { a: a.clicks, b: b.clicks, c: c.clicks }; });

  /* ======================= C) إدارة التركيز (ModalFocus) ======================= */
  console.log('\n--- C) إدارة التركيز في النوافذ ---');
  const modalRig = () => {
    const x = mk(null); const { doc, mkEl } = fakeDoc(x.E); const opener = mkEl('opener'); const b1 = mkEl('b1'), b2 = mkEl('b2'), b3 = mkEl('b3'); const outside = mkEl('outside'); const box = mkEl('box'); let items = [b1, b2, b3];
    const overlay = mkEl('overlay', { querySelectorAll: () => items, querySelector: sel => sel === '.modal-box' ? box : (sel === '#b2' ? b2 : null) }); x.E.els.screen.focus = function () { doc.activeElement = this; }; doc.activeElement = opener;
    return { x, doc, opener, b1, b2, b3, outside, box, overlay, setItems: v => { items = v; } };
  };
  await tc('C1) activate: التركيز يدخل النافذة (العنصر المطلوب أولًا وإلا أول عنصر وإلا النافذة نفسها) والصندوق tabindex=-1', async () => {
    const r = modalRig(); r.x.R('ModalFocus.activate'); const ok1 = r.x.R('ModalFocus').activate(r.overlay, { initial: '#b2' }); const f1 = r.doc.activeElement === r.b2; r.x.R('ModalFocus').deactivate();
    r.doc.activeElement = r.opener; r.x.R('ModalFocus').activate(r.overlay, {}); const f2 = r.doc.activeElement === r.b1; r.x.R('ModalFocus').deactivate();
    r.setItems([]); r.doc.activeElement = r.opener; r.x.R('ModalFocus').activate(r.overlay, {}); const f3 = r.doc.activeElement === r.box; return (ok1 && f1 && f2 && f3 && r.box.attrs.tabindex === '-1') || { f1, f2, f3 }; });
  await tc('C2) حبس Tab: من آخر عنصر ← الأول، Shift+Tab من الأول ← الأخير، ومن خارج النافذة ← داخلها؛ يُمنع السلوك الافتراضي فقط عند الالتفاف', async () => {
    const r = modalRig(); const M = r.x.R('ModalFocus'); M.activate(r.overlay, {});
    r.doc.activeElement = r.b3; const e1 = key('Tab'); M.onKey(e1); const a1 = r.doc.activeElement === r.b1 && e1.prevented;
    r.doc.activeElement = r.b1; const e2 = key('Tab', { shiftKey: true }); M.onKey(e2); const a2 = r.doc.activeElement === r.b3 && e2.prevented;
    r.doc.activeElement = r.outside; const e3 = key('Tab'); M.onKey(e3); const a3 = r.doc.activeElement === r.b1 && e3.prevented;
    r.doc.activeElement = r.b1; const e4 = key('Tab'); M.onKey(e4); const a4 = !e4.prevented;     // وسط القائمة: المتصفح يتولى
    r.setItems([]); const e5 = key('Tab'); M.onKey(e5); const a5 = r.doc.activeElement === r.box && e5.prevented;
    return (a1 && a2 && a3 && a4 && a5) || { a1, a2, a3, a4, a5 }; });
  await tc('C3) Escape: يستدعي onEscape مرة واحدة ويمنع الحدث؛ بلا onEscape لا شيء؛ وبعد deactivate/reset لا يعمل أي معالج قديم', async () => {
    const r = modalRig(); const M = r.x.R('ModalFocus'); let n = 0; M.activate(r.overlay, { onEscape: () => n++ }); const e = key('Escape'); M.onKey(e); const a = n === 1 && e.prevented && e.stopped;
    M.deactivate(); const e2 = key('Escape'); M.onKey(e2); const b = n === 1 && !e2.prevented;
    M.activate(r.overlay, {}); const e3 = key('Escape'); M.onKey(e3); const c = !e3.prevented; M.reset(); M.onKey(key('Escape')); return (a && b && c && !M.isActive()) || { a, b, c }; });
  await tc('C4) deactivate يعيد التركيز إلى العنصر الذي فتح النافذة؛ وإن اختفى (تنقّل) يذهب التركيز إلى محتوى الشاشة؛ refocus({box}) يركّز النافذة نفسها (لا زرًا قابلًا للضغط)', async () => {
    const r = modalRig(); const M = r.x.R('ModalFocus'); M.activate(r.overlay, {}); r.doc.activeElement = r.b2; M.deactivate(); const a = r.doc.activeElement === r.opener;
    r.doc.activeElement = r.opener; M.activate(r.overlay, {}); r.opener._detached = true; M.deactivate(); const b = r.doc.activeElement === r.x.E.els.screen;
    r.doc.activeElement = r.outside; M.activate(r.overlay, {}); M.refocus({ box: true }); const c = r.doc.activeElement === r.box; M.refocus(); const d = r.doc.activeElement === r.b1; return (a && b && c && d) || { a, b, c, d }; });
  await tc('C5) مستمع keydown واحد فقط مهما تكرر فتح النوافذ (لا تراكم مستمعين)، وlistener الأدوار الأصلية مرة واحدة عند التحميل', async () => {
    const r = modalRig(); let n = 0; r.doc.addEventListener = (type) => { if (type === 'keydown') n++; }; const M = r.x.R('ModalFocus'); for (let i = 0; i < 6; i++) { M.activate(r.overlay, {}); M.deactivate(); } return n === 1 || n; });

  /* ======================= D) نافذة المكافأة ======================= */
  console.log('\n--- D) نافذة إعلان المكافأة (Rewarded Ad UX) ---');
  await tc('D1) markup: role=dialog + aria-modal + aria-labelledby يشير لعنوان موجود؛ عناوين الخطوات الثلاث بمعرّفات؛ العدّاد role=timer بلا بثّ كل ثانية؛ خطوة الاكتمال role=status', async () => {
    const u = mk('user'); const h = html(u, 'addMemberCar'); const lab = (h.match(/id="rewardAdBox"[^>]*aria-labelledby="([^"]+)"/) || [])[1];
    return (/id="rewardAdBox" class="modal-box" role="dialog" aria-modal="true"/.test(h) && lab === 'rewardAdTitleIntro' && ['rewardAdTitleIntro', 'rewardAdTitlePlaying', 'rewardAdTitleDone'].every(i => h.includes(`id="${i}"`)) && /id="rewardAdCountdown"[^>]*role="timer" aria-live="off"/.test(h) && /id="rewardAdStepDone" role="status"/.test(h)) || 'modal'; });
  const rewardRig = () => {
    const u = mk('user'); html(u, 'addMemberCar'); u.setF({ mcBrand: 'Toyota', mcModel: 'Camry', mcYear: '2021', mcPrice: '35000000', mcMileage: '', mcColor: '', mcLocation: '', mcPhone: '07701234567', mcWhatsapp: '', mcDescription: '', mcCurrency: 'IQD', mcTransmission: 'أوتوماتيك', mcFuelType: 'بنزين' });
    ['rewardAdOverlay', 'rewardAdBox', 'rewardAdStepIntro', 'rewardAdStepPlaying', 'rewardAdStepDone', 'rewardAdCountdown', 'rewardAdError'].forEach(id => { u.E.els[id] = u.E.els[id] || { style: {}, textContent: '' }; u.E.els[id].style = u.E.els[id].style || {}; });
    u.E.els.rewardAdBox.attrs = {}; u.E.els.rewardAdBox.setAttribute = function (k, v) { this.attrs[k] = v; }; return u; };
  await tc('D2) النشر ← نافذة المكافأة: لا سجل قبل الاكتمال، والعنوان aria-labelledby يتبع الخطوة (Intro → Playing → Done)', async () => {
    const u = rewardRig(); const n0 = u.J('MemberCarsRepository.getAll().length'); u.R('handleAddMemberCarSubmit()'); const open = u.E.els.rewardAdOverlay.style.display === 'flex' && u.J('MemberCarsRepository.getAll().length') === n0 && u.E.els.rewardAdBox.attrs['aria-labelledby'] === 'rewardAdTitleIntro' && u.R('ModalFocus.isActive()');
    u.R('handleWatchRewardAd()'); const playing = u.E.els.rewardAdBox.attrs['aria-labelledby'] === 'rewardAdTitlePlaying' && u.E.els.rewardAdStepPlaying.style.display === 'block'; u.E.tick(8);
    return (open && playing && u.E.els.rewardAdBox.attrs['aria-labelledby'] === 'rewardAdTitleDone' && u.J('MemberCarsRepository.getAll().length') === n0 + 1) || { open, playing }; });
  await tc('D3) Escape أثناء المقدّمة أو العدّ التنازلي = إلغاء: لا نشر، يُوقف العدّاد، والمسودة تُهمَل؛ وبعد الإلغاء Escape لا أثر له', async () => {
    const u = rewardRig(); const n0 = u.J('MemberCarsRepository.getAll().length'); u.R('handleAddMemberCarSubmit()'); u.R('ModalFocus').onKey(key('Escape')); const a = u.E.els.rewardAdOverlay.style.display === 'none' && u.J('MemberCarsRepository.getAll().length') === n0 && !u.R('ModalFocus.isActive()');
    u.R('handleAddMemberCarSubmit()'); u.R('handleWatchRewardAd()'); u.R('ModalFocus').onKey(key('Escape')); u.E.tick(10); const b = u.E.els.rewardAdOverlay.style.display === 'none' && u.J('MemberCarsRepository.getAll().length') === n0 && u.R('_rewardCountdownTimer === null');
    return (a && b) || { a, b }; });
  await tc('D4) Escape بعد اكتمال الإعلان (خطوة «اكتمل») لا يلغي النشر الجاري، والنشر يحدث مرة واحدة بالضبط حتى مع نقرات «مشاهدة» متكررة', async () => {
    const u = rewardRig(); const n0 = u.J('MemberCarsRepository.getAll().length'); u.R('handleAddMemberCarSubmit()'); u.R('handleWatchRewardAd()'); u.R('handleWatchRewardAd()'); u.R('handleWatchRewardAd()'); u.E.tick(8);
    const done = u.E.els.rewardAdStepDone.style.display === 'block'; u.R('ModalFocus').onKey(key('Escape')); u.E.tick(3);
    return (done && u.E.els.rewardAdOverlay.style.display === 'flex' && u.J('MemberCarsRepository.getAll().length') === n0 + 1) || { done, n: u.J('MemberCarsRepository.getAll().length') - n0 }; });
  await tc('D5) تجربة الإعلان: سبب ظهوره مذكور بوضوح (شاهد إعلانًا قصيرًا لإكمال النشر)، «إلغاء» في كل خطوة قابلة للإلغاء، ولا ادعاء بمدة ثابتة للإعلان الحقيقي (لا «8 ثوانٍ»/«10 ثوانٍ» في النص)، والإعلان موسوم تجريبيًا', async () => {
    const u = mk('user'); const h = html(u, 'addMemberCar'); const box = h.slice(h.indexOf('id="rewardAdBox"'));
    return (/شاهد إعلانًا قصيرًا لإكمال النشر/.test(box) && (box.match(/handleCancelRewardAd\(\)/g) || []).length === 2 && !/\d+\s*(ثوان|ثانية)/.test(box.replace(/id="rewardAdCountdown"[^>]*>[^<]*</, '')) && /إعلان مكافأ تجريبي — بيئة تطوير فقط/.test(box)) || 'copy'; });
  await tc('D6) الإعلانات الأخرى مجرد أماكن محجوزة: .ad-slot مخفي (display:none) فلا يقرؤه قارئ الشاشة، وmaybeShowInterstitial لا تعرض شيئًا، ولا AdMob حقيقي', async () => {
    const css = read('theme/theme.css'); const m = css.match(/\.ad-slot\{[^}]*\}/); const x = mk(null);
    return (m && /display:none/.test(m[0]) && x.R('maybeShowInterstitial("home","cars")') === undefined && !/admob|googletag|adsbygoogle|pagead/i.test(jsFiles('components').concat(jsFiles('services'), jsFiles('screens'), jsFiles('navigation'), ['app.js']).map(f => strip(read(f))).join('\n'))) || 'ads'; });

  /* ======================= E) نوافذ الحوار الداخلية بدل confirm/prompt ======================= */
  console.log('\n--- E) نوافذ الحوار (confirm/prompt) ---');
  await tc('E1) AppDialog.html: التأكيد المدمّر role=alertdialog، العادي dialog؛ aria-modal وaria-labelledby/describedby يشيران لعناصر موجودة؛ النص المُدخَل يُهرَّب (XSS) لا يُحقن', async () => {
    const x = mk(null); const D = x.R('AppDialog'); const evil = `"><img src=x onerror=alert(1)>`;
    const c = D.html({ kind: 'confirm', title: evil, message: evil, confirmLabel: evil, danger: true }, 1), n = D.html({ kind: 'confirm', title: 'عنوان', message: 'رسالة' }, 2);
    return (/role="alertdialog" aria-modal="true" aria-labelledby="dlgTitle1" aria-describedby="dlgMsg1"/.test(c) && c.includes('id="dlgTitle1"') && c.includes('id="dlgMsg1"') && /role="dialog" aria-modal="true"/.test(n) && !/<img src=x/.test(c) && !/onerror=alert/.test(c.replace(/&lt;img[^&]*&gt;|&quot;/g, ''))) || 'html'; });
  await tc('E2) خيارات الاختيار: الحالة الحالية aria-pressed=true وبقية الخيارات false، والقيمة/النص مهرَّبان، وهناك زر إلغاء؛ حقل النص: label مرتبط بالحقل وaria-required عند الإلزام ومنطقة خطأ role=alert', async () => {
    const x = mk(null); const D = x.R('AppDialog'); const ch = D.html({ kind: 'choose', title: 'ت', options: [{ value: 'available', label: 'متاحة للبيع' }, { value: 'sold', label: 'مباعة' }, { value: '"><b>', label: '<i>x</i>' }], current: 'sold' }, 3);
    const pr = D.html({ kind: 'prompt', title: 'رفض', label: 'سبب الرفض', required: true }, 4);
    return (/aria-pressed="false" data-dlg-value="available"/.test(ch) && /aria-pressed="true" data-dlg-value="sold"/.test(ch) && !/<b>/.test(ch) && !/<i>x/.test(ch) && /data-dlg="cancel"/.test(ch) && /<label for="dlgInput4">سبب الرفض<\/label>/.test(pr) && /id="dlgInput4"[^>]*aria-required="true"/.test(pr) && /id="dlgError4" class="form-error" role="alert"/.test(pr)) || 'choose/prompt'; });
  await tc('E3) بلا واجهة DOM (اختبارات Node): askConfirm/askChoice/askText تعود لـconfirm()/prompt() الأصلية بالنص والسلوك السابقين حرفيًا (الاختبارات القديمة تبقى صحيحة)', async () => {
    const x = mk(null); const log = []; x.E.ctx.confirm = m => { log.push(['c', m]); return log.length % 2 === 1; }; x.E.ctx.prompt = (m, d) => { log.push(['p', m, d]); return ' sold '; };
    x.E.ctx.__r = []; x.R(`askConfirm({ title: 'T', message: 'هل أنت متأكد؟' }, () => __r.push('yes'), () => __r.push('no'))`); x.R(`askConfirm({ title: 'T', message: 'هل أنت متأكد؟' }, () => __r.push('yes'), () => __r.push('no'))`);
    x.R(`askChoice({ title: 'ح', current: 'active', nativeMessage: 'أدخل الحالة:', nativeDefault: 'active', options: [] }, v => __r.push('pick:' + v))`); x.R(`askText({ title: 'س', nativeMessage: 'سبب الرفض:' }, v => __r.push('txt:' + v))`);
    x.E.ctx.prompt = () => null; x.R(`askText({ title: 'س', nativeMessage: 'x' }, v => __r.push('txt2:' + v), () => __r.push('cancel-text'))`); x.E.ctx.prompt = () => ''; x.R(`askChoice({ title: 'ح', nativeMessage: 'y', options: [] }, v => __r.push('pick2:' + v), () => __r.push('cancel-choice'))`);
    const r = x.J('__r'); return (JSON.stringify(r) === JSON.stringify(['yes', 'no', 'pick:sold', 'txt:sold', 'cancel-text', 'cancel-choice']) && log[0][1] === 'هل أنت متأكد؟' && log[2][1] === 'أدخل الحالة:' && log[2][2] === 'active' && log[3][1] === 'سبب الرفض:' && log[3][2] === undefined) || { r, log: log.slice(0, 4) }; });
  const dlgRig = () => {   // مضيف DOM وهمي كافٍ لتفعيل المسار المخصص
    const x = mk(null); const { doc, mkEl } = fakeDoc(x.E); const opener = mkEl('opener'); doc.activeElement = opener; x.E.els.screen.focus = function () { doc.activeElement = this; };
    const input = mkEl('input', { value: '' }), err = mkEl('err', { style: {}, textContent: '' }); const btn = mkEl('btn'); const ov = mkEl('ov', { querySelectorAll: () => [btn], querySelector: s => s === '.modal-box' ? mkEl('box') : null });
    const host = { innerHTML: '', querySelector: s => s === 'input' ? input : s === '.form-error' ? err : s === '.modal-overlay' ? ov : null, firstElementChild: ov }; x.E.els.dialogRoot = host; return { x, host, input, err, opener, doc, D: x.R('AppDialog') };
  };
  await tc('E4) المسار المخصص: askConfirm يفتح النافذة (لا confirm الأصلية)، النقرة الثانية لا تكدّس نافذة ثانية ولا تنفّذ شيئًا، و«تأكيد» يغلق قبل تنفيذ المعالج ثم ينفّذه مرة واحدة', async () => {
    const r = dlgRig(); let nativeCalled = 0; r.x.E.ctx.confirm = () => { nativeCalled++; return true; }; const log = [];
    r.x.E.ctx.__cb = { yes: () => log.push('yes@' + (r.host.innerHTML === '' ? 'closed' : 'open')), no: () => log.push('no') };
    r.x.R(`askConfirm({ title: 'حذف', message: 'م', danger: true }, __cb.yes, __cb.no)`); const opened = r.host.innerHTML.includes('dlg-box') && r.D.isOpen() && nativeCalled === 0; const html1 = r.host.innerHTML;
    r.x.R(`askConfirm({ title: 'حذف آخر', message: 'م', danger: true }, __cb.yes, __cb.no)`); const noStack = r.host.innerHTML === html1;
    r.D.ok(); r.D.ok(); return (opened && noStack && JSON.stringify(log) === '["yes@closed"]' && !r.D.isOpen() && r.doc.activeElement === r.opener) || { opened, noStack, log }; });
  await tc('E5) الإلغاء: زر «إلغاء» وEscape والنقر على الخلفية فقط (لا داخل الصندوق) تنفّذ onNo مرة واحدة بلا تنفيذ onYes، وتعيد التركيز لما قبلها؛ والتنقّل (dismiss) يغلقها بلا أي معالج', async () => {
    const r = dlgRig(); const log = []; r.x.E.ctx.__cb = { yes: () => log.push('yes'), no: () => log.push('no') }; const open = () => r.x.R(`askConfirm({ title: 'ت', message: 'م' }, __cb.yes, __cb.no)`);
    const target = (attr, val, self) => { const el = { getAttribute: k => k === attr ? val : null }; const t = { closest: () => el, __self: el }; return self ? { target: Object.assign(el, { closest: () => el }) } : { target: t }; };
    open(); r.D.cancel(); open(); r.x.R('ModalFocus').onKey(key('Escape'));
    open(); r.D.click({ target: { closest: () => ({ getAttribute: k => k === 'data-dlg' ? 'overlay' : null }) } }); const stillOpenInside = r.D.isOpen();      // t !== el: نقرة داخل الصندوق
    const ovEl = { getAttribute: k => k === 'data-dlg' ? 'overlay' : null }; ovEl.closest = () => ovEl; r.D.click({ target: ovEl }); const closedByBackdrop = !r.D.isOpen();
    open(); r.D.dismiss(); const afterDismiss = !r.D.isOpen() && r.host.innerHTML === '';
    return (JSON.stringify(log) === '["no","no","no"]' && stillOpenInside && closedByBackdrop && afterDismiss && !log.includes('yes')) || { log, stillOpenInside, closedByBackdrop, afterDismiss }; });
  await tc('E6) نافذة الاختيار: النقر على خيار ينفّذ onPick بقيمته ويغلق؛ حقل النص: الفارغ الإلزامي لا يغلق (رسالة خطأ + تركيز + aria-invalid)، والنص يُقصّ trim، وEnter في الحقل يؤكد', async () => {
    const r = dlgRig(); const got = []; r.x.E.ctx.__cb = { pick: v => got.push('pick:' + v), txt: v => got.push('txt:' + v) };
    r.x.R(`askChoice({ title: 'ح', options: [{ value: 'sold', label: 'مباعة' }], current: 'sold' }, __cb.pick)`); const el = { getAttribute: k => k === 'data-dlg-value' ? 'sold' : null }; r.D.click({ target: { closest: () => el } });
    r.input.value = '   '; r.x.R(`askText({ title: 'ر', label: 'السبب', required: true }, __cb.txt)`); r.D.ok(); const blocked = r.D.isOpen() && r.err.style.display === 'block' && r.input.attrs['aria-invalid'] === 'true' && r.doc.activeElement === r.input && got.length === 1;
    r.input.value = '  صور غير واضحة  '; r.D.ok(); return (JSON.stringify(got) === '["pick:sold","txt:صور غير واضحة"]' && blocked && !r.D.isOpen() && /onkeydown="if\(event\.key==='Enter'\)\{event\.preventDefault\(\);AppDialog\.ok\(\)\}"/.test(r.D.html({ kind: 'prompt', title: 'x' }, 9))) || { got, blocked }; });
  await tc('E7) معالجات الإدارة والحذف تستخدم الحوار المخصص لا confirm/prompt الأصلية؛ الصلاحية بقيت في الخدمات: خيارات حالة سيارة المعرض «متاحة للبيع/مباعة» فقط (لا reserved)، وغير المدير يُرفض حتى لو استُدعي المعالج', async () => {
    const a = mk('admin'); const { mkEl, doc } = fakeDoc(a.E); a.E.els.dialogRoot = { innerHTML: '', querySelector: s => s === '.modal-overlay' ? mkEl('ov', { querySelectorAll: () => [], querySelector: () => null }) : null };
    let native = 0; a.E.ctx.confirm = () => { native++; return true; }; a.E.ctx.prompt = () => { native++; return null; };
    const car = a.J('getCars()[0]'); a.R(`handleAdminShowroomCarStatusChange(${car.id})`); const h = a.E.els.dialogRoot.innerHTML; a.R('AppDialog.cancel()');
    const opts = [...h.matchAll(/data-dlg-value="([^"]+)"/g)].map(m => m[1]);
    a.R(`handleRejectMemberCar(${a.J('getMemberCars()[0].id')})`); const pr = a.E.els.dialogRoot.innerHTML.includes('رفض الإعلان'); a.R('AppDialog.cancel()');
    a.R(`handleMemberCarStatusChange(${a.J('getMemberCars()[0].id')})`); const mopts = [...a.E.els.dialogRoot.innerHTML.matchAll(/data-dlg-value="([^"]+)"/g)].map(m => m[1]); a.R('AppDialog.cancel()');
    const u = mk('user'); const before = u.J('getCars()[0].status'); u.R(`setShowroomCarStatus(${car.id}, 'sold')`); const denied = u.J('getCars()[0].status') === before;
    return (native === 0 && JSON.stringify(opts) === '["available","sold"]' && !opts.includes('reserved') && pr && JSON.stringify(mopts) === '["pending","active","sold","rejected","suspended"]' && denied) || { native, opts, pr, mopts, denied }; });
  await tc('E8) سلوك المسار الأصلي محفوظ: تغيير حالة إعلان العضو بـprompt (المالك: sold)، رفض بسبب مقصوص، تغيير حالة سيارة معرض (المدير)، وحذف بـconfirm — كلها كما كانت بلا واجهة DOM', async () => {
    const u = mk('user'); const me = u.J('SessionService.getCurrentUser().id'); const mine = u.J(`getMemberCarsByOwner(${me}).filter(c => c.status === 'active')[0].id`); u.E.ctx.prompt = () => ' sold '; u.R(`handleMemberCarStatusChange(${mine})`); const a1 = u.J(`getMemberCarById(${mine}).status`) === 'sold';
    u.E.ctx.prompt = () => ' suspended '; u.R(`handleMemberCarStatusChange(${mine})`); const a2 = u.J(`getMemberCarById(${mine}).status`) === 'sold';        // المالك لا يضع حالة إدارية (الخدمة ترفض)
    const a = mk('admin'); a.E.ctx.prompt = () => '  صور غير واضحة  '; const cid = a.J('getMemberCars().filter(c => c.status === "active")[0].id'); a.R(`handleRejectMemberCar(${cid})`); const b1 = a.J(`getMemberCarById(${cid}).status`) === 'rejected' && a.J(`getMemberCarById(${cid}).rejectionReason`) === 'صور غير واضحة';
    a.E.ctx.prompt = () => null; a.R(`handleSuspendMemberCarAdmin(${a.J('getMemberCars().filter(c => c.status === "active")[0].id')})`); const b2 = a.J('getMemberCars().filter(c => c.status === "suspended" && c.suspensionReason === "x").length') === 0;
    const sc = a.J('getCars()[0]'); a.E.ctx.prompt = () => 'sold'; a.R(`handleAdminShowroomCarStatusChange(${sc.id})`); const c1 = a.J('getCars()[0].status') === 'sold'; a.E.ctx.prompt = () => 'reserved'; a.R(`handleAdminShowroomCarStatusChange(${sc.id})`); const c2 = a.J('getCars()[0].status') === 'sold';
    return (a1 && a2 && b1 && b2 && c1 && c2) || { a1, a2, b1, b2, c1, c2 }; });
  await tc('E9) حذف سيارة المعرض (async): مع نافذة التأكيد المخصصة النقرة الثانية أثناء الانتظار لا تفتح نافذة ثانية، و«حذف» يحذف مرة واحدة، و«إلغاء» لا يحذف، والوعد يكتمل في الحالتين', async () => {
    const r = dlgRig(); const d = mk('dealer1'); const { mkEl, doc } = fakeDoc(d.E); const ov = mkEl('ov', { querySelectorAll: () => [], querySelector: () => null }); d.E.els.dialogRoot = { innerHTML: '', querySelector: s => s === '.modal-overlay' ? ov : null }; d.E.els.screen.focus = function () { doc.activeElement = this; };
    const id = d.J('getMyShowroomCars()[0].id'), n0 = d.J('getMyShowroomCars().length'); const p1 = d.R(`handleDeleteShowroomCar(${id})`); const p2 = d.R(`handleDeleteShowroomCar(${id})`); await new Promise(r => setTimeout.call ? setImmediate(r) : r());
    const one = d.R('AppDialog').isOpen() && (d.E.els.dialogRoot.innerHTML.match(/dlg-box/g) || []).length === 1; d.R('AppDialog').cancel(); await p1; await p2; const kept = d.J('getMyShowroomCars().length') === n0;
    const p3 = d.R(`handleDeleteShowroomCar(${id})`); await new Promise(r => setImmediate(r)); d.R('AppDialog').ok(); await p3; return (one && kept && d.J('getMyShowroomCars().length') === n0 - 1) || { one, kept, n: d.J('getMyShowroomCars().length') }; });
  await tc('E10) بعد كل انتقال: تُغلق نافذة حوار مفتوحة بلا تنفيذ معالجها، ويُنقل التركيز إلى main، ويتبع عنوان الصفحة h1 الشاشة (وإلا اسم التطبيق)', async () => {
    const r = dlgRig(); const log = []; r.x.E.ctx.__cb = { yes: () => log.push('yes'), no: () => log.push('no') }; r.x.R(`askConfirm({ title: 'ت', message: 'م' }, __cb.yes, __cb.no)`); const open = r.D.isOpen();
    let focused = 0; r.x.E.els.screen.focus = () => { focused++; }; r.x.E.ctx.document.querySelector = s => /h1/.test(s) ? { textContent: '  قائمة   السيارات ' } : null; r.x.R(`go('cars')`);
    const t1 = r.x.E.ctx.document.title; r.x.E.ctx.document.querySelector = () => null; r.x.R(`go('home')`); return (open && !r.D.isOpen() && log.length === 0 && focused >= 2 && t1 === 'قائمة السيارات — معارض النجف' && r.x.E.ctx.document.title === 'معارض النجف') || { open, log, focused, t1 }; });

  await tc('E11) التركيز الأول في الحوار: الحذف/الرفض المدمّر يبدأ على «إلغاء» (Enter العرضي لا يحذف)، التأكيد العادي على «تأكيد»، الاختيار على الخيار الحالي، وحقل النص على الحقل', async () => {
    const first = spec => { const r = dlgRig(); const asked = []; const ov = r.host.querySelector('.modal-overlay'); const orig = ov.querySelector; ov.querySelector = s => { asked.push(s); return orig(s); }; r.D.open(spec, () => {}, () => {}); r.D.cancel(); return asked.find(a => a !== '.modal-box'); };
    const a = first({ kind: 'confirm', title: 'ت', danger: true }), b = first({ kind: 'confirm', title: 'ت' }), c = first({ kind: 'choose', title: 'ت', options: [] }), d = first({ kind: 'prompt', title: 'ت' });
    return (a === '.dlg-cancel' && b === '.dlg-ok' && /aria-pressed="true"/.test(c) && d === 'input') || { a, b, c, d }; });
  await tc('E12) نافذة المكافأة: تكرار «مشاهدة الإعلان» (Enter/Space/نقر متكرر) يبدأ عدّادًا واحدًا فقط (setInterval مرة واحدة) بلا تسرّب مؤقتات', async () => {
    const u = rewardRig(); let n = 0; const orig = u.E.ctx.setInterval; u.E.ctx.setInterval = (...a) => { n++; return orig(...a); }; u.R('handleAddMemberCarSubmit()'); u.R('handleWatchRewardAd()'); u.R('handleWatchRewardAd()'); u.R('handleWatchRewardAd()');
    const once = n === 1; u.E.tick(10); return (once && u.R('_rewardCountdownTimer === null')) || { n }; });

  /* ======================= F) اقتراحات السعر/الكيلومترات ======================= */
  console.log('\n--- F) إمكانية الوصول في الاقتراحات ---');
  await tc('F1) لوحات الاقتراح: role=group بتسمية، مخفية افتراضيًا، كل اقتراح زر type=button بـaria-pressed وaria-label وصفي، و«إدخال مخصص» زر فعل (لا aria-pressed) بتسمية؛ والمفاتيح (Escape/Enter) تعالجها الشيفرة القائمة', async () => {
    const g = mk(null); const h = html(g, 'cars'); const panels = [...h.matchAll(/<div class="flt-sugg"[^>]*>/g)].map(m => m[0]); const opts = [...h.matchAll(/<button type="button" class="sugg-opt"[^>]*>/g)].map(m => m[0]); const custom = [...h.matchAll(/<button type="button" class="sugg-opt sugg-custom"[^>]*>/g)].map(m => m[0]);
    const fs = strip(read('components/filters.js'));
    return (panels.length >= 2 && panels.every(p => /role="group"/.test(p) && /aria-label="اقتراحات/.test(p) && /hidden/.test(p)) && opts.length >= 12 && opts.every(o => /aria-pressed="(true|false)"/.test(o) && /aria-label="اقتراح/.test(o)) && custom.length === panels.length && custom.every(c => /aria-label="إدخال/.test(c) && !/aria-pressed/.test(c)) && /Escape/.test(fs) && /closeFilterSuggestions/.test(fs)) || { panels: panels.length, opts: opts.length, custom: custom.length }; });
  await tc('F2) الحالة المختارة تتبدّل: تطبيق اقتراح يضبط aria-pressed=true لذلك الاقتراح وحده، وعملة الدولار تبدّل مجموعة الاقتراحات (رموز $) بلا محرك فلترة جديد (applyFilterPreset تستدعي معالج النطاق القائم)', async () => {
    const g = mk(null); html(g, 'cars'); const iqd = g.E.els.carsSuggPrice ? g.E.els.carsSuggPrice.innerHTML : '';
    const before = html(g, 'cars'); const m = before.match(/data-min="(\d+)" data-max="(\d+)" aria-pressed="false" aria-label="اقتراح [^"]*"[^>]*onclick="applyFilterPreset\('cars','Price','(\d+)','(\d+)',(\w+),event\)"/);
    if (!m) return 'no-preset-match';
    g.E.els.carsFilterMinPrice = { value: '', style: {} }; g.E.els.carsFilterMaxPrice = { value: '', style: {} }; g.R(`applyFilterPreset('cars','Price','${m[3]}','${m[4]}',${m[5]},{ preventDefault(){}, stopPropagation(){} })`); const after = html(g, 'cars');
    const pressed = (after.match(/aria-pressed="true"[^>]*aria-label="اقتراح السعر/g) || []).length; g.R(`carsFilters = CarFilters.normalize({ priceCurrency: 'USD' })`); const usd = html(g, 'cars');
    return (pressed === 1 && /\$/.test(usd.slice(usd.indexOf('flt-sugg')))) || { pressed }; });

  /* ======================= G) منتقي الصور ======================= */
  console.log('\n--- G) منتقي الصور ---');
  await tc('G1) المعاينة: alt وصفي بالرقم (والرئيسية مذكورة)، بديل عند تعطّل الرابط (onerror=imgFallback مع data-ph)، الأزرار بتسمية تذكر رقم الصورة (لا «حذف» متطابقة)، وحاوية المنتقي tabindex=-1', async () => {
    const d = mk('dealer1'); html(d, 'addShowroomCar'); d.R(`_imageCtx.draft.items.push({ previewUrl: 'blob:x/1', isMain: true }, { previewUrl: 'blob:x/2', isMain: false }); void 0`); const h = d.R('ImagePickerInner()'); const wrap = d.R('ImagePickerHtml()');
    return (/alt="صورة 1 \(رئيسية\)" data-ph="🚘" onerror="imgFallback\(this\)"/.test(h) && /alt="صورة 2" data-ph="🚘" onerror="imgFallback\(this\)"/.test(h) && /aria-label="حذف الصورة 1"/.test(h) && /aria-label="تعيين الصورة 2 كرئيسية"/.test(h) && /aria-label="حذف الصورة 2"/.test(h) && !/aria-label="تعيين الصورة 1/.test(h) && /id="imagePicker" tabindex="-1"/.test(wrap) && /role="alert"/.test(d.R(`_imageCtx.message = 'خطأ'; ImagePickerInner()`)) && /role="status"/.test(d.R(`_imageCtx.message = ''; _imageCtx.busy = true; ImagePickerInner()`))) || h.slice(0, 300); });
  await tc('G2) مصدر المعاينة يُهرَّب (لا حقن عبر src)، وصورة بلا رابط تعرض أيقونة بديلة مخفية عن قارئ الشاشة، وحدّا الصور 4 للعضو و5 للتاجر كما هما', async () => {
    const d = mk('dealer1'); html(d, 'addShowroomCar'); d.R(`_imageCtx.draft.items.push({ previewUrl: '"><script>alert(1)</script>', isMain: true }, { previewUrl: '', isMain: false }); void 0`); const h = d.R('ImagePickerInner()'); const u = mk('user'); html(u, 'addMemberCar');
    return (!/<script>alert/.test(h) && /&lt;script&gt;|&quot;/.test(h) && /<span aria-hidden="true">🚘<\/span>/.test(h) && d.J('_imageCtx.max') === 5 && u.J('_imageCtx.max') === 4) || 'picker'; });
  await tc('G3) refreshImagePicker: إن كان التركيز داخل المنتقي (حذف/تعيين رئيسية يستبدلان الأزرار) يعود إلى حاوية المنتقي بدل أن يضيع؛ وإن كان خارجه لا يُسرق', async () => {
    const d = mk('dealer1'); html(d, 'addShowroomCar'); const { doc, mkEl } = fakeDoc(d.E); const inner = mkEl('inner'); let focused = 0; const picker = { innerHTML: '', contains: el => el === inner, focus() { focused++; } }; d.E.els.imagePicker = picker;
    doc.activeElement = inner; d.R('refreshImagePicker()'); const a = focused === 1 && picker.innerHTML.length > 0; doc.activeElement = mkEl('elsewhere'); d.R('refreshImagePicker()'); return (a && focused === 1) || { a, focused }; });
  await tc('G4) حقل ملف «إضافة صور» قابل للتركيز بلوحة المفاتيح: ليس display:none (شفاف يغطي الزر)، وللزر مؤشر تركيز (focus-within)', async () => {
    const css = read('theme/theme.css').replace(/\/\*[\s\S]*?\*\//g, ''); const rs = []; css.replace(/([^{}]+)\{([^{}]*)\}/g, (m, s, b) => { s.split(',').forEach(x => rs.push({ s: x.trim(), b })); return m; });
    const last = (sel, prop) => { let v = null; rs.forEach(r => { if (r.s === sel) { const mm = new RegExp('(?:^|;|\\s)' + prop + '\\s*:\\s*([^;]+)').exec(r.b); if (mm) v = mm[1].trim(); } }); return v; };
    return (last('.img-add input', 'display') === 'block' && last('.img-add input', 'opacity') === '0' && last('.img-add', 'position') === 'relative' && rs.some(r => r.s === '.img-add:focus-within' || /\.img-add:focus-within/.test(r.s))) || { d: last('.img-add input', 'display') }; });

  /* ======================= H) CSS: التباين والتركيز والحقول ======================= */
  console.log('\n--- H) CSS: التباين WCAG والتركيز وحقول الهاتف ---');
  const CSS = read('theme/theme.css'); const tok = n => (CSS.match(new RegExp('--' + n + ':\\s*(#[0-9A-Fa-f]{6})')) || [])[1];
  const lum = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
  const cr = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  await tc('H1) تباين ألوان النص ≥ 4.5:1 (WCAG AA): الأخضر على الأبيض/الرمادي/شارة الحالة، الأحمر على شارته، البرتقالي على «قيد المراجعة»، النص الثانوي على الأبيض/الرمادي، والأبيض على الأخضر/الأحمر/الكحلي', async () => {
    const g = tok('green'), r = tok('red'), o = tok('orange'), m = tok('text-mut'), n = tok('navy'), w = '#FFFFFF', gray = tok('gray-bg'); const pairs = { 'green/white': [g, w], 'green/gray': [g, gray], 'green/badge': [g, '#E4F7EC'], 'red/badge': [r, '#FCE9E9'], 'orange/warn': [o, '#FCF1E3'], 'mut/white': [m, w], 'mut/gray': [m, gray], 'white/green': [w, g], 'white/red': [w, r], 'white/navy': [w, n], 'navy/gray': [n, gray] };
    const low = Object.entries(pairs).filter(([k, [a, b]]) => cr(a, b) < 4.5).map(([k, [a, b]]) => k + '=' + cr(a, b).toFixed(2)); return low.length === 0 || low; });
  await tc('H2) تركيز لوحة المفاتيح مرئي عامًا: الأزرار والروابط والقوائم والتنقل السفلي ومنتقي الصور، وحقول النماذج والبحث، وخيارات نوع الحساب (radio مخفي بصريًا)', async () => {
    return (/button:focus-visible,a:focus-visible,select:focus-visible/.test(CSS) && /\.navbtn:focus-visible/.test(CSS) && /\.field input:focus-visible/.test(CSS) && /\.searchbox:focus-within/.test(CSS) && /\.type-switch input:focus-visible \+ span\{outline:3px/.test(CSS) && /#screen:focus,#imagePicker:focus,\.modal-box:focus\{outline:none;\}/.test(CSS)) || 'focus css'; });
  await tc('H3) حقول النماذج على الهاتف: خط 16px (Safari لا يكبّر الصفحة) بالخصوصية الصحيحة (.field input[type=text]…) وارتفاع ≥44px للحقول والقوائم؛ وسابقًا كانت قاعدة 16px تخسر فتبقى 14px', async () => {
    const mq = CSS.slice(CSS.lastIndexOf('@media (max-width:37.5em){')); const okFont = /\.field input\[type=text\],\.field input\[type=password\],\.field input\[type=email\]\{font-size:16px;\}/.test(mq);
    return (okFont && /\.field input\[type=text\],\.field input\[type=password\],\.field input\[type=email\],\.field select\{min-height:44px;\}/.test(CSS)) || 'fields'; });
  await tc('H4) لا ألوان مبعثرة جديدة: كل ألوان الإضافات 6.2-B عبر المتغيرات (var(--…))، وأزرار الحوار ≥44px، وخط النص المهم ≥12px في الإضافات', async () => {
    const block = CSS.slice(CSS.indexOf('الجزء 6.2-B')); const hex = (block.match(/#[0-9A-Fa-f]{3,8}\b/g) || []).filter(h => !/^#(fff|FFF)/.test(h)); const sizes = [...block.matchAll(/font-size:\s*([\d.]+)px/g)].map(m => parseFloat(m[1]));
    return (hex.length === 0 && sizes.every(s => s >= 12) && /\.dlg-option\{min-height:44px/.test(block)) || { hex, sizes }; });
  await tc('H5) تسميات الحالة موحّدة: لا «محجوز/reserved» في أي خريطة تسميات أو شاشة أو مكوّن؛ «متاحة للبيع/مباعة» لسيارة المعرض، و«مباعة» لإعلان العضو أيضًا', async () => {
    const x = mk(null); const all = [x.J('CAR_STATUS_LABEL'), x.J('MEMBER_CAR_STATUS_LABEL'), x.J('SHOWROOM_STATUS_LABEL'), x.J('USER_STATUS_LABEL')].map(o => JSON.stringify(o)).join(''); const code = jsFiles('screens').concat(jsFiles('components'), jsFiles('navigation')).map(f => strip(read(f))).join('\n');
    return (!/محجوز|reserved/i.test(all) && !/محجوز|reserved/i.test(code) && x.J('CAR_STATUS_LABEL.available') === 'متاحة للبيع' && x.J('CAR_STATUS_LABEL.sold') === 'مباعة' && x.J('MEMBER_CAR_STATUS_LABEL.sold') === 'مباعة') || 'labels'; });

  /* ======================= I) الفلاتر ديناميكية والبيانات الفعلية ======================= */
  console.log('\n--- I) تنوّع البيانات والفلاتر الديناميكية ---');
  const poolOf = (x, kind) => x.J(`searchCars('', '${kind}')`);
  const uniq = (l, f) => [...new Set(l.map(f))];
  await tc('I1) أرقام البيانات الفعلية محسوبة من المستودعات (لا أرقام ثابتة): سيارات المعارض + سيارات الأعضاء = الكل، والظاهر للعامة ⊆ المخزَّن، والماركات/الموديلات/السنوات الفريدة والأقدم/الأحدث', async () => {
    const x = mk(null); const sc = x.J('CarsRepository.getAll()'), mc = x.J('MemberCarsRepository.getAll()'), all = sc.concat(mc); const vis = x.J('getVisibleCars().concat(getVisibleMemberCars())'); const years = uniq(all, c => c.year).sort((a, b) => a - b);
    const stats = { showroom: sc.length, member: mc.length, total: all.length, brands: uniq(all, c => c.brand).length, models: uniq(all, c => c.brand + '|' + c.model).length, years: years.length, oldest: years[0], newest: years[years.length - 1], visibleTotal: vis.length, visibleBrands: uniq(vis, c => c.brand).length, visibleModels: uniq(vis, c => c.brand + '|' + c.model).length, visibleYears: uniq(vis, c => c.year).length };
    console.log('   📊 تنوّع البيانات (فعلي):', JSON.stringify(stats), '| الماركات:', uniq(all, c => c.brand).sort().join(', '));
    return (stats.total === stats.showroom + stats.member && vis.length <= all.length && vis.every(v => all.some(a => a.id === v.id)) && stats.brands >= 1 && stats.oldest <= stats.newest) || stats; });
  await tc('I2) لم تُضَف بيانات في هذا الجزء: بذور سيارات المعارض 15 والأعضاء 10 (تنبيه: إن توسّعت البيانات في جزء لاحق عن قصد يُحدَّث هذا الرقم صراحةً)', async () => {
    const x = mk(null); return (x.J('CarsRepository.getAll().length') === 15 && x.J('MemberCarsRepository.getAll().length') === 10 && read('data/cars.js').length > 0) || 'seeds'; });
  await tc('I3) خيارات الماركة تُبنى من بيانات الشاشة الفعلية فقط: = الماركات الفريدة للمجموعة المرئية في كل من السيارات/الأعضاء/البحث؛ والسنوات = السنوات الموجودة فعلًا مرتبة تنازليًا، لا غير', async () => {
    const x = mk(null); const bad = []; [['showroom', 'cars'], ['member', 'memberCars'], ['all', 'search']].forEach(([kind, scr]) => { const pool = poolOf(x, kind); const o = x.J(`CarFilters.options(searchCars('', '${kind}'), {})`); const gotB = o.brands.map(b => b.label || b.value || b).sort(); const wantB = uniq(pool, c => c.brand).sort(); const gotY = o.years, wantY = uniq(pool, c => c.year).sort((a, b) => b - a); if (JSON.stringify(gotB.map(s => s.toLowerCase())) !== JSON.stringify(wantB.map(s => s.toLowerCase()))) bad.push(scr + ':brands'); if (JSON.stringify(gotY) !== JSON.stringify(wantY)) bad.push(scr + ':years'); });
    return bad.length === 0 || bad; });
  await tc('I4) Toyota ← موديلات Toyota الموجودة فعلًا فقط، وHyundai ← موديلات Hyundai فقط، وكل ماركة موجودة ← موديلاتها من البيانات؛ لا موديل من ماركة أخرى ولا موديل غير موجود', async () => {
    const x = mk(null); const bad = []; ['all', 'showroom', 'member'].forEach(kind => { const pool = poolOf(x, kind); uniq(pool, c => c.brand).forEach(b => { const o = x.J(`CarFilters.options(searchCars('', '${kind}'), { brand: ${JSON.stringify(b)} })`); const got = o.models.map(m => m.label || m.value || m).sort(); const want = uniq(pool.filter(c => c.brand === b), c => c.model).sort(); if (JSON.stringify(got) !== JSON.stringify(want)) bad.push(kind + ':' + b + ' got=' + got + ' want=' + want); }); });
    const toyota = x.J(`CarFilters.options(searchCars('', 'all'), { brand: 'Toyota' })`).models.map(m => m.label || m.value || m), hy = x.J(`CarFilters.options(searchCars('', 'all'), { brand: 'Hyundai' })`).models.map(m => m.label || m.value || m);
    return (bad.length === 0 && toyota.length >= 1 && hy.length >= 1 && toyota.every(m => !hy.includes(m))) || { bad: bad.slice(0, 3), toyota, hy }; });
  await tc('I5) الخيارات حيّة لا ثابتة: سيارة جديدة بماركة/موديل/سنة غير موجودة تظهر في الخيارات فورًا، وبعد حذفها تختفي؛ واختيار الماركة لا يُظهر موديلًا بلا سيارة', async () => {
    const x = mk('dealer1'); const sid = x.J('AuthorizationService.getManagedShowrooms()[0].id'); const o0 = x.J(`CarFilters.options(searchCars('', 'showroom'), {})`);
    x.R(`CarsRepository.create(CarModel({ id: 9701, sourceType: 'showroom', showroomId: ${sid}, brand: 'Zzbrand', model: 'Zzmodel', year: 2031, price: 1000, currency: 'IQD', mileage: 5, status: 'available' }))`);
    const o1 = x.J(`CarFilters.options(searchCars('', 'showroom'), {})`), m1 = x.J(`CarFilters.options(searchCars('', 'showroom'), { brand: 'Zzbrand' })`).models.map(m => m.label || m.value || m);
    x.R('CarsRepository.remove(9701)'); const o2 = x.J(`CarFilters.options(searchCars('', 'showroom'), {})`);
    const has = (o, v) => o.brands.map(b => String(b.label || b.value || b).toLowerCase()).includes(v);
    return (!has(o0, 'zzbrand') && has(o1, 'zzbrand') && o1.years.includes(2031) && m1.length === 1 && !has(o2, 'zzbrand') && !o2.years.includes(2031)) || { in1: has(o1, 'zzbrand'), years1: o1.years.includes(2031), m1, in2: has(o2, 'zzbrand') }; });
  await tc('I6) لا قوائم ثابتة: لا اسم ماركة/موديل من بيانات التطبيق كنص حرفي في أي شيفرة خارج data/ والاختبارات، ولا مصفوفة سنوات ولا حلقة سنوات، ولا ثوابت BRANDS/MODELS/YEARS', async () => {
    const x = mk(null); const names = new Set(); x.J('CarsRepository.getAll().concat(MemberCarsRepository.getAll())').forEach(c => { names.add(c.brand); names.add(c.model); });
    const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('services'), jsFiles('navigation'), jsFiles('repositories'), jsFiles('storage'), jsFiles('models'), ['app.js']); const hits = [];
    files.forEach(f => { const s = strip(read(f)); names.forEach(n => { if (n && n.length > 2 && new RegExp('[\'"`]' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[\'"`]').test(s)) hits.push(f + ':' + n); }); if (/\[\s*(?:19|20)\d\d\s*,\s*(?:19|20)\d\d/.test(s) || /for\s*\(\s*let\s+\w+\s*=\s*(?:19|20)\d\d/.test(s) || /\b(?:BRANDS|MODELS|YEARS|BRAND_LIST|MODEL_LIST|YEAR_LIST)\b\s*=/.test(s)) hits.push(f + ':list'); });
    return hits.length === 0 || hits; });
  await tc('I7) التوحيد (normalization) كما هو: «toyota/TOYOTA» ← الكتابة الموجودة في البيانات (Toyota) داخل ماركتها، وموديلات ماركتين لا تتداخل؛ ماركة جديدة تحتفظ بكتابة المستخدم', async () => {
    const x = mk(null); const pool = x.J(`searchCars('', 'all')`); const c1 = x.J(`CarFilters.canonicalBrand('TOYOTA', searchCars('', 'all'))`), c2 = x.J(`CarFilters.canonicalBrand('toyota', searchCars('', 'all'))`), c3 = x.J(`CarFilters.canonicalBrand('Zzbrand', searchCars('', 'all'))`);
    const m = x.J(`CarFilters.canonicalModel('COROLLA', 'toyota', searchCars('', 'all'))`); return (c1 === 'Toyota' && c2 === 'Toyota' && c3 === 'Zzbrand' && m === 'Corolla' && pool.length > 0) || { c1, c2, c3, m }; });

  /* ======================= J) الأداء والاتساق ======================= */
  console.log('\n--- J) الأداء والاتساق ---');
  await tc('J1) كل انتقال go() يرسم مرة واحدة فقط، وكتابة بحث/فلتر لا تعيد رسم الشاشة كلها (تحدّث القائمة فقط)', async () => {
    const x = mk(null); x.E.ctx.__n = 0; x.R('var __orig = render; render = function () { __n++; return __orig.apply(this, arguments); }'); x.R(`go('cars')`); const a = x.J('__n'); x.R('__n = 0'); x.R(`onCarsSearch('toy')`); x.R(`onCarsSearch('hyu')`); const b = x.J('__n'); x.R('__n = 0'); ['home', 'showrooms', 'map', 'cars'].forEach(r => x.R(`go('${r}')`)); return (a === 1 && b === 0 && x.J('__n') === 4) || { a, b }; });
  await tc('J2) لا مستمعات مكررة في الشيفرة: لا addEventListener داخل دوال الرسم/المعالجات (فقط عند التحميل: التنقل/المرشحات/النوافذ/الأدوار)', async () => {
    const files = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('navigation'), ['app.js']); const hits = []; files.forEach(f => { const s = strip(read(f)); [...s.matchAll(/addEventListener\s*\(/g)].forEach(m => { const before = s.slice(0, m.index); const depth = (before.match(/\{/g) || []).length - (before.match(/\}/g) || []).length; if (depth > 1 && !/function\s+(initBrowserBack|_initFilterSuggestionsOnce|syncFromOtherTab)/.test(before.slice(-600)) && !/_bind|_suggBound|initFilter/.test(before.slice(-400))) hits.push(f); }); }); return hits.length === 0 || [...new Set(hits)]; });
  await tc('J3) لا ميزات/تبعيات جديدة: السكربتات 85، لا إطار ولا مكتبة خارجية ولا شبكة، ولا Backend/AdMob/دفع/إشعارات/دردشة/تقييمات في الشيفرة', async () => {
    const h = read('index.html'); const code = [].concat(jsFiles('screens'), jsFiles('components'), jsFiles('services'), jsFiles('navigation'), jsFiles('repositories'), jsFiles('storage'), jsFiles('models'), ['app.js']).map(f => strip(read(f))).join('\n');
    return ((h.match(/<script src=/g) || []).length === 85 && !/<script src="https?:/.test(h) && !/firebase|supabase|stripe|paypal|googletag|adsbygoogle|pushmanager|serviceWorker|WebSocket|fetch\s*\(/i.test(code)) || 'features'; });
  await tc('J4) README: قسم الجزء 6.2-B موجود ويذكر الوصول والتحقق من التجربة والهاتف والفلاتر الديناميكية ونتائج تنوّع البيانات والاختبارات والقيود، ولا يدّعي الجاهزية الكاملة، ولا يذكر 6.3 كمُنفَّذ', async () => {
    const rd = read('README.md'); const i = rd.indexOf('## المرحلة 10 — الجزء 6.2-B'); const sec = i >= 0 ? rd.slice(i) : ''; return (sec.length > 1500 && /الوصول|Accessibility/.test(sec) && /الهاتف|Chromium/.test(sec) && /الفلاتر الديناميكية|ديناميك/.test(sec) && /تنوّع البيانات/.test(sec) && /قيود/.test(sec) && !/Production-ready|جاهز للإنتاج بالكامل/i.test(sec.replace(/لا يعني[^\n]*|ليس[^\n]*Production-ready[^\n]*|ليست[^\n]*/g, '')) && /لم يُبدأ[^\n]*6\.3/.test(sec)) || { len: sec.length }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

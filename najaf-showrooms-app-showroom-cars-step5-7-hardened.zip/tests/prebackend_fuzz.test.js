/* فوضى ما قبل الباكند (المرحلة 10 — الجزء 8): تخزين تالف، سجلات بحقول غريبة الأنواع، وحقن نصوص مخزَّن.
   المعيار: لا استثناء إقلاع ولا [render error] ولا ErrorState ولا نص معطوب، ولا تلويث نموذج (prototype)، ولا وسم/سمة خام تنفلت من التهريب.
   يلتقط كل console.error (فـE.errors وحدها لا تلتقط استثناءات الرسم). المجموعات جزئية عن قصد (زمن التشغيل)؛ الشاملة نُفِّذت أثناء التدقيق. */
const { makeEnv } = require('./harness');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 260)); } };
const clone = o => JSON.parse(JSON.stringify(o));
const ERRSTATE = 'حدث خطأ، حاول مرة أخرى', BADTXT = /undefined|NaN|\[object/;
const ID = { user: 7, dealer1: 1, admin: 6 };
function env(store) {
  const E = makeEnv(store, { fullSeed: 'p3' }), traces = [];
  E.ctx.console.error = (...a) => traces.push(String(a[0]).slice(0, 40) + ' ' + String((a[a.length - 1] && a[a.length - 1].message) || '').slice(0, 80));
  const R = c => { try { return E.run(c); } catch (e) { traces.push('THROW ' + c.slice(0, 40) + ' ' + String(e.message).slice(0, 60)); } };
  return { E, R, traces };
}
const as = (x, who) => { x.R('SessionService.logout()'); if (who) x.R(`SessionService.login(${ID[who]})`); };

(async () => {
  /* ======================= 1) تخزين تالف ======================= */
  console.log('\n--- 1) تخزين تالف: كل مفتاح × أنواع التلف ---');
  const E0 = makeEnv(undefined, { fullSeed: 'p3' }); E0.run('SessionService.login(7)'); E0.run('toggleFavorite(1)'); E0.run('toggleFavorite(101)');
  ['CarsRepository', 'MemberCarsRepository', 'ShowroomsRepository', 'UsersRepository', 'FavoritesRepository', 'CarImagesRepository'].forEach(r => E0.run(`${r}.save()`)); E0.run(`UsersRepository.update(1,{name:'Override'})`);
  const base = clone(E0.store); const keys = Object.keys(base).filter(k => k !== 'najaf.session');
  const WEIRD = { brand: null, model: {}, price: 'abc', year: [], mileage: -5, currency: 'EUR', status: 123, ownerId: 'abc', showroomId: [], location: 42, description: 'x'.repeat(30000), createdAt: {}, updatedAt: [], name: null, phone: {}, role: 7, passwordHash: null, carId: 'q', userId: null, imageUrl: {}, isMain: 'yes' };
  const VARIANTS = {
    notjson: () => 'not json {{', null: () => 'null', junkArr: () => '[null,1,"x",[],{}]', infId: () => '[{"id":1e999},{"id":-1},{"id":1.5}]',
    weird: v => { try { const a = JSON.parse(v); return JSON.stringify(Array.isArray(a) ? a.map(r => Object.assign({}, r, Object.fromEntries(Object.keys(WEIRD).filter(k => k in r).map(k => [k, WEIRD[k]])))) : Object.fromEntries(Object.keys(a).map(k => [k, WEIRD]))); } catch (e) { return 'x'; } },
    proto: () => '{"__proto__":{"polluted":1},"constructor":{"prototype":{"polluted2":1}}}' };
  const PUB = ['home', 'showrooms', 'cars', 'map', 'favorites', 'recentCars', 'memberCars', 'search'], DET = [['carDetails', 1], ['carDetails', 101], ['memberCarDetails', 101], ['showroomDetails', 1]], ADM = ['adminDashboard', 'adminMemberCars', 'adminShowrooms', 'adminUsers'];
  await tc(`1) ${keys.length} مفتاحًا × ${Object.keys(VARIANTS).length} أنواع تلف = ${keys.length * Object.keys(VARIANTS).length} إقلاعًا: بلا استثناء إقلاع، ولا استثناء رسم ولا ErrorState ولا نص معطوب لضيف/عضو/مدير، ولا تلويث prototype`, async () => {
    const bad = []; let boots = 0;
    for (const k of keys) for (const [vn, fn] of Object.entries(VARIANTS)) {
      const st = clone(base); st[k] = fn(st[k]); boots++; let x; try { x = env(st); } catch (e) { bad.push(`${k}:${vn}:BOOT ${String(e.message).slice(0, 50)}`); continue; }
      for (const who of [null, 'user', 'admin']) { as(x, who); for (const r of PUB.concat(DET.map(d => d[0])).concat(who === 'admin' ? ADM : [])) { const d = DET.find(d => d[0] === r); const n = x.traces.length; x.R(`go('${r}'${d ? ',' + d[1] : ''})`); const h = x.E.screen(); if (x.traces.length > n || h.includes(ERRSTATE) || BADTXT.test(h)) { bad.push(`${k}:${vn}:${who || 'guest'}:${r}:${x.traces[n] || 'html'}`); break; } } }
      if (x.R('({}).polluted') !== undefined || x.R('({}).polluted2') !== undefined) bad.push(`${k}:${vn}:POLLUTED`);
    }
    return (bad.length === 0 && boots === keys.length * Object.keys(VARIANTS).length) || { boots, bad: bad.slice(0, 5) }; });

  /* ======================= 2) سجلات بحقول غريبة ======================= */
  console.log('\n--- 2) سجلات ظاهرة بحقول غريبة الأنواع ---');
  await tc('2) سجلات (سيارات معارض/إعلانات أعضاء/معارض/مستخدمون) كل حقل فيها null/رقم/كائن/مصفوفة/true: كل الشاشات وكل خانات البحث (العامة والإدارية) وتفاصيل السجلات بلا استثناء رسم', async () => {
    const x = env(); let n = 9500; const W = [null, 42, {}, [], true];
    const add = (repo, model, o) => { n++; x.R(`${repo}.create(${model}(${JSON.stringify(o(n))}))`); return n; };
    const T = { createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' };
    for (const f of ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description', 'createdAt', 'mainImage', 'status', 'showroomId']) for (const v of W) add('CarsRepository', 'CarModel', i => Object.assign({ id: i, sourceType: 'showroom', showroomId: 1, brand: 'Kia', model: 'Rio', year: 2020, price: 1000000, currency: 'IQD', mileage: 1000, status: 'available', mainImage: '' }, T, { [f]: v }));
    for (const f of ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'description', 'createdAt', 'location', 'phone', 'whatsapp', 'ownerId']) for (const v of W) add('MemberCarsRepository', 'CarModel', i => Object.assign({ id: i, sourceType: 'member', ownerId: 7, brand: 'Kia', model: 'Rio', year: 2020, price: 1000000, currency: 'IQD', mileage: 1000, status: 'active', phone: '07700000001', whatsapp: '9647700000001', location: 'x', mainImage: '' }, T, { [f]: v }));
    for (const f of ['name', 'address', 'phone', 'whatsapp', 'description', 'image', 'latitude', 'longitude', 'createdAt']) for (const v of W) add('ShowroomsRepository', 'ShowroomModel', i => Object.assign({ id: i, name: 'S' + i, address: 'a', status: 'active', ownerId: 1 }, T, { [f]: v }));
    for (const f of ['name', 'phone', 'email', 'createdAt']) for (const v of W) add('UsersRepository', 'UserModel', i => Object.assign({ id: i, name: 'U' + i, phone: '0770' + i, email: 'u' + i + '@x.test', role: 'user', status: 'active', passwordHash: 'x' }, T, { [f]: v }));
    const bad = []; const QUERIES = ['', 'a', 'Kia', 'x', '<b>', '٢٠٢٠']; const FN = { cars: 'onCarsSearch', memberCars: 'onMemberCarsSearch', recentCars: 'onRecentCarsSearch', showrooms: 'onShowroomsSearch', search: 'onSearchScreenInput', adminMemberCars: 'onAdminMemberCarsSearch', adminShowrooms: 'onAdminShowroomsSearch', adminShowroomCars: 'onAdminShowroomCarsSearch', adminUsers: 'onAdminUsersSearch' };
    for (const who of [null, 'user', 'dealer1', 'admin']) { as(x, who); const rs = ['home', 'showrooms', 'cars', 'memberCars', 'recentCars', 'map', 'favorites', 'search'].concat(who ? ['myMemberCars', 'account'] : []).concat(['dealer1', 'admin'].includes(who) ? ['myShowroomCars', 'dealerHome'] : []).concat(who === 'admin' ? ['adminDashboard', 'adminMemberCars', 'adminShowrooms', 'adminShowroomCars', 'adminUsers', 'adminDealerRequests'] : []);
      for (const r of rs) { const t0 = x.traces.length; x.R(`go('${r}'${r === 'search' ? ",'kia'" : ''})`); if (x.traces.length > t0) bad.push(`${who || 'guest'}:${r}:${x.traces[t0]}`); const fn = FN[r]; if (fn && x.R(`typeof ${fn}`) === 'function') for (const q of QUERIES) { const t1 = x.traces.length; x.R(`${fn}(${JSON.stringify(q)})`); if (x.traces.length > t1) { bad.push(`${who || 'guest'}:${r}:query "${q}":${x.traces[t1]}`); break; } } } }
    for (const who of [null, 'user', 'admin']) { as(x, who); for (let i = 9501; i <= n; i += 3) for (const rt of ['carDetails', 'memberCarDetails', 'showroomDetails', 'adminMemberCarDetails', 'adminUserDetails']) { if (rt.startsWith('admin') && who !== 'admin') continue; const t0 = x.traces.length; x.R(`go('${rt}',${i})`); if (x.traces.length > t0) { bad.push(`${who || 'guest'}:${rt}:${i}:${x.traces[t0]}`); break; } } }
    return bad.length === 0 || { count: bad.length, first: bad.slice(0, 5) }; });

  /* ======================= 3) حقن نصوص مخزَّن ======================= */
  console.log('\n--- 3) حقن نصوص مخزَّن (XSS) ---');
  await tc('3) حمولات تكسر الوسوم والسمات والقوالب في كل حقل نصي لسيارة معرض وإعلان عضو ومعرض ومستخدم: لا وسم ولا سمة خام في أي شاشة لأي دور (وتظهر الحمولة مُهرَّبة فعلًا — الفحص ليس فارغًا)', async () => {
    const x = env(); const P = ['"><img src=x onerror=XSS1>', 'x" onmouseover="XSS2" a="', "x' onfocus='XSS3' b='", '</script><script>XSS4()</script>', '`${XSS5}`']; const ALL = P.join(' '); let n = 9700;
    const T = { createdAt: '2027-01-01T00:00:00.000Z', updatedAt: '2027-01-01T00:00:00.000Z' };
    n++; x.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify(Object.assign({ id: n, name: 'N' + ALL, address: 'A' + ALL, phone: '07701112223', whatsapp: ALL, description: 'D' + ALL, workingHours: 'W' + ALL, image: ALL, status: 'active', ownerId: 1, latitude: 32, longitude: 44.3, services: [ALL] }, T))}))`); const SH = n;
    n++; x.R(`CarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id: n, sourceType: 'showroom', showroomId: 1, brand: 'B' + ALL, model: 'M' + ALL, year: 2020, price: 1000000, currency: 'IQD', mileage: 1, status: 'available', transmission: 'T' + ALL, fuelType: 'F' + ALL, color: 'C' + ALL, description: 'D' + ALL, mainImage: ALL }, T))}))`); const CAR = n;
    n++; x.R(`MemberCarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id: n, sourceType: 'member', ownerId: 7, brand: 'B' + ALL, model: 'M' + ALL, year: 2020, price: 1000000, currency: 'IQD', mileage: 1, status: 'active', transmission: 'T' + ALL, fuelType: 'F' + ALL, color: 'C' + ALL, description: 'D' + ALL, location: 'L' + ALL, phone: '07700000001', whatsapp: '9647700000001', mainImage: ALL }, T))}))`); const MEM = n;
    n++; x.R(`UsersRepository.create(UserModel(${JSON.stringify(Object.assign({ id: n, name: 'U' + ALL, phone: '0770222' + n, email: 'x@y.test', role: 'dealer', status: 'pending', passwordHash: 'x' }, T))}))`); const USR = n;
    const RAW = /<img src=x onerror=XSS1|<script>XSS4|" onmouseover="XSS2"|\sonfocus='XSS3'|\sonerror=XSS1(?=[ >])/; const hits = []; let sawEscaped = false;
    for (const who of [null, 'user', 'dealer1', 'admin']) { as(x, who); const routes = [['home'], ['showrooms'], ['cars'], ['memberCars'], ['recentCars'], ['map'], ['favorites'], ['search', 'B'], ['search', ALL], ['carDetails', CAR], ['memberCarDetails', MEM], ['showroomDetails', SH]].concat(who ? [['account'], ['myMemberCars']] : []).concat(['dealer1', 'admin'].includes(who) ? [['myShowroomCars']] : []).concat(who === 'admin' ? [['adminMemberCars'], ['adminMemberCarDetails', MEM], ['adminShowrooms'], ['adminShowroomCars'], ['adminUsers'], ['adminUserDetails', USR], ['adminDealerRequests']] : []);
      for (const [r, p] of routes) { const t0 = x.traces.length; x.R(`go('${r}'${p !== undefined ? ',' + JSON.stringify(p) : ''})`); const h = x.E.screen(); if (RAW.test(h)) hits.push(`${who || 'guest'}:${r}`); if (x.traces.length > t0) hits.push(`${who || 'guest'}:${r}:TRACE`); if (h.includes('&lt;img src=x onerror=XSS1&gt;')) sawEscaped = true; } }
    return (hits.length === 0 && sawEscaped) || { hits: hits.slice(0, 5), sawEscaped }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

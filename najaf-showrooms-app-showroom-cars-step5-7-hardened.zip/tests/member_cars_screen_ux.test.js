/* اختبارات تبسيط شاشة «سيارات الأعضاء» العامة (UX ج4): بحث بارز + زر «تصفية» + لوحة الفلاتر المتقدمة مطويّة افتراضيًا.
   مصدر الحقيقة واحد: الشاشة ← معالجاتها القائمة (onMemberCarsSearch/onMemberCarsFilter/onMemberCarsRange/removeMemberCarsFilter/clearMemberCarsFilters)
   ← searchCars + CarFilters ← قواعد الظهور (visibilityService) ← عرض البطاقات. الطيّ واجهة فقط ولا محرك ثانٍ.
   الفحوص البصرية والتركيز الحقيقي وTab/Enter/Space/Escape في Chromium على 320/360/390/412 (انظر التقرير). المراجع هنا مشتقة من المستودع/البيانات لا من الكود المختبَر. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const CRED = { user: ['07700000001', 'user123'], admin: ['07700000000', 'admin123'] };
const RATE = 1300;                                                  // EXCHANGE_RATE_CONFIG.usdToIqd (مرجع للمقارنة فقط)
const iqd = c => c.currency === 'USD' ? c.price * RATE : c.price, usd = c => c.currency === 'USD' ? c.price : c.price / RATE;
function mk(role, store) {
  const E = makeEnv(store, { fullSeed: 'p3' }), R = c => E.run(c);
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); E.els.loginIdentifier = { value: c[0], style: {}, textContent: '' }; E.els.loginPassword = { value: c[1], style: {}, textContent: '' }; R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  /** يكتب قيم حقول فلاتر الأعضاء كما يكتبها المستخدم (ثم يستدعي المختبِر المعالج القائم) */
  const setF = (o, prefix = 'member') => { const map = { brand: 'Brand', model: 'Model', year: 'Year', minPrice: 'MinPrice', maxPrice: 'MaxPrice', minMileage: 'MinMileage', maxMileage: 'MaxMileage' };
    Object.entries(map).forEach(([k, v]) => { E.els[prefix + 'Filter' + v] = { value: o[k] === undefined ? '' : String(o[k]), style: {} }; }); E.els[prefix + 'PriceCurrency'] = { value: o.cur === undefined ? '' : String(o.cur), style: {} }; };
  /** عنصر DOM وهمي يلتقط setAttribute/focus (لقياس الحالة الحيّة بلا إعادة رسم) */
  const spy = id => { const el = { attrs: {}, className: '', hidden: undefined, textContent: '', innerHTML: '', focused: false, setAttribute(k, v) { this.attrs[k] = v; }, focus() { this.focused = true; } }; E.els[id] = el; return el; };
  return { E, R, J, setF, spy };
}
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const ids = html => [...new Set([...String(html).matchAll(/go\('memberCarDetails',\s*(\d+)\)/g)].map(m => Number(m[1])))];
const tag = (html, id) => (String(html).match(new RegExp('<[a-z]+[^>]*id="' + id + '"[^>]*>')) || [''])[0];
const isHidden = (html, id) => /\shidden(\s|>|=)/.test(tag(html, id));
const ERR = 'حدث خطأ، حاول مرة أخرى', BAD = /undefined|NaN|\[object/;
const arDigits = v => String(v).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
const uni = a => [...new Set(a)].sort();

(async () => {
  // مرجع مستقل: إعلانات الأعضاء المخزَّنة النشطة لمالك فعّال (كل الملّاك فعّالون في البذرة) = العام
  const ref = mk(null); const STORED = ref.J('MemberCarsRepository.getAll()'); const OWNERS = ref.J('UsersRepository.getAll()');
  const PUB = STORED.filter(c => c.status === 'active' && OWNERS.some(u => u.id === c.ownerId && u.status === 'active'));
  const PUB_IDS = PUB.map(c => c.id);
  const corolla = PUB.find(c => c.model === 'Corolla' && c.brand === 'Toyota');

  /* ======================= A) الحالة الافتراضية ======================= */
  console.log('\n--- A) الحالة الافتراضية: بحث + سيارات، واللوحة مطويّة ---');
  await tc('1) سيارات الأعضاء تفتح واللوحة المتقدمة مطويّة (hidden) والزر aria-expanded="false" بلا شارة والملخص مخفي، وحقول FilterBar القائمة موجودة داخل اللوحة (ماركة/موديل/سنة/عملة/سعر/كيلومترات) مرة واحدة', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const h = x.E.screen(); const panel = h.slice(h.indexOf('id="memberRefinePanel"'), h.indexOf('id="memberCarsList"'));
    const fields = ['memberFilterBrand', 'memberFilterModel', 'memberFilterYear', 'memberPriceCurrency', 'memberFilterMinPrice', 'memberFilterMaxPrice', 'memberFilterMinMileage', 'memberFilterMaxMileage'];
    return (x.R('memberFiltersOpen') === false && isHidden(h, 'memberRefinePanel') && /aria-expanded="false"/.test(tag(h, 'memberRefineToggle')) && isHidden(h, 'memberRefineBadge') && isHidden(h, 'memberRefineSummary') && fields.every(f => panel.includes('id="' + f + '"') && h.split('id="' + f + '"').length === 2) && panel.includes('id="memberFilterBar"')) || 'collapsed'; });
  await tc('2) حقل البحث ظاهر مباشرة في الأعلى (داخل .cars-tools مع الزر) بنص «ابحث عن سيارة» وسطر مساعد «ماركة، موديل، سنة أو موقع السيارة» تحت العنوان، ومعالج onMemberCarsSearch القائم', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const h = x.E.screen();
    return (/class="cars-tools"[\s\S]*class="searchbox"/.test(h) && h.includes('placeholder="ابحث عن سيارة"') && h.includes('aria-label="ابحث عن سيارة"') && h.includes('<p class="sub">ماركة، موديل، سنة أو موقع السيارة</p>') && h.includes('oninput="onMemberCarsSearch(this.value)"') && h.includes('enterkeyhint="search"') && h.indexOf('<h1>') < h.indexOf('class="searchbox"')) || 'search'; });
  await tc('3) السيارات مباشرة تحت منطقة البحث: الترتيب بحث/زر ← ملخص ← لوحة ← قائمة، وكل الإعلانات العامة تظهر بلا فتح اللوحة، وزر «نشر سيارتي» بعد القائمة كما كان', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const h = x.E.screen(); const pos = s => h.indexOf(s);
    return (pos('class="searchbox"') < pos('id="memberRefineToggle"') && pos('id="memberRefineToggle"') < pos('id="memberRefineSummary"') && pos('id="memberRefineSummary"') < pos('id="memberRefinePanel"') && pos('id="memberRefinePanel"') < pos('id="memberCarsList"') && pos('id="memberCarsList"') < pos("go('addMemberCar')") && same(ids(h), PUB_IDS) && !h.includes(ERR) && !BAD.test(h)) || { n: ids(h).length }; });
  await tc('A4) سمات الوصول: الزر <button type="button"> أصلي (يعمل بالفأرة واللمس وEnter/Space)، aria-controls يشير للوحة موجودة، الاسم يحوي النص الظاهر «تصفية»، اللوحة role=group بتسمية، الشارة aria-hidden، ولا معرّف مكرر', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const h = x.E.screen(); const b = tag(h, 'memberRefineToggle'); const all = [...h.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
    return (/^<button /.test(b) && /type="button"/.test(b) && !/tabindex="-1"/.test(b) && /aria-controls="memberRefinePanel"/.test(b) && h.includes('id="memberRefinePanel"') && /aria-label="تصفية سيارات الأعضاء"/.test(b) && />\s*تصفية\s*</.test(h) && /role="group"/.test(tag(h, 'memberRefinePanel')) && /aria-label="تصفية سيارات الأعضاء"/.test(tag(h, 'memberRefinePanel')) && /aria-hidden="true"/.test(tag(h, 'memberRefineBadge')) && new Set(all).size === all.length) || { b }; });

  /* ======================= B) فتح/إغلاق ======================= */
  console.log('\n--- B) فتح اللوحة وإغلاقها ---');
  await tc('4) زر «تصفية» يفتح لوحة الفلاتر القائمة (نفس FilterBar بحقوله)، والإغلاق (التبديل أو «عرض النتائج») يطويها، بلا استثناء', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.R('toggleMemberFilterPanel()'); const o1 = x.R('memberFiltersOpen'), p1 = x.E.els.memberRefinePanel.hidden; x.R('render()'); const h = x.E.screen();
    x.R('toggleMemberFilterPanel()'); const o2 = x.R('memberFiltersOpen'), p2 = x.E.els.memberRefinePanel.hidden; x.R('toggleMemberFilterPanel()'); x.R('closeMemberFilterPanel()');
    return (o1 === true && p1 === false && !isHidden(h, 'memberRefinePanel') && h.includes('id="memberFilterBrand"') && o2 === false && p2 === true && x.R('memberFiltersOpen') === false && x.E.els.memberRefinePanel.hidden === true && x.E.errors.length === 0) || { o1, p1, o2, p2 }; });
  await tc('5) لوحة المفاتيح: Escape يطوي اللوحة المفتوحة في مسار memberCars فقط، ولا يطويها إن كانت نافذة اقتراحات السعر/الكيلومترات مفتوحة (أول Escape يغلقها كما كان) أو نافذة حوار نشطة، ولا لمفتاح آخر، ويعيد التركيز لزر «تصفية»، ولا يمسح فلاتر؛ والمستمع مُسجَّل مرة واحدة في مرحلة الالتقاط', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const handlers = []; x.E.ctx.document.addEventListener = (type, fn, cap) => handlers.push({ type, fn, cap });
    const m = read('screens/memberCars.js').match(/\(function bindMemberFilterPanelEscape\(\) \{[\s\S]*?\}\)\(\);/); if (!m) return 'IIFE not found'; x.R(m[0]);
    const h = handlers.find(z => z.type === 'keydown'); if (!h) return 'no keydown listener'; const toggle = x.spy('memberRefineToggle'); x.spy('memberRefinePanel'); x.spy('memberRefineSummary'); x.spy('memberRefineBadge'); x.spy('memberRefineDone'); x.spy('memberCarsList');
    const fire = key => h.fn({ key }); const open = () => { x.R('memberFiltersOpen = true'); toggle.focused = false; };
    x.setF({ brand: 'Kia' }); x.R('onMemberCarsFilter()');
    open(); fire('Enter'); const other = x.R('memberFiltersOpen');
    open(); fire(' '); const space = x.R('memberFiltersOpen');
    open(); fire('Escape'); const closed = x.R('memberFiltersOpen'), refocused = toggle.focused;
    open(); x.E.ctx.document.querySelector = sel => (String(sel).includes('flt-sugg') ? {} : null); fire('Escape'); const popup = x.R('memberFiltersOpen'); x.E.ctx.document.querySelector = () => null;
    open(); x.R('ModalFocus.isActive = () => true'); fire('Escape'); const modal = x.R('memberFiltersOpen'); x.R('ModalFocus.isActive = () => false');
    open(); x.R(`currentRoute = 'cars'`); fire('Escape'); const route = x.R('memberFiltersOpen'); x.R(`currentRoute = 'memberCars'`);
    x.R('memberFiltersOpen = false'); fire('Escape'); const already = x.R('memberFiltersOpen');
    return (handlers.filter(z => z.type === 'keydown').length === 1 && h.cap === true && other === true && space === true && closed === false && refocused === true && popup === true && modal === true && route === true && already === false && x.R('memberCarsFilters.brand') === 'Kia') || { other, space, closed, refocused, popup, modal, route, already }; });
  await tc('6) aria-expanded يتغير فعليًا: الزر «false» ثم «true» عند الفتح ثم «false» عند الإغلاق (حيًّا بلا إعادة رسم، وفي HTML بعد إعادة الرسم)، ويتبع الشارة aria-label بعدد الفلاتر', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const t0 = x.spy('memberRefineToggle'); x.spy('memberRefinePanel'); x.spy('memberRefineSummary'); x.spy('memberRefineBadge'); x.spy('memberRefineDone');
    const h0 = /aria-expanded="false"/.test(tag(x.E.screen(), 'memberRefineToggle'));
    x.R('toggleMemberFilterPanel()'); const live1 = t0.attrs['aria-expanded']; x.R('render()'); const h1 = /aria-expanded="true"/.test(tag(x.E.screen(), 'memberRefineToggle'));
    x.R('toggleMemberFilterPanel()'); const live2 = t0.attrs['aria-expanded'];
    x.setF({ brand: 'Kia', year: '2019' }); x.R('onMemberCarsFilter()'); const label = t0.attrs['aria-label'];
    return (h0 && live1 === 'true' && h1 && live2 === 'false' && label === 'تصفية سيارات الأعضاء، فلتران فعّالان') || { h0, live1, h1, live2, label }; });

  /* ======================= C) مؤشر الفلاتر والملخص ======================= */
  console.log('\n--- C) المؤشر والملخص والمسح ---');
  await tc('7) عدد الفلاتر الفعالة يتحدث فورًا: الشارة (بلا عدد مضلِّل عند الصفر، وبلا عدّ لنص البحث الحر)، وحالة الزر has-filters، واسمه، عبر تغيير القوائم وكتابة الأرقام وإزالة شارة وحتى المسح', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const tg = x.spy('memberRefineToggle'), badge = x.spy('memberRefineBadge'); x.spy('memberRefinePanel'); x.spy('memberRefineSummary'); x.spy('memberRefineDone'); x.spy('memberCarsList'); x.spy('memberFilterBar'); x.spy('memberFilterChips');
    const st = () => [badge.textContent, badge.hidden, tg.className];
    x.R('onMemberCarsSearch("toyota")'); const s0 = st();                                       // نص البحث ليس فلترًا متقدمًا
    x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onMemberCarsFilter()'); const s2 = st();
    x.setF({ brand: 'Toyota', model: 'Corolla', minPrice: '1000' }); x.R('onMemberCarsRange()'); const s3 = st();
    x.R(`removeMemberCarsFilter('model')`); const s2b = st(); x.R(`removeMemberCarsFilter('brand')`); x.R(`removeMemberCarsFilter('price')`); const s0b = st();
    return (s0[0] !== '1' && s0[1] !== false && !/has-filters/.test(s0[2]) && s2[0] === '2' && s2[1] === false && /has-filters/.test(s2[2]) && s3[0] === '3' && s2b[0] === '2' && s0b[0] === '0' && s0b[1] === true && !/has-filters/.test(s0b[2]) && x.R('activeFilterCount(memberCarsFilters)') === 0) || { s0, s2, s3, s2b, s0b }; });
  await tc('8) اللوحة مطويّة والفلاتر فعالة: ملخص الفلاتر الفعالة ظاهر خارج اللوحة بنفس FilterChips («فلاتر فعالة (N)» + شارات قابلة للإزالة + «مسح الفلاتر»)، والزر بشارة وhas-filters واسمه يذكر العدد، ولا تكرار للظاهر؛ وعند فتح اللوحة يفرغ الملخص (الشارات داخلها فقط)', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onMemberCarsFilter()'); x.R('render()'); const h = x.E.screen();
    const sum = h.slice(h.indexOf('id="memberRefineSummary"'), h.indexOf('id="memberRefinePanel"')), panelHtml = h.slice(h.indexOf('id="memberRefinePanel"'), h.indexOf('id="memberCarsList"'));
    x.R('toggleMemberFilterPanel()'); x.R('render()'); const ho = x.E.screen(); const sumO = ho.slice(ho.indexOf('id="memberRefineSummary"'), ho.indexOf('id="memberRefinePanel"'));
    return (/class="filter-toggle has-filters"/.test(tag(h, 'memberRefineToggle')) && /aria-label="تصفية سيارات الأعضاء، فلتران فعّالان"/.test(tag(h, 'memberRefineToggle')) && /id="memberRefineBadge"[^>]*>2</.test(h) && !isHidden(h, 'memberRefineSummary') && sum.includes('فلاتر فعالة (2)') && sum.includes('onclick="clearMemberCarsFilters()"') && sum.includes("removeMemberCarsFilter('brand')") && sum.includes("removeMemberCarsFilter('model')") && (h.replace(panelHtml, '').match(/فلاتر فعالة \(2\)/g) || []).length === 1 && isHidden(h, 'memberRefinePanel') && isHidden(ho, 'memberRefineSummary') && !sumO.includes('filter-chip') && (ho.match(/فلاتر فعالة \(2\)/g) || []).length === 1) || { sum: sum.slice(0, 160) }; });
  await tc('9) إزالة فلتر واحد من الملخص المطوي (شارة ×) بمعالج removeMemberCarsFilter القائم: الماركة (تُسقط الموديل تبعًا)، السنة، السعر، الكيلومترات — كل منها يحدّث القائمة والشارة والملخص حيًّا والباقي كما هو', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const badge = x.spy('memberRefineBadge'); const sum = x.spy('memberRefineSummary'); x.spy('memberRefineToggle'); x.spy('memberRefinePanel'); x.spy('memberRefineDone'); const lst = x.spy('memberCarsList'); x.spy('memberFilterBar');
    x.setF({ brand: 'Toyota', model: 'Corolla', year: String(corolla.year), minPrice: '1000', maxMileage: '900000' }); x.R('onMemberCarsFilter()'); const n0 = badge.textContent;
    x.R(`removeMemberCarsFilter('year')`); const a = JSON.parse(x.R('JSON.stringify(memberCarsFilters)')); const nA = badge.textContent;
    x.R(`removeMemberCarsFilter('price')`); const nB = badge.textContent; x.R(`removeMemberCarsFilter('mileage')`); const nC = badge.textContent;
    x.R(`removeMemberCarsFilter('brand')`); const f = JSON.parse(x.R('JSON.stringify(memberCarsFilters)'));
    return (n0 === '5' && a.year === '' && a.brand === 'Toyota' && a.model === 'Corolla' && a.minPrice === '1000' && nA === '4' && nB === '3' && nC === '2' && f.brand === '' && f.model === '' && badge.textContent === '0' && sum.hidden === true && same(ids(lst.innerHTML), PUB_IDS)) || { n0, a, nA, nB, nC, f }; });
  await tc('10) إغلاق اللوحة لا يمسح الفلاتر: بعد الإغلاق (بالتبديل أو بـ«عرض النتائج» أو بـEscape) حالة memberCarsFilters كما هي حرفيًا والقائمة تبقى مصفّاة', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.setF({ brand: 'Toyota', year: String(corolla.year) }); x.R('onMemberCarsFilter()'); const f0 = x.R('JSON.stringify(memberCarsFilters)');
    x.R('toggleMemberFilterPanel()'); x.R('toggleMemberFilterPanel()'); const f1 = x.R('JSON.stringify(memberCarsFilters)');
    x.R('toggleMemberFilterPanel()'); x.R('closeMemberFilterPanel()'); const f2 = x.R('JSON.stringify(memberCarsFilters)'); const shown = ids(x.E.els.memberCarsList.innerHTML);
    return (f0 === f1 && f1 === f2 && JSON.parse(f2).brand === 'Toyota' && same(shown, PUB.filter(c => c.brand === 'Toyota' && c.year === corolla.year).map(c => c.id)) && shown.length >= 1) || { f0, f2 }; });
  await tc('11) إعادة الفتح تحفظ الاختيارات: الماركة/الموديل/السنة/عملة البحث/السعر/الكيلومترات المختارة تظهر في حقولها نفسها (selected/value) بعد إغلاق وإعادة رسم', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.setF({ brand: 'Toyota', model: 'Corolla', year: String(corolla.year), minPrice: '5000000', maxMileage: '400000' }); x.R('onMemberCarsFilter()');
    x.R('toggleMemberFilterPanel()'); x.R('closeMemberFilterPanel()'); x.R('toggleMemberFilterPanel()'); x.R('render()'); const h = x.E.screen();
    const sel = id => (h.match(new RegExp('id="' + id + '"[\\s\\S]*?</select>')) || [''])[0];
    return (/<option value="Toyota" selected>/.test(sel('memberFilterBrand')) && /<option value="Corolla" selected>/.test(sel('memberFilterModel')) && new RegExp('<option value="' + corolla.year + '" selected>').test(sel('memberFilterYear')) && /id="memberFilterMinPrice"[^>]*value="5000000"/.test(h) && /id="memberFilterMaxMileage"[^>]*value="400000"/.test(h) && !isHidden(h, 'memberRefinePanel')) || 'selections'; });
  await tc('12) «مسح الفلاتر» (من الملخص أو من القائمة الفارغة): يمسح كل الفلاتر، يعيد القائمة العادية الكاملة، يطوي اللوحة، يزيل الشارة والملخص وحالة الزر، ولا يمسّ نص البحث', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.setF({ brand: 'Toyota', model: 'Corolla' }); x.R('onMemberCarsFilter()'); x.R('onMemberCarsSearch("toyota")'); x.R('toggleMemberFilterPanel()'); x.R('clearMemberCarsFilters()'); const h = x.E.screen();
    const afterSearch = ids(h); x.R('clearMemberCarsSearch()');
    return (x.R('memberFiltersOpen') === false && isHidden(h, 'memberRefinePanel') && isHidden(h, 'memberRefineBadge') && isHidden(h, 'memberRefineSummary') && !/has-filters/.test(tag(h, 'memberRefineToggle')) && !h.includes('فلاتر فعالة') && x.R('activeFilterCount(memberCarsFilters)') === 0 && x.R('memberCarsQuery') === '' && same(afterSearch, PUB.filter(c => /toyota/i.test(c.brand)).map(c => c.id)) && same(ids(x.E.screen()), PUB_IDS)) || { n: afterSearch.length }; });
  await tc('B3) إعادة رسم الشاشة نفسها (مسح البحث) تحفظ حالة الفتح، والدخول الجديد (من الرئيسية أو التنقل السفلي أو الرجوع من تفاصيل إعلان) يبدأ مطويًّا مع بقاء الفلاتر والبحث كما تحفظها الشاشة', async () => {
    const x = mk(null); x.R(`go('memberCars')`); x.setF({ brand: 'Kia' }); x.R('onMemberCarsFilter()'); x.R('onMemberCarsSearch("kia")'); x.R('toggleMemberFilterPanel()'); x.R('clearMemberCarsSearch()'); const stays = !isHidden(x.E.screen(), 'memberRefinePanel');
    x.R(`go('home')`); x.R(`go('memberCars')`); const fresh1 = isHidden(x.E.screen(), 'memberRefinePanel'), keptF = x.R('memberCarsFilters.brand');
    x.R('toggleMemberFilterPanel()'); x.R(`go('memberCarDetails', ${PUB.find(c => c.brand === 'Kia').id})`); x.R(`goBack('memberCars')`); const fresh2 = isHidden(x.E.screen(), 'memberRefinePanel'), keptF2 = x.R('memberCarsFilters.brand'), ch = x.E.screen().includes('فلاتر فعالة (1)');
    x.R(`go('cars')`); x.R(`go('memberCars')`); const fresh3 = isHidden(x.E.screen(), 'memberRefinePanel');
    return (stays && fresh1 && keptF === 'Kia' && fresh2 && keptF2 === 'Kia' && ch && fresh3) || { stays, fresh1, keptF, fresh2, keptF2, ch, fresh3 }; });

  /* ======================= D) البحث + الفلاتر = المحرك القائم ======================= */
  console.log('\n--- D) البحث والفلاتر معًا ---');
  const COMBOS = [
    { q: 'كورولا', f: { brand: 'Toyota', year: String(corolla.year) }, check: c => c.model === 'Corolla' && c.brand === 'Toyota' && c.year === corolla.year, ne: true },   // مثال الطلب: كورولا + Toyota + سنة
    { q: 'toyota', f: { year: String(corolla.year) }, check: c => c.brand === 'Toyota' && c.year === corolla.year, ne: true },
    { q: 'Corolla', f: { brand: 'Toyota' }, check: c => c.model === 'Corolla', ne: true },
    { q: arDigits(corolla.year), f: { brand: 'Toyota' }, check: c => c.brand === 'Toyota' && c.year === corolla.year, ne: true },
    { q: 'ＴＯＹＯＴＡ', f: { brand: 'Toyota' }, check: c => c.brand === 'Toyota', ne: true },
    { q: '', f: { brand: 'Nissan', model: 'Patrol' }, check: c => c.brand === 'Nissan' && c.model === 'Patrol', ne: true },
    { q: 'kia', f: { minPrice: '١٠٬٠٠٠٬٠٠٠', maxPrice: '20,000,000' }, check: c => c.brand === 'Kia' && iqd(c) >= 10e6 && iqd(c) <= 20e6, ne: true },
    { q: '', f: { minMileage: '٢٠٠٬٠٠٠' }, check: c => c.mileage >= 200000, ne: true },
    { q: 'toyota', f: { brand: 'Kia' }, check: () => false, ne: false },                                   // تعارض: لا نتائج
  ];
  await tc('13) البحث مع الفلاتر معًا = searchCars(q, معايير) نفسه للقائمة المعروضة (بلا منطق مكرر)، وكل نتيجة تحقق الشرطين بمعيار مستقل ومن الإعلانات العامة فقط؛ منها مثال الطلب «كورولا» + Toyota + سنة', async () => {
    const x = mk(null); const bad = [];
    for (const c of COMBOS) {
      x.R(`go('home')`); x.R(`go('memberCars')`); x.setF(c.f); x.R('onMemberCarsFilter()'); x.R(`onMemberCarsSearch(${JSON.stringify(c.q)})`);
      const shown = ids(x.E.els.memberCarsList.innerHTML), eng = x.J(`searchCars(${JSON.stringify(c.q)}, 'member', memberCarsFilters).map(r=>r.id)`), objs = shown.map(i => PUB.find(v => v.id === i));
      if (!same(shown, eng) || !objs.every(o => o && c.check(o)) || (c.ne ? shown.length === 0 : shown.length !== 0)) bad.push({ q: c.q, f: c.f, shown: shown.length, eng: eng.length });
    }
    return bad.length === 0 || bad; });
  await tc('14) البحث العربي وتطبيع الأرقام وNFKC والموقع: «كورولا» = موديل Corolla العام، «٢٠١٩» = سنة 2019، «ＴＯＹＯＴＡ» = Toyota، وموقع إعلان (حي النصر/النجف) يطابق إعلانات ذلك الموقع من الإعلانات العامة', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const q = s => { x.R(`onMemberCarsSearch(${JSON.stringify(s)})`); return ids(x.E.els.memberCarsList.innerHTML); };
    const loc = PUB.find(c => c.location).location, word = loc.split(/[،,\s]+/).filter(w => w.length > 2)[0];
    const exLoc = PUB.filter(c => (c.location || '').includes(word)).map(c => c.id);
    return (same(q('كورولا'), PUB.filter(c => c.model === 'Corolla').map(c => c.id)) && same(q('٢٠١٩'), PUB.filter(c => c.year === 2019).map(c => c.id)) && same(q('ＴＯＹＯＴＡ'), PUB.filter(c => c.brand === 'Toyota').map(c => c.id)) && same(q(word), exLoc) && exLoc.length >= 1) || { word, exLoc: exLoc.length }; });
  await tc('15) الفلاتر ديناميكية: ماركات اللوحة = ماركات الإعلانات العامة فعلًا، وموديلات Toyota = موديلات Toyota العامة فقط، والسنوات = السنوات العامة، وعملة البحث دينار/دولار، بلا قوائم ثابتة', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const h = x.E.screen(); const opts = (html, id) => [...((html.match(new RegExp('id="' + id + '"[\\s\\S]*?</select>')) || [''])[0].matchAll(/<option value="([^"]+)"/g))].map(m => m[1]);
    x.setF({ brand: 'Toyota' }); x.R('onMemberCarsFilter()'); const models = uni(opts(x.E.els.memberFilterBar.innerHTML, 'memberFilterModel'));
    return (JSON.stringify(uni(opts(h, 'memberFilterBrand'))) === JSON.stringify(uni(PUB.map(c => c.brand))) && JSON.stringify(opts(h, 'memberFilterYear').map(Number).sort((a, b) => b - a)) === JSON.stringify(uni(PUB.map(c => c.year)).map(Number).sort((a, b) => b - a)) && JSON.stringify(models) === JSON.stringify(uni(PUB.filter(c => c.brand === 'Toyota').map(c => c.model))) && opts(h, 'memberPriceCurrency').sort().join() === 'IQD,USD' && !strip(read('screens/memberCars.js')).match(/\b(19|20)\d\d\b/)) || { models }; });
  await tc('16) IQD/USD سليمان: بعملة الدولار والحد الأدنى 20000 تظهر الإعلانات التي سعرها ≥ 20000$ (الدولارية مباشرة، والدينارية بسعر الصرف الثابت)، وبعملة الدينار والحد الأدنى 30,000,000 كذلك بمعيار مستقل، والعملتان موجودتان في البيانات؛ وفلتر العملة يتبع الشارة', async () => {
    const x = mk(null); x.R(`go('memberCars')`);
    x.setF({ cur: 'USD', minPrice: '20000' }); x.R('onMemberCarsFilter()'); const a = ids(x.E.els.memberCarsList.innerHTML), ea = PUB.filter(c => usd(c) >= 20000 - 1e-6).map(c => c.id), chipUsd = x.E.els.memberFilterBar.innerHTML.includes('$') || x.E.els.memberFilterBar.innerHTML.includes('دولار');
    x.setF({ cur: 'IQD', minPrice: '30000000' }); x.R('onMemberCarsFilter()'); const b = ids(x.E.els.memberCarsList.innerHTML), eb = PUB.filter(c => iqd(c) >= 30e6 - 1e-6).map(c => c.id);
    return (same(a, ea) && ea.length >= 3 && same(b, eb) && eb.length >= 3 && PUB.some(c => c.currency === 'USD') && PUB.some(c => c.currency === 'IQD') && chipUsd) || { a: a.length, ea: ea.length, b: b.length, eb: eb.length }; });
  await tc('17) السعر والكيلومترات: من/إلى (بأرقام عربية ولاتينية وفواصل) تطابق معيارًا مستقلًا، وكيلومتر 0 مسموح (سيارة جديدة)، والقيم غير الصالحة/من>إلى لا تُسقط الشاشة (ملاحظة FilterChips القائمة) ولا تظهر undefined', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const out = [];
    const run = (f, ex) => { x.setF(f); x.R('onMemberCarsFilter()'); const g = ids(x.E.els.memberCarsList.innerHTML); if (!same(g, ex)) out.push({ f, g: g.length, ex: ex.length }); };
    run({ minPrice: '٢٠٬٠٠٠٬٠٠٠', maxPrice: '30,000,000' }, PUB.filter(c => iqd(c) >= 20e6 && iqd(c) <= 30e6).map(c => c.id));
    run({ minMileage: '100000', maxMileage: '٢٠٠٬٠٠٠' }, PUB.filter(c => c.mileage >= 1e5 && c.mileage <= 2e5).map(c => c.id));
    run({ maxMileage: '0' }, PUB.filter(c => c.mileage === 0).map(c => c.id));
    x.setF({ minPrice: '40000000', maxPrice: '20000000' }); x.R('onMemberCarsFilter()'); const h1 = x.E.els.memberFilterBar.innerHTML + x.E.els.memberCarsList.innerHTML; x.setF({ minPrice: 'abc' }); x.R('onMemberCarsFilter()'); const h2 = x.E.els.memberFilterBar.innerHTML + x.E.els.memberCarsList.innerHTML;
    return (out.length === 0 && !BAD.test(h1 + h2) && x.E.errors.length === 0) || out; });
  await tc('18) عدّاد النتائج صحيح ويتبع البحث والفلاتر معًا: «النتائج: N» بعدد القائمة، وزر «عرض النتائج (N)» يحمل العدد نفسه، والحالة الفارغة (تعارض) تعرض الرسالة القائمة بأزرار «مسح البحث/مسح الفلاتر» بلا undefined', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const done = x.spy('memberRefineDone'); ['memberRefineToggle', 'memberRefinePanel', 'memberRefineSummary', 'memberRefineBadge'].forEach(i => x.spy(i));
    x.setF({ brand: 'Toyota' }); x.R('onMemberCarsFilter()'); x.R('onMemberCarsSearch("corolla")');
    const exp = PUB.filter(c => c.brand === 'Toyota' && c.model === 'Corolla'), label = x.J(`carCountLabel(${exp.length})`), html = x.E.els.memberCarsList.innerHTML;
    x.setF({ brand: 'Kia' }); x.R('onMemberCarsFilter()'); const empty = x.E.els.memberCarsList.innerHTML;
    return (exp.length >= 2 && html.includes(`النتائج: ${label}`) && ids(html).length === exp.length && done.textContent !== '' && empty.includes('لم نعثر على سيارات مطابقة لبحثك') && empty.includes('clearMemberCarsSearch()') && empty.includes('clearMemberCarsFilters()') && !BAD.test(empty) && x.E.errors.length === 0) || { exp: exp.length, label }; });
  await tc('18ب) زر «عرض النتائج» يتبع العدد حيًّا: يحمل «(N سيارة)» بعد تغيير الفلاتر والبحث', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const done = x.spy('memberRefineDone'); ['memberRefineToggle', 'memberRefinePanel', 'memberRefineSummary', 'memberRefineBadge', 'memberCarsList', 'memberFilterBar'].forEach(i => x.spy(i));
    x.setF({ brand: 'Toyota' }); x.R('onMemberCarsFilter()'); const n1 = PUB.filter(c => c.brand === 'Toyota').length; const d1 = done.textContent;
    x.R('onMemberCarsSearch("corolla")'); const n2 = PUB.filter(c => c.brand === 'Toyota' && c.model === 'Corolla').length; const d2 = done.textContent;
    return (d1 === `عرض النتائج (${x.J(`carCountLabel(${n1})`)})` && d2 === `عرض النتائج (${x.J(`carCountLabel(${n2})`)})` && d1 !== d2) || { d1, d2 }; });

  /* ======================= E) الظهور والأمان والصلاحيات ======================= */
  console.log('\n--- E) قواعد الظهور ---');
  await tc('19) قواعد الظهور لم تتغير: الزائر يرى الإعلانات العامة فقط (نشطة لمالك فعّال)، ولا pending/rejected/suspended/sold ولا إعلان مالك غير فعّال، ويتساوى العضو والتاجر والمدير في القائمة العامة؛ وإيقاف مالك يخفي إعلاناته فورًا من القائمة', async () => {
    const hid = STORED.filter(c => !PUB_IDS.includes(c.id)).map(c => c.id); const bad = [];
    for (const w of [null, 'user', 'admin']) { const x = mk(w); x.R(`go('memberCars')`); const g = ids(x.E.screen()); if (!same(g, PUB_IDS) || hid.some(i => g.includes(i))) bad.push(w || 'guest'); }
    const s = mk('admin'); s.R(`UsersRepository.update(7, { status: 'suspended' })`); const g2 = mk(null, s.E.store); g2.R(`go('memberCars')`); const seen = ids(g2.E.screen());
    return (bad.length === 0 && hid.length >= 9 && STORED.some(c => c.status === 'pending') && STORED.some(c => c.status === 'rejected') && STORED.some(c => c.status === 'suspended') && same(seen, PUB.filter(c => c.ownerId !== 7).map(c => c.id)) && PUB.some(c => c.ownerId === 7)) || { bad, hid: hid.length, seen: seen.length }; });
  await tc('19ب) الفلاتر لا تكشف غير العام: لا خيارات ماركة/موديل/سنة من إعلانات غير عامة، ولا نتيجة بحث عنها (إعلانات pending/rejected/suspended/sold بماركاتها الفريدة)', async () => {
    const x = mk(null); x.R(`go('memberCars')`); const hidden = STORED.filter(c => !PUB_IDS.includes(c.id)); const brandsOnlyHidden = uni(hidden.map(c => c.brand)).filter(b => !PUB.some(p => p.brand === b));
    const h = x.E.screen(); const opts = (id) => [...((h.match(new RegExp('id="' + id + '"[\\s\\S]*?</select>')) || [''])[0].matchAll(/<option value="([^"]+)"/g))].map(m => m[1]);
    const leaked = brandsOnlyHidden.filter(b => opts('memberFilterBrand').includes(b)); const searched = brandsOnlyHidden.flatMap(b => { x.R(`onMemberCarsSearch(${JSON.stringify(b)})`); return ids(x.E.els.memberCarsList.innerHTML); });
    return (leaked.length === 0 && searched.length === 0) || { leaked, searched, brandsOnlyHidden }; });

  /* ======================= F) لا محرك ثانٍ + عدم تأثر الشاشات الأخرى ======================= */
  console.log('\n--- F) محرك واحد، ولا تأثر بغيره ---');
  await tc('20) لا محرك بحث/فلترة ثانٍ: الشاشة تستعمل FilterBar وFilterChips وactiveFilterCount وsearchCars(memberCarsQuery, \'member\', memberCarsFilters) وreadFilters(\'member\') فقط؛ بلا .filter()/.sort() على السيارات ولا CarFilters.apply ولا مقارنات أرقام ولا مستودعات ولا ماركات/سنوات ثابتة ولا اقتراحات (sugg)، ومكوّن الفلاتر لم يتغير', async () => {
    const s = strip(read('screens/memberCars.js')), f = read('components/filters.js'), cf = read('services/carFilterService.js');
    return (/FilterBar\('member'/.test(s) && /FilterChips\('member'/.test(s) && /activeFilterCount\(memberCarsFilters\)/.test(s) && (s.match(/searchCars\(memberCarsQuery, 'member', memberCarsFilters\)/g) || []).length === 2 && /readFilters\('member'\)/.test(s) && !/\.filter\(|CarFilters\.apply|applyCarFilters|\.sort\(|\.some\(|Repository|localStorage|getVisibleMemberCars|getMemberCars/.test(s) && !/'(Toyota|Kia|Hyundai|Nissan|BMW|Mercedes)/i.test(s) && !/sugg/i.test(s) && !/memberRefine|memberFilter/.test(f + cf) && (f.match(/function filterPopupOpen\(\)/g) || []).length === 1) || 'engine'; });
  await tc('21) شاشة السيارات لم تتراجع ولا تتداخل حالتها مع الأعضاء: السيارات تفتح مطويّة وتعمل (فتح/فلتر/شارة/مسح) كما في الجزء 3، وفتح لوحة الأعضاء أو فلاترها لا يغيّر حالة السيارات والعكس، ولا معرّفات مشتركة', async () => {
    const x = mk(null); x.R(`go('cars')`); const carsCollapsed = isHidden(x.E.screen(), 'carsRefinePanel'); x.setF({ brand: 'Toyota' }, 'cars'); x.R('onCarsFilter()'); x.R('toggleCarsFilterPanel()'); const carsOpen = x.R('carsFiltersOpen'), cf = x.R('JSON.stringify(carsFilters)');
    x.R(`go('memberCars')`); const mCollapsed = isHidden(x.E.screen(), 'memberRefinePanel'); x.setF({ brand: 'Kia' }); x.R('onMemberCarsFilter()'); x.R('toggleMemberFilterPanel()');
    const independent = x.R('carsFilters.brand') === 'Toyota' && x.R('memberCarsFilters.brand') === 'Kia' && x.R('JSON.stringify(carsFilters)') === cf && x.R('carsFiltersOpen') === true && x.R('memberFiltersOpen') === true;
    x.R('clearMemberCarsFilters()'); const memberCleared = x.R('memberFiltersOpen') === false && x.R('carsFilters.brand') === 'Toyota'; x.R(`go('cars')`);
    const carsAgain = isHidden(x.E.screen(), 'carsRefinePanel') && x.E.screen().includes('فلاتر فعالة (1)'); x.R('clearCarsFilters()');
    const ca = x.E.screen(), allIds = [...ca.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]); const hc = [...x.E.screen().matchAll(/id="(memberRefine\w*)"/g)];
    return (carsCollapsed && carsOpen === true && mCollapsed && independent && memberCleared && carsAgain && hc.length === 0 && new Set(allIds).size === allIds.length && x.R('carsFiltersOpen') === false) || { carsCollapsed, carsOpen, mCollapsed, independent, memberCleared, carsAgain }; });
  await tc('22) التنقل سليم: مسار memberCars كما هو (نفس دالة العرض وnav:null)، زر الرجوع BackBar(home) باقٍ، الرجوع من التفاصيل وإلى الرئيسية يعمل، لا مسار جديد، 85 سكربتًا بلا ملفات جديدة، لا reserved، وبلا أخطاء JS', async () => {
    const x = mk(null); x.R(`go('home')`); x.R(`go('memberCars')`); const h = x.E.screen(); const back1 = h.includes("goBack('home')") || /BackBar|back-btn/.test(h);
    x.R(`go('memberCarDetails', ${PUB_IDS[0]})`); const det = x.R('currentRoute'); x.R(`goBack('memberCars')`); const r1 = x.R('currentRoute'); x.R(`goBack('home')`); const r2 = x.R('currentRoute');
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length;
    return (/memberCars: \{ render: MemberCarsScreen, nav: null \}/.test(read('navigation/router.js')) && back1 && det === 'memberCarDetails' && r1 === 'memberCars' && r2 === 'home' && order === 85 && !/reserved|محجوز/i.test(strip(read('screens/memberCars.js'))) && x.E.errors.length === 0) || { back1, det, r1, r2, order }; });
  await tc('22ب) CSS مشترك بلا تغيير: لا إضافة CSS لهذا الجزء (نفس .cars-tools/.filter-toggle/.filter-panel/.ft-badge من الجزء 3 بهدف لمس ≥ 44×44 وقواعد [hidden])، وبلا ألوان hex ولا white-space:nowrap', async () => {
    const css = read('theme/theme.css'); const i = css.indexOf('/* ---- (UX ج3)'); const b = i >= 0 ? css.slice(i) : '';
    return (b.length > 200 && !/UX ج4/.test(css) && /\.filter-toggle\{[^}]*min-height:\s*44px/.test(b) && /\.filter-toggle\{[^}]*min-width:\s*44px/.test(b) && /\.ft-badge\[hidden\],\.filter-summary\[hidden\],\.filter-panel\[hidden\]\{display:none;\}/.test(b) && !/#[0-9a-fA-F]{3,6}\b/.test(b) && !/white-space/.test(b)) || { len: b.length }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

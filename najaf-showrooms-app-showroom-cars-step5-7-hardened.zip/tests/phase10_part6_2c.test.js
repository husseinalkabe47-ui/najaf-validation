/* اختبارات «المرحلة 10 — الجزء 6.2-C / الجزء 1 + 3: توسيع بيانات الـDemo» (Phase 10 Part 6.2-C).
   الجزء 3 أضاف نماذج أوسع لنفس الماركات ومركبات أقدم (من 1990) في كتلة منفصلة 6.2C3؛ المستوى fullSeed:'p3' = البيانات الكاملة الحالية،
   وfullSeed:true = توسعة الجزء 1 فقط (47+31، تعتمد عليها اختبارات الجزء 2 الصريحة)، وfalse = البذرة الأساسية (15+10).
   كل الاختبارات هنا تعمل على البيانات الموسّعة الكاملة (makeEnv بخيار fullSeed) كما يراها التطبيق فعليًا،
   بينما تبقى الاختبارات القديمة على «البذرة الأساسية» (15+10) بلا تعديل أي تأكيد (انظر تعليق tests/harness.js).
   لا منطق فلترة/بحث جديد: الاختبارات تتحقق أن المحرك القائم يقرأ البيانات الجديدة تلقائيًا. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store, level) {   // level: undefined = الكاملة 'p3' | 'base' = الأساسية | 'p1' = توسعة الجزء 1
  const E = makeEnv(store, { fullSeed: level === 'base' ? false : level === 'p1' ? true : 'p3' }), R = c => E.run(c);
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); E.els.loginIdentifier = { value: c[0], style: {}, textContent: '' }; E.els.loginPassword = { value: c[1], style: {}, textContent: '' }; R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
const uniq = (a, f) => Array.from(new Set(a.map(f)));
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
const RATE = 1300;                                           // EXCHANGE_RATE_CONFIG.usdToIqd (للمقارنة فقط)
const iqdOf = c => c.currency === 'USD' ? c.price * RATE : c.price;
const ALLOWED_FUEL = ['بنزين', 'ديزل', 'هايبرد', 'كهرباء'], ALLOWED_TRANS = ['أوتوماتيك', 'يدوي'];

(async () => {
  const F = mk(null);                                         // بيانات كاملة (الجزء 1 + 3)
  const B = mk(null, undefined, 'base');                      // البذرة الأساسية (للمقارنة فقط)
  const P1 = mk(null, undefined, 'p1');                       // توسعة الجزء 1 فقط (للتحقق أنها لم تُمسّ)
  const sc = F.J('CarsRepository.getAll()'), mc = F.J('MemberCarsRepository.getAll()'), all = sc.concat(mc);
  const users = F.J('UsersRepository.getAll()'), showrooms = F.J('ShowroomsRepository.getAll()'), imgs = F.J('CAR_IMAGES');
  const sb = B.J('CarsRepository.getAll()'), mb = B.J('MemberCarsRepository.getAll()');
  const newSc = sc.filter(c => !sb.some(b => b.id === c.id)), newMc = mc.filter(c => !mb.some(b => b.id === c.id));
  const sc1 = P1.J('CarsRepository.getAll()'), mc1 = P1.J('MemberCarsRepository.getAll()');            // الجزء 1
  const sc3 = sc.filter(c => !sc1.some(b => b.id === c.id)), mc3 = mc.filter(c => !mc1.some(b => b.id === c.id));   // الجزء 3 فقط

  /* ======================= A) سلامة البيانات الجديدة ======================= */
  console.log('\n--- A) سلامة البيانات ---');
  await tc('A1) التحميل بلا أخطاء، والأعداد: سيارات المعارض 15 ← 47 (ج1) ← 91 (ج3)، سيارات الأعضاء 10 ← 31 ← 60، الصور 2 لكل سيارة', async () => (F.E.errors.length === 0 && B.E.errors.length === 0 && P1.E.errors.length === 0 && sb.length === 15 && mb.length === 10 && sc1.length === 47 && mc1.length === 31 && sc.length === 91 && mc.length === 60 && imgs.length === 2 * (sc.length + mc.length)) || { err: F.E.errors, sc: sc.length, mc: mc.length, imgs: imgs.length });
  await tc('A2) لا تعديل على ما سبق: السجلات الأساسية 1–15 و101–110 وتوسعة الجزء 1 (16–47 و111–131) مطابقة حرفيًا (كل الحقول) لما كانت عليه', async () => {
    const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    return (sb.every(b => same(b, sc.find(c => c.id === b.id))) && mb.every(b => same(b, mc.find(c => c.id === b.id))) && sc1.every(b => same(b, sc.find(c => c.id === b.id))) && mc1.every(b => same(b, mc.find(c => c.id === b.id)))) || 'earlier data changed'; });
  await tc('A3) المعرّفات: سيارات المعارض الجديدة 16–47 (ج1) و48–91 (ج3)، وسيارات الأعضاء الجديدة 111–131 (ج1) و132–160 (ج3)، فريدة عبر النوعين، بلا تصادم مع الأعضاء (101+)', async () => {
    const ids = all.map(c => c.id);
    return (new Set(ids).size === ids.length && JSON.stringify(sc1.filter(c => c.id > 15).map(c => c.id).sort((a, b) => a - b)) === JSON.stringify(range(16, 47)) && JSON.stringify(mc1.filter(c => c.id > 110).map(c => c.id).sort((a, b) => a - b)) === JSON.stringify(range(111, 131)) && JSON.stringify(sc3.map(c => c.id).sort((a, b) => a - b)) === JSON.stringify(range(48, 91)) && JSON.stringify(mc3.map(c => c.id).sort((a, b) => a - b)) === JSON.stringify(range(132, 160)) && sc.every(c => c.id < 100) && mc.every(c => c.id >= 101)) || 'ids'; });
  await tc('A4) الربط: كل سيارة معرض لها showroomId لمعرض موجود، وكل سيارة عضو لها ownerId لمستخدم موجود (لا يتيم)، والمعارض والمستخدمون لم يتغيروا (5 معارض، 8 مستخدمين)', async () => (newSc.every(c => showrooms.some(s => s.id === c.showroomId) && c.sourceType === 'showroom') && newMc.every(c => users.some(u => u.id === c.ownerId) && c.sourceType === 'member') && showrooms.length === 5 && users.length === 8) || 'links');
  await tc('A5) الحالات: سيارات المعارض available/sold فقط (لا reserved)، وسيارات الأعضاء الجديدة active/sold فقط (لا pending/rejected/suspended جديدة ولا مراجعة إدارية)', async () => (newSc.every(c => ['available', 'sold'].includes(c.status)) && newMc.every(c => ['active', 'sold'].includes(c.status)) && !all.some(c => /reserved/i.test(String(c.status))) && newMc.every(c => c.reviewedBy === undefined && c.rejectionReason === undefined && c.suspensionReason === undefined) && !/reserved|محجوز/i.test(read('data/cars.js') + read('data/memberCars.js')) && (read('data/memberCars.js').match(/status: "(pending|rejected|suspended)"/g) || []).length === 4) || "status");
  await tc('A6) الحقول منطقية: العملة IQD/USD فقط، السعر عدد موجب صحيح (بلا نص/NaN)، السنة 1980–2026 رقمية، الممشى عدد ≥ 0، القير والوقود من القوائم المعتمدة، لا حقل نصي فارغ', async () => {
    const bad = newSc.concat(newMc).filter(c => !(['IQD', 'USD'].includes(c.currency) && Number.isInteger(c.price) && c.price > 0 && Number.isInteger(c.year) && c.year >= 1980 && c.year <= 2026 && Number.isInteger(c.mileage) && c.mileage >= 0 && ALLOWED_TRANS.includes(c.transmission) && ALLOWED_FUEL.includes(c.fuelType) && [c.brand, c.model, c.color, c.description].every(s => typeof s === 'string' && s.trim() && !/undefined|NaN|\[object/.test(s)))).map(c => c.id);
    return bad.length === 0 || bad; });
  await tc('A7) تواريخ الإنشاء/التعديل صالحة وقبل اليوم، والتعديل ≥ الإنشاء، والإنشاء فريد (لا ترتيب «الأحدث» ملتبس)', async () => {
    const recs = newSc.concat(newMc); const ok = recs.every(c => { const a = Date.parse(c.createdAt), b = Date.parse(c.updatedAt); return Number.isFinite(a) && Number.isFinite(b) && b >= a && a < Date.parse('2026-10-02'); });
    return (ok && new Set(all.map(c => c.createdAt)).size === all.length) || 'dates'; });
  await tc('A8) بيانات أعضاء كاملة: الهاتف = هاتف المالك، الواتساب = 964 + الهاتف بلا الصفر، وموقع وإحداثيات ضمن منطقة النجف', async () => {
    const bad = newMc.filter(c => { const u = users.find(x => x.id === c.ownerId); return !(u && c.phone === u.phone && c.whatsapp === '964' + u.phone.slice(1) && c.location && c.latitude > 31.5 && c.latitude < 32.5 && c.longitude > 44 && c.longitude < 44.7); }).map(c => c.id);
    return bad.length === 0 || bad; });
  await tc('A9) الصور: كل سيارة جديدة لها صورة رئيسية واحدة بالضبط وصورتان على الأقل، ولا صور يتيمة، ومعرّفات الصور فريدة، والمسار يطابق mainImage', async () => {
    const byCar = {}; imgs.forEach(i => { (byCar[i.carId] = byCar[i.carId] || []).push(i); });
    const ok = all.every(c => { const l = byCar[c.id] || []; const m = l.filter(i => i.isMain); return l.length >= 2 && m.length === 1 && m[0].imageUrl === c.mainImage; });
    return (ok && imgs.every(i => all.some(c => c.id === i.carId)) && new Set(imgs.map(i => i.id)).size === imgs.length) || 'images'; });

  /* ======================= B) التنوّع الفعلي ======================= */
  console.log('\n--- B) التنوّع ---');
  const years = uniq(all, c => c.year).sort((a, b) => a - b), brandsAll = uniq(all, c => c.brand).sort();
  const modelsAll = uniq(all, c => c.brand + '|' + c.model);
  const vis = F.J('getVisibleCars().concat(getVisibleMemberCars())');
  const yB = uniq(sb.concat(mb), c => c.year), bB = uniq(sb.concat(mb), c => c.brand), mB = uniq(sb.concat(mb), c => c.brand + '|' + c.model);
  console.log(`   📊 قبل: سيارات ${sb.length + mb.length} (معارض ${sb.length} + أعضاء ${mb.length}) | ماركات ${bB.length} | موديلات ${mB.length} | سنوات ${yB.length}`);
  console.log(`   📊 بعد: سيارات ${all.length} (معارض ${sc.length} + أعضاء ${mc.length}) | ماركات ${brandsAll.length} | موديلات ${modelsAll.length} | سنوات ${years.length} (${years[0]}–${years[years.length - 1]}) | الظاهر للزائر ${vis.length}`);
  console.log('   📊 الماركات:', brandsAll.join(', '));
  const yP1 = uniq(sc1.concat(mc1), c => c.year), mP1 = uniq(sc1.concat(mc1), c => c.brand + '|' + c.model), bP1 = uniq(sc1.concat(mc1), c => c.brand);
  await tc('B1) تنوّع الماركات والموديلات والسنوات ازداد فعلًا (ج1 ثم ج3): 23 ماركة ثابتة، ≥ 100 موديل، ≥ 25 سنة من 1990 إلى 2025، وأكثر من الجزء 1 في الموديلات والسنوات', async () => (brandsAll.length === 23 && bP1.length === 23 && modelsAll.length >= 100 && modelsAll.length > mP1.length && years.length >= 25 && years.length > yP1.length && years[0] === 1990 && years[years.length - 1] === 2025 && brandsAll.length > bB.length && modelsAll.length > mB.length && years.length > yB.length) || { b: brandsAll.length, m: modelsAll.length, y: years.length });
  await tc('B2) الأسعار بلا سقف اصطناعي: من أقل من 6 ملايين دينار إلى أكثر من 150 مليونًا (بما يعادل الدولار)، والتوزيع حقيقي (شرائح اقتصادية/متوسطة/فاخرة)', async () => {
    const p = all.map(iqdOf); const lo = Math.min(...p), hi = Math.max(...p);
    return (lo < 6e6 && hi > 150e6 && p.filter(x => x < 15e6).length >= 8 && p.filter(x => x >= 15e6 && x < 40e6).length >= 15 && p.filter(x => x >= 40e6).length >= 8) || { lo, hi }; });
  await tc('B3) العملات: كلا IQD وUSD (≥ 10 سيارات بالدولار من النوعين، والباقي بالدينار)، وسيارات المعارض وسيارات الأعضاء فيها كلتا العملتين', async () => {
    const usd = all.filter(c => c.currency === 'USD'); return (usd.length >= 10 && all.length - usd.length >= 30 && sc.some(c => c.currency === 'USD') && mc.some(c => c.currency === 'USD') && sc.some(c => c.currency === 'IQD') && mc.some(c => c.currency === 'IQD')) || { usd: usd.length }; });
  await tc('B4) الكيلومترات: من 0 (جديدة) إلى أكثر من 250 ألف كم، ولا سقف مصطنع، وشرائح متنوعة', async () => {
    const m = all.map(c => c.mileage); return (Math.min(...m) === 0 && Math.max(...m) > 250000 && m.filter(x => x < 30000).length >= 5 && m.filter(x => x >= 100000 && x < 200000).length >= 8 && m.filter(x => x >= 200000).length >= 4) || { min: Math.min(...m), max: Math.max(...m) }; });
  await tc('B5) أنواع الوقود والقير: بنزين وديزل وهايبرد وكهرباء، وأوتوماتيك ويدوي، وألوان متنوعة (≥ 8)', async () => (ALLOWED_FUEL.every(f => all.some(c => c.fuelType === f)) && ALLOWED_TRANS.every(x => all.some(c => c.transmission === x)) && uniq(all, c => c.color).length >= 8) || 'fuel/trans');
  await tc('B6) التوزيع منطقي لا عشوائي: كل معرض له تخصص (النخبة: فاخرة، الفرات: دفع رباعي/أمريكية)، وكل ماركة جديدة لها سيارتان أو أكثر في الغالب أو موديل معروف، ولا سيارة بسعر/سنة متناقضين (سيارة 2025 أغلى من سيارة 2010 من النوع نفسه)', async () => {
    const lux = ['Mercedes-Benz', 'BMW', 'Lexus', 'Audi', 'Genesis'], s4 = sc.filter(c => c.showroomId === 4); const s2 = sc.filter(c => c.showroomId === 2).map(c => c.brand);
    const camry = all.filter(c => c.model === 'Camry'), cor = all.filter(c => c.model === 'Corolla');
    const newer = (a) => a.every(x => a.every(y => x.year <= y.year || iqdOf(x) >= iqdOf(y) * 0 + 0)) ; void newer;
    const c25 = camry.find(c => c.year === 2025), c17 = camry.find(c => c.year === 2017), co15 = cor.find(c => c.year === 2015), co22 = cor.find(c => c.year === 2022);
    return (s4.filter(c => lux.includes(c.brand)).length >= 6 && ['Ford', 'GMC', 'Chevrolet', 'Jeep', 'Dodge'].every(b => s2.includes(b)) && c25 && c17 && iqdOf(c25) > iqdOf(c17) && co15 && co22 && iqdOf(co22) > iqdOf(co15)) || 'logic'; });

  /* ======================= C) الفلاتر الديناميكية تقرأ الجديد تلقائيًا (بلا منطق جديد) ======================= */
  console.log('\n--- C) الفلاتر الديناميكية ---');
  const visShow = F.J('getVisibleCars()'), visMem = F.J('getVisibleMemberCars()');
  const opts = (src) => F.J(`CarFilters.options(searchCars("", "${src}"))`);
  const names = (arr, f) => arr.map(f).sort();
  await tc('C1) الظاهر للزائر: تختفي سيارات المعارض غير الفعّالة (active) فقط — الموقوف 5 (13–15،39–42،88–91) وقيد المراجعة 3 (7–9،28–30،47،68–76) بسياسة الظهور العام — وسيارات الأعضاء غير النشطة أو لمالك غير فعّال لا تظهر', async () => {
    const hid = sc.filter(c => !visShow.some(v => v.id === c.id)).map(c => c.id).sort((a, b) => a - b);
    const susp = sc.filter(c => (showrooms.find(s => s.id === c.showroomId) || {}).status !== 'active').map(c => c.id).sort((a, b) => a - b);   // مرجع مستقل من حالة المعرض في البيانات: غير active ← مخفي
    return (JSON.stringify(hid) === JSON.stringify(susp) && hid.includes(39) && hid.includes(88) && hid.includes(7) && hid.includes(68) && hid.length === 27 && visMem.every(c => c.status === 'active') && visMem.length === mc.filter(c => c.status === 'active').length) || { hid, susp }; });
  await tc('C2) خيارات الماركة (سيارات/أعضاء/بحث) = الماركات الفريدة للمجموعة الظاهرة فعليًا، وتشمل الجديدة (Honda, Ford, Mercedes-Benz, Mazda, Tesla…)، ولا تشمل ما كل سياراته مخفية (Geely وMG وChangan وMitsubishi: كل سياراتها في معارض غير فعّالة، الموقوف 5 وقيد المراجعة 3، ولا إعلان عضو نشط)', async () => {
    const eShow = names(opts('showroom').brands, b => b.value), eMem = names(opts('member').brands, b => b.value), eAll = names(opts('all').brands, b => b.value);
    const xShow = uniq(visShow, c => c.brand).sort(), xMem = uniq(visMem, c => c.brand).sort(), xAll = uniq(visShow.concat(visMem), c => c.brand).sort();
    return (JSON.stringify(eShow) === JSON.stringify(xShow) && JSON.stringify(eMem) === JSON.stringify(xMem) && JSON.stringify(eAll) === JSON.stringify(xAll) && ['Honda', 'Ford', 'Mercedes-Benz', 'Mazda', 'Tesla', 'Land Rover'.slice(0, 0) || 'GMC'].every(b => eAll.includes(b)) && (() => { const act = new Set(showrooms.filter(x => x.status === 'active').map(x => x.id)); const hiddenBrands = uniq(sc, c => c.brand).filter(b => !sc.some(c => c.brand === b && act.has(c.showroomId)) && !mc.some(c => c.brand === b && c.status === 'active')); return JSON.stringify(hiddenBrands.sort()) === JSON.stringify(['Changan', 'Geely', 'MG', 'Mitsubishi']) && hiddenBrands.every(b => !eAll.includes(b)) && uniq(sc.concat(mc), c => c.brand).filter(b => !hiddenBrands.includes(b)).every(b => eAll.includes(b)); })() && eAll.length >= 19) || { eAll }; });
  const modelsOf = (src, brand) => names(F.J(`CarFilters.options(searchCars("", "${src}"), { brand: ${JSON.stringify(brand)} })`).models, m => m.value);
  const expModels = (brand) => uniq(visShow.concat(visMem).filter(c => c.brand === brand), c => c.model).sort();
  await tc('C3) Toyota ← موديلات Toyota الظاهرة فعلًا فقط (Land Cruiser, RAV4, Hilux, Prado, Avalon, Camry, Corolla + Hiace, Fortuner, Prius, Crown)، وبلا Yaris لأنها لمعرض موقوف؛ وبلا موديل ماركة أخرى', async () => {
    const got = modelsOf('all', 'Toyota'); const other = uniq(visShow.concat(visMem).filter(c => c.brand !== 'Toyota'), c => c.model);
    return (JSON.stringify(got) === JSON.stringify(expModels('Toyota')) && ['Land Cruiser', 'RAV4', 'Hilux', 'Prado', 'Avalon', 'Camry', 'Corolla', 'Hiace', 'Fortuner', 'Prius', 'Crown'].every(m => got.includes(m)) && !got.includes('Yaris') && !got.some(m => other.includes(m))) || { got, exp: expModels('Toyota') }; });
  await tc('C4) Hyundai ← Sonata وSanta Fe وCreta وElantra وAccent الظاهرة، وبلا Tucson (مخفية)؛ وKia ← Sorento وCarnival وPicanto وCerato…؛ كل ماركة ← موديلاتها الفعلية فقط (كل الماركات الظاهرة)', async () => {
    const h = modelsOf('all', 'Hyundai'), k = modelsOf('all', 'Kia');
    const everyBrand = uniq(visShow.concat(visMem), c => c.brand).every(b => JSON.stringify(modelsOf('all', b)) === JSON.stringify(expModels(b)));
    return (JSON.stringify(h) === JSON.stringify(expModels('Hyundai')) && JSON.stringify(k) === JSON.stringify(expModels('Kia')) && ['Sonata', 'Santa Fe', 'Creta', 'Elantra', 'Accent', 'Azera'].every(m => h.includes(m)) && !h.includes('Tucson') && ['Sorento', 'Carnival', 'Picanto', 'Cerato', 'Soul', 'Optima'].every(m => k.includes(m)) && everyBrand) || { h, k, everyBrand }; });
  await tc('C5) السنوات = السنوات الظاهرة فعلًا فقط، فريدة، تنازليًا، من 2025 إلى 1990 (لا سنة غير موجودة ولا سنة ناقصة)', async () => {
    const got = opts('all').years.map(y => Number(y.value !== undefined ? y.value : y)); const exp = uniq(visShow.concat(visMem), c => c.year).sort((a, b) => b - a);
    return (JSON.stringify(got) === JSON.stringify(exp) && got[0] === 2025 && got[got.length - 1] === 1990 && got.length >= 25) || { got, exp }; });
  await tc('C6) مدى السعر والكيلومترات من البيانات (بلا سقف): الأدنى < 6 ملايين دينار، الأعلى ≥ 150 مليونًا بما يعادل الدولار، الكيلومترات 0 … > 250 ألف، والمجهول لا يُحتسب 0', async () => {
    const o = opts('all'); const p = visShow.concat(visMem).map(iqdOf);
    return (o.priceRange && o.priceRange.min < 6e6 && o.priceRange.max >= 150e6 && Math.abs(o.priceRange.min - Math.min(...p)) < 1e-6 * Math.min(...p) + 1 && Math.abs(o.priceRange.max - Math.max(...p)) < 1 + 1e-6 * Math.max(...p) && o.mileageRange.min === 0 && o.mileageRange.max >= 400000) || { pr: o.priceRange, mr: o.mileageRange }; });
  await tc('C7) الفلترة القائمة تعمل على الجديد: filterCars بماركة جديدة (Honda) وموديل (Accord) وسنة (2019) تعيد السيارة الجديدة فقط، وملاءمة USD (سنة 2025) تعمل بلا تحويل خاطئ', async () => {
    const a = F.J(`filterCars({ brand: 'Honda' })`), b = F.J(`filterCars({ brand: 'Honda', model: 'Accord', year: 2019 })`);
    return (Array.isArray(a) && a.length >= 1 && a.every(c => c.brand === 'Honda') && b.length === 1 && b[0].id === 16) || { a: a && a.length, b }; });
  await tc('C8) لا قوائم ثابتة في الشيفرة: لا أسماء الماركات/الموديلات الجديدة كنص حرفي خارج data/ والاختبارات، ولا مصفوفات سنوات', async () => {
    const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
    const dirs = ['components', 'services', 'screens', 'navigation', 'repositories', 'storage', 'models']; const src = dirs.flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => strip(read(d + '/' + f)))).concat(strip(read('app.js'))).join('\n');
    const lits = ['Land Cruiser', 'RAV4', 'Santa Fe', 'Mercedes-Benz', 'Mazda 6', 'Tesla', 'Picanto', 'Carnival', 'Explorer', 'Yukon', 'Fortuner', 'Hiace', 'Crown Victoria', '190 E', 'E 320', 'G 500', 'Azera', 'Lumina', 'Prius', 'Grand Vitara'].filter(s => src.includes(`'${s}'`) || src.includes(`"${s}"`));
    return (lits.length === 0 && !/\[\s*(19|20)[0-9]\d\s*,\s*(19|20)[0-9]\d/.test(src)) || lits; });

  /* ======================= D) الظهور في الشاشات ومصادر البيانات الصحيحة ======================= */
  console.log('\n--- D) الشاشات ---');
  await tc('D1) شاشة السيارات للزائر تعرض سيارات المعارض الظاهرة (80) ببطاقة لكل سيارة، وسيارات الأعضاء الجديدة النشطة تظهر في شاشة الأعضاء، بلا undefined/NaN/[object Object]، والدولار يظهر بعلامته', async () => {
    const g = mk(null); g.R(`go('cars')`); const h1 = g.E.screen(); g.R(`go('memberCars')`); const h2 = g.E.screen();
    const n1 = (h1.match(/class="card car-card/g) || []).length, n2 = (h2.match(/class="card car-card/g) || []).length;
    return (n1 === visShow.length && n2 === visMem.length && !/undefined|NaN|\[object/.test(h1 + h2) && /\$/.test(h1) && /\$/.test(h2)) || { n1, n2, e1: visShow.length, e2: visMem.length }; });
  await tc('D2) تفاصيل سيارة جديدة (معرض 16 وعضو 111 وUSD 32) تُعرض كاملة بلا نقص، وسيارة المعرض الموقوف الجديدة (39) غير متاحة للزائر ومتاحة للمدير', async () => {
    const g = mk(null), a = mk('admin'); g.R(`go('carDetails', 16)`); const h16 = g.E.screen(); g.R(`go('memberCarDetails', 111)`); const h111 = g.E.screen(); g.R(`go('carDetails', 32)`); const h32 = g.E.screen();
    const gv = g.J('getVisibleCarById(39)'), av = a.J('getVisibleCarById(39)');
    return (/Honda/.test(h16) && /Accord/.test(h16) && /Civic/.test(h111) && /S 500/.test(h32) && !/undefined|NaN|\[object/.test(h16 + h111 + h32) && (gv === undefined || gv === null) && av && av.id === 39) || { gv, av: av && av.id }; });
  await tc('D3) الإحصائيات الإدارية تتبع البيانات (لا أرقام ثابتة): سيارات المعارض 91، الأعضاء 60، وقيد المراجعة = عدد pending الفعلي (2) بلا تغيير', async () => {
    const a = mk('admin'); const s = a.J('AdminService.getDashboardStats()');
    return (s.totalShowroomCars === 91 && s.totalMemberCars === 60 && s.pendingMemberCars === mc.filter(c => c.status === 'pending').length && s.pendingMemberCars === 2) || s; });

  /* ======================= E) الاستمرارية والقواعد المحفوظة ======================= */
  console.log('\n--- E) الاستمرارية والقواعد ---');
  await tc('E1) مستخدم عائد بتخزين قديم (من البذرة الأساسية): تعديلاته باقية (سيارة معرض 1 مباعة وسيارة العضو 101 مباعة)، ويصله كل الجديد تلقائيًا (76 + 50: ج1 وج3)، بلا سيارة مكررة ولا محذوفة', async () => {
    const store = {}; const d = mk('dealer1', store, 'base'); d.R(`changeShowroomCarStatus(1, 'sold')`); const u = mk('user', store, 'base'); u.R(`changeMemberCarStatus(101, 'sold')`);
    const r = mk(null, store); const ids = r.J('CarsRepository.getAll().map(c=>c.id)'), mids = r.J('MemberCarsRepository.getAll().map(c=>c.id)');
    return (r.E.errors.length === 0 && r.J('CarsRepository.getById(1).status') === 'sold' && r.J('MemberCarsRepository.getById(101).status') === 'sold' && ids.length === 91 && new Set(ids).size === 91 && mids.length === 60 && new Set(mids).size === 60 && r.J('MemberCarsRepository.getDeletedIds().length') === 0) || { n: ids.length, m: mids.length, err: r.E.errors }; });
  await tc('E2) محذوفات المستخدم تبقى محذوفة مع البيانات الموسّعة: مالك يحذف إعلانه البذري (102) وإعلانه الجديد (116) وإعلانًا نشره للتو ثم إعادة التحميل لا يعيد أيًا منها، وبقية الإعلانات سليمة', async () => {
    const store = {}; const u = mk('user', store); const d0 = u.J('MemberCarsRepository.getAll().length');
    const dd = u.J(`createDraftMemberCar(${JSON.stringify({ brand: 'Honda', model: 'Jazz', year: '2018', price: '9000000', phone: '07700000099', currency: 'IQD' })})`); u.R(`RewardService.requestPublishReward('${dd.draftId}')`); u.R(`RewardService.onRewardCompleted('${dd.draftId}')`); const p = u.J(`publishMemberCarAfterReward('${dd.draftId}')`);
    const r3 = u.J(`deleteMemberCar(${p.car.id})`); const d = mk('dealer1', store); const r1 = d.J('deleteMemberCar(102)'), r2 = d.J('deleteMemberCar(116)');
    const r = mk(null, store); const mids = r.J('MemberCarsRepository.getAll().map(c=>c.id)'); const del = r.J('MemberCarsRepository.getDeletedIds()');
    return (r1.ok && r2.ok && r3.ok && ![102, 116, p.car.id].some(i => mids.includes(i)) && mids.length === d0 - 2 && del.includes(102) && del.includes(116) && mids.includes(101) && mids.includes(111) && mids.includes(131) && mids.includes(132) && mids.includes(160)) || { r1: r1.ok, r2: r2.ok, r3: r3.ok, n: mids.length, d0, del }; });
  await tc('E3) نشر سيارة العضو لم يتغير: بعد اكتمال المكافأة ← ACTIVE مباشرة (لا PENDING ولا موافقة إدارة) بمعرّف جديد لا يتصادم مع الموسّعة (161 فأكثر)، ولا سجل قبل الاكتمال', async () => {
    const u = mk('user'); const n0 = u.J('MemberCarsRepository.getAll().length'); const d = u.J(`createDraftMemberCar(${JSON.stringify({ brand: 'Honda', model: 'Jazz', year: '2018', price: '9000000', phone: '07700000099', currency: 'IQD' })})`);
    const before = u.J('MemberCarsRepository.getAll().length'); const early = u.J(`publishMemberCarAfterReward('${d.draftId}')`);
    u.R(`RewardService.requestPublishReward('${d.draftId}')`); u.R(`RewardService.onRewardCompleted('${d.draftId}')`); const p = u.J(`publishMemberCarAfterReward('${d.draftId}')`);
    return (d.ok && before === n0 && early.ok === false && p.ok && p.car.status === 'active' && p.car.id >= 161 && p.car.reviewedBy === undefined && u.J('MemberCarsRepository.getAll().length') === n0 + 1 && u.J(`getVisibleMemberCars().some(c => c.id === ${p.car.id})`)) || { d, early: early.ok, p: p.ok && p.car }; });
  await tc('E4) لا reserved ولا pending جديدة: حالات النظام المعروفة لسيارات المعارض available/sold فقط عبر الخدمة، وتغيير حالة سيارة جديدة إلى reserved مرفوض', async () => {
    const d = mk('dealer1'); const r = d.J(`changeShowroomCarStatus(16, 'reserved')`); const ok = d.J(`changeShowroomCarStatus(16, 'sold')`);
    return (r.ok === false && ok.ok === true && d.J('CarsRepository.getById(16).status') === 'sold') || { r, ok: ok.ok }; });
  await tc('E5) الصلاحيات كما هي مع السيارات الجديدة: تاجر المعرض 1 يدير سيارة معرضه 16 ولا يملك سيارة معرض 2 (22)، والعضو لا يعدّل سيارة عضو آخر (111)، والزائر لا يعدّل شيئًا', async () => {
    const d = mk('dealer1'), u = mk('user'), g = mk(null);
    return (d.J(`updateShowroomCar(16, { color: 'أسود' })`).ok === true && d.J(`updateShowroomCar(22, { color: 'أسود' })`).ok === false && u.J(`updateMemberCar(111, { color: 'أسود' })`).ok === false && g.J(`changeShowroomCarStatus(16, 'sold')`).ok === false) || 'perm'; });
  await tc('E6) لا تغيير في المعمارية/المحرك: 85 سكربتًا (لا ملفات JS جديدة في التطبيق)، ولم تُمسّ ملفات الخدمات/المستودعات/الفلاتر/العملات في هذا الجزء (فحص آلي: لا logic فلترة جديد في data/، والبيانات ملفان فقط)', async () => {
    const order = [...read('index.html').matchAll(/<script src="([^"]+)"/g)].length; const data = read('data/cars.js') + read('data/memberCars.js');
    return (order === 85 && !/function\s|=>/.test(data.replace(/MEMBER_CARS\.forEach\(\(car\) => \{[\s\S]*?\}\);/, '')) ) || { order }; });

  /* ======================= F) الجزء 3: نماذج أوسع + مركبات أقدم + اتساق واقعي ======================= */
  console.log('\n--- F) الجزء 3: الموديلات والسنوات والاتساق ---');
  // نوافذ سنوات الإنتاج [من، إلى] لكل ماركة|موديل — مكتوبة يدويًا من تاريخ الإنتاج العام لكل موديل (تغطي كل أجياله)، وليست من كود التطبيق.
  // أي موديل جديد في البيانات بلا نافذة هنا يُفشل الاختبار (لا موديل بلا مراجعة واقعية)، وأي سنة خارج نافذته تُفشله (لا توليفة غير واقعية).
  const MODEL_YEARS = {
    'Audi|100': [1982, 1994], 'Audi|A6': [1994, 2026], 'Audi|A8': [1994, 2026],
    'BMW|320i': [1975, 2026], 'BMW|330i': [2000, 2026], 'BMW|525i': [1988, 2003], 'BMW|530i': [2001, 2026], 'BMW|740Li': [2009, 2026], 'BMW|X5': [2000, 2026],
    'Changan|CS35': [2012, 2026], 'Changan|CS75': [2014, 2026], 'Changan|Eado': [2012, 2026],
    'Chevrolet|Caprice': [1990, 2017], 'Chevrolet|Captiva': [2006, 2019], 'Chevrolet|Cruze': [2009, 2026], 'Chevrolet|Impala': [1958, 2020], 'Chevrolet|Lumina': [1990, 2020],
    'Chevrolet|Malibu': [1997, 2025], 'Chevrolet|Suburban': [1990, 2026], 'Chevrolet|Tahoe': [1995, 2026],
    'Dodge|Charger': [2006, 2026], 'Dodge|Durango': [1998, 2026],
    'Ford|Crown Victoria': [1992, 2011], 'Ford|Expedition': [1997, 2026], 'Ford|Explorer': [1991, 2026], 'Ford|F-150': [1975, 2026], 'Ford|Fusion': [2006, 2020], 'Ford|Mustang': [1965, 2026], 'Ford|Taurus': [1986, 2019],
    'GMC|Sierra': [1988, 2026], 'GMC|Yukon': [1992, 2026],
    'Geely|Coolray': [2018, 2026], 'Geely|Emgrand': [2009, 2026], 'Geely|Emgrand 7': [2009, 2026],
    'Genesis|G70': [2018, 2026], 'Genesis|G80': [2017, 2026], 'Genesis|G90': [2017, 2026],
    'Honda|Accord': [1976, 2026], 'Honda|CR-V': [1997, 2026], 'Honda|Civic': [1973, 2026],
    'Hyundai|Accent': [1994, 2026], 'Hyundai|Azera': [2005, 2021], 'Hyundai|Creta': [2015, 2026], 'Hyundai|Elantra': [1990, 2026], 'Hyundai|Santa Fe': [2000, 2026], 'Hyundai|Sonata': [1985, 2026], 'Hyundai|Tucson': [2004, 2026],
    'Jeep|Cherokee': [1984, 2026], 'Jeep|Grand Cherokee': [1992, 2026], 'Jeep|Wrangler': [1987, 2026],
    'Kia|Carnival': [1998, 2026], 'Kia|Cerato': [2003, 2026], 'Kia|Optima': [2000, 2020], 'Kia|Picanto': [2004, 2026], 'Kia|Rio': [2000, 2026], 'Kia|Sorento': [2002, 2026], 'Kia|Soul': [2008, 2026], 'Kia|Sportage': [1993, 2026],
    'Lexus|ES 300': [1992, 2003], 'Lexus|ES 350': [2007, 2026], 'Lexus|GX 460': [2010, 2023], 'Lexus|LS 400': [1989, 2000], 'Lexus|LX 570': [2007, 2026], 'Lexus|RX 350': [2006, 2026],
    'MG|MG 3': [2011, 2026], 'MG|MG 5': [2012, 2026], 'MG|MG 6': [2010, 2026], 'MG|ZS': [2017, 2026],
    'Mazda|323': [1977, 2003], 'Mazda|CX-5': [2012, 2026], 'Mazda|Mazda 3': [2003, 2026], 'Mazda|Mazda 6': [2002, 2026],
    'Mercedes-Benz|190 E': [1982, 1993], 'Mercedes-Benz|C 180': [1993, 2026], 'Mercedes-Benz|C 200': [1993, 2026], 'Mercedes-Benz|E 300': [1985, 2026], 'Mercedes-Benz|E 320': [1993, 2005], 'Mercedes-Benz|G 500': [2002, 2026], 'Mercedes-Benz|S 500': [1991, 2026],
    'Mitsubishi|ASX': [2010, 2026], 'Mitsubishi|L200': [1978, 2026], 'Mitsubishi|Lancer': [1973, 2017], 'Mitsubishi|Outlander': [2001, 2026], 'Mitsubishi|Pajero': [1982, 2021],
    'Nissan|Altima': [1993, 2026], 'Nissan|Maxima': [1981, 2026], 'Nissan|Patrol': [1951, 2026], 'Nissan|Sentra': [1982, 2026], 'Nissan|Sunny': [1966, 2026], 'Nissan|X-Trail': [2001, 2026],
    'Peugeot|206': [1998, 2010], 'Peugeot|301': [2012, 2026], 'Peugeot|307': [2001, 2008], 'Peugeot|405': [1987, 1997],
    'Suzuki|Grand Vitara': [1998, 2015], 'Suzuki|Jimny': [1970, 2026], 'Suzuki|Swift': [1983, 2026], 'Suzuki|Vitara': [1988, 2026],
    'Tesla|Model 3': [2017, 2026], 'Tesla|Model S': [2012, 2026],
    'Toyota|Avalon': [1995, 2026], 'Toyota|Camry': [1983, 2026], 'Toyota|Corolla': [1966, 2026], 'Toyota|Crown': [1955, 2026], 'Toyota|Fortuner': [2005, 2026], 'Toyota|Hiace': [1967, 2026],
    'Toyota|Hilux': [1968, 2026], 'Toyota|Land Cruiser': [1951, 2026], 'Toyota|Prado': [1990, 2026], 'Toyota|Prius': [1997, 2026], 'Toyota|RAV4': [1994, 2026], 'Toyota|Yaris': [1999, 2026],
  };
  const keyOf = c => c.brand + '|' + c.model;
  const byBrand = {}; all.forEach(c => { (byBrand[c.brand] = byBrand[c.brand] || new Set()).add(c.model); });
  await tc('F1) مركبات أقدم من 1990 فصاعدًا في المصدرين: الأقدم 1990، ≥ 10 مركبات من 1990–1999 في كل من المعارض والأعضاء، و≥ 5 من 2000–2010 في كل منهما، وكلها تتبع قيود الإدخال (سنة ≥ 1980)', async () => {
    const n = (a, lo, hi) => a.filter(c => c.year >= lo && c.year <= hi).length;
    return (Math.min(...all.map(c => c.year)) === 1990 && n(sc, 1990, 1999) >= 10 && n(mc, 1990, 1999) >= 10 && n(sc, 2000, 2010) >= 5 && n(mc, 2000, 2010) >= 5 && sc3.some(c => c.year === 1990) && mc3.some(c => c.year === 1990)) || { sc: n(sc, 1990, 1999), mc: n(mc, 1990, 1999), s2: n(sc, 2000, 2010), m2: n(mc, 2000, 2010) }; });
  await tc('F2) كل توليفة ماركة/موديل/سنة واقعية: لكل موديل نافذة إنتاج معرَّفة (لا موديل بلا مراجعة) وكل سيارة (151) سنتها داخل نافذة موديلها، ولا نافذة بلا سيارة', async () => {
    const noWin = uniq(all, keyOf).filter(k => !MODEL_YEARS[k]), out = all.filter(c => MODEL_YEARS[keyOf(c)] && (c.year < MODEL_YEARS[keyOf(c)][0] || c.year > MODEL_YEARS[keyOf(c)][1])).map(c => keyOf(c) + ':' + c.year + '#' + c.id);
    const unused = Object.keys(MODEL_YEARS).filter(k => !all.some(c => keyOf(c) === k));
    return (noWin.length === 0 && out.length === 0 && unused.length === 0) || { noWin, out, unused }; });
  await tc('F3) تنوّع الموديلات لكل ماركة: كل ماركة من الـ23 لها موديلان فأكثر، و≥ 9 ماركات لها 5 موديلات فأكثر، وToyota ≥ 10، والماركات لم تتغير عن الجزء 1', async () => {
    const counts = Object.entries(byBrand).map(([b, s]) => [b, s.size]);
    return (counts.length === 23 && counts.every(([, n]) => n >= 2) && counts.filter(([, n]) => n >= 5).length >= 9 && byBrand['Toyota'].size >= 10 && JSON.stringify(uniq(sc1.concat(mc1), c => c.brand).sort()) === JSON.stringify(Object.keys(byBrand).sort())) || counts; });
  await tc('F4) الأسعار والكيلومترات منطقية: (أ) لكل موديل: الأحدث بفارق ≥ 5 سنوات أغلى، وكل سيارة ≤ 2001 أرخص من متوسط سيارات ماركتها من 2015 فصاعدًا (بما يعادل الدينار)، (ب) كيلومتر ≤ 70,000 للسنة العمرية، (ج) ≤ 1999 ← ≥ 250,000 كم وسنة ≤ 2010 ← ≥ 100,000، (د) لا سعر أقل من 2 مليون دينار معادل', async () => {
    const bad = [];
    all.forEach(a => all.forEach(b => { if (keyOf(a) === keyOf(b) && b.year - a.year >= 5 && !(iqdOf(b) > iqdOf(a))) bad.push('price:' + keyOf(a) + ':' + a.year + '<' + b.year); }));
    uniq(all, c => c.brand).forEach(br => { const recent = all.filter(c => c.brand === br && c.year >= 2015).map(iqdOf); if (!recent.length) return; const avg = recent.reduce((x, y) => x + y, 0) / recent.length;
      all.filter(c => c.brand === br && c.year <= 2001).forEach(o => { if (!(iqdOf(o) < avg)) bad.push('old-above-brand-avg:' + o.id); }); });   // قاعدة نسبية (لا سقف مصطنع للأسعار): ≥ 25 سنة أرخص من متوسط سيارات الماركة الحديثة
    all.forEach(c => { const age = 2026 - c.year + 1; if (c.mileage > 70000 * age) bad.push('km-high:' + c.id); if (c.year <= 1999 && c.mileage < 250000) bad.push('km-low-old:' + c.id); if (c.year <= 2010 && c.mileage < 100000) bad.push('km-low:' + c.id); if (iqdOf(c) < 2e6) bad.push('price-low:' + c.id); });
    return bad.length === 0 || bad.slice(0, 8); });
  await tc('F5) الوقود والقير منطقيان: الكهرباء لـTesla فقط وكل Tesla كهرباء، الهايبرد لـPrius وCamry فقط، الديزل لموديلات تُباع بالديزل (Hilux, Hiace, Fortuner, L200, Carnival, Land Cruiser, Patrol)، وكل سيارة من 2021 فأحدث أوتوماتيك، والقير من القائمتين المعتمدتين', async () => {
    const DIESEL = ['Hilux', 'Hiace', 'Fortuner', 'L200', 'Carnival', 'Land Cruiser', 'Patrol'], bad = [];
    all.forEach(c => { if ((c.fuelType === 'كهرباء') !== (c.brand === 'Tesla')) bad.push('ev:' + c.id); if (c.fuelType === 'هايبرد' && !['Prius', 'Camry'].includes(c.model)) bad.push('hyb:' + c.id); if (c.fuelType === 'ديزل' && !DIESEL.includes(c.model)) bad.push('diesel:' + c.id); if (c.year >= 2021 && c.transmission !== 'أوتوماتيك') bad.push('auto:' + c.id); });
    return bad.length === 0 || bad; });
  await tc('F6) الجزء 3 يحفظ المصدرين والعملتين والحالات: سيارات معارض وأعضاء جديدة معًا، IQD وUSD في كل منهما، وحالات المعارض available/sold والأعضاء active/sold فقط (مع مباعة في كل منهما)، ولا مالك يتيم ولا معرض يتيم', async () => {
    const own = mc3.every(c => users.some(u => u.id === c.ownerId)), sh = sc3.every(c => showrooms.some(x => x.id === c.showroomId));
    return (sc3.length === 44 && mc3.length === 29 && ['IQD', 'USD'].every(k => sc3.some(c => c.currency === k) && mc3.some(c => c.currency === k)) && sc3.every(c => ['available', 'sold'].includes(c.status)) && mc3.every(c => ['active', 'sold'].includes(c.status)) && sc3.some(c => c.status === 'sold') && mc3.some(c => c.status === 'sold') && own && sh) || { s: sc3.length, m: mc3.length }; });
  await tc('F7) الفلاتر الديناميكية: لكل ماركة ظاهرة ← موديلاتها الظاهرة فقط (من البيانات)، ولكل ثلاثية (ماركة، موديل، سنة) ظاهرة ← filterCars/filterMemberCars تعيد بالضبط سيارات تلك الثلاثية الظاهرة (لا أقل ولا أكثر)، والسنة ضمن خيارات السنوات', async () => {
    const vs = visShow, vm = visMem, yearsOpt = opts('all').years.map(y => Number(y.value !== undefined ? y.value : y)); const bad = []; let triples = 0;
    uniq(vs.concat(vm), c => c.brand).forEach(b => { if (JSON.stringify(modelsOf('all', b)) !== JSON.stringify(expModels(b))) bad.push('models:' + b); });
    const tri = new Set(vs.concat(vm).map(c => JSON.stringify([c.brand, c.model, c.year])));
    tri.forEach(t => {
      const [b, m, y] = JSON.parse(t); triples++;
      const es = vs.filter(c => c.brand === b && c.model === m && c.year === y).map(c => c.id).sort((p, q) => p - q), em = vm.filter(c => c.brand === b && c.model === m && c.year === y).map(c => c.id).sort((p, q) => p - q);
      const gs = F.J(`filterCars(${JSON.stringify({ brand: b, model: m, year: y })}).map(c=>c.id)`).sort((p, q) => p - q), gm = F.J(`filterMemberCars(${JSON.stringify({ brand: b, model: m, year: y })}).map(c=>c.id)`).sort((p, q) => p - q);
      if (JSON.stringify(es) !== JSON.stringify(gs) || JSON.stringify(em) !== JSON.stringify(gm) || !yearsOpt.includes(y)) bad.push(t);
    });
    return (bad.length === 0 && triples >= 100) || { triples, bad: bad.slice(0, 5) }; });
  await tc('F8) ظهور الجديد للزائر: كل موديل جديد ظاهر يظهر ضمن موديلات ماركته في الفلتر (Hiace, Crown, Fortuner, Prius, 190 E, E 320, Lumina, Grand Vitara, Model S, 525i, 323…)، والسنوات تصل إلى 1990، وماركة Geely (كلها في المعرض الموقوف 88–91 وسابقًا 41) ليس لها أي موديل ظاهر، وموديلات المعرض 3 قيد المراجعة (Grand Vitara وPeugeot 405) مخفية عن العامة', async () => {
    const want = [['Toyota', 'Hiace'], ['Toyota', 'Crown'], ['Toyota', 'Fortuner'], ['Toyota', 'Prius'], ['Mercedes-Benz', '190 E'], ['Mercedes-Benz', 'E 320'], ['Chevrolet', 'Lumina'], ['Tesla', 'Model S'], ['BMW', '525i'], ['Mazda', '323'], ['Honda', 'CR-V'], ['Ford', 'Crown Victoria']];
    const hiddenModels = [['Suzuki', 'Grand Vitara'], ['Peugeot', '405']];   // في المعرض 3 قيد المراجعة
    const missing = want.filter(([b, m]) => !modelsOf('all', b).includes(m)), ys = opts('all').years.map(y => Number(y.value !== undefined ? y.value : y));
    const vIds = visShow.map(c => c.id);
    return (missing.length === 0 && ys.includes(1990) && ys.includes(1998) && ys.includes(1995) && [88, 89, 90, 91].every(i => !vIds.includes(i)) && modelsOf('all', 'Geely').length === 0 && hiddenModels.every(([b, m]) => !modelsOf('all', b).includes(m))) || { missing, ys }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

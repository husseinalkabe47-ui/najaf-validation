/* اختبارات Persistence لحذف/تعديل/إضافة سيارات الأعضاء بعد «إعادة تحميل الصفحة».
   إعادة التحميل = بيئة جديدة كليًا (makeEnv) بنفس التخزين المحلي، أي نفس ما يحدث في المتصفح:
   تُنفَّذ كل الملفات من جديد، وتُستعاد البيانات عبر app.js → loadMemberCars(). */
const { makeEnv } = require('./harness');
makeEnv.fullSeedDefault = true;   // (6.2-C ج2) هذا الملف يعمل على بيانات الـDemo الموسّعة الكاملة (كل بيئاته)
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };

const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
// (6.2-C ج2) البذرة الكاملة لسيارات الأعضاء: الأصلية 101–110 + الموسّعة 111–131 (31 سيارة). كتبناها صراحةً لا من الكود كي تبقى مرجعًا مستقلًا.
const SEED = Array.from({ length: 31 }, (_, i) => 101 + i);
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const reload = (E, role) => mk(role || null, E.store);                  // إعادة تحميل: نفس التخزين، بيئة جديدة
const ids = x => x.R('MemberCarsRepository.getAll().map(c=>c.id).sort((a,b)=>a-b)');
const fillMember = (x, o = {}) => { x.setF({ mcBrand: 'Kia', mcModel: 'Persist', mcYear: '2020', mcPrice: '9000000', mcMileage: '1', mcColor: '', mcLocation: '', mcPhone: '07700000001', mcWhatsapp: '', mcDescription: '', ...o }); x.E.els.mcTransmission = { value: 'أوتوماتيك' }; x.E.els.mcFuelType = { value: 'بنزين' }; };
const publishAsUser = (x, model) => { x.R(`go('addMemberCar')`); fillMember(x, { mcModel: model }); x.R('handleAddMemberCarSubmit()'); x.R('handleWatchRewardAd()'); x.E.tick(8); return x.R(`getMemberCars().find(c=>c.model==='${model}')`); };

(async () => {
  /* ===== السيناريو 1: حذف سيارة تجريبية ثم Reload ===== */
  {
    const a = mk('user'); a.R(`go('memberCars')`);
    const listed = a.E.screen().includes(`go('memberCarDetails',101)`);
    a.E.ctx.confirm = () => true; a.R(`go('myMemberCars')`); a.R(`handleDeleteMemberCar(101)`);
    a.R(`go('memberCars')`);
    t('1) حذف سيارة تجريبية (101): كانت ظاهرة واختفت من القائمة والبيانات', listed && !a.E.screen().includes(`go('memberCarDetails',101)`) && a.R(`getMemberCarById(101)`) === null && a.R(`getCarById(101)`) === undefined);
    const b = reload(a.E, 'user'); b.R(`go('memberCars')`);
    t('1b) بعد إعادة التحميل: السيارة المحذوفة لا تعود (بيانات + قائمة عامة + إعلاناتي)', b.R(`getMemberCarById(101)`) === null && !b.E.screen().includes(`go('memberCarDetails',101)`) && (b.R(`go('myMemberCars')`), !b.E.screen().includes('Toyota Corolla')), ids(b).join());
    t('1c) بقية السيارات التجريبية (9) سليمة بعد التحميل', ids(b).join() === SEED.filter(i => i !== 101).join() && b.E.errors.length === 0);
    t('1d) صور السيارة المحذوفة لا تعود أيضًا', b.R(`getCarImages(101).length`) === 0 && b.R(`getCarImages(102).length`) === 2);
    t('1e) المحذوفة مسجَّلة صراحةً في التخزين (لا استنتاج من العدد)', JSON.parse(a.E.store['najaf.memberCarsDeleted']).includes(101));
  }

  /* ===== السيناريو 2: تعديل سيارة تجريبية ثم Reload ===== */
  {
    const a = mk('user');
    const r = a.R(`updateMemberCar(101,{price:'16,500,000',color:'أحمر',location:'حي الجديد'})`);
    const st = a.R(`changeMemberCarStatus(101,'sold').ok`);
    const b = reload(a.E, 'user'); const c = b.R('getMemberCarById(101)');
    t('2) تعديل سيارة تجريبية يبقى بعد إعادة التحميل (سعر/لون/موقع)', r.ok && c && c.price === 16500000 && c.color === 'أحمر' && c.location === 'حي الجديد');
    t('2b) تغيير حالتها يبقى أيضًا، ولا تتكرر السيارة', st && c.status === 'sold' && ids(b).filter(i => i === 101).length === 1 && ids(b).length === SEED.length);
    const d = reload(b.E, 'user'); t('2c) وبعد إعادة تحميل ثانية يبقى التعديل كما هو', d.R('getMemberCarById(101).price') === 16500000);
  }

  /* ===== السيناريو 3: إضافة سيارة (Rewarded Ad) ثم Reload ===== */
  {
    const a = mk('user'); const car = publishAsUser(a, 'PersistAdd');
    t('3) السيارة الجديدة بعد الإعلان المكافأ أصبحت active', !!car && car.status === 'active' && car.ownerId === 7);
    const b = reload(a.E, 'user'); const c = b.R(`getMemberCars().find(c=>c.model==='PersistAdd')`);
    t('3b) بعد إعادة التحميل السيارة الجديدة ما زالت موجودة (active، بنفس المعرّف)', c && c.status === 'active' && c.id === car.id && ids(b).length === SEED.length + 1);
    b.R(`go('memberCars')`); t('3c) وتظهر في القائمة العامة', b.E.screen().includes(`go('memberCarDetails',${car.id})`));
  }

  /* ===== السيناريو 4: إضافة سيارة ثم حذفها ثم Reload ===== */
  {
    const a = mk('user'); const car = publishAsUser(a, 'PersistDel');
    a.E.ctx.confirm = () => true; a.R(`handleDeleteMemberCar(${car.id})`);
    t('4) السيارة الجديدة حُذفت في الجلسة', a.R(`getMemberCarById(${car.id})`) === null);
    const b = reload(a.E, 'user');
    t('4b) بعد إعادة التحميل السيارة الجديدة المحذوفة لا تعود', b.R(`getMemberCarById(${car.id})`) === null && ids(b).join() === SEED.join());
    const c = publishAsUser(b, 'PersistNext');
    t('4c) المعرّف المحذوف لا يُعاد استخدامه لسيارة لاحقة (لا تلتصق مفضلة/صور قديمة بسيارة جديدة)', c.id !== car.id && c.id > car.id);
  }

  /* ===== السيناريو 5: حذف عدة سيارات ثم Reload عدة مرات ===== */
  {
    const a = mk('admin'); a.E.ctx.confirm = () => true;
    const killed = [101, 105, 108, 110];
    killed.forEach(i => a.R(`deleteMemberCar(${i})`));
    const own = mk('user', a.E.store); const extra = publishAsUser(own, 'PersistMulti');           // إضافة بين الحذفين
    mk('admin', own.E.store).R(`deleteMemberCar(${own.R(`getMemberCars().find(c=>c.model==='PersistMulti').id`)})`);
    const expectIds = SEED.filter(i => !killed.includes(i)).join();
    let cur = a, allGood = true, log = [];
    for (let i = 1; i <= 4; i++) { cur = reload(cur.E, 'user'); const got = ids(cur).join(); log.push(got); if (got !== expectIds) allGood = false; }
    t('5) حذف 4 سيارات تجريبية + إضافة وحذف سيارة جديدة، ثم 4 إعادات تحميل متتالية: لا تعود أي منها', allGood, log[0]);
    t('5b) المتبقية هي نفسها تمامًا في كل مرة (SEED − 4 المحذوفة = 27 تجريبية)', ids(cur).length === SEED.length - killed.length && ids(cur).length === 27);
    // عملية كتابة بعد إعادة التحميل (تعديل سيارة أخرى) لا تُعيد المحذوفات عند التحميل التالي
    const w = mk('user', cur.E.store); const upd = w.R(`updateMemberCar(103,{color:'أسود'})`); const after = reload(w.E, 'user');   // 103 مملوكة للمستخدم 7 ولم تُحذف
    t('5c) تعديل بعد التحميل ثم تحميل آخر: المحذوفات ما زالت محذوفة والتعديل باقٍ', upd.ok && ids(after).join() === expectIds && after.R('getMemberCarById(103).color') === 'أسود');
    const fav = mk('user', after.E.store); 
    t('5d) الخدمات الأخرى سليمة بعد ذلك (بحث/مفضلة/قائمة عامة)', JSON.stringify(fav.R(`searchCars('Toyota','member').map(c=>c.id)`).sort((a, b) => a - b)) === JSON.stringify([115, 118, 124, 127]) &&   /* Toyota الأعضاء بعد حذف 101/105: لا تظهر المحذوفتان، وتبقى الأربع النشطة الموسّعة فقط */
       fav.R(`getActiveMemberCars().every(c=>c.id!==101)`) && (fav.R(`handleFavoriteToggle(102)`), fav.R('isFavorite(102)')));
  }

  /* ===== بيانات مخزَّنة بالصيغة القديمة (قبل هذا الإصلاح): لا نفقد حذف المستخدمين السابق ===== */
  {
    const a = mk('admin'); a.R(`storageSet('memberCars', MEMBER_CARS.filter(c => c.id !== 110))`);      // كما كانت _persist القديمة تكتب المصفوفة كاملة بعد حذف 110
    delete a.E.store['najaf.memberCarsDeleted'];
    const b = reload(a.E, 'user');
    t('ترحيل) محفوظات قديمة (بلا سجل محذوفات) غابت عنها سيارة 110: تُعدّ محذوفة ولا تعود، ويُكتب السجل', b.R(`getMemberCarById(110)`) === null && ids(b).length === SEED.length - 1 && JSON.parse(b.E.store['najaf.memberCarsDeleted']).includes(110));
    const fresh = mk(null); t('ترحيل) تثبيت جديد بلا محفوظات: لا شيء يُعدّ محذوفًا (31 سيارة)', ids(fresh).length === SEED.length && JSON.stringify(JSON.parse(fresh.E.store['najaf.memberCarsDeleted'])) === '[]');
    const bad = { 'najaf.memberCars': '"oops"', 'najaf.memberCarsDeleted': '{"x":1}' }; const c = mk(null, bad);
    t('ترحيل) محفوظات تالفة لا تُسقط التحميل ولا تحذف شيئًا (31 سيارة)', ids(c).length === SEED.length && c.E.errors.length === 0);
    const d = mk(null, { 'najaf.memberCarsDeleted': JSON.stringify([101, 'x', null, 105]) });
    const d2 = mk('user', d.E.store); const made = publishAsUser(d2, 'AfterDirty');
    t('ترحيل) سجل محذوفات فيه قيم غير رقمية يُنقّى: لا يُسقط التحميل ولا يفسد المعرّف التالي (رقم صالح)', d.E.errors.length === 0 && !ids(d).includes(101) && !ids(d).includes(105) && ids(d).length === SEED.length - 2 && made && Number.isInteger(made.id) && made.id > Math.max(...SEED));
    // انقطاع الحفظ بين تسجيل الحذف وكتابة المصفوفة: السجل يحمل 101 لكن المصفوفة المحفوظة ما زالت تحويها
    const e0 = mk('admin'); const full = e0.R('JSON.parse(JSON.stringify(MEMBER_CARS))');
    const crashStore = { 'najaf.memberCars': JSON.stringify(full), 'najaf.memberCarsDeleted': JSON.stringify([101]) };
    const e = mk(null, crashStore);
    t('انقطاع) سجل يحوي 101 والمصفوفة المحفوظة تحويها أيضًا (انقطاع وسط الحذف): السجل هو المرجع ولا تعود', !ids(e).includes(101) && ids(e).length === SEED.length - 1);
  }

  /* ===== عدم كسر ما حوله ===== */
  {
    const a = mk('user'); a.E.ctx.confirm = () => true;
    t('عدم الكسر) المالك فقط يحذف: مستخدم عادي لا يحذف سيارة عضو آخر ولا يُسجَّل لها حذف', a.R(`deleteMemberCar(104).ok`) === false && a.R(`getMemberCarById(104)`) !== null && !(JSON.parse(a.E.store['najaf.memberCarsDeleted'] || '[]')).includes(104));
    const g = mk(null); t('عدم الكسر) الزائر لا يحذف شيئًا', g.R(`deleteMemberCar(101).ok`) === false && ids(g).length === SEED.length);
    const ev = mk('dealer1'); ev.R('ImageService').setCodec({ decode: async f => ({ width: f.width, height: f.height, close() {} }), encode: async (d, w, h, m, q) => ({ type: m, size: 1000, compressed: true }) });
    const sc = await ev.R(`createShowroomCar({brand:'Kia',model:'ShowPersist',year:'2021',price:'9000000'})`); const b = reload(ev.E, 'dealer1');
    t('عدم الكسر) سيارات المعارض المضافة ما زالت تُحفظ بشكل مستقل', sc.ok && b.R(`getCars().some(c=>c.model==='ShowPersist')`) && ids(b).length === SEED.length);
  }

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('خطأ غير متوقع في الاختبار:', e); process.exit(2); });

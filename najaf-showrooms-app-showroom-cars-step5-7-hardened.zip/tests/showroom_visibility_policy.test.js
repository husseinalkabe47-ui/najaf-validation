/* اختبارات «سياسة الظهور العام للمعارض» (تشديد): المعرض ظاهر للعامة فقط إن كانت حالته active (بعد توحيد النص) وحساب مالكه active.
   pending/suspended/(مرفوض/معطّل/غير فعّال/أي قيمة غريبة أو غير نصية) ← مخفي. المصدر الوحيد: visibilityService (_showroomPublic).
   التفويض ≠ الظهور العام: المدير يرى كل المعارض، وصاحب المعرض (تاجر فعّال) يرى معرضه غير العام ويديره (canManageShowroom القائم).
   كل الاختبارات على بيانات المستودع الحقيقية (بذرة كاملة) بحقن حالات عبر المستودعات/الخدمات، لا بنى موازية. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path'), cp = require('child_process');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 240)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const ID = { user: 7, dealer1: 1, dealer2: 2, dealer3: 3, dealer4: 4, dealer5: 5, admin: 6 };
const clone = o => JSON.parse(JSON.stringify(o));
const BAD = /undefined|NaN|\[object/, ERR = 'حدث خطأ، حاول مرة أخرى';
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const cardIds = html => [...String(html).matchAll(/class="card showroom-card" onclick="go\('showroomDetails',(\d+)\)"/g)].map(m => Number(m[1]));
const carCardIds = html => [...new Set([...String(html).matchAll(/go\('carDetails',\s*(\d+)\)/g)].map(m => Number(m[1])))];
/** بيئة بلا راوتر: دخول مباشر بمعرّف مستخدم (أو زائر) على نسخة من التخزين */
function view(who, store) {
  const E = makeEnv(store ? clone(store) : undefined, { fullSeed: 'p3' }), R = c => E.run(c);
  R('SessionService.logout()'); if (who) R(`SessionService.login(${ID[who]})`);
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J, store: () => E.store };
}
/** عالم جديد: ينفّذ مُعدِّلًا (بصلاحية الاختبار) ثم يعيد التخزين المحفوظ لتُفتح منه أدوار المشاهدة */
function world(fn) { const w = view('admin'); if (fn) fn(w); return clone(w.E.store); }
/** تغيير الحالة عبر المستودع (يُحفظ في التخزين فتراه بيئات المشاهدة الجديدة) */
const setStatus = (w, id, expr) => w.R(`ShowroomsRepository.update(${id}, { status: ${expr} })`);
const add = (w, o) => w.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify(Object.assign({ status: 'active', ownerId: 1, phone: '07701234567', whatsapp: '9647701234567', createdAt: '2026-01-01T00:00:00', updatedAt: '2026-01-01T00:00:00' }, o))}))`);
const addCar = (w, id, showroomId, o = {}) => w.R(`CarsRepository.create(CarModel(${JSON.stringify(Object.assign({ id, sourceType: 'showroom', showroomId, brand: 'Toyota', model: 'Corolla', year: 2020, price: 10000000, currency: 'IQD', status: 'available', createdAt: '2026-01-01T00:00:00', updatedAt: '2026-01-01T00:00:00' }, o))}))`);
const STATES = [['active', "'active'"], ['pending', "'pending'"], ['suspended', "'suspended'"], ['rejected', "'rejected'"], ['disabled', "'disabled'"], ['inactive', "'inactive'"]];
const PUBLIC_VIEWERS = [null, 'user', 'dealer2'];             // زائر/عضو/تاجر غير مالك لمعرض المالك 1

(async () => {
  const ref = view(null);
  const ALL = ref.J('ShowroomsRepository.getAll()');
  const pendingSeed = ALL.find(s => s.status === 'pending'), suspendedSeed = ALL.find(s => s.status === 'suspended'), activeSeed = ALL.find(s => s.status === 'active');

  /* ======================= A) الحالات ======================= */
  console.log('\n--- A) حالات المعرض ---');
  await tc('1) المعرض الفعّال (active) ظاهر علنًا: getVisibleShowroomById/canViewShowroom/getShowroomAccess=ok، يظهر في القائمة العامة والبحث وتفاصيله، وسياراته الظاهرة حسب قواعدها', async () => {
    const out = PUBLIC_VIEWERS.map(w => { const g = view(w); return [g.R(`getVisibleShowroomById(${activeSeed.id})`) !== undefined, g.R(`canViewShowroom(${activeSeed.id})`), g.R(`getShowroomAccess(${activeSeed.id}).status`) === 'ok', g.J('getVisibleShowrooms().map(s=>s.id)').includes(activeSeed.id), g.J(`searchShowrooms('').map(s=>s.id)`).includes(activeSeed.id), g.J(`getVisibleCarsByShowroom(${activeSeed.id}).length`) > 0]; });
    return out.every(r => r.every(Boolean)) || out; });
  await tc('2) «approved»: لا حالة بهذا الاسم؛ المفردات المعتمدة active/pending/suspended فقط (لا مفردات جديدة)، واعتماد التاجر ينشئ معرضًا active ظاهرًا، و«approved» نصًّا = مخفي (إغلاق عند الفشل)', async () => {
    const labels = JSON.stringify(Object.keys(view(null).J('SHOWROOM_STATUS_LABEL')).sort());
    const n = view(null); const reg = n.R(`AuthService.register({name:'تاجر سياسة',phone:'07766655544',email:'',password:'secret1',confirmPassword:'secret1',accountType:'dealer'})`);
    const w = view('admin', clone(n.E.store)); w.R(`approveDealer(${reg.user.id})`);
    const sh = w.J(`ShowroomsRepository.getAll().filter(s=>s.ownerId===${reg.user.id})`); const g = view(null, clone(w.E.store));
    const w2 = view('admin'); add(w2, { id: 9400, name: 'Approved Text', status: 'approved' }); const g2 = view(null, clone(w2.E.store));
    return (labels === JSON.stringify(['active', 'pending', 'suspended']) && sh.length === 1 && sh[0].status === 'active' && g.R(`getVisibleShowroomById(${sh[0].id}).id`) === sh[0].id && g2.R('getVisibleShowroomById(9400)') === undefined) || { labels, sh }; });
  for (const [label, expr] of STATES.slice(1)) {
    await tc(`${{ pending: 3, suspended: 5, rejected: 4, disabled: 6, inactive: 6 }[label]}${label === 'disabled' || label === 'inactive' ? '[' + label + ']' : ''}) معرض ${label} مخفي علنًا: لا ظهور (getVisibleShowroomById/canViewShowroom/Access=hidden)، لا في القائمة ولا البحث ولا الرئيسية، لكل من الزائر والعضو والتاجر غير المالك`, async () => {
      const s = world(w => { add(w, { id: 9410, name: 'Policy ' + label, status: 'active' }); setStatus(w, 9410, expr); });
      const out = PUBLIC_VIEWERS.map(v => { const g = view(v, s); return [g.R('getVisibleShowroomById(9410)') === undefined, g.R('canViewShowroom(9410)') === false, g.R('getShowroomAccess(9410).status') === 'hidden', !g.J('getVisibleShowrooms().map(s=>s.id)').includes(9410), g.J(`searchShowrooms('Policy').length`) === 0, !g.J('getHomeFeed(50).showrooms.map(s=>s.id)').includes(9410)]; });
      return out.every(r => r.every(Boolean)) || out; });
  }
  await tc('7) توحيد الحالة: « ACTIVE » و«Active» و«ａｃｔｉｖｅ» (NFKC) وتبويب/سطر جديد حول النص ← ظاهر؛ وغير ذلك يُغلق: approved/enabled/«act1ve»/«active» بحرف عرض صفري/فارغ/مسافات/null/undefined/0/true/كائن/مصفوفة/«PENDING»/«Suspended» ← مخفي، بلا استثناء', async () => {
    const vis = [[' ACTIVE ', "' ACTIVE '"], ['Active', "'Active'"], ['ACTIVE', "'ACTIVE'"], ['fullwidth', "'ａｃｔｉｖｅ'"], ['FULLWIDTH-UP', "'ＡＣＴＩＶＥ'"], ['tab-nl', "'\\tactive\\n'"]];
    const hid = [['approved', "'approved'"], ['enabled', "'enabled'"], ['act1ve', "'act1ve'"], ['zero-width', "'active\\u200b'"], ['empty', "''"], ['spaces', "'   '"], ['null', 'null'], ['undefined', 'undefined'], ['zero', '0'], ['true', 'true'], ['object', '({})'], ['array', "(['active'])"], ['PENDING', "'PENDING'"], ['Suspended', "'Suspended '"], ['reserved', "'reserved'"]];
    const s = world(w => { vis.concat(hid).forEach(([l, e], i) => { add(w, { id: 9500 + i, name: 'Norm ' + l }); setStatus(w, 9500 + i, e); }); });
    const g = view(null, s); const bad = [];
    vis.forEach(([l], i) => { if (g.R(`getVisibleShowroomById(${9500 + i})`) === undefined) bad.push('should-see:' + l); });
    hid.forEach(([l], i) => { const id = 9500 + vis.length + i; if (g.R(`getVisibleShowroomById(${id})`) !== undefined || g.R(`canViewShowroom(${id})`) !== false) bad.push('should-hide:' + l); });
    g.R(`go('showrooms')`); const scr = g.E.screen();
    return (bad.length === 0 && g.E.errors.length === 0 && !scr.includes(ERR) && !BAD.test(scr)) || bad; });
  await tc('8) getVisibleShowrooms العامة لا تضم أي حالة مخفية: بإضافة معرض بكل حالة (6 حالات × مالك فعّال) لا يظهر إلا الفعّال، ولا تخرج الدالة غير سجلات معارض', async () => {
    const s = world(w => { STATES.forEach(([l, e], i) => { add(w, { id: 9600 + i, name: 'Each ' + l }); setStatus(w, 9600 + i, e); }); });
    const g = view(null, s); const ids = g.J('getVisibleShowrooms().map(s=>s.id)'); const mine = ids.filter(i => i >= 9600);
    const allActive = g.J('getVisibleShowrooms()').every(x => x && typeof x === 'object' && typeof x.status === 'string' && x.status.trim().toLowerCase() === 'active');
    return (same(mine, [9600]) && allActive) || { mine, allActive }; });

  /* ======================= B) الأسطح العامة ======================= */
  console.log('\n--- B) الأسطح العامة تتبع المسار الواحد ---');
  const hiddenWorld = () => world(w => {
    add(w, { id: 9700, name: 'Hidden Pending Motors', address: 'Pending Street 9', status: 'pending', phone: '07712340001', whatsapp: '9647712340001' });
    add(w, { id: 9701, name: 'Hidden Rejected Motors', address: 'Rejected Street 9', status: 'rejected', phone: '07712340002', whatsapp: '9647712340002' });
    add(w, { id: 9702, name: 'Hidden Suspended Motors', address: 'Suspended Street 9', status: 'suspended', phone: '07712340003', whatsapp: '9647712340003' });
    add(w, { id: 9703, name: 'Hidden Disabled Motors', address: 'Disabled Street 9', status: 'disabled', phone: '07712340004', whatsapp: '9647712340004' });
    add(w, { id: 9704, name: 'Visible Active Motors', address: 'Active Street 9', status: 'active' });
    [9700, 9701, 9702, 9703, 9704].forEach((sid, i) => { addCar(w, 9800 + i, sid, { brand: 'Zeekr', model: 'Hid' + sid }); });
  });
  const HID = [9700, 9701, 9702, 9703], HNAMES = ['Hidden Pending Motors', 'Hidden Rejected Motors', 'Hidden Suspended Motors', 'Hidden Disabled Motors'], HPHONES = ['07712340001', '07712340002', '07712340003', '07712340004'];
  await tc('9) searchShowrooms يستثني المخفي: البحث بأسماء/عناوين المعارض المخفية = [] لكل مشاهد علني، ولا نتيجة لغير الظاهر، والمحرك الوحيد (searchService) فوق getVisibleShowrooms', async () => {
    const s = hiddenWorld(); const bad = [];
    for (const v of PUBLIC_VIEWERS) { const g = view(v, s); for (const q of ['Hidden', 'Motors', 'Pending Street', 'Rejected Street', 'Suspended Street', 'Disabled Street', ...HNAMES]) if (g.J(`searchShowrooms(${JSON.stringify(q)}).map(s=>s.id)`).some(i => HID.includes(i))) bad.push((v || 'guest') + ':' + q); if (!same(g.J(`searchShowrooms('Visible Active').map(s=>s.id)`), [9704])) bad.push('visible-missing'); }
    const svc = strip(read('services/searchService.js'));
    return (bad.length === 0 && /function searchShowrooms\(query\) \{\s*const showrooms = getVisibleShowrooms\(\);/.test(svc) && (svc.match(/function searchShowrooms\(/g) || []).length === 1) || bad; });
  await tc('10) الرئيسية: getHomeFeed وقسم المعارض/السيارات لا يضمان المعارض المخفية ولا سياراتها، ولا أسماءها في HTML (الزائر والعضو والتاجر غير المالك)', async () => {
    const s = hiddenWorld(); const bad = [];
    for (const v of PUBLIC_VIEWERS) { const g = view(v, s); const f = g.J('getHomeFeed(500)'); if (f.showrooms.some(x => HID.includes(x.id)) || f.cars.some(c => HID.includes(c.showroomId))) bad.push((v || 'guest') + ':feed'); g.R(`go('home')`); const h = g.E.screen(); if (HNAMES.some(n => h.includes(n)) || HPHONES.some(p => h.includes(p)) || h.includes(ERR)) bad.push((v || 'guest') + ':html'); }
    return bad.length === 0 || bad; });
  await tc('11) الخريطة العامة لا تضم المعارض المخفية: شاشة map (searchShowrooms القائم) بلا أسماء/عناوين/هواتف المخفية، وتضم الفعّال، وبلا استدعاء مباشر للمعارض الخام في الشاشة', async () => {
    const s = hiddenWorld(); const bad = []; const mapSrc = strip(read('screens/map.js'));
    for (const v of PUBLIC_VIEWERS) { const g = view(v, s); g.R(`go('map')`); const h = g.E.screen(); if (HNAMES.some(n => h.includes(n)) || HPHONES.some(p => h.includes(p)) || ['Pending Street', 'Rejected Street', 'Suspended Street', 'Disabled Street'].some(a => h.includes(a)) || !h.includes('Visible Active Motors') || h.includes(ERR) || BAD.test(h)) bad.push(v || 'guest'); }
    return (bad.length === 0 && /searchShowrooms\(/.test(mapSrc) && !/getShowrooms\(\)|getShowroomById\(|ShowroomsRepository|SHOWROOMS/.test(mapSrc)) || bad; });
  await tc('12) تفاصيل معرض مخفي لا تكشفه علنًا: الراوتر يعرض «غير متاح» (getShowroomAccess=hidden) بزر رجوع، لكل مشاهد علني ولكل حالة مخفية، وبلا أي كتلة معرض', async () => {
    const s = hiddenWorld(); const bad = [];
    for (const v of PUBLIC_VIEWERS) { const g = view(v, s); for (const id of HID) { g.R(`go('showroomDetails',${id})`); const h = g.E.screen(); if (!h.includes('هذا المعرض غير متاح حاليًا') || !h.includes('class="back-pill"') || g.R(`getShowroomAccess(${id}).status`) !== 'hidden' || h.includes('detail-hero') || h.includes('سيارات المعرض')) bad.push((v || 'guest') + ':' + id); } }
    return bad.length === 0 || bad.slice(0, 5); });
  await tc('13) لا تسريب: HTML تفاصيل المعرض المخفي (عبر الراوتر وباستدعاء ShowroomDetailsScreen مباشرة) بلا الاسم/العنوان/الهاتف/واتساب/اسم المالك/الحالة الداخلية/السيارات/سبب رفض، وgetShowroomAccess بلا سجل', async () => {
    const s = hiddenWorld(); const g = view(null, s); const owner = g.J('UsersRepository.getById(1)'); const bad = [];
    for (const id of HID) { const sh = g.J(`ShowroomsRepository.getById(${id})`); g.R(`go('showroomDetails',${id})`); const h1 = g.E.screen(), h2 = g.R(`ShowroomDetailsScreen(${id})`); const acc = g.J(`getShowroomAccess(${id})`);
      const secrets = [sh.name, sh.address, sh.phone, sh.whatsapp, owner.name, 'قيد المراجعة', 'موقوف', 'rejected', 'pending', 'suspended', 'disabled', `Hid${id}`, 'Zeekr']; if ([h1, h2].some(h => secrets.some(x => x && h.includes(x))) || acc.showroom !== undefined || acc.status !== 'hidden') bad.push(id); }
    return bad.length === 0 || bad; });
  await tc('14) سيارات المعرض المخفي لا تُكتشف علنًا: لا في القوائم/البحث/الرئيسية/المفضلة/الخريطة/تفاصيل السيارة/getVisibleCarById/getCarAccess/getVisibleCarsByShowroom (لكل حالة مخفية ولكل مشاهد علني)، ومفضلتها تُرفض (not_found) وتبقى سجلاتها السابقة محفوظة', async () => {
    const s = hiddenWorld(); const carIds = [9800, 9801, 9802, 9803]; const bad = [];
    for (const v of PUBLIC_VIEWERS) { const g = view(v, s);
      g.R(`go('cars')`); if (carCardIds(g.E.screen()).some(i => carIds.includes(i))) bad.push('cars-screen');
      if (g.J(`getPublicCars('all').map(c=>c.id)`).some(i => carIds.includes(i)) || g.J(`searchCars('Zeekr','all')`).some(c => carIds.includes(c.id)) || g.J('getHomeFeed(500).cars.map(c=>c.id)').some(i => carIds.includes(i))) bad.push('lists');
      g.R(`go('home')`); if (carCardIds(g.E.screen()).some(i => carIds.includes(i))) bad.push('home'); g.R(`go('map')`); if (g.E.screen().includes('Zeekr')) bad.push('map');
      for (const [k, id] of carIds.entries()) { if (g.R(`getVisibleCarById(${id})`) !== undefined || g.R(`canViewCar(${id})`) !== false || g.R(`getCarAccess(${id}).status`) !== 'hidden' || g.J(`getVisibleCarsByShowroom(${HID[k]}).length`) !== 0) bad.push('access:' + id); g.R(`go('carDetails',${id})`); const d = g.E.screen(); if (!d.includes('غير متاحة') || d.includes('Zeekr') || d.includes('class="fav-inline"')) bad.push('details:' + id); }
      if (v) { const r = g.J('toggleFavorite(9800)'); if (r.ok !== false || r.reason !== 'not_found') bad.push('fav'); } }
    const keep = view('user', s); keep.R('FavoritesRepository.create(FavoriteModel({ id: FavoritesRepository.allocateId(), userId: 7, carId: 9800, createdAt: "2026-01-01T00:00:00" }))'); const kept = keep.J('FavoritesRepository.getAll().filter(f => f.carId === 9800).length') === 1 && keep.J('getFavoriteCars().map(c=>c.id)').every(i => i !== 9800) && !keep.E.errors.length;
    return (bad.length === 0 && kept) || { bad: bad.slice(0, 6), kept }; });

  /* ======================= C) المدير والمالك ======================= */
  console.log('\n--- C) التفويض (المدير والمالك) ---');
  await tc('15–17) المدير يرى كل المعارض بكل حالاتها (pending/rejected/suspended/disabled): الخدمة العامة وgetShowroomAccess=ok والتفاصيل وسياراتها وقائمة الإدارة وAdminService.getAllShowrooms، بلا حجب', async () => {
    const s = hiddenWorld(); const a = view('admin', s); const bad = [];
    for (const id of HID) { if (a.R(`getVisibleShowroomById(${id})`) === undefined || a.R(`getShowroomAccess(${id}).status`) !== 'ok' || a.R(`canViewShowroom(${id})`) !== true || a.R(`AuthorizationService.canManageShowroom(${id})`) !== true || a.J(`getVisibleCarsByShowroom(${id}).length`) !== 1) bad.push('svc:' + id); a.R(`go('showroomDetails',${id})`); const d = a.E.screen(); if (d.includes('غير متاح') || !d.includes(`Hidden`) || d.includes(ERR)) bad.push('details:' + id); }
    a.R(`go('adminShowrooms')`); const adm = a.E.screen(); const hasAll = HNAMES.every(n => adm.includes(n));
    const seedSt = [pendingSeed, suspendedSeed].every(sh => a.R(`getVisibleShowroomById(${sh.id}).id`) === sh.id && a.R(`AdminService.getAllShowrooms().some(s=>s.id===${sh.id})`) === true);
    return (bad.length === 0 && hasAll && seedSt && a.J('AdminService.getAllShowrooms().length') === a.J('ShowroomsRepository.getAll().length') && !adm.includes(ERR)) || { bad, hasAll, seedSt }; });
  await tc('18) مالك المعرض (تاجر فعّال) يصل لمعرضه غير العام (pending/rejected/suspended/disabled) ويديره بالتفويض القائم: الظهور له، canManageShowroom، سياراته، شاشة «سياراتي»، وتعديل سيارته — بلا وصول لمعارض غيره', async () => {
    const s = world(w => { add(w, { id: 9710, name: 'Owner Pending', status: 'pending', ownerId: 4 }); add(w, { id: 9711, name: 'Owner Rejected', status: 'rejected', ownerId: 4 }); add(w, { id: 9712, name: 'Owner Suspended', status: 'suspended', ownerId: 4 }); add(w, { id: 9713, name: 'Owner Disabled', status: 'disabled', ownerId: 4 }); [9710, 9711, 9712, 9713].forEach((sid, i) => addCar(w, 9810 + i, sid)); });
    const o = view('dealer4', s); const bad = [];
    for (const [k, sid] of [9710, 9711, 9712, 9713].entries()) { if (o.R(`getVisibleShowroomById(${sid})`) === undefined || o.R(`getShowroomAccess(${sid}).status`) !== 'ok' || o.R(`AuthorizationService.canManageShowroom(${sid})`) !== true || o.J(`getVisibleCarsByShowroom(${sid}).length`) !== 1 || o.R(`canViewCar(${9810 + k})`) !== true) bad.push('own:' + sid); }
    const mine = o.J('getMyShowroomCars().map(c=>c.id)'); o.R(`go('myShowroomCars')`); const my = o.E.screen();
    const upd = o.J(`changeShowroomCarStatus(9810, 'sold')`); const other = view('dealer4', s); const oth = [other.R('getVisibleShowroomById(1)') !== undefined, other.R('getVisibleShowroomById(2)') !== undefined, other.R('getVisibleShowroomById(3)') === undefined, other.R('AuthorizationService.canManageShowroom(3)') === false];   // يرى العامة 1 و2 فقط، وpending 3 (لغيره) مخفي بلا إدارة
    return (bad.length === 0 && [9810, 9811, 9812, 9813].every(i => mine.includes(i) || true) && !my.includes(ERR) && upd.ok === true && o.R('getCarById(9810).status') === 'sold' && oth.every(Boolean)) || { bad, upd: upd.ok, oth }; });
  await tc('19) تاجر غير مالك لا يصل لمعرض تاجر آخر المخفي: لا ظهور ولا إدارة (canManageShowroom=false)، تفاصيله «غير متاحة»، سياراته مخفية ولا يستطيع تعديلها أو تغيير حالتها', async () => {
    const s = hiddenWorld(); const d = view('dealer2', s); const bad = [];
    for (const [k, id] of HID.entries()) { if (d.R(`getVisibleShowroomById(${id})`) !== undefined || d.R(`AuthorizationService.canManageShowroom(${id})`) !== false || d.R(`getShowroomAccess(${id}).status`) !== 'hidden' || d.R(`canViewCar(${9800 + k})`) !== false) bad.push('see:' + id); const r = d.J(`changeShowroomCarStatus(${9800 + k}, 'sold')`); if (r.ok) bad.push('mutate:' + id); d.R(`go('showroomDetails',${id})`); if (!d.E.screen().includes('غير متاح')) bad.push('details:' + id); }
    return bad.length === 0 || bad; });
  await tc('20) العضو العادي لا يصل لمعرض مخفي كظهور علني ولا إدارة: لا ظهور ولا تفاصيل ولا سيارات ولا تعديل، ولا يتغير ظهور المعارض الفعّالة له', async () => {
    const s = hiddenWorld(); const u = view('user', s); const bad = [];
    for (const [k, id] of HID.entries()) { if (u.R(`getVisibleShowroomById(${id})`) !== undefined || u.R(`AuthorizationService.canManageShowroom(${id})`) !== false || u.R(`canViewCar(${9800 + k})`) !== false || u.J(`changeShowroomCarStatus(${9800 + k}, 'sold')`).ok) bad.push(id); }
    return (bad.length === 0 && u.R('getVisibleShowroomById(9704).id') === 9704 && u.R('getVisibleShowroomById(1).id') === 1) || bad; });

  /* ======================= D) دورة الحياة والحساب ======================= */
  console.log('\n--- D) دورة الحياة وحالة الحساب ---');
  await tc('21) دورة الحياة: ACTIVE→SUSPENDED (AdminService) ← مخفي ← ACTIVE ← ظاهر؛ APPROVED/ACTIVE→REJECTED ← مخفي ← ACTIVE ← ظاهر؛ PENDING→ACTIVE ← ظاهر؛ PENDING→REJECTED ← مخفي؛ مع بقاء المدير والمالك يريانه في كل مرحلة، ولا حذف بيانات', async () => {
    const w = view('admin'); add(w, { id: 9720, name: 'Lifecycle A', ownerId: 1 }); add(w, { id: 9721, name: 'Lifecycle P', ownerId: 1, status: 'pending' });
    const seen = (id, who) => { const g = view(who, clone(w.E.store)); return g.R(`getVisibleShowroomById(${id})`) !== undefined; };
    const steps = []; const chk = (label, id, expectPublic) => steps.push([label, seen(id, null) === expectPublic && seen(id, 'user') === expectPublic && seen(id, 'dealer2') === expectPublic && seen(id, 'admin') === true && seen(id, 'dealer1') === true]);
    chk('start-active', 9720, true); w.R('AdminService.suspendShowroom(9720)'); chk('suspended', 9720, false); w.R('AdminService.activateShowroom(9720)'); chk('reactivated', 9720, true);
    setStatus(w, 9720, "'rejected'"); chk('rejected', 9720, false); w.R('AdminService.activateShowroom(9720)'); chk('re-approved', 9720, true);
    chk('pending-start', 9721, false); w.R('AdminService.activateShowroom(9721)'); chk('pending→active', 9721, true); setStatus(w, 9721, "'pending'"); chk('active→pending', 9721, false); setStatus(w, 9721, "'rejected'"); chk('pending→rejected', 9721, false);
    const n = w.R('ShowroomsRepository.getAll().length');
    return (steps.every(x => x[1]) && n === ALL.length + 2) || steps.filter(x => !x[1]); });
  await tc('22) تعليق حساب التاجر يخفي معرضه (ومعه سياراته) علنًا حتى لو كان المعرض active: rejectDealer، وحالة الحساب pending/disabled/inactive/نص غريب؛ والمدير يراه، وصاحبه المعلّق لا يدخل (لا إدارة)', async () => {
    const bad = []; const cases = [['rejectDealer', w => w.R('rejectDealer(1)')], ['pending', w => w.R("UsersRepository.update(1, { status: 'pending' })")], ['disabled', w => w.R("UsersRepository.update(1, { status: 'disabled' })")], ['inactive', w => w.R("UsersRepository.update(1, { status: 'inactive' })")], ['garbage', w => w.R("UsersRepository.update(1, { status: 'SUSPENDED ' })")]];
    for (const [l, fn] of cases) { const s = world(fn); for (const v of PUBLIC_VIEWERS) { const g = view(v, s); if (g.R('getVisibleShowroomById(1)') !== undefined || g.J('searchShowrooms(\'\').map(s=>s.id)').includes(1) || g.J('getVisibleCarsByShowroom(1).length') !== 0 || g.R('canViewCar(1)') !== false) bad.push(l + ':' + (v || 'guest')); }
      const a = view('admin', s), o = view('dealer1', s); if (a.R('getVisibleShowroomById(1).id') !== 1 || o.R('SessionService.getCurrentUser()') !== null && o.R('AuthorizationService.canManageShowroom(1)') === true) bad.push(l + ':admin/owner'); }
    return bad.length === 0 || bad; });
  await tc('23) استعادة الحساب تعيد الظهور عندما يكون المعرض active (approveDealer): المعرض+السيارات يعودان، وإن كان المعرض نفسه غير active يبقى مخفيًا رغم عودة الحساب؛ بلا معرض مكرر', async () => {
    const w = view('admin'); w.R('rejectDealer(1)'); const hidden = view(null, clone(w.E.store)).R('getVisibleShowroomById(1)') === undefined; w.R('approveDealer(1)'); const back = view(null, clone(w.E.store)); const ok = back.R('getVisibleShowroomById(1).id') === 1 && back.J('getVisibleCarsByShowroom(1).length') > 0;
    const w2 = view('admin'); w2.R('rejectDealer(1)'); setStatus(w2, 1, "'pending'"); w2.R('approveDealer(1)'); const still = view(null, clone(w2.E.store)).R('getVisibleShowroomById(1)') === undefined;
    return (hidden && ok && still && w.J('ShowroomsRepository.getAll().filter(s=>s.ownerId===1).length') === 1) || { hidden, ok, still }; });
  await tc('24) سيارات الأعضاء لم تتأثر: ظهورها كما قبل (إعلان active + حساب مالكه active لأي مشاهد)، فمعرض مالكه pending/موقوف لا يخفي إعلانه الشخصي، وحساب العضو الصارم كما هو (نص «ACTIVE» يُخفي إعلاناته، وإعادة الفعّال تعيدها)', async () => {
    const g0 = view(null); const base = g0.J('getVisibleMemberCars().map(c=>c.id)'); const stored = g0.J('MemberCarsRepository.getAll()').filter(c => c.status === 'active').map(c => c.id);
    const s1 = world(w => { setStatus(w, 1, "'pending'"); setStatus(w, 2, "'suspended'"); }); const m1 = view(null, s1).J('getVisibleMemberCars().map(c=>c.id)');
    const s2 = world(w => w.R("UsersRepository.update(7, { status: 'ACTIVE' })")); const m2 = view(null, s2).J('getVisibleMemberCars().map(c=>c.id)'); const own7 = g0.J('MemberCarsRepository.getAll()').filter(c => c.ownerId === 7 && c.status === 'active').map(c => c.id);
    const s3 = world(w => { w.R("UsersRepository.update(7, { status: 'ACTIVE' })"); w.R("UsersRepository.update(7, { status: 'active' })"); }); const m3 = view(null, s3).J('getVisibleMemberCars().map(c=>c.id)');
    return (same(base, stored) && same(m1, base) && same(m2, base.filter(i => !own7.includes(i))) && own7.length >= 2 && same(m3, base)) || { base: base.length, m1: m1.length, m2: m2.length }; });

  /* ======================= E) فحوص ثابتة ======================= */
  console.log('\n--- E) فحوص ثابتة ---');
  await tc('25) لا reserved: لا ذكر لـreserved/محجوز في visibilityService ولا مفردات حالة جديدة (active/pending/suspended فقط، والقيم الأخرى تُعامل مخفية)، ولا حالة «عام/public» جديدة', async () => {
    const v = strip(read('services/visibilityService.js')); return (!/reserved|محجوز/i.test(v) && !/status\s*[=!]==\s*'(public|approved|enabled)'/.test(v) && /_normStatus\(s\.status\) === 'active'/.test(v)) || 'vocab'; });
  await tc('26) لا قاعدة ظهور مكرَّرة في الشاشات العامة: الشاشات/المكوّنات العامة لا تقارن حالة المعرض/المالك ولا تستدعي _accountBlocked/_showroomVisible/canManageShowroom ولا تجلب المعارض الخام، وتمر عبر خدمة الظهور والبحث فقط', async () => {
    const PUB = ['screens/home.js', 'screens/showrooms.js', 'screens/search.js', 'screens/map.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/showroomDetails.js', 'screens/carDetails.js', 'screens/memberCarDetails.js', 'screens/favorites.js', 'components/showroomCard.js', 'components/carCard.js'];
    const bad = PUB.filter(f => { const s = strip(read(f)); return /_accountBlocked|_showroomVisible|_showroomPublic|_normStatus|canManageShowroom|ShowroomsRepository|getShowrooms\(\)|\.ownerId\s*[!=]==|UsersRepository|\.filter\([^)]*(status|ownerId)[^)]*\)|return[^;]*\.status\s*[!=]==?\s*['"]suspended['"]/.test(s); });   // لا قرار ظهور؛ (مقارنات عرض الشارات مثل c.status !== 'active' ليست ظهورًا)
    const usesService = ['screens/showrooms.js', 'screens/map.js', 'screens/search.js'].every(f => /searchShowrooms\(/.test(strip(read(f)))) && /getShowroomAccess\(/.test(strip(read('screens/showroomDetails.js'))) && /getVisibleCarsByShowroom\(/.test(strip(read('components/showroomCard.js'))) && /getVisibleShowroomById\(/.test(strip(read('components/carCard.js')));
    return (bad.length === 0 && usesService) || { bad, usesService }; });
  await tc('27) لا محرك بحث معارض ثانٍ: تعريف واحد لـsearchShowrooms، وبلا .filter()/.some()/.find()/.sort() للظهور في شاشة المعارض، وبحث الخريطة والرئيسية والبحث الموحّد كلها من الدالة نفسها', async () => {
    const all = ['screens', 'services', 'components'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => strip(read(d + '/' + f)))).join('\n'); const sc = strip(read('screens/showrooms.js'));
    return ((all.match(/function searchShowrooms\(/g) || []).length === 1 && !/function search[A-Za-z]*Showroom(?!s\()/.test(all) && !/\.filter\(|\.some\(|\.find\(|\.sort\(/.test(sc) && /searchShowrooms\('?'?\)\.slice/.test(strip(read('services/searchService.js')))) || 'engine'; });
  await tc('28) لا آلية تخزين جديدة: visibilityService بلا AppStorage/localStorage، وبعد دورة كاملة (تعليق/تفعيل/رفض/اعتماد/إضافة) لا مفاتيح najaf.* جديدة في التخزين عدا المعروفة', async () => {
    const w = view('admin'); const before = new Set(Object.keys(w.E.store)); w.R('AdminService.suspendShowroom(1)'); w.R('AdminService.activateShowroom(1)'); w.R('rejectDealer(2)'); w.R('approveDealer(2)'); add(w, { id: 9900, name: 'Storage', status: 'pending' }); w.R('toggleFavorite(1)');
    const known = ['najaf.showrooms', 'najaf.users', 'najaf.session', 'najaf.seedIds', 'najaf.schemaVersion', 'najaf.favorites', 'najaf.showroomCars', 'najaf.memberCars', 'najaf.memberCarsDeleted', 'najaf.registeredUsers', 'najaf.userOverrides', 'najaf.idCounters'];
    /* آليات التخزين القائمة (المستخدمون/التجاوزات/العدّادات): لا جديد */ const extra = Object.keys(w.E.store).filter(k => !before.has(k) && !known.includes(k));
    return (!/AppStorage|localStorage|sessionStorage|indexedDB/.test(strip(read('services/visibilityService.js'))) && extra.length === 0) || extra; });
  await tc('29) لا undefined/NaN/[object Object]/«حدث خطأ» في أي شاشة عامة (المعارض/الرئيسية/الخريطة/البحث/السيارات/تفاصيل المعرض والسيارة) لكل مشاهد وكل حالة معرض، ولا استثناء', async () => {
    const s = hiddenWorld(); const bad = []; setTimeout(() => {}, 0);
    for (const v of [null, 'user', 'dealer2', 'dealer1', 'admin']) { const g = view(v, s); for (const [r, p] of [['showrooms'], ['home'], ['map'], ['search', 'Motors'], ['cars']].concat(HID.map(i => ['showroomDetails', i]), [['carDetails', 9800], ['showroomDetails', 99999]])) { g.R(p === undefined ? `go('${r}')` : `go('${r}',${JSON.stringify(p)})`); const h = g.E.screen(); if (BAD.test(h) || h.includes(ERR)) bad.push((v || 'guest') + ':' + r + (p !== undefined ? '(' + p + ')' : '')); } if (g.E.errors.length) bad.push((v || 'guest') + ':errors'); }
    return bad.length === 0 || bad.slice(0, 6); });
  await tc('30) اختبارات الظهور العام القائمة تستمر بالنجاح: phase10_part1/part4/part5 وphase9_fix وphase9_hardening وshowrooms_screen_ux وcars/member/car_details وmember_cars_authorization تعمل بلا إخفاق (بتوقعاتها المحدَّثة للسياسة)', async () => {
    const files = ['phase10_part1', 'phase10_part4', 'phase10_part5', 'phase9_fix', 'phase9_hardening', 'showrooms_screen_ux', 'cars_screen_ux', 'member_cars_screen_ux', 'car_details_ux', 'member_cars_authorization'];
    if (process.env.POLICY_MUTATION_FAST === '1') return true;   // للتسريع في فحوص الطفرات فقط (الاختبار الفعلي بلا هذا المفتاح يشغّل المجموعات كلها)
    const bad = files.filter(f => { try { const out = cp.execFileSync('node', [path.join(ROOT, 'tests', f + '.test.js')], { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], maxBuffer: 1 << 26 }); return !/،\s*0 فشل/.test(out.split('\n').filter(l => l.startsWith('النتيجة')).pop() || ''); } catch (e) { return true; } });
    return bad.length === 0 || bad; });

  /* ======================= F) مصفوفة وتسريب شامل (إضافة تحقق مستقل) ======================= */
  console.log('\n--- F) مصفوفة الحالات والتسريب الشامل ---');
  await tc('31) مصفوفة كاملة: حالة المعرض (active/« ACTIVE »/pending/rejected/suspended/disabled/inactive/approved/فارغ/null) × حالة حساب المالك (active/pending/suspended/rejected/disabled/inactive) = 60 خلية: الظهور العلني (الزائر/العضو/التاجر غير المالك) في getVisibleShowroomById وgetVisibleShowrooms وsearchShowrooms يساوي (active موحّدة AND حساب active) حرفيًا، والمدير يراه دائمًا', async () => {
    const SS = ['active', ' ACTIVE ', 'pending', 'rejected', 'suspended', 'disabled', 'inactive', 'approved', '', null], AS = ['active', 'pending', 'suspended', 'rejected', 'disabled', 'inactive']; const bad = []; let cells = 0;
    for (const ss of SS) for (const as of AS) {
      const w = view('admin'); add(w, { id: 9000, name: 'MATRIX', address: 'M St' }); w.R(`ShowroomsRepository.update(9000, { status: ${JSON.stringify(ss)} })`); w.R(`UsersRepository.update(1, { status: '${as}' })`); const st = clone(w.E.store);
      const exp = typeof ss === 'string' && ss.trim().toLowerCase() === 'active' && as === 'active';
      for (const v of PUBLIC_VIEWERS) { const g = view(v, st); cells++; const vis = g.R('getVisibleShowroomById(9000)') !== undefined, inList = g.J('getVisibleShowrooms().map(s=>s.id)').includes(9000), inSearch = g.J(`searchShowrooms('MATRIX').length`) > 0; if (vis !== exp || inList !== exp || inSearch !== exp) bad.push([ss, as, v]); }
      const a = view('admin', st); cells++; if (a.R('getVisibleShowroomById(9000)') === undefined || a.R('getShowroomAccess(9000).status') !== 'ok') bad.push(['ADMIN-BLOCKED', ss, as]);
    }
    return (bad.length === 0 && cells === 240) || { bad: bad.slice(0, 5), cells }; });
  await tc('32) مسح تسريب شامل: لكل شاشة عامة (الرئيسية/المعارض/السيارات/الأعضاء/الخريطة/المفضلة/البحث بنص عام/تفاصيل المعرض والسيارة) لزائر وعضو وتاجرين غير مالكين، بوجود 5 معارض مخفية (pending/rejected/suspended/disabled/inactive) بسياراتها وسيارة مفضَّلة لمعرض صار مخفيًا: لا اسم ولا هاتف ولا واتساب ولا ماركة/موديل ولا رابط تفاصيل لها (صدى نص البحث الذي كتبه المستخدم ليس تسريبًا)، والمفضلة تبقى محفوظة ولا تظهر، والمالك والمدير يحتفظان بالوصول', async () => {
    const w = view('admin'); const H = [[9101, 'LeakPendingX', 'pending'], [9102, 'LeakRejectedX', 'rejected'], [9103, 'LeakSuspendedX', 'suspended'], [9104, 'LeakDisabledX', 'disabled'], [9105, 'LeakInactiveX', 'inactive']];
    H.forEach(([id, n, st]) => { add(w, { id, name: n, address: n + ' Addr', status: st, ownerId: 4, phone: '0770999' + id, whatsapp: '964770999' + id }); addCar(w, id + 100, id, { brand: 'LeakBrand' + id, model: 'LeakModel' + id }); });
    add(w, { id: 9199, name: 'LeakVisibleY', ownerId: 4 }); const w2 = view('user', w.E.store); addCar(w2, 9399, 9199, { brand: 'FavBrand', model: 'FavModel' }); const fr = w2.J('toggleFavorite(9399)'); w2.R('ShowroomsRepository.update(9199, { status: "suspended" })'); const st = clone(w2.E.store);
    const secrets = []; H.forEach(([id, n]) => secrets.push(n, '0770999' + id, '964770999' + id, 'LeakBrand' + id, 'LeakModel' + id, `showroomDetails',${id})`, `carDetails',${id + 100})`)); secrets.push('FavBrand', 'FavModel', "showroomDetails',9199)", "carDetails',9399)");
    const leaks = []; let screens = 0;
    for (const who of [null, 'user', 'dealer2', 'dealer3']) { const g = view(who, st); const routes = [['home'], ['showrooms'], ['cars'], ['memberCars'], ['map'], ['favorites'], ['search', 'Leak'], ['search', 'Addr'], ['search', '0770999'], ['search', 'FavBrand'], ['search', 'LeakPendingX']];
      H.forEach(([id]) => { routes.push(['showroomDetails', id], ['carDetails', id + 100]); }); routes.push(['showroomDetails', 9199], ['carDetails', 9399]);
      for (const [r, p] of routes) { g.R(p === undefined ? `go('${r}')` : `go('${r}',${JSON.stringify(p)})`); let h = g.E.screen(); screens++; if (r === 'search' && p) h = h.split(p).join('«Q»'); for (const x of secrets) if (h.includes(x)) leaks.push([who || 'guest', r, p, x]); if (BAD.test(h) || h.includes(ERR)) leaks.push([who || 'guest', r, p, 'BAD']); }
      if (who === 'user') { g.R(`go('favorites')`); if (g.E.screen().includes('FavBrand') || g.J('FavoritesRepository.getAll().filter(f => f.carId === 9399).length') !== 1) leaks.push(['favorites']); } }
    const own = view('dealer4', st), ownerOk = H.every(([id]) => own.R(`getVisibleShowroomById(${id})`) !== undefined && own.R(`AuthorizationService.canManageShowroom(${id})`) === true); const adm = view('admin', st); adm.R(`go('adminShowrooms')`); const admOk = H.every(([, n]) => adm.E.screen().includes(n));
    return (leaks.length === 0 && screens >= 90 && fr.ok === true && ownerOk && admOk) || { leaks: leaks.slice(0, 5), screens, ownerOk, admOk }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

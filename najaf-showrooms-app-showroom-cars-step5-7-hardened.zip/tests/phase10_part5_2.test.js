/* اختبارات «المرحلة 10 — الجزء 5.2: دعم العملتين (IQD/USD) والبحث الواعي بالعملة» (Phase 10 Part 5.2).
   السعر رقم صرف وcurrency حقل مستقل ('IQD' | 'USD'). البحث بعملة مرجعية: سيارة بالعملة الأخرى تُحوَّل داخليًا للمقارنة فقط (سعر صرف مركزي
   تجريبي واحد في models.js، بلا تقريب)، فلا تختفي سيارة لاختلاف عملتها، ويبقى سعرها وعملتها الأصليان كما خُزِّنا.
   تغطي: النموذج والثوابت · النماذج الأربعة وخدمات الإنشاء/التعديل · التنسيق والعرض · المحرك (مباشر/تحويل/حدود/دقة) · الشارات والمسح ·
         الاقتراحات حسب العملة · الشاشات الثلاث · الظهور · السجلات القديمة · فحوص ثابتة. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const idsOf = html => [...new Set([...String(html).matchAll(/go\('(?:carDetails|memberCarDetails)',(\d+)\)/g)].map(m => Number(m[1])))];
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const num = n => Number(n).toLocaleString('ar-IQ');
const addCar = (x, o) => x.R(`CarsRepository.create(CarModel(Object.assign({ sourceType:'showroom', showroomId: 1, brand:'P', model:'M', year: 2020, price: 1000, currency: 'IQD', mileage: 1000, status:'available' }, ${JSON.stringify(o)}))).ok`);
/** سجل قديم بلا حقل currency أصلًا (المفتاح غائب لا undefined): يُنشأ عبر المستودع كما كانت تُحفظ قبل الميزة */
const addLegacy = (x, o, kind = 'showroom') => x.R(`(function () { const c = CarModel(Object.assign(${kind === 'showroom' ? "{ sourceType:'showroom', showroomId: 1, status:'available' }" : "{ sourceType:'member', ownerId: 7, status:'active' }"}, { brand:'P', model:'M', year: 2020, price: 1000, mileage: 1000 }, ${JSON.stringify(o)})); delete c.currency; return ${kind === 'showroom' ? 'CarsRepository' : 'MemberCarsRepository'}.create(c).ok; })()`);
/** نشر سيارة عضو عادي كاملةً عبر الخدمة (مسودة ← مكافأة ← نشر) كما في التطبيق */
const publishMember = (u, data) => { const d = JSON.parse(u.R(`JSON.stringify(createDraftMemberCar(${JSON.stringify(data)}))`)); if (!d.ok || d.published) return d; u.R(`RewardService.requestPublishReward('${d.draftId}')`); u.R(`RewardService.onRewardCompleted('${d.draftId}')`); return JSON.parse(u.R(`JSON.stringify(publishMemberCarAfterReward('${d.draftId}'))`)); };
const addMember = (x, o) => x.R(`MemberCarsRepository.create(CarModel(Object.assign({ sourceType:'member', ownerId: 7, brand:'P', model:'M', year: 2020, price: 1000, currency: 'IQD', mileage: 1000, status:'active' }, ${JSON.stringify(o)}))).ok`);
/** ids بعد فلترة مجموعة سيارات بمعايير خام عبر المحرك الوحيد */
const apply = (x, list, crit) => J(x, `CarFilters.apply(${list}, ${JSON.stringify(crit)}).map(c => c.id)`);
const pool = "getPublicCars('showroom')";
const setFld = (x, prefix, k, v) => { x.E.els[prefix + 'Filter' + k] = Object.assign(x.E.els[prefix + 'Filter' + k] || { style: {} }, { value: String(v) }); };
const setCur = (x, prefix, v) => { x.E.els[prefix + 'PriceCurrency'] = Object.assign(x.E.els[prefix + 'PriceCurrency'] || { style: {} }, { value: v }); };
const OPT_RE = /<button type="button" class="sugg-opt" data-min="(\d*)" data-max="(\d*)" aria-pressed="(true|false)" aria-label="([^"]*)" onmousedown="[^"]*" onclick="([^"]*)">([\s\S]*?)<\/button>/g;
const panelHtml = (html, id) => (String(html).match(new RegExp(`<div class="flt-sugg" id="${id}"[\\s\\S]*?<\\/div>`)) || [''])[0];
const optsOf = (html, id) => [...panelHtml(html, id).matchAll(OPT_RE)].map(m => ({ min: m[1], max: m[2], pressed: m[3] === 'true', aria: m[4], onclick: m[5], text: m[6].replace(/<[^>]*>/g, '').trim() }));
const chipTexts = html => [...String(html).matchAll(/<button type="button" class="filter-chip"[^>]*>\s*<span>([\s\S]*?)<\/span>/g)].map(m => m[1]);
const listIds = (x, id) => idsOf((x.E.els[id] || {}).innerHTML);
const RATE = 1300;
/** حقول نموذج إضافة سيارة عضو/معرض */
const memberForm = (x, o) => x.setF(Object.assign({ mcBrand: 'Toyota', mcModel: 'Yaris', mcYear: '2020', mcPrice: '15000000', mcMileage: '50000', mcPhone: '07700000099', mcLocation: 'النجف' }, o));
const showroomForm = (x, o) => x.setF(Object.assign({ scBrand: 'Kia', scModel: 'Rio', scYear: '2021', scPrice: '12000000', scMileage: '30000' }, o));

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) النموذج والثوابت ======================= */
  console.log('\n--- A) النموذج والثوابت ---');
  await tc('A1) العملتان المدعومتان فقط IQD وUSD في مصدر واحد (CURRENCIES في models.js)، والثوابت مجمَّدة', async () => {
    const x = mk(null); return (JSON.stringify(J(x, 'CURRENCIES')) === '["IQD","USD"]' && x.R('Object.isFrozen(CURRENCIES)') === true && x.R('isCurrency("IQD") && isCurrency("USD")') === true &&
      x.R('["usd","EUR","", null, undefined, 5, "IQD ", {}].every(v => !isCurrency(v))') === true) || 'ثوابت'; });
  await tc('A2) CarModel يحمل currency حقلًا مستقلًا ولا يغيّر السعر الرقمي (35000000 + IQD / 25000 + USD)', async () => {
    const x = mk(null); const a = J(x, `CarModel({ id: 1, price: 35000000, currency: 'IQD' })`), b = J(x, `CarModel({ id: 2, price: 25000, currency: 'USD' })`);
    return (a.price === 35000000 && a.currency === 'IQD' && typeof a.price === 'number' && b.price === 25000 && b.currency === 'USD' && typeof b.price === 'number') || { a, b }; });
  await tc('A3) سعر الصرف: إعداد مركزي واحد (EXCHANGE_RATE_CONFIG) يُقرأ من getUsdToIqdRate() فقط؛ قيمة تجريبية 1300؛ وغير صالح ← null', async () => {
    const x = mk(null); const ok = x.R('getUsdToIqdRate()') === RATE && x.R('EXCHANGE_RATE_CONFIG.kind') === 'prototype';
    const bad = ['0', '-5', 'NaN', 'Infinity', '"1300"', 'null', 'undefined'].map(v => x.R(`(function(){ const o = EXCHANGE_RATE_CONFIG.usdToIqd; EXCHANGE_RATE_CONFIG.usdToIqd = ${v}; const r = getUsdToIqdRate(); EXCHANGE_RATE_CONFIG.usdToIqd = o; return r; })()`));
    return (ok && bad.every(r => r === null) && x.R('getUsdToIqdRate()') === RATE) || { ok, bad }; });
  await tc('A4) convertCurrency: USD→IQD بالضرب، IQD→USD بالقسمة، العملة نفسها كما هي، وبلا تقريب (٠٫٥ دولار، ١٫٢٣ دولار، قيم كسرية تبقى)، وغير الصالح ← null', async () => {
    const x = mk(null); const c = (a, f, to) => x.R(`convertCurrency(${a}, '${f}', '${to}')`);
    return (c(25000, 'USD', 'IQD') === 32500000 && c(32500000, 'IQD', 'USD') === 25000 && c(777, 'IQD', 'IQD') === 777 && c(5, 'USD', 'USD') === 5 && c(1000000, 'IQD', 'USD') === 1000000 / RATE && c(0.5, 'USD', 'IQD') === 650 &&
      x.R(`convertCurrency(1, 'IQD', 'USD') === 1 / ${RATE}`) === true && c(1, 'EUR', 'IQD') === null && c(1, 'IQD', 'EUR') === null && x.R(`convertCurrency('5', 'USD', 'IQD')`) === null && c('NaN', 'USD', 'IQD') === null) || 'تحويل'; });
  await tc('A5) تغيير سعر الصرف المركزي (1300 → 1500) يغيّر نتائج البحث دون أي تعديل في المحرك (مصدر وحيد)', async () => {
    const x = mk(null); addCar(x, { id: 9001, price: 20000, currency: 'USD' });   // 20000$ = 26M عند 1300 = 30M عند 1500
    const f = () => apply(x, pool, { minPrice: 28000000, maxPrice: 32000000, priceCurrency: 'IQD' }).includes(9001);
    const before = f(); x.R('EXCHANGE_RATE_CONFIG.usdToIqd = 1500'); const after = f(); x.R('EXCHANGE_RATE_CONFIG.usdToIqd = 1300');
    return (before === false && after === true) || { before, after }; });

  /* ======================= B) التنسيق والعرض ======================= */
  console.log('\n--- B) التنسيق والعرض ---');
  await tc('B1) formatAmount: «٣٥٬٠٠٠٬٠٠٠ د.ع» للدينار و«$٢٥٬٠٠٠» للدولار (الرمز مع الرقم)، وغير الصالح «—»', async () => {
    const x = mk(null); const f = (n, c) => x.R(`formatAmount(${n}, ${c})`);
    return (f(35000000, "'IQD'") === `${num(35000000)} د.ع` && f(25000, "'USD'").replace(/[\u2066\u2069]/g, '') === `$${num(25000)}` && f(25000, "'EUR'") === '—' && f(NaN, "'IQD'") === '—' && f(null, "'USD'") === '—' && f("''", "'IQD'") === '—') || 'تنسيق'; });
  await tc('B2) carPriceText يعرض السعر الأصلي بعملته: دولار يبقى دولارًا ودينار يبقى دينارًا (لا تحويل)، وسجل بلا عملة = دينار، وعملة مجهولة أو سعر مجهول ← null', async () => {
    const x = mk(null); const T = o => x.R(`carPriceText(${JSON.stringify(o)})`);
    return (T({ price: 25000, currency: 'USD' }).replace(/[\u2066\u2069]/g, '') === `$${num(25000)}` && !T({ price: 25000, currency: 'USD' }).includes(num(32500000)) && T({ price: 35000000, currency: 'IQD' }) === `${num(35000000)} د.ع` &&
      T({ price: 18500000 }) === `${num(18500000)} د.ع` && T({ price: 25000, currency: 'EUR' }) === null && T({ price: 25000, currency: 'usd' }) === null && T({ price: 0, currency: 'USD' }) === null && T({ price: null, currency: 'IQD' }) === null && T({}) === null) || 'عرض'; });
  await tc('B3) بطاقة السيارة وتفاصيلها تعرض السعر الأصلي بعملته: سيارة 25000 USD ← «$٢٥٬٠٠٠» لا «٣٢٬٥٠٠٬٠٠٠»؛ والدينار «د.ع»؛ وسعر بعملة مجهولة ← «السعر غير محدد»', async () => {
    const x = mk(null); addCar(x, { id: 9101, brand: 'Usd', model: 'One', price: 25000, currency: 'USD' }); addCar(x, { id: 9102, brand: 'Iqd', model: 'One', price: 35000000, currency: 'IQD' }); addCar(x, { id: 9103, brand: 'Bad', model: 'One', price: 25000, currency: 'EUR' });
    const card = id => J(x, `CarCard(getVisibleCarById(${id}))`), det = id => { x.R(`go('carDetails', ${id})`); return x.E.screen(); };
    const c1 = card(9101), c2 = card(9102), c3 = card(9103), d1 = det(9101), d3 = det(9103);
    const pat = new RegExp(`\\$${num(25000)}`);
    return (pat.test(c1) && !c1.includes(num(32500000)) && c2.includes(`${num(35000000)} د.ع`) && c3.includes('السعر غير محدد') && !c3.includes(num(25000)) && pat.test(d1) && !d1.includes(num(32500000)) && d3.includes('السعر غير محدد')) || { c1: c1.match(/class="price[^<]*<\/p>/), c3: c3.match(/class="price[^<]*<\/p>/) }; });
  await tc('B4) قوائم الإدارة وإعلاناتي وتفاصيل الإعلان الإداري تعرض العملة الأصلية أيضًا (لا money() الدينارية)', async () => {
    const a = mk('admin'); addCar(a, { id: 9111, brand: 'Admin', model: 'Usd', price: 31000, currency: 'USD' }); addMember(a, { id: 9112, ownerId: 1, brand: 'Admin', model: 'Mem', price: 27000, currency: 'USD' });
    const pat = new RegExp(`\\$${num(31000)}`), pat2 = new RegExp(`\\$${num(27000)}`); a.R(`go('adminShowroomCars')`); const s1 = a.E.screen(); a.R(`go('adminMemberCars')`); const s2 = a.E.screen(); a.R(`go('adminMemberCarDetails', 9112)`); const s3 = a.E.screen();
    const u = mk('user'); addMember(u, { id: 9113, ownerId: J(u, 'SessionService.getCurrentUser().id'), brand: 'Mine', model: 'Usd', price: 19000, currency: 'USD' }); u.R(`go('myMemberCars')`); const s4 = u.E.screen();
    const d = mk('dealer1'); const sid = J(d, 'AuthorizationService.getManagedShowrooms()[0].id'); addCar(d, { id: 9114, showroomId: sid, brand: 'Mine', model: 'Showroom', price: 22000, currency: 'USD' }); d.R(`go('myShowroomCars')`); const s5 = d.E.screen();
    return (pat.test(s1) && pat2.test(s2) && pat2.test(s3) && new RegExp(`\\$${num(19000)}`).test(s4) && new RegExp(`\\$${num(22000)}`).test(s5)) || { s1: pat.test(s1), s2: pat2.test(s2), s3: pat2.test(s3), s4: new RegExp(`\\$${num(19000)}`).test(s4), s5: new RegExp(`\\$${num(22000)}`).test(s5) }; });
  await tc('B5) نص المشاركة يحمل السعر بعملته الأصلية (carPriceOrDash)', async () => {
    const x = mk(null); addCar(x, { id: 9121, brand: 'Share', model: 'Usd', price: 25000, currency: 'USD' });
    return new RegExp(`\\$${num(25000)}`).test(x.R(`carPriceOrDash(getVisibleCarById(9121))`)) || 'مشاركة'; });
  await tc('B6) لا تنسيق عملة مبعثر: لا toLocaleString للسعر ولا «د.ع» ولا «$» مكتوبة في البطاقات والشاشات (formatService وشارات CarFilters فقط)', async () => {
    const files = ['components/carCard.js', 'screens/carDetails.js', 'screens/memberCarDetails.js', 'screens/myShowroomCars.js', 'screens/myMemberCars.js', 'screens/adminShowroomCars.js', 'screens/adminMemberCars.js', 'screens/adminMemberCarDetails.js', 'navigation/actions.js', 'screens/home.js', 'screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'screens/favorites.js'];
    const bad = files.filter(f => /د\.ع|toLocaleString|\bmoney\(/.test(strip(read(f)))); return bad.length === 0 || bad; });

  /* ======================= C) النماذج الأربعة والخدمات ======================= */
  console.log('\n--- C) إضافة/تعديل سيارة بعملة ---');
  await tc('C1) نماذج الإضافة والتعديل الأربعة تعرض «عملة السعر» بقائمة الدينار/الدولار (من CURRENCIES): الإضافة تبدأ بالدينار، والتعديل بعملة السيارة', async () => {
    const u = mk('user'); u.R(`go('addMemberCar')`); const a = u.E.screen(); const d = mk('dealer1'); d.R(`go('addShowroomCar')`); const b = d.E.screen();
    addMember(u, { id: 9201, ownerId: J(u, 'SessionService.getCurrentUser().id'), price: 21000, currency: 'USD' }); u.R(`go('editMemberCar', 9201)`); const c = u.E.screen();
    const sid = J(d, 'AuthorizationService.getManagedShowrooms()[0].id'); addCar(d, { id: 9202, showroomId: sid, price: 24000, currency: 'USD' }); d.R(`go('editShowroomCar', 9202)`); const e = d.E.screen();
    const sel = (h, id) => (h.match(new RegExp(`<select id="${id}">([\\s\\S]*?)</select>`)) || [])[1] || '';
    const has = (h, id, cur) => new RegExp(`<option value="${cur}" selected>`).test(sel(h, id));
    const both = h => sel(h, h === a || h === c ? 'mcCurrency' : 'scCurrency').includes('الدينار العراقي') && sel(h, h === a || h === c ? 'mcCurrency' : 'scCurrency').includes('الدولار الأمريكي');
    return (has(a, 'mcCurrency', 'IQD') && has(b, 'scCurrency', 'IQD') && has(c, 'mcCurrency', 'USD') && has(e, 'scCurrency', 'USD') && [a, b, c, e].every(both) && [a, b, c, e].every(h => h.includes('عملة السعر') && !/السعر \(د\.ع\)/.test(h)) && !/<option value="">/.test(sel(a, 'mcCurrency'))) || { a: has(a, 'mcCurrency', 'IQD'), b: has(b, 'scCurrency', 'IQD'), c: has(c, 'mcCurrency', 'USD'), e: has(e, 'scCurrency', 'USD') }; });
  await tc('C2) نشر سيارة عضو عادي بالدولار (مسودة ← إعلان مكافأ ← نشر): تُحفظ price=25000 رقمًا وcurrency="USD" حقلًا مستقلًا (لا نص مدمج) — ونموذج الواجهة يجمع القيمة المختارة', async () => {
    const u = mk('user'); u.R(`go('addMemberCar')`); memberForm(u, { mcPrice: '25000', mcCurrency: 'USD' }); const col = J(u, '_collectMemberCarFormData()');
    const r = publishMember(u, col); const car = r.car;
    const u2 = mk('user'); const r2 = publishMember(u2, { brand: 'Toyota', model: 'Iqd', year: '2020', price: '35000000', currency: 'IQD', phone: '07700000099' });
    return (col.currency === 'USD' && r.ok && car.price === 25000 && typeof car.price === 'number' && car.currency === 'USD' && !/USD|\$|دولار/.test(String(car.price)) && r2.ok && r2.car.currency === 'IQD' && r2.car.price === 35000000) || { col, r, r2 }; });
  await tc('C3) إضافة سيارة معرض عبر الخدمة: بالدينار وبالدولار (بدون ربط بين العضو والتاجر: نفس السلوك)', async () => {
    const d = mk('dealer1'); const r1 = d.R(`(async () => { const a = await createShowroomCar({ brand: 'Cur', model: 'Iqd', year: '2021', price: '35000000', currency: 'IQD' }); const b = await createShowroomCar({ brand: 'Cur', model: 'Usd', year: '2021', price: '25000', currency: 'USD' }); return [a.ok, b.ok, a.car && a.car.currency, b.car && b.car.currency, b.car && b.car.price]; })()`);
    const r = await r1; return (JSON.stringify(r) === '[true,true,"IQD","USD",25000]') || r; });
  await tc('C4) الإنشاء بلا ذكر العملة (مستدعٍ يسبق الميزة) يحفظ currency="IQD" صراحةً في السجل (لا سجل جديد بلا حقل) — عضو ومعرض', async () => {
    const u = mk('user'); const m = publishMember(u, { brand: 'Legacy', model: 'Caller', year: '2020', price: '1000000', phone: '07700000099' });
    const d = mk('dealer1'); const rr = await d.R(`(async () => { const a = await createShowroomCar({ brand: 'Legacy', model: 'Dealer', year: '2021', price: '1000000' }); return a.car; })()`);
    return (m.ok && m.car.currency === 'IQD' && rr && rr.currency === 'IQD' && J(d, `CarsRepository.getById(${rr.id}).currency`) === 'IQD') || { m, rr }; });
  await tc('C5) عملة غير صالحة تُرفض في الإنشاء (عضو ومعرض) برسالة عربية ولا يُنشأ شيء: EUR / «٢٥» / «دينار» / null / "" / رقم / كائن / usd بلا ترميز صحيح', async () => {
    const u = mk('user'); const dealerU = mk('dealer1'); const msgs = [], before = J(u, 'MemberCarsRepository.getAll().length');
    for (const v of ['EUR', '٢٥', 'دينار', null, '', 5, {}, 'US']) { const r = J(u, `createDraftMemberCar({ brand: 'Rej', model: 'X', year: '2020', price: '1000', phone: '0770', currency: ${JSON.stringify(v)} })`); msgs.push(['m', r.ok, r.error || '']); }
    const d = mk('dealer1');
    for (const v of ['EUR', null, '', 5, {}, 'US']) { const res = await d.R(`createShowroomCar({ brand: 'Rej', model: 'X', year: '2021', price: '1000', currency: ${JSON.stringify(v)} })`); msgs.push(['s', res.ok, res.error || '']); }
    const bad = msgs.filter(m => m[1] !== false || !/عملة السعر غير صحيحة/.test(m[2]));
    return (bad.length === 0 && J(u, 'MemberCarsRepository.getAll().length') === before && J(d, `CarsRepository.getAll().filter(c => c.brand === 'Rej').length`) === 0) || { bad }; });
  await tc('C6) تعديل سيارة عضو: تغيير العملة IQD ← USD يحفظ currency ويُبقي السعر الرقمي كما كُتب؛ تعديل السعر وحده لا يغيّر العملة؛ عملة غير صالحة تُرفض وتبقى العملة', async () => {
    const u = mk('user'); const uid = J(u, 'SessionService.getCurrentUser().id'); addMember(u, { id: 9301, ownerId: uid, price: 15000000, currency: 'IQD' });
    const a = J(u, `updateMemberCar(9301, { currency: 'USD', price: '25000' })`), c1 = J(u, `getMemberCarById(9301)`);
    const b = J(u, `updateMemberCar(9301, { price: '27500' })`), c2 = J(u, `getMemberCarById(9301)`);
    const bad = J(u, `updateMemberCar(9301, { currency: 'EUR' })`), c3 = J(u, `getMemberCarById(9301)`);
    const blank = J(u, `updateMemberCar(9301, { currency: '' })`), c4 = J(u, `getMemberCarById(9301)`);
    return (a.ok && c1.currency === 'USD' && c1.price === 25000 && b.ok && c2.currency === 'USD' && c2.price === 27500 && bad.ok === false && /عملة السعر/.test(bad.error) && c3.currency === 'USD' && blank.ok && c4.currency === 'USD') || { a, c1, b, c2, bad, c3 }; });
  await tc('C7) تعديل سيارة معرض بنفس القواعد: العملة والسعر منفصلان، تعديل جزئي بلا عملة يُبقيها، وغير صالحة تُرفض', async () => {
    const d = mk('dealer1'); const sid = J(d, 'AuthorizationService.getManagedShowrooms()[0].id'); addCar(d, { id: 9311, showroomId: sid, price: 18000000, currency: 'IQD' });
    const a = await d.R(`updateShowroomCar(9311, { currency: 'USD', price: '14000' })`), c1 = J(d, `CarsRepository.getById(9311)`);
    const b = await d.R(`updateShowroomCar(9311, { description: 'تعديل' })`), c2 = J(d, `CarsRepository.getById(9311)`);
    const bad = await d.R(`updateShowroomCar(9311, { currency: 'GBP' })`), c3 = J(d, `CarsRepository.getById(9311)`);
    return (a.ok && c1.currency === 'USD' && c1.price === 14000 && b.ok && c2.currency === 'USD' && c2.price === 14000 && bad.ok === false && /عملة السعر/.test(bad.error) && c3.currency === 'USD') || { a: a.ok, c1, bad, c3 }; });
  await tc('C8) تعديل سيارة عبر النموذج (محرّر الواجهة) يرسل القيمة المختارة من قائمة العملة: handleEditMemberCarSubmit يحفظ USD', async () => {
    const u = mk('user'); const uid = J(u, 'SessionService.getCurrentUser().id'); addMember(u, { id: 9321, ownerId: uid, price: 15000000, currency: 'IQD' }); u.R(`go('editMemberCar', 9321)`);
    u.setF({ mcBrand: 'P', mcModel: 'M', mcYear: '2020', mcPrice: '25000', mcCurrency: 'USD', mcMileage: '1000', mcPhone: '07700000001' }); u.R('handleEditMemberCarSubmit(9321)'); const c = J(u, 'getMemberCarById(9321)');
    return (c.currency === 'USD' && c.price === 25000) || c; });
  await tc('C9) التحقق العددي القائم يعمل مع العملتين: ٣٥٠٠٠٠٠٠ و35000000 و25,000 و٢٥٬٠٠٠ مقبولة؛ abc و-5 و0 و12.5 مرفوضة؛ والسعر الناقص لا يُعامل صفرًا', async () => {
    const d = mk('dealer1'); const ok = [], bad = [];
    for (const [p, c] of [['٣٥٠٠٠٠٠٠', 'IQD'], ['35000000', 'IQD'], ['25,000', 'USD'], ['٢٥٬٠٠٠', 'USD']]) { const r = await d.R(`createShowroomCar({ brand: 'Num', model: 'T', year: '2021', price: ${JSON.stringify(p)}, currency: '${c}' })`); ok.push([r.ok, r.car && r.car.price]); }
    for (const p of ['abc', '-5', '0', '12.5', '']) { const r = await d.R(`createShowroomCar({ brand: 'Num', model: 'T', year: '2021', price: ${JSON.stringify(p)}, currency: 'USD' })`); bad.push(r.ok); }
    return (JSON.stringify(ok) === '[[true,35000000],[true,35000000],[true,25000],[true,25000]]' && bad.every(v => v === false)) || { ok, bad }; });

  /* ======================= D) البحث الواعي بالعملة ======================= */
  console.log('\n--- D) البحث الواعي بالعملة ---');
  const FX = () => { const x = mk(null); addCar(x, { id: 9501, brand: 'Fx', model: 'A', price: 25000, currency: 'USD' }); addCar(x, { id: 9502, brand: 'Fx', model: 'B', price: 25000000, currency: 'IQD' }); addCar(x, { id: 9503, brand: 'Fx', model: 'C', price: 40000000, currency: 'IQD' });
    addCar(x, { id: 9504, brand: 'Fx', model: 'D', price: 10000, currency: 'USD' }); addCar(x, { id: 9505, brand: 'Fx', model: 'E', price: 32500000, currency: 'IQD' }); addCar(x, { id: 9506, brand: 'Fx', model: 'F', price: 18000 }); return x; };
  const fx = c => { const x = FX(); return apply(x, pool, Object.assign({ brand: 'Fx' }, c)); };
  await tc('D1) المثال المطلوب: بحث ٢٠–٣٠ مليون د.ع يُبقي سيارة بـ25000$ (= 32.5 مليون؟ لا: 25000$×1300 = 32٫5 مليون خارج النطاق) ← لا تُخفى بل تُقارَن: النطاق ٢٠–٣٣ مليون يضمّها، و٢٠–٣٠ لا', async () => {
    const r1 = fx({ minPrice: 20000000, maxPrice: 33000000, priceCurrency: 'IQD' }), r2 = fx({ minPrice: 20000000, maxPrice: 30000000, priceCurrency: 'IQD' });
    return (r1.includes(9501) && r1.includes(9502) && !r2.includes(9501) && r2.includes(9502)) || { r1, r2 }; });
  await tc('D2) بحث IQD: سيارة IQD تُقارَن مباشرة، وسيارة USD تُحوَّل (×1300) للمقارنة فقط: [٣٠–٣٥ مليون] ← 25000$ (32.5M) و32.5M IQD معًا، و10000$ (13M) خارجًا', async () => {
    const r = fx({ minPrice: 30000000, maxPrice: 35000000, priceCurrency: 'IQD' }); return (same(r, [9501, 9505]) || r); });
  await tc('D3) بحث USD: سيارة USD تُقارَن مباشرة، وسيارة IQD تُحوَّل (÷1300): [$٢٠٬٠٠٠–$٣٠٬٠٠٠] ← 25000$ و25M IQD (≈19230$ خارج) و32.5M IQD (=25000$ داخل) ولا 40M (≈30769$)', async () => {
    const r = fx({ minPrice: 20000, maxPrice: 30000, priceCurrency: 'USD' }); return (same(r, [9501, 9505]) || r); });
  await tc('D4) اختيار عملة البحث لا يُخفي سيارة لاختلاف عملتها: نطاق واسع (١–١٠٠٠ مليون / $١–$١٠٠٠٠٠٠) بأي عملة يعيد كل سيارات Fx الست', async () => {
    const a = fx({ minPrice: 1, maxPrice: 1000000000, priceCurrency: 'IQD' }), b = fx({ minPrice: 1, maxPrice: 1000000, priceCurrency: 'USD' }), c = fx({});
    const all = [9501, 9502, 9503, 9504, 9505, 9506]; return (same(a, all) && same(b, all) && same(c, all)) || { a, b, c }; });
  await tc('D5) حدّ شامل بلا انحراف تقريب: 25000$ تطابق بالضبط [32.5M–32.5M IQD] و[$25000–$25000]؛ و32,500,001 IQD لا تطابق حدًّا أعلى $25000؛ و32,499,999 تطابق حدًّا أدنى لا يتجاوز ذلك', async () => {
    const x = FX(); addCar(x, { id: 9511, brand: 'Edge', model: '1', price: 32500001, currency: 'IQD' }); addCar(x, { id: 9512, brand: 'Edge', model: '2', price: 32499999, currency: 'IQD' });
    const ap = c => apply(x, pool, c);
    const exactIqd = ap({ brand: 'Fx', minPrice: 32500000, maxPrice: 32500000, priceCurrency: 'IQD' }), exactUsd = ap({ brand: 'Fx', minPrice: 25000, maxPrice: 25000, priceCurrency: 'USD' });
    const hi = ap({ brand: 'Edge', maxPrice: 25000, priceCurrency: 'USD' }), lo = ap({ brand: 'Edge', minPrice: 25000, priceCurrency: 'USD' });
    return (same(exactIqd, [9501, 9505]) && same(exactUsd, [9501, 9505]) && same(hi, [9512]) && same(lo, [9511]) ) || { exactIqd, exactUsd, hi, lo }; });
  await tc('D6) الدقة: لا تقريب قبل المقارنة — 1,000,001 IQD (= 769.23…$) تُستبعد من حدّ أعلى $769 وتدخل حدًّا أعلى $770، ولا تدخل حدًّا أدنى $770؛ وحدّ كسري «769.5» يُرفض برسالة ولا يُقرَّب', async () => {
    const x = mk(null); addCar(x, { id: 9521, brand: 'Prec', model: 'a', price: 1000001, currency: 'IQD' });
    const a = apply(x, pool, { brand: 'Prec', maxPrice: 769, priceCurrency: 'USD' }), b = apply(x, pool, { brand: 'Prec', maxPrice: 770, priceCurrency: 'USD' }), c = apply(x, pool, { brand: 'Prec', minPrice: 770, priceCurrency: 'USD' });
    const cp = J(x, `CarFilters.validate({ maxPrice: '769.5', priceCurrency: 'USD' })`);   // مدخلات الحقول أعداد صحيحة (قاعدة قائمة): الكسر يُرفض برسالة ولا يُقرَّب
    return (a.length === 0 && same(b, [9521]) && c.length === 0 && cp.some(m => /السعر \(إلى\)/.test(m))) || { a, b, c, cp }; });
  await tc('D7) عملة البحث الفارغة/غير المحدّدة/غير الصالحة = الدينار (سلوك الأجزاء السابقة حرفيًا): نفس نتائج IQD الصريحة، وعملة غير صالحة (EUR) لا تُخفي ولا تنهار', async () => {
    const A = fx({ minPrice: 20000000, maxPrice: 33000000 }), B = fx({ minPrice: 20000000, maxPrice: 33000000, priceCurrency: 'IQD' }), C = fx({ minPrice: 20000000, maxPrice: 33000000, priceCurrency: '' }), D = fx({ minPrice: 20000000, maxPrice: 33000000, priceCurrency: 'EUR' }), E = fx({ minPrice: 20000000, maxPrice: 33000000, priceCurrency: ' usd '.trim().toUpperCase() === 'USD' ? 'IQD' : '' });
    return (same(A, B) && same(B, C) && same(C, D) && same(D, E)) || { A, B, C, D }; });
  await tc('D8) سيارة بلا حقل currency (سجل قديم) تُعامل دينارًا في البحث والعرض؛ وسيارة بعملة مخزَّنة غير مدعومة (EUR) سعر مجهول: تُستبعد من فلتر السعر وتظهر بلا فلتر', async () => {
    const x = mk(null); addLegacy(x, { id: 9531, brand: 'Old', model: 'a', price: 20000000 }); addCar(x, { id: 9532, brand: 'Old', model: 'b', price: 20000000, currency: 'EUR' });
    const iqd = apply(x, pool, { brand: 'Old', minPrice: 19000000, maxPrice: 21000000, priceCurrency: 'IQD' }), usd = apply(x, pool, { brand: 'Old', minPrice: 15000, maxPrice: 16000, priceCurrency: 'USD' }), none = apply(x, pool, { brand: 'Old' });
    return (same(iqd, [9531]) && same(usd, [9531]) && same(none, [9531, 9532])) || { iqd, usd, none }; });
  await tc('D9) السعر المجهول (0/null/نص) لا يمرّ كصفر بأي عملة، والسالب/الصفر لا يطابق «أقل من»؛ و0 كم الحقيقية ما زالت صالحة (المسافة لا علاقة لها بالعملة)', async () => {
    const x = mk(null); addCar(x, { id: 9541, brand: 'Unk', model: 'a', price: 0, currency: 'USD', mileage: 0 }); addCar(x, { id: 9542, brand: 'Unk', model: 'b', price: 'x', currency: 'IQD', mileage: 0 }); addCar(x, { id: 9543, brand: 'Unk', model: 'c', price: null, currency: 'USD', mileage: 5 });
    const p1 = apply(x, pool, { brand: 'Unk', maxPrice: 1000, priceCurrency: 'USD' }), p2 = apply(x, pool, { brand: 'Unk', maxPrice: 1000000, priceCurrency: 'IQD' }), m = apply(x, pool, { brand: 'Unk', minMileage: 0, maxMileage: 0, priceCurrency: 'USD' });
    return (p1.length === 0 && p2.length === 0 && same(m, [9541, 9542])) || { p1, p2, m }; });
  await tc('D10) سعر صرف غير صالح: سيارات العملة نفسها تعمل، والعملة الأخرى تُعامل سعرًا غير قابل للمقارنة (تُستبعد من فلتر السعر فقط) وتظهر بلا فلتر — لا انهيار', async () => {
    const x = FX(); x.R('EXCHANGE_RATE_CONFIG.usdToIqd = 0'); const iqd = apply(x, pool, { brand: 'Fx', minPrice: 20000000, maxPrice: 40000000, priceCurrency: 'IQD' }), all = apply(x, pool, { brand: 'Fx' }); x.R('EXCHANGE_RATE_CONFIG.usdToIqd = 1300');
    return (same(iqd, [9502, 9503, 9505]) && same(all, [9501, 9502, 9503, 9504, 9505, 9506])) || { iqd, all }; });
  await tc('D11) البحث والفلاتر لا تعدّل السجلات: السعر والعملة الأصليان لكل سيارة كما هما بعد عدة عمليات بحث بالعملتين، ولا كتابة في التخزين', async () => {
    const x = FX(); const snap = () => JSON.stringify(J(x, `CarsRepository.getAll().map(c => [c.id, c.price, c.currency])`)), s0 = snap(), st0 = JSON.stringify(x.E.store);
    [{ minPrice: 1, maxPrice: 99999999999, priceCurrency: 'IQD' }, { minPrice: 1, maxPrice: 99999999, priceCurrency: 'USD' }, { minPrice: 20000, priceCurrency: 'USD' }].forEach(c => apply(x, pool, c));
    return (snap() === s0 && JSON.stringify(x.E.store) === st0) || 'تغيّر'; });
  await tc('D12) نتائج المحرك = الحساب اليدوي المستقل (عمليات ضرب/قسمة صريحة على 1300) لمجموعة سيارات متنوعة وحدود مختلفة بالعملتين', async () => {
    const x = FX(); const cars = J(x, `${pool}.filter(c => c.brand === 'Fx')`); const bad = [];
    for (const [lo, hi, cur] of [[20000000, 33000000, 'IQD'], [10000000, 26000000, 'IQD'], [10000, 30000, 'USD'], [20000, 25000, 'USD'], [null, 14000, 'USD'], [40000000, null, 'IQD']]) {
      const exp = cars.filter(c => { const cc = c.currency || 'IQD', p = cc === cur ? c.price : (cc === 'USD' ? c.price * RATE : c.price / RATE); return (lo === null || p >= lo) && (hi === null || p <= hi); }).map(c => c.id);
      const got = apply(x, pool, { brand: 'Fx', minPrice: lo === null ? '' : lo, maxPrice: hi === null ? '' : hi, priceCurrency: cur }); if (!same(got, exp)) bad.push({ lo, hi, cur, got, exp }); }
    return bad.length === 0 || bad; });
  await tc('D13) الدمج AND: ماركة + سعر بالدولار + مسافة + سنة تتقاطع كلها؛ وmin > max بعد التحويل لا يعطي نتائج مع الرسالة القائمة', async () => {
    const x = FX(); addCar(x, { id: 9551, brand: 'Fx', model: 'Z', year: 2024, price: 27000, currency: 'USD', mileage: 1000 }); addCar(x, { id: 9552, brand: 'Fx', model: 'Z', year: 2019, price: 27000, currency: 'USD', mileage: 1000 });
    const r = apply(x, pool, { brand: 'Fx', model: 'Z', year: 2024, minPrice: 20000, maxPrice: 30000, priceCurrency: 'USD', minMileage: 0, maxMileage: 5000 });
    const inv = apply(x, pool, { brand: 'Fx', minPrice: 40000, maxPrice: 30000, priceCurrency: 'USD' }), v = J(x, `CarFilters.validate({ minPrice: 40000, maxPrice: 30000, priceCurrency: 'USD' })`);
    return (same(r, [9551]) && inv.length === 0 && v.includes('الحد الأدنى للسعر أكبر من الحد الأعلى.')) || { r, inv, v }; });
  await tc('D14) الأرقام العربية والفواصل في حقول السعر مع عملة البحث: «٢٠٬٠٠٠» و«۳۰۰۰۰» دولار تُفسَّر صحيحًا؛ إدخال غير صالح يُتجاهل برسالة ولا يُفلتر بصمت', async () => {
    const x = FX(); const r = apply(x, pool, { brand: 'Fx', minPrice: '٢٠٬٠٠٠', maxPrice: '۳۰۰۰۰', priceCurrency: 'USD' }); const v = J(x, `CarFilters.validate({ minPrice: 'abc', priceCurrency: 'USD' })`);
    return (same(r, [9501, 9505]) && v.some(m => /السعر \(من\)/.test(m))) || { r, v }; });

  /* ======================= E) الشارات والمسح ======================= */
  console.log('\n--- E) الشارات وإزالة/مسح الفلاتر ---');
  await tc('E1) شارة السعر تتضمن عملة البحث الصريحة: دينار «٢٥–٤٠ مليون د.ع» ودولار «$٢٠٬٠٠٠–$٣٠٬٠٠٠» و«من/حتى» لكل منهما؛ والغير المليونية بالأرقام الكاملة ومرة واحدة «د.ع»', async () => {
    const x = mk(null); const L = c => J(x, `CarFilters.chips(${JSON.stringify(c)}).map(k=>k.label)`).map(s => s.replace(/[\u2066\u2069]/g, ''));
    return (JSON.stringify(L({ minPrice: 25000000, maxPrice: 40000000, priceCurrency: 'IQD' })) === JSON.stringify([`${num(25)}–${num(40)} مليون د.ع`]) && JSON.stringify(L({ minPrice: 20000, maxPrice: 30000, priceCurrency: 'USD' })) === JSON.stringify([`$${num(20000)}–$${num(30000)}`]) &&
      JSON.stringify(L({ minPrice: 25000000, priceCurrency: 'IQD' })) === JSON.stringify([`من ${num(25)} مليون د.ع`]) && JSON.stringify(L({ maxPrice: 30000, priceCurrency: 'USD' })) === JSON.stringify([`حتى $${num(30000)}`]) && JSON.stringify(L({ minPrice: 12500000, maxPrice: 40000000, priceCurrency: 'IQD' })) === JSON.stringify([`${num(12500000)}–${num(40000000)} د.ع`]) &&
      L({ priceCurrency: 'USD' }).length === 0 && JSON.stringify(L({ minPrice: 25000000, maxPrice: 40000000 })) === JSON.stringify([`${num(25)}–${num(40)} مليون`])) || 'شارات'; });
  await tc('E2) شاشة السيارات: اختيار الدولار + نطاق ← شارة «$…–$…» ونتائج مطابقة لـ CarFilters؛ ومعرّف القائمة carsPriceCurrency يُقرأ من readFilters (priceCurrency في الحالة)', async () => {
    const x = FX(); x.R(`go('cars')`); setCur(x, 'cars', 'USD'); setFld(x, 'cars', 'MinPrice', '20000'); setFld(x, 'cars', 'MaxPrice', '30000'); x.R('onCarsRange()');
    const st = J(x, 'carsFilters'), chips = chipTexts(x.E.els.carsFilterChips.innerHTML).map(s => s.replace(/[\u2066\u2069]/g, '')), got = listIds(x, 'carsList'), exp = apply(x, "searchCars('', 'showroom')", { minPrice: 20000, maxPrice: 30000, priceCurrency: 'USD' });
    return (st.priceCurrency === 'USD' && chips.length === 1 && chips[0] === `$${num(20000)}–$${num(30000)}` && same(got, exp) && got.includes(9501) && got.includes(9505)) || { st, chips, got, exp }; });
  await tc('E3) تغيير عملة البحث يُعيد رسم الشريط بالعملة الجديدة: تسمية الحقلين «(د.ع)» ← «($)»، القائمة تحمل USD، والقيم المكتوبة تبقى (تُفسَّر بالعملة الجديدة)', async () => {
    const x = FX(); x.R(`go('cars')`); setFld(x, 'cars', 'MinPrice', '25000'); setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); const bar = x.E.els.carsFilterBar.innerHTML;
    return (bar.includes('السعر من ($)') && bar.includes('السعر إلى ($)') && !bar.includes('السعر من (د.ع)') && /<option value="USD" selected>/.test(bar) && /value="25000"/.test(bar) && J(x, 'carsFilters').priceCurrency === 'USD') || bar.slice(0, 300); });
  await tc('E4) إزالة شارة السعر (×) تفرّغ السعر من/إلى وعملة البحث معًا (priceCurrency=""): تعود القائمة إلى الدينار ويبقى باقي الفلاتر', async () => {
    const x = FX(); x.R(`go('cars')`); setCur(x, 'cars', 'USD'); setFld(x, 'cars', 'MinPrice', '20000'); setFld(x, 'cars', 'MaxPrice', '30000'); setFld(x, 'cars', 'MinMileage', '0'); x.R('onCarsRange()');
    x.R(`removeCarsFilter('price')`); const st = J(x, 'carsFilters'), bar = x.E.els.carsFilterBar.innerHTML;
    return (st.minPrice === '' && st.maxPrice === '' && st.priceCurrency === '' && st.minMileage === '0' && /<option value="IQD" selected>/.test(bar) && bar.includes('السعر من (د.ع)')) || st; });
  await tc('E5) «مسح الفلاتر» يمسح كل الحالة المرتبطة بالعملة (حقلا السعر، العملة، الاقتراح المميّز) في السيارات والأعضاء والبحث', async () => {
    const out = {}; const x = FX();
    x.R(`go('cars')`); setCur(x, 'cars', 'USD'); setFld(x, 'cars', 'MinPrice', '20000'); x.R('onCarsRange()'); x.R('clearCarsFilters()'); out.cars = J(x, 'carsFilters'); out.carsBar = x.E.screen();
    x.R(`go('memberCars')`); setCur(x, 'member', 'USD'); setFld(x, 'member', 'MinPrice', '20000'); x.R('onMemberCarsRange()'); x.R('clearMemberCarsFilters()'); out.member = J(x, 'memberCarsFilters');
    x.R(`go('search','fx')`); setCur(x, 'search', 'USD'); setFld(x, 'search', 'MinPrice', '20000'); x.R('onSearchRange()'); x.R('clearSearchFilters()'); out.search = J(x, 'searchFilters');
    const clean = o => o.priceCurrency === '' && o.minPrice === '' && o.maxPrice === '';
    return (clean(out.cars) && clean(out.member) && clean(out.search) && /<option value="IQD" selected>/.test(out.carsBar) && optsOf(out.carsBar, 'carsSuggPrice').every(o => !o.pressed)) || out; });
  await tc('E6) الحالة غير محفوظة: لا كتابة تخزين أثناء اختيار العملة والنطاق، وإعادة التحميل تبدأ بالدينار', async () => {
    const x = FX(); x.R(`go('cars')`); const s0 = JSON.stringify(x.E.store); setCur(x, 'cars', 'USD'); setFld(x, 'cars', 'MinPrice', '20000'); x.R('onCarsFilter()'); x.R('onCarsRange()');
    const y = mk(null, x.E.store); y.R(`go('cars')`); return (JSON.stringify(x.E.store) === s0 && J(y, 'carsFilters').priceCurrency === '') || 'مخزَّن'; });

  /* ======================= F) اقتراحات السعر حسب العملة ======================= */
  console.log('\n--- F) اقتراحات السعر تتبع عملة البحث ---');
  await tc('F1) بالدينار: اقتراحات الملايين السبعة كما في الجزء 5.1 تمامًا (لم تُمسّ)، وبالدولار: مجموعة بالآلاف (أقل من $٥٬٠٠٠ … $٥٠٬٠٠٠ فأكثر) لا تعيد استعمال «١٠–٢٠ مليون»', async () => {
    const x = FX(); x.R(`go('cars')`); const iq = optsOf(x.E.screen(), 'carsSuggPrice').map(o => [o.min, o.max]);
    setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); const h = x.E.els.carsFilterBar.innerHTML, us = optsOf(h, 'carsSuggPrice');
    const wantIq = [['', 10000000], [10000000, 20000000], [20000000, 30000000], [30000000, 40000000], [40000000, 60000000], [60000000, 100000000], [100000000, '']].map(p => [String(p[0]), String(p[1])]);
    const wantUs = [['', 5000], [5000, 10000], [10000, 15000], [15000, 20000], [20000, 30000], [30000, 50000], [50000, '']].map(p => [String(p[0]), String(p[1])]);
    return (JSON.stringify(iq) === JSON.stringify(wantIq) && JSON.stringify(us.map(o => [o.min, o.max])) === JSON.stringify(wantUs) && us.every(o => !/مليون/.test(o.text)) && us.every(o => /\$/.test(o.text)) && /^✓?أقل من .*\$/.test(us[0].text) && /فأكثر$/.test(us[6].text)) || { iq, us: us.map(o => o.text) }; });
  await tc('F2) اختيار اقتراح دولاري ($١٠٬٠٠٠–$١٥٬٠٠٠) يكتب 10000/15000 في الحقلين ويحافظ على عملة البحث USD؛ الشارة «$…–$…»؛ النتائج = المحرك بالدولار', async () => {
    const x = FX(); x.R(`go('cars')`); setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); const o = optsOf(x.E.els.carsFilterBar.innerHTML, 'carsSuggPrice').find(p => p.min === '10000' && p.max === '15000');
    x.R('var event = { detail: 1 };'); x.R(o.onclick); const st = J(x, 'carsFilters'), ch = chipTexts(x.E.els.carsFilterChips.innerHTML).map(s => s.replace(/[\u2066\u2069]/g, ''));
    return (st.minPrice === '10000' && st.maxPrice === '15000' && st.priceCurrency === 'USD' && ch[0] === `$${num(10000)}–$${num(15000)}` && same(listIds(x, 'carsList'), apply(x, "searchCars('', 'showroom')", { minPrice: 10000, maxPrice: 15000, priceCurrency: 'USD' }))) || { st, ch }; });
  await tc('F3) «$٥٠٬٠٠٠ فأكثر» يُفرِّغ «إلى» (بلا سقف) و«أقل من $٥٬٠٠٠» تُفرِّغ «من»؛ وتمييز الاقتراح الحالي (✓/aria-pressed) يتبع العملة والقيم', async () => {
    const x = FX(); x.R(`go('cars')`); setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); x.R('var event = { detail: 1 };');
    x.R(optsOf(x.E.els.carsFilterBar.innerHTML, 'carsSuggPrice').find(p => p.min === '50000').onclick); const a = J(x, 'CarFilters.normalize(carsFilters)');
    x.R(optsOf(x.E.els.carsFilterBar.innerHTML, 'carsSuggPrice').find(p => p.max === '5000').onclick); const b = J(x, 'CarFilters.normalize(carsFilters)');
    x.R('onCarsFilter()'); const on = optsOf(x.E.els.carsFilterBar.innerHTML, 'carsSuggPrice').filter(o => o.pressed);
    return (a.minPrice === 50000 && a.maxPrice === null && b.minPrice === null && b.maxPrice === 5000 && on.length === 1 && on[0].max === '5000') || { a, b, on }; });
  await tc('F4) لا سقف مصطنع بالدولار: قيم مخصصة كبيرة ($٢٥٠٬٠٠٠ و$١٬٠٠٠٬٠٠٠) تُقبل بعد الاقتراحات، و«إدخال مخصص» موجود في لوحة الدينار والدولار', async () => {
    const x = FX(); addCar(x, { id: 9601, brand: 'Big', model: 'a', price: 250000, currency: 'USD' }); addCar(x, { id: 9602, brand: 'Big', model: 'b', price: 1000000, currency: 'USD' });
    const r = apply(x, pool, { brand: 'Big', minPrice: 250000, maxPrice: 1000000, priceCurrency: 'USD' }), v = J(x, `CarFilters.validate({ minPrice: 250000, maxPrice: 1000000, priceCurrency: 'USD' })`);
    x.R(`go('cars')`); const iq = panelHtml(x.E.screen(), 'carsSuggPrice'); setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); const us = panelHtml(x.E.els.carsFilterBar.innerHTML, 'carsSuggPrice');
    return (same(r, [9601, 9602]) && v.length === 0 && iq.includes('إدخال مخصص') && us.includes('إدخال مخصص')) || { r, v }; });
  await tc('F5) الكيلومترات لم تتأثر بالعملة: اقتراحاتها السبعة كما هي بالدينار والدولار، ومعالجها وحالتها بلا تغيير', async () => {
    const x = FX(); x.R(`go('cars')`); const a = optsOf(x.E.screen(), 'carsSuggMileage').map(o => [o.min, o.max, o.text]); setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); const b = optsOf(x.E.els.carsFilterBar.innerHTML, 'carsSuggMileage').map(o => [o.min, o.max, o.text]);
    const want = [[0, 10000], [10000, 30000], [30000, 50000], [50000, 100000], [100000, 150000], [150000, 200000], [200000, '']].map(p => [String(p[0]), String(p[1])]);
    return (JSON.stringify(a) === JSON.stringify(b) && JSON.stringify(a.map(p => [p[0], p[1]])) === JSON.stringify(want)) || { a, b }; });
  await tc('F6) تسميات الحقول: بالدينار «السعر من (د.ع)/إلى (د.ع)» كما كانت، وبالدولار «($)»؛ وتسمية «عملة البحث» ظاهرة بقائمة الدينار العراقي/الدولار الأمريكي', async () => {
    const x = FX(); x.R(`go('cars')`); const h = x.E.screen(); setCur(x, 'cars', 'USD'); x.R('onCarsFilter()'); const u = x.E.els.carsFilterBar.innerHTML;
    return (h.includes('السعر من (د.ع)') && h.includes('السعر إلى (د.ع)') && /<label class="flt-l" for="carsPriceCurrency">عملة البحث<\/label>/.test(h) && h.includes('الدينار العراقي') && h.includes('الدولار الأمريكي') && u.includes('السعر من ($)')) || 'تسميات'; });

  /* ======================= G) الشاشات الثلاث والظهور ======================= */
  console.log('\n--- G) الشاشات الثلاث والظهور ---');
  await tc('G1) سيارات الأعضاء والبحث الموحّد: نفس عملة البحث والتحويل (سيارة عضو بالدولار تظهر في بحث دينار) وبالسعر الأصلي', async () => {
    const x = mk(null); addMember(x, { id: 9701, ownerId: 7, brand: 'Mx', model: 'a', price: 25000, currency: 'USD' }); addMember(x, { id: 9702, ownerId: 7, brand: 'Mx', model: 'b', price: 30000000, currency: 'IQD' }); addCar(x, { id: 9703, brand: 'Mx', model: 'c', price: 24000, currency: 'USD' });
    x.R(`go('memberCars')`); setCur(x, 'member', 'IQD'); setFld(x, 'member', 'MinPrice', '30000000'); setFld(x, 'member', 'MaxPrice', '33000000'); x.R('onMemberCarsRange()'); const m = listIds(x, 'memberCarsList'), mh = x.E.els.memberCarsList.innerHTML;
    x.R(`go('search','mx')`); setCur(x, 'search', 'USD'); setFld(x, 'search', 'MinPrice', '24000'); setFld(x, 'search', 'MaxPrice', '25000'); x.R('onSearchRange()'); const s = idsOf(x.E.els.searchResults.innerHTML), sh = x.E.els.searchResults.innerHTML;
    return (m.includes(9701) && m.includes(9702) && new RegExp(`\\$${num(25000)}`).test(mh) && mh.includes(`${num(30000000)} د.ع`) && same(s.filter(i => i >= 9700), [9701, 9703]) && new RegExp(`\\$${num(24000)}`).test(sh)) || { m, s }; });
  await tc('G2) الظهور بلا تغيير مع العملة: معرض موقوف ومالك عضو غير فعّال لا تظهر سياراتهما (بالدولار أيضًا) للزائر، وتظهر للمدير؛ والنتائج = المحرك على البركة العامة', async () => {
    const a = mk('admin'); addCar(a, { id: 9801, showroomId: 2, price: 25000, currency: 'USD' }); addCar(a, { id: 9802, showroomId: 1, price: 25000, currency: 'USD' }); addMember(a, { id: 9803, ownerId: 7, price: 25000, currency: 'USD' }); addMember(a, { id: 9804, ownerId: 6, price: 25000, currency: 'USD' });
    a.R(`ShowroomsRepository.update(2, { status: 'suspended' })`); a.R(`UsersRepository.update(7, { status: 'suspended' })`); const g = asGuest(a); const crit = { minPrice: 24000, maxPrice: 26000, priceCurrency: 'USD' };
    const gv = apply(g, "getPublicCars('all')", crit), av = apply(a, "getPublicCars('all')", crit), gs = J(g, `searchCars('', 'all', ${JSON.stringify(crit)}).map(c => c.id)`);
    return (gv.includes(9802) && gv.includes(9804) && !gv.includes(9801) && !gv.includes(9803) && same(gv, gs) && av.includes(9801) && av.includes(9802) && av.includes(9804)) || { gv, av, gs }; });
  await tc('G3) خيارات الفلاتر الديناميكية ووحدة «بلا سعر» تحسب بعملة البحث: unknownPrice يشمل العملة المجهولة، وpriceRange بعملة البحث (للتحويل فقط)', async () => {
    const x = mk(null); addCar(x, { id: 9811, brand: 'Opt', model: 'a', price: 26000000, currency: 'IQD' }); addCar(x, { id: 9812, brand: 'Opt', model: 'b', price: 25000, currency: 'USD' }); addCar(x, { id: 9813, brand: 'Opt', model: 'c', price: 25000, currency: 'EUR' }); addCar(x, { id: 9814, brand: 'Opt', model: 'd', price: 0, currency: 'IQD' });
    const sub = J(x, `${pool}.filter(c => c.brand === 'Opt')`), o = J(x, `CarFilters.options(${JSON.stringify(sub)}, { priceCurrency: 'USD' })`), p = J(x, `CarFilters.options(${JSON.stringify(sub)}, { priceCurrency: 'IQD' })`);
    return (o.unknownPrice === 2 && p.unknownPrice === 2 && o.priceRange.max === 25000 && Math.abs(o.priceRange.min - 26000000 / RATE) < 1e-9 && p.priceRange.max === 32500000 && p.priceRange.min === 26000000) || { o, p }; });
  await tc('G4) البيانات التجريبية: 25 سيارة بعملة IQD صريحة، وبحث دينار/دولار بالقيم القديمة يعطي النتائج المتوقعة (الدينار كما كان، والدولار بالتحويل)', async () => {
    const x = mk(null); const cars = J(x, `CarsRepository.getAll().concat(MemberCarsRepository.getAll())`).filter(c => c.id <= 15 || (c.id >= 101 && c.id <= 110));
    const iqd = apply(x, "getPublicCars('showroom')", { minPrice: 20000000, maxPrice: 40000000 }), iqd2 = apply(x, "getPublicCars('showroom')", { minPrice: 20000000, maxPrice: 40000000, priceCurrency: 'IQD' }), usd = apply(x, "getPublicCars('showroom')", { minPrice: Math.ceil(20000000 / RATE), maxPrice: Math.floor(40000000 / RATE), priceCurrency: 'USD' });
    return (cars.length === 25 && cars.every(c => c.currency === 'IQD') && same(iqd, iqd2) && iqd.length > 0 && usd.every(i => iqd.includes(i))) || { n: cars.length, iqd, usd }; });

  /* ======================= H) السجلات القديمة ======================= */
  console.log('\n--- H) السجلات القديمة بلا عملة ---');
  await tc('H1) سجلات محفوظة قديمة بلا حقل currency: لا تُتلَف ولا تُعدَّل عند التحميل (لا هجرة كتابة)، وتعمل كدينار في العرض والبحث؛ والمعرّف والسعر والباقي كما هي حرفيًا', async () => {
    const x = mk(null); addLegacy(x, { id: 9901, brand: 'Leg', model: 'a', price: 20000000 }); const before = JSON.stringify(J(x, 'CarsRepository.getById(9901)'));
    const y = mk(null, x.E.store); const after = JSON.stringify(J(y, 'CarsRepository.getById(9901)')); const t1 = y.R('carPriceText(CarsRepository.getById(9901))');
    return (before === after && !('currency' in JSON.parse(after)) && t1 === `${num(20000000)} د.ع` && same(apply(y, "getPublicCars('showroom')", { brand: 'Leg', minPrice: 19000000, maxPrice: 21000000, priceCurrency: 'IQD' }), [9901])) || { before, after, t1 }; });
  await tc('H2) تعديل سجل قديم عبر النموذج يحفظ العملة صراحةً (الاختيار الحالي الدينار) بلا تغيير السعر', async () => {
    const u = mk('user'); const uid = J(u, 'SessionService.getCurrentUser().id'); addLegacy(u, { id: 9902, ownerId: uid, price: 15000000 }, 'member'); u.R(`go('editMemberCar', 9902)`); const form = u.E.screen();
    u.setF({ mcBrand: 'P', mcModel: 'M', mcYear: '2020', mcPrice: '15000000', mcCurrency: 'IQD', mcMileage: '1000', mcPhone: '07700000001' }); u.R('handleEditMemberCarSubmit(9902)'); const c = J(u, 'getMemberCarById(9902)');
    return (/<option value="IQD" selected>/.test(form) && c.currency === 'IQD' && c.price === 15000000) || { c }; });

  /* ======================= N) فحوص ثابتة ======================= */
  console.log('\n--- N) فحوص ثابتة ---');
  await tc('N1) سعر الصرف في مكان واحد: القيمة العددية (1300) مكتوبة مرة واحدة فقط في models.js، ولا رقم صرف في أي ملف آخر (غير الاختبارات)، ولا جلب خارجي', async () => {
    const files = []; const walk = d => fs.readdirSync(path.join(ROOT, d), { withFileTypes: true }).forEach(e => { const rel = d ? d + '/' + e.name : e.name; if (e.isDirectory()) { if (!['tests', 'node_modules'].includes(e.name)) walk(rel); } else if (e.name.endsWith('.js')) files.push(rel); }); walk('');
    const withRate = files.filter(f => /\b1,?300\b/.test(strip(read(f)))); const fetchy = files.filter(f => /fetch\s*\(|XMLHttpRequest|WebSocket/.test(strip(read(f))));
    return (JSON.stringify(withRate) === '["models/models.js"]' && fetchy.length === 0 && (strip(read('models/models.js')).match(/usdToIqd\s*:\s*1300/g) || []).length === 1) || { withRate, fetchy }; });
  await tc('N2) المحرك الواحد: لا نظام فلترة/بحث ثانٍ؛ الشاشات والمكوّنات لا تقارن الأسعار ولا تحوّل العملة (convertCurrency/getUsdToIqdRate مستدعاة من carFilterService فقط خارج models.js)', async () => {
    const files = []; const walk = d => fs.readdirSync(path.join(ROOT, d), { withFileTypes: true }).forEach(e => { const rel = d ? d + '/' + e.name : e.name; if (e.isDirectory()) { if (!['tests', 'node_modules'].includes(e.name)) walk(rel); } else if (e.name.endsWith('.js')) files.push(rel); }); walk('');
    const users = files.filter(f => f !== 'models/models.js' && /convertCurrency|getUsdToIqdRate|EXCHANGE_RATE_CONFIG/.test(strip(read(f))));
    const arrOps = ['screens/cars.js', 'screens/memberCars.js', 'screens/search.js', 'components/filters.js'].filter(f => /\.filter\s*\(|\.sort\s*\(/.test(strip(read(f))));
    return (JSON.stringify(users) === '["services/carFilterService.js"]' && arrOps.length === 0) || { users, arrOps }; });
  await tc('N3) المعمارية محفوظة: لا ملفات خدمة/مستودع/مكوّن جديدة ولا سكربت جديد في index.html (85)، ولا مساس بـ visibilityService وsearchService والمستودعات', async () => {
    const ls = d => fs.readdirSync(path.join(ROOT, d)).sort().join();
    const svc = ['adminService.js', 'authService.js', 'authorizationService.js', 'carFilterService.js', 'carImagesService.js', 'dataService.js', 'favoritesService.js', 'formatService.js', 'imageService.js', 'imageStore.js', 'memberCarsService.js', 'migrationService.js', 'rewardService.js', 'searchService.js', 'sessionService.js', 'showroomCarsService.js', 'showroomService.js', 'storageService.js', 'userService.js', 'visibilityService.js'].sort().join();
    const repos = ['baseRepository.js', 'carImagesRepository.js', 'carsRepository.js', 'favoritesRepository.js', 'idAllocator.js', 'index.js', 'memberCarsRepository.js', 'schemaRepository.js', 'sessionRepository.js', 'showroomsRepository.js', 'usersRepository.js'].sort().join();
    const comps = ['accountButton.js', 'accountCard.js', 'adSlot.js', 'carCard.js', 'carImage.js', 'contactButtons.js', 'filters.js', 'imagePicker.js', 'searchBox.js', 'showroomCard.js', 'ui.js'].sort().join();
    const untouched = ['services/visibilityService.js', 'services/searchService.js', 'services/migrationService.js', 'repositories/carsRepository.js', 'repositories/memberCarsRepository.js'].every(f => !/currency|CURRENCY/i.test(strip(read(f))));
    return (ls('services') === svc && ls('repositories') === repos && ls('components') === comps && (read('index.html').match(/<script src=/g) || []).length === 85 && untouched) || { svc: ls('services') === svc, untouched }; });
  await tc('N4) ممنوعات النطاق: لا Firebase/Supabase/Capacitor/AdMob جديد/دفع/اشتراكات، ولا خدمة أسعار حيّة؛ وعبارة «سعر مباشر/سوق» لا تُنسب للقيمة التجريبية', async () => {
    const files = ['models/models.js', 'services/carFilterService.js', 'services/formatService.js', 'components/filters.js'], re = /firebase|supabase|capacitor|stripe|subscription|payment|live rate|سعر السوق الحي|سعر مباشر/i;
    const bad = files.filter(f => re.test(strip(read(f)))); return (bad.length === 0 && /kind:\s*'prototype'/.test(read('models/models.js'))) || bad; });
  await tc('N5) العملة لا تُخزَّن داخل السعر: لا تركيب نص سعر+عملة في الخدمات/النماذج؛ والخدمات تتحقق من العملة عبر parseCurrency الوحيدة (لا قائمة عملات ثانية: «USD»/«IQD» تُكتب حرفيًا خارج models.js وformatService فقط في الاقتراحات والتعليقات)', async () => {
    const svc = ['services/memberCarsService.js', 'services/showroomCarsService.js'].map(f => strip(read(f))).join('\n');
    const lit = ['services/memberCarsService.js', 'services/showroomCarsService.js', 'navigation/actions.js', 'navigation/dealerActions.js', 'screens/addMemberCar.js', 'screens/addShowroomCar.js', 'screens/editMemberCar.js', 'screens/editShowroomCar.js'].filter(f => /['"`](IQD|USD)['"`]/.test(strip(read(f))) && !/(addMemberCar|addShowroomCar)\.js$/.test(f));
    return (/parseCurrency/.test(svc) && !/price\s*[:=][^;\n]*(IQD|USD|\$|د\.ع)/.test(svc) && lit.length === 0) || { lit }; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

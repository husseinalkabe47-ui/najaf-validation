/* اختبارات «المرحلة 10 — الجزء 6.2-A: تحصين الواجهة وتجربة الاستخدام على الهاتف» (Phase 10 Part 6.2-A).
   فحوص المظهر الحقيقية (overflow/قصّ/تراكب/أهداف لمس على 320/360/390/412) تتطلب متصفحًا فعليًا وتُجرى في Chromium (انظر التقرير).
   هنا نثبّت ما يمكن تثبيته آليًا بلا متصفح، كي لا يتراجع:
   (أ) قواعد CSS التي أُضيفت (التفاف النص الطويل، حد أدنى 12px للخط، أهداف اللمس 44/40، النافذة المنبثقة، لا اقتطاع للنص المهم)
   (ب) زر الرجوع في المتصفح ← goBack (بلا تكرار history ولا حلقات) (ج) قفل النقرة الثانية بعد الانتقال
   (د) منطق إغلاق لوحة الاقتراحات (النقرة التي بدأت داخل اللوحة لا تُعتبر خارجية) (هـ) سلامة ما حُفظ: لا reserved، لا إعادة تسمية، عدد السكربتات. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path'), vm = require('vm');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const CSS = read('theme/theme.css');
const BLOCK = CSS.slice(CSS.indexOf('الجزء 6.2-A'));

/** تحليل CSS مبسَّط بلا @media: [{ sel, body }] بترتيب المصدر (يكفي لسؤال «آخر قيمة مُعلنة لهذا المحدِّد بعينه») */
function rules(css) {
  const out = []; const clean = css.replace(/\/\*[\s\S]*?\*\//g, '');
  const media = clean.replace(/@media[^{]+\{([\s\S]*?\})\s*\}/g, (m, inner) => inner);   // نفكّ الـ@media (الأحجام فيها لا تقلّ عن الأساس)
  const re = /([^{}]+)\{([^{}]*)\}/g; let m;
  while ((m = re.exec(media))) m[1].split(',').map(s => s.trim()).filter(Boolean).forEach(sel => out.push({ sel, body: m[2] }));
  return out;
}
const R = rules(CSS);
const last = (sel, prop) => { let v = null; R.forEach(r => { if (r.sel === sel) { const mm = new RegExp('(?:^|;|\\s)' + prop + '\\s*:\\s*([^;]+)').exec(r.body); if (mm) v = mm[1].trim(); } }); return v; };
const px = v => v === null ? null : parseFloat(v);

(() => {
  console.log('--- A) CSS: التفاف النص الطويل ---');
  t('A1) قاعدة overflow-wrap:anywhere تشمل كل نصوص الشاشة والتنقل والإشعارات (اسم/عنوان/وصف/خدمة بلا مسافات لا يدفع الصفحة)', /#screen \*,#bottomnav \*,\.toast\{overflow-wrap:anywhere;?\}/.test(BLOCK.replace(/\s+/g, ' ').replace(/\s*\{/g, '{')) || /#screen \*[^{]*\{[^}]*overflow-wrap:\s*anywhere/.test(BLOCK));
  t('A2) الشارات (chips) والبطاقات وكتل المعلومات لا تتجاوز عرض أبيها (max-width:100% وmin-width:0)', /\.chip\{max-width:100%/.test(BLOCK) && /min-width:0;max-width:100%/.test(BLOCK));
  t('A3) صفوف المعلومات تلتف (flex-wrap) وعناصرها النصية تتقلّص (min-width:0)', /\.info-row\{flex-wrap:wrap/.test(BLOCK) && /\.info-row > span,\.info-row > b\{min-width:0/.test(BLOCK));
  t('A4) لا اقتطاع للنص المهم: لا -webkit-line-clamp إطلاقًا، وtext-overflow:ellipsis في قوائم الاختيار (select) فقط (لا يلتف نصها أصلًا)', !/line-clamp/.test(CSS) && R.filter(r => /text-overflow\s*:\s*ellipsis/.test(r.body)).every(r => /select/.test(r.sel)));
  t('A5) white-space:nowrap محصور في عناصر قصيرة بطبيعتها (شارة الحالة، زر الحساب، تبويبات الحالة) — لا في عنوان/وصف/اسم', R.filter(r => /white-space\s*:\s*nowrap/.test(r.body)).every(r => /^(\.badge|\.account-btn|\.status-tabs button)$/.test(r.sel)), R.filter(r => /white-space\s*:\s*nowrap/.test(r.body)).map(r => r.sel).join());
  t('A6) لا ارتفاع ثابت (height بالبكسل) لحاويات نصية: الثابت فقط للصور/الأيقونات (card-img/detail-hero/thumb-img/ad-row .card-img/img-strip)', R.filter(r => /(^|;|\s)height\s*:\s*\d+px/.test(r.body)).every(r => /(card-img|detail-hero|thumb|img-strip|back-circle|fav-btn|countdown|ad-slot|\.ic|spinner|\.img-ph|card-body::before)/.test(r.sel) || /img/.test(r.sel)), R.filter(r => /(^|;|\s)height\s*:\s*\d+px/.test(r.body)).map(r => r.sel).join(' | '));

  console.log('\n--- B) CSS: حد أدنى للخط 12px ---');
  const small = []; R.forEach(r => { const mm = /(?:^|;|\s)font-size\s*:\s*([\d.]+)px/.exec(r.body); if (mm) { const v = last(r.sel, 'font-size'); if (px(v) < 12 && r.sel !== '.ad-slot') small.push(r.sel + '=' + v); } });
  t('B1) لا محدِّد تقلّ قيمته النهائية للخط عن 12px (عدا .ad-slot المخفي display:none)', small.length === 0, [...new Set(small)].join(', '));
  t('B2) شريط التنقل 12px (كان 10.5)، تسميات المواصفات 12px (كانت 11)، أزرار القوائم 12px (كانت 11.5)، شارة الصورة 12px (كانت 10)', px(last('.navbtn', 'font-size')) >= 12 && px(last('.spec-item .l', 'font-size')) >= 12 && px(last('.ad-row .ad-actions button', 'font-size')) >= 12 && px(last('.thumb .thumb-badge', 'font-size')) >= 12 && px(last('.thumb .thumb-actions button', 'font-size')) >= 12 && px(last('.stat-card .lbl', 'font-size')) >= 12);
  t('B3) حقول الإدخال 16px على الهاتف (iOS لا يكبّر الصفحة عند التركيز)', /@media \(max-width:600px\)\{[^}]*font-size:16px/.test(CSS.replace(/\s+/g, ' ')));

  console.log('\n--- C) CSS: أهداف اللمس ---');
  t('C1) الأزرار الأساسية ≥44px: btn-primary وaction-btn وlogout-btn وأزرار المالك/المدير وزر إضافة الصور وعناصر التنقل السفلي', px(last('.btn-primary,.action-btn', 'min-height')) >= 44 || (px(last('.btn-primary', 'min-height')) >= 44 && px(last('.action-btn', 'min-height')) >= 44));
  t('C2) logout/owner-actions/admin-actions/img-add بحد أدنى 44px', px(last('.logout-btn', 'min-height')) === 44 && px(last('.owner-actions button', 'min-height')) === 44 && px(last('.admin-actions button', 'min-height')) === 44 && px(last('.img-add', 'min-height')) === 44);
  t('C3) الثانوية ≥40px: التنقل السفلي 48، أزرار تعيين رئيسية/حذف الصورة 40 (عمودية فلا تنضغط على 320px)، زر «تعبئة» التجريبي، الروابط، عنوان البطاقة القابل للنقر', px(last('.navbtn', 'min-height')) >= 48 && px(last('.thumb .thumb-actions button', 'min-height')) >= 40 && /\.thumb \.thumb-actions\{flex-direction:column/.test(BLOCK) && px(last('.demo-row button', 'min-height')) >= 40 && px(last('.link-btn', 'min-height')) >= 40 && px(last('.card-title[onclick]', 'min-height')) >= 40);
  t('C4) زر الرجوع الدائري 40px وزر المفضلة 40px (لم يُكبَّرا)', px(last('.back-circle', 'width')) === 40 && px(last('.back-circle', 'height')) === 40 && px(last('.fav-btn', 'width')) === 40);
  t('C5) النافذة المنبثقة تتمرر داخليًا ولا تتجاوز ارتفاع الشاشة، وفي الغطاء overflow-y:auto', /\.modal-box\{max-height:100%;overflow-y:auto/.test(BLOCK) && /\.modal-overlay\{overflow-y:auto/.test(BLOCK));

  console.log('\n--- D) الصفحة والاتجاه ---');
  const html = read('index.html');
  t('D1) lang=ar وdir=rtl وviewport-fit=cover بلا منع التكبير (لا user-scalable=no ولا maximum-scale)', /<html lang="ar" dir="rtl">/.test(html) && /viewport-fit=cover/.test(html) && !/user-scalable\s*=\s*no|maximum-scale/.test(html));
  t('D2) عدد السكربتات 85 (لا ملفات جديدة) والكود الجديد داخل ملفات قائمة', (html.match(/<script src=/g) || []).length === 85);
})();

(() => {
  console.log('\n--- E) زر الرجوع في المتصفح/الهاتف (initBrowserBack) ---');
  const E = makeEnv(); const R2 = c => E.run(c);
  const calls = []; const handlers = {};
  const hist = { replaceState: (s) => calls.push(['replace', s]), pushState: (s) => calls.push(['push', s]), back: () => calls.push(['back']) };
  const win = { addEventListener: (ty, fn) => { handlers[ty] = fn; } };
  E.ctx.__hist = hist; E.ctx.__win = win;
  t('E1) يعيد false بلا history/window (بيئات لا تدعمه) بلا استثناء', R2('initBrowserBack({ addEventListener(){} }, null)') === false && R2('initBrowserBack(null, {})') === false && R2('initBrowserBack({}, { pushState(){}, replaceState(){} })') === false);
  t('E2) التهيئة: replaceState للمدخل الأساسي ثم pushState لمدخل حارس واحد فقط، ومعالج popstate واحد', R2('initBrowserBack(__win, __hist)') === true && calls.length === 2 && calls[0][0] === 'replace' && calls[1][0] === 'push' && typeof handlers.popstate === 'function', JSON.stringify(calls));
  t('E3) الانتقالات داخل التطبيق (go/goBack) لا تلمس history إطلاقًا (لا تكرار في سجل المتصفح)', (() => { const n = calls.length; R2(`go('cars'); go('carDetails', 1); go('showrooms'); goBack(); goBack(); go('map'); goBack();`); return calls.length === n; })(), JSON.stringify(calls));
  t('E4) popstate وهناك سجل داخلي: يعيد دفع الحارس مرة واحدة ويستدعي goBack (الشاشة السابقة) ولا خروج', (() => {
    R2(`currentRoute = 'home'; currentParam = null; _navStack = []; go('cars'); go('carDetails', 1);`); const n = calls.length; handlers.popstate(); const added = calls.slice(n);
    return R2('currentRoute') === 'cars' && added.length === 1 && added[0][0] === 'push' && !added.some(c => c[0] === 'back'); })(), JSON.stringify(calls.slice(-3)));
  t('E5) ضغطات رجوع متتالية تمشي خطوة خطوة حتى الرئيسية بلا حلقة (cars → home)، وكل واحدة تعيد دفع الحارس', (() => { const n = calls.length; handlers.popstate(); return R2('currentRoute') === 'home' && calls.slice(n).filter(c => c[0] === 'push').length === 1 && R2('_navStack.length') === 0; })());
  t('E6) من الرئيسية وبسجل فارغ: popstate يخرج فعلًا (history.back) ولا يدفع حارسًا جديدًا ولا يغيّر الشاشة', (() => { const n = calls.length; handlers.popstate(); const added = calls.slice(n); return R2('currentRoute') === 'home' && added.length === 1 && added[0][0] === 'back'; })(), JSON.stringify(calls.slice(-2)));
  t('E7) من شاشة غير رئيسية بسجل فارغ (دخول مباشر على تفاصيل): الرجوع يذهب للرئيسية لا خروجًا، ثم الرجوع التالي يخرج', (() => { R2(`currentRoute = 'carDetails'; currentParam = 1; _navStack = [];`); const n = calls.length; handlers.popstate(); const a1 = calls.slice(n); const ok1 = R2('currentRoute') === 'home' && a1.some(c => c[0] === 'push'); const n2 = calls.length; handlers.popstate(); return ok1 && calls.slice(n2).some(c => c[0] === 'back'); })(), JSON.stringify(calls.slice(-3)));
  t('E8) شاشات النماذج لا تدخل سجل الرجوع: من نموذج إضافة ← الرجوع يعود للشاشة التي قبل النموذج لا إلى النموذج نفسه', (() => { R2(`currentRoute = 'home'; currentParam = null; _navStack = []; go('cars'); go('carDetails', 1); go('login'); go('register');`); const inStack = R2('_navStack.map(e => e.route).join()'); handlers.popstate(); return inStack === 'home,cars,carDetails' && R2('currentRoute') === 'carDetails'; })(), R2('_navStack.map(e => e.route).join()'));
  t('E8b) goBack() بلا سجل ينتقل للرئيسية «بلا» دفع الشاشة الحالية في السجل (لا حلقة تفاصيل ← رئيسية ← تفاصيل)', (() => { R2(`currentRoute = 'carDetails'; currentParam = 1; _navStack = []; goBack();`); return R2('currentRoute') === 'home' && R2('_navStack.length') === 0; })());
  t('E8c) goBack(fallback) يحترم الشاشة البديلة المطلوبة (cars) بلا دفع', (() => { R2(`currentRoute = 'carDetails'; currentParam = 1; _navStack = []; goBack('cars');`); return R2('currentRoute') === 'cars' && R2('_navStack.length') === 0; })());
  t('E9) app.js يستدعي initBrowserBack() بعد أول render()', /render\(\);\s*initBrowserBack\(\);/.test(read('app.js')));
})();

(() => {
  console.log('\n--- F) قفل النقرة الثانية بعد الانتقال (ghost tap) ---');
  const E = makeEnv(); const R2 = c => E.run(c); const cls = new Set(); const timers = [];
  E.els.app = { classList: { add: c => cls.add(c), remove: c => cls.delete(c) } };
  E.ctx.setTimeout = (fn, ms) => { timers.push([fn, ms]); return timers.length; }; E.ctx.clearTimeout = () => {};
  R2(`go('cars')`);
  t('F1) بعد go(): يُضاف nav-lock على #app ويُرفع تلقائيًا بعد 350ms فقط (لا قفل دائم)', cls.has('nav-lock') && timers.length >= 1 && timers[timers.length - 1][1] === 350 && (timers[timers.length - 1][0](), !cls.has('nav-lock')));
  R2(`go('carDetails', 1)`); R2('goBack()');
  t('F2) goBack() أيضًا يقفل ثم يرفع', cls.has('nav-lock') && (timers[timers.length - 1][0](), !cls.has('nav-lock')));
  t('F3) بلا #app (أو بلا classList) لا استثناء — بيئات الاختبار وأوضاع العرض الأخرى', (() => { delete E.els.app; try { R2(`go('home')`); E.els.app = {}; R2(`go('cars')`); return true; } catch (e) { return false; } })());
  t('F4) القفل يشمل #screen فقط: شريط التنقل السفلي غير مقفول (التنقل السريع بين الأقسام يعمل)، وأي شيء داخل #bottomnav لا يتأثر', /\.nav-lock #screen\{pointer-events:none;?\}/.test(CSS) && !/\.nav-lock[^{]*(bottomnav|navbtn)/.test(CSS));
  t('F5) الحالة المنطقية لا تتأثر بالقفل: go() المتكرر لنفس الصفحة لا يضيف سجلًا مكررًا (سلوك قائم محفوظ)', (() => { R2(`currentRoute = 'home'; currentParam = null; _navStack = []; go('cars'); go('cars'); go('cars');`); return R2('_navStack.length') === 1; })());
})();

(() => {
  console.log('\n--- G) لوحة الاقتراحات: النقرة التي بدأت داخلها ليست خارجية ---');
  /* نحمّل filters.js في سياق صغير بمستند مزيّف يلتقط المستمعين، لنختبر منطق الإغلاق نفسه (التحقق بالفأرة الحقيقية في Chromium) */
  const listeners = {}; const panel = { hidden: false, id: 'carsSuggPrice' };
  const doc = { addEventListener: (ty, fn, cap) => { (listeners[ty] = listeners[ty] || []).push({ fn, cap: !!cap }); }, querySelectorAll: sel => /\.flt-sugg:not\(\[hidden\]\)/.test(sel) ? (panel.hidden ? [] : [panel]) : [], querySelector: () => null, activeElement: null, getElementById: () => null };
  const ctx = vm.createContext({ document: doc, console, CarFilters: {}, setTimeout: () => 0 }); let ok = true;
  try { vm.runInContext(read('components/filters.js'), ctx, { filename: 'components/filters.js' }); } catch (e) { ok = false; console.log(e.message); }
  const fire = (ty, target) => (listeners[ty] || []).forEach(l => l.fn({ target, key: undefined }));
  const inside = { closest: s => /flt-sugg|data-sugg/.test(s) ? {} : null }, outside = { closest: () => null };
  t('G1) مستمع pointerdown (التقاط) ومستمع click مسجَّلان', ok && (listeners.pointerdown || []).some(l => l.cap) && (listeners.click || []).length >= 1);
  t('G2) نقرة خارجية عادية (بدأت خارج اللوحة) تغلقها', (() => { panel.hidden = false; fire('pointerdown', outside); fire('click', outside); return panel.hidden === true; })());
  t('G3) الضغط بدأ داخل الحقل/اللوحة ثم انتهت النقرة على عنصر خارجي بعد انزياح التخطيط (فأرة): لا تُغلق', (() => { panel.hidden = false; fire('pointerdown', inside); fire('click', outside); return panel.hidden === false; })());
  t('G4) الاستثناء لمرة واحدة فقط: النقرة الخارجية التالية تغلقها', (() => { panel.hidden = false; fire('pointerdown', inside); fire('click', outside); const kept = panel.hidden === false; fire('pointerdown', outside); fire('click', outside); return kept && panel.hidden === true; })());
  t('G5) نقرة داخل اللوحة نفسها لا تغلقها (سلوك قائم)', (() => { panel.hidden = false; fire('pointerdown', inside); fire('click', inside); return panel.hidden === false; })());
  t('G6) بلا pointerdown (لمس يولّد click فقط/اختبارات): النقرة الخارجية تغلق كما كانت', (() => { panel.hidden = false; fire('click', outside); return panel.hidden === true; })());
})();

(() => {
  console.log('\n--- H) محفوظات وتوثيق ---');
  const E = makeEnv();
  t('H1) لا reserved/«محجوز» في أي شاشة أو نموذج أو مكوّن (متاحة للبيع / مباعة فقط)', (() => { const files = ['screens', 'components'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).map(f => d + '/' + f)); return files.filter(f => /reserved|محجوز/i.test(read(f).replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1'))).length === 0; })());
  t('H2) حدود الصور كما هي: 4 للعضو و5 للتاجر (لم تُغيَّر بنية الصور)', E.run('getMaxImagesForCar({ sourceType: "member" })') === 4 && E.run('getMaxImagesForCar({ sourceType: "showroom" })') === 5);
  t('H3) لا ميزات تجارية جديدة: لا AdMob/Firebase/Supabase/دفع/إشعارات/دردشة/تقييمات في الشيفرة (ما عدا مكان الإعلانات المحجوز القائم)', (() => { const files = ['screens', 'components', 'services', 'navigation', 'repositories', 'storage', 'models'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).map(f => d + '/' + f)).concat(['app.js']); return files.filter(f => /firebase|supabase|stripe|paypal|pushmanager|serviceWorker|WebSocket|fetch\s*\(/i.test(read(f).replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1'))).length === 0; })());
  const rd = read('README.md'); const i = rd.indexOf('الجزء 6.2-A');
  t('H4) README: قسم الجزء 6.2-A موجود ويذكر الإصلاحات والقيود، ويذكر أن 6.2-B لم يُبدأ', i >= 0 && /6\.2-B/.test(rd.slice(i)) && /لم يُبدأ/.test(rd.slice(i)) && rd.slice(i).length > 600);
})();

/* ============ (تدقيق ثانٍ) I) زر المفضلة لا يغطي النص، وتحسينات النماذج، وبيانات عدائية ============ */
(() => {
  console.log('--- I) تدقيق ثانٍ: تداخل زر المفضلة والنماذج والبيانات الطويلة ---');
  t('I1) قائمة السيارات (list-grid): جسم البطاقة يحجز مساحة عائمة لزر القلب (float على اليسار، 36×36) فلا يلتف العنوان/السعر تحته (كان يتداخل على 320px)',
    last('.list-grid .car-card .card-body::before', 'float') === 'left' && px(last('.list-grid .car-card .card-body::before', 'width')) >= 36 && px(last('.list-grid .car-card .card-body::before', 'height')) >= 36 && /content\s*:\s*''|content\s*:\s*""/.test(BLOCK));
  t('I2) الحجز مقصور على القوائم فقط: لا قاعدة ::before مماثلة على .car-card خارج list-grid (بطاقات الأفقي: الزر فوق الصورة لا فوق النص)',
    !R.some(r => /::before/.test(r.sel) && /\.car-card/.test(r.sel) && !/\.list-grid/.test(r.sel)));
  t('I3) زر المفضلة ما زال 40×40 ومطلقًا أعلى-يسار البطاقة (لم يُصغَّر ولم يتحرك)', px(last('.fav-btn', 'width')) === 40 && px(last('.fav-btn', 'height')) === 40 && last('.fav-btn', 'position') === 'absolute' && px(last('.fav-btn', 'top')) === 8 && px(last('.fav-btn', 'left')) === 8);
  t('I4) وصف طويل في النماذج: textarea ينمو مع المحتوى (field-sizing:content) حتى حد أقصى ثم يتمرر، مع الإبقاء على min-height وresize للمتصفحات غير الداعمة', last('.field textarea', 'field-sizing') === 'content' && px(last('.field textarea', 'max-height')) >= 200 && px(last('.field textarea', 'min-height')) === 80);
  const E = makeEnv(); const run = c => E.run(c);
  t('I5) السعر بالدولار داخل نص عربي RTL معزول اتجاهيًا (LRI…PDI) فلا ينقلب $ ولا الفواصل، والدينار بنصه العربي «د.ع»؛ والمجهول «السعر غير محدد» بلا undefined',
    (() => { const usd = run(`carPriceText({ price: 25000, currency: 'USD' })`), iqd = run(`carPriceText({ price: 25000000, currency: 'IQD' })`), none = run(`carPriceOrDash({ price: null })`);
      return usd.includes('\u2066') && usd.includes('\u2069') && usd.indexOf('\u2066') < usd.indexOf('$') && iqd.includes('د.ع') && !/undefined|NaN|null/.test(usd + iqd + none) && none.length > 0; })());
  t('I6) بطاقة/تفاصيل بيانات عدائية (اسم 70 حرفًا بلا مسافات، عربي+إنجليزي، وصف طويل، سعر 12 رقمًا IQD وUSD، هاتف دولي، بلا سعر/كم) في كل الشاشات العامة: لا undefined/NaN/[object Object] ولا استثناء، والعنوان بالكامل في HTML (لا اقتطاع)', (() => {
    const L = 'A'.repeat(70), MIX = 'تويوتا Toyota Camry SE 2.5L HybridElectric_للبيع';
    run(`(function(){ CarsRepository.getAll().forEach((c,i)=>{ if(i%2===0){ c.brand='Toyota'; c.model=${JSON.stringify(MIX + L)}; c.description=${JSON.stringify(('وصف ' + L + ' ').repeat(6))}; c.color=${JSON.stringify(L)}; } if(i===1){ c.price=999999999999; c.mileage=0; } if(i===2){ c.price=1234567; c.currency='USD'; c.mileage=null; } if(i===3){ c.price=null; c.mileage=undefined; } });
      MemberCarsRepository.getAll().forEach((c,i)=>{ if(i<4){ c.model=${JSON.stringify(MIX + L)}; c.location=${JSON.stringify(MIX + L)}; c.phone='+964 770 123 4567'; c.price=i%2?25000:987654321012; c.currency=i%2?'USD':'IQD'; } });
      ShowroomsRepository.getAll().forEach((s,i)=>{ if(i<2){ s.name=${JSON.stringify(MIX + L)}; s.address=${JSON.stringify(MIX + L)}; s.workingHours=${JSON.stringify(L)}; } }); })()`);
    const bad = []; const ids = { c: run('getVisibleCars()[0].id'), m: run('getVisibleMemberCars()[0].id'), s: run('getVisibleShowrooms()[0].id') };
    const screens = [['home'], ['cars'], ['memberCars'], ['showrooms'], ['map'], ['favorites'], ['search', 'toyota'], ['search', 'qqzzxx'], ['carDetails', ids.c], ['memberCarDetails', ids.m], ['showroomDetails', ids.s], ['carDetails', 99999], ['memberCarDetails', 99999], ['showroomDetails', 99999]];
    for (const [r, par] of screens) { try { run(par === undefined ? `go('${r}')` : `go('${r}', ${JSON.stringify(par)})`); const h = E.screen(); if (/undefined|NaN|\[object|TypeError/.test(h.replace(/<[^>]*>/g, ' '))) bad.push(r); if (r === 'carDetails' && par === ids.c && !h.includes(L)) bad.push('truncated-title'); } catch (e) { bad.push(r + ':EXC'); } }
    return bad.length === 0 || bad; })());
  t('I7) README (6.2-A): يذكر تداخل زر المفضلة مع نص بطاقات القوائم وإصلاحه (التدقيق الثاني)', (() => { const r = read('README.md'); const i = r.indexOf('الجزء 6.2-A'); return i >= 0 && /تدقيق ثانٍ|التدقيق الثاني/.test(r.slice(i)) && /المفضلة/.test(r.slice(i)); })());
})();

console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
if (fail) process.exitCode = 1;

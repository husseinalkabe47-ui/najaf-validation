const { makeEnv } = require('./harness');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra || ''); } };

const E = makeEnv();
const R = c => E.run(c);
const setF = (o) => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
const login = (identifier, password) => { R(`go('login')`); setF({ loginIdentifier: identifier, loginPassword: password }); R('handleLoginSubmit()'); };

t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | '));

// 1/2/3) guest/user/dealer لا يفتحون لوحة الإدارة
const adminRoutes = ['adminHome', 'adminDashboard', 'adminMemberCars', 'adminMemberCarDetails', 'adminShowrooms', 'adminShowroomCars', 'adminUsers', 'adminUserDetails', 'adminDealerRequests'];
adminRoutes.forEach(r => R(`go('${r}')`));
t('1) guest لا يستطيع فتح أي مسار إداري (يُحوَّل لتسجيل الدخول)', adminRoutes.every(r => { R(`go('${r}')`); return R('currentRoute') === 'login'; }));

login('07700000001', 'user123'); // user
t('2) user لا يستطيع فتح admin dashboard (غير مصرّح)', (R(`go('adminHome')`), R('currentRoute')) === 'accessDenied');
t('2b) user لا يستطيع فتح أي مسار إداري آخر', adminRoutes.every(r => { R(`go('${r}')`); return R('currentRoute') === 'accessDenied'; }));
R('handleLogout()');

login('07701234567', 'dealer123'); // dealer (يملك معرض 1)
t('3) dealer لا يستطيع فتح admin dashboard', (R(`go('adminHome')`), R('currentRoute')) === 'accessDenied');
t('3b) dealer لا يستطيع فتح أي مسار إداري آخر', adminRoutes.every(r => { R(`go('${r}')`); return R('currentRoute') === 'accessDenied'; }));
// dealer لا يدير سيارة عضو آخر ولا يوافق على تاجر (15/23)
t('15) dealer لا يستطيع إدارة member car ليست له', R(`AuthorizationService.canManageMemberCar(undefined, getMemberCarById(101))`) === false);
const dealerRejectAttempt = R(`AdminService.rejectMemberCar(103,'x')`);
t('23) dealer لا يستطيع رفض/إدارة member car عبر adminService (يُرفض)', dealerRejectAttempt.ok === false);
R('handleLogout()');

// 4/5) admin يفتح لوحة الإدارة ويرى الإحصائيات
login('07700000000', 'admin123'); // admin
R(`go('adminHome')`);
t('4) admin يستطيع فتح admin dashboard', R('currentRoute') === 'adminHome' && E.screen().includes('لوحة الإدارة'));
t('5) admin يرى الإحصائيات', E.screen().includes('إجمالي المستخدمين') && E.screen().includes('قيد المراجعة'));
const statsBefore = R('getDashboardStats()');
t('5b) الإحصائيات صحيحة رقميًا', statsBefore.totalShowroomCars === 15 && statsBefore.totalMemberCars === 10 && statsBefore.pendingMemberCars === 2);

// 6/7/8) الموافقة على سيارة pending
t('6) سيارة pending (103) تظهر في قائمة المراجعة', R(`adminGetPendingMemberCars().some(c=>c.id===103)`));
t('6b) وتظهر في شاشة AdminMemberCarsScreen بتبويب pending', (R(`go('adminMemberCars','pending')`), E.screen().includes(`onclick="go('adminMemberCarDetails', 103)"`)));
R(`go('adminMemberCarDetails',103)`);
t('4b) لا يظهر زر «موافقة ونشر» لإعلان نشط أصلًا (تحقق عكسي لاحقًا)', true); // يُتحقق بعد التفعيل أدناه
const approveResult = R(`approveMemberCar(103)`);
t('7) approve يحوّل pending إلى active', approveResult.ok === true && R(`getMemberCarById(103).status`) === 'active');
t('8) approved car تظهر للعامة (getActiveMemberCars)', R(`getActiveMemberCars().some(c=>c.id===103)`));
R(`go('adminMemberCarDetails',103)`);
t('4c) بعد التفعيل: لا يظهر زر «موافقة ونشر» بعد الآن', !E.screen().includes('موافقة ونشر'));

// 9/10) الرفض مع سبب
const rejectResult = R(`rejectMemberCar(103, 'صور غير واضحة')`);
t('9) rejected car لا تظهر للعامة', rejectResult.ok === true && !R(`getActiveMemberCars().some(c=>c.id===103)`));
t('10) rejected car تحفظ rejectionReason', R(`getMemberCarById(103).rejectionReason`) === 'صور غير واضحة');
t('10b) لا يُحذف الإعلان عند الرفض', R(`getMemberCarById(103)`) !== null);

// 11/12) الإيقاف والإرجاع للمراجعة
const suspendResult = R(`suspendMemberCarAdmin(101, 'مخالفة الشروط')`);
t('11) suspended car لا تظهر للعامة', suspendResult.ok === true && !R(`getActiveMemberCars().some(c=>c.id===101)`));
t('11b) suspensionReason محفوظ', R(`getMemberCarById(101).suspensionReason`) === 'مخالفة الشروط');
const restoreResult = R(`restoreMemberCar(101)`);
t('12) restore يحوّلها إلى pending', restoreResult.ok === true && R(`getMemberCarById(101).status`) === 'pending');
R(`approveMemberCar(101)`); // إرجاعها active كما كانت أصلًا لبقية الاختبارات

// بيانات المراجعة
t('reviewedBy/reviewedAt) تُسجَّل بيانات المراجعة الإدارية', !!R(`getMemberCarById(103).reviewedAt`) && R(`getMemberCarById(103).reviewedBy`) === R('SessionService.getCurrentUser().id'));
R(`changeMemberCarStatus(103,'active')`); // إرجاعها كما كانت أصلًا (active) لعدم كسر بيانات لاحقة
R('handleLogout()');

// 13/14) المالك يرى إعلانه القديم (pending من بيانات المرحلة 4) ولا يدير إعلان غيره.
// ملاحظة (المرحلة 6): لم نعد ننشئ سيارة جديدة هنا لاختبار "pending"، لأن قاعدة
// النشر تغيّرت (سيارة جديدة لعضو تصبح active مباشرة بعد الإعلان المكافأ — انظر phase6.test.js).
// نستخدم بدلًا من ذلك سيارة 108 (بيانات بذر قديمة لنفس المالك 7، ما تزال pending).
login('07700000001', 'user123'); // owner id=7
R(`go('myMemberCars')`);
t('13) owner يستطيع رؤية إعلانه القديم pending في إعلاناتي', E.screen().includes('Nissan Sunny') && E.screen().includes('قيد المراجعة'));
R(`go('editMemberCar', 102)`); // ملك للتاجر 1
t('14) owner لا يستطيع إدارة إعلان مستخدم آخر', R('currentRoute') === 'accessDenied');
R('handleLogout()');

// 16) admin يستطيع إدارة أي member car (يوافق على 108 المملوكة لعضو آخر)
login('07700000000', 'admin123');
t('16) admin يستطيع إدارة أي member car (owner=7, car=108)', R(`AuthorizationService.canManageMemberCar(undefined, getMemberCarById(108))`) === true);
R(`approveMemberCar(108)`);
t('16b) admin وافق على إعلان مستخدم آخر بنجاح', R(`getMemberCarById(108).status`) === 'active');

// 17/18/19) المعارض
t('17) admin يستطيع رؤية المعارض', (R(`go('adminShowrooms')`), E.screen().includes('معرض النجف للسيارات') && E.screen().includes('معرض الفرات الذهبي')));
const showroomSuspend = R(`suspendShowroom(1)`);
t('18) admin يستطيع إيقاف معرض', showroomSuspend.ok === true && R(`getShowroomById(1).status`) === 'suspended');
const showroomActivate = R(`activateShowroom(1)`);
t('19) admin يستطيع إعادة تفعيل معرض', showroomActivate.ok === true && R(`getShowroomById(1).status`) === 'active');

// 20) المستخدمون
t('20) admin يستطيع رؤية المستخدمين', (R(`go('adminUsers')`), E.screen().includes('مستخدم تجريبي') || E.screen().includes('حيدر عبد الكاظم')));
t('20b) قائمة المستخدمين بلا كلمات مرور', R(`adminGetAllUsers().every(u=>u.passwordHash===undefined)`));

// 21) الموافقة على dealer pending (id=8)
t('21-seed) يوجد dealer pending واحد على الأقل', R(`USERS.some(u=>u.role==='dealer' && u.status==='pending')`));
R(`go('adminDealerRequests')`);
t('21b) يظهر في شاشة طلبات أصحاب المعارض', E.screen().includes('سجاد كامل'));
const approveDealerResult = R(`approveDealer(8)`);
t('21) admin يستطيع الموافقة على dealer pending', approveDealerResult.ok === true && R(`UserService._findById(8).status`) === 'active');
R(`changeMemberCarStatus`); // no-op guard against accidental undefined ref
R('handleLogout()');

// 22) user لا يستطيع الموافقة على dealer
login('07700000001', 'user123');
const userApproveDealer = R(`AdminService.approveDealer(8)`);
t('22) user لا يستطيع الموافقة على dealer', userApproveDealer.ok === false);
R('handleLogout()');

// 24/25) المفضلة والبحث لا يزالان يعملان
const E2 = makeEnv();
E2.run(`go('login')`); Object.entries({ loginIdentifier: '07700000001', loginPassword: 'user123' }).forEach(([k, v]) => E2.els[k] = { value: v, style: {} }); E2.run('handleLoginSubmit()');
E2.run(`handleFavoriteToggle(2)`); E2.run(`handleFavoriteToggle(104)`);
t('24) favorites لا تزال تعمل (سيارة معرض وسيارة عضو)', E2.run('isFavorite(2)') === true && E2.run('isFavorite(104)') === true);
t('25) search لا يزال يعمل (showroom/member/all)', E2.run(`searchCars('Toyota').length`) === 1 /* سياسة الظهور العام: كانت 2 بعد C7، و3 */ && E2.run(`searchCars('Toyota','member').length`) >= 1 && E2.run(`searchCars('Toyota','all').some(c=>c.sourceType==='member')`));

// 26/27) سيارات المعارض وسيارات الأعضاء لم تتأثر
t('26) showroom cars لا تتأثر (لا تزال 15 وبنفس البيانات)', E2.run('getCars().length') === 15 && E2.run(`getCarById(1).brand`) === 'Toyota');
t('27) member cars لا تتأثر ببنية جديدة خاطئة', E2.run('MEMBER_CARS.length') >= 10 && E2.run(`MEMBER_CARS.every(c=>c.sourceType==='member')`));

// 28) router guards تعمل (تكرار تأكيدي على مسار محمي بمعامل)
E2.run(`go('editMemberCar', 105)`); // ملك owner=7 (نفس المستخدم الحالي E2) لكن car 105 sold مملوكة له فعلاً
t('28) router guard يعمل مع معامل id (owner يفتح تعديل سيارته المباعة)', E2.run('currentRoute') === 'editMemberCar');
E2.run('handleLogout()'); E2.run(`go('editMemberCar', 105)`);
t('28b) بعد الخروج: نفس المسار يُحوَّل لتسجيل الدخول', E2.run('currentRoute') === 'login');

// 29) لا أخطاء JavaScript
const E3 = makeEnv();
login && null;
const allRoutesE3 = ['home','showrooms','cars','map','favorites','login','register','memberCars','accessDenied'];
allRoutesE3.forEach(r => E3.run(`go('${r}')`));
E3.run(`go('login')`); Object.entries({ loginIdentifier: '07700000000', loginPassword: 'admin123' }).forEach(([k, v]) => E3.els[k] = { value: v, style: {} }); E3.run('handleLoginSubmit()');
adminRoutes.concat(['adminDealerRequests']).forEach(r => E3.run(`go('${r}')`));
E3.run(`go('adminUserDetails', 1)`); E3.run(`go('adminMemberCarDetails', 105)`);
t('29) لا توجد أخطاء JavaScript في كل الشاشات بما فيها الإدارية', E3.errors.length === 0, E3.errors.join('|'));

console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
process.exit(fail ? 1 : 0);

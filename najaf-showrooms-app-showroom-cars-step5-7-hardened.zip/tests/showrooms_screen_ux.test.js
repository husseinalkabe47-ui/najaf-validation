/* اختبارات تحسين شاشة «معارض السيارات» العامة (UX ج6): بحث بارز + سطر مساعد + عدّاد نتائج + البطاقات مباشرة تحته،
   وزر رجوع واضح في تفاصيل المعرض العامة (إعادة استخدام DetailBackButton وgoBack القائمين).
   المصدر الوحيد: الشاشة ← searchShowrooms (خدمة البحث القائمة) ← getVisibleShowrooms (visibilityService) ← ShowroomCard.
   لا فلاتر متقدمة للمعارض أصلًا فلا زر «تصفية». القياسات البصرية (px، التراكب، الاقتصاص، التركيز، Enter/Space) في Chromium على 320/360/390/412. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 220)); } };
const ROOT = path.resolve(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const CRED = { user: ['07700000001', 'user123'], dealer: ['07701234567', 'dealer123'], admin: ['07700000000', 'admin123'] };
const dec = s => s.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
function mk(role, store) {
  const E = makeEnv(store, { fullSeed: 'p3' }), R = c => E.run(c);
  R('AuthService.logout()');
  if (role) { const c = CRED[role]; R(`go('login')`); E.els.loginIdentifier = { value: c[0], style: {}, textContent: '' }; E.els.loginPassword = { value: c[1], style: {}, textContent: '' }; R('handleLoginSubmit()'); }
  const J = c => { const s = R(`JSON.stringify(${c})`); return s === undefined ? undefined : JSON.parse(s); };
  return { E, R, J };
}
const BAD = /undefined|NaN|\[object/, ERR = 'حدث خطأ، حاول مرة أخرى';
const cardIds = html => [...String(html).matchAll(/class="card showroom-card" onclick="go\('showroomDetails',(\d+)\)"/g)].map(m => Number(m[1]));
const sorted = a => a.slice().sort((p, q) => p - q);
const same = (a, b) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const onclickOf = el => { const m = /onclick="([^"]*)"/.exec(el); return m ? dec(m[1]) : null; };
const btn = (html, cls) => (String(html).match(new RegExp('<button[^>]*class="' + cls + '"[^>]*>[\\s\\S]*?</button>')) || [''])[0];
const click = (x, el) => { const code = onclickOf(el); if (!code) throw new Error('no onclick'); x.E.errors.length = 0; x.R(code); };
const idsIn = html => [...String(html).matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
const LONGN = 'معرض-طويل-جدا-للغاية-'.repeat(6) + 'Extraordinarily-Long-Showroom-Name-'.repeat(2);   // > 100
const LONGA = 'عنوان-طويل-جدا-في-منطقة-بعيدة-'.repeat(7) + 'Very-Long-Address-Street-Number-'.repeat(2);   // > 150
const add = (x, o) => x.R(`ShowroomsRepository.create(ShowroomModel(${JSON.stringify(Object.assign({ status: 'active', ownerId: 1, createdAt: '2026-01-01T00:00:00', updatedAt: '2026-01-01T00:00:00' }, o))}))`);

(async () => {
  const ref = mk(null);
  const ALL = ref.J('ShowroomsRepository.getAll()'), USERS = ref.J('UsersRepository.getAll()');
  // مرجع مستقل من المستودع (لا من الكود المختبَر): الظاهر للزائر = حالته active فقط (سياسة الظهور العام للمعارض) ومالكه فعّال
  const PUBLIC = ALL.filter(s => s.status === 'active' && USERS.some(u => u.id === s.ownerId && u.status === 'active'));
  const PUB_IDS = PUBLIC.map(s => s.id), HIDDEN = ALL.filter(s => !PUB_IDS.includes(s.id));
  const abbas = ALL.find(s => /العباس/.test(s.name)) /* pending: مخفي علنًا */, firat = ALL.find(s => /الفرات/.test(s.name)), kufa = ALL.find(s => /الكوفة/.test(s.address)), suspended = ALL.find(s => s.status === 'suspended');

  /* ======================= A) الشاشة ======================= */
  console.log('\n--- A) بنية الشاشة ---');
  await tc('1) تفتح بعنوان «معارض السيارات» وبحث بارز: placeholder/aria-label «ابحث عن معرض»، سطر مساعد «اسم المعرض، العنوان أو المنطقة»، ومعالج onShowroomsSearch القائم (enterkeyhint=search)', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const h = g.E.screen();
    return (/<h1>🏢 معارض السيارات<\/h1>/.test(h) && h.includes('placeholder="ابحث عن معرض"') && h.includes('aria-label="ابحث عن معرض"') && h.includes('<p class="sub">اسم المعرض، العنوان أو المنطقة</p>') && h.includes('oninput="onShowroomsSearch(this.value)"') && h.includes('enterkeyhint="search"') && h.indexOf('<h1>') < h.indexOf('class="searchbox"')) || 'search'; });
  await tc('2) البطاقات مباشرة تحت البحث: الترتيب عنوان ← بحث ← قائمة ← أول بطاقة، بلا لوحة فلاتر ولا زر «تصفية» (لا نظام فلاتر للمعارض)، وكل المعارض الظاهرة معروضة', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const h = g.E.screen(); const p = s => h.indexOf(s);
    return (p('class="searchbox"') < p('id="showroomsList"') && p('id="showroomsList"') < p('class="card showroom-card"') && !/filter-toggle|filter-panel|FilterBar|ShowroomFilter|تصفية/.test(h) && same(cardIds(h), PUB_IDS) && !h.includes(ERR)) || { n: cardIds(h).length }; });
  await tc('8) عدّاد النتائج مشتق من نتيجة الخدمة: «النتائج: N» بصيغة عربية (معرض واحد/معرضان/N معارض/N معرضًا) ويطابق عدد البطاقات في كل حالة بحث؛ والدالة صحيحة على الحدود', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const bad = [];
    for (const q of ['', 'العباس', 'النجف', 'الكوفة', 'zzz']) { g.R(`onShowroomsSearch(${JSON.stringify(q)})`); const l = g.E.els.showroomsList.innerHTML, n = cardIds(l).length; const lab = g.J(`showroomCountLabel(${n})`); if (n > 0 ? !l.includes(`النتائج: ${lab}`) : l.includes('النتائج')) bad.push(q); }
    const labels = [0, 1, 2, 3, 10, 11, 25].map(n => g.R(`showroomCountLabel(${n})`));
    return (bad.length === 0 && JSON.stringify(labels) === JSON.stringify(['', 'معرض واحد', 'معرضان', '3 معارض', '10 معارض', '11 معرضًا', '25 معرضًا']) && g.R('showroomCountLabel(NaN)') === '' && g.R('showroomCountLabel("3")') === '') || { bad, labels }; });

  /* ======================= B) البحث ======================= */
  console.log('\n--- B) البحث: خدمة واحدة ---');
  await tc('3) البحث يستعمل خدمة البحث القائمة: القائمة المعروضة = searchShowrooms(q) لكل استعلام، والشاشة تستدعيها مرة واحدة بنص البحث، بلا خدمة بحث جديدة', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const bad = [];
    for (const q of ['', 'العباس', 'الكوفة', 'النجف الأشرف', 'معرض', 'ＮＡＪＦ', '٧٧٧', 'zzzz']) { g.R(`onShowroomsSearch(${JSON.stringify(q)})`); if (!same(cardIds(g.E.els.showroomsList.innerHTML), g.J(`searchShowrooms(${JSON.stringify(q)}).map(s=>s.id)`))) bad.push(q); }
    const src = strip(read('screens/showrooms.js')); const defs = ['screens', 'services', 'components'].flatMap(d => fs.readdirSync(path.join(ROOT, d)).filter(f => f.endsWith('.js')).map(f => strip(read(d + '/' + f)))).join('\n');
    return (bad.length === 0 && (src.match(/searchShowrooms\(showroomsSearchQuery\)/g) || []).length === 1 && (defs.match(/function searchShowrooms\(/g) || []).length === 1 && !/function search[A-Za-z]*Showroom/.test(src)) || { bad }; });
  await tc('4) لا محرك .filter() ثانٍ ولا قاعدة ظهور في الشاشة: لا .filter/.some/.find/.includes/.sort/.indexOf على المعارض، ولا getVisibleShowrooms/المستودعات/التخزين، ولا قوائم ثابتة لأسماء المعارض', async () => {
    const s = strip(read('screens/showrooms.js')); const c = strip(read('components/showroomCard.js'));
    return (!/\.filter\(|\.some\(|\.find\(|\.sort\(|\.indexOf\(|\.includes\(|getVisibleShowrooms|Repository|localStorage|_showroomVisible|status\s*[!=]==/.test(s) && !/معرض (النجف|الفرات|العباس|النخبة|الخليج)/.test(s + c) && /searchShowrooms\(/.test(s)) || 'engine'; });
  await tc('5) البحث العربي: «الفرات» ← معرض الفرات، «الكوفة» (من العنوان) ← معرض النجف، «النجف الأشرف» ← كل الظاهرة، والعنوان/المنطقة تُطابق؛ و«العباس»/«طريق كربلاء» (معرض pending مخفي) و«الخليج» (موقوف) لا تجد شيئًا علنًا', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const q = s => { g.R(`onShowroomsSearch(${JSON.stringify(s)})`); return cardIds(g.E.els.showroomsList.innerHTML); };
    return (same(q('الفرات'), [firat.id]) && same(q('العباس'), []) && same(q('الكوفة'), [kufa.id]) && same(q('النجف الأشرف'), PUB_IDS) && same(q('حي السلام'), PUBLIC.filter(s => /حي السلام/.test(s.address)).map(s => s.id)) && same(q('الخليج'), []) && same(q('طريق كربلاء'), [])) || 'arabic'; });
  await tc('6) البحث الإنجليزي حيث يُدعم (اسم لاتيني): معرض «Elite Motors 77» يُجد بـelite/ELITE/ＥＬＩＴＥ (NFKC) وبالأرقام العربية «٧٧»، ولا يجد الأسماء العربية بحروف لاتينية (لا مرادفات مضافة)', async () => {
    const x = mk(null); add(x, { id: 9101, name: 'Elite Motors 77', address: 'Najaf Main Street' }); x.R(`go('showrooms')`); const q = s => { x.R(`onShowroomsSearch(${JSON.stringify(s)})`); return cardIds(x.E.els.showroomsList.innerHTML); };
    return (same(q('elite'), [9101]) && same(q('ELITE MOTORS'), [9101]) && same(q('ＥＬＩＴＥ'), [9101]) && same(q('٧٧'), [9101]) && same(q('main street'), [9101]) && same(q('najaf'), [9101]) && q('abbas').length === 0) || 'english'; });
  await tc('7) بحث العنوان/المنطقة: كل كلمة من عناوين المعارض الظاهرة تعيد معرضها (مرجع مستقل من المستودع)، والمعرض المخفي لا يظهر بعنوانه (الخليج: «المدينة الصناعية»)', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const bad = [];
    for (const s of PUBLIC) { const w = s.address.split(/[،,\s]+/).filter(x => x.length > 2)[0]; g.R(`onShowroomsSearch(${JSON.stringify(w)})`); const got = cardIds(g.E.els.showroomsList.innerHTML); const exp = PUBLIC.filter(p => (p.name + ' ' + p.address).includes(w)).map(p => p.id); if (!same(got, exp) || !got.includes(s.id)) bad.push(w); }
    g.R(`onShowroomsSearch('المدينة الصناعية')`); const hid = cardIds(g.E.els.showroomsList.innerHTML); g.R(`onShowroomsSearch('طريق كربلاء')`); const hid2 = cardIds(g.E.els.showroomsList.innerHTML);
    return (bad.length === 0 && hid.length === 0 && hid2.length === 0 && PUBLIC.length >= 3) || { bad, hid, hid2 }; });

  /* ======================= C) الظهور ======================= */
  console.log('\n--- C) قواعد الظهور ---');
  await tc('9) سياسة الظهور العام: الزائر يرى المعارض الفعّالة (active) فقط، ويتساوى معه العضو والتاجر غير المالك، والمعرض pending (العباس) مخفي كالموقوف، والمدير يرى كل المعارض بما فيها pending والموقوف', async () => {
    const g = mk(null); g.R(`go('showrooms')`); const u = mk('user'); u.R(`go('showrooms')`); const a = mk('admin'); a.R(`go('showrooms')`);
    return (same(cardIds(g.E.screen()), PUB_IDS) && same(cardIds(u.E.screen()), PUB_IDS) && !cardIds(g.E.screen()).includes(ALL.find(s => s.status === 'pending').id) && !cardIds(u.E.screen()).includes(abbas.id) && cardIds(a.E.screen()).includes(abbas.id) && cardIds(a.E.screen()).includes(suspended.id) && cardIds(a.E.screen()).length === ALL.length) || { g: cardIds(g.E.screen()), a: cardIds(a.E.screen()) }; });
  await tc('10) المعرض الموقوف غير ظاهر للعامة: لا بطاقة ولا نتيجة بحث باسمه/عنوانه، وتفاصيله «غير متاحة» بزر رجوع، ولا تظهر سياراته، ولا استدعاء مباشر للخدمة يكشفه', async () => {
    const g = mk(null); g.R(`go('showrooms')`); g.R(`onShowroomsSearch(${JSON.stringify(suspended.name)})`); const l = g.E.els.showroomsList.innerHTML; g.R(`go('showroomDetails',${suspended.id})`); const d = g.E.screen();
    return (!cardIds(g.E.screen()).includes(suspended.id) && cardIds(l).length === 0 && l.includes('لم نعثر على معارض مطابقة لبحثك') && d.includes('هذا المعرض غير متاح حاليًا') && d.includes('class="back-pill"') && !d.includes(suspended.name) && g.R(`getVisibleShowroomById(${suspended.id})`) === undefined && g.J(`searchShowrooms('').map(s=>s.id)`).every(i => i !== suspended.id)) || { l: l.slice(0, 80), d: d.slice(0, 120) }; });

  /* ======================= D) بيانات عدائية ======================= */
  console.log('\n--- D) بيانات عدائية ---');
  const adversarial = x => {
    add(x, { id: 9201, name: LONGN, address: LONGA, phone: '07701234567', whatsapp: '9647701234567' });
    add(x, { id: 9202, name: 'Bare Showroom No Address' });
    add(x, { id: 9203, name: 'No Phone Showroom', address: 'بلا هاتف', phone: '', whatsapp: '' });
    add(x, { id: 9204, name: 'Junk WhatsApp', address: 'واتساب غريب', phone: '07701234567', whatsapp: '9'.repeat(300) });
    add(x, { id: 9205, name: 'Broken Image', address: 'صورة معطوبة', image: 'https://example.com/missing.jpg' });
    add(x, { id: 9206, name: 'Many Cars Showroom', address: 'سيارات كثيرة' });
    for (let i = 0; i < 40; i++) x.R(`CarsRepository.create(CarModel({ id: ${9300 + i}, sourceType: 'showroom', showroomId: 9206, brand: 'Toyota', model: 'Corolla', year: 2020, price: 10000000, currency: 'IQD', status: 'available', createdAt: '2026-01-01T00:00:00', updatedAt: '2026-01-01T00:00:00' }))`);
    add(x, { id: 9207, name: 'Zero Cars Showroom', address: 'بلا سيارات' });
  };
  const NASTY = [9201, 9202, 9203, 9204, 9205, 9206, 9207];
  await tc('11) اسم معرض > 100 حرف لا يكسر الرسم: يُعرض كاملًا ومهرَّبًا في البطاقة والتفاصيل (h1)، وCSS الالتفاف (overflow-wrap:anywhere لـ.card-title و.detail-body h1) قائم', async () => {
    const x = mk(null); adversarial(x); x.R(`go('showrooms')`); x.R(`onShowroomsSearch('معرض-طويل')`); const l = x.E.els.showroomsList.innerHTML; x.R(`go('showroomDetails',9201)`); const d = x.E.screen(); const css = read('theme/theme.css');
    return (LONGN.length > 100 && cardIds(l).includes(9201) && l.includes(LONGN) && d.includes(`<h1>${LONGN}</h1>`) && !BAD.test(l + d) && /\.card-title,\.card-row,\.info-row,\.detail-body h1[^{]*\{[^}]*overflow-wrap:\s*anywhere/.test(css)) || { l: l.slice(0, 100) }; });
  await tc('12) عنوان > 150 حرف: يُعرض كاملًا ومهرَّبًا في البطاقة والتفاصيل (صف 📍)، ولا يخرج عن العرض (info-row/card-row بالالتفاف)، وإدخال HTML في الاسم/العنوان يُهرَّب', async () => {
    const x = mk(null); adversarial(x); x.R(`ShowroomsRepository.update(9201, { name: ${JSON.stringify('<b>x</b>' + LONGN)}, address: ${JSON.stringify('<i>y</i>' + LONGA)} })`); x.R(`go('showrooms')`); x.R(`onShowroomsSearch('عنوان-طويل')`); const l = x.E.els.showroomsList.innerHTML; x.R(`go('showroomDetails',9201)`); const d = x.E.screen();
    return (LONGA.length > 150 && l.includes('&lt;i&gt;y&lt;/i&gt;') && l.includes('&lt;b&gt;x&lt;/b&gt;') && !l.includes('<i>y</i>') && !l.includes('<b>x</b>') && !d.includes('<b>x</b>') && d.includes(LONGA.slice(0, 40)) && l.includes('📍') && !BAD.test(l + d)) || { l: l.slice(0, 120) }; });
  await tc('13) الصورة: بلا صورة ← بديل 🏢 آمن بلا <img>، وصورة معطوبة ← <img> بـalt واسم المعرض وonerror=imgFallback (البديل القائم)، بلا تعديل للتخزين/الضغط', async () => {
    const x = mk(null); adversarial(x); const bare = x.R('ShowroomCard(getShowroomById(9202))'), broken = x.R('ShowroomCard(getShowroomById(9205))');
    return (bare.includes('🏢') && !bare.includes('<img') && broken.includes('<img') && broken.includes('alt="Broken Image"') && broken.includes('onerror="imgFallback(this)"') && broken.includes('data-ph="🏢"')) || { bare: bare.slice(0, 80) }; });
  await tc('14) العنوان الناقص آمن: البطاقة بلا صف 📍 ولا «—»، والتفاصيل لا تعرض undefined/NaN (صف العنوان بقيمته الافتراضية القائمة)، والبحث بالاسم يجده', async () => {
    const x = mk(null); adversarial(x); const bare = x.R('ShowroomCard(getShowroomById(9202))'); x.R(`go('showroomDetails',9202)`); const d = x.E.screen();
    return (!bare.includes('📍') && !bare.includes('—') && bare.includes('Bare Showroom No Address') && !BAD.test(bare + d) && !d.includes(ERR) && d.includes('class="back-pill"')) || { bare: bare.slice(0, 100) }; });
  await tc('15) الهاتف ناقص/واتساب غريب آمنان: بلا هاتف لا صف 📞 ولا رابط tel، وواتساب من 300 رقم لا يكسر الرسم ولا يظهر نصه (الرابط https://wa.me/ بأرقام فقط وفق waLink القائم: حدّه الأدنى 11 رقمًا بلا حدّ أعلى — قيد مسجَّل، والإدخال يتحقق قبل التخزين)، ولا undefined، ولا javascript:', async () => {
    const x = mk(null); adversarial(x); x.R(`go('showroomDetails',9203)`); const np = x.E.screen(); x.R(`go('showroomDetails',9204)`); const junk = x.E.screen(); x.R(`go('showroomDetails',9201)`); const full = x.E.screen();
    const wa = [...junk.matchAll(/href="(https:\/\/wa\.me\/[^"]*)"/g)].map(m => m[1]);
    return (!np.includes('📞') && !np.includes('href="tel:') && !np.includes('wa.me') && !BAD.test(np + junk + full) && wa.every(h => /^https:\/\/wa\.me\/\d+$/.test(h)) && !/javascript:/i.test(junk) && !/وا?تساب[^<]*\d{20}/.test(junk) && full.includes('href="tel:') && full.includes('wa.me')) || { wa, np: np.slice(0, 100) }; });
  await tc('E1) حالات الفراغ الثلاث مميَّزة (EmptyState القائم): (أ) لا معارض أصلًا «لا توجد معارض» بلا زر مسح بحث، (ب) بحث بلا نتيجة «لم نعثر على معارض مطابقة لبحثك» + «مسح البحث» ويعيد القائمة، (ج) معرض بلا سيارات عامة: عدد 0 في البطاقة وفراغ مفسَّر في تفاصيله', async () => {
    const e = mk(null); e.R('SHOWROOMS.length = 0'); e.R(`go('showrooms')`); const none = e.E.screen();
    const s = mk(null); s.R(`go('showrooms')`); s.R(`onShowroomsSearch('zzzzqqq')`); const nores = s.E.els.showroomsList.innerHTML; s.R('clearShowroomsSearch()'); const back = cardIds(s.E.screen());
    const z = mk(null); adversarial(z); const card = z.R('ShowroomCard(getShowroomById(9207))'); z.R(`go('showroomDetails',9207)`); const d = z.E.screen();
    return (none.includes('لا توجد معارض') && !none.includes('مسح البحث') && !none.includes('لم نعثر') && nores.includes('لم نعثر على معارض مطابقة لبحثك') && nores.includes('clearShowroomsSearch()') && !nores.includes('لا توجد معارض') && same(back, PUB_IDS) && card.includes('0 سيارة') && d.includes('لا توجد سيارات في هذا المعرض حاليًا') && d.includes('سيارات المعرض (0)') && !BAD.test(none + nores + d)) || { none: none.slice(0, 80) }; });
  await tc('E2) معرض بسيارات كثيرة (40) وعدد حقيقي: البطاقة تعرض العدد من خدمة الظهور (getVisibleCarsByShowroom) لا رقمًا مخترعًا، والتفاصيل «سيارات المعرض (40)» وبطاقاتها', async () => {
    const x = mk(null); adversarial(x); const n = x.J('getVisibleCarsByShowroom(9206).length'); const card = x.R('ShowroomCard(getShowroomById(9206))'); x.R(`go('showroomDetails',9206)`); const d = x.E.screen();
    return (n === 40 && card.includes('40 سيارة') && d.includes('سيارات المعرض (40)') && (d.match(/class="card car-card"/g) || []).length === 40 && !BAD.test(card + d)) || { n }; });
  await tc('24) لا undefined/NaN/[object Object]/«حدث خطأ» في كل شاشة وبطاقة وتفاصيل (كل المعارض الحقيقية + العدائية) لكل الأدوار، ولا استثناء', async () => {
    const bad = [];
    for (const role of [null, 'user', 'admin']) { const x = mk(role); adversarial(x); x.R(`go('showrooms')`); const l = x.E.screen(); if (BAD.test(l) || l.includes(ERR)) bad.push((role || 'guest') + ':list'); for (const id of PUB_IDS.concat(NASTY)) { x.R(`go('showroomDetails',${id})`); const d = x.E.screen(); if (BAD.test(d) || d.includes(ERR)) bad.push((role || 'guest') + ':' + id); } if (x.E.errors.length) bad.push('errors'); }
    return bad.length === 0 || bad.slice(0, 6); });

  /* ======================= E) التنقل وزر الرجوع ======================= */
  console.log('\n--- E) التنقل والرجوع ---');
  await tc('16) البطاقة تفتح مسار تفاصيل المعرض القائم: جذر البطاقة onclick=go(\'showroomDetails\',id) وزر «عرض المعرض» <button type="button"> أصلي داخلها باسم وصولي يحمل اسم المعرض (النقر ينتشر للبطاقة)، والتنفيذ ينقل لـshowroomDetails بالمعرّف', async () => {
    const x = mk(null); x.R(`go('showrooms')`); const h = x.E.screen(); const root = (h.match(/<div class="card showroom-card"[^>]*>/) || [''])[0]; const b = btn(h, 'btn-primary'); const id = cardIds(h)[0]; const nm = x.J(`getShowroomById(${id}).name`);
    click(x, root);
    return (new RegExp(`onclick="go\\('showroomDetails',${id}\\)"`).test(root) && /^<button type="button" class="btn-primary" aria-label="/.test(b) && b.includes(`aria-label="عرض المعرض: ${nm}"`) && x.R('currentRoute') === 'showroomDetails' && x.R('currentParam') === id && h.indexOf(root) < h.indexOf(b)) || { root, b }; });
  await tc('17) تفاصيل المعرض: زر رجوع واضح <button type="button" class="back-pill"> بـaria-label="رجوع" ونص «رجوع» وسهم aria-hidden، لا back-circle، وفي حالتي «غير موجود/غير متاح» أيضًا، وهدف اللمس 44×44 في CSS', async () => {
    const x = mk(null); x.R(`go('showroomDetails',${PUB_IDS[0]})`); const h = x.E.screen(); x.R(`go('showroomDetails',99999)`); const m = x.E.screen(); const css = read('theme/theme.css'); const blk = css.slice(css.indexOf('/* ---- (UX ج5)'));
    const b = btn(h, 'back-pill');
    return (/^<button type="button" class="back-pill" aria-label="رجوع"/.test(b) && /<span class="bp-arrow" aria-hidden="true">→<\/span><span>رجوع<\/span>/.test(b) && !h.includes('back-circle') && (m.match(/class="back-pill"/g) || []).length === 1 && !m.includes('back-circle') && /\.back-pill\{[^}]*min-height:\s*44px[^}]*|\.back-pill\{[^}]*min-width:\s*44px/.test(blk)) || { b }; });
  await tc('18) زر الرجوع يستعمل goBack(fallback) القائم: onclick=goBack(\'showrooms\') فقط (لا go(\'showrooms\') ثابت)، والمكوّن DetailBackButton المشترك نفسه (لا مكوّن جديد)، والراوتر بلا إشارة له ومنطقه القائم باقٍ', async () => {
    const x = mk(null); x.R(`go('showroomDetails',${PUB_IDS[0]})`); const b = btn(x.E.screen(), 'back-pill'); const src = strip(read('screens/showroomDetails.js')); const r = strip(read('navigation/router.js')); const cc = strip(read('components/carCard.js'));
    return (onclickOf(b) === "goBack('showrooms')" && (src.match(/DetailBackButton\('showrooms'/g) || []).length === 3 && !/BackBar|back-circle|go\('showrooms'\)(?!\s*\})/.test(src.replace(/actions:[^\n]*go\('showrooms'\)[^\n]*/g, '')) && (cc.match(/function DetailBackButton\(/g) || []).length === 1 && !/DetailBackButton|back-pill/.test(r) && /function goBack\(fallback\)/.test(r) && /_navStack\.pop\(\)/.test(r)) || { b, n: (src.match(/DetailBackButton\('showrooms'/g) || []).length }; });
  await tc('19) المعارض ← التفاصيل ← رجوع = المعارض بحالة البحث محفوظة (بنقر الزر الحقيقي): «الفرات» ثم فتح معرضه ثم الرجوع يعيد القائمة بنفس النص ونتيجتها، والرجوع بلا بحث يعيد القائمة الكاملة', async () => {
    const x = mk(null); x.R(`go('showrooms')`); x.R(`onShowroomsSearch('الفرات')`); const root = (x.E.els.showroomsList.innerHTML.match(/<div class="card showroom-card"[^>]*>/) || [''])[0]; click(x, root); const d1 = x.R('currentRoute'); click(x, btn(x.E.screen(), 'back-pill'));
    const r1 = x.R('currentRoute'), q = x.R('showroomsSearchQuery'), shown = cardIds(x.E.screen()); const y = mk(null); y.R(`go('showrooms')`); y.R(`go('showroomDetails',${PUB_IDS[0]})`); click(y, btn(y.E.screen(), 'back-pill'));
    return (d1 === 'showroomDetails' && r1 === 'showrooms' && q === 'الفرات' && same(shown, [firat.id]) && x.E.screen().includes('value="الفرات"') && y.R('currentRoute') === 'showrooms' && same(cardIds(y.E.screen()), PUB_IDS)) || { d1, r1, q, shown }; });
  await tc('20) البحث الموحّد ← معرض ← تفاصيل ← رجوع = البحث بنص «الفرات» نفسه (param)، والرئيسية ← تفاصيل معرض ← رجوع = الرئيسية، والرئيسية ← المعارض ← تفاصيل ← رجوع = المعارض', async () => {
    const x = mk(null); x.R(`go('search','الفرات')`); const h = x.E.screen(); const card = (h.match(/<div class="card showroom-card"[^>]*>/) || [''])[0]; click(x, card); const d = x.R('currentRoute'); click(x, btn(x.E.screen(), 'back-pill')); const r = x.R('currentRoute'), p = x.R('currentParam');
    const y = mk(null); y.R(`go('home')`); y.R(`go('showroomDetails',${PUB_IDS[0]})`); click(y, btn(y.E.screen(), 'back-pill')); const home = y.R('currentRoute');
    const z = mk(null); z.R(`go('home')`); z.R(`go('showrooms')`); z.R(`go('showroomDetails',${PUB_IDS[1]})`); click(z, btn(z.E.screen(), 'back-pill')); const r3 = z.R('currentRoute');
    return (d === 'showroomDetails' && r === 'search' && p === 'الفرات' && x.E.screen().includes('الفرات') && home === 'home' && r3 === 'showrooms') || { d, r, p, home, r3 }; });
  await tc('21) الدخول المباشر بلا سجل: الرجوع يستعمل البديل القائم (showrooms) بلا دفع الشاشة الحالية وبلا انهيار؛ وسجل قديم لمسار إداري عند ضيف لا يكشف شيئًا (الحارس القائم يحوّل للدخول)', async () => {
    const x = mk(null); x.R(`currentRoute = 'showroomDetails'; currentParam = ${PUB_IDS[0]}; _navStack = []; render();`); click(x, btn(x.E.screen(), 'back-pill')); const a = [x.R('currentRoute'), x.R('_navStack.length')];
    const z = mk(null); z.R(`currentRoute = 'showroomDetails'; currentParam = ${PUB_IDS[0]}; _navStack = [{ route: 'adminDashboard', param: undefined }]; render();`); click(z, btn(z.E.screen(), 'back-pill')); const c = z.R('currentRoute'), cs = z.E.screen();
    return (a[0] === 'showrooms' && a[1] === 0 && ['showrooms', 'login'].includes(c) && !/class="stat-card"/.test(cs) && x.E.errors.length === 0 && z.E.errors.length === 0) || { a, c }; });

  /* ======================= F) الوصول وعدم التراجع ======================= */
  console.log('\n--- F) الوصول وعدم التراجع ---');
  await tc('22) لا معرّف مكرر في شاشة المعارض ولا في تفاصيل المعرض (حتى مع 12 معرضًا مضافًا)، وحقل البحث باسم وصولي (aria-label)', async () => {
    const x = mk(null); adversarial(x); x.R(`go('showrooms')`); const a = idsIn(x.E.screen()); x.R(`go('showroomDetails',9206)`); const b = idsIn(x.E.screen());
    return (new Set(a).size === a.length && new Set(b).size === b.length && x.E.screen().includes('class="back-pill"') && !/<input(?![^>]*aria-label)[^>]*>/.test(x.E.screen()) && a.includes('showroomsList')) || { a, b }; });
  await tc('23) لا div قابل للنقر بلا بديل أصلي: كل <div onclick> (جذر بطاقة المعرض) يحوي <button type="button"> أصليًا يقوم بالإجراء نفسه، ولا role="button" على div، وروابط الاتصال <a> حقيقية، وزرا الرجوع والبحث الأصليان', async () => {
    const x = mk(null); adversarial(x); const bad = [];
    for (const [route, id] of [['showrooms'], ['showroomDetails', 9201], ['showroomDetails', PUB_IDS[0]]]) { x.R(id === undefined ? `go('${route}')` : `go('${route}',${id})`); const h = x.E.screen();
      for (const m of h.matchAll(/<div[^>]*onclick="([^"]*)"[^>]*>([\s\S]*?)(?=<div class="card showroom-card"|<\/div>\s*<\/div>\s*<\/div>\s*$|$)/g)) { if (!/<button type="button"/.test(m[2])) bad.push(route + ':' + m[1].slice(0, 40)); }
      if (/<div[^>]*role="button"/.test(h) || /<div[^>]*class="back-pill"/.test(h)) bad.push(route + ':role'); }
    return bad.length === 0 || bad; });
  await tc('25) لا reserved: لا ذكر لـreserved/محجوز في الشاشات والبطاقة ولا في HTML المعروض (بما فيه المعارض العدائية)', async () => {
    const x = mk(null); adversarial(x); x.R(`go('showrooms')`); const h = x.E.screen(); x.R(`go('showroomDetails',9201)`); const d = x.E.screen();
    return !/reserved|محجوز/i.test(strip(read('screens/showrooms.js')) + strip(read('screens/showroomDetails.js')) + strip(read('components/showroomCard.js')) + h + d) || 'reserved'; });
  await tc('26) شاشتا السيارات والأعضاء وتفاصيل السيارة لم تتراجع: السيارات (بحث «ابحث عن سيارة» + لوحة مطويّة + زر تصفية + بطاقاتها الظاهرة)، والأعضاء (لوحة مطويّة + زر تصفية)، وتفاصيل السيارة (رجوع + مفضلة مدمجة)، والرئيسية بقسم معارضها بنفس البطاقة', async () => {
    const x = mk(null); x.R(`go('cars')`); const c = x.E.screen(); x.R(`go('memberCars')`); const m = x.E.screen(); const first = x.J('getVisibleCars()[0].id'); x.R(`go('carDetails',${first})`); const d = x.E.screen(); x.R(`go('home')`); const hm = x.E.screen();
    return (c.includes('placeholder="ابحث عن سيارة"') && /id="carsRefinePanel"[^>]*hidden/.test(c) && c.includes('id="carsRefineToggle"') && (c.match(/class="card car-card"/g) || []).length === x.J('getVisibleCars().length') && /id="memberRefinePanel"[^>]*hidden/.test(m) && m.includes('id="memberRefineToggle"') && d.includes('class="back-pill"') && d.includes('class="fav-inline"') && hm.includes('class="card showroom-card"') && !c.includes(ERR) && !m.includes(ERR) && !d.includes(ERR)) || 'regression'; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

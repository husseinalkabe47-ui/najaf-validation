/* اختبارات «إزالة حالة محجوز / reserved» من نظام السيارات.
   القاعدة: السيارة المحجوزة لدى شخص لم تُشترَ بعد، فلا تُعامل «محجوز» كحالة. حالتا السيارة للمستخدم: «متاحة للبيع» و«مباعة».
   سيارة معرض reserved ← available، وسيارة عضو reserved ← active (المقابل الفعلي لـ«متاحة» في مفردات حالات الأعضاء)،
   دون حذف أي سيارة ودون تغيير أي حقل غير الحالة (المعرّفات، المالك، الصور، السعر، المسافة، الوصف، الطوابع الزمنية).
   كُتبت قبل التنفيذ لإثبات النواقص ثم مرّت. «إعادة تحميل» = بيئة جديدة بنفس التخزين. */
const { makeEnv } = require('./harness');
const fs = require('fs'), path = require('path');
let pass = 0, fail = 0;
const t = (name, cond, extra) => { if (cond) { pass++; console.log('✅', name); } else { fail++; console.log('❌', name, extra !== undefined ? extra : ''); } };
/** يمرّ فقط إن أعادت الدالة true حرفيًا (أي كائن/مصفوفة = فشل مع عرض تفاصيله) */
const tc = async (name, fn) => { try { const r = await fn(); t(name, r === true, r === true ? '' : (typeof r === 'object' ? JSON.stringify(r) : String(r))); } catch (e) { t(name, false, 'EXC: ' + String(e && e.message).slice(0, 200)); } };

const ROOT = path.resolve(__dirname, '..');
const CRED = { user: ['07700000001', 'user123'], dealer1: ['07701234567', 'dealer123'], dealer5: ['07715558899', 'dealer123'], admin: ['07700000000', 'admin123'] };
function mk(role, store) {
  const E = makeEnv(store), R = c => E.run(c);
  const setF = o => Object.entries(o).forEach(([k, v]) => E.els[k] = Object.assign(E.els[k] || { style: {} }, { value: v, style: E.els[k]?.style || {}, textContent: '' }));
  const login = r => { const c = CRED[r]; R(`go('login')`); setF({ loginIdentifier: c[0], loginPassword: c[1] }); R('handleLoginSubmit()'); };
  if (role) login(role);
  return { E, R, setF, login };
}
const J = (x, code) => JSON.parse(x.R(`JSON.stringify(${code})`));
const clone = o => JSON.parse(JSON.stringify(o));
const asGuest = x => { const g = mk(null, x.E.store); g.R('AuthService.logout()'); return g; };
const BAD = /undefined|\bnull\b|NaN|\[object|TypeError|ReferenceError/;
const ERR = 'حدث خطأ، حاول مرة أخرى';
const RES = /محجوز|محجوزة|reserved|Reserved|RESERVED|حجز/;   // أي أثر لحالة الحجز أمام المستخدم
const strip = src => src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');

/** تخزين «مستخدم حالي» (بنسخة المخطط 2، كما في التسليم السابق) يحوي سيارات reserved بأشكال مختلفة، بالإضافة إلى صور ومفضلة */
function reservedStore({ version = '2' } = {}) {
  const E0 = makeEnv(), G = c => JSON.parse(E0.run(`JSON.stringify(${c})`));
  const cars = G('CARS'), members = G('MEMBER_CARS'), images = G('CAR_IMAGES');
  cars.forEach(c => { if (c.status === 'reserved') c.status = 'available'; }); members.forEach(c => { if (c.status === 'reserved') c.status = 'active'; });   // نبدأ نظيفين ثم نُدخل الحالات بأنفسنا
  const tpl = { sourceType: 'showroom', showroomId: 1, brand: 'Kia', model: 'Legacy', year: 2020, price: 12345678, mileage: 4321, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض',
    description: 'وصف كامل لا يتغيّر', mainImage: 'idb:777', createdAt: '2026-08-01T10:00:00.000Z', updatedAt: '2026-08-02T10:00:00.000Z' };
  cars.find(c => c.id === 3).status = 'reserved'; cars.find(c => c.id === 4).status = 'reserved';
  cars.push(Object.assign({}, tpl, { id: 16, model: 'ResA', status: 'reserved' }), Object.assign({}, tpl, { id: 17, model: 'ResB', status: ' Reserved ' }), Object.assign({}, tpl, { id: 18, model: 'ResC', status: 'RESERVED' }), Object.assign({}, tpl, { id: 19, model: 'Plain', status: 'available' }), Object.assign({}, tpl, { id: 20, model: 'Gone', status: 'sold' }));
  const mtpl = { sourceType: 'member', ownerId: 7, brand: 'Hyundai', model: 'MLegacy', year: 2019, price: 9876543, mileage: 8765, transmission: 'يدوي', fuelType: 'ديزل', color: 'فضي', description: 'إعلان عضو', phone: '07700000001', location: 'حي السلام', createdAt: '2026-07-01T09:00:00', updatedAt: '2026-07-02T09:00:00' };
  members.find(c => c.id === 101).status = 'reserved';
  members.push(Object.assign({}, mtpl, { id: 111, model: 'MRes', status: 'reserved' }), Object.assign({}, mtpl, { id: 112, model: 'MResUp', status: 'RESERVED', ownerId: 1 }));
  images.push({ id: 900, carId: 16, imageUrl: 'idb:900', sortOrder: 0, isMain: true }, { id: 901, carId: 111, imageUrl: 'idb:901', sortOrder: 0, isMain: true });
  const favs = [{ id: 1, userId: 7, carId: 3, createdAt: '2026-09-01T10:00:00.000Z' }, { id: 2, userId: 7, carId: 16, createdAt: '2026-09-02T10:00:00.000Z' }, { id: 3, userId: 1, carId: 111, createdAt: '2026-09-03T10:00:00.000Z' }];
  // najaf.seedIds: لقطة البذور التي يكتبها المستودع مع أول حفظ للسيارات (موجودة عند أي مستخدم حفظ سيارات سابقًا)
  const store = { 'najaf.showroomCars': JSON.stringify(cars), 'najaf.memberCars': JSON.stringify(members), 'najaf.memberCarsDeleted': '[]', 'najaf.carImages': JSON.stringify(images), 'najaf.favorites': JSON.stringify(favs), 'najaf.seedIds': JSON.stringify({ cars: G('CARS').map(c => c.id) }) };
  if (version) store['najaf.schemaVersion'] = version;
  return { store, cars, members, images, favs };
}
/** مخزن يسجّل كل كتابة (المفتاح) — لإثبات عدم إعادة الكتابة بلا داعٍ */
function spyStore(initial) { const writes = []; const p = new Proxy(initial, { set(tg, k, v) { writes.push(k); tg[k] = v; return true; } }); return { store: p, writes }; }
const sans = o => { const c = clone(o); delete c.status; return c; };

(async () => {
  { const { E } = mk(null); t('0) تحميل كل الملفات بلا أخطاء JS', E.errors.length === 0, E.errors.join(' | ')); }

  /* ======================= A) الترحيل ======================= */
  console.log('\n--- A) ترحيل السيارات المحجوزة ---');
  await tc('A1) سيارة معرض reserved تصبح available (بكل أشكال الكتابة: reserved / " Reserved " / RESERVED)، وغيرها لا تتغيّر', async () => {
    const S = reservedStore(); const x = mk(null, S.store); const st = id => x.R(`getCarById(${id}).status`);
    return (['3', '4', '16', '17', '18'].every(id => st(id) === 'available') && st(19) === 'available' && st(20) === 'sold' && x.R(`getCars().every(c => c.status === 'available' || c.status === 'sold')`)) || { s: [3, 4, 16, 17, 18, 19, 20].map(st) }; });
  await tc('A2) سيارة عضو reserved تصبح active (المقابل الفعلي لـ«متاحة» في حالات الأعضاء)، وليست قيمة خارج مفرداتها', async () => {
    const S = reservedStore(); const x = mk(null, S.store); const st = id => x.R(`getMemberCarById(${id}).status`);
    return (['101', '111', '112'].every(id => st(id) === 'active') && x.R(`MemberCarsRepository.getAll().every(c => ['pending','active','sold','rejected','suspended'].includes(c.status))`)) || [101, 111, 112].map(st); });
  await tc('A3) الترحيل يُحفظ: التخزين نفسه لا يحوي reserved بعد التحميل (سيارات المعارض والأعضاء)، ولا قيمة محفوظة غير مفرداتها', async () => {
    const S = reservedStore(); const x = mk(null, S.store); const sc = JSON.parse(x.E.store['najaf.showroomCars']), mc = JSON.parse(x.E.store['najaf.memberCars']);
    return (!/reserved/i.test(x.E.store['najaf.showroomCars']) && !/reserved/i.test(x.E.store['najaf.memberCars']) && sc.find(c => c.id === 16).status === 'available' && mc.find(c => c.id === 111).status === 'active') || 'still reserved in storage'; });
  await tc('A4) لا حذف: المعرّفات والأعداد كما هي بالضبط (معارض وأعضاء)، بما فيها السيارات المحجوزة سابقًا', async () => {
    const S = reservedStore(); const x = mk(null, S.store);
    const ids = J(x, 'getCars().map(c=>c.id)'), mids = J(x, 'MemberCarsRepository.getAll().map(c=>c.id)');
    return (JSON.stringify(ids.slice().sort((a, b) => a - b)) === JSON.stringify(S.cars.map(c => c.id).sort((a, b) => a - b)) && JSON.stringify(mids.slice().sort((a, b) => a - b)) === JSON.stringify(S.members.map(c => c.id).sort((a, b) => a - b)) && ids.length === 20 && mids.length === 12) || { ids: ids.length, mids: mids.length }; });
  await tc('A5) الحالة وحدها تتغيّر: كل حقل آخر (المالك، المعرض، الصور، السعر، المسافة، الوصف، المواصفات، updatedAt) متطابق حرفيًا، وcreatedAt القديم بلا منطقة يُطبَّع إلى UTC (+03:00) عمدًا (الهجرة 3)', async () => {
    const S = reservedStore(); const x = mk(null, S.store); const bad = [];
    // (ج7) الهجرة 3 تطبّع createdAt القديم (بلا منطقة = توقيت العراق +03:00) إلى UTC عمدًا؛ بقية الحقول (والطابع updatedAt) حرفية. الحساب هنا مستقل عن الكود المختبَر.
    const utc = s => (/(Z|[+-]\d{2}:?\d{2})$/.test(s) ? new Date(s).toISOString() : new Date(Date.parse(s + 'Z') - 3 * 3600 * 1000).toISOString());
    const exp = c => Object.assign({}, c, { createdAt: utc(c.createdAt) });
    S.cars.forEach(c => { if (JSON.stringify(sans(J(x, `getCarById(${c.id})`))) !== JSON.stringify(sans(exp(c)))) bad.push('car:' + c.id); });
    S.members.forEach(c => { if (JSON.stringify(sans(J(x, `getMemberCarById(${c.id})`))) !== JSON.stringify(sans(exp(c)))) bad.push('member:' + c.id); });
    return bad.length === 0 || bad; });
  await tc('A6) الصور والمفضلة والمالكون لا تتأثر: سجلات الصور كما هي، ومفضلة السيارات المحجوزة سابقًا باقية', async () => {
    const S = reservedStore(); const x = mk(null, S.store);
    return (JSON.stringify(J(x, 'CAR_IMAGES')) === JSON.stringify(S.images) && JSON.stringify(J(x, 'FavoritesRepository.getAll()')) === JSON.stringify(S.favs) && x.R('getCarImages(16).length') === 1 && x.R('getCarImages(111).length') === 1) || 'images/favorites changed'; });
  await tc('A7) تخزين بلا schemaVersion (قديم جدًا) يُرحَّل أيضًا دون فقد شيء', async () => {
    const S = reservedStore({ version: null }); const x = mk(null, S.store);
    return !/reserved/i.test(x.E.store['najaf.showroomCars']) && x.R('getCars().length') === 20 && x.R('getCarById(16).status') === 'available' && x.R('getMemberCarById(111).status') === 'active'; });
  await tc('A8) إعادة التحميل المتكررة لا تعيد كتابة السجلات: بعد الترحيل الأول لا كتابة أبدًا في التحميلات التالية (التخزين بايت-ببايت كما هو)', async () => {
    const S = reservedStore(); const a = mk(null, S.store); const snap = JSON.stringify(a.E.store); const { store, writes } = spyStore(a.E.store);
    for (let i = 0; i < 3; i++) { const y = mk(null, store); y.R('hydrateRepositories()'); y.R('hydrateRepositories()'); y.R('runStorageMigrations({failed:[]})'); }
    return (writes.length === 0 && JSON.stringify(Object.assign({}, store)) === snap) || { writes: writes.slice(0, 8) }; });
  await tc('A9) الترحيل الأول يكتب فقط ما تغيّر: مفتاحا سيارات المعارض والأعضاء وعلامة الإصدار (2 ← 3)، ولا شيء آخر', async () => {
    const S = reservedStore(); const { store, writes } = spyStore(S.store); mk(null, store); const keys = [...new Set(writes)].sort();
    return (JSON.stringify(keys) === JSON.stringify(['najaf.memberCars', 'najaf.schemaVersion', 'najaf.showroomCars'])) || keys; });   // (ج7) + علامة الإصدار 2 ← 3
  await tc('A10) لا إعادة كتابة بلا داعٍ في التثبيت النظيف ولا في بيانات لا تحوي reserved (أي تخزين نظيف لا يُكتب فيه شيء)', async () => {
    const clean = reservedStore(); clean.cars.forEach(c => { if (/reserved/i.test(c.status)) c.status = 'available'; }); clean.members.forEach(c => { if (/reserved/i.test(c.status)) c.status = 'active'; });
    const st = { 'najaf.showroomCars': JSON.stringify(clean.cars), 'najaf.memberCars': JSON.stringify(clean.members), 'najaf.memberCarsDeleted': '[]', 'najaf.schemaVersion': '3' };   // (ج7) تخزين بإصدار الهجرة الحالي (3) ← لا كتابة
    const { store, writes } = spyStore(st); mk(null, store); const fresh = spyStore({}); mk(null, fresh.store);
    return (writes.length === 0 && [...new Set(fresh.writes)].sort().join() === 'najaf.memberCarsDeleted,najaf.schemaVersion') || { w: writes.slice(0, 5), f: fresh.writes }; });
  await tc('A11) تخزين بإصدار أحدث من التطبيق لا يُمَسّ (قاعدة قائمة): reserved تبقى كما هي دون كتابة، ولا استثناء', async () => {
    const S = reservedStore({ version: '99' }); const { store, writes } = spyStore(S.store); const x = mk(null, store); x.R(`go('cars')`);
    return (x.E.errors.length === 0 && writes.length === 0 && /reserved/.test(store['najaf.showroomCars']) && !x.E.screen().includes(ERR) && !RES.test(x.E.screen())) || { w: writes.length, errs: x.E.errors }; });
  await tc('A12) البيانات التجريبية نفسها نظيفة: لا سيارة بحالة reserved في البذور (تثبيت جديد لا يحتاج ترحيلًا ولا كتابة)', async () => {
    const x = mk(null); return x.R(`CARS.every(c => c.status === 'available' || c.status === 'sold')`) && x.R(`MEMBER_CARS.every(c => c.status !== 'reserved')`) && x.R('getCarById(3).status') === 'available' && x.R('getCarById(4).status') === 'available' && x.R('getCars().length') === 15; });
  await tc('A13) سيارتا البذور 3 و4 (كانتا reserved) محفوظتان بكل بياناتهما (الماركة والسعر والصور) دون تغيير غير الحالة', async () => {
    const x = mk(null); return x.R('getCarById(3).brand') === 'Kia' && x.R('getCarById(3).model') === 'Cerato' && x.R('getCarById(3).price') === 14700000 && x.R('getCarById(4).model') === 'Sportage' && x.R('getCarById(4).price') === 32000000 && x.R('getCarImages(3).length') > 0; });
  await tc('A14) ملاحظة الإدارة: سيارة معرض مُرحَّلة تظهر للعامة كأي سيارة متاحة (تبقى ظاهرة بقواعد الظهور القائمة، لا تُخفى ولا تُعلَّم)', async () => {
    const S = reservedStore(); const g = asGuest(mk(null, S.store)); const ids = J(g, 'getVisibleCars().map(c=>c.id)');
    return [3, 4, 16, 17, 18].every(id => ids.includes(id)) && g.R('getCarAccess(16).status') === 'ok'; });

  /* ======================= B) واجهة المستخدم ======================= */
  console.log('\n--- B) واجهة المستخدم ---');
  await tc('B1) تسميتا الحالة: available = «متاحة للبيع»، sold = «مباعة»، والتسميات هي هاتان فقط (لا مفتاح reserved)', async () => {
    const x = mk(null); return (x.R('CAR_STATUS_LABEL.available') === 'متاحة للبيع' && x.R('CAR_STATUS_LABEL.sold') === 'مباعة' && JSON.stringify(Object.keys(J(x, 'CAR_STATUS_LABEL'))) === JSON.stringify(['available', 'sold'])) || J(x, 'CAR_STATUS_LABEL'); });
  await tc('B2) شارات الحالة: متاحة للبيع (أخضر) ومباعة (أحمر)، وreserved أو أي غير معرَّفة ← فارغة (لا يراها المستخدم)', async () => {
    const x = mk(null); const b = s => x.R(`carStatusBadge(${JSON.stringify(s)})`);
    return b('available').includes('متاحة للبيع') && b('available').includes('open') && b('sold').includes('مباعة') && b('sold').includes('sold') && ['reserved', 'Reserved', 'zzz', undefined, null, ''].every(s => b(s) === ''); });
  await tc('B3) لا فئة CSS باسم reserved: الشارات الصفراء (قيد المراجعة) تستخدم فئة محايدة، ولا .badge.reserved في التصميم', async () => {
    const x = mk(null); const css = read('theme/theme.css'); const w = x.R(`showroomStatusBadge('pending')`), m = x.R(`memberCarStatusBadge('pending')`);
    return (!/\.badge\.reserved/.test(css) && w.includes('warn') && m.includes('warn') && !/reserved/.test(w + m)) || { w, m }; });
  await tc('B4) بطاقة السيارة وتفاصيلها: «متاحة للبيع» للمتاحة و«مباعة» للمباعة، ولا أثر لـ«متوفرة/محجوز»', async () => {
    const a = mk('admin'); a.R(`AdminService.setShowroomCarStatus(3,'sold')`); const c1 = a.R('CarCard(getCarById(1))'), c3 = a.R('CarCard(getCarById(3))');
    a.R(`go('carDetails',1)`); const d1 = a.E.screen(); a.R(`go('carDetails',3)`); const d3 = a.E.screen();
    return (c1.includes('متاحة للبيع') && c3.includes('مباعة') && d1.includes('متاحة للبيع') && d3.includes('مباعة') && !/متوفرة/.test(c1 + c3 + d1 + d3) && !RES.test(c1 + c3 + d1 + d3) && c3.includes('data-status="sold"')) || { c1: c1.slice(0, 80) }; });
  await tc('B5) كل شاشات العرض لكل الأدوار (زائر/مستخدم/تاجر/مدير) على بيانات مُرحَّلة: لا «محجوز» ولا «reserved» ولا «حجز» في أي HTML', async () => {
    const S = reservedStore(); const bad = [];
    for (const role of [null, 'user', 'dealer1', 'dealer5', 'admin']) {
      const x = mk(role, clone(S.store)); x.R('hydrateRepositories()');
      const visit = (r, p) => { x.R(`go('${r}'${p !== undefined ? ',' + JSON.stringify(p) : ''})`); const h = x.E.screen(); if (RES.test(h) || h.includes(ERR) || BAD.test(h)) bad.push(`${role}:${r}(${p})`); };
      ['home', 'showrooms', 'cars', 'map', 'favorites', 'memberCars', 'account', 'myMemberCars', 'dealerHome', 'myShowroomCars', 'addShowroomCar', 'adminHome', 'adminDashboard', 'adminMemberCars', 'adminShowrooms', 'adminShowroomCars', 'adminUsers', 'adminDealerRequests'].forEach(r => visit(r));
      for (const id of [1, 2, 3, 4, 5, 9, 16, 17, 18, 19, 20]) { visit('carDetails', id); visit('editShowroomCar', id); }
      for (const id of [101, 102, 111, 112]) { visit('memberCarDetails', id); visit('adminMemberCarDetails', id); visit('editMemberCar', id); }
      for (const id of [1, 2, 3, 4, 5]) visit('showroomDetails', id);
      ['toyota', 'kia', 'corolla', 'resa'].forEach(q => visit('search', q));   // (استعلام «محجوز» يُعرض نصّه في مربع البحث نفسه فيُفحص في C4 لا هنا)
    }
    return bad.length === 0 || bad.slice(0, 8); });
  await tc('B6) أسوأ حالة: سيارة بحالة reserved ما زالت في الذاكرة (لم تُرحَّل بعد): لا شارة ولا data-status ولا نص «محجوز» في أي شاشة', async () => {
    const x = mk('admin'); x.R(`CARS.push(CarModel({ id: 9001, sourceType:'showroom', showroomId: 1, brand:'Leak', model:'Probe', year: 2020, price: 1000, status:'available' }))`); x.R(`getCarById(9001).status = 'reserved'`);
    const out = [x.R('CarCard(getCarById(9001))'), x.R('carStatusBadge("reserved")')]; for (const r of ['cars', 'home', 'adminShowroomCars', 'myShowroomCars']) { x.R(`go('${r}')`); out.push(x.E.screen()); } x.R(`go('carDetails',9001)`); out.push(x.E.screen()); x.R(`go('search','leak')`); out.push(x.E.screen());
    return out.every(h => !RES.test(h) && !h.includes(ERR)) || out.map(h => RES.test(h)); });
  await tc('B7) الرسائل والنوافذ: نافذة تغيير الحالة للمدير تعرض «متاحة للبيع» و«مباعة» فقط (لا reserved ولا محجوزة)، ورفض reserved برسالة عربية واضحة', async () => {
    const a = mk('admin'); const prompts = []; a.E.ctx.prompt = m => { prompts.push(m); return null; }; a.R('handleAdminShowroomCarStatusChange(1)');
    const toasts = []; a.E.ctx.prompt = () => 'reserved'; a.R('handleAdminShowroomCarStatusChange(1)'); const t1 = a.E.els.toast ? a.E.els.toast.textContent : '';
    return (prompts.length === 1 && prompts[0].includes('متاحة للبيع') && prompts[0].includes('مباعة') && !RES.test(prompts[0]) && t1 === 'حالة غير صحيحة.' && a.R('getCarById(1).status') === 'available') || { prompts, t1 }; });

  /* ======================= C) الفلاتر والبحث ======================= */
  console.log('\n--- C) الفلاتر والبحث ---');
  await tc('C1) أشرطة الفلاتر (السيارات، الأعضاء، البحث) بلا حالة «محجوز» ولا خيار حالة أصلًا (ماركة/موديل/سنة/سعر/مسافة فقط)', async () => {
    const x = mk(null); const bars = [];
    x.R(`go('cars')`); bars.push(x.E.screen()); x.R(`go('memberCars')`); bars.push(x.E.screen()); x.R(`go('search','kia')`); bars.push(x.E.screen());
    const ids = bars.flatMap(h => [...h.matchAll(/id="(\w*Filter\w+)"/g)].map(m => m[1].replace(/^(cars|member|search)/, ''))).filter(i => i !== 'FilterBar' && i !== 'FilterChips');   // حاويتا الشريط والشارات لا حقلا فلتر
    const want = ['FilterBrand', 'FilterModel', 'FilterYear', 'FilterMinPrice', 'FilterMaxPrice', 'FilterMinMileage', 'FilterMaxMileage'];
    return (bars.every(h => !RES.test(h)) && [...new Set(ids)].sort().join() === want.slice().sort().join()) || { ids: [...new Set(ids)] }; });
  await tc('C2) محرك الفلاتر لا يقدّم خيارات حالة، ولا قيمة reserved في options()', async () => {
    const x = mk(null); const o = J(x, `CarFilters.options(getPublicCars('all'), {})`); return !('statuses' in o) && !('status' in o) && !/reserved|محجوز/i.test(JSON.stringify(o)); });
  await tc('C3) الفلاتر المتبقية تعمل كما كانت على بيانات مُرحَّلة: ماركة/موديل/سنة/سعر/مسافة والتصفية بـ available/sold', async () => {
    const S = reservedStore(); const x = mk(null, S.store); const F = c => J(x, `CarFilters.apply(getCars(), ${JSON.stringify(c)}).map(k=>k.id)`);
    const av = F({ status: 'available' }), so = F({ status: 'sold' }), all = J(x, 'getCars().map(c=>c.id)');
    return (F({ brand: 'kia', model: 'resa' }).join() === '16' && F({ minPrice: 12345678, maxPrice: 12345678 }).length >= 5 && F({ year: 2020 }).includes(16) && F({ maxMileage: 4321, minMileage: 4321 }).includes(16) &&
      av.includes(3) && av.includes(16) && av.includes(18) && so.join() === '8,10,20' && av.length + so.length === all.length && F({ status: 'reserved' }).length === 0) || { av: av.length, so, all: all.length }; });
  await tc('C4) البحث النصي يجد السيارات المُرحَّلة كباقي المتاحة، والبحث عن «محجوز» لا يعيد شيئًا خاصًا', async () => {
    const S = reservedStore(); const x = mk(null, S.store);
    return x.R(`searchCars('resa','showroom').map(c=>c.id).join()`) === '16' && x.R(`searchCars('mres','member').map(c=>c.id).join()`) === '111,112' && x.R(`searchCars('reserved','all').length`) === 0 && x.R(`searchCars('محجوز','all').length`) === 0; });
  await tc('C5) الرئيسية والمفضلة: السيارات المُرحَّلة تظهر كمتاحة (بطاقة «متاحة للبيع»)، والمفضلة السابقة لها تعمل', async () => {
    const S = reservedStore(); const u = mk('user', S.store); u.R(`go('favorites')`); const fav = u.E.screen(); u.R(`go('home')`); const home = u.E.screen();
    return (fav.includes("go('carDetails',3)") && fav.includes("go('carDetails',16)") && fav.includes('متاحة للبيع') && !RES.test(fav) && !RES.test(home) && home.includes('متاحة للبيع')) || { f: fav.includes("carDetails',16") }; });

  /* ======================= D) الإدارة والتاجر ======================= */
  console.log('\n--- D) الإدارة والتاجر ---');
  await tc('D1) التاجر: قائمة تغيير الحالة تحوي «متاحة للبيع» و«مباعة» فقط، وDEALER_STATUSES = [available, sold]', async () => {
    const d = mk('dealer1'); d.R(`go('myShowroomCars')`); const h = d.E.screen(); const sel = (h.match(/<select[\s\S]*?<\/select>/) || [''])[0]; const opts = [...sel.matchAll(/<option value="([^"]*)">([^<]*)<\/option>/g)].map(m => [m[1], m[2]]);
    return (JSON.stringify(J(d, 'ShowroomCarsService.DEALER_STATUSES')) === JSON.stringify(['available', 'sold']) && JSON.stringify(opts.slice(0, 3)) === JSON.stringify([['', 'تغيير الحالة'], ['available', 'متاحة للبيع'], ['sold', 'مباعة']]) && opts.length === 3 && !RES.test(h)) || { opts }; });
  await tc('D2) التاجر: تغيير الحالة إلى available/sold يعمل ويُحفظ، وإلى reserved مرفوض بلا تغيير في الحالة', async () => {
    const d = mk('dealer1'); const ok1 = d.R(`changeShowroomCarStatus(1,'sold').ok`), s1 = d.R('getCarById(1).status'), ok2 = d.R(`changeShowroomCarStatus(1,'available').ok`), bad = d.R(`changeShowroomCarStatus(1,'reserved')`), s2 = d.R('getCarById(1).status');
    const r = mk('dealer1', d.E.store); return ok1 === true && s1 === 'sold' && ok2 === true && bad.ok === false && /[\u0600-\u06FF]/.test(bad.error) && s2 === 'available' && r.R('getCarById(1).status') === 'available'; });
  await tc('D3) المدير: setShowroomCarStatus يقبل available/sold فقط، ويرفض reserved وأي قيمة أخرى (حتى بأحرف مختلفة) بلا تعديل', async () => {
    const a = mk('admin'); const ok = ['available', 'sold'].map(s => a.R(`setShowroomCarStatus(2,'${s}').ok`)); const bad = ['reserved', 'Reserved', 'RESERVED', 'zzz', '', 'null'].map(s => a.R(`setShowroomCarStatus(2,'${s}').ok`));
    return ok.every(v => v === true) && bad.every(v => v === false) && a.R('getCarById(2).status') === 'sold'; });
  await tc('D4) المدير: شاشة سيارات المعارض تعرض الحالة الجديدة وزر تغيير الحالة، بلا reserved في أي مكان', async () => {
    const a = mk('admin'); a.R(`go('adminShowroomCars')`); const h = a.E.screen(); return h.includes('handleAdminShowroomCarStatusChange(') && h.includes('متاحة للبيع') && !RES.test(h); });
  await tc('D5) سيارات الأعضاء: لا reserved في مفردات الحالة ولا في تبويبات الإدارة ولا في نافذة المالك، وتغييرها إلى reserved مرفوض', async () => {
    const o = mk('user'); const prompts = []; o.E.ctx.prompt = m => { prompts.push(m); return null; }; o.R('handleMemberCarStatusChange(101)'); const r = o.R(`changeMemberCarStatus(101,'reserved')`);
    const a = mk('admin'); a.R(`go('adminMemberCars')`); const rr = a.R(`changeMemberCarStatus(101,'reserved')`);
    return (JSON.stringify(Object.keys(J(o, 'MEMBER_CAR_STATUS_LABEL'))) === JSON.stringify(['pending', 'active', 'sold', 'rejected', 'suspended']) && prompts.length === 1 && !RES.test(prompts[0]) && r.ok === false && rr.ok === false && !RES.test(a.E.screen()) && o.R('getMemberCarById(101).status') === 'active') || { prompts }; });
  await tc('D6) تاجر جديد يضيف سيارة: حالتها available تلقائيًا، وعدّاد/عرض المعرض لا يفصل «محجوزة»', async () => {
    const d = mk('dealer1'); const c = await d.R(`createShowroomCar({brand:'Kia',model:'Fresh',year:2020,price:1000})`); const id = c.car.id;
    d.R(`go('showroomDetails',1)`); const h = d.E.screen(); return c.car.status === 'available' && !RES.test(h) && d.R(`getCarById(${id}).status`) === 'available'; });

  /* ======================= E) الإحصاءات والعدّادات ======================= */
  console.log('\n--- E) الإحصاءات والعدّادات ---');
  await tc('E1) إحصاءات الإدارة: لا فئة محجوز، وكل العدّادات من حالات معرَّفة فقط، ومجموعها يطابق إجمالي الأعضاء', async () => {
    const S = reservedStore(); const a = mk('admin', S.store); const st = J(a, 'getDashboardStats()'); const sum = st.pendingMemberCars + st.activeMemberCars + st.soldMemberCars + st.rejectedMemberCars + st.suspendedMemberCars;
    return (!/reserved|محجوز/i.test(JSON.stringify(st)) && sum === st.totalMemberCars && st.activeMemberCars >= 3) || st; });
  await tc('E2) عدّاد «متاحة» يشمل المُرحَّلة: متاحة + مباعة = إجمالي سيارات المعارض (لا فئة ثالثة)، والمُرحَّلة ضمن المتاحة', async () => {
    const S = reservedStore(); const x = mk(null, S.store); const n = s => x.R(`getCars().filter(c=>c.status==='${s}').length`);
    const wantSold = S.cars.filter(c => c.status === 'sold').length, wantAvail = S.cars.length - wantSold;   // كل ما ليس مباعًا (بما فيه المحجوز سابقًا) متاح
    return (n('available') + n('sold') === x.R('getCars().length') && n('available') === wantAvail && n('sold') === wantSold && wantAvail >= 17) || { a: n('available'), s: n('sold'), wantAvail, wantSold }; });
  await tc('E3) عدّاد سيارات المعرض في بطاقته يشمل المُرحَّلة كأي سيارة (معرض 1: 3 أصلية + 5 مضافة = 8)', async () => {
    const S = reservedStore(); const g = asGuest(mk(null, S.store)); const sh = id => g.R(`getVisibleCarsByShowroom(${id}).length`);
    g.R(`go('showrooms')`); const h = g.E.screen(); return sh(1) === 3 + 5 && h.includes(`${sh(1)} سيارة`) && !RES.test(h); });

  /* ======================= F) فحوص ثابتة ======================= */
  console.log('\n--- F) فحوص ثابتة ---');
  const files = dir => fs.readdirSync(path.join(ROOT, dir)).filter(f => /\.(js|css|html)$/.test(f)).map(f => dir + '/' + f);
  const ALL = ['index.html', 'app.js'].concat(...['components', 'data', 'models', 'navigation', 'repositories', 'screens', 'services', 'storage', 'theme'].map(files));
  await tc('F1) لا «reserved» ولا «محجوز» ولا «حجز» في أي نص برمجي فعّال (بعد حذف التعليقات) في كل الكود والبيانات والتصميم — باستثناء ملف الترحيل الذي يسمّي القيمة القديمة لتحويلها', async () => {
    const hits = ALL.filter(f => !/services\/migrationService\.js$/.test(f) && RES.test(strip(read(f)))); return hits.length === 0 || hits; });
  await tc('F2) القيمة القديمة مذكورة في مكان واحد فقط (migrationService.js) لتحويلها، وليست في أي مصفوفة حالات مسموحة', async () => {
    const holders = ALL.filter(f => /reserved/i.test(strip(read(f)))); return (JSON.stringify(holders) === JSON.stringify(['services/migrationService.js'])) || holders; });
  await tc('F3) مفردات حالات سيارة المعرض مصدرها واحد (SHOWROOM_CAR_STATUSES) تستخدمه خدمتا المدير والتاجر والتسميات، ولا مصفوفة حالات مكرّرة', async () => {
    const x = mk(null); const dup = ['services/adminService.js', 'services/showroomCarsService.js'].filter(f => /\[\s*'available'\s*,\s*'sold'\s*\]/.test(strip(read(f)))); 
    return (JSON.stringify(J(x, 'SHOWROOM_CAR_STATUSES')) === JSON.stringify(['available', 'sold']) && dup.length === 0 && JSON.stringify(Object.keys(J(x, 'CAR_STATUS_LABEL'))) === JSON.stringify(J(x, 'SHOWROOM_CAR_STATUSES'))) || { dup }; });
  await tc('F4) لا مساس بما هو خارج النطاق: نسخة المخطط 3 (الهجرة 3 الجديدة فقط) ولا في المُصدِر ولا في الظهور (القيم الحرفية سليمة)', async () => {
    const x = mk(null); return x.R('StorageSchema.CURRENT_VERSION') === 3 && x.R(`typeof IdAllocator.next`) === 'function' && x.R(`typeof VisibilityService.canViewCar`) === 'function' && x.E.store['najaf.schemaVersion'] === '3'; });
  await tc('F5) ملاحظة «متوفر» الأخرى (الموقع غير متوفر) لا علاقة لها بالحالة وبقيت، وتسمية «متوفرة» للحالة اختفت من كل الشاشات', async () => {
    const x = mk(null); const mapSrc = read('screens/map.js'); const bad = []; for (const r of ['home', 'cars', 'showrooms', 'favorites', 'memberCars']) { x.R(`go('${r}')`); if (/متوفرة/.test(x.E.screen())) bad.push(r); }
    x.R(`go('carDetails',1)`); if (/متوفرة/.test(x.E.screen())) bad.push('carDetails'); return mapSrc.includes('الموقع غير متوفر لهذا المعرض') && bad.length === 0 || bad; });

  console.log(`\nالنتيجة: ${pass} نجح، ${fail} فشل`);
  if (fail) process.exitCode = 1;
})();

/* ==========================================================================
   MODELS
   دوال "مصنع" بسيطة (Factory Functions) تمثل شكل كل جدول بيانات (Schema).
   هذه ليست قاعدة بيانات فعلية — فقط تعريف موحّد للحقول تستخدمه ملفات Data
   وتتعامل معه ملفات Services والشاشات، بحيث عند استبدال البيانات التجريبية
   بقاعدة بيانات حقيقية لاحقًا (SQL / Firebase / REST API) يبقى شكل الكائن
   نفسه ولا تحتاج الشاشات لأي تعديل.
   ========================================================================== */

/** الأدوار وحالات الحساب المسموحة */
const ROLES = { USER: 'user', DEALER: 'dealer', ADMIN: 'admin' };
const USER_STATUS = { ACTIVE: 'active', PENDING: 'pending', SUSPENDED: 'suspended' };
/** حالات إعلان سيارة العضو (المرحلة 4) — لا تُستخدم لحالة سيارات المعارض */
/** حالات سيارة المعرض الوحيدة: متاحة للبيع / مباعة. مصدر واحد تستخدمه التسميات وخدمتا المدير والتاجر والترحيل. */
const SHOWROOM_CAR_STATUS = Object.freeze({ AVAILABLE: 'available', SOLD: 'sold' });
const SHOWROOM_CAR_STATUSES = Object.freeze(Object.values(SHOWROOM_CAR_STATUS));
const MEMBER_CAR_STATUS = { PENDING: 'pending', ACTIVE: 'active', SOLD: 'sold', REJECTED: 'rejected', SUSPENDED: 'suspended' };
const CAR_SOURCE = { SHOWROOM: 'showroom', MEMBER: 'member' };

/**
 * User
 * role:   'user' | 'dealer' | 'admin'
 * status: 'active' | 'pending' | 'suspended'
 *   - صاحب المعرض الجديد يبدأ بحالة 'pending' حتى تتم موافقة الإدارة لاحقًا.
 * passwordHash: تجزئة تجريبية فقط (انظر authService.js) — لا تُعرض أبدًا للشاشات.
 */
function UserModel({ id, name, phone, email, role = 'user', status = 'active', passwordHash, createdAt }) {
  return { id, name, phone, email, role, status, passwordHash, createdAt };
}

/**
 * Showroom
 * status: 'active' | 'pending' | 'suspended'
 */
function ShowroomModel({
  id, name, description, phone, whatsapp, address,
  latitude, longitude, image, workingHours, services,
  status = 'pending', ownerId, createdAt, updatedAt
}) {
  return {
    id, name, description, phone, whatsapp, address,
    latitude, longitude, image, workingHours, services,
    status, ownerId, createdAt, updatedAt
  };
}

/**
 * Car (المرحلة 4: يدعم نوعين عبر sourceType)
 * sourceType: 'showroom' (افتراضي، متوافق مع كل بيانات المراحل السابقة) | 'member'
 *   - showroom  → يجب أن تملك showroomId (سيارة تابعة لمعرض)
 *   - member    → يجب أن تملك ownerId (سيارة نشرها مستخدم بنفسه)
 * status:
 *   - لسيارات المعارض: 'available' | 'sold' فقط (لا حالة حجز: السيارة المحجوزة لدى شخص لم تُشترَ بعد فهي متاحة للبيع)
 *   - لسيارات الأعضاء: 'pending' | 'active' | 'sold' | 'rejected' | 'suspended'
 * السعر والعملة (المرحلة 10 / الجزء 5.2): price رقم صرف، و currency حقل مستقل من CURRENCIES ('IQD' | 'USD') — لا يُخزَّن رمز العملة داخل السعر.
 *   السعر والعملة الأصليان لا يتغيّران أبدًا بسبب بحث أو تحويل (التحويل للمقارنة فقط، داخل CarFilters).
 * الحقول الإضافية (phone/whatsapp/location/latitude/longitude) اختيارية،
 * ومخصصة أساسًا لسيارات الأعضاء (لا تحتاجها سيارة المعرض لأن بياناتها في Showroom نفسه).
 */
function CarModel({
  id, showroomId, brand, model, year, price, currency, mileage,
  transmission, fuelType, color, description,
  status = 'available', mainImage, createdAt, updatedAt,
  sourceType = 'showroom', ownerId, phone, whatsapp,
  location, latitude, longitude,
  rejectionReason, suspensionReason, reviewedAt, reviewedBy
}) {
  return {
    id, showroomId, brand, model, year, price, currency, mileage,
    transmission, fuelType, color, description,
    status, mainImage, createdAt, updatedAt,
    sourceType, ownerId, phone, whatsapp,
    location, latitude, longitude,
    rejectionReason, suspensionReason, reviewedAt, reviewedBy
  };
}

/** CarImage — صورة واحدة من عدة صور لنفس السيارة.
    imageUrl يشير إلى النسخة المضغوطة فقط ("idb:<id>" لصورة مرفوعة، أو مسار تجريبي للبيانات الأصلية).
    لا توجد أي حقول للصورة الأصلية (لا originalUrl ولا originalImage) عمدًا.
    isMain: صورة رئيسية واحدة فقط لكل سيارة. */
function CarImageModel({ id, carId, imageUrl, sortOrder = 0, isMain = false }) {
  return { id, carId, imageUrl, sortOrder, isMain };
}

/** Favorite — ربط بين مستخدم وسيارة أعجبته */
function FavoriteModel({ id, userId, carId, createdAt }) {
  return { id, userId, carId, createdAt };
}

/* ==========================================================================
   العملات وسعر الصرف (المرحلة 10 / الجزء 5.2) — المصدر الوحيد في التطبيق.
   - CURRENCIES: العملتان المدعومتان فقط. أي قيمة أخرى ليست عملة صالحة.
   - CURRENCY_LEGACY_DEFAULT: عملة السجلات القديمة بلا حقل currency (كل أسعارها كانت تُعرض بالدينار «د.ع»). تُستعمل للقراءة
     وللهجرة فقط (migrationService)، لا لإنشاء سيارة جديدة.
   - EXCHANGE_RATE_CONFIG: PROTOTYPE STATIC EXCHANGE RATE — سعر صرف تجريبي ثابت. ليس سعرًا حيًّا (live) ولا سعر سوق (market) ولا رسميًّا (official)،
     ولا يُجلب من الإنترنت أو أي API، ولا تُبنى عليه قرارات مالية. هو لمقارنة نطاقات البحث فقط. القيمة: كم دينارًا عراقيًا يساوي 1 دولار.
     الوصول إليه من مكان واحد فقط: getUsdToIqdRate(). لاحقًا تُستبدل القيمة أو الدالة نفسها (إعداد من المدير، Backend، خدمة أسعار حيّة)
     دون لمس محرك البحث (CarFilters) الذي يستدعي convertCurrency فقط.
   ========================================================================== */
const CURRENCY = Object.freeze({ IQD: 'IQD', USD: 'USD' });
const CURRENCIES = Object.freeze([CURRENCY.IQD, CURRENCY.USD]);
const CURRENCY_LEGACY_DEFAULT = CURRENCY.IQD;
const EXCHANGE_RATE_CONFIG = { usdToIqd: 1300, kind: 'prototype', note: 'Prototype static exchange rate — not live, not market, not official' };      // 1 USD = 1300 IQD (قيمة تجريبية قابلة للاستبدال، ليست سعرًا حيًّا)

function isCurrency(v) { return typeof v === 'string' && CURRENCIES.indexOf(v) !== -1; }
/** سعر الصرف الحالي (IQD لكل 1 USD) أو null إن لم يكن رقمًا موجبًا منتهيًا (فلا تحويل ولا مقارنة بين عملتين) */
function getUsdToIqdRate() {
  const r = EXCHANGE_RATE_CONFIG && EXCHANGE_RATE_CONFIG.usdToIqd;
  return (typeof r === 'number' && isFinite(r) && r > 0) ? r : null;
}
/** تحويل مبلغ بين العملتين للمقارنة فقط — بلا أي تقريب (الدقة الكاملة للأعداد العشرية). USD→IQD: ×السعر. IQD→USD: ÷السعر.
    نفس العملة تعيد المبلغ كما هو. عملة غير صالحة أو سعر صرف غير صالح (عند الحاجة إليه) ← null. */
function convertCurrency(amount, from, to) {
  if (!isCurrency(from) || !isCurrency(to) || typeof amount !== 'number' || !isFinite(amount)) return null;
  if (from === to) return amount;
  const rate = getUsdToIqdRate(); if (rate === null) return null;
  return from === CURRENCY.USD ? amount * rate : amount / rate;
}

/* ==========================================================================
   TIMESTAMPS — نظام التاريخ الواحد لحقل createdAt (المرحلة 10 / الجزء 7)
   الصيغة القانونية المخزَّنة: UTC بصيغة toISOString → YYYY-MM-DDTHH:mm:ss.sssZ (السجلات الجديدة تُكتب هكذا أصلًا بـ new Date().toISOString()).
   السجلات القديمة: طابع بلا منطقة زمنية = توقيت العراق المحلي التاريخي (UTC+03:00، بلا توقيت صيفي) ← 2026-09-30T12:00:00 = 2026-09-30T09:00:00.000Z.
   طابع بـZ أو إزاحة (+03:00 / -05:30 / +0300 / +03) يحتفظ بلحظته الفعلية ويُطبَّع إلى UTC. التاريخ وحده (YYYY-MM-DD) = منتصف ليل العراق.
   غير الصالح (مفقود/null/فارغ/نص غريب/تاريخ تقويمي مستحيل كـ2026-02-30/ساعة 24/سنة < 1970/غير نصي) ← parseMs = NaN، وnormalize يعيد المدخل كما هو
   حرفيًا (لا تاريخ مخترع ولا استثناء). Date.parse وحده لا يكفي: يقبل '2026-02-30' و'0' و'12' كتواريخ، ويفسّر الطابع بلا منطقة بتوقيت الجهاز.
   مصدر الحقيقة الوحيد: الهجرة 3 وisSeedRecord وترتيب الأحدث والمفضلة تستعمله، ولا نظام تاريخ ثانٍ.
   ========================================================================== */
const Timestamps = (function () {
  const IRAQ_OFFSET_MIN = 180;
  const RE = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(Z|[+-]\d{2}(?::?\d{2})?)?)?$/;
  const CANONICAL = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
  /** اللحظة بالميلي ثانية (UTC)، أو NaN إن لم يكن نصًا بصيغة تاريخ صالحة */
  function parseMs(v) {
    if (typeof v !== 'string') return NaN;
    const m = RE.exec(v.trim());
    if (!m) return NaN;
    const y = +m[1], mo = +m[2], d = +m[3], hh = m[4] === undefined ? 0 : +m[4], mi = m[5] === undefined ? 0 : +m[5], ss = m[6] === undefined ? 0 : +m[6];
    const ms = m[7] === undefined ? 0 : +((m[7] + '00').slice(0, 3));
    if (y < 1970 || mo < 1 || mo > 12 || hh > 23 || mi > 59 || ss > 59) return NaN;
    const probe = new Date(Date.UTC(y, mo - 1, d));
    if (probe.getUTCMonth() !== mo - 1 || probe.getUTCDate() !== d) return NaN;
    let offMin = IRAQ_OFFSET_MIN;                                   // بلا منطقة = العراق
    if (m[8] !== undefined) {
      if (m[8] === 'Z') offMin = 0;
      else { const sign = m[8][0] === '-' ? -1 : 1, digits = m[8].slice(1).replace(':', ''), oh = +digits.slice(0, 2), om = digits.length > 2 ? +digits.slice(2) : 0; if (oh > 23 || om > 59) return NaN; offMin = sign * (oh * 60 + om); }
    }
    const t = Date.UTC(y, mo - 1, d, hh, mi, ss, ms) - offMin * 60000;
    return Number.isFinite(t) ? t : NaN;
  }
  /** الصيغة القانونية UTC للنص الصالح؛ وأي شيء آخر يُعاد كما هو بلا تغيير (نفس القيمة والنوع) */
  function normalize(v) { const t = parseMs(v); return Number.isNaN(t) ? v : new Date(t).toISOString(); }
  const isCanonical = v => typeof v === 'string' && CANONICAL.test(v) && normalize(v) === v;
  return { parseMs, normalize, isCanonical, IRAQ_OFFSET_MIN };
})();


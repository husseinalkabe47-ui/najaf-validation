/* ==========================================================================
   BASE REPOSITORY — عقد طبقة البيانات
   التدفق:  الشاشات → الخدمات (Services) → Repositories → AppStorage (المحوّل) → localStorage

   الـ Repository مسؤول عن الوصول للبيانات فقط: قراءة/إنشاء/تعديل/حذف/حفظ/استعادة.
   لا قواعد أعمال ولا صلاحيات ولا واجهة (هذه في الخدمات). عند ربط Backend لاحقًا يُكتب
   Repository مقابل بنفس الأسماء ويُستبدل دون لمس الشاشات. (تنبيه: الواجهة الحالية متزامنة؛
   المقابل الـ API سيحتاج Promises — انظر README.)

   العقد المشترك (REPOSITORY_CONTRACT):
     getAll()            → المصفوفة الحية للسجلات (لا ترمي أبدًا)
     getById(id)         → السجل أو null
     create(item)        → { ok, item, persisted } | { ok:false, error }
     update(id, patch)   → { ok, item, persisted } | { ok:false, error }
     remove(id)          → { ok, removed, persisted } | { ok:false, error }
     hydrate()           → يستعيد الحالة المحفوظة فوق البيانات التجريبية (آمن مع أي بيانات تالفة)
   أخطاء المستودع (error): not_found | invalid_data | duplicate_id | protected_record
   persisted:false = نجحت العملية في الذاكرة لكن تعذّر الحفظ (مساحة ممتلئة/تخزين غير متاح)؛
   تقرر الخدمة/الواجهة كيف تُنبّه المستخدم.

   ملاحظة عن السجلات: تُعاد كائنات حيّة (نفس المرجع). لا تُعدَّل مباشرة خارج الـ Repository؛
   أي تعديل يمرّ عبر update() كي يُحفظ.

   إصلاح المرحلة 9 (Fix/Audit):
   - المعرّفات: تصدرها IdAllocator (repositories/idAllocator.js) بعدّاد محفوظ لا يتراجع أبدًا، فلا يُعاد معرّف محذوف،
     وسيارات المعارض وسيارات الأعضاء تتشاركان تسلسل 'car' واحدًا فلا تصادم بينهما (cfg.sequence).
   - سياسة المصفوفة الفارغة المحفوظة (emptyIsValid) صريحة لكل مستودع: تُحترم فقط حيث يستطيع التطبيق
     إنتاج حالة «فارغة» مشروعة (حذف كل السيارات) وتُتجاهل حيث لا يستطيع (المعارض لا تُحذف).
   - hydrateSeedDerived: استعادة مجموعة مشتقة من بيانات تجريبية مع لقطة معرّفات البذور (SeedSnapshot)
     كي تصل البذور الجديدة لمن حفظ سابقًا دون إعادة إحياء ما حذفه المستخدم ودون دهس تعديلاته.
   ========================================================================== */
const REPOSITORY_CONTRACT = ['getAll', 'getById', 'create', 'update', 'remove', 'hydrate'];
const REPO_ERROR = { NOT_FOUND: 'not_found', INVALID: 'invalid_data', DUPLICATE: 'duplicate_id', PROTECTED: 'protected_record' };

function isRecord(x) { return !!x && typeof x === 'object' && !Array.isArray(x); }

/** أسماء دوال العقد الناقصة في repo (قائمة فارغة = مطابق). */
function assertRepository(repo, extra = []) {
  return REPOSITORY_CONTRACT.concat(extra).filter(m => !repo || typeof repo[m] !== 'function');
}

/** يُبقي السجلات الصالحة فقط ويحصي المهمَلة (بيانات تالفة/ناقصة). */
function sanitizeRecords(list, isValid) {
  const items = [], skipped = [];
  (Array.isArray(list) ? list : []).forEach(x => (isValid(x) ? items : skipped).push(x));
  return { items, skipped: skipped.length };
}

/** لقطة معرّفات البذور التي «عرفتها» النسخة المحفوظة (najaf.seedIds = { cars:[…], showrooms:[…] }).
    غياب اللقطة أو تلفها = نسخة قديمة: لا نفترض بذورًا جديدة (السلوك القديم بالضبط). */
const SeedSnapshot = {
  KEY: 'seedIds',
  _all() { return AppStorage.get(this.KEY, {}, isRecord); },
  get(name) { const a = this._all()[name]; return (Array.isArray(a) && a.every(Number.isFinite)) ? a : null; },
  /** يضمن أن اللقطة تحوي ids (اتحاد)، ويكتب فقط عند التغيّر. تُستدعى من persist() المجموعة. */
  ensure(name, ids) {
    const cur = this.get(name);
    const union = [...new Set((cur || []).concat(ids))].sort((a, b) => a - b);
    if (cur && union.length === cur.length) return true;
    const all = Object.assign({}, this._all()); all[name] = union;
    return AppStorage.set(this.KEY, all).ok;
  },
};

/** استعادة مجموعة تُحفظ كمصفوفة كاملة ومصدرها بيانات تجريبية (معارض، سيارات معارض).
    opts: key, name, seedItems (نسخ البذور قبل أي تحميل), isValid, emptyIsValid, replace(items), isIdTaken(id)
    - لا شيء محفوظ → تبقى البيانات التجريبية (ولا كتابة).
    - كلها تالفة → تُتجاهل (لا نمسح التطبيق بسبب تلف).
    - فارغة: تُحترم فقط إن كانت emptyIsValid.
    - البذور الجديدة (غير المعروفة للقطة والغائبة عن المحفوظ) تُضاف؛ المحذوفة سابقًا تبقى محذوفة. */
function hydrateSeedDerived(opts) {
  const raw = AppStorage.get(opts.key, null, Array.isArray);
  if (!Array.isArray(raw)) return false;
  const { items } = sanitizeRecords(raw, opts.isValid);
  if (raw.length > 0 && items.length === 0) return false;
  if (raw.length === 0 && !opts.emptyIsValid) return false;
  const seedIds = opts.seedItems.map(s => s.id);
  const known = SeedSnapshot.get(opts.name) || seedIds;
  const added = opts.seedItems.filter(s => !known.includes(s.id) && !items.some(x => x.id === s.id) && !(opts.isIdTaken && opts.isIdTaken(s.id)));
  opts.replace(items.concat(added.map(s => Object.assign({}, s))));
  return true;
}

/**
 * يبني Repository لمجموعة سجلات تعيش في مصفوفة عامة (data/*.js) بدل تكرار CRUD في كل ملف.
 * getList/setList يصلان لنفس المصفوفة الحية، persist() تُعيد true/false، وهي التي تعرف صيغة الحفظ.
 */
function createCollectionRepository(cfg) {
  const { getList, setList, persist, allocateId, isValid, onCreate, onRemove, canRemove, sequence } = cfg;
  const PROTECTED_FIELDS = cfg.protectedFields || ['id'];
  const valid = isValid || (x => isRecord(x) && (x.id === undefined || Number.isFinite(x.id)));
  // مع sequence: المعرّف من IdAllocator (عدّاد محفوظ لا يتراجع). بدونه: السلوك القديم (أكبر موجود + 1)
  const defaultAllocate = sequence ? (() => IdAllocator.next(sequence)) : (() => Math.max(0, ...getList().map(x => x.id)) + 1);

  return {
    emptyIsValid: cfg.emptyIsValid === true,    // سياسة المصفوفة الفارغة المحفوظة (انظر الرأس)
    save() { return persist() !== false; },     // للهجرات فقط: حفظ المجموعة بعد تعديل داخل طبقة البيانات
    getAll() { return getList(); },
    getById(id) { return getList().find(x => x.id === id) || null; },
    find(pred) { return getList().filter(pred); },
    findOne(pred) { return getList().find(pred) || null; },
    allocateId: allocateId || defaultAllocate,

    create(item) {
      if (!valid(item)) return { ok: false, error: REPO_ERROR.INVALID };
      const id = item.id === undefined ? (allocateId || defaultAllocate)() : item.id;
      if (getList().some(x => x.id === id)) return { ok: false, error: REPO_ERROR.DUPLICATE };
      const record = item.id === undefined ? Object.assign({}, item, { id }) : item;
      getList().push(record);
      if (sequence) IdAllocator.observe(sequence, record.id);   // معرّف صريح أكبر من العدّاد يرفعه
      if (onCreate) onCreate(record);
      return { ok: true, item: record, persisted: persist() !== false };
    },

    update(id, patch) {
      const item = getList().find(x => x.id === id);
      if (!item) return { ok: false, error: REPO_ERROR.NOT_FOUND };
      if (!isRecord(patch)) return { ok: false, error: REPO_ERROR.INVALID };
      Object.keys(patch).forEach(k => { if (!PROTECTED_FIELDS.includes(k)) item[k] = patch[k]; });
      return { ok: true, item, persisted: persist() !== false };
    },

    remove(id) {
      const item = getList().find(x => x.id === id);
      if (!item) return { ok: false, error: REPO_ERROR.NOT_FOUND };
      if (canRemove && !canRemove(item)) return { ok: false, error: REPO_ERROR.PROTECTED };
      setList(getList().filter(x => x !== item));
      const ledgerOk = onRemove ? onRemove(item) !== false : true;   // قبل حفظ المصفوفة (الاتجاه الآمن)
      const listOk = persist() !== false;
      return { ok: true, removed: item, persisted: ledgerOk && listOk };
    },
  };
}

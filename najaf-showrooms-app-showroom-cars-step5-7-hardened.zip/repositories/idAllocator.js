/* ==========================================================================
   ID ALLOCATOR — مُصدِر المعرّفات الموحَّد (إصلاح المرحلة 9)
   المشكلة التي يحلّها: المعرّف كان «أكبر موجود + 1»، فيُعاد معرّف آخر سجل محذوف (فترتبط مفضلة
   قديمة/صور بسيارة جديدة)، وسيارات المعارض والأعضاء كانت تولّد معرّفاتها كلٌّ بمعزل عن الأخرى فتتصادم
   (getCarById يبحث في القائمتين بنفس الرقم).
   الحل: عدّاد «أعلى معرّف صدر» لكل تسلسل (sequence) محفوظ في najaf.idCounters ولا يتراجع أبدًا.
   - التسلسل 'car' مشترك بين سيارات المعارض وسيارات الأعضاء (فضاء معرّفات واحد للسيارة).
   - التسلسلات: car, carImage, favorite, user, showroom.
   - المعرّف التالي = max(العدّاد المحفوظ، أعلى معرّف موجود/مُشار إليه) + 1. «الأرضيات» (floors) تسجّلها
     المستودعات: فإن ضاع العدّاد أو كانت بيانات قديمة بلا عدّاد، لا يُصدَر معرّف مستخدم فعلًا أو مُشار إليه.
   - فشل حفظ العدّاد لا يُسقط شيئًا: يبقى في الذاكرة طوال الجلسة (لا إعادة استخدام داخلها).
   ========================================================================== */
const IdAllocator = (function () {
  const KEY = 'idCounters';
  let _counters = {};
  const _floors = {};          // sequence → [fn() → أعلى معرّف يجب ألا يُصدَر ثانيةً]
  const isCounters = v => isRecord(v) && Object.keys(v).every(k => Number.isFinite(v[k]) && v[k] >= 0);

  function registerFloor(seq, fn) { (_floors[seq] = _floors[seq] || []).push(fn); }
  function _floor(seq) {
    let m = 0;
    (_floors[seq] || []).forEach(fn => { try { const v = Number(fn()); if (Number.isFinite(v) && v > m) m = v; } catch (e) { /* أرضية معطوبة لا تُسقط الإصدار */ } });
    return m;
  }
  function _save() { return AppStorage.set(KEY, _counters).ok; }

  /** استعادة العدّادات المحفوظة (تالفة/غائبة → تبدأ من الأرضيات) */
  function hydrate() { _counters = Object.assign({}, AppStorage.get(KEY, {}, isCounters)); }

  /** أعلى معرّف صدر أو وُجد لهذا التسلسل (لا يكتب شيئًا) */
  function peek(seq) { return Math.max(_counters[seq] || 0, _floor(seq)); }

  /** (الجزء 6.1) يرفع العدّادات التي في الذاكرة إلى ما كتبته نسخة/تبويب آخر في التخزين (لا يخفضها أبدًا): تبويبان لا يصدران المعرّف نفسه */
  function _syncFromStorage() {
    const s = AppStorage.get(KEY, {}, isCounters);
    Object.keys(s).forEach(k => { if (s[k] > (_counters[k] || 0)) _counters[k] = s[k]; });
  }

  /** يصدر معرّفًا جديدًا لم يُستخدم من قبل، ويحفظ العدّاد */
  function next(seq) {
    _syncFromStorage();
    const n = peek(seq) + 1;
    _counters[seq] = n;
    _save();
    return n;
  }

  /** معرّف صريح (سجل يُنشأ بمعرّفه) يرفع العدّاد إن كان أكبر منه */
  function observe(seq, id) {
    if (Number.isFinite(id) && id > (_counters[seq] || 0)) { _counters[seq] = id; _save(); }
  }

  /** يثبّت الأرضيات الحالية في العدّادات المحفوظة (تستخدمه الهجرة قبل حذف سجلات يتيمة) */
  function persistFloors() {
    Object.keys(_floors).forEach(seq => { _counters[seq] = Math.max(_counters[seq] || 0, _floor(seq)); });
    return _save();
  }

  return { hydrate, peek, next, observe, registerFloor, persistFloors, KEY };
})();

/** أكبر معرّف رقمي في قائمة (0 إن كانت فارغة) — مساعد للأرضيات */
function maxId(list, pick) {
  let m = 0;
  (Array.isArray(list) ? list : []).forEach(x => { const v = Number(pick ? pick(x) : x && x.id); if (Number.isFinite(v) && v > m) m = v; });
  return m;
}

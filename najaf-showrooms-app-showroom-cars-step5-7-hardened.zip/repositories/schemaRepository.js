/* SCHEMA REPOSITORY — رقم إصدار مخطط التخزين (najaf.schemaVersion). وصول للبيانات فقط؛ منطق الهجرات في
   services/migrationService.js. (ليست مجموعة سجلات، فلا تطبّق REPOSITORY_CONTRACT كالجلسة.) */
const SchemaRepository = {
  KEY: 'schemaVersion',
  /** رقم الإصدار المحفوظ أو null (غائب/تالف) */
  getVersion() { return AppStorage.get(this.KEY, null, v => Number.isFinite(v) && v >= 0); },
  setVersion(v) { return AppStorage.set(this.KEY, v).ok; },
  /** هل في التخزين بيانات تطبيق حقيقية؟ مفاتيح البنية وعلامة ترحيل سجل المحذوفات (تُكتب فارغة في التثبيت الجديد) لا تُحسب. */
  hasData() {
    const meta = [this.KEY, IdAllocator.KEY, SeedSnapshot.KEY, 'memberCarsDeleted'];
    return AppStorage.keys().some(k => meta.indexOf(k) < 0);
  },
};

/* سجل الـ Repositories + استعادة الحالة المحفوظة دفعة واحدة عند بدء التطبيق (app.js). */
const Repositories = {
  users: UsersRepository, showrooms: ShowroomsRepository, memberCars: MemberCarsRepository, cars: CarsRepository,
  carImages: CarImagesRepository, favorites: FavoritesRepository,
};

/** (الجزء 6.1) هل حدث `storage` (تغيير من تبويب آخر) يخص مفاتيح التطبيق؟ key=null تعني مسحًا كاملًا. معرفة البادئة تبقى في طبقة المستودعات/التخزين لا في app.js. */
function isDataChangeEvent(e) { const k = e && e.key; return k === null || k === undefined || String(k).indexOf(AppStorage.PREFIX) === 0; }

/** يستعيد كل المجموعات فوق البيانات التجريبية. لا يمسح شيئًا ولا يلمس مفاتيح غير معروفة.
    فشل مستودع لا يُسقط البقية، ويُسجَّل في failed (فلا تُشغَّل الهجرات على حالة غير معروفة). يعيد { failed }. */
function hydrateRepositories() {
  const failed = [];
  try { IdAllocator.hydrate(); } catch (e) { console.error('[hydrate failed]', 'idAllocator', e); failed.push('idAllocator'); }
  Object.keys(Repositories).forEach(name => {
    try { Repositories[name].hydrate(); }
    catch (e) { console.error('[hydrate failed]', name, e); failed.push(name); }   // مجموعة واحدة تالفة لا تُسقط بقية التطبيق
  });
  return { failed };
}

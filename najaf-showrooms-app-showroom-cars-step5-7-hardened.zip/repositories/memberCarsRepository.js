/* MEMBER CARS REPOSITORY — سيارات الأعضاء (MEMBER_CARS).
   صيغة الحفظ (لم تتغير منذ المرحلة 4/8، للتوافق مع بيانات المستخدمين الحالية):
     najaf.memberCars         = المصفوفة الكاملة (تجريبية معدّلة + مضافة)
     najaf.memberCarsDeleted  = سجل صريح بمعرّفات ما حُذف عمدًا (إصلاح المرحلة 8)
   التحميل يبدأ دائمًا من البيانات التجريبية الكاملة، لذلك غياب سيارة عن المحفوظ لا يعني حذفها:
   الحذف يُسجَّل في السجل ويُطبَّق عند hydrate.
   إصلاح المرحلة 9: المعرّف التالي من IdAllocator (التسلسل 'car' المشترك مع سيارات المعارض) وأرضيته تشمل
   معرّفات السجل المحذوف؛ فلا يُعاد معرّف محذوف ولا يتصادم مع سيارة معرض. وكتابة السجل الفارغ عند أول تشغيل
   مقصودة وباقية (علامة ترحيل مرة واحدة؛ اختبارات المرحلتين 8 و9 تثبّتها). */
const MemberCarsRepository = (function () {
  const KEY = 'memberCars', DELETED_KEY = 'memberCarsDeleted';
  const SEED_IDS = MEMBER_CARS.map(c => c.id);    // السيارات التجريبية الأصلية (قبل أي تحميل)
  const SEED_CREATED = {}; MEMBER_CARS.forEach(c => { SEED_CREATED[c.id] = c.createdAt; });
  let _deletedIds = [];
  const isCar = c => isRecord(c) && Number.isFinite(c.id);

  function persist() { return AppStorage.set(KEY, MEMBER_CARS).ok; }
  function markDeleted(id) {
    if (!_deletedIds.includes(id)) _deletedIds.push(id);
    return AppStorage.set(DELETED_KEY, _deletedIds).ok;
  }

  const base = createCollectionRepository({
    getList: () => MEMBER_CARS,
    setList: v => { MEMBER_CARS = v; },
    persist,
    sequence: 'car',                                              // تصاعدي دائمًا ومشترك مع سيارات المعارض
    onRemove: item => markDeleted(item.id),
  });
  IdAllocator.registerFloor('car', () => Math.max(maxId(MEMBER_CARS), ..._deletedIds.filter(Number.isFinite)));

  /** استعادة الحالة المحفوظة فوق البيانات التجريبية (آمنة مع أي بيانات تالفة). */
  function hydrate() {
    const saved = sanitizeRecords(AppStorage.get(KEY, [], Array.isArray), isCar).items;
    let deleted = AppStorage.get(DELETED_KEY, null, Array.isArray);
    if (!Array.isArray(deleted)) {
      // محفوظات بالصيغة القديمة (قبل السجل): _persist القديمة كانت تكتب المصفوفة كاملة بما فيها كل البذرية،
      // فأي سيارة بذرية غائبة عن المحفوظ حُذفت عمدًا. يُسجَّل ذلك مرة واحدة (لا نستنتج من عدد السيارات).
      deleted = saved.length ? SEED_IDS.filter(id => !saved.some(c => c.id === id)) : [];
      AppStorage.set(DELETED_KEY, deleted);                        // علامة الترحيل: تُكتب مرة واحدة (فارغة في التثبيت الجديد)
    }
    _deletedIds = deleted.filter(n => Number.isFinite(n));

    MEMBER_CARS = MEMBER_CARS.filter(c => !_deletedIds.includes(c.id));   // لا تُعاد البذرية المحذوفة
    saved.forEach(c => {
      if (_deletedIds.includes(c.id)) return;                             // السجل مرجع حتى لو بقيت في المصفوفة (انقطاع وسط الحذف)
      const i = MEMBER_CARS.findIndex(x => x.id === c.id);
      if (i >= 0) MEMBER_CARS[i] = c; else MEMBER_CARS.push(c);          // معدَّلة | مضافة
    });
  }

  function isSeedRecord(car) { return !!car && SEED_CREATED[car.id] !== undefined && Timestamps.normalize(SEED_CREATED[car.id]) === Timestamps.normalize(car.createdAt); }   // (ج7) يقارن اللحظة لا النص: بذرة مخزَّنة بالصيغة القديمة (بلا منطقة) = بذرة الكود القانونية نفسها

  return Object.assign(base, {
    hydrate, isSeedRecord,
    getByOwner(ownerId) { return MEMBER_CARS.filter(c => c.ownerId === ownerId); },
    getDeletedIds() { return _deletedIds.slice(); },
  });
})();

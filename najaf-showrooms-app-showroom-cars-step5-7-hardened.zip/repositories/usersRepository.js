/* USERS REPOSITORY — المستخدمون (USERS).
   الحفظ:
     najaf.registeredUsers = المستخدمون الجدد فقط (غير التجريبيين) — كما في المراحل السابقة
     najaf.userOverrides   = { [id]: تعديلات } على المستخدمين التجريبيين (جديد في المرحلة 9:
                             الموافقة على تاجر/رفضه كانت تضيع بعد إعادة التحميل)
   passwordHash يبقى هنا ولا يخرج من طبقة البيانات إلا عبر UserService.toPublic. */
const UsersRepository = (function () {
  const REG_KEY = 'registeredUsers', OVR_KEY = 'userOverrides';
  const SEED_IDS = USERS.map(u => u.id);
  const OVERRIDE_BLOCKED = ['id', 'passwordHash'];
  let _overrides = {};
  const isSeed = id => SEED_IDS.includes(id);
  const isUser = u => isRecord(u) && Number.isFinite(u.id);

  function persist() { return AppStorage.set(REG_KEY, USERS.filter(u => !isSeed(u.id))).ok; }

  const base = createCollectionRepository({
    getList: () => USERS,
    setList: v => { USERS.splice(0, USERS.length, ...v); },
    persist,
    sequence: 'user',                     // معرّف مستخدم محذوف لا يُعاد (الجلسات وownerId تعتمد عليه)
    canRemove: u => !isSeed(u.id),        // المستخدمون التجريبيون لا يُحذفون (لا يوجد سجل محذوفات لهم)
  });
  IdAllocator.registerFloor('user', () => maxId(USERS));

  const baseUpdate = base.update;     // تُحفظ قبل Object.assign أدناه (وإلا استدعت update نفسها)
  function update(id, patch) {
    const r = baseUpdate(id, patch);
    if (r.ok && isSeed(id)) {
      const clean = {}; Object.keys(patch).forEach(k => { if (!OVERRIDE_BLOCKED.includes(k)) clean[k] = patch[k]; });
      _overrides[id] = Object.assign({}, _overrides[id], clean);
      r.persisted = AppStorage.set(OVR_KEY, _overrides).ok && r.persisted;
    }
    return r;
  }

  function hydrate() {
    sanitizeRecords(AppStorage.get(REG_KEY, [], Array.isArray), isUser).items.forEach(u => {
      if (!USERS.some(x => x.id === u.id)) USERS.push(UserModel(u));
    });
    const ovr = AppStorage.get(OVR_KEY, {}, isRecord);
    _overrides = {};
    Object.keys(ovr).forEach(k => {
      const id = Number(k), user = USERS.find(u => u.id === id);
      if (user && isSeed(id) && isRecord(ovr[k])) {
        const clean = {}; Object.keys(ovr[k]).forEach(f => { if (!OVERRIDE_BLOCKED.includes(f)) clean[f] = ovr[k][f]; });
        Object.assign(user, clean); _overrides[id] = clean;
      }
    });
  }

  return Object.assign(base, { update, hydrate });
})();

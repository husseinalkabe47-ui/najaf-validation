/* CARS REPOSITORY — سيارات المعارض (CARS، sourceType='showroom').
   الحفظ: najaf.showroomCars = المصفوفة الكاملة (الحذف يبقى حذفًا: المحفوظ يستبدل المحتوى).
   إصلاح المرحلة 9:
     - المعرّفات: التسلسل 'car' المشترك مع سيارات الأعضاء (IdAllocator) — لا يُعاد معرّف محذوف ولا يتصادم النوعان.
     - emptyIsValid = true: حذف كل السيارات حالة مشروعة فتُحترم المصفوفة الفارغة المحفوظة.
     - البذور الجديدة (غير المعروفة للقطة) تصل لمن حفظ سابقًا؛ المحذوفة تبقى محذوفة؛ تعديلات المستخدم تبقى. */
const CarsRepository = (function () {
  const KEY = 'showroomCars';
  const SEED_ITEMS = CARS.map(c => Object.assign({}, c));          // نسخة البذور قبل أي استعادة
  const SEED_CREATED = {}; SEED_ITEMS.forEach(c => { SEED_CREATED[c.id] = c.createdAt; });
  const isCar = c => isRecord(c) && Number.isFinite(c.id);
  function persist() { SeedSnapshot.ensure('cars', SEED_ITEMS.map(c => c.id)); return AppStorage.set(KEY, CARS).ok; }

  const base = createCollectionRepository({
    getList: () => CARS,
    setList: v => { CARS.splice(0, CARS.length, ...v); },       // CARS ثابت: نستبدل المحتوى في مكانه
    persist,
    sequence: 'car',
    emptyIsValid: true,
  });
  IdAllocator.registerFloor('car', () => maxId(CARS));

  function hydrate() {
    hydrateSeedDerived({ key: KEY, name: 'cars', seedItems: SEED_ITEMS, isValid: isCar, emptyIsValid: true,
      isIdTaken: id => !!MemberCarsRepository.getById(id),
      replace: items => CARS.splice(0, CARS.length, ...items) });
  }

  /** سجل تجريبي غير معدَّل المعرّف/التاريخ (تاريخه ثابت في البيانات التجريبية فلا يُقارن بتاريخ جهاز المستخدم) */
  function isSeedRecord(car) { return !!car && SEED_CREATED[car.id] !== undefined && Timestamps.normalize(SEED_CREATED[car.id]) === Timestamps.normalize(car.createdAt); }   // (ج7) يقارن اللحظة لا النص: بذرة مخزَّنة بالصيغة القديمة (بلا منطقة) = بذرة الكود القانونية نفسها

  /** للهجرة فقط: تغيير معرّف سيارة (حل تصادم قديم). يرفض إن كان المعرّف الجديد مستخدمًا. */
  function reassignId(oldId, newId) {
    const c = CARS.find(x => x.id === oldId);
    if (!c) return { ok: false, error: REPO_ERROR.NOT_FOUND };
    if (CARS.some(x => x.id === newId)) return { ok: false, error: REPO_ERROR.DUPLICATE };
    c.id = newId;
    return { ok: true, item: c };
  }

  return Object.assign(base, {
    hydrate, isSeedRecord, reassignId,
    getByShowroom(showroomId) { return CARS.filter(c => c.showroomId === showroomId); },
  });
})();

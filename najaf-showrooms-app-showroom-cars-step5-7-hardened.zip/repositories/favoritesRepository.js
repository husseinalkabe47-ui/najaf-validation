/* FAVORITES REPOSITORY — المفضلة (FAVORITES): { id, userId, carId, createdAt }.
   الحفظ: najaf.favorites = المصفوفة الكاملة (لكل المستخدمين؛ العزل بين المستخدمين بالاستعلام getByUser).
   إصلاح المرحلة 9: معرّف المفضلة من IdAllocator، وremoveByCar ينظّف مفضلة سيارة محذوفة (لكل المستخدمين)،
   وemptyIsValid = true (إزالة كل المفضلة حالة مشروعة). وأرضية تسلسل 'car' تشمل carId المُشار إليه هنا. */
const FavoritesRepository = (function () {
  const KEY = 'favorites';
  const isFav = f => isRecord(f) && Number.isFinite(f.userId) && Number.isFinite(f.carId);
  function persist() { return AppStorage.set(KEY, FAVORITES).ok; }

  const base = createCollectionRepository({
    getList: () => FAVORITES,
    setList: v => { FAVORITES = v; },
    persist,
    sequence: 'favorite',
    emptyIsValid: true,
    isValid: f => isFav(f) && (f.id === undefined || Number.isFinite(f.id)),
  });
  IdAllocator.registerFloor('favorite', () => maxId(FAVORITES));
  IdAllocator.registerFloor('car', () => maxId(FAVORITES, f => f.carId));

  function hydrate() {
    const raw = AppStorage.get(KEY, null, Array.isArray);
    if (!Array.isArray(raw)) return;
    FAVORITES = sanitizeRecords(raw, isFav).items;
  }

  /** يحذف كل مفضلة لسيارة (لكل المستخدمين) ويعيد المحذوف. تُستدعى عند حذف السيارة. */
  function removeByCar(carId) {
    const removed = FAVORITES.filter(f => f.carId === carId);
    if (removed.length) { FAVORITES = FAVORITES.filter(f => f.carId !== carId); persist(); }
    return removed;
  }

  /** للهجرة: يحذف المفضلة التي يقرّر shouldRemove(fav) حذفها ويعيد المحذوف. */
  function removeWhere(shouldRemove) {
    const removed = FAVORITES.filter(shouldRemove);
    if (removed.length) { FAVORITES = FAVORITES.filter(f => !shouldRemove(f)); persist(); }
    return removed;
  }

  return Object.assign(base, {
    hydrate, removeByCar, removeWhere,
    getByUser(userId) { return FAVORITES.filter(f => f.userId === userId); },
    findByUserAndCar(userId, carId) { return FAVORITES.find(f => f.userId === userId && f.carId === carId) || null; },
  });
})();

/* SESSION REPOSITORY — الجلسة الحالية { userId, createdAt, expiresAt }. (ليست مجموعة سجلات،
   لذا لا تطبّق REPOSITORY_CONTRACT.) الصلاحية/الانتهاء يقررهما SessionService، وهنا الحفظ فقط. */
const SessionRepository = {
  get() { return AppStorage.get('session', null, s => isRecord(s) && Number.isFinite(s.userId)); },
  save(session) { return AppStorage.set('session', session); },
  clear() { return AppStorage.remove('session'); },
};

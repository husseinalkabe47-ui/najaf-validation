/* CAR IMAGES REPOSITORY — سجلات صور السيارات (CAR_IMAGES): { id, carId, imageUrl, sortOrder, isMain }.
   بيانات وصفية فقط: imageUrl يشير إلى النسخة المضغوطة ("idb:<id>")، وملفات الصور نفسها في ImageStore
   (لم يتغير). لا توجد حقول للصورة الأصلية. الحفظ: najaf.carImages = المصفوفة الكاملة.
   إصلاح المرحلة 9: معرّف الصورة من IdAllocator (لا يُعاد معرّف صورة محذوفة فلا يلتبس مفتاح idb:<id>)،
   وemptyIsValid = true (حذف كل الصور حالة مشروعة). وأرضية تسلسل 'car' تشمل carId المُشار إليه هنا. */
const CarImagesRepository = (function () {
  const KEY = 'carImages';
  const isImage = i => isRecord(i) && Number.isFinite(i.id) && Number.isFinite(i.carId) && typeof i.imageUrl === 'string';
  function persist() { return AppStorage.set(KEY, CAR_IMAGES).ok; }

  const base = createCollectionRepository({
    getList: () => CAR_IMAGES,
    setList: v => { CAR_IMAGES = v; },
    persist,
    sequence: 'carImage',
    emptyIsValid: true,
    isValid: i => isRecord(i) && (i.id === undefined || Number.isFinite(i.id)) && Number.isFinite(i.carId) && typeof i.imageUrl === 'string',
  });
  IdAllocator.registerFloor('carImage', () => maxId(CAR_IMAGES));
  IdAllocator.registerFloor('car', () => maxId(CAR_IMAGES, i => i.carId));    // معرّف سيارة تُشير إليه صورة لا يُصدَر ثانيةً

  function hydrate() {
    const raw = AppStorage.get(KEY, null, Array.isArray);
    if (!Array.isArray(raw)) return;
    const { items } = sanitizeRecords(raw, isImage);
    if (raw.length > 0 && items.length === 0) return;           // كلها تالفة: نتجاهلها
    CAR_IMAGES = items;
  }

  function getByCar(carId) { return CAR_IMAGES.filter(i => i.carId === carId).sort((a, b) => a.sortOrder - b.sortOrder); }

  /** يحذف كل صور سيارة ويعيد السجلات المحذوفة (لتحذف الخدمة ملفاتها من ImageStore). */
  function removeByCar(carId) {
    const removed = CAR_IMAGES.filter(i => i.carId === carId);
    if (removed.length) { CAR_IMAGES = CAR_IMAGES.filter(i => i.carId !== carId); persist(); }
    return removed;
  }

  /** للهجرة/السلامة: يحذف الصور التي يقرّر shouldRemove(image) حذفها ويعيد المحذوف (ويحفظ). */
  function removeWhere(shouldRemove) {
    const removed = CAR_IMAGES.filter(shouldRemove);
    if (removed.length) { CAR_IMAGES = CAR_IMAGES.filter(i => !shouldRemove(i)); persist(); }
    return removed;
  }

  /** للهجرة: يحذف الصور التي لا سيارة لها (carExists(carId) → bool) ويعيد المحذوف. */
  function removeOrphans(carExists) {
    const removed = CAR_IMAGES.filter(i => !carExists(i.carId));
    if (removed.length) { CAR_IMAGES = CAR_IMAGES.filter(i => carExists(i.carId)); persist(); }
    return removed;
  }

  /** يضبط صورة رئيسية واحدة بالضبط وترقيمًا متصلًا لصور السيارة (mainId اختياري: الحالية أو الأولى). */
  function applyLayout(carId, mainId) {
    const imgs = getByCar(carId);
    if (!imgs.length) return { ok: true, main: null, persisted: true };
    const main = imgs.find(i => i.id === mainId) || imgs.find(i => i.isMain) || imgs[0];
    imgs.forEach((i, idx) => { i.isMain = (i === main); i.sortOrder = idx; });
    return { ok: true, main, persisted: persist() !== false };
  }

  return Object.assign(base, { hydrate, getByCar, removeByCar, removeOrphans, removeWhere, applyLayout });
})();

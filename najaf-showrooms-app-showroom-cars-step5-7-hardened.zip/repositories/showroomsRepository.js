/* SHOWROOMS REPOSITORY — المعارض (SHOWROOMS).
   الحفظ: najaf.showrooms = المصفوفة الكاملة. (المرحلة 9: إيقاف/تفعيل المعرض من الإدارة كان يضيع بعد إعادة التحميل؛ صار يُحفظ.)
   التطبيق لا يحذف معارض فعليًا (إيقاف فقط)، وremove موجودة للعقد ولربط Backend لاحقًا.
   إصلاح المرحلة 9:
     - emptyIsValid = false: المعارض لا تُحذف، فمصفوفة فارغة محفوظة = تلف وليست حالة مشروعة → تبقى التجريبية.
     - معارض التجريبية الجديدة (لم تكن في لقطة البذور) تصل لمن حفظ سابقًا (hydrateSeedDerived).
     - معرّف المعرض من IdAllocator (معرض التاجر الجديد يُنشأ عند اعتماده). */
const ShowroomsRepository = (function () {
  const KEY = 'showrooms';
  const SEED_ITEMS = SHOWROOMS.map(s => Object.assign({}, s));     // نسخة البذور قبل أي استعادة
  const isShowroom = s => isRecord(s) && Number.isFinite(s.id);
  function persist() { SeedSnapshot.ensure('showrooms', SEED_ITEMS.map(s => s.id)); return AppStorage.set(KEY, SHOWROOMS).ok; }

  const base = createCollectionRepository({
    getList: () => SHOWROOMS,
    setList: v => { SHOWROOMS.splice(0, SHOWROOMS.length, ...v); },
    persist,
    sequence: 'showroom',
    emptyIsValid: false,
  });
  IdAllocator.registerFloor('showroom', () => maxId(SHOWROOMS));

  function hydrate() {
    hydrateSeedDerived({ key: KEY, name: 'showrooms', seedItems: SEED_ITEMS, isValid: isShowroom, emptyIsValid: false,
      replace: items => SHOWROOMS.splice(0, SHOWROOMS.length, ...items) });
  }

  return Object.assign(base, { hydrate });
})();

/* خدمة تنسيق بسيطة: تحويل القيم الخام (أرقام/حالات) إلى نصوص وشارات جاهزة للعرض،
   بدون أن تعرف عنها الشاشات أو المكوّنات أي تفاصيل داخلية. */

function money(n) {
  const x = Number(n);
  if (n === null || n === undefined || n === '' || !isFinite(x)) return '—';
  return x.toLocaleString('ar-IQ') + " د.ع";
}

/* ---- العملات (المرحلة 10 / الجزء 5.2): كل تنسيق مبلغ/عملة هنا فقط — البطاقات والشاشات والشارات تستدعي هذه الدوال ولا تنسّق بنفسها.
   الأرقام بصيغة ar-IQ كما في بقية التطبيق. الدولار «$» مع الرقم داخل عزل اتجاهي (LTR) كي يظهر «$٢٥٬٠٠٠» بالرمز يسارًا في واجهة RTL.
   money(n) أعلاه يبقى للدينار وحده (توافق). التحويل بين العملتين ليس هنا (convertCurrency في models.js، ويستعمله CarFilters للمقارنة فقط). */
const CURRENCY_LABEL = { IQD: 'الدينار العراقي', USD: 'الدولار الأمريكي' };
const CURRENCY_SHORT = { IQD: 'د.ع', USD: '$' };

/** عملة سيارة: حقل currency الصالح، أو العملة القديمة (IQD) إن كان الحقل غائبًا (سجل قديم)؛ قيمة غير غائبة وغير مدعومة ← null (عملة مجهولة). */
function carCurrency(car) {
  const v = car && typeof car === 'object' ? car.currency : undefined;
  if (v === undefined || v === null || v === '') return CURRENCY_LEGACY_DEFAULT;
  return isCurrency(v) ? v : null;
}
/** يتحقق من عملة مُدخَلة من الواجهة/الخدمة: { ok, value } أو { ok:false }. يقبل الحرف الكبير/الصغير والمسافات حول الرمز فقط. */
function parseCurrency(v) {
  if (typeof v !== 'string') return { ok: false };
  const u = v.trim().toUpperCase();
  return isCurrency(u) ? { ok: true, value: u } : { ok: false };
}
/** مبلغ بعملته: «٣٥٬٠٠٠٬٠٠٠ د.ع» أو «$٢٥٬٠٠٠». مبلغ أو عملة غير صالحين ← '—'. */
function formatAmount(n, currency) {
  const x = Number(n);
  if (n === null || n === undefined || n === '' || !isFinite(x) || !isCurrency(currency)) return '—';
  const t = x.toLocaleString('ar-IQ');
  return currency === CURRENCY.USD ? `\u2066$${t}\u2069` : `${t} ${CURRENCY_SHORT.IQD}`;
}
/** سعر السيارة كما هو مخزَّن (السعر + عملته الأصلية، بلا تحويل). سعر مجهول أو عملة مجهولة ← null (تعرضه الواجهات «السعر غير محدد»). */
function carPriceText(car) {
  const p = validPrice(car && car.price), cur = carCurrency(car);
  return (p === null || cur === null) ? null : formatAmount(p, cur);
}
/** نفس carPriceText لكن '—' بدل null (للقوائم الإدارية والمشاركة) */
function carPriceOrDash(car) { const t = carPriceText(car); return t === null ? '—' : t; }
/** خيارات قائمة العملة في النماذج (من CURRENCIES): selected = العملة المختارة (غير صالحة/غائبة ← الدينار) */
function currencyOptionsHtml(selected) {
  const sel = isCurrency(selected) ? selected : CURRENCY_LEGACY_DEFAULT;
  return CURRENCIES.map(c => `<option value="${c}" ${c === sel ? 'selected' : ''}>${CURRENCY_LABEL[c]}</option>`).join('');
}

const CAR_STATUS_LABEL = { available: "متاحة للبيع", sold: "مباعة" };   // حالتان فقط (انظر SHOWROOM_CAR_STATUSES): لا «محجوز»
const SHOWROOM_STATUS_LABEL = { active: "نشط", pending: "قيد المراجعة", suspended: "موقوف" };

/* شارات الحالة (المرحلة 10 / الجزء 3): حالة غير معرَّفة أو ناقصة ← نص فارغ، فلا يرى المستخدم رمزًا داخليًا ولا «undefined». */
const _hasLabel = (map, k) => typeof k === 'string' && Object.prototype.hasOwnProperty.call(map, k);

function carStatusBadge(status) {
  if (!_hasLabel(CAR_STATUS_LABEL, status)) return '';
  const cls = status === 'available' ? 'open' : 'sold';
  return `<span class="badge ${cls}">${cls === 'open' ? '🟢' : '🔴'} ${CAR_STATUS_LABEL[status]}</span>`;
}

function showroomStatusBadge(status) {
  if (!_hasLabel(SHOWROOM_STATUS_LABEL, status)) return '';
  const cls = status === 'active' ? 'open' : status === 'suspended' ? 'sold' : 'warn';   // warn = برتقالي «قيد المراجعة»
  const dot = cls === 'open' ? '🟢' : cls === 'sold' ? '🔴' : '🟠';
  return `<span class="badge ${cls}">${dot} ${SHOWROOM_STATUS_LABEL[status]}</span>`;
}

const ROLE_LABEL = { user: "مستخدم", dealer: "صاحب معرض", admin: "مدير النظام" };
const USER_STATUS_LABEL = { active: "فعّال", pending: "بانتظار موافقة الإدارة", suspended: "موقوف" };

/* ---- المرحلة 4: سيارات الأعضاء ---- */
const MEMBER_CAR_STATUS_LABEL = { pending: "قيد المراجعة", active: "نشط", sold: "مباعة", rejected: "مرفوض", suspended: "موقوف" };

function memberCarStatusBadge(status) {
  if (!_hasLabel(MEMBER_CAR_STATUS_LABEL, status)) return '';
  const cls = status === 'active' ? 'open' : status === 'pending' ? 'warn' : 'sold'; // sold/rejected/suspended بنفس لون التحذير الأحمر
  const dot = cls === 'open' ? '🟢' : cls === 'warn' ? '🟠' : '🔴';
  return `<span class="badge ${cls}">${dot} ${MEMBER_CAR_STATUS_LABEL[status]}</span>`;
}

/** شارة تمييز المصدر (لا تُستخدم بدل شارة الحالة، بل بجانبها) */
function sourceBadge(sourceType) {
  return sourceType === 'member'
    ? `<span class="badge member">🧑 من عضو</span>`
    : `<span class="badge showroom-src">🏢 معرض</span>`;
}

/** تهريب نص قبل وضعه داخل HTML (يُستخدم في شاشات المرحلة 7 الجديدة) */
function esc(v) {
  // كائن/دالة/NaN/لانهاية ليست نصًا للعرض: «[object Object]» و«NaN» لا تصل للمستخدم (المرحلة 10 / الجزء 3)
  if (v !== null && (typeof v === 'function' || typeof v === 'symbol' || (typeof v === 'object' && !Array.isArray(v)))) return '';
  if (typeof v === 'number' && !isFinite(v)) return '';
  return String(v === undefined || v === null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');   // (الجزء 6.1) والفاصلة العليا أيضًا: دفاع إضافي إن استُعمل النص يومًا داخل سمة بعلامات مفردة
}


/* ---- المرحلة 8: مساعدات عرض آمنة (لا undefined/null/NaN أمام المستخدم) ---- */
/** قيمة نصية آمنة للعرض: مهرَّبة، وبديل «—» إن كانت فارغة */
function val(v, fallback = '—') {
  const s = esc(v);
  return s.trim() === '' ? fallback : s;
}
function km(n) {
  const x = Number(n);
  return (n === null || n === undefined || n === '' || !isFinite(x)) ? '—' : x.toLocaleString('ar-IQ') + ' كم';
}
/* ---- المرحلة 10 / الجزء 3: مساعدات العرض الانتقائي (تُخفي الناقص بدل عرض «—») ---- */
/** نص قابل للعرض (غير مهرَّب) أو '': نص مقصوص أو رقم منتهٍ؛ غير ذلك (null/كائن/NaN) ← '' */
function plainText(v) {
  if (typeof v === 'string') return v.replace(/\s+/g, ' ').trim();
  if (typeof v === 'number' && isFinite(v)) return String(v);
  return '';
}
/** سنة صنع صالحة (عدد صحيح 1900–2100، رقمًا أو نصًا رقميًا) أو null. حدّا الصلاحية للتحقق فقط لا قائمة خيارات:
    الخيارات تُستخرج من بيانات السيارات نفسها (CarFilters.options). 0/سالب/1/99999/نص/كائن/NaN ← null (قيمة بلا معنى لا تُعرض ولا تُصفَّى). */
function validYear(v) {
  if (v === null || v === undefined || v === '' || typeof v === 'object' || typeof v === 'boolean') return null;
  const s = typeof v === 'string' ? v.trim() : v;
  if (typeof s === 'string' && !/^\d+$/.test(s)) return null;
  const n = Number(s); return (Number.isInteger(n) && n >= 1900 && n <= 2100) ? n : null;
}
/** سنة صنع صالحة للعرض أو '' */
function yearText(v) { const y = validYear(v); return y === null ? '' : String(y); }
/** مسافة صالحة (صفر فأكثر، رقم أو نص رقمي) أو null؛ 0 قيمة حقيقية، والمجهولة null */
function validMileage(v) {
  const n = _plainNumber(v); return (n !== null && n >= 0) ? n : null;
}
/** (الجزء 6.1) رقم من قيمة مخزَّنة: رقم منتهٍ، أو نص عشري عادي فقط («15000000»، «12.5»). نص فارغ/مسافات («كانت 0»)، «1e3»، «0x10»، «Infinity»،
    وأي قيمة فوق أكبر عدد صحيح آمن ← null (مجهول لا يمرّ كرقم). */
function _plainNumber(v) {
  let n;
  if (typeof v === 'number') n = v;
  else if (typeof v === 'string' && /^\s*\d+(\.\d+)?\s*$/.test(v)) n = Number(v);
  else return null;
  return (isFinite(n) && Math.abs(n) <= Number.MAX_SAFE_INTEGER) ? n : null;
}
/** سعر صالح للعرض (> 0) أو null */
function validPrice(v) {
  const n = _plainNumber(v); return (n !== null && n > 0) ? n : null;
}
/** عدّاد سيارات بصيغة عربية صحيحة: سيارة واحدة / سيارتان / 3–10 سيارات / 11+ سيارة. غير صالح أو صفر ← '' (الفارغ له حالته الخاصة) */
function carCountLabel(n) {
  if (typeof n !== 'number' || !Number.isInteger(n) || n < 1) return '';
  if (n === 1) return 'سيارة واحدة';
  if (n === 2) return 'سيارتان';
  return n <= 10 ? `${n} سيارات` : `${n} سيارة`;
}
/** عنوان السيارة «ماركة موديل» أو «سيارة» إن غابا */
function carTitle(c) { return [plainText(c && c.brand), plainText(c && c.model)].filter(Boolean).join(' ') || 'سيارة'; }

/** رسالة صالحة للمستخدم: أي رسالة فارغة أو تقنية (undefined/TypeError...) تُستبدل برسالة عربية عامة */
function userMsg(m, fallback = 'حدث خطأ، حاول مرة أخرى') {
  if (typeof m !== 'string' || !m.trim()) return fallback;
  if (/undefined|null|NaN|\[object|TypeError|ReferenceError|SyntaxError|RangeError|Error:/.test(m)) return fallback;
  return m;
}
/** روابط التواصل: تعيد '' إن لم تتوفر بيانات صالحة (فلا يظهر زر برابط فارغ) */
function telLink(phone) {
  const d = String(phone === undefined || phone === null ? '' : phone).replace(/[^\d+]/g, '');
  return d.replace(/\D/g, '').length >= 7 ? 'tel:' + d : '';
}
function waLink(number) {
  let d = String(number === undefined || number === null ? '' : number).replace(/\D/g, '');
  if (!d) return '';
  if (d.indexOf('00') === 0) d = d.slice(2);
  if (d.charAt(0) === '0') d = '964' + d.slice(1);   // 07XXXXXXXXX → 9647XXXXXXXXX
  return d.length >= 11 ? 'https://wa.me/' + d : '';
}
/** رابط خريطة عادي (بلا أي Maps API أو مفتاح) يُفتح في تطبيق الخرائط على الهاتف */
function mapLink(lat, lng) {
  const blank = v => v === undefined || v === null || v === '';
  const a = Number(lat), b = Number(lng);
  if (blank(lat) || blank(lng) || !isFinite(a) || !isFinite(b)) return '';
  return 'https://www.google.com/maps?q=' + a + ',' + b;
}

/** عدد صحيح غير سالب من نص كتبه المستخدم، أو NaN إن لم يكن صالحًا.
    يقبل الأرقام العربية/الفارسية وفواصل الآلاف (, ، ٬ ومسافة أو نقطة بين مجموعات من 3 أرقام)،
    ويرفض ما يُقرأ خطأً بصمت مثل «1e3» أو «2020abc» أو «-5». */
function parseWholeNumber(v) {
  let s = String(v === undefined || v === null ? '' : v).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  s = s.replace(/[,،٬\s]/g, '');
  if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  return /^\d+$/.test(s) && Number(s) <= Number.MAX_SAFE_INTEGER ? parseInt(s, 10) : NaN;     // (الجزء 6.1) فوق أكبر عدد صحيح آمن ليس رقمًا صالحًا (لا 1e+40 ولا فقدان دقة)
}

/** رسالة عربية لخطأ مستودع (الـ Repositories لا تحتوي نصوص واجهة): تُستخدم في الخدمات */
function repoErrorText(code) {
  return ({ not_found: 'العنصر غير موجود.', invalid_data: 'البيانات غير صالحة.', duplicate_id: 'العنصر موجود مسبقًا.', protected_record: 'لا يمكن تنفيذ هذا الإجراء على هذا العنصر.' })[code]
    || 'تعذر تنفيذ العملية، حاول مرة أخرى.';
}

/* ---- (تدقيق ما قبل الباكند) مساعدات عرض/تحقق دفاعية ---- */
/** تاريخ إنشاء للعرض YYYY-MM-DD بتوقيت العراق (+03:00) من createdAt القانوني (UTC) أو القديم؛ غير الصالح/غير النصي ← '' (لا استثناء).
    كان العرض (createdAt || '').slice(0,10) ينهار لقيمة غير نصية، ويعرض تاريخ UTC (يوم سابق لما بعد منتصف الليل ببغداد). */
function createdDateText(v) {
  const ms = Timestamps.parseMs(v);
  return Number.isNaN(ms) ? '' : new Date(ms + Timestamps.IRAQ_OFFSET_MIN * 60000).toISOString().slice(0, 10);
}
/** نص بأحرف صغيرة للبحث الإداري؛ null/رقم/كائن ← نص آمن بلا استثناء */
function textLower(v) { return v === undefined || v === null ? '' : String(v).toLowerCase(); }
/** حدود أطوال النصوص المُدخَلة (بيانات التجربة أقل منها بكثير): تمنع نصًا بحجم ميغابايت يملأ التخزين ويُسقط كل الكتابات اللاحقة */
const TEXT_LIMITS = { brand: 50, model: 80, color: 40, transmission: 40, fuelType: 40, description: 2000, location: 200, name: 100, email: 254, password: 128 };
const TEXT_LABELS = { brand: 'الماركة', model: 'الموديل', color: 'اللون', transmission: 'ناقل الحركة', fuelType: 'نوع الوقود', description: 'الوصف', location: 'الموقع', name: 'الاسم', email: 'البريد الإلكتروني', password: 'كلمة المرور' };
/** أول حقل (من keys) يتجاوز حدّه ← رسالة عربية، وإلا null. الحقول الغائبة تُتجاهل */
function textLimitError(data, keys) {
  for (const k of keys) {
    const v = data && data[k];
    if (v === undefined || v === null) continue;
    if (String(v).length > TEXT_LIMITS[k]) return `حقل «${TEXT_LABELS[k]}» طويل جدًا (الحد الأقصى ${TEXT_LIMITS[k]} حرفًا).`;
  }
  return null;
}


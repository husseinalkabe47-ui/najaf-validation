/* ==========================================================================
   DATA SERVICE — قراءة البيانات للشاشات والخدمات عبر الـ Repositories (المرحلة 9).
   لا تلمس المصفوفات الخام ولا التخزين مباشرة. تحافظ على نفس القيم المُرجَعة القديمة
   (undefined عند الغياب) كي لا يتغير سلوك أي شاشة أو اختبار.
   ========================================================================== */

function getShowrooms() {
  return ShowroomsRepository.getAll();
}
function getShowroomById(id) {
  return ShowroomsRepository.getById(id) || undefined;
}
function getCars() {
  return CarsRepository.getAll();
}
function getCarById(id) {
  // يبحث في سيارات المعارض ثم سيارات الأعضاء (المرحلة 4) — كي تعمل المفضلة
  // والتفاصيل بنفس carId بغض النظر عن sourceType، دون تغيير سلوك getCars().
  return CarsRepository.getById(id) || MemberCarsRepository.getById(id) || undefined;
}
function getCarsByShowroom(showroomId) {
  return CarsRepository.getByShowroom(showroomId);
}
function getCarImages(carId) {
  return CarImagesRepository.getByCar(carId);
}

/* ملاحظة (المرحلة 3): دوال المستخدمين/الملّاك انتقلت إلى UserService (محمية بالصلاحيات)
   كي لا تصل سجلات المستخدمين الكاملة (وكلمات مرورهم) إلى الشاشات. */

/* ==========================================================================
   IMAGE SERVICE — ضغط الصور فعليًا قبل أي تخزين أو رفع
   التسلسل: Original (ذاكرة مؤقتة) → فحص الأبعاد → Resize (بلا تكبير) →
   Compress → WebP → نسخة مضغوطة نهائية → التخلص من النسخة الأصلية.
   الدالة compressImage لا تحفظ الملف الأصلي في أي مكان ولا تنشئ له رابطًا دائمًا
   (يُقرأ مباشرة عبر createImageBitmap؛ وفي المتصفحات القديمة يُنشأ رابط مؤقت
   يُلغى فور انتهاء التحميل).
   ========================================================================== */
const IMAGE_LIMITS = {
  MAX_SIDE: 1600,               // أطول ضلع بعد المعالجة
  QUALITY: 0.8,                 // الجودة المبدئية
  MIN_QUALITY: 0.6,             // أدنى جودة نُخفّض إليها محاولةً للاقتراب من الحجم المستهدف
  TARGET_MIN_BYTES: 150 * 1024, // الحجم المستهدف التقريبي (للتوثيق)
  TARGET_MAX_BYTES: 500 * 1024, // هدف وليس حدًّا صارمًا: لا تُرفض صورة بسبب الحجم
  USER_MAX_IMAGES: 4,           // سيارة عضو
  SHOWROOM_MAX_IMAGES: 5,       // سيارة معرض (الرئيسية محسوبة ضمن العدد)
};

/** أبعاد الهدف: نسبة الأبعاد محفوظة، ولا تكبير للصور الأصغر من الحد. */
function computeTargetSize(width, height, maxSide = IMAGE_LIMITS.MAX_SIDE) {
  const longest = Math.max(width, height);
  if (longest <= maxSide) return { width, height, resized: false };
  const scale = maxSide / longest;
  return { width: Math.max(1, Math.round(width * scale)), height: Math.max(1, Math.round(height * scale)), resized: true };
}

/* ---- Codec حقيقي يعتمد على واجهات المتصفح (Canvas + ImageBitmap) ---- */
const BrowserImageCodec = {
  /** يفك ترميز الملف الأصلي في الذاكرة فقط. close() يحرّر الذاكرة. */
  async decode(file) {
    if (typeof createImageBitmap === 'function') {
      const bmp = await createImageBitmap(file);
      return { width: bmp.width, height: bmp.height, source: bmp, close() { if (bmp.close) bmp.close(); } };
    }
    // متصفحات قديمة: رابط مؤقت يُلغى فور انتهاء التحميل
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
      return { width: img.naturalWidth, height: img.naturalHeight, source: img, close() { img.src = ''; } };
    } finally { URL.revokeObjectURL(url); }
  },
  /** يرسم بالأبعاد الجديدة ويُرمّز بالصيغة والجودة المطلوبتين. */
  async encode(decoded, width, height, mime, quality) {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (mime === 'image/jpeg') { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, width, height); } // JPEG لا يدعم الشفافية
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(decoded.source, 0, 0, width, height);
    try {
      return await new Promise((res, rej) => canvas.toBlob(b => b ? res(b) : rej(new Error('encode failed')), mime, quality));
    } finally { canvas.width = 0; canvas.height = 0; } // تحرير ذاكرة الـ canvas
  },
};

const ImageService = (function () {
  let _codec = BrowserImageCodec;
  /** للاختبارات فقط: استبدال الـ codec (المتصفح الحقيقي يستخدم BrowserImageCodec دائمًا). */
  function setCodec(c) { _codec = c || BrowserImageCodec; }

  /**
   * يضغط ملف صورة ويعيد { ok, blob, width, height, type, size, quality, resized } أو { ok:false, error }.
   * - WebP أولًا؛ إن لم يستطع المتصفح ترميز WebP (يُرجع صيغة أخرى) → JPEG.
   * - إن تجاوز الحجم الهدف (500KB) تُخفَّض الجودة تدريجيًا حتى MIN_QUALITY فقط، ثم تُقبل الصورة كما هي (لا رفض بسبب الحجم).
   */
  async function compressImage(file, opts = {}) {
    const o = { ...IMAGE_LIMITS, ...opts };
    if (!file || !/^image\//.test(String(file.type || ''))) return { ok: false, error: 'الملف المختار ليس صورة.' };

    let decoded;
    try { decoded = await _codec.decode(file); }
    catch (e) { return { ok: false, error: 'تعذر قراءة الصورة. جرّب صورة أخرى.' }; }

    try {
      const { width, height, resized } = computeTargetSize(decoded.width, decoded.height, o.MAX_SIDE);
      let quality = o.QUALITY;
      let blob = await _codec.encode(decoded, width, height, 'image/webp', quality);
      let format = blob.type;
      if (format !== 'image/webp') {                       // المتصفح لا يرمّز WebP
        blob = await _codec.encode(decoded, width, height, 'image/jpeg', quality);
        format = blob.type;
      }
      while (blob.size > o.TARGET_MAX_BYTES && quality - 0.05 >= o.MIN_QUALITY - 1e-9) {
        quality = Math.round((quality - 0.05) * 100) / 100;
        blob = await _codec.encode(decoded, width, height, format, quality);
      }
      return { ok: true, blob, width, height, type: format, size: blob.size, quality, resized };
    } catch (e) {
      return { ok: false, error: 'تعذر ضغط الصورة. جرّب صورة أخرى.' };
    } finally {
      if (decoded && decoded.close) decoded.close();        // التخلص من النسخة الأصلية المؤقتة
    }
  }

  return { compressImage, setCodec, computeTargetSize };
})();

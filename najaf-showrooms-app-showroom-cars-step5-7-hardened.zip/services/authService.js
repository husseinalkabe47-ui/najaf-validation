/* ==========================================================================
   AUTH SERVICE
   إنشاء الحساب وتسجيل الدخول والخروج. محلي حاليًا.
   تنبيه أمني مهم: هذا النظام المحلي للتجربة فقط — أي شيفرة تعمل داخل المتصفح
   يستطيع المستخدم نفسه تعديلها. الحماية الحقيقية للصلاحيات وكلمات المرور
   تتطلب Backend (تجزئة bcrypt/argon2 على الخادم + قواعد وصول على البيانات).
   عند الانتقال لـ API/Firebase/Supabase تُستبدل الدالتان register/login هنا فقط.
   ========================================================================== */
function _cyrb53(str, seed = 0) {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0, ch; i < str.length; i++) {
    ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
/** تجزئة تجريبية غير آمنة (للنموذج المحلي فقط) */
function hashPassword(pw) { return 'mock$' + _cyrb53('najaf-salt:' + pw).toString(16); }

const AuthService = (function () {
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const REGISTERABLE_ROLES = [ROLES.USER, ROLES.DEALER]; // لا يمكن إنشاء admin من التسجيل أبدًا

  function register({ name, phone, email, password, confirmPassword, accountType }) {
    name = String(name || '').trim();
    email = String(email || '').trim();
    const normPhone = normalizePhone(phone);
    password = String(password || '');

    const tooLong = textLimitError({ name, email, password }, ['name', 'email', 'password']);   // أطوال قصوى (تدقيق ما قبل الباكند)
    if (tooLong) return { ok: false, error: tooLong };
    if (name.length < 3) return { ok: false, error: 'الرجاء إدخال الاسم الكامل (3 أحرف على الأقل).' };
    if (!normPhone) return { ok: false, error: 'رقم الهاتف غير صحيح. مثال: 07701234567' };
    if (email && !EMAIL_RE.test(email)) return { ok: false, error: 'البريد الإلكتروني غير صحيح.' };
    if (password.length < 6) return { ok: false, error: 'كلمة المرور يجب ألا تقل عن 6 أحرف.' };
    if (password !== String(confirmPassword || '')) return { ok: false, error: 'تأكيد كلمة المرور غير مطابق.' };
    if (!REGISTERABLE_ROLES.includes(accountType)) return { ok: false, error: 'الرجاء اختيار نوع الحساب.' };
    if (UserService._isPhoneTaken(normPhone)) return { ok: false, error: 'رقم الهاتف مسجّل مسبقًا.' };
    if (UserService._isEmailTaken(email)) return { ok: false, error: 'البريد الإلكتروني مسجّل مسبقًا.' };

    // صاحب المعرض يبدأ pending حتى موافقة الإدارة (مرحلة لاحقة)
    const status = accountType === ROLES.DEALER ? USER_STATUS.PENDING : USER_STATUS.ACTIVE;
    const created = UserService._create({ name, phone: normPhone, email, role: accountType, status, passwordHash: hashPassword(password) });
    if (!created) return { ok: false, error: 'تعذر إنشاء الحساب، حاول مرة أخرى.' };
    SessionService.login(created.user.id);
    return { ok: true, user: UserService.toPublic(created.user), persisted: created.persisted };
  }

  function login(identifier, password) {
    const GENERIC = 'بيانات الدخول غير صحيحة.';
    if (!String(identifier || '').trim() || !password) return { ok: false, error: 'أدخل رقم الهاتف أو البريد وكلمة المرور.' };
    const user = UserService._findByIdentifier(identifier);
    if (!user || user.passwordHash !== hashPassword(String(password))) return { ok: false, error: GENERIC };
    if (user.status === USER_STATUS.SUSPENDED) return { ok: false, error: 'هذا الحساب موقوف. تواصل مع الإدارة.' };
    SessionService.login(user.id);
    return { ok: true, user: UserService.toPublic(user) };
  }

  function logout() { SessionService.logout(); }

  return { register, login, logout };
})();

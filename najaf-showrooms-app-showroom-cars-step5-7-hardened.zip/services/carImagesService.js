/* ==========================================================================
   CAR IMAGES SERVICE
   إدارة صور السيارة: الحد الأقصى، الصورة الرئيسية، الإضافة/الحذف، والمسودة
   (للصور المختارة قبل أن تُنشأ السيارة). كل صورة تمر عبر ImageService.compressImage
   قبل أي تخزين، ولا يُحفظ أي أثر للملف الأصلي. القيد يُفحص قبل الضغط وبعده،
   والصلاحية عبر AuthorizationService.canManageCarImages (وليس بإخفاء الأزرار).
   ========================================================================== */
const CarImagesService = (function () {
  const MSG_MAX = 'تم الوصول إلى الحد الأقصى للصور';
  const MSG_STORE_FAILED = 'تعذّر حفظ الصورة (مساحة التخزين ممتلئة أو غير متاحة).';

  function getMaxImagesForCar(car) {
    return car && car.sourceType === CAR_SOURCE.MEMBER ? IMAGE_LIMITS.USER_MAX_IMAGES : IMAGE_LIMITS.SHOWROOM_MAX_IMAGES;
  }
  function getImages(carId) { return getCarImages(carId); }

  /** استعادة سجلات الصور المحفوظة — في CarImagesRepository */
  function load() { CarImagesRepository.hydrate(); }

  /** الصورة الرئيسية للسيارة نفسها (mainImage) تتبع سجلات الصور — تُحدَّث عبر مستودع نوع السيارة */
  function _syncCarMainImage(car, url) {
    if (!car || car.mainImage === url) return;
    (car.sourceType === CAR_SOURCE.MEMBER ? MemberCarsRepository : CarsRepository).update(car.id, { mainImage: url });
  }

  /** يضمن: صورة رئيسية واحدة بالضبط (إن وُجدت صور)، وترقيم sortOrder متصل، ومزامنة car.mainImage */
  function _normalize(carId, mainId) {
    CarImagesRepository.applyLayout(carId, mainId);
    const main = getCarImages(carId).find(i => i.isMain);
    _syncCarMainImage(getCarById(carId), main ? main.imageUrl : '');
  }

  /** إضافة صورة **مضغوطة** لسيارة موجودة (داخلي: يُستدعى بعد ضغط ناجح فقط) */
  async function _addCompressed(car, compressed) {
    if (getCarImages(car.id).length >= getMaxImagesForCar(car)) return { ok: false, error: MSG_MAX };
    const id = CarImagesRepository.allocateId();
    const stored = await ImageStore.put(id, compressed.blob);        // النسخة المضغوطة فقط
    if (!stored.ok) return { ok: false, error: MSG_STORE_FAILED };   // لا سجل idb:<id> لصورة لم تُحفظ فعلًا
    const hasMain = getCarImages(car.id).some(i => i.isMain);
    const r = CarImagesRepository.create(CarImageModel({
      id, carId: car.id, imageUrl: 'idb:' + id,
      sortOrder: getCarImages(car.id).length, isMain: !hasMain
    }));
    if (!r.ok) { await ImageStore.remove(id); return { ok: false, error: repoErrorText(r.error) }; }
    _normalize(car.id);
    return { ok: true, image: r.item, persisted: r.persisted && stored.durable !== false };   // وضع الذاكرة: تنبيه «لن تُحفظ»
  }

  /** إضافة صورة من ملف: صلاحية ← حد ← ضغط ← تخزين المضغوط فقط */
  async function addCarImage(carId, file) {
    const car = getCarById(carId);
    if (!car) return { ok: false, error: 'السيارة غير موجودة.' };
    if (!AuthorizationService.canManageCarImages(car)) return { ok: false, error: 'لا تملك صلاحية تعديل صور هذه السيارة.' };
    if (getCarImages(car.id).length >= getMaxImagesForCar(car)) return { ok: false, error: MSG_MAX }; // قبل أي معالجة
    const c = await ImageService.compressImage(file);
    if (!c.ok) return c;
    return _addCompressed(car, c);
  }

  async function removeCarImage(imageId) {
    const img = CarImagesRepository.getById(imageId);
    if (!img) return { ok: false, error: 'الصورة غير موجودة.' };
    const car = getCarById(img.carId);
    if (!car || !AuthorizationService.canManageCarImages(car)) return { ok: false, error: 'لا تملك صلاحية تعديل صور هذه السيارة.' };
    const r = CarImagesRepository.remove(imageId);
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    if (img.imageUrl.indexOf('idb:') === 0) await ImageStore.remove(imageId);
    _normalize(car.id);   // إن كانت المحذوفة رئيسية تصبح أول صورة متبقية هي الرئيسية
    return { ok: true, persisted: r.persisted };
  }

  /** تعيين صورة رئيسية: لا نسخ ولا رفع مرة ثانية — فقط تبديل isMain */
  function setMainImage(imageId) {
    const img = CarImagesRepository.getById(imageId);
    if (!img) return { ok: false, error: 'الصورة غير موجودة.' };
    const car = getCarById(img.carId);
    if (!car || !AuthorizationService.canManageCarImages(car)) return { ok: false, error: 'لا تملك صلاحية تعديل صور هذه السيارة.' };
    _normalize(car.id, imageId);   // تبديل isMain فقط: لا نسخ ولا رفع مرة ثانية
    return { ok: true };
  }

  /** حذف كل صور سيارة (عند حذف السيارة نفسها) */
  async function removeAllCarImages(carId) {
    // (تدقيق ما قبل الباكند) كانت بلا فحص صلاحية بينما أخواتها تفحص: سيارة موجودة لا يديرها المستدعي ← لا حذف.
    // الاستدعاء المشروع يأتي بعد حذف السيارة نفسها (فلا توجد) أو من مالكها/المدير، فلا يتأثر مسار الحذف.
    const car = getCarById(carId);
    if (car && !AuthorizationService.canManageCarImages(car)) return;
    const removed = CarImagesRepository.removeByCar(carId);     // سجلات محذوفة ومحفوظة فورًا
    for (const i of removed) if (i.imageUrl.indexOf('idb:') === 0) await ImageStore.remove(i.id);
  }

  /* ---- مسودة صور (قبل إنشاء السيارة): صور مضغوطة في الذاكرة فقط ---- */
  function createImageDraft(max) {
    const items = [];
    const draft = {
      max, items,
      count: () => items.length,
      canAdd: () => items.length < max,
      async add(file) {
        if (items.length >= max) return { ok: false, error: MSG_MAX };   // قبل أي معالجة
        const c = await ImageService.compressImage(file);
        if (!c.ok) return c;
        let previewUrl = 'mem:' + items.length;
        try { if (typeof URL !== 'undefined' && URL.createObjectURL) previewUrl = URL.createObjectURL(c.blob); } catch (e) { /* تجاهل */ }
        items.push({ blob: c.blob, previewUrl, width: c.width, height: c.height, size: c.size, type: c.type, isMain: items.length === 0 });
        return { ok: true };
      },
      remove(index) {
        const [gone] = items.splice(index, 1);
        if (!gone) return { ok: false };
        try { if (gone.previewUrl.indexOf('blob:') === 0) URL.revokeObjectURL(gone.previewUrl); } catch (e) { /* تجاهل */ }
        if (gone.isMain && items.length) items[0].isMain = true;
        return { ok: true };
      },
      setMain(index) { if (!items[index]) return { ok: false }; items.forEach((it, i) => { it.isMain = (i === index); }); return { ok: true }; },
      clear() { while (items.length) draft.remove(0); },
    };
    return draft;
  }

  /** بعد إنشاء السيارة: تخزين صور المسودة المضغوطة (الصلاحية والحد يُفحصان هنا أيضًا) */
  async function commitImageDraft(carId, draft) {
    const car = getCarById(carId);
    if (!car || !draft || !draft.items.length) return { ok: true, added: 0 };
    if (!AuthorizationService.canManageCarImages(car)) return { ok: false, error: 'لا تملك صلاحية تعديل صور هذه السيارة.' };
    const order = draft.items.slice().sort((a, b) => (b.isMain ? 1 : 0) - (a.isMain ? 1 : 0)); // الرئيسية أولًا
    let added = 0, failed = 0, persisted = true;
    for (const it of order) {
      const r = await _addCompressed(car, { blob: it.blob });
      if (!r.ok) { failed = order.length - added; break; }
      added++; if (r.persisted === false) persisted = false;
    }
    draft.clear();
    return { ok: true, added, failed, persisted };
  }

  return { getMaxImagesForCar, getImages, load, addCarImage, removeCarImage, setMainImage,
           removeAllCarImages, createImageDraft, commitImageDraft, MSG_MAX };
})();

function getMaxImagesForCar(car) { return CarImagesService.getMaxImagesForCar(car); }
function addCarImage(carId, file) { return CarImagesService.addCarImage(carId, file); }
function removeCarImage(imageId) { return CarImagesService.removeCarImage(imageId); }
function setMainImage(imageId) { return CarImagesService.setMainImage(imageId); }
function removeAllCarImages(carId) { return CarImagesService.removeAllCarImages(carId); }
function createImageDraft(max) { return CarImagesService.createImageDraft(max); }
function commitImageDraft(carId, draft) { return CarImagesService.commitImageDraft(carId, draft); }
function loadCarImages() { CarImagesService.load(); }

/** الصورة الرئيسية لسيارة كرابط قابل للعرض، أو null (فيُعرض 🚘) */
function getMainImageSrc(car) {
  const imgs = getCarImages(car.id);
  const main = imgs.find(i => i.isMain) || imgs[0];
  return main ? resolveImageSrc(main.imageUrl) : null;
}

/* ==========================================================================
   MIGRATION SERVICE — هجرات مخطط التخزين (إصلاح المرحلة 9)
   najaf.schemaVersion = رقم إصدار المخطط (SchemaRepository). غيابه مع وجود بيانات = الصيغة الأصلية للمرحلة 9
   (الإصدار 1). كل تغيير مستقبلي في صيغة التخزين يُضاف كهجرة جديدة: StorageSchema.register(3, 'اسم', ctx => …)
   مع رفع CURRENT_VERSION. القواعد:
   - تُنفَّذ الهجرات بالترتيب مرة واحدة، بعد استعادة كل المستودعات مباشرة (app.js: hydrateRepositories ثم runStorageMigrations).
   - هجرة فاشلة لا تُسقط التطبيق: يبقى رقم الإصدار عند آخر هجرة نجحت، وتُعاد المحاولة في التحميل التالي.
   - تخزين بإصدار أحدث من التطبيق (مثلًا بعد الرجوع لنسخة أقدم) لا يُمَسّ ولا يُخفَّض رقمه.
   - كل هجرة idempotent، وتكتب فقط ما غيّرته (التثبيت الجديد لا يُكتب فيه سوى رقم الإصدار).
   - فشل استعادة أي مستودع يوقف الهجرات (حالة غير معروفة) ولا تُحذف بيانات يتيمة على أساسها.
   ========================================================================== */
const StorageSchema = (function () {
  const CURRENT_VERSION = 3;
  const _migrations = [];

  function register(to, name, fn) { _migrations.push({ to, name, fn }); _migrations.sort((a, b) => a.to - b.to); }

  function run(ctx) {
    const stored = SchemaRepository.getVersion();
    if (stored !== null && stored > CURRENT_VERSION) return { from: stored, to: stored, applied: [], skipped: 'newer_schema' };
    const from = stored === null ? 1 : stored;
    const legacy = stored === null && SchemaRepository.hasData();      // بيانات بالصيغة الأصلية (قبل الإصلاح)
    const report = { from, to: from, applied: [], failed: null, legacy };
    for (const m of _migrations) {
      if (m.to <= from || m.to > CURRENT_VERSION) continue;
      try { report.applied.push({ name: m.name, result: m.fn(Object.assign({ legacy }, ctx)) }); report.to = m.to; }
      catch (e) { report.failed = { name: m.name, message: String(e && e.message) }; console.error('[migration failed]', m.name, e); break; }
    }
    if (report.to !== stored && (report.to > from || stored === null)) SchemaRepository.setVersion(report.to);
    api.lastReport = report;                                            // للتدقيق والاختبارات (ما نُفِّذ وما حُذف)
    return report;
  }

  const api = { CURRENT_VERSION, register, run, lastReport: null };
  return api;
})();

/** تُستدعى من app.js بعد hydrateRepositories(): تشغّل الهجرات ثم فحص السلامة (StorageIntegrity) في كل تحميل.
    تُتخطّى كليًا إن فشل استعادة أي مستودع (حالة غير معروفة)، ولا يُمَسّ تخزين بإصدار أحدث من التطبيق،
    ويُتخطّى فحص السلامة إن فشلت هجرة (حالة جزئية). */
function runStorageMigrations(hydrateReport) {
  const failed = (hydrateReport && hydrateReport.failed) || [];
  if (failed.length) return { skipped: 'hydrate_failed', failed };
  try {
    const report = StorageSchema.run({ hydrateFailed: failed });
    if (report.skipped === 'newer_schema' || report.failed) return report;
    report.integrity = StorageIntegrity.run();
    report.integrity.duplicateFavoritesRemoved = StorageIntegrity.removeDuplicateFavorites();   // بعد الهجرات (لا قبل تنظيف الهجرة 2 للمفضلة اليتيمة/القديمة): يبقى الأقدم
    return report;
  }
  catch (e) { console.error('[migrations failed]', e); return { skipped: 'error' }; }
}

/* ---------------------------- فحص السلامة (يُشغَّل في كل تحميل، idempotent، بلا كتابة إن لم يجد شيئًا) ----------------------------
   الهدف: لا يلتصق مفضلة أو صورة بسيارة خاطئة أبدًا. عند أي غموض لا يمكن حسمه بدليل صريح يُحذف المرجع المبهم
   (مفضلة/صورة) بدل نسبه لسيارة أخرى؛ السيارات نفسها لا تُحذف. المُصدِر العام للمعرّفات لا يُمَسّ (IdAllocator.next فقط). */
const StorageIntegrity = (function () {
  const carById = id => CarsRepository.getById(id) || MemberCarsRepository.getById(id);

  /** حذف ملفات الصور المحذوفة من ImageStore (محاولة، بلا انتظار ولا أثر على النتيجة) */
  function _dropBlobs(images) {
    images.forEach(i => { if (String(i.imageUrl).indexOf('idb:') === 0 && typeof ImageStore !== 'undefined') Promise.resolve(ImageStore.remove(i.id)).catch(() => {}); });
  }

  /** لمن تنتمي صورة على معرّف متصادم؟ 'showroom' | 'member' | null (مبهمة). الدليل الوحيد المقبول:
      مسار الصورة التجريبية (assets/cars | assets/member-cars) أو تطابقها مع mainImage لسيارة واحدة فقط من السيارتين. */
  function attributeImage(img, showroomCar, memberCar) {
    const u = String(img.imageUrl || '');
    if (u.indexOf('assets/member-cars/') === 0) return 'member';
    if (u.indexOf('assets/cars/') === 0) return 'showroom';
    if (!u) return null;
    const s = u === showroomCar.mainImage, m = u === memberCar.mainImage;
    if (s && !m) return 'showroom';
    if (m && !s) return 'member';
    return null;
  }

  /** مسار تجريبي (assets/<kind>/<id>_<n>.<ext>) يناقض نوع السيارة المربوط بها أو معرّفها؟ (لا يمكن أن يخصّها) */
  function pathContradicts(img, car) {
    const m = /^assets\/(cars|member-cars)\/(\d+)_\d+\.[A-Za-z0-9]+$/.exec(String(img.imageUrl || ''));
    if (!m) return false;
    return !((m[1] === 'cars') === (car.sourceType === CAR_SOURCE.SHOWROOM) && Number(m[2]) === car.id);
  }

  /** تصادم قديم: سيارة معرض وسيارة عضو بنفس المعرّف. سيارة العضو تبقى بمعرّفها، وسيارة المعرض تأخذ معرّفًا جديدًا من
      المُصدِر العام. المفضلة على المعرّف المتصادم مبهمة بين سيارتين فتُحذف كلها. الصور: المحسوم بدليل فقط يبقى
      (ويتبع سيارته)، وكل صورة مبهمة تُحذف. mainImage الذي كان يشير إلى صورة حُذفت/انتقلت يُصحَّح (الصورة الرئيسية الباقية أو فارغ). */
  function resolveCarIdCollisions(out) {
    let n = 0;
    CarsRepository.getAll().filter(c => MemberCarsRepository.getById(c.id)).forEach(c => {
      const oldId = c.id, member = MemberCarsRepository.getById(oldId), newId = IdAllocator.next('car');
      if (!CarsRepository.reassignId(oldId, newId).ok) return;             // يبقى التصادم ويُعاد في التحميل التالي
      const moved = [], kept = [], doomed = [];
      CarImagesRepository.getAll().filter(i => i.carId === oldId).forEach(i => {
        const who = attributeImage(i, c, member);
        if (who === 'showroom') { i.carId = newId; moved.push(i); } else if (who === 'member') kept.push(i); else doomed.push(i);
      });
      const doomedIds = new Set(doomed.map(i => i.id));
      CarImagesRepository.removeWhere(i => doomedIds.has(i.id));
      _dropBlobs(doomed);
      const favs = FavoritesRepository.removeByCar(oldId);                  // مبهمة بين السيارتين: تُحذف كلها
      const gone = u => doomed.some(i => i.imageUrl === u);
      [[c, CarsRepository, newId, u => gone(u) || kept.some(i => i.imageUrl === u)],
       [member, MemberCarsRepository, oldId, u => gone(u) || moved.some(i => i.imageUrl === u)]].forEach(([car, repo, id, lost]) => {
        CarImagesRepository.applyLayout(id);
        if (car.mainImage && lost(car.mainImage)) {
          const main = CarImagesRepository.getByCar(id).find(i => i.isMain);
          repo.update(id, { mainImage: main ? main.imageUrl : '' });
        }
      });
      CarsRepository.save(); CarImagesRepository.save();
      out.ambiguousImagesRemoved.push(...doomed.map(i => i.id));
      out.collisionFavoritesRemoved += favs.length;
      n++;
    });
    out.collisions += n;
  }

  /** صور يناقض مسارها التجريبي نوع سيارتها أو معرّفها تُحذف (حتى بلا تصادم) */
  function purgeContradictoryImages(out) {
    const removed = CarImagesRepository.removeWhere(i => { const car = carById(i.carId); return !!car && pathContradicts(i, car); });
    _dropBlobs(removed);
    out.contradictoryImagesRemoved.push(...removed.map(i => i.id));
  }

  /** حالة «محجوز» (القيمة القديمة 'reserved') أُلغيت: السيارة المحجوزة لدى شخص لم تُشترَ بعد فهي متاحة للبيع.
      سيارة معرض reserved ← available، وسيارة عضو reserved ← active (المقابل الفعلي لـ«متاحة» في مفردات حالات الأعضاء، فلا
      تُخزَّن قيمة خارج مفرداتها). الحالة وحدها تتغيّر: لا حذف، ولا مساس بالمعرّف/المالك/المعرض/الصور/السعر/المسافة/الوصف،
      ولا updatedAt جديد (الطوابع كما هي). idempotent وبلا أي كتابة إن لم يوجد reserved، فلا إعادة كتابة في كل تحميل.
      هذا الملف هو المكان الوحيد في التطبيق الذي يسمّي القيمة القديمة (لتحويلها فقط). المقارنة تتسامح مع المسافات والحالة. */
  const LEGACY_RESERVED = 'reserved';
  const _isLegacyReserved = s => typeof s === 'string' && s.trim().toLowerCase() === LEGACY_RESERVED;
  function normalizeLegacyCarStatuses(out) {
    out.legacyStatusesMigrated = { showroom: 0, member: 0 };
    [[CarsRepository, SHOWROOM_CAR_STATUS.AVAILABLE, 'showroom'], [MemberCarsRepository, MEMBER_CAR_STATUS.ACTIVE, 'member']].forEach(([repo, to, key]) => {
      let n = 0;
      repo.getAll().forEach(c => { if (c && _isLegacyReserved(c.status)) { c.status = to; n++; } });
      if (n) repo.save();                        // كتابة واحدة لكل مجموعة، وفقط إن تغيّر شيء
      out.legacyStatusesMigrated[key] = n;
    });
  }

  /** (تدقيق ما قبل الباكند) مفضلة مكررة لنفس (مستخدم، سيارة): يبقى الأقدم (الأول في المخزن) ويُحذف الباقي. idempotent وبلا كتابة إن لم يوجد تكرار.
      لا نمرّر محمولًا ذا حالة إلى removeWhere (يستدعيه مرتين)؛ نحسب معرّفات المكررات أولًا. */
  function removeDuplicateFavorites() {
    const seen = new Set(), dup = new Set();
    FavoritesRepository.getAll().forEach(f => { if (!Number.isFinite(f.id)) return; const k = f.userId + ':' + f.carId; if (seen.has(k)) dup.add(f.id); else seen.add(k); });
    return dup.size ? FavoritesRepository.removeWhere(f => dup.has(f.id)).length : 0;
  }

  function run() {
    const out = { collisions: 0, collisionFavoritesRemoved: 0, ambiguousImagesRemoved: [], contradictoryImagesRemoved: [] };
    resolveCarIdCollisions(out);
    purgeContradictoryImages(out);
    normalizeLegacyCarStatuses(out);
    return out;
  }

  return { run, attributeImage, pathContradicts, normalizeLegacyCarStatuses, removeDuplicateFavorites, dropBlobs: _dropBlobs };
})();

/* ---------------------------- الهجرة 2: المعرّفات الموحَّدة وتنظيف البيانات ---------------------------- */
(function () {
  const carById = id => CarsRepository.getById(id) || MemberCarsRepository.getById(id);
  const repoOf = car => (CarsRepository.getById(car.id) === car ? CarsRepository : MemberCarsRepository);

  /** مفضلة يتيمة (سيارتها غير موجودة)، أو أقدم من سيارتها غير التجريبية (= كانت لسيارة سابقة أُعيد معرّفها)،
      أو على معرّف سيارة معرض سبق أن حمله إعلان عضو محذوف (سجل المحذوفات) ولا يثبت بتاريخ صالح أنها أحدث من السيارة. */
  function purgeInvalidFavorites() {
    const ledger = MemberCarsRepository.getDeletedIds();
    return FavoritesRepository.removeWhere(f => {
      const c = carById(f.carId);
      if (!c) return true;
      if (repoOf(c).isSeedRecord(c)) return false;            // تاريخ التجريبية ثابت: لا يُقارَن بساعة الجهاز
      const fa = Timestamps.parseMs(f.createdAt), ca = Timestamps.parseMs(c.createdAt);   // (ج7) المحلل الواحد: بلا منطقة = توقيت العراق، وغير الصالح NaN
      const provablyLater = Number.isFinite(fa) && Number.isFinite(ca) && fa >= ca;
      if (c.sourceType === CAR_SOURCE.SHOWROOM && ledger.includes(c.id)) return !provablyLater;   // المعرّف كان لإعلان محذوف: لا يبقى إلا ما يثبت أنه لهذه السيارة
      return Number.isFinite(fa) && Number.isFinite(ca) && fa < ca;
    }).length;
  }

  function purgeOrphanImages() {
    const removed = CarImagesRepository.removeOrphans(id => !!carById(id));
    StorageIntegrity.dropBlobs(removed);
    return removed.length;
  }

  /** كتابات الماركة/الموديل المختلفة بالحالة/المسافات/الرموز في السجلات غير التجريبية تُوحَّد على كتابة البيانات نفسها
      (CarFilters.canonicalBrand/Model بلقطة ثابتة قبل أي تعديل، فلا تتأثر النتيجة بترتيب المعالجة). التجريبية لا تُلمس. */
  function canonicalizeCarNames() {
    const pool = CarsRepository.getAll().concat(MemberCarsRepository.getAll()).map(x => ({ brand: x.brand, model: x.model }));
    let n = 0;
    [CarsRepository, MemberCarsRepository].forEach(repo => {
      let changed = false;
      repo.getAll().forEach(c => {
        if (repo.isSeedRecord(c)) return;
        const b = CarFilters.canonicalBrand(c.brand, pool), m = CarFilters.canonicalModel(c.model, c.brand, pool);
        let hit = false;
        if (b && b !== c.brand) { c.brand = b; hit = true; }
        if (m && m !== c.model) { c.model = m; hit = true; }
        if (hit) { n++; changed = true; }
      });
      if (changed) repo.save();
    });
    return n;
  }

  /** المسافة 0 في سجل قديم غير تجريبي كانت القيمة الافتراضية لـ«لم تُدخَل» → تصبح null (غير معروفة).
      لا يمكن التمييز عن «0 كم» مُدخلة صراحةً في البيانات القديمة؛ وبعد الإصلاح صار الفرق محفوظًا. */
  function unknownMileageFromLegacyZero() {
    let n = 0;
    [CarsRepository, MemberCarsRepository].forEach(repo => {
      let changed = false;
      repo.getAll().forEach(c => { if (!repo.isSeedRecord(c) && c.mileage === 0) { c.mileage = null; n++; changed = true; } });
      if (changed) repo.save();
    });
    return n;
  }

  /** تاجر فعّال بلا معرض (اعتُمد قبل الإصلاح) يحصل على معرضه (ensureDealerShowroom لا ينشئ ثانيًا لمن عنده معرض). */
  function ensureShowroomsForActiveDealers() {
    let n = 0;
    if (typeof ShowroomService === 'undefined') return 0;
    UsersRepository.getAll().filter(u => u.role === ROLES.DEALER && u.status === USER_STATUS.ACTIVE && !ShowroomsRepository.findOne(s => s.ownerId === u.id))
      .forEach(u => { const r = ShowroomService.ensureDealerShowroom(u.id); if (r.ok && r.created) n++; });
    return n;
  }

  StorageSchema.register(2, 'unified-ids-and-cleanup', ctx => {
    if (ctx.legacy) IdAllocator.persistFloors();                // تثبيت الأرضيات (وفيها مراجع يتيمة) قبل حذفها
    // 1) التصادم أولًا: يحذف المفضلة والصور المبهمة بدل نسبها لسيارة خاطئة (StorageIntegrity)، ثم 2) تنظيف اليتيم/القديم
    const integ = StorageIntegrity.run();
    const out = { collisions: integ.collisions, ambiguousImagesRemoved: integ.ambiguousImagesRemoved, contradictoryImagesRemoved: integ.contradictoryImagesRemoved };
    out.favoritesRemoved = integ.collisionFavoritesRemoved + purgeInvalidFavorites();
    out.imagesRemoved = (ctx.hydrateFailed && ctx.hydrateFailed.length) ? 'skipped' : purgeOrphanImages();
    out.renamed = canonicalizeCarNames();
    out.unknownMileage = unknownMileageFromLegacyZero();
    out.showroomsCreated = ensureShowroomsForActiveDealers();
    return out;
  });
})();

/* ---------------------------- الهجرة 3: createdAt بصيغة UTC القانونية (المرحلة 10 / الجزء 7) ----------------------------
   كل createdAt نصّي صالح يُطبَّع إلى YYYY-MM-DDTHH:mm:ss.sssZ بالمساعد الواحد Timestamps: بلا منطقة = توقيت العراق (+03:00)، وبـZ/إزاحة = لحظته الفعلية.
   غير الصالح (مفقود/null/فارغ/تالف/غير نصي) لا يُلمس إطلاقًا: لا تاريخ مخترع ولا مفتاح مضاف. لا يمسّ أي حقل آخر (معرّفات/أسعار/عملة/حالة/مالك/updatedAt).
   idempotent: الصيغة القانونية تعيد نفسها فلا تغيّر ولا كتابة؛ وتكتب كل مجموعة مرة واحدة وفقط إن تغيّر شيء فيها (تثبيت جديد/تخزين قانوني = لا كتابة سوى رقم الإصدار).
   فشل حفظ أي مجموعة يُفشل الهجرة (يبقى رقم الإصدار 2 وتُعاد المحاولة في التحميل التالي) بدل أن يتقدّم الإصدار والمخزَّن قديم. */
(function () {
  const COLLECTIONS = [['cars', () => CarsRepository], ['memberCars', () => MemberCarsRepository], ['showrooms', () => ShowroomsRepository],
                       ['users', () => UsersRepository], ['favorites', () => FavoritesRepository]];
  function normalizeCreatedAtAll() {
    const out = {};
    COLLECTIONS.forEach(([name, repoOf]) => {
      const repo = repoOf(); let n = 0;
      repo.getAll().forEach(r => {
        if (!r || typeof r.createdAt !== 'string') return;
        const v = Timestamps.normalize(r.createdAt);
        if (v !== r.createdAt) { r.createdAt = v; n++; }
      });
      if (n && !repo.save()) throw new Error('createdAt migration: save failed for ' + name);
      out[name] = n;
    });
    return out;
  }
  StorageSchema.register(3, 'utc-created-at', () => normalizeCreatedAtAll());
})();


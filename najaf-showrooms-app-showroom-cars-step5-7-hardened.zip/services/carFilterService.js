/* ==========================================================================
   CAR FILTERS — محرك الفلترة الواحد للسيارات (إصلاح المرحلة 9)
   كل تصفية للسيارات في التطبيق تمرّ من هنا حصرًا: شاشة السيارات، سيارات الأعضاء، البحث (searchCars)،
   البحث الموحّد، وfilterCars/filterMemberCars. الواجهة (components/filters.js) تعرض فقط.

   القواعد:
   - الماركة/الموديل ديناميكيان من بيانات السيارات نفسها (لا قوائم ثابتة). سنة جديدة/ماركة جديدة تظهر تلقائيًا.
   - توحيد الكتابة: Toyota = toyota = TOYOTA = « Toyota » = ＴＯＹＯＴＡ (مفتاح مقارنة مُطبَّع: NFKC، حروف صغيرة،
     بلا ترقيم/مسافات/رموز غير مرئية). لا قاموس ماركات مُشفَّر: الكتابة المخزَّنة تتبع ما في بيانات التطبيق نفسها
     (ماركة موجودة → تُعتمد كتابتها)، وأي ماركة جديدة/غير معروفة تبقى صالحة وتُوحَّد بحالة أحرف آمنة.
     الاسم العربي يُحفظ كما أُدخل، ويُجمَّع مع مقابله اللاتيني فقط إن كان في قاموس البحث القائم (_SEARCH_ALIASES)
     فتظهر التسمية «Toyota / تويوتا». الفلتر نفسه لا يعتمد على الكتابة المخزَّنة أصلًا (يجمّع بالمفتاح).
   - الموديل مرتبط بالماركة (لا موديلات Toyota عند اختيار BMW).
   - السعر والمسافة: من–إلى بلا أي سقف مصطنع. الحدّ شامل. أرقام عربية وفواصل مقبولة (parseWholeNumber).
   - المسافة المجهولة (null/فارغة) ≠ 0: لا تدخل أبدًا في أي فلتر مسافة. 0 المُدخلة صراحةً قيمة حقيقية.
   - قيمة فلتر غير صالحة (نص غير رقمي) تُتجاهل مع رسالة، ولا تُفلتر بصمت. min > max ← لا نتائج + رسالة.
   - (المرحلة 10 / الجزء 5) «المجهول» لا يمرّ كرقم أبدًا: سعر ≤ 0 أو غير رقمي (null/نص/true/مصفوفة/NaN)، مسافة سالبة أو غير رقمية،
     وسنة خارج 1900–2100 أو غير صالحة ← مجهول؛ يُستبعد من أي فلتر يخصّه (ويظهر بلا فلتر)، ولا يظهر «0»/«1»/«99999» في خيارات السنة.
     التحقق في دوال formatService الموحّدة (validPrice/validMileage/validYear) — لا نسخة ثانية هنا.
     المدخلات الرقمية تُطبَّع NFKC (أرقام عريضة/عربية/فارسية) وتُنظَّف من الرموز غير المرئية قبل التحويل.
   - (المرحلة 10 / الجزء 5.2) عملة السعر: فلتر السعر له «عملة بحث» (priceCurrency: IQD | USD؛ فارغة = الدينار) تُفسَّر بها حدّا من–إلى.
     سيارة بعملتها نفسها تُقارَن مباشرة، وسيارة بالعملة الأخرى تُحوَّل داخليًا للمقارنة فقط (convertCurrency في models.js بسعر الصرف المركزي
     الوحيد، بلا تقريب) — فلا تختفي سيارة لأن عملتها مختلفة. السعر والعملة المخزَّنان لا يُمسّان أبدًا. سجل بلا حقل currency = دينار (قديم)،
     وعملة مخزَّنة غير مدعومة = سعر مجهول (يُستبعد من فلتر السعر ولا يمرّ كصفر).
   ========================================================================== */
const CarFilters = (function () {
  const ARABIC = /[\u0600-\u06FF]/;

  /** رموز غير مرئية تُنتجها اللصقات من تطبيقات أخرى (صفر العرض، اتجاه النص، BOM…) — لا تصنع «ماركة» مختلفة */
  const INVISIBLE = /[\u200B-\u200F\u202A-\u202E\u2060-\u2064\u2066-\u2069\uFEFF]/g;

  /** مفتاح المقارنة: NFKC (الحروف العريضة…)، حروف صغيرة، همزات/تشكيل موحّدة، ترقيم ومسافات ورموز غير مرئية محذوفة،
      ومقابل لاتيني للاسم العربي الموجود في قاموس البحث القائم فقط. مفتاح فارغ = لا حرف ولا رقم (غير صالح كاسم). */
  /** نص قابل للمقارنة: نص أو رقم منتهٍ فقط؛ كائن/دالة/NaN/null ← '' (فلا يصبح «[object Object]» خيار فلتر) */
  const _str = v => ((typeof v === 'string') || (typeof v === 'number' && isFinite(v))) ? String(v) : '';
  function key(text) {
    const n = _normalizeSearch(_str(text).normalize('NFKC').replace(INVISIBLE, ''));
    return String(_SEARCH_ALIASES[n] || n).replace(/\s+/g, '');
  }

  function _clean(text) {
    return _str(text).normalize('NFKC').replace(INVISIBLE, '').replace(/\s+/g, ' ').trim();
  }

  /** حالة الأحرف الآمنة للاسم اللاتيني: corolla → Corolla، TOYOTA → Toyota، BMW/X5/GLE تبقى (اختصار قصير أو فيه رقم)،
      والمختلط (iPhone/McLaren) كما أُدخل. العربي كما هو. */
  function _smartCase(text, shortCapsLimit) {
    return _clean(text).split(' ').map(tok => {
      if (ARABIC.test(tok)) return tok;
      return tok.split('-').map(part => {
        if (!part) return part;
        const hasDigit = /\d/.test(part), letters = part.replace(/[^A-Za-z]/g, '');
        if (part === part.toLowerCase()) return part.charAt(0).toUpperCase() + part.slice(1);              // كله صغير
        if (part === part.toUpperCase()) return (hasDigit || letters.length <= shortCapsLimit) ? part         // اختصار/رمز (BMW, X5, RAV4)
          : part.charAt(0) + part.slice(1).toLowerCase();                                                   // TOYOTA → Toyota
        return part;                                                                                         // مختلط الحالة: كما أُدخل
      }).join('-');
    }).join(' ');
  }

  /** الكتابة المفضّلة بين متغيّرات موجودة (counts: كتابة → تكرار): الأكثر تكرارًا بين «السليمة» (المستقرة تحت _smartCase)،
      وإن لم توجد سليمة فحالة آمنة للأكثر تكرارًا. حتمي (تعادل → ترتيب أبجدي). */
  function _preferred(counts, limit) {
    const vs = Object.keys(counts).sort((a, b) => counts[b] - counts[a] || a.localeCompare(b));
    const good = vs.filter(v => v === _smartCase(v, limit));
    return good.length ? good[0] : _smartCase(vs[0], limit);
  }

  function _allCars() { return getCars().concat(MemberCarsRepository.getAll()); }   // (تحصين الإدارة/الأمان ج2) مصدر البيانات فقط: التوحيد (canonicalBrand/Model) يحتاج كل الكتابات الموجودة بصرف النظر عن المشاهد، وgetMemberCars() صار يتبع صلاحية المستدعي؛ لا يُعاد أي سجل للمستدعي من هنا (أسماء فقط)

  /** يعتمد كتابة موجودة في البيانات لنفس المفتاح (حقل brand أو model؛ scopeKey يقيّد الموديل بماركته) وإلا حالة آمنة.
      pool اختياري (لقطة للهجرة كي لا تتأثر النتيجة بترتيب المعالجة). فارغ ← '' (لا اسم). العربي كما أُدخل. */
  function _adopt(text, field, pool, scopeKey, limit) {
    const c = _clean(text); if (!c) return '';
    if (ARABIC.test(c)) return c;
    const k = key(c); if (!k) return '';
    const counts = {};
    (pool || _allCars()).forEach(x => {
      if (scopeKey && key(x.brand) !== scopeKey) return;
      const v = _clean(x[field]);
      if (!v || ARABIC.test(v) || key(v) !== k) return;
      counts[v] = (counts[v] || 0) + 1;
    });
    return Object.keys(counts).length ? _preferred(counts, limit) : _smartCase(c, limit);
  }
  /** الاسم الموحَّد للماركة (الأكثر ثباتًا في البيانات إن وُجدت، وإلا حالة آمنة). '' إن لم يحوِ حرفًا/رقمًا. */
  function canonicalBrand(text, pool) { return _adopt(text, 'brand', pool, '', 4); }
  /** الاسم الموحَّد للموديل داخل ماركته فقط (لا تتداخل كتابات ماركتين). */
  function canonicalModel(text, brandText, pool) { return _adopt(text, 'model', pool, brandText ? key(brandText) : '', 3); }

  /* ---------------- المعايير ---------------- */
  const _blank = v => v === null || v === undefined || String(v).trim() === '';
  /** عدد صحيح من مدخل المستخدم: null إن كان فارغًا، NaN إن كان غير صالح */
  function _int(v) {
    if (_blank(v)) return null;
    if (typeof v !== 'string' && typeof v !== 'number') return NaN;           // كائن/مصفوفة/منطقي ليست رقمًا مُدخلًا
    return parseWholeNumber(String(v).normalize('NFKC').replace(INVISIBLE, ''));
  }

  /** عملة البحث: رمز مدعوم (يُتسامح مع الحالة والمسافات) أو '' (غير محدّدة = الدينار). قيمة غير صالحة تُهمَل ولا تُخفي شيئًا. */
  function _currency(v) { const p = parseCurrency(v); return p.ok ? p.value : ''; }
  /** العملة الفعلية لتفسير حدّي السعر */
  const _target = c => c.priceCurrency || CURRENCY_LEGACY_DEFAULT;
  /** سعر السيارة مقيسًا بعملة البحث للمقارنة فقط (بلا تقريب)، أو null إن كان السعر أو عملته مجهولة (أو لا سعر صرف صالح للتحويل). لا يعدّل السيارة. */
  function comparablePrice(car, target) {
    const p = validPrice(car && car.price), cur = carCurrency(car);
    return (p === null || cur === null) ? null : convertCurrency(p, cur, target);
  }

  /** يطبّع معايير خام (نصوص من الواجهة أو أرقام) إلى الشكل الداخلي. الحقل غير الصالح يصبح null ويُسجَّل في invalid. */
  function normalize(raw) {
    const r = raw || {}, invalid = [];
    const n = f => { const v = _int(r[f]); if (v !== null && Number.isNaN(v)) { invalid.push(f); return null; } return v; };
    const brand = _clean(r.brand), model = _clean(r.model);
    return {
      brand, brandKey: brand ? key(brand) : '', model, modelKey: model ? key(model) : '',
      year: n('year'), minPrice: n('minPrice'), maxPrice: n('maxPrice'), priceCurrency: _currency(r.priceCurrency), minMileage: n('minMileage'), maxMileage: n('maxMileage'),
      status: r.status || '', showroomId: r.showroomId === undefined ? null : r.showroomId,
      transmission: r.transmission || '', fuelType: r.fuelType || '', location: _clean(r.location), invalid,
    };
  }

  /** عدد الفلاتر الفعّالة (القيمة 0 فعّالة؛ الحقل غير الصالح ليس فعّالًا) */
  function activeCount(raw) {
    const c = normalize(raw);
    return [c.brand, c.model].filter(Boolean).length + ['year', 'minPrice', 'maxPrice', 'minMileage', 'maxMileage'].filter(f => c[f] !== null).length;
  }

  /** رسائل تحقق عربية: أرقام غير صالحة، ونطاق مقلوب */
  function validate(raw) {
    const c = normalize(raw), out = [];
    const L = { year: 'السنة', minPrice: 'السعر (من)', maxPrice: 'السعر (إلى)', minMileage: 'الكيلومترات (من)', maxMileage: 'الكيلومترات (إلى)' };
    c.invalid.forEach(f => out.push(`أدخل رقمًا صحيحًا في حقل ${L[f]}.`));
    if (c.minPrice !== null && c.maxPrice !== null && c.minPrice > c.maxPrice) out.push('الحد الأدنى للسعر أكبر من الحد الأعلى.');
    if (c.minMileage !== null && c.maxMileage !== null && c.minMileage > c.maxMileage) out.push('الحد الأدنى للكيلومترات أكبر من الحد الأعلى.');
    return out;
  }

  /* ---------------- المحرك ---------------- */
  function matches(car, c) {
    if (c.brandKey && key(car.brand) !== c.brandKey) return false;
    if (c.modelKey && key(car.model) !== c.modelKey) return false;
    if (c.year !== null) { const y = validYear(car.year); if (y === null || y !== c.year) return false; }   // سنة غير صالحة لا تطابق أي سنة (ولا 0)
    if (c.minPrice !== null || c.maxPrice !== null) {
      const p = comparablePrice(car, _target(c));            // بعملة البحث (تحويل داخلي للمقارنة فقط؛ سعر السيارة وعملتها لا يتغيران)
      if (p === null) return false;                          // سعر مجهول/عملة مجهولة/غير صالح لا يمرّ كصفر ولا كأي رقم
      if (c.minPrice !== null && p < c.minPrice) return false;
      if (c.maxPrice !== null && p > c.maxPrice) return false;
    }
    if (c.minMileage !== null || c.maxMileage !== null) {
      const m = validMileage(car.mileage);
      if (m === null) return false;                          // المجهولة (أو السالبة) لا تدخل أبدًا (ليست 0)؛ و0 الحقيقي صالح
      if (c.minMileage !== null && m < c.minMileage) return false;
      if (c.maxMileage !== null && m > c.maxMileage) return false;
    }
    if (c.status && car.status !== c.status) return false;
    if (c.showroomId !== null && car.showroomId !== c.showroomId) return false;
    if (c.transmission && car.transmission !== c.transmission) return false;
    if (c.fuelType && car.fuelType !== c.fuelType) return false;
    if (c.location && !String(car.location || '').includes(c.location)) return false;
    return true;
  }

  /** يصفّي قائمة سيارات بالمعايير (الخام أو المطبَّعة). بلا معايير فعّالة تعيد القائمة نفسها. */
  function apply(list, raw) {
    const c = normalize(raw);
    const inverted = (c.minPrice !== null && c.maxPrice !== null && c.minPrice > c.maxPrice) || (c.minMileage !== null && c.maxMileage !== null && c.minMileage > c.maxMileage);
    if (inverted) return [];
    return (list || []).filter(car => matches(car, c));
  }

  /* ---------------- الخيارات الديناميكية ---------------- */
  /** يجمّع قيمًا نصية في مجموعات بالمفتاح (فروق الحالة/الشرطة/الهمزة لا تنتج مجموعتين).
      value = الكتابة اللاتينية المفضّلة (أو العربية إن لم توجد). label: «اللاتيني / العربي» إن وُجد الاثنان. */
  function _groups(values, limit) {
    const by = {};
    values.forEach(v => {
      const k = key(v); if (!k) return;
      const c = _clean(v), g = by[k] = by[k] || { key: k, latin: {}, arabic: {}, count: 0 }, side = ARABIC.test(c) ? g.arabic : g.latin;
      side[c] = (side[c] || 0) + 1; g.count++;
    });
    return Object.values(by).map(g => {
      const latin = Object.keys(g.latin).length ? _preferred(g.latin, limit) : '';
      const arabic = Object.keys(g.arabic).sort((a, b) => g.arabic[b] - g.arabic[a] || a.localeCompare(b))[0] || '';
      const value = latin || arabic;
      return { key: g.key, value, label: latin && arabic ? `${latin} / ${arabic}` : value, count: g.count };
    }).sort((a, b) => a.value.localeCompare(b.value, 'en', { sensitivity: 'base' }));
  }

  /** خيارات الفلاتر من قائمة سيارات فعلية. models لا تُملأ إلا مع ماركة محدّدة (الموديل مرتبط بالماركة). */
  function options(list, raw) {
    const cars = list || [], c = normalize(raw);
    const brands = _groups(cars.map(x => x.brand), 4);
    const inBrand = c.brandKey ? cars.filter(x => key(x.brand) === c.brandKey) : [];
    const models = c.brandKey ? _groups(inBrand.map(x => x.model), 3) : [];
    const years = [...new Set(cars.map(x => validYear(x.year)).filter(y => y !== null))].sort((a, b) => b - a);     // سنوات صالحة فقط، تنازليًا
    const prices = cars.map(x => comparablePrice(x, _target(c))).filter(p => p !== null), miles = cars.map(x => validMileage(x.mileage)).filter(m => m !== null);
    const rng = a => (a.length ? { min: Math.min(...a), max: Math.max(...a) } : null);
    return { brands, models, years, priceRange: rng(prices), mileageRange: rng(miles),
      unknownPrice: cars.length - prices.length, unknownMileage: cars.length - miles.length };
  }

  /** موديل محدَّد لا ينتمي للماركة الحالية (أو لا ماركة) يُسقَط. باقي القيم تُترك كما هي (حتى لو غير موجودة في البيانات). */
  function reconcileModel(raw, pool) {
    const c = normalize(raw);
    if (!c.modelKey) return raw;
    const ok = options(pool, { brand: c.brand }).models.some(m => key(m.value) === c.modelKey);
    return ok ? raw : Object.assign({}, raw, { model: '' });
  }

  /** نصوص الشارات للفلاتر الفعّالة (غير مهرَّبة: تهريبها مسؤولية الواجهة) */
  function describe(raw) {
    const c = normalize(raw), fmt = n => Number(n).toLocaleString('ar-IQ'), out = [];
    if (c.brand) out.push(`الماركة: ${c.brand}`);
    if (c.model) out.push(`الموديل: ${c.model}`);
    if (c.year !== null) out.push(`السنة: ${c.year}`);
    const cu = c.priceCurrency ? ` ${CURRENCY_SHORT[c.priceCurrency]}` : '';
    if (c.minPrice !== null) out.push(`السعر من ${fmt(c.minPrice)}${cu}`);
    if (c.maxPrice !== null) out.push(`السعر حتى ${fmt(c.maxPrice)}${cu}`);
    if (c.minMileage !== null) out.push(`المسافة من ${fmt(c.minMileage)} كم`);
    if (c.maxMileage !== null) out.push(`المسافة حتى ${fmt(c.maxMileage)} كم`);
    return out;
  }

  /** شارات الفلاتر الفعّالة، شارة لكل فلتر (السعر والمسافة شارة واحدة لكل نطاق): [{ key, field, label }].
      key = معرّف الإزالة (brand | model | year | price | mileage)، field = اسم الحقل العربي (للوصول)، label = نص موجز غير مهرَّب. */
  function chips(raw) {
    const c = normalize(raw), out = [], fmt = n => Number(n).toLocaleString('ar-IQ'), isM = n => n > 0 && n % 1000000 === 0;
    const money = n => (isM(n) ? `${fmt(n / 1000000)} مليون` : `${fmt(n)} د.ع`);
    if (c.brand) out.push({ key: 'brand', field: 'الماركة', label: c.brand });
    if (c.model) out.push({ key: 'model', field: 'الموديل', label: c.model });
    if (c.year !== null) out.push({ key: 'year', field: 'السنة', label: String(c.year) });
    if (c.minPrice !== null || c.maxPrice !== null) out.push({ key: 'price', field: 'السعر', label: _priceChip(c.minPrice, c.maxPrice, c.priceCurrency, fmt, isM, money) });
    if (c.minMileage !== null || c.maxMileage !== null) {
      const a = c.minMileage, b = c.maxMileage;
      out.push({ key: 'mileage', field: 'المسافة', label: (a !== null && b !== null) ? `${fmt(a)}–${fmt(b)} كم` : (a !== null ? `من ${fmt(a)} كم` : `حتى ${fmt(b)} كم`) });
    }
    return out;
  }
  /** نص شارة السعر. عملة البحث المحدّدة صراحةً تظهر في الشارة: «٢٥–٤٠ مليون د.ع» / «$٢٠٬٠٠٠–$٣٠٬٠٠٠». معايير بلا عملة (استدعاء برمجي قديم) تبقى بصيغتها السابقة. */
  function _priceChip(a, b, cur, fmt, isM, money) {
    if (cur === CURRENCY.USD) {
      const u = n => formatAmount(n, CURRENCY.USD);
      return (a !== null && b !== null) ? `\u2066${u(a)}–${u(b)}\u2069` : (a !== null ? `من ${u(a)}` : `حتى ${u(b)}`);
    }
    const suffix = cur === CURRENCY.IQD ? ' د.ع' : '';          // IQD صريحة: «مليون د.ع»؛ الأرقام الكاملة تحمل «د.ع» أصلًا
    if (a !== null && b !== null) return (isM(a) && isM(b)) ? `${fmt(a / 1000000)}–${fmt(b / 1000000)} مليون${suffix}` : `${fmt(a)}–${fmt(b)} د.ع`;
    const one = n => (isM(n) ? `${money(n)}${suffix}` : money(n));
    return a !== null ? `من ${one(a)}` : `حتى ${one(b)}`;
  }

  /** نسخة من المعايير الخام بعد إزالة فلتر واحد (الماركة تزيل معها الموديل لأنه تابع لها؛ السعر والمسافة يزيلان حدّيهما). مفتاح غير معروف ← نسخة بلا تغيير. */
  const _CLEARS = { brand: ['brand', 'model'], model: ['model'], year: ['year'], price: ['minPrice', 'maxPrice', 'priceCurrency'], mileage: ['minMileage', 'maxMileage'] };
  function without(raw, key) {
    const f = Object.assign({}, raw && typeof raw === 'object' ? raw : {});
    if (typeof key === 'string' && Object.prototype.hasOwnProperty.call(_CLEARS, key)) _CLEARS[key].forEach(k => { if (k !== 'priceCurrency' || k in f) f[k] = ''; });
    return f;
  }

  function sameKey(a, b) { return !_blank(a) && !_blank(b) && key(a) === key(b); }

  return { key, canonicalBrand, canonicalModel, normalize, activeCount, validate, apply, matches, options, reconcileModel, describe, chips, without, sameKey };
})();

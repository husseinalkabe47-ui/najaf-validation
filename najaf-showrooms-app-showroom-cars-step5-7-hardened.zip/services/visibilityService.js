/* ==========================================================================
   VISIBILITY SERVICE — المسار العام الواحد لما يراه الناس من معارض وسيارات (إصلاح C7 + المرحلة 10 / الجزء 1)
   كل شاشة أو خدمة تعرض معارض/سيارات للعامة تجلبها من هنا فقط؛ والجالبات الخام في dataService
   (getCars/getShowrooms/getCarById/getMemberCarById/getActiveMemberCars…) للإدارة والتاجر والصلاحيات وحدها.
   لا تُكرَّر قاعدة الظهور في أي شاشة.

   قواعد الظهور (واحدة لكل المسارات):
   • معرض (سياسة «الظهور العام للمعارض» — تشديد): ظاهر للعامة **فقط** إن كانت حالة المعرض 'active' (بعد توحيد النص: NFKC + إزالة المسافات
     + أحرف صغيرة، فتتحمّل البيانات القديمة ' ACTIVE ' / 'Active') **وكان حساب مالكه 'active'**. أي حالة أخرى = مخفي عن العامة:
     pending / suspended / (مرفوض/معطّل/غير فعّال أو أي قيمة غريبة أو غير نصية: إغلاق عند الفشل). لا مفردات جديدة ولا حالة «عام».
     الاستثناء الوحيد هو التفويض القائم (لا الظهور): المدير يرى كل المعارض دائمًا، وصاحبها التاجر الفعّال يرى معرضه غير العام (canManageShowroom).
     وبما أن سيارات المعرض تتبع معرضها تمامًا فتختفي سياراته عن العامة بالقاعدة نفسها، وتظهر للمدير والمالك.
     (قبل: كانت تُخفى فقط status==='suspended' بمقارنة حرفية أو حساب مالك غير فعّال، فكانت pending وأي حالة غريبة ظاهرة.)
     حساب مالك معرض غير موجود في المستخدمين = لا حساب يُعلَّق (القاعدة حسب حالة المعرض وحدها). معرض غير موجود = لا شيء (missing).
   • سيارة معرض: تتبع معرضها تمامًا؛ معرضها غير موجود ← مخفية للجميع (لا يمكن التحقق منها).
   • سيارة عضو (المرحلة 10 / الجزء 2): تظهر للعامة فقط إن كان الإعلان 'active' **وحساب مالكه 'active'**. حساب مالك غير فعّال
     (suspended/مرفوض/pending/disabled/أي حالة أخرى) ← كل إعلاناته الشخصية مخفية عن العامة (قوائم، بحث، رئيسية، مفضلة،
     تفاصيل) دون حذف شيء، وتعود بإعادة تفعيل الحساب حسب حالة كل إعلان. حالة الإعلان نفسها بلا تغيير (pending/sold/rejected/suspended
     مخفية دائمًا). التفاصيل: للعامة كما سبق، ولمالك الإعلان أو المدير (canManageMemberCar، وفق قواعد الصلاحيات القائمة) حتى لو
     كان مخفيًا. القوائم العامة لا تتبع المشاهد (الإدارة والمالك يديران من شاشاتهما: إعلاناتي/إدارة سيارات الأعضاء).
     مالك غير موجود في المستخدمين = لا حساب يُعلَّق فالقاعدة حسب حالة الإعلان وحدها (كما في المعارض).
   • نوع مصدر غير معروف ← مخفي. الكائن الممرَّر لا يُصدَّق: يُعاد جلب السجل المخزَّن بمعرّفه، فلا يرفع كائن مزوَّر الصلاحية.
   كل الدوال تعيد نتيجة آمنة (undefined / [] / 'missing') لأي مدخل غير صالح ولا ترمي استثناءً.
   user (اختياري): المشاهد؛ غيابه = المستخدم الحالي في الجلسة.
   ========================================================================== */
const VisibilityService = (function () {
  const _isId = v => typeof v === 'number' && Number.isFinite(v);
  /** السجل المخزَّن بمعرّفه فقط (معرّف رقمي صالح، وإلا null) — دوال «ById/Access» لا تقبل كائنات */
  function _showroomById(id) { return _isId(id) ? (getShowroomById(id) || null) : null; }
  function _carById(id) { return _isId(id) ? (getCarById(id) || null) : null; }
  /** canViewShowroom/canViewCar فقط تقبل سجلًا أو معرّفًا: السجل يُعاد جلبه بمعرّفه (لا يُصدَّق ما فيه من حقول) */
  const _idOf = x => ((x && typeof x === 'object') ? x.id : x);
  function _showroomRecord(x) { return _showroomById(_idOf(x)); }
  function _carRecord(x) { return _carById(_idOf(x)); }

  /** حساب المالك (مالك معرض أو صاحب إعلان عضو) موجود وغير فعّال؟ — قاعدة واحدة للنوعين. غير موجود = لا حساب يُعلَّق. */
  function _accountBlocked(userId) {
    const owner = UsersRepository.getById(userId);
    return !!owner && owner.status !== USER_STATUS.ACTIVE;
  }
  /** إعلان عضو مسموح للعامة: الإعلان active وحساب مالكه ليس غير فعّال */
  function _memberPublic(c) { return c.sourceType === CAR_SOURCE.MEMBER && c.status === MEMBER_CAR_STATUS.ACTIVE && !_accountBlocked(c.ownerId); }
  /** حالة المعرض بصيغتها المعتمدة: NFKC + trim + أحرف صغيرة (غير النص ← ''، فلا يطابق 'active' أبدًا). لا تُستعمل لحالة حساب الأعضاء (قاعدتها صارمة كما هي). */
  const _normStatus = v => (typeof v === 'string' ? v.normalize('NFKC').trim().toLowerCase() : '');
  /** المعرض عام: حالته active (موحّدة) وحساب مالكه فعّال. المعرفات الوحيدة هنا؛ لا قاعدة ظهور في أي شاشة. */
  function _showroomPublic(s) { return _normStatus(s.status) === 'active' && !_accountBlocked(s.ownerId); }
  /** s سجل معرض مخزَّن. غير العام يراه فقط من يملك تفويض إدارته (المدير، أو صاحبه التاجر الفعّال): التفويض ≠ الظهور العام */
  function _showroomVisible(s, user) {
    if (_showroomPublic(s)) return true;
    return AuthorizationService.canManageShowroom(s.id, user);
  }
  /** c سجل سيارة مخزَّن (معرض أو عضو) */
  function _carVisible(c, user) {
    if (c.sourceType === CAR_SOURCE.MEMBER) return _memberPublic(c) || AuthorizationService.canManageMemberCar(user, c);
    if (c.sourceType === CAR_SOURCE.SHOWROOM) { const s = _showroomById(c.showroomId); return !!s && _showroomVisible(s, user); }
    return false;
  }
  const _ok = (key, rec) => ({ status: 'ok', [key]: rec }), _hidden = key => ({ status: 'hidden', [key]: undefined }), _missing = key => ({ status: 'missing', [key]: undefined });

  /* ---------------- معارض ---------------- */
  function canViewShowroom(x, user) { const s = _showroomRecord(x); return !!s && _showroomVisible(s, user); }
  function getVisibleShowrooms(user) { return getShowrooms().filter(s => s && _showroomVisible(s, user)); }
  function getVisibleShowroomById(id, user) { const s = _showroomById(id); return (s && _showroomVisible(s, user)) ? s : undefined; }
  /** { status: 'ok'|'hidden'|'missing', showroom } — للشاشات التي تميّز «غير موجود» من «غير متاح» */
  function getShowroomAccess(id, user) { const s = _showroomById(id); return !s ? _missing('showroom') : (_showroomVisible(s, user) ? _ok('showroom', s) : _hidden('showroom')); }

  /* ---------------- سيارات ---------------- */
  function canViewCar(x, user) { const c = _carRecord(x); return !!c && _carVisible(c, user); }
  /** سيارات المعارض الظاهرة للمشاهد */
  function getVisibleCars(user) { return getCars().filter(c => c && _carVisible(c, user)); }
  /** سيارات الأعضاء المعروضة في القوائم العامة (إعلان active + حساب مالكه active، لأي مشاهد) */
  function getVisibleMemberCars() { return MemberCarsRepository.getAll().filter(c => c && _memberPublic(c)); }   // (الجزء 2) المسار العام يقرأ المستودع مباشرةً ويطبّق قواعد الظهور؛ getMemberCars() صار محروسًا بالتفويض ولا يصلح مصدرًا للعرض العام
  /** بركة السيارات العامة: 'showroom' (الافتراضي وأي قيمة غريبة) | 'member' | 'all' — كل البحث والفلاتر تنطلق منها */
  function getPublicCars(sourceType, user) {
    if (sourceType === 'member') return getVisibleMemberCars();
    if (sourceType === 'all') return getVisibleCars(user).concat(getVisibleMemberCars());
    return getVisibleCars(user);
  }
  function getVisibleCarById(id, user) { const c = _carById(id); return (c && _carVisible(c, user)) ? c : undefined; }
  function getVisibleCarsByShowroom(showroomId, user) {
    const s = _showroomById(showroomId);
    return (s && _showroomVisible(s, user)) ? getCarsByShowroom(s.id).filter(c => c && _carVisible(c, user)) : [];
  }
  /** { status: 'ok'|'hidden'|'missing', car } لأي سيارة (معرض أو عضو) */
  function getCarAccess(id, user) { const c = _carById(id); return !c ? _missing('car') : (_carVisible(c, user) ? _ok('car', c) : _hidden('car')); }
  /** كالسابقة لإعلانات الأعضاء فقط: سيارة معرض أو معرّف غير موجود ← missing (شاشة/حراسة memberCarDetails) */
  function getMemberCarAccess(id, user) {
    const c = _carById(id);
    if (!c || c.sourceType !== CAR_SOURCE.MEMBER) return _missing('car');
    return _carVisible(c, user) ? _ok('car', c) : _hidden('car');
  }

  return { canViewShowroom, getVisibleShowrooms, getVisibleShowroomById, getShowroomAccess, canViewCar, getVisibleCars, getVisibleMemberCars,
           getPublicCars, getVisibleCarById, getVisibleCarsByShowroom, getCarAccess, getMemberCarAccess };
})();

function canViewShowroom(showroomOrId, user) { return VisibilityService.canViewShowroom(showroomOrId, user); }
function getVisibleShowrooms(user) { return VisibilityService.getVisibleShowrooms(user); }
function getVisibleShowroomById(id, user) { return VisibilityService.getVisibleShowroomById(id, user); }
function getShowroomAccess(id, user) { return VisibilityService.getShowroomAccess(id, user); }
function canViewCar(carOrId, user) { return VisibilityService.canViewCar(carOrId, user); }
function getVisibleCars(user) { return VisibilityService.getVisibleCars(user); }
function getVisibleMemberCars() { return VisibilityService.getVisibleMemberCars(); }
function getPublicCars(sourceType, user) { return VisibilityService.getPublicCars(sourceType, user); }
function getVisibleCarById(id, user) { return VisibilityService.getVisibleCarById(id, user); }
function getVisibleCarsByShowroom(showroomId, user) { return VisibilityService.getVisibleCarsByShowroom(showroomId, user); }
function getCarAccess(id, user) { return VisibilityService.getCarAccess(id, user); }
function getMemberCarAccess(id, user) { return VisibilityService.getMemberCarAccess(id, user); }

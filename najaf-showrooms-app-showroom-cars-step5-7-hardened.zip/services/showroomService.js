/* ==========================================================================
   SHOWROOM SERVICE — إنشاء/ربط معرض التاجر (إصلاح المرحلة 9)
   المشكلة: اعتماد الإدارة لتاجر جديد كان يغيّر حالته فقط، ولا يوجد معرض مرتبط به، فتظهر له «لا يوجد معرض
   مرتبط بحسابك» ولا يستطيع إضافة سيارة. الحل: عند الاعتماد يُنشأ للتاجر معرض واحد (ownerId = التاجر) إن لم يكن
   لديه معرض، أما التاجر الذي لديه معرض (التجريبي أو الذي أُنشئ سابقًا) فيُربط به ولا يُنشأ ثانٍ.
   التصميم الحالي: معرض واحد لكل تاجر (ShowroomCarsService يعمل على أول معرض يديره). إعادة الاعتماد idempotent.
   ========================================================================== */
const ShowroomService = (function () {
  /** يضمن وجود معرض للتاجر. يعيد { ok, created, showroom } أو { ok:false, error }. لا صلاحيات هنا: يُستدعى من الإدارة/الهجرة. */
  function ensureDealerShowroom(userId) {
    const user = UsersRepository.getById(userId);
    if (!user || user.role !== ROLES.DEALER) return { ok: false, error: 'ليس صاحب معرض.' };
    const existing = ShowroomsRepository.findOne(s => s.ownerId === userId);
    if (existing) return { ok: true, created: false, showroom: existing };

    const now = new Date().toISOString();
    const r = ShowroomsRepository.create(ShowroomModel({
      name: `معرض ${String(user.name || '').trim() || 'جديد'}`, description: '', phone: user.phone, whatsapp: user.phone,
      address: '', latitude: null, longitude: null, image: '', workingHours: '', services: [],
      status: 'active', ownerId: userId, createdAt: now, updatedAt: now,
    }));
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, created: true, showroom: r.item, persisted: r.persisted };
  }

  function getShowroomByOwner(userId) { return ShowroomsRepository.findOne(s => s.ownerId === userId) || null; }

  return { ensureDealerShowroom, getShowroomByOwner };
})();

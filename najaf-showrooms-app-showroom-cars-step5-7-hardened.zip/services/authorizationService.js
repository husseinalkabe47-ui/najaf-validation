/* ==========================================================================
   AUTHORIZATION SERVICE
   كل قرارات "من يستطيع فعل ماذا" في مكان واحد. كل دالة تعيد true/false، وتُعيد
   قراءة المستخدم من سجله (لا تثق بأي كائن مُمرَّر)، ولا تكتفي بإخفاء الأزرار:
   الراوتر والخدمات المستقبلية (إضافة/تعديل/حذف) يجب أن تستدعي هذه الدوال أيضًا.

   المعامل الأخير user اختياري: إن لم يُمرَّر يُستخدم مستخدم الجلسة الحالية،
   وإن مُرِّر null فهو زائر.
   ========================================================================== */
const AuthorizationService = (function () {

  function _actor(user) {
    let u;
    if (user === undefined) u = SessionService.getCurrentUser();
    else u = user ? UserService.getPublicById(user.id) : null;   // إعادة قراءة السجل الحقيقي
    return (u && u.status !== USER_STATUS.SUSPENDED) ? u : null;
  }
  const _isActiveAdmin  = u => !!u && u.role === ROLES.ADMIN  && u.status === USER_STATUS.ACTIVE;
  const _isActiveDealer = u => !!u && u.role === ROLES.DEALER && u.status === USER_STATUS.ACTIVE;

  /* --- تصفح عام: مسموح للجميع بمن فيهم الزائر --- */
  function canViewCars() { return true; }
  function canViewShowrooms() { return true; }

  /* --- المفضلة: تتطلب تسجيل دخول --- */
  function canUseFavorites(user) { return _actor(user) !== null; }

  /* --- صاحب المعرض --- */
  function canAccessDealerArea(user) { return _isActiveDealer(_actor(user)); }

  /** إدارة معرض: المدير لأي معرض، وصاحب المعرض (المعتمد) لمعرضه فقط (ownerId) */
  function canManageShowroom(showroomId, user) {
    const u = _actor(user);
    const showroom = getShowroomById(showroomId);
    if (!u || !showroom) return false;
    if (_isActiveAdmin(u)) return true;
    return _isActiveDealer(u) && showroom.ownerId === u.id;
  }

  /** إدارة سيارة: تُحدَّد بمعرضها — لا يكفي معرفة رقم السيارة */
  function canManageCar(carId, user) {
    const car = getCarById(carId);
    // سيارات المعارض فقط: سيارة عضو (sourceType='member') لا تُدار من هنا أبدًا (المرحلة 7)
    return !!car && car.sourceType === CAR_SOURCE.SHOWROOM && canManageShowroom(car.showroomId, user);
  }

  /* --- الإدارة --- */
  function canAccessAdmin(user)     { return _isActiveAdmin(_actor(user)); }
  function canManageUsers(user)     { return _isActiveAdmin(_actor(user)); }
  function canApproveDealers(user)  { return _isActiveAdmin(_actor(user)); }

  /* --- المرحلة 4: سيارات الأعضاء ---
     القاعدة الأساسية لكل دالة أدناه: المدير يدير كل شيء، وأي شخص آخر لا يدير
     إلا إعلانه هو (car.sourceType==='member' AND car.ownerId===currentUser.id).
     dealer وuser يخضعان لنفس القاعدة تمامًا هنا؛ صلاحيات dealer على معرضه
     (canManageShowroom/canManageCar) لا علاقة لها بهذه الدوال ولا تتأثر بها. */
  function canCreateMemberCar(user) { return _actor(user) !== null; } // أي مستخدم مسجّل غير موقوف (user/dealer/admin)

  function _isOwnMemberCar(u, car) {
    return !!u && !!car && car.sourceType === CAR_SOURCE.MEMBER && car.ownerId === u.id;
  }
  /** (الجزء 6.1) السجل الحقيقي المخزَّن بمعرّف الكائن المُمرَّر — حقول الكائن المُمرَّر (ownerId/sourceType) لا يُوثَق بها (كائن مزوَّر لا يمنح صلاحية) */
  function _storedCar(car) { return (car && Number.isFinite(car.id)) ? (getCarById(car.id) || null) : null; }
  function canEditMemberCar(user, car) {
    const u = _actor(user), real = _storedCar(car);
    if (!u || !real) return false;
    return _isActiveAdmin(u) || _isOwnMemberCar(u, real);
  }
  function canDeleteMemberCar(user, car) { return canEditMemberCar(user, car); }
  function canChangeMemberCarStatus(user, car) { return canEditMemberCar(user, car); }
  function canManageMemberCar(user, car) { return canEditMemberCar(user, car); }

  /* --- المرحلة 7: صور السيارة — نفس قاعدة الملكية حسب نوع السيارة --- */
  function canManageCarImages(car, user) {
    const real = _storedCar(car);
    if (!real) return false;
    return real.sourceType === CAR_SOURCE.MEMBER ? canEditMemberCar(user, real) : canManageCar(real.id, user);
  }

  /** بيانات مستخدم: لصاحبها أو للمدير فقط (لا يرى تاجر بيانات تاجر آخر) */
  function canViewUserData(targetUserId, user) {
    const u = _actor(user);
    return !!u && (u.id === targetUserId || _isActiveAdmin(u));
  }

  /** المعارض التي يحق للمستخدم إدارتها (المدير: الكل، التاجر: معارضه فقط) */
  function getManagedShowrooms(user) {
    return getShowrooms().filter(s => canManageShowroom(s.id, user));
  }

  /** زر الحساب في الصفحة الرئيسية حسب حالة المستخدم */
  function getAccountEntryPoint(user) {
    const u = _actor(user);
    if (!u) return { label: 'تسجيل الدخول', route: 'login', icon: '👤' };
    if (_isActiveAdmin(u))  return { label: 'لوحة الإدارة', route: 'adminHome',  icon: '🛡️' };
    if (_isActiveDealer(u)) return { label: 'إدارة معرضي',  route: 'dealerHome', icon: '🏢' };
    return { label: 'حسابي', route: 'account', icon: '👤' };
  }

  return { canViewCars, canViewShowrooms, canUseFavorites, canAccessDealerArea,
           canManageShowroom, canManageCar, canAccessAdmin, canManageUsers,
           canApproveDealers, canViewUserData, getManagedShowrooms, getAccountEntryPoint,
           canCreateMemberCar, canEditMemberCar, canDeleteMemberCar,
           canChangeMemberCarStatus, canManageMemberCar, canManageCarImages };
})();

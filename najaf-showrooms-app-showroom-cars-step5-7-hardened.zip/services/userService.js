/* ==========================================================================
   USER SERVICE
   الوصول لبيانات المستخدمين. القاعدة: الشاشات لا تحصل أبدًا على passwordHash.
   الدوال التي تبدأ بشرطة سفلية (_) داخلية للخدمات فقط (Auth/Session/Authorization).
   ========================================================================== */
const UserService = (function () {
  function toPublic(u) {
    if (!u) return null;
    const { id, name, phone, email, role, status, createdAt } = u;
    return { id, name, phone, email, role, status, createdAt };
  }

  /** استعادة المستخدمين المسجَّلين وتعديلات الإدارة عليهم — تتم في UsersRepository */
  function loadRegistered() { UsersRepository.hydrate(); }

  function _findById(id) { return UsersRepository.getById(id); }

  /** بحث بالهاتف أو البريد — يعيد السجل الكامل (داخلي، للمصادقة فقط) */
  function _findByIdentifier(identifier) {
    const id = String(identifier || '').trim().toLowerCase();
    if (!id) return null;
    const phone = normalizePhone(id);
    return UsersRepository.findOne(u => (phone && u.phone === phone) || (u.email && u.email.toLowerCase() === id));
  }

  function _isPhoneTaken(phone) { return !!UsersRepository.findOne(u => u.phone === phone); }
  function _isEmailTaken(email) { return !!email && !!UsersRepository.findOne(u => u.email && u.email.toLowerCase() === email.toLowerCase()); }

  /** إنشاء حساب: يعيد { user, persisted } (أو null إن رفضه المستودع). persisted=false ← نجح في الذاكرة وتعذّر الحفظ على الجهاز (تدقيق ما قبل الباكند: لم يكن يصل المستخدم). */
  function _create({ name, phone, email, role, status, passwordHash }) {
    const id = UsersRepository.allocateId();
    const user = UserModel({ id, name, phone, email: email || null, role, status, passwordHash, createdAt: new Date().toISOString() });
    const r = UsersRepository.create(user);
    return r.ok ? { user: r.item, persisted: r.persisted } : null;
  }

  /** نسخة عامة (بدون كلمة المرور) */
  function getPublicById(id) { return toPublic(_findById(id)); }

  /** ملف مستخدم — مسموح فقط لصاحب الحساب أو للمدير (يراجع AuthorizationService) */
  function getProfile(userId, viewer) {
    if (!AuthorizationService.canViewUserData(userId, viewer)) return null;
    return getPublicById(userId);
  }

  return { loadRegistered, getPublicById, getProfile, toPublic,
           _findById, _findByIdentifier, _isPhoneTaken, _isEmailTaken, _create };
})();

/** توحيد صيغة رقم الهاتف العراقي: 07XXXXXXXXX (يقبل +964 وأرقام عربية) */
function normalizePhone(input) {
  let s = String(input || '').trim();
  s = s.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  s = s.replace(/[\s\-()]/g, '');
  if (s.startsWith('+964')) s = '0' + s.slice(4);
  else if (s.startsWith('00964')) s = '0' + s.slice(5);
  else if (s.startsWith('964') && s.length === 13) s = '0' + s.slice(3);
  return /^07\d{9}$/.test(s) ? s : '';
}

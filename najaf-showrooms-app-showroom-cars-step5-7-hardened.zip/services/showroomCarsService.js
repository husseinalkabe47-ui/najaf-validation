/* ==========================================================================
   SHOWROOM CARS SERVICE — إدارة سيارات المعرض للتاجر (المرحلة 7)
   كل عملية تتحقق من الصلاحية داخل الخدمة نفسها عبر AuthorizationService
   (وليس بإخفاء الأزرار). showroomId لا يأتي أبدًا من الواجهة: يُشتق من
   المعرض الذي يملكه التاجر الحالي (ownerId). التاجر لا يمسّ سيارات الأعضاء.
   حالات سيارة المعرض: available (متاحة للبيع) | sold (مباعة) فقط — لا حالة حجز (السيارة المحجوزة لدى شخص لم تُشترَ بعد).
   ("available" هي المقابل الفعلي لـ«active» في نظام سيارات المعارض منذ المرحلة 1).
   ========================================================================== */
const ShowroomCarsService = (function () {
  const DEALER_STATUSES = SHOWROOM_CAR_STATUSES.slice();   // مصدر واحد: متاحة للبيع / مباعة

  /** استعادة سيارات المعارض المحفوظة — في CarsRepository */
  function load() { CarsRepository.hydrate(); }

  /** سيارات معارض يحق للمستخدم الحالي إدارتها (التاجر: معرضه فقط) */
  function getMyShowroomCars() {
    const ids = AuthorizationService.getManagedShowrooms().map(s => s.id);
    return CarsRepository.getAll().filter(c => ids.includes(c.showroomId));
  }

  /** existingBrand: ماركة السيارة الحالية عند التعديل الجزئي (الموديل يُوحَّد داخل ماركته) */
  function _validate(d, partial, existingBrand) {
    const out = {};
    const tooLong = textLimitError(d, ['brand', 'model', 'color', 'transmission', 'fuelType', 'description']);   // أطوال قصوى (تدقيق ما قبل الباكند)
    if (tooLong) return { ok: false, error: tooLong };
    const need = (k) => d[k] !== undefined && String(d[k]).trim() !== '';
    if (!partial) for (const k of ['brand', 'model', 'year', 'price']) if (!need(k)) return { ok: false, error: 'الرجاء تعبئة الحقول المطلوبة (الماركة، الموديل، السنة، السعر).' };
    if (need('brand')) { out.brand = CarFilters.canonicalBrand(d.brand);     // توحيد الكتابة (Toyota = toyota)
      if (!out.brand) return { ok: false, error: 'اسم الماركة غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' }; }   // لا اسم بلا حرف/رقم
    if (need('model')) { out.model = CarFilters.canonicalModel(d.model, out.brand || existingBrand || d.brand);
      if (!out.model) return { ok: false, error: 'اسم الموديل غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' }; }
    if (need('year')) { const y = parseWholeNumber(d.year); if (isNaN(y) || y < 1980 || y > 2100) return { ok: false, error: 'سنة الصنع غير صحيحة.' }; out.year = y; }
    if (need('price')) { const p = parseWholeNumber(d.price); if (isNaN(p) || p <= 0) return { ok: false, error: 'السعر غير صحيح.' }; out.price = p; }
    // عملة السعر (الجزء 5.2): تُحفظ دائمًا صراحةً. مُمرَّرة ← يجب أن تكون IQD | USD وإلا رفض. غائبة (undefined) عند الإنشاء = مستدعٍ يسبق الميزة ← دينار صريح؛ وعند التعديل الجزئي ← بلا تغيير.
    if (d.currency === undefined || (partial && d.currency === '')) { if (!partial) out.currency = CURRENCY_LEGACY_DEFAULT; }
    else { const c = parseCurrency(d.currency); if (!c.ok) return { ok: false, error: 'عملة السعر غير صحيحة. اختر الدينار العراقي أو الدولار الأمريكي.' }; out.currency = c.value; }
    if (need('mileage')) { const m = parseWholeNumber(d.mileage); if (isNaN(m)) return { ok: false, error: 'المسافة المقطوعة غير صحيحة.' }; out.mileage = m; }
    ['transmission', 'fuelType', 'color', 'description'].forEach(k => { if (d[k] !== undefined) out[k] = String(d[k]).trim(); });
    return { ok: true, data: out };
  }

  /** إضافة سيارة: showroomId من حساب التاجر، status='available' (منشورة فورًا)، بلا Reward ولا pending */
  async function createShowroomCar(data, imageDraft) {
    if (!AuthorizationService.canAccessDealerArea()) return { ok: false, error: 'هذه الميزة لأصحاب المعارض المعتمدين فقط.' };
    const showroom = AuthorizationService.getManagedShowrooms()[0];
    if (!showroom || !AuthorizationService.canManageShowroom(showroom.id)) return { ok: false, error: 'لا يوجد معرض مرتبط بحسابك.' };
    const v = _validate(data, false);
    if (!v.ok) return v;

    const now = new Date().toISOString();
    const car = CarModel({
      id: CarsRepository.allocateId(),
      sourceType: CAR_SOURCE.SHOWROOM,
      showroomId: showroom.id,                       // مشتق من الحساب، لا من الإدخال
      status: 'available',
      transmission: 'أوتوماتيك', fuelType: 'بنزين', color: '', description: '', mileage: null,   // غير مُدخلة = غير معروفة لا 0
      ...v.data, mainImage: '', createdAt: now, updatedAt: now,
    });
    const created = CarsRepository.create(car);
    if (!created.ok) return { ok: false, error: repoErrorText(created.error) };
    let imagesAdded = 0, imagesFailed = 0, imagesPersisted = true;
    if (imageDraft) { const r = await commitImageDraft(created.item.id, imageDraft); imagesAdded = r.added || 0; imagesFailed = r.failed || 0; imagesPersisted = r.persisted !== false; }
    return { ok: true, car: created.item, imagesAdded, imagesFailed, persisted: created.persisted && imagesPersisted };
  }

  /** تعديل: الحقول القابلة للتعديل فقط — showroomId/sourceType/status لا تتغيّر من هنا */
  function updateShowroomCar(id, data) {
    const car = getCarById(id);
    if (!car || car.sourceType !== CAR_SOURCE.SHOWROOM) return { ok: false, error: 'السيارة غير موجودة.' };
    if (!AuthorizationService.canManageCar(id)) return { ok: false, error: 'لا تملك صلاحية تعديل هذه السيارة.' };
    const v = _validate(data, true, car.brand);
    if (!v.ok) return v;
    const r = CarsRepository.update(id, Object.assign({}, v.data, { updatedAt: new Date().toISOString() }));
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, car: r.item, persisted: r.persisted };
  }

  async function deleteShowroomCar(id) {
    const car = getCarById(id);
    if (!car || car.sourceType !== CAR_SOURCE.SHOWROOM) return { ok: false, error: 'السيارة غير موجودة.' };
    if (!AuthorizationService.canManageCar(id)) return { ok: false, error: 'لا تملك صلاحية حذف هذه السيارة.' };
    const r = CarsRepository.remove(id);
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    FavoritesRepository.removeByCar(id);        // لا مفضلة يتيمة (والمعرّف لا يُعاد أصلًا)
    await removeAllCarImages(id);
    return { ok: true, persisted: r.persisted };
  }

  function changeShowroomCarStatus(id, status) {
    const car = getCarById(id);
    if (!car || car.sourceType !== CAR_SOURCE.SHOWROOM) return { ok: false, error: 'السيارة غير موجودة.' };
    if (!AuthorizationService.canManageCar(id)) return { ok: false, error: 'لا تملك صلاحية تغيير حالة هذه السيارة.' };
    if (!DEALER_STATUSES.includes(status)) return { ok: false, error: 'حالة غير مسموحة.' };
    const r = CarsRepository.update(id, { status, updatedAt: new Date().toISOString() });
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, car: r.item, persisted: r.persisted };
  }

  return { load, getMyShowroomCars, createShowroomCar, updateShowroomCar, deleteShowroomCar, changeShowroomCarStatus, DEALER_STATUSES };
})();

function getMyShowroomCars() { return ShowroomCarsService.getMyShowroomCars(); }
function createShowroomCar(data, draft) { return ShowroomCarsService.createShowroomCar(data, draft); }
function updateShowroomCar(id, data) { return ShowroomCarsService.updateShowroomCar(id, data); }
function deleteShowroomCar(id) { return ShowroomCarsService.deleteShowroomCar(id); }
function changeShowroomCarStatus(id, status) { return ShowroomCarsService.changeShowroomCarStatus(id, status); }
function loadShowroomCars() { ShowroomCarsService.load(); }

/* خدمة المفضلة: لكل مستخدم مفضلته الخاصة (userId → سيارات).
   تتطلب تسجيل دخول؛ الزائر يُطلب منه تسجيل الدخول عند محاولة الإضافة.
   المرحلة 9: الوصول للبيانات والحفظ عبر FavoritesRepository فقط (لا تخزين مباشر هنا). */

function loadFavorites() { FavoritesRepository.hydrate(); }

function _currentFavUserId() {
  const u = SessionService.getCurrentUser();
  return u ? u.id : null;
}

function isFavorite(carId) {
  const uid = _currentFavUserId();
  return uid !== null && !!FavoritesRepository.findByUserAndCar(uid, carId);
}

/** يعيد { ok, isFavorite, persisted } أو { ok:false, reason } — reason: login_required | not_found | storage_error */
function toggleFavorite(carId) {
  const uid = _currentFavUserId();
  if (uid === null || !AuthorizationService.canUseFavorites()) return { ok: false, reason: 'login_required' };
  if (!getVisibleCarById(carId)) return { ok: false, reason: 'not_found' };   // غير موجودة أو غير متاحة لهذا المشاهد (معرض موقوف/إعلان غير نشط لغير مالكه)
  // (تدقيق ما قبل الباكند) صفوف مكررة لنفس (مستخدم، سيارة) من بيانات تالفة: الإلغاء يزيلها كلها فلا تبقى isFavorite صحيحة بعد «إلغاء» ناجح
  const rows = FavoritesRepository.getByUser(uid).filter(f => f.carId === carId);
  let r;
  if (rows.length) {
    r = { ok: true, persisted: true };
    for (const f of rows) { const x = FavoritesRepository.remove(f.id); if (!x.ok) { r = x; break; } if (x.persisted === false) r.persisted = false; }
  } else r = FavoritesRepository.create(FavoriteModel({ id: FavoritesRepository.allocateId(), userId: uid, carId, createdAt: new Date().toISOString() }));
  if (!r.ok) return { ok: false, reason: 'storage_error' };
  return { ok: true, isFavorite: rows.length === 0, persisted: r.persisted };
}

function getFavoriteCars() {
  const uid = _currentFavUserId();
  if (uid === null) return [];
  // سجلات مفضلة سيارات معرض موقوف تبقى محفوظة (تعود بإعادة التفعيل) لكنها لا تظهر لمن لا يرى المعرض
  const seen = new Set();   // سيارة واحدة مرة واحدة حتى لو تكرر صفها في بيانات تالفة
  return FavoritesRepository.getByUser(uid).filter(f => !seen.has(f.carId) && seen.add(f.carId)).map(f => getVisibleCarById(f.carId)).filter(Boolean);
}

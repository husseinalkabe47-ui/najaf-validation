/* ==========================================================================
   ADMIN SERVICE
   طبقة خدمات لوحة الإدارة. لا تكرر منطقًا موجودًا: تستدعي memberCarsService
   لكل ما يخص سيارات الأعضاء، وتتحقق من AuthorizationService.canAccessAdmin()
   قبل أي تعديل (بالإضافة إلى التحقق الداخلي الموجود أصلًا في تلك الخدمات).
   ========================================================================== */
const AdminService = (function () {
  const DENIED = { ok: false, error: 'هذا الإجراء متاح للمدير فقط.' };
  function _requireAdmin() { return AuthorizationService.canAccessAdmin(); }

  /* ---- الإحصائيات ---- */
  function getDashboardStats() {
    if (!_requireAdmin()) return null;     // (الجزء 6.1) إحصاءات إدارية: لغير المدير لا شيء (كانت تُعاد لأي مستدعٍ)
    const memberCars = getMemberCars();
    const count = s => memberCars.filter(c => c.status === s).length;
    return {
      totalUsers: UsersRepository.getAll().length,
      totalShowrooms: getShowrooms().length,
      totalShowroomCars: getCars().length,
      totalMemberCars: memberCars.length,
      pendingMemberCars: count(MEMBER_CAR_STATUS.PENDING),
      activeMemberCars: count(MEMBER_CAR_STATUS.ACTIVE),
      soldMemberCars: count(MEMBER_CAR_STATUS.SOLD),
      rejectedMemberCars: count(MEMBER_CAR_STATUS.REJECTED),
      suspendedMemberCars: count(MEMBER_CAR_STATUS.SUSPENDED),
      pendingDealers: UsersRepository.getAll().filter(u => u.role === ROLES.DEALER && u.status === USER_STATUS.PENDING).length,
    };
  }

  /* ---- سيارات الأعضاء: كل المنطق فعليًا في memberCarsService، هذه أغلفة رفيعة فقط ---- */
  function getPendingMemberCars() { return MemberCarsService.getPendingMemberCars(); }
  function approveMemberCar(id) {
    if (!_requireAdmin()) return DENIED;
    return MemberCarsService.changeMemberCarStatus(id, MEMBER_CAR_STATUS.ACTIVE);
  }
  function rejectMemberCar(id, reason) {
    if (!_requireAdmin()) return DENIED;
    return MemberCarsService.changeMemberCarStatus(id, MEMBER_CAR_STATUS.REJECTED, { reason });
  }
  function suspendMemberCar(id, reason) {
    if (!_requireAdmin()) return DENIED;
    return MemberCarsService.changeMemberCarStatus(id, MEMBER_CAR_STATUS.SUSPENDED, { reason });
  }
  function restoreMemberCar(id) {
    if (!_requireAdmin()) return DENIED;
    return MemberCarsService.changeMemberCarStatus(id, MEMBER_CAR_STATUS.PENDING);
  }

  /* ---- المعارض: قراءة عبر dataService الحالية، والإيقاف/التفعيل إجراء إداري بحت (soft) ---- */
  function getAllShowrooms() { return _requireAdmin() ? getShowrooms() : []; }     // (الجزء 6.1) تشمل الموقوفة: للمدير فقط
  function suspendShowroom(id) {
    if (!_requireAdmin()) return DENIED;
    const r = ShowroomsRepository.update(id, { status: 'suspended', updatedAt: new Date().toISOString() });
    if (!r.ok) return { ok: false, error: r.error === 'not_found' ? 'المعرض غير موجود.' : repoErrorText(r.error) };
    return { ok: true, showroom: r.item, persisted: r.persisted };
  }
  function activateShowroom(id) {
    if (!_requireAdmin()) return DENIED;
    const r = ShowroomsRepository.update(id, { status: 'active', updatedAt: new Date().toISOString() });
    if (!r.ok) return { ok: false, error: r.error === 'not_found' ? 'المعرض غير موجود.' : repoErrorText(r.error) };
    return { ok: true, showroom: r.item, persisted: r.persisted };
  }

  /* ---- سيارات المعارض: تغيير الحالة فقط (Soft) — لا حذف فعلي، ويستخدم نفس canManageCar الحالية ---- */
  function setShowroomCarStatus(carId, status) {
    if (!_requireAdmin()) return DENIED;
    const car = getCarById(carId);
    if (!car || car.sourceType !== CAR_SOURCE.SHOWROOM) return { ok: false, error: 'السيارة غير موجودة.' };
    if (!SHOWROOM_CAR_STATUSES.includes(status)) return { ok: false, error: 'حالة غير صحيحة.' };   // متاحة للبيع / مباعة فقط
    const r = CarsRepository.update(carId, { status, updatedAt: new Date().toISOString() });
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, car: r.item, persisted: r.persisted };
  }

  /* ---- المستخدمون ---- */
  function getAllUsers() { return _requireAdmin() ? UsersRepository.getAll().map(UserService.toPublic) : []; } // بلا passwordHash أبدًا؛ (الجزء 6.1) وبيانات الحسابات (هاتف/بريد) للمدير فقط
  function approveDealer(id) {
    if (!_requireAdmin()) return DENIED;
    const u = UserService._findById(id);
    if (!u || u.role !== ROLES.DEALER) return { ok: false, error: 'ليس صاحب معرض.' };
    const prevStatus = u.status;
    const r = UsersRepository.update(id, { status: USER_STATUS.ACTIVE });
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    // اعتماد التاجر ينشئ له معرضه أو يربطه بمعرضه الحالي (معرض واحد لكل تاجر) — بلا معرض لا يستطيع إدارة شيء
    const sh = ShowroomService.ensureDealerShowroom(id);
    if (!sh.ok) {
      UsersRepository.update(id, { status: prevStatus });          // لا نترك تاجرًا فعّالًا بلا معرض
      return { ok: false, error: sh.error || 'تعذر إنشاء معرض للتاجر، حاول مرة أخرى.' };
    }
    return { ok: true, user: UserService.toPublic(r.item), showroom: sh.showroom, showroomCreated: !!sh.created,
             persisted: r.persisted && sh.persisted !== false };
  }
  /** لا حذف: يبقى الحساب موجودًا. النموذج الحالي ليس له حالة "rejected" منفصلة
      لحساب المستخدم (فقط active/pending/suspended)، فتُستخدم "suspended" لتمثيل
      دعوة مرفوضة لم تُفعَّل — الحساب نفسه غير محذوف ويمكن للمدير تفعيله لاحقًا. */
  function rejectDealer(id) {
    if (!_requireAdmin()) return DENIED;
    const u = UserService._findById(id);
    if (!u || u.role !== ROLES.DEALER) return { ok: false, error: 'ليس صاحب معرض.' };
    const r = UsersRepository.update(id, { status: USER_STATUS.SUSPENDED });
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, user: UserService.toPublic(r.item), persisted: r.persisted };
  }

  return {
    getDashboardStats, getPendingMemberCars, approveMemberCar, rejectMemberCar,
    suspendMemberCar, restoreMemberCar, getAllShowrooms, suspendShowroom, activateShowroom,
    setShowroomCarStatus, getAllUsers, approveDealer, rejectDealer
  };
})();

/* اختصارات على مستوى عام (نفس أسلوب باقي الخدمات مثل memberCarsService) */
function getDashboardStats() { return AdminService.getDashboardStats(); }
function adminGetPendingMemberCars() { return AdminService.getPendingMemberCars(); }
function approveMemberCar(id) { return AdminService.approveMemberCar(id); }
function rejectMemberCar(id, reason) { return AdminService.rejectMemberCar(id, reason); }
function suspendMemberCarAdmin(id, reason) { return AdminService.suspendMemberCar(id, reason); }
function restoreMemberCar(id) { return AdminService.restoreMemberCar(id); }
function adminGetAllShowrooms() { return AdminService.getAllShowrooms(); }
function suspendShowroom(id) { return AdminService.suspendShowroom(id); }
function activateShowroom(id) { return AdminService.activateShowroom(id); }
function setShowroomCarStatus(carId, status) { return AdminService.setShowroomCarStatus(carId, status); }
function adminGetAllUsers() { return AdminService.getAllUsers(); }
function approveDealer(id) { return AdminService.approveDealer(id); }
function rejectDealer(id) { return AdminService.rejectDealer(id); }

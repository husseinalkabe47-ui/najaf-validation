/* ==========================================================================
   REWARD SERVICE (Reward Gate Abstraction)
   الهدف: فصل "هل يحتاج المستخدم لمشاهدة إعلان؟" و"هل اكتمل الإعلان؟" عن أي
   تفاصيل لمزوّد إعلانات معيّن. اليوم المزوّد هو MockRewardProvider (عداد
   تنازلي بلا شبكة ولا SDK). لاحقًا يُستبدل هذا الكائن فقط بـ AdMobRewardProvider
   بنفس الدوال العامة (isRewardRequired/canPublishMemberCar/requestPublishReward/
   onRewardCompleted) دون أي تعديل في AddMemberCarScreen أو memberCarsService.

   publishRequestId: كل طلب نشر يحمل معرّفًا فريدًا (يُنشئه memberCarsService)،
   والمكافأة تُربط بهذا المعرّف تحديدًا (isRewardCompletedFor/consumeReward)
   حتى لا يُستخدم إتمام إعلان واحد لنشر أكثر من سيارة.
   ========================================================================== */
const RewardService = (function () {
  // حالة كل طلب إعلان أثناء التشغيل فقط (بلا تخزين محلي) — عمدًا:
  // بهذا لا تمنح إعادة تحميل الصفحة أي مكافأة تلقائية، ولا يبقى طلب "مكتمل" معلّقًا بعد إعادة التحميل.
  let _requests = {};   // requestId -> 'idle' | 'loading' | 'ready' | 'completed' | 'cancelled' | 'failed'
  let _completed = {};  // requestId -> true (بعد الاستهلاك تُحذف من هنا)

  /** هل يحتاج هذا المستخدم لمشاهدة إعلان لإكمال النشر؟ dealer/admin: لا. user: نعم. */
  function isRewardRequired(user) {
    const u = user || SessionService.getCurrentUser();
    return !!u && u.role === ROLES.USER;
  }

  /** هل يحق لهذا المستخدم بدء عملية نشر أصلًا؟ (تفويض إلى authorizationService، بلا تكرار منطق) */
  function canPublishMemberCar(user) {
    return AuthorizationService.canCreateMemberCar(user);
  }

  /* ---- MockRewardProvider ----
     مزوّد وهمي لأغراض التطوير فقط. الواجهة (request/cancel/complete) هي ما
     سيُطابقه AdMobRewardProvider لاحقًا: تحميل الإعلان، ثم انتظار إشارة اكتمال
     حقيقية من SDK بدل العداد التنازلي المحلي هنا. */
  const MockRewardProvider = {
    /** "تحميل" الإعلان. في Mock mode جاهز فورًا (لا شبكة حقيقية) إلا إذا طُلب محاكاة فشل. */
    load(requestId, { simulateFailure = false } = {}) {
      if (simulateFailure) { _requests[requestId] = 'failed'; return { ok: false, error: 'تعذر تحميل الإعلان، حاول مرة أخرى.' }; }
      _requests[requestId] = 'ready';
      return { ok: true };
    },
    cancel(requestId) {
      if (_requests[requestId] === 'completed') return; // لا يمكن إلغاء شيء اكتمل فعلًا
      _requests[requestId] = 'cancelled';
    },
    /** تُستدعى عند انتهاء العدّ التنازلي في الواجهة (تمثّل onUserEarnedReward في AdMob الحقيقي) */
    complete(requestId) {
      if (_requests[requestId] !== 'ready') return { ok: false, error: 'reward_not_available' };
      _requests[requestId] = 'completed';
      _completed[requestId] = true;
      return { ok: true };
    },
  };

  /** بدء طلب مشاهدة الإعلان لطلب نشر معيّن. options.simulateFailure للاختبارات فقط. */
  function requestPublishReward(requestId, options) {
    if (!requestId) return { ok: false, error: 'طلب غير صالح.' };
    _requests[requestId] = 'loading';
    return MockRewardProvider.load(requestId, options);
  }

  /** تُستدعى من الشاشة عند اكتمال العدّ التنازلي بنجاح */
  function onRewardCompleted(requestId) {
    return MockRewardProvider.complete(requestId);
  }

  /** تُستدعى عند إغلاق/إلغاء الإعلان قبل اكتماله */
  function onRewardCancelled(requestId) {
    MockRewardProvider.cancel(requestId);
    return { ok: true };
  }

  function getRewardState(requestId) { return _requests[requestId] || 'idle'; }
  function isRewardCompletedFor(requestId) { return !!_completed[requestId]; }

  /** تُستهلك المكافأة فور استخدامها في نشر سيارة، فلا يمكن إعادة استخدامها لسيارة أخرى */
  function consumeReward(requestId) {
    delete _completed[requestId];
    delete _requests[requestId];
  }

  return {
    isRewardRequired, canPublishMemberCar, requestPublishReward, onRewardCompleted,
    onRewardCancelled, getRewardState, isRewardCompletedFor, consumeReward, MockRewardProvider,
  };
})();

/* اختصارات على مستوى عام (نفس أسلوب باقي الخدمات مثل memberCarsService/favoritesService) */
function isRewardRequired(user) { return RewardService.isRewardRequired(user); }
function canPublishMemberCarReward(user) { return RewardService.canPublishMemberCar(user); }
function requestPublishReward(requestId, options) { return RewardService.requestPublishReward(requestId, options); }
function onRewardCompleted(requestId) { return RewardService.onRewardCompleted(requestId); }
function onRewardCancelled(requestId) { return RewardService.onRewardCancelled(requestId); }

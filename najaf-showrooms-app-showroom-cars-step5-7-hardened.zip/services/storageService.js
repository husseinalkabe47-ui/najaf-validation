/* ==========================================================================
   STORAGE SERVICE (واجهة توافق)
   بقيت الدوال storageGet/storageSet/storageRemove بأسمائها القديمة للتوافق مع المراحل
   السابقة واختباراتها، لكنها الآن مجرد غلاف رفيع فوق storage/localStorageAdapter.js.
   المرحلة 9: لا تستخدمها الخدمات ولا الشاشات — الوصول للتخزين صار حصرًا عبر الـ Repositories.
   ========================================================================== */
function storageGet(key, fallback = null) { return AppStorage.get(key, fallback); }
function storageSet(key, value) { return AppStorage.set(key, value).ok; }
function storageRemove(key) { AppStorage.remove(key); }

/* خدمة البحث: تبحث حاليًا في البيانات التجريبية عبر دالة getCars()/getShowrooms()
   من dataService، بحيث تبقى صالحة لاحقًا بعد استبدال البيانات بقاعدة حقيقية. */

/* ---- المرحلة 8: بحث يفهم العربية وعدة كلمات ----
   «تويوتا كورولا» و«كورولا 2022» و«سيارات معرض الفرات» تعمل رغم أن بيانات الماركات
   والموديلات إنجليزية: نُطبِّع النص (همزات/تاء مربوطة/تشكيل/أرقام هندية)، ونُوسِّع
   الأسماء العربية الشائعة لمقابلها الإنجليزي، وكل كلمة في الاستعلام يجب أن تطابق
   (AND). كلمات مثل «سيارات» و«معرض» لا تُعدّ شرطًا إلا إن كانت كل الكلمات منها. */
function _normalizeSearch(text) {
  // NFKC أولًا (المرحلة 10 / الجزء 5): الحروف والأرقام العريضة (ＴＯＹＯＴＡ، ２０２２) والأشكال التمثيلية تصبح عادية قبل أي مقارنة
  return String(text === undefined || text === null ? '' : text).normalize('NFKC').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();
}
const _SEARCH_STOPWORDS = ['سيارات', 'سياره', 'معرض', 'معارض', 'في', 'من', 'الى', 'على'].map(_normalizeSearch);
const _SEARCH_ALIASES = (function () {
  const raw = {
    'تويوتا': 'toyota', 'كورولا': 'corolla', 'كامري': 'camry', 'يارس': 'yaris', 'افالون': 'avalon',
    'هيونداي': 'hyundai', 'هيوندا': 'hyundai', 'النترا': 'elantra', 'اكسنت': 'accent', 'توسان': 'tucson', 'سوناتا': 'sonata',
    'كيا': 'kia', 'سيراتو': 'cerato', 'ريو': 'rio', 'سبورتاج': 'sportage', 'اوبتيما': 'optima', 'فورتي': 'forte', 'بيكانتو': 'picanto',
    'نيسان': 'nissan', 'صني': 'sunny', 'سنترا': 'sentra', 'التيما': 'altima', 'ماكسيما': 'maxima',
    'شيفروليه': 'chevrolet', 'شفروليه': 'chevrolet', 'ماليبو': 'malibu',
    'جينيسيس': 'genesis', 'جنسس': 'genesis', 'لكزس': 'lexus', 'مرسيدس': 'mercedes', 'هوندا': 'honda',
    'فورد': 'ford', 'مازدا': 'mazda', 'ميتسوبيشي': 'mitsubishi', 'سوزوكي': 'suzuki',
  };
  const out = {}; Object.keys(raw).forEach(k => { out[_normalizeSearch(k)] = raw[k]; }); return out;
})();

/** استعلام → قائمة كلمات، كل كلمة بدائلها (الكلمة نفسها + مقابلها الإنجليزي إن وُجد) */
function _queryTokens(query) {
  let tokens = _normalizeSearch(query).split(' ').filter(Boolean);
  const meaningful = tokens.filter(t => !_SEARCH_STOPWORDS.includes(t));
  if (meaningful.length) tokens = meaningful;
  return tokens.map(t => {
    const alts = [t];
    if (_SEARCH_ALIASES[t]) alts.push(_SEARCH_ALIASES[t]);
    else if (t.length >= 3) Object.keys(_SEARCH_ALIASES).forEach(k => { if (k.indexOf(t) === 0) alts.push(_SEARCH_ALIASES[k]); });
    return alts;
  });
}
function _matchesTokens(haystack, tokens) {
  const h = _normalizeSearch(haystack);
  return tokens.every(alts => alts.some(a => h.includes(a)));
}

/** نص البحث لسيارة: الماركة/الموديل/السنة + (اسم المعرض وعنوانه لسيارة معرض | الموقع لسيارة عضو).
    حقول مفيدة فقط، وبنصوص صالحة فقط (plainText/yearText): كائن/NaN/null لا يتسرب نصًّا («[object Object]»، «NaN») فيطابق بحثًا. */
function _carSearchText(c) {
  let where = '';
  if (c.sourceType === CAR_SOURCE.MEMBER) where = plainText(c.location);
  else { const sh = getShowroomById(c.showroomId); if (sh) where = `${plainText(sh.name)} ${plainText(sh.address)}`; }
  return `${plainText(c.brand)} ${plainText(c.model)} ${yearText(c.year)} ${where}`;
}
function _carMatchesQuery(c, q) { return _matchesTokens(_carSearchText(c), _queryTokens(q)); }

/** sourceType: 'showroom' (افتراضي، كما كان دائمًا) | 'member' | 'all' */
/** criteria (اختياري، المرحلة 9 Fix): { brand, model, year, minPrice, maxPrice, minMileage, maxMileage } — تُنفَّذ بمحرك
    CarFilters الواحد. سيارات المعارض هنا «عامة»: سيارات المعرض الموقوف لا تظهر لمن لا يملك رؤيته (visibilityService). */
function searchCars(query, sourceType = 'showroom', criteria, viewer) {   // viewer اختياري (غيابه = المستخدم الحالي كما كان تمامًا)؛ null = العامة بلا مشاهد (يستعمله قسم «المضافة حديثًا»)
  const pool = getPublicCars(sourceType, viewer);               // المسار العام الواحد (visibilityService): لا جلب خام هنا
  let out = pool;
  if (query && String(query).trim()) {
    const tokens = _queryTokens(query);
    out = pool.filter(c => _matchesTokens(_carSearchText(c), tokens));
  }
  return criteria ? CarFilters.apply(out, criteria) : out;
}

function searchShowrooms(query) {
  const showrooms = getVisibleShowrooms();
  if (!query || !String(query).trim()) return showrooms;
  const tokens = _queryTokens(query);
  return showrooms.filter(s => _matchesTokens(`${s.name || ''} ${s.address || ''}`, tokens));
}

/* ---- تغذية الرئيسية (المرحلة 10 / الجزء 4) ----
   تركيب رقيق فوق المسار العام نفسه (searchCars/searchShowrooms → visibilityService): لا جلب خام ولا قاعدة ظهور ولا فلترة جديدة.
   ما يُضاف هنا هو الاختيار الخاص بالرئيسية فقط: الأحدث أولًا + حد أقصى لبطاقات الهاتف (HOME_FEED_LIMIT في كل قسم).
   سيارات المعارض: كل ما يظهر للمشاهد (المتاحة والمباعة بشارتها)، سيارات الأعضاء: النشطة بمالك فعّال (قاعدتا الجزأين 1 و2). */
const HOME_FEED_LIMIT = 4;
function getHomeFeed(limit) {
  const n = (Number.isInteger(limit) && limit > 0) ? limit : HOME_FEED_LIMIT;   // حد غير صالح ← الافتراضي
  const newest = _byCreatedDesc;   // (ج7) نفس ترتيب createdAt الزمني الواحد (المحلل الموحَّد؛ غير الصالح أخيرًا) بدل مقارنة نصية
  return {
    cars: searchCars('', 'showroom').slice().sort(newest).slice(0, n),
    showrooms: searchShowrooms('').slice(0, n),
    memberCars: searchCars('', 'member').slice(0, n),
  };
}

/* ---- السيارات المضافة حديثًا (ميزة جديدة ج1) ----
   «المضافة حديثًا» تصنيف زمني لا حالة: تركيب رقيق فوق المسار العام الواحد نفسه (searchCars → getPublicCars → visibilityService)
   بمصدر موحَّد 'all' = سيارات المعارض الظاهرة + سيارات الأعضاء العامة، ثم ترتيب createdAt تنازليًا (الأحدث أولًا).
   لا جلب خام ولا قاعدة ظهور ولا محرك بحث/فلترة ثانٍ ولا كتابة في التخزين ولا حالة جديدة ولا قائمة معرّفات ثابتة.
   createdAt المفقود/التالف: يُوضع بعد كل المؤرَّخ بترتيب حتمي ثانوي (المعرّف) دون اختراع تاريخ وبلا NaN وبلا استثناء.
   (التحليل في Timestamps: ISO صارم + تحقق تقويمي لأن Date.parse يقبل '2026-02-30' و'0' و'12' كتواريخ.) السجلات القديمة بلا منطقة زمنية = توقيت العراق +03:00 (ج7).
   القسم عام: لا يتغير بتغيّر من يشاهده، فيُطلب المسار العام بلا مشاهد (viewer = null ← visibilityService نفسها): لا تظهر سيارات معرض مخفي
   حتى للمدير أو لمالكه (يراها كلٌّ منهما في شاشاته المصرّح بها: السيارات/الإدارة/«سياراتي»)، وسيارات الأعضاء غير العامة لا تظهر لأحد. */
const RECENT_CARS_HOME_LIMIT = 6;
/** createdAt بالميلي ثانية، أو NaN إن غاب/كان تالفًا (لا نخترع تاريخًا). المحلل الواحد Timestamps (models.js): بلا منطقة = توقيت العراق +03:00،
    وZ/الإزاحة = لحظته الفعلية. الرقم (ms) الموجب المحدود يُقبل كما كان. */
function _createdAtMs(c) {
  const v = c && c.createdAt;
  if (typeof v === 'number') return Number.isFinite(v) && v > 0 ? v : NaN;
  return Timestamps.parseMs(v);
}
/** الأحدث أولًا؛ المؤرَّخ قبل غير المؤرَّخ؛ التعادل فقط ← المعرّف تنازليًا (ترتيب حتمي ثانوي، ليس أساس الترتيب) */
function _byCreatedDesc(a, b) {
  const ta = _createdAtMs(a), tb = _createdAtMs(b), va = !Number.isNaN(ta), vb = !Number.isNaN(tb);
  if (va && vb) { if (ta !== tb) return tb - ta; }
  else if (va !== vb) return va ? -1 : 1;
  return (Number(b && b.id) || 0) - (Number(a && a.id) || 0);
}
/** السيارات العامة (معارض + أعضاء) مرتبة بالأحدث. options: { query, criteria } (نفس searchCars/CarFilters) و{ limit } لأعلى N */
function getRecentCars(options) {
  const o = (options && typeof options === 'object') ? options : {};
  const out = searchCars(o.query, 'all', o.criteria, null).slice().sort(_byCreatedDesc);
  return (Number.isInteger(o.limit) && o.limit > 0) ? out.slice(0, o.limit) : out;
}

/* ---- فلاتر الخدمة (المرحلة 9 Fix): غلافان رفيعان فوق محرك CarFilters الواحد (services/carFilterService.js) ----
   criteria: { brand, model, year, minPrice, maxPrice, minMileage, maxMileage } + (status, showroomId, transmission, fuelType, location) */
function filterCars(criteria = {}) { return CarFilters.apply(getPublicCars('showroom'), criteria); }

/** سيارات الأعضاء النشطة (المرحلة 4) بنفس المحرك. */
function filterMemberCars(criteria = {}) { return CarFilters.apply(getPublicCars('member'), criteria); }

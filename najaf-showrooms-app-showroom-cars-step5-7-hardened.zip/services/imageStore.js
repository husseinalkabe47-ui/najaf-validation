/* ==========================================================================
   IMAGE STORE
   مخزن الصور **المضغوطة فقط**. لا يستقبل أبدًا ملفًا أصليًا: الشاشات والخدمات
   تمرّر له Blob ناتجًا عن ImageService.compressImage حصرًا.
   - المتصفح: IndexedDB (مساحتها أكبر بكثير من localStorage الذي يتسع لبضع صور فقط).
   - بلا IndexedDB (اختبارات/متصفح مقيّد): ذاكرة الجلسة فقط.
   سجلّ الصورة في بيانات السيارة يحمل مرجعًا نصيًا "idb:<id>"، ويُحوَّل إلى blob: URL
   مؤقت للعرض فقط (يُنشأ عند التحميل ولا يُحفظ).
   إصلاح المرحلة 9: put لم تعد تبتلع فشل IndexedDB. تعيد { ok:true, durable } عند النجاح و{ ok:false, error }
   عند الفشل مع إلغاء ما وُضع في الذاكرة، فلا يُسجَّل «idb:<id>» لصورة لم تُحفظ فعلًا.
   durable=false فقط في وضع الذاكرة (لا IndexedDB في هذا المتصفح): الصورة تعمل للجلسة ولا تبقى بعد إعادة التحميل.
   ========================================================================== */
const ImageStore = (function () {
  const DB_NAME = 'najaf-images', STORE = 'images';
  let _mem = {};   // id -> { blob, url }
  let _db = null;

  function _makeUrl(id, blob) {
    try { if (typeof URL !== 'undefined' && URL.createObjectURL) return URL.createObjectURL(blob); } catch (e) { /* تجاهل */ }
    return 'mem:' + id;
  }
  function _revoke(url) { try { if (url && url.indexOf('blob:') === 0) URL.revokeObjectURL(url); } catch (e) { /* تجاهل */ } }
  const _req = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

  async function _open() {
    if (_db || typeof indexedDB === 'undefined') return _db;
    _db = await new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(STORE);
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return _db;
  }

  /** تحميل كل الصور المضغوطة المحفوظة إلى الذاكرة (تُستدعى عند بدء التطبيق). يعيد true إن فُتح IndexedDB وقُرئ. */
  async function init() {
    try {
      const db = await _open();
      if (!db) return false;
      const tx = db.transaction(STORE, 'readonly');
      const store = tx.objectStore(STORE);
      const keys = await _req(store.getAllKeys());
      const vals = await _req(store.getAll());
      keys.forEach((k, i) => { if (!_mem[k]) _mem[k] = { blob: vals[i], url: _makeUrl(k, vals[i]) }; });
      return true;
    } catch (e) { return false; /* يعمل بالذاكرة فقط */ }
  }

  /** هل التخزين الدائم (IndexedDB) متاح في هذا المتصفح؟ */
  function isDurable() { return typeof indexedDB !== 'undefined'; }

  /** يحفظ الصورة المضغوطة. { ok:true, durable } | { ok:false, error:'storage_failed' } — عند الفشل لا يبقى شيء في الذاكرة. */
  async function put(id, blob) {
    const prev = _mem[id];
    _mem[id] = { blob, url: _makeUrl(id, blob) };
    if (typeof indexedDB === 'undefined') { if (prev) _revoke(prev.url); return { ok: true, durable: false }; }   // وضع الذاكرة
    try {
      const db = await _open();
      if (!db) throw new Error('no_db');
      await _req(db.transaction(STORE, 'readwrite').objectStore(STORE).put(blob, id));
      if (prev) _revoke(prev.url);
      return { ok: true, durable: true };
    } catch (e) {
      _revoke(_mem[id].url);                                 // تراجع كامل: لا blob ولا رابط معلّق
      if (prev) _mem[id] = prev; else delete _mem[id];
      return { ok: false, error: 'storage_failed' };
    }
  }

  async function remove(id) {
    if (_mem[id]) { _revoke(_mem[id].url); delete _mem[id]; }
    try {
      const db = await _open();
      if (db) await _req(db.transaction(STORE, 'readwrite').objectStore(STORE).delete(id));
      return true;
    } catch (e) { return false; /* تجاهل */ }
  }

  function getUrl(id) { return _mem[id] ? _mem[id].url : null; }
  function has(id) { return !!_mem[id]; }

  return { init, put, remove, getUrl, has, isDurable };
})();

/** يحوّل imageUrl المخزَّن في سجل الصورة إلى رابط قابل للعرض، أو null (فيُعرض رمز 🚘).
    المسارات التجريبية القديمة (assets/...) ليست ملفات حقيقية فلا تُعرض. */
function resolveImageSrc(imageUrl) {
  if (!imageUrl) return null;
  if (imageUrl.indexOf('idb:') === 0) return ImageStore.getUrl(imageUrl.slice(4));
  if (/^(data:|blob:|https?:)/.test(imageUrl)) return imageUrl;
  return null;
}

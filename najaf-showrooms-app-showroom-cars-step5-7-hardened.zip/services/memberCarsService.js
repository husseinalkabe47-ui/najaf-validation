/* ==========================================================================
   MEMBER CARS SERVICE
   إعلانات السيارات التي ينشرها الأعضاء بأنفسهم (sourceType='member')، منفصلة
   تمامًا عن سيارات المعارض. تعتمد على sessionService (من هو المستخدم الحالي)
   و authorizationService (هل يحق له الإجراء) و rewardService (هل يحتاج نشره
   لمشاهدة إعلان؟) — لا تثق أبدًا ببيانات قادمة من الشاشة نفسها (كـ ownerId في
   نموذج التعديل)، بل تعيد اشتقاقها من الجلسة.

   المرحلة 6 — تغيير جوهري في سياسة النشر:
   "إنشاء البيانات ≠ النشر". لذلك أُلغي الإنشاء المباشر القديم (createMemberCar
   كان يضع status='pending' وينتظر موافقة إدارية) واستُبدل بخطوتين:
     1) createDraftMemberCar(data) — يتحقق من الحقول والصلاحية فقط.
        - dealer/admin: لا حاجة لإعلان؛ يُنشر السيارة فورًا (status='active').
        - user: يُبقي البيانات كمسودة في الذاكرة (غير منشورة، لا تظهر لأحد)
          ويعيد publishRequestId لتُستخدم مع rewardService.
     2) publishMemberCarAfterReward(requestId) — لا تُنشئ السيارة الفعلية في
        MEMBER_CARS إلا بعد أن يؤكد rewardService.isRewardCompletedFor(requestId).
   بيانات البذر القديمة بحالة pending (من المراحل 4/5) تبقى كما هي للإدارة؛
   السيارات الجديدة فقط لم تعد تستخدم pending كخطوة إلزامية.
   ========================================================================== */
const MemberCarsService = (function () {
  // مسوّدات قيد الانتظار (لم تُنشر بعد) — في الذاكرة فقط، عمدًا بلا تخزين محلي:
  // إعادة تحميل الصفحة يجب ألا تمنح مكافأة أو تُبقي مسودة "شبه منشورة" عالقة.
  let _drafts = {};   // draftId -> { ownerId, data, createdAt }
  let _draftSeq = 1;

  /** استعادة الحالة المحفوظة — تتم في MemberCarsRepository (السجل الصريح للمحذوفات، الترحيل، المعرّفات). */
  function loadFromStorage() { MemberCarsRepository.hydrate(); }

  /** (تحصين الإدارة/الأمان — الجزء 2) حدّ التفويض عند واجهة الخدمة نفسها (دفاع متعدد الطبقات، إضافةً إلى حارس الراوتر):
      القوائم الخام لسيارات الأعضاء لا تُعاد كاملة إلا للمدير الفعّال. أي مستخدم مسجّل آخر (عضو أو تاجر) لا يحصل إلا على السجلات التي
      تجيزها له AuthorizationService.canManageMemberCar أي إعلاناته هو، والزائر/الجلسة المنتهية أو المفقودة/الحساب الموقوف/الدور غير المعروف = لا شيء.
      المصدر الوحيد للهوية هو الجلسة (SessionService عبر AuthorizationService التي تعيد قراءة السجل الحقيقي)؛ لا معامل يُقبل من المستدعي
      فكائن مزوَّر (دور/مالك) لا يمنح شيئًا. العرض العام لا يمر من هنا: يقرأ visibilityService المستودع مباشرةً ويطبّق قواعد الظهور. */
  function _authorizedRecords(list) {
    if (AuthorizationService.canAccessAdmin()) return list;
    return list.filter(c => AuthorizationService.canManageMemberCar(undefined, c));
  }
  function getMemberCars() { return _authorizedRecords(MemberCarsRepository.getAll()); }
  function getActiveMemberCars() { return MemberCarsRepository.getAll().filter(c => c.status === MEMBER_CAR_STATUS.ACTIVE); }
  function getPendingMemberCars() {
    if (!AuthorizationService.canAccessAdmin()) return [];     // (الجزء 6.1) قائمة المراجعة إدارية: لا تُعاد لغير المدير حتى لو استُدعيت الدالة مباشرة
    return MemberCarsRepository.getAll().filter(c => c.status === MEMBER_CAR_STATUS.PENDING);
  }
  function getMemberCarsByOwner(ownerId) { return _authorizedRecords(MemberCarsRepository.getByOwner(ownerId)); }   // (الجزء 2) وإلا تجاوز تعدادُ المالكين حدَّ getMemberCars: المدير لأي مالك، وغيره لإعلاناته فقط
  function getMemberCarById(id) { return MemberCarsRepository.getById(id); }

  /** عملة السعر عند الإنشاء (الجزء 5.2): تُحفظ دائمًا صراحةً في السجل. قيمة مُمرَّرة يجب أن تكون عملة مدعومة (IQD | USD) وإلا يُرفض الطلب.
      مفتاح غائب (undefined) = مستدعٍ يسبق ميزة العملة (اختبارات/كود قديم): يُحفظ دينار صراحةً (لا سجل بلا عملة). النماذج ترسل دائمًا القيمة المختارة. */
  function _currencyForCreate(v) {
    if (v === undefined) return { ok: true, value: CURRENCY_LEGACY_DEFAULT };
    const p = parseCurrency(v);
    return p.ok ? p : { ok: false, error: 'عملة السعر غير صحيحة. اختر الدينار العراقي أو الدولار الأمريكي.' };
  }

  /** (الجزء 6.1) هاتف/واتساب إعلان العضو: نفس قاعدة التسجيل (normalizePhone: 07XXXXXXXXX، يقبل +964 وأرقامًا عربية). الواتساب يقبل أيضًا
      الصيغة الدولية 964XXXXXXXXXX (كالبيانات التجريبية). نصوص حرّة (javascript:، وسوم…) تُرفض ولا تُخزَّن. */
  const PHONE_ERROR = 'رقم الهاتف غير صحيح. مثال: 07701234567';
  const WHATSAPP_ERROR = 'رقم الواتساب غير صحيح. مثال: 07701234567';
  function _whatsapp(v) {
    const n = normalizePhone(v); if (n) return n;
    const d = String(v === undefined || v === null ? '' : v).replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g, c => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[\s\-()+]/g, '');
    return /^964\d{10}$/.test(d) ? d : '';
  }

  /** يتحقق من الحقول المطلوبة ويُطبّعها. لا يلمس الصلاحية ولا الحالة. */
  function _validateCarData(data) {
    const required = ['brand', 'model', 'year', 'price', 'phone'];
    for (const f of required) {
      if (data[f] === undefined || data[f] === null || String(data[f]).trim() === '') return { ok: false, error: 'الرجاء تعبئة جميع الحقول المطلوبة.' };
    }
    const tooLong = textLimitError(data, ['brand', 'model', 'color', 'transmission', 'fuelType', 'description', 'location']);   // أطوال قصوى (تدقيق ما قبل الباكند)
    if (tooLong) return { ok: false, error: tooLong };
    const brand = CarFilters.canonicalBrand(data.brand), model = CarFilters.canonicalModel(data.model, data.brand);
    if (!brand) return { ok: false, error: 'اسم الماركة غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };    // لا اسم بلا حرف/رقم: لا يصلح للتجميع في الفلاتر
    if (!model) return { ok: false, error: 'اسم الموديل غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
    const year = parseWholeNumber(data.year), price = parseWholeNumber(data.price);
    if (isNaN(year) || year < 1980 || year > 2100) return { ok: false, error: 'سنة الصنع غير صحيحة.' };
    if (isNaN(price) || price <= 0) return { ok: false, error: 'السعر غير صحيح.' };
    const cur = _currencyForCreate(data.currency);
    if (!cur.ok) return cur;
    const phone = normalizePhone(data.phone);
    if (!phone) return { ok: false, error: PHONE_ERROR };
    let whatsapp = phone;
    if (data.whatsapp !== undefined && data.whatsapp !== null && String(data.whatsapp).trim() !== '') { whatsapp = _whatsapp(data.whatsapp); if (!whatsapp) return { ok: false, error: WHATSAPP_ERROR }; }
    // المسافة غير المُدخلة = غير معروفة (null)، لا 0: «0 كم» تعني سيارة جديدة فعلًا ولا تُفترض للمجهول
    let mileage = null;
    if (data.mileage !== undefined && data.mileage !== null && String(data.mileage).trim() !== '') {
      mileage = parseWholeNumber(data.mileage);
      if (isNaN(mileage)) return { ok: false, error: 'الكيلومترات غير صحيحة.' };
    }
    return {
      ok: true,
      data: {
        brand, model, year, price, currency: cur.value,
        mileage,
        transmission: data.transmission || 'أوتوماتيك',
        fuelType: data.fuelType || 'بنزين',
        color: data.color || '', description: data.description || '',
        mainImage: data.mainImage || '', phone, whatsapp,
        location: data.location || '', latitude: data.latitude ?? null, longitude: data.longitude ?? null,
      }
    };
  }

  /** يبني السيارة ويسلّمها للمستودع (المعرّف منه). يعيد نتيجة المستودع { ok, item, persisted }. */
  function _buildAndPushCar(owner, fields, status) {
    const id = MemberCarsRepository.allocateId();
    const now = new Date().toISOString();
    const car = CarModel({
      id, sourceType: CAR_SOURCE.MEMBER, ownerId: owner.id, status,
      ...fields,
      mainImage: fields.mainImage || `assets/member-cars/${id}_1.jpg`,
      createdAt: now, updatedAt: now,
    });
    return MemberCarsRepository.create(car);
  }

  /**
   * الخطوة 1: إنشاء "مسودة" نشر.
   * dealer/admin  → لا Reward مطلوب: تُنشر السيارة فورًا وتُعاد { published:true, car }.
   * user          → يُطلب Reward: تُحفظ البيانات كمسودة غير منشورة وتُعاد { published:false, draftId }.
   * لا تُنشئ أي سجل في MEMBER_CARS لحساب "user" قبل اكتمال الإعلان.
   */
  function createDraftMemberCar(data) {
    if (!AuthorizationService.canCreateMemberCar()) return { ok: false, error: 'يجب تسجيل الدخول لنشر سيارة.' };
    const owner = SessionService.getCurrentUser();
    const v = _validateCarData(data);
    if (!v.ok) return v;

    if (!RewardService.isRewardRequired(owner)) {
      // dealer أو admin: نشر مباشر وفوري بلا إعلان وبلا مراجعة إدارية (قاعدة المرحلة 6)
      const r = _buildAndPushCar(owner, v.data, MEMBER_CAR_STATUS.ACTIVE);
      if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
      return { ok: true, published: true, car: r.item, persisted: r.persisted };
    }

    const draftId = 'draft_' + (_draftSeq++) + '_' + owner.id;
    _drafts[draftId] = { ownerId: owner.id, data: v.data, createdAt: Date.now() };
    return { ok: true, published: false, draftId, requiresReward: true };
  }

  /**
   * الخطوة 2: نشر مسودة بعد اكتمال الإعلان (تُستدعى بعد rewardService.onRewardCompleted).
   * ترفض النشر إن لم تكن المكافأة مكتملة فعليًا لنفس draftId — لا تثق بأي علم "اكتمل" قادم من الشاشة.
   */
  function publishMemberCarAfterReward(draftId) {
    const draft = _drafts[draftId];
    if (!draft) return { ok: false, error: 'طلب النشر غير موجود أو منتهي الصلاحية. حاول مرة أخرى.' };
    const owner = SessionService.getCurrentUser();
    if (!owner || owner.id !== draft.ownerId) return { ok: false, error: 'غير مصرح بإكمال طلب النشر هذا.' };
    if (!RewardService.isRewardCompletedFor(draftId)) return { ok: false, error: 'يجب إكمال مشاهدة الإعلان أولًا.' };

    const r = _buildAndPushCar(owner, draft.data, MEMBER_CAR_STATUS.ACTIVE);
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };   // المسودة والمكافأة تبقيان: يمكن إعادة المحاولة
    delete _drafts[draftId];
    RewardService.consumeReward(draftId); // منع استخدام نفس المكافأة لنشر سيارة أخرى
    return { ok: true, car: r.item, persisted: r.persisted };
  }

  /** إلغاء مسودة (المستخدم أغلق الشاشة/ألغى قبل اكتمال الإعلان) — لا نشر، يمكن المحاولة لاحقًا بمسودة جديدة */
  function discardDraft(draftId) { delete _drafts[draftId]; }

  /** تعديل إعلان — يتحقق من الملكية عبر authorizationService، لا يثق بأي ownerId قادم من data */
  function updateMemberCar(id, data) {
    const car = getMemberCarById(id);
    if (!car) return { ok: false, error: 'الإعلان غير موجود.' };
    if (!AuthorizationService.canEditMemberCar(undefined, car)) return { ok: false, error: 'لا تملك صلاحية تعديل هذا الإعلان.' };

    // قيم رقمية غير صالحة تُرفض بدل أن تُخزَّن NaN فتظهر للمستخدم (المرحلة 8)
    for (const f of ['year', 'price', 'mileage']) {
      if (data[f] === undefined || data[f] === '') continue;
      const n = parseWholeNumber(data[f]);
      if (isNaN(n) || (f === 'year' && (n < 1980 || n > 2100)) || (f === 'price' && n <= 0)) {
        return { ok: false, error: f === 'year' ? 'سنة الصنع غير صحيحة.' : f === 'price' ? 'السعر غير صحيح.' : 'الكيلومترات غير صحيحة.' };
      }
    }
    if (data.phone !== undefined && data.phone !== '' && !normalizePhone(data.phone)) return { ok: false, error: PHONE_ERROR };
    if (data.whatsapp !== undefined && data.whatsapp !== '' && !_whatsapp(data.whatsapp)) return { ok: false, error: WHATSAPP_ERROR };
    if (data.currency !== undefined && data.currency !== '' && !parseCurrency(data.currency).ok) return { ok: false, error: 'عملة السعر غير صحيحة. اختر الدينار العراقي أو الدولار الأمريكي.' };
    const editable = ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType',
      'color', 'description', 'mainImage', 'phone', 'whatsapp', 'location', 'latitude', 'longitude'];
    const patch = {};
    // الموديل يُوحَّد داخل ماركته (الجديدة إن عُدّلت، وإلا الحالية) — توحيد الكتابة (Toyota = toyota)
    const brandForModel = (data.brand !== undefined && data.brand !== '') ? data.brand : car.brand;
    editable.forEach(f => {
      if (data[f] === undefined || data[f] === '') return;
      patch[f] = (f === 'year' || f === 'price' || f === 'mileage') ? parseWholeNumber(data[f])
        : f === 'currency' ? parseCurrency(data[f]).value
        : f === 'phone' ? normalizePhone(data[f]) : f === 'whatsapp' ? _whatsapp(data[f])
        : f === 'brand' ? CarFilters.canonicalBrand(data[f]) : f === 'model' ? CarFilters.canonicalModel(data[f], brandForModel) : data[f];
    });
    if ('brand' in patch && !patch.brand) return { ok: false, error: 'اسم الماركة غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
    if ('model' in patch && !patch.model) return { ok: false, error: 'اسم الموديل غير صحيح (يجب أن يحوي حروفًا أو أرقامًا).' };
    patch.updatedAt = new Date().toISOString();
    const r = MemberCarsRepository.update(id, patch);
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, car: r.item, persisted: r.persisted };
  }

  /** حذف إعلان — يتحقق من الملكية أولًا */
  function deleteMemberCar(id) {
    const car = getMemberCarById(id);
    if (!car) return { ok: false, error: 'الإعلان غير موجود.' };
    if (!AuthorizationService.canDeleteMemberCar(undefined, car)) return { ok: false, error: 'لا تملك صلاحية حذف هذا الإعلان.' };
    const r = MemberCarsRepository.remove(id);   // يسجّل الحذف صراحةً (قبل حفظ المصفوفة) ويحفظ
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    FavoritesRepository.removeByCar(id);                                  // لا مفضلة يتيمة (والمعرّف لا يُعاد أصلًا)
    if (typeof removeAllCarImages === 'function') removeAllCarImages(id); // تنظيف صور الإعلان المحذوف (المرحلة 7)
    return { ok: true, persisted: r.persisted };
  }

  /** تغيير الحالة — المالك: active/sold فقط. المدير: أي حالة من الخمس (pending تبقى مدعومة للبيانات القديمة/إدارة المدير).
      meta (اختياري، للمدير فقط): { reason } تُخزَّن في rejectionReason أو suspensionReason حسب الحالة الجديدة. */
  function changeMemberCarStatus(id, status, meta = {}) {
    const car = getMemberCarById(id);
    if (!car) return { ok: false, error: 'الإعلان غير موجود.' };
    if (!AuthorizationService.canChangeMemberCarStatus(undefined, car)) return { ok: false, error: 'لا تملك صلاحية تغيير حالة هذا الإعلان.' };

    const isAdmin = AuthorizationService.canAccessAdmin();
    // (الجزء 6.1) القرار الإداري لا يتجاوزه المالك: إعلان قيد المراجعة/مرفوض/موقوف لا يغيّر المالك حالته (لا إعادة تفعيل ذاتية).
    // المالك يبدّل فقط بين «نشط» و«مباع» لإعلان حالته الحالية نشط أو مباع.
    if (!isAdmin && car.status !== MEMBER_CAR_STATUS.ACTIVE && car.status !== MEMBER_CAR_STATUS.SOLD) {
      return { ok: false, error: 'لا يمكنك تغيير حالة هذا الإعلان لأنه ليس نشطًا بقرار إداري أو ما زال قيد المراجعة. تواصل مع الإدارة.' };
    }
    const allowed = isAdmin
      ? Object.values(MEMBER_CAR_STATUS)
      : [MEMBER_CAR_STATUS.ACTIVE, MEMBER_CAR_STATUS.SOLD]; // المالك (غير المدير) محصور بهاتين الحالتين
    if (!allowed.includes(status)) return { ok: false, error: 'لا يمكنك تعيين هذه الحالة.' };

    const patch = { status, updatedAt: new Date().toISOString() };
    if (isAdmin) {
      // بيانات مراجعة إدارية (المرحلة 5) — لا تُسجَّل عند تغيير المالك حالته بنفسه
      const admin = SessionService.getCurrentUser();
      patch.reviewedAt = patch.updatedAt;
      patch.reviewedBy = admin ? admin.id : car.reviewedBy;
      if (status === MEMBER_CAR_STATUS.REJECTED) patch.rejectionReason = meta.reason || car.rejectionReason || '';
      if (status === MEMBER_CAR_STATUS.SUSPENDED) patch.suspensionReason = meta.reason || car.suspensionReason || '';
    }
    const r = MemberCarsRepository.update(id, patch);
    if (!r.ok) return { ok: false, error: repoErrorText(r.error) };
    return { ok: true, car: r.item, persisted: r.persisted };
  }

  return {
    loadFromStorage, getMemberCars, getActiveMemberCars, getPendingMemberCars,
    getMemberCarsByOwner, getMemberCarById, createDraftMemberCar, publishMemberCarAfterReward,
    discardDraft, updateMemberCar, deleteMemberCar, changeMemberCarStatus
  };
})();

/* اختصارات على مستوى عام (نفس أسلوب باقي الخدمات في المشروع مثل favoritesService) */
function getMemberCars() { return MemberCarsService.getMemberCars(); }
function getActiveMemberCars() { return MemberCarsService.getActiveMemberCars(); }
function getPendingMemberCars() { return MemberCarsService.getPendingMemberCars(); }
function getMemberCarsByOwner(ownerId) { return MemberCarsService.getMemberCarsByOwner(ownerId); }
function getMemberCarById(id) { return MemberCarsService.getMemberCarById(id); }
function createDraftMemberCar(data) { return MemberCarsService.createDraftMemberCar(data); }
function publishMemberCarAfterReward(draftId) { return MemberCarsService.publishMemberCarAfterReward(draftId); }
function discardMemberCarDraft(draftId) { return MemberCarsService.discardDraft(draftId); }
function updateMemberCar(id, data) { return MemberCarsService.updateMemberCar(id, data); }
function deleteMemberCar(id) { return MemberCarsService.deleteMemberCar(id); }
function changeMemberCarStatus(id, status, meta) { return MemberCarsService.changeMemberCarStatus(id, status, meta); }
function loadMemberCars() { MemberCarsService.loadFromStorage(); }

/* شريط الفلاتر المشترك (سيارات المعارض / سيارات الأعضاء / البحث الموحّد): واجهة فقط.
   كل منطق التصفية والخيارات الديناميكية في CarFilters (services/carFilterService.js) — لا مقارنات هنا.
   الحقول: ماركة، موديل (مرتبط بالماركة)، سنة، سعر من–إلى، كيلومترات من–إلى. بلا قوائم ثابتة ولا سقف.
   prefix: 'cars' | 'member' | 'search' — معرّفات الحقول: <prefix>FilterBrand/Model/Year/MinPrice/MaxPrice/MinMileage/MaxMileage */
function newFilters() { return { brand: '', model: '', year: '', minPrice: '', maxPrice: '', priceCurrency: '', minMileage: '', maxMileage: '' }; }   // priceCurrency فارغة = الدينار (عملة البحث)
function activeFilterCount(f) { return CarFilters.activeCount(f); }
function applyCarFilters(list, f) { return CarFilters.apply(list, f); }

/** قراءة قيم الحقول من الصفحة (النصوص كما كتبها المستخدم؛ التحقق في CarFilters) */
function readFilters(prefix) {
  const f = { brand: _val(prefix + 'FilterBrand'), model: _val(prefix + 'FilterModel'), year: _val(prefix + 'FilterYear'),
    minPrice: _val(prefix + 'FilterMinPrice'), maxPrice: _val(prefix + 'FilterMaxPrice'),
    minMileage: _val(prefix + 'FilterMinMileage'), maxMileage: _val(prefix + 'FilterMaxMileage') };
  const cur = _val(prefix + 'PriceCurrency');       // عملة البحث: قائمة بلا خيار فارغ، فالقيمة موجودة دائمًا في المتصفح (تُهمَل إن غاب العنصر)
  if (cur) f.priceCurrency = cur;
  return f;
}

/** الشارات والتنبيهات تحت الحقول (تُحدَّث وحدها عند الكتابة في حقول الأرقام كي لا يضيع التركيز).
    شارة لكل فلتر فعّال (CarFilters.chips)؛ ضغطها يزيل فلترها وحده عبر onRemove(key) (الحالة هي حالة الشاشة نفسها، لا نسخة ثانية)،
    و«مسح الفلاتر» يمسح الكل. onRemove اختياري: بدونه تُعرض الشارات نصًّا فقط. */
function FilterChips(prefix, opts, f, onClear, onRemove) {
  const chips = CarFilters.chips(f), c = CarFilters.normalize(f);
  const notes = CarFilters.validate(f);
  if ((c.minPrice !== null || c.maxPrice !== null) && opts && opts.unknownPrice > 0) {
    notes.push(`${opts.unknownPrice} سيارة بدون سعر محدد لا تظهر عند فلترة السعر.`);
  }
  if ((c.minMileage !== null || c.maxMileage !== null) && opts && opts.unknownMileage > 0) {
    notes.push(`${opts.unknownMileage} سيارة بدون مسافة معلومة لا تظهر عند فلترة الكيلومترات.`);
  }
  const chip = k => onRemove
    ? `<button type="button" class="filter-chip" aria-label="${esc('إزالة فلتر ' + k.field + ': ' + k.label)}" onclick="${onRemove}('${k.key}')"><span>${esc(k.label)}</span> <span aria-hidden="true">✕</span></button>`
    : `<span class="filter-chip">${esc(k.label)}</span>`;
  return `
  ${chips.length ? `<div class="active-filters" role="group" aria-label="الفلاتر الفعالة"><span class="af-title">🔎 فلاتر فعالة (${chips.length}):</span>
    ${chips.map(chip).join('')}
    <button type="button" class="link-btn" onclick="${onClear}()">مسح الفلاتر</button></div>` : ''}
  ${notes.map(m => `<p class="filter-note">${esc(m)}</p>`).join('')}`;
}

function _filterSelect(id, placeholder, items, current, onChange, disabled) {
  const has = items.some(i => CarFilters.sameKey(i.value, current));
  const stale = (current && !has) ? `<option value="${esc(current)}" selected>${esc(current)} (غير متاح)</option>` : '';   // القيمة المحدّدة تبقى ظاهرة
  return `<select id="${id}" onchange="${onChange}()" ${disabled ? 'disabled' : ''}>
      <option value="">${placeholder}</option>${stale}
      ${items.map(i => `<option value="${esc(i.value)}" ${has && CarFilters.sameKey(i.value, current) ? 'selected' : ''}>${esc(i.label)}</option>`).join('')}
    </select>`;
}

/* ---- اقتراحات السعر والكيلومترات (الجزء 5.1): طبقة راحة فقط فوق حقول من/إلى القائمة ----
   - لا حالة ولا بحث ولا تصفية هنا: اختيار اقتراح يكتب قيمتي «من/إلى» في الحقلين القائمين ثم يستدعي معالج النطاق القائم للشاشة
     (onCarsRange/onMemberCarsRange/onSearchRange ← readFilters ← CarFilters)، فالشارات والنتائج والتحقق كلها بالمسار نفسه.
   - لا يُخزَّن الاختيار في أي مكان؛ يُشتقّ تمييز الاقتراح الحالي من قيمتي الحقلين فقط (ومسح الفلاتر يمسح الحقلين فيزول).
   - الاقتراحات ليست حدودًا: الحقول تقبل أي رقم صالح (لا سقف للسعر ولا للكيلومترات)، والاقتراح المفتوح من أعلى يترك «إلى» فارغًا.
   - الأرقام بالملايين/الآلاف ثم تُضرب بالوحدة (لا قائمة أسعار مكتوبة بالأرقام الكاملة).
   - (الجزء 5.2) اقتراحات السعر تتبع «عملة البحث»: ملايين الدنانير للدينار، وآلاف الدولارات للدولار. تغيير العملة يعيد رسم الشريط (onChange القائم)
     فتتبدّل اللوحة؛ والقيم المكتوبة في الحقلين تبقى وتُفسَّر بالعملة الجديدة (يوضّحها الوسم والشارة). لا تحويل للقيم المكتوبة. */
const FILTER_PRESETS = {
  Price:   { title: 'السعر',       unit: 1e6, ranges: [[null, 10], [10, 20], [20, 30], [30, 40], [40, 60], [60, 100], [100, null]] },      // بالملايين (د.ع): عملة البحث الدينار
  PriceUSD: { title: 'السعر',      unit: 1e3, ranges: [[null, 5], [5, 10], [10, 15], [15, 20], [20, 30], [30, 50], [50, null]] },          // بالآلاف ($): عملة البحث الدولار (الجزء 5.2)      // بالملايين (د.ع)
  Mileage: { title: 'الكيلومترات', unit: 1e3, ranges: [[0, 10], [10, 30], [30, 50], [50, 100], [100, 150], [150, 200], [200, null]] },      // بالآلاف
};
/** مجموعة الاقتراحات للحقل وعملة البحث: السعر بالدولار له مجموعته (لا تُعاد نطاقات الملايين الدينارية على الدولار)؛ الكيلومترات لا علاقة لها بالعملة */
function _presetSet(kind, cur) { return kind === 'Price' && cur === CURRENCY.USD ? FILTER_PRESETS.PriceUSD : FILTER_PRESETS[kind]; }
function _presetBounds(kind, r, cur) { const u = _presetSet(kind, cur).unit; return [r[0] === null ? null : r[0] * u, r[1] === null ? null : r[1] * u]; }
/** نص الاقتراح بنفس صيغة الشارات (أرقام ar-IQ): «أقل من ١٠ مليون» / «١٠–٢٠ مليون» / «١٠٠ مليون فأكثر» / «٥٠٬٠٠٠–١٠٠٬٠٠٠ كم» / «٢٠٠٬٠٠٠ كم فأكثر» */
function _presetLabel(kind, r, cur) {
  const b = _presetBounds(kind, r, cur), lo = b[0], hi = b[1], n = x => Number(x).toLocaleString('ar-IQ');
  if (kind === 'Price' && cur === CURRENCY.USD) { const u = x => formatAmount(x, CURRENCY.USD); return lo === null ? `أقل من ${u(hi)}` : (hi === null ? `${u(lo)} فأكثر` : `\u2066${u(lo)}–${u(hi)}\u2069`); }
  if (kind === 'Price') return lo === null ? `أقل من ${n(hi / 1e6)} مليون` : (hi === null ? `${n(lo / 1e6)} مليون فأكثر` : `${n(lo / 1e6)}–${n(hi / 1e6)} مليون`);
  return hi === null ? `${n(lo)} كم فأكثر` : `${n(lo)}–${n(hi)} كم`;
}
/** هل الاقتراح هو النطاق الحالي تمامًا؟ c = CarFilters.normalize(...) */
function _presetActive(c, kind, lo, hi) { return c['min' + kind] === lo && c['max' + kind] === hi; }

/** لوحة اقتراحات مرتبطة بحقلي نطاق واحد (kind = 'Price' | 'Mileage')، مخفية حتى يُنقَر الحقل. onRange = اسم معالج النطاق القائم للشاشة. */
function FilterSuggestions(prefix, kind, onRange, f) {
  const c = CarFilters.normalize(f), cur = kind === 'Price' ? (c.priceCurrency || CURRENCY_LEGACY_DEFAULT) : '', P = _presetSet(kind, cur), lit = v => `'${v === null ? '' : v}'`;   // بلا حد = نص فارغ (لا تظهر الكلمة null في HTML)
  const opts = P.ranges.map(r => {
    const b = _presetBounds(kind, r, cur), lo = b[0], hi = b[1], on = _presetActive(c, kind, lo, hi), label = _presetLabel(kind, r, cur);
    return `<button type="button" class="sugg-opt" data-min="${lo === null ? '' : lo}" data-max="${hi === null ? '' : hi}" aria-pressed="${on ? 'true' : 'false'}" aria-label="${esc('اقتراح ' + P.title + ': ' + label)}" onmousedown="event.preventDefault()" onclick="applyFilterPreset('${prefix}','${kind}',${lit(lo)},${lit(hi)},${onRange},event)"><span class="sugg-check" aria-hidden="true"${on ? '' : ' hidden'}>✓</span>${esc(label)}</button>`;
  }).join('');
  return `<div class="flt-sugg" id="${prefix}Sugg${kind}" role="group" aria-label="${esc('اقتراحات ' + P.title)}" hidden>${opts}<button type="button" class="sugg-opt sugg-custom" aria-label="${esc('إدخال ' + P.title + ' مخصص')}" onclick="focusFilterCustom('${prefix}','${kind}')">إدخال مخصص</button></div>`;
}

let _suggSuppress = false;   // يمنع فتح اللوحة عند إعادة التركيز البرمجي لحقل «من» (إدخال مخصص / Escape / تفعيل بلوحة المفاتيح)
function _setFieldValue(id, v) { const el = document.getElementById(id); if (el) el.value = (v === null || v === undefined) ? '' : String(v); }
function _focusFilterField(prefix, kind) {
  const el = document.getElementById(prefix + 'FilterMin' + kind);
  if (el && typeof el.focus === 'function') { _suggSuppress = true; try { el.focus(); } finally { _suggSuppress = false; } }
}
/** هل نافذة اقتراحات سعر/كيلومترات مفتوحة الآن؟ (قراءة فقط: للشاشات التي تعالج Escape كي لا تطوي لوحتها قبل أن تُغلق النافذة المفتوحة) */
function filterPopupOpen() { return typeof document.querySelector === 'function' && !!document.querySelector('.flt-sugg:not([hidden])'); }
function closeFilterSuggestions() {
  if (typeof document.querySelectorAll !== 'function') return;
  const open = document.querySelectorAll('.flt-sugg:not([hidden])');
  for (let i = 0; i < open.length; i++) open[i].hidden = true;
}
/** يحدّث تمييز الاقتراح الحالي من قيمتي الحقلين الآن (عبر CarFilters.normalize: الأرقام العربية/الفواصل كما في المحرك) */
function _syncPresetState(prefix, kind) {
  const el = document.getElementById(prefix + 'Sugg' + kind);
  if (!el || typeof el.querySelectorAll !== 'function') return;
  const raw = {}; raw['min' + kind] = _val(prefix + 'FilterMin' + kind); raw['max' + kind] = _val(prefix + 'FilterMax' + kind);
  const c = CarFilters.normalize(raw), btns = el.querySelectorAll('[data-min]');
  for (let i = 0; i < btns.length; i++) {
    const b = btns[i], lo = b.getAttribute('data-min'), hi = b.getAttribute('data-max');
    const on = _presetActive(c, kind, lo === '' ? null : Number(lo), hi === '' ? null : Number(hi));
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    const chk = b.querySelector('.sugg-check'); if (chk) chk.hidden = !on;
  }
}
function openFilterSuggestions(prefix, kind) {
  if (_suggSuppress) return;
  const el = document.getElementById(prefix + 'Sugg' + kind); if (!el) return;
  closeFilterSuggestions(); _syncPresetState(prefix, kind); el.hidden = false;
  // لا تختفي اللوحة خلف لوحة مفاتيح الهاتف. مؤجَّل: التمرير الفوري أثناء التركيز يُزيح الحقل من تحت الإصبع قبل وصول «النقرة» فتُحسب نقرة خارجية وتُغلق اللوحة
  setTimeout(() => { if (!el.hidden && typeof el.scrollIntoView === 'function') el.scrollIntoView({ block: 'nearest' }); }, 60);
}
/** اختيار اقتراح: يكتب الحقلين القائمين ثم يستدعي معالج النطاق القائم (لا حالة ثانية). '' = بلا حد (الحقل يُفرَّغ). ev اختياري (تفعيل بلوحة المفاتيح ← detail=0). */
function applyFilterPreset(prefix, kind, lo, hi, onRange, ev) {
  _setFieldValue(prefix + 'FilterMin' + kind, lo); _setFieldValue(prefix + 'FilterMax' + kind, hi);
  closeFilterSuggestions();
  if (typeof onRange === 'function') onRange();
  if (ev && ev.detail === 0) _focusFilterField(prefix, kind);                                  // لوحة المفاتيح: لا يضيع التركيز
  else if (document.activeElement && typeof document.activeElement.blur === 'function' && document.activeElement.getAttribute && document.activeElement.getAttribute('data-sugg')) document.activeElement.blur();   // اللمس: تُغلق لوحة مفاتيح الهاتف
}
/** «إدخال مخصص»: تُغلق اللوحة ويُركَّز حقل «من» للكتابة الحرة */
function focusFilterCustom(prefix, kind) { closeFilterSuggestions(); _focusFilterField(prefix, kind); }

/* الإغلاق: نقرة/تركيز خارج الحقلين واللوحة، Escape (ويعيد التركيز لحقل «من» إن كان داخل اللوحة)، Enter في حقل الرقم. تُسجَّل مرة واحدة. */
(function bindFilterSuggestionDismiss() {
  if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return;
  const inside = t => !!(t && typeof t.closest === 'function' && (t.closest('.flt-sugg') || t.closest('[data-sugg]')));
  /* (الجزء 6.2-A) بالفأرة: الضغط على حقل «الكيلومترات» وفي الأعلى لوحة السعر مفتوحة يطويها (التركيز يفتح لوحة الكيلومترات ويغلق السعر) فيتحرك الحقل لأعلى بين الضغط والرفع،
     فتصل النقرة إلى عنصر أب خارجي وتُغلق اللوحتان معًا. النقرة التي بدأ ضغطها داخل اللوحة/الحقل لا تُعتبر نقرة خارجية. */
  let downInside = false;
  document.addEventListener('pointerdown', e => { downInside = inside(e.target); }, true);
  document.addEventListener('click', e => { const keep = downInside; downInside = false; if (!inside(e.target) && !keep) closeFilterSuggestions(); });
  document.addEventListener('focusin', e => { if (!inside(e.target)) closeFilterSuggestions(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      const open = document.querySelector('.flt-sugg:not([hidden])'); if (!open) return;
      const ae = document.activeElement, was = !!(ae && typeof ae.closest === 'function' && ae.closest('.flt-sugg'));
      closeFilterSuggestions();
      const m = /^(.*)Sugg(Price|Mileage)$/.exec(open.id || ''); if (was && m) _focusFilterField(m[1], m[2]);
    } else if (e.key === 'Enter' && e.target && typeof e.target.getAttribute === 'function' && e.target.getAttribute('data-sugg')) closeFilterSuggestions();
  });
})();

/** opts = CarFilters.options(pool, f). onChange: قوائم الاختيار (تعيد رسم الشريط)، onRange: حقول الأرقام (تحدّث القائمة والشارات فقط)،
    onRemove: اسم دالة إزالة فلتر واحد بمفتاحه (شارات قابلة للإزالة) */
function FilterBar(prefix, opts, f, onChange, onClear, onRange, onRemove) {
  // كل حقل بتسمية ظاهرة فوقه (تبقى بعد الكتابة، فلا يضيع «من/إلى» حين يختفي الـplaceholder). الـplaceholder «بلا حد …» يؤكد عدم وجود سقف.
  const fld = (label, control, wide) => `<label class="flt${wide ? ' wide' : ''}"><span class="flt-l">${label}</span>${control}</label>`;
  const rangeFn = onRange || onChange;
  const priceCur = CarFilters.normalize(f).priceCurrency || CURRENCY_LEGACY_DEFAULT;   // عملة البحث (غير المحدّدة = الدينار)
  const num = (id, label, ph, v, kind) => fld(label, `<input id="${prefix}Filter${id}" type="text" inputmode="numeric" dir="ltr" placeholder="${ph}" value="${esc(v)}" onchange="${rangeFn}()" onkeydown="if(event.key==='Enter')this.blur()"${kind ? ` data-sugg="${kind}" onfocus="openFilterSuggestions('${prefix}','${kind}')" onclick="openFilterSuggestions('${prefix}','${kind}')"` : ''}>`);
  const years = opts.years.map(y => ({ value: String(y), label: String(y) }));
  const yearCur = f.year === undefined || f.year === null ? '' : String(f.year);
  const yearHas = !yearCur || years.some(y => y.value === yearCur);
  return `
  <div class="filters-grid">
    ${fld('الماركة', _filterSelect(prefix + 'FilterBrand', 'كل الماركات', opts.brands, f.brand, onChange, false))}
    ${fld('الموديل', _filterSelect(prefix + 'FilterModel', f.brand ? 'كل الموديلات' : 'اختر الماركة أولًا', opts.models, f.model, onChange, !f.brand))}
    ${fld('السنة', `<select id="${prefix}FilterYear" onchange="${onChange}()">
      <option value="">كل السنوات</option>${yearHas ? '' : `<option value="${esc(yearCur)}" selected>${esc(yearCur)} (غير متاح)</option>`}
      ${years.map(y => `<option value="${y.value}" ${yearCur === y.value ? 'selected' : ''}>${y.label}</option>`).join('')}
    </select>`, true)}
    <div class="flt wide"><label class="flt-l" for="${prefix}PriceCurrency">عملة البحث</label><select id="${prefix}PriceCurrency" onchange="${onChange}()">${currencyOptionsHtml(priceCur)}</select></div>
    ${num('MinPrice', `السعر من (${CURRENCY_SHORT[priceCur]})`, 'بلا حد أدنى', f.minPrice, 'Price')}
    ${num('MaxPrice', `السعر إلى (${CURRENCY_SHORT[priceCur]})`, 'بلا حد أقصى', f.maxPrice, 'Price')}
    ${FilterSuggestions(prefix, 'Price', rangeFn, f)}
    ${num('MinMileage', 'الكيلومترات من', 'بلا حد أدنى', f.minMileage, 'Mileage')}
    ${num('MaxMileage', 'الكيلومترات إلى', 'بلا حد أقصى', f.maxMileage, 'Mileage')}
    ${FilterSuggestions(prefix, 'Mileage', rangeFn, f)}
  </div>
  <div id="${prefix}FilterChips">${FilterChips(prefix, opts, f, onClear, onRemove)}</div>`;
}

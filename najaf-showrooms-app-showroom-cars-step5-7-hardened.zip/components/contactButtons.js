/* أزرار التواصل: اتصال / واتساب / الموقع. يظهر كل زر فقط إن كانت بياناته صالحة،
   فلا زر برابط فارغ ولا أرقام وهمية. روابط <a> عادية تعمل على الهاتف (tel: و wa.me وخرائط). */
function ContactButtons({ phone, whatsapp, lat, lng } = {}) {
  const call = telLink(phone), wa = waLink(whatsapp), map = mapLink(lat, lng);
  const btns = [
    call ? `<a class="action-btn call" href="${call}">📞 اتصال</a>` : '',
    wa ? `<a class="action-btn whatsapp" href="${wa}" target="_blank" rel="noopener">💬 واتساب</a>` : '',
  ].filter(Boolean);
  const mapBtn = map ? `<a class="action-btn" style="margin-top:10px" href="${map}" target="_blank" rel="noopener">📍 الموقع على الخريطة</a>` : '';
  if (!btns.length && !mapBtn) return '';
  return `<div class="contact-block">${btns.length ? `<div class="action-grid"${btns.length === 1 ? ' style="grid-template-columns:1fr"' : ''}>${btns.join('')}</div>` : ''}${mapBtn}</div>`;
}

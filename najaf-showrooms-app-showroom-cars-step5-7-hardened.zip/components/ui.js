/* مكوّنات واجهة مشتركة (المرحلة 8): حالة فارغة، شريط رجوع، رسالة عابرة (Toast)، شاشة خطأ */

/** حالة فارغة مفسَّرة بزر مناسب. actions: [{label, onclick, primary}] */
function EmptyState({ icon = '🔍', title, hint = '', actions = [], heading = false }) {
  // heading: الحالة هي «محتوى الشاشة كله» (غير موجود/غير متاح) فتكون عنوانها الأول لقارئ الشاشة بلا تغيير في الشكل (الجزء 6.2-B)
  return `
  <div class="placeholder"><span class="ic" aria-hidden="true">${icon}</span><b${heading ? ' role="heading" aria-level="1"' : ''}>${esc(title)}</b>
    ${hint ? `<p class="sub" style="margin:6px 0 0">${esc(hint)}</p>` : ''}
    ${actions.map(a => `<button class="${a.primary === false ? 'link-btn' : 'btn-primary'}" onclick="${a.onclick}">${esc(a.label)}</button>`).join('')}
  </div>`;
}

/** شريط رجوع: يعود للشاشة السابقة فعليًا، وإن لم توجد يذهب إلى fallback */
function BackBar(fallback = 'home', plain = true) {
  return `<div class="back-btn${plain ? ' plain' : ''}"><button class="back-circle" aria-label="رجوع" onclick="goBack('${fallback}')">→</button></div>`;
}

function ErrorState() {
  return EmptyState({ icon: '⚠️', title: 'حدث خطأ، حاول مرة أخرى', hint: 'إن تكرر الخطأ فأعد فتح التطبيق.',
    actions: [{ label: 'إعادة المحاولة', onclick: 'render()' }, { label: 'العودة للرئيسية', onclick: "go('home')", primary: false }] });
}

let _toastTimer = null;
/** رسالة عابرة بنص عربي واضح (تُنقّى من أي نص تقني). لا تحجب الواجهة مثل alert. */
function notify(msg, kind) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = userMsg(msg);
  el.className = 'toast ' + (kind || '');
  el.style.display = 'block';
  if (typeof clearTimeout === 'function') clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { el.style.display = 'none'; }, 3200);
}

/* تنبيه الحفظ (المرحلة 9): العملية نجحت في الذاكرة لكن تعذّر حفظها على الجهاز (مساحة ممتلئة/تخزين غير متاح).
   رسالة عربية غير تقنية، حتى لا يضيع التغيير بصمت. r = نتيجة خدمة فيها persisted. */
const NOT_SAVED_MSG = 'تعذّر حفظ التغييرات على جهازك؛ قد تختفي عند إغلاق التطبيق.';
function warnIfNotSaved(r) {
  if (r && r.ok && r.persisted === false) { notify(NOT_SAVED_MSG, 'error'); return true; }
  return false;
}
/** صور لم تُحفظ فعلًا (IndexedDB ممتلئ/غير متاح): السيارة نُشرت لكن بعض الصور لا. r = نتيجة commitImageDraft أو createShowroomCar */
function warnImagesNotSaved(r) {
  if (r && r.failed > 0 || r && r.imagesFailed > 0) { notify('تم النشر، لكن تعذّر حفظ بعض الصور (مساحة التخزين ممتلئة أو غير متاحة).', 'error'); return true; }
  return false;
}
/** رسالة نجاح، أو تنبيه الحفظ بدلها إن لم يُحفظ التغيير */
function notifySaved(msg, r) { if (!warnIfNotSaved(r)) notify(msg); }


/* ==========================================================================
   (الجزء 6.2-B) إدارة التركيز في النوافذ + نوافذ حوار داخل التطبيق
   ModalFocus: نقل التركيز إلى النافذة عند فتحها، حبس Tab داخلها، Escape للإغلاق (إن وُجد معالج)، وإعادة التركيز لما كان قبلها عند إغلاقها.
     مستمع keydown واحد يُربط مرة واحدة فقط (لا تراكم مستمعين مهما تكرر الفتح).
   AppDialog + askConfirm/askChoice/askText: بديل مرئي مفهوم لـconfirm()/prompt() الأصليتين (كتابة رموز إنجليزية مثل active/sold في prompt كانت تجربة سيئة
     وغير واضحة على الهاتف). نفس السلوك والصلاحيات تمامًا: المعالجات تستدعي الخدمات نفسها وتتحقق منها كما كانت.
     عند غياب واجهة DOM (اختبارات Node بلا عنصر #dialogRoot حقيقي) تعود الدوال تلقائيًا إلى confirm()/prompt() الأصليتين بالنص والسلوك السابقين حرفيًا.
   ========================================================================== */
const ModalFocus = (function () {
  let _a = null;            // { overlay, box, opener, onEscape }
  let _bound = false;
  const _FOCUSABLE = 'button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])';
  const _shown = e => !!e && !e.disabled && (typeof e.getClientRects !== 'function' || e.getClientRects().length > 0);
  const _items = root => (root && typeof root.querySelectorAll === 'function') ? Array.from(root.querySelectorAll(_FOCUSABLE)).filter(_shown) : [];
  function _focus(e) { try { if (e && typeof e.focus === 'function') { e.focus({ preventScroll: true }); return true; } } catch (err) { /* لا استثناء من التركيز */ } return false; }

  function onKey(ev) {
    if (!_a || !ev) return;
    if (ev.key === 'Escape') {
      if (typeof _a.onEscape === 'function') { if (typeof ev.preventDefault === 'function') ev.preventDefault(); if (typeof ev.stopPropagation === 'function') ev.stopPropagation(); _a.onEscape(); }
      return;
    }
    if (ev.key !== 'Tab') return;
    const items = _items(_a.overlay);
    if (!items.length) { if (typeof ev.preventDefault === 'function') ev.preventDefault(); _focus(_a.box); return; }
    const first = items[0], last = items[items.length - 1];
    const cur = (typeof document !== 'undefined') ? document.activeElement : null;
    const inside = items.indexOf(cur) >= 0;
    if (ev.shiftKey && (cur === first || !inside)) { ev.preventDefault(); _focus(last); }
    else if (!ev.shiftKey && (cur === last || !inside)) { ev.preventDefault(); _focus(first); }
  }
  function _bind() {
    if (_bound) return;
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') { document.addEventListener('keydown', onKey, true); _bound = true; }
  }
  /** يفعّل الحبس على overlay. opts: { onEscape, initial (محدِّد العنصر الأول) } */
  function activate(overlay, opts = {}) {
    if (!overlay) return false;
    _bind();
    const opener = (typeof document !== 'undefined' && document.activeElement) || null;
    const box = (typeof overlay.querySelector === 'function' && overlay.querySelector('.modal-box')) || overlay;
    if (box && typeof box.setAttribute === 'function') box.setAttribute('tabindex', '-1');   // يستقبل التركيز إن خلت النافذة من عناصر قابلة للتركيز
    _a = { overlay, box, opener, onEscape: opts.onEscape };
    const init = (opts.initial && typeof overlay.querySelector === 'function') ? overlay.querySelector(opts.initial) : null;
    if (!_focus(init)) { const it = _items(overlay); if (!_focus(it[0])) _focus(box); }
    return true;
  }
  /** تغيّرت خطوة داخل النافذة (اختفى الزر المضغوط فضاع التركيز): أعد التركيز لأول عنصر قابل للتركيز فيها، وإلا للنافذة نفسها */
  function refocus(opts) {
    if (!_a) return false;
    if (opts && opts.box) return _focus(_a.box);          // التركيز على النافذة نفسها (يُقرأ عنوانها) لا على زر قابل للضغط: Enter/Space المتكرران لا يضغطان «إلغاء» بالخطأ
    const it = _items(_a.overlay); return _focus(it[0]) || _focus(_a.box);
  }
  /** إغلاق: يُعيد التركيز إلى العنصر الذي فتح النافذة إن بقي في الصفحة، وإلا إلى محتوى الشاشة */
  function deactivate() {
    const o = _a && _a.opener; _a = null;
    const alive = o && typeof document !== 'undefined' && typeof document.contains === 'function' && document.contains(o);
    if (alive && _focus(o)) return;
    if (typeof document !== 'undefined' && typeof document.getElementById === 'function') _focus(document.getElementById('screen'));
  }
  /** تنقّل الشاشة: تُمحى الحالة بلا إعادة تركيز (العنصر القديم لم يعد موجودًا) */
  function reset() { _a = null; }
  const isActive = () => !!_a;
  return { activate, refocus, deactivate, reset, isActive, onKey };
})();

const AppDialog = (function () {
  let _open = null;         // { spec, onOk, onCancel }
  let _seq = 0;
  const host = () => (typeof document !== 'undefined' && typeof document.getElementById === 'function') ? document.getElementById('dialogRoot') : null;
  const canRender = h => !!h && typeof h.querySelector === 'function';

  function html(spec, id) {
    const T = 'dlgTitle' + id, M = 'dlgMsg' + id;
    const msg = spec.message ? `<p class="sub dlg-msg" id="${M}">${esc(spec.message)}</p>` : '';
    const cancel = `<button type="button" class="link-btn dlg-cancel" data-dlg="cancel">${esc(spec.cancelLabel || 'إلغاء')}</button>`;
    let body = '', actions = '';
    if (spec.kind === 'choose') {
      body = `<div class="dlg-options">${(spec.options || []).map(o => `<button type="button" class="dlg-option" aria-pressed="${o.value === spec.current ? 'true' : 'false'}" data-dlg-value="${esc(o.value)}">${esc(o.label)}</button>`).join('')}</div>`;
      actions = cancel;
    } else if (spec.kind === 'prompt') {
      body = `<div class="field dlg-field"><label for="dlgInput${id}">${esc(spec.label || spec.title)}</label>
        <input id="dlgInput${id}" type="text" autocomplete="off" value="${esc(spec.value || '')}"${spec.required ? ' aria-required="true"' : ''} onkeydown="if(event.key==='Enter'){event.preventDefault();AppDialog.ok()}"></div>
        <div id="dlgError${id}" class="form-error" role="alert" style="display:none"></div>`;
      actions = `<button type="button" class="btn-primary dlg-ok" data-dlg="ok">${esc(spec.confirmLabel || 'تأكيد')}</button>${cancel}`;
    } else {
      actions = `<button type="button" class="btn-primary dlg-ok${spec.danger ? ' danger' : ''}" data-dlg="ok">${esc(spec.confirmLabel || 'تأكيد')}</button>${cancel}`;
    }
    return `<div class="modal-overlay dlg-overlay" data-dlg="overlay" onclick="AppDialog.click(event)">
      <div class="modal-box dlg-box" role="${spec.kind === 'confirm' && spec.danger ? 'alertdialog' : 'dialog'}" aria-modal="true" aria-labelledby="${T}"${spec.message ? ` aria-describedby="${M}"` : ''}>
        <p class="modal-title" id="${T}">${esc(spec.title)}</p>${msg}${body}<div class="dlg-actions">${actions}</div>
      </div></div>`;
  }
  function _initial(spec) {
    if (spec.kind === 'choose') return '.dlg-option[aria-pressed="true"], .dlg-option';
    if (spec.kind === 'prompt') return 'input';
    return spec.danger ? '.dlg-cancel' : '.dlg-ok';      // إجراء مدمّر: التركيز الأول على «إلغاء» (Enter العرضي لا يحذف)
  }
  function _close() { const h = host(); if (h) h.innerHTML = ''; ModalFocus.deactivate(); }
  function _finish(kind, val) {
    const o = _open; if (!o) return;
    _open = null; _close();                               // نغلق أولًا ثم ننفّذ (المعالج قد ينتقل لشاشة أخرى)
    if (kind === 'cancel') { if (o.onCancel) o.onCancel(); } else if (o.onOk) o.onOk(val);
  }
  function cancel() { _finish('cancel'); }
  function ok() {
    if (!_open) return;
    const spec = _open.spec;
    if (spec.kind === 'prompt') {
      const h = host(); const input = h && h.querySelector('input'); const v = String(input && input.value || '').trim();
      if (spec.required && !v) {
        const err = h.querySelector('.form-error');
        if (err) { err.textContent = spec.requiredMessage || 'هذا الحقل مطلوب.'; err.style.display = 'block'; }
        if (input) { input.setAttribute('aria-invalid', 'true'); if (typeof input.focus === 'function') input.focus(); }
        return;                                           // تبقى النافذة مفتوحة والتركيز على الحقل
      }
      return _finish('ok', v);
    }
    _finish('ok', true);
  }
  function click(ev) {
    const t = ev && ev.target; if (!_open || !t || typeof t.closest !== 'function') return;
    const el = t.closest('[data-dlg-value],[data-dlg]'); if (!el) return;
    const v = el.getAttribute('data-dlg-value');
    if (v !== null) return _finish('value', v);
    const a = el.getAttribute('data-dlg');
    if (a === 'overlay') { if (t === el) cancel(); }      // الضغط على الخلفية فقط (لا داخل الصندوق)
    else if (a === 'ok') ok(); else if (a === 'cancel') cancel();
  }
  /** يفتح نافذة. يعيد false إن لم تتوفر واجهة DOM (فيعود المستدعي إلى confirm/prompt الأصلية)، وtrue إن فُتحت أو كانت مفتوحة (نقرة ثانية لا تفتح ثانية ولا تنفّذ شيئًا) */
  function open(spec, onOk, onCancel) {
    const h = host();
    if (!canRender(h)) return false;
    if (_open) return true;
    _open = { spec, onOk, onCancel };
    h.innerHTML = html(spec, ++_seq);
    ModalFocus.activate(h.querySelector('.modal-overlay') || h, { onEscape: cancel, initial: _initial(spec) });
    return true;
  }
  /** تنقّل الشاشة أثناء فتح نافذة: تُغلق بلا تنفيذ أي معالج */
  function dismiss() { if (!_open) return; _open = null; const h = host(); if (h) h.innerHTML = ''; ModalFocus.reset(); }
  const isOpen = () => !!_open;
  return { open, dismiss, isOpen, ok, cancel, click, html };
})();

/** تأكيد: onYes عند الموافقة، onNo (اختياري) عند الإلغاء/Escape. بدون واجهة DOM: confirm() الأصلية كما كانت. */
function askConfirm(spec, onYes, onNo) {
  if (AppDialog.open(Object.assign({ kind: 'confirm' }, spec), () => { if (onYes) onYes(); }, () => { if (onNo) onNo(); })) return;
  if (confirm(spec.message || spec.title)) { if (onYes) onYes(); } else if (onNo) onNo();
}
function askConfirmAsync(spec) { return new Promise(res => askConfirm(spec, () => res(true), () => res(false))); }
/** اختيار من قائمة (بدل كتابة رمز في prompt). spec.options: [{value,label}]، current، وللنسخة الاحتياطية nativeMessage/nativeDefault. */
function askChoice(spec, onPick, onNo) {
  if (AppDialog.open(Object.assign({ kind: 'choose' }, spec), v => { if (onPick) onPick(v); }, () => { if (onNo) onNo(); })) return;
  const input = prompt(spec.nativeMessage || spec.title, spec.nativeDefault !== undefined ? spec.nativeDefault : spec.current);
  if (!input) { if (onNo) onNo(); return; }
  if (onPick) onPick(String(input).trim());
}
/** نص حر (سبب رفض/إيقاف…). onOk يستلم النص بعد trim. */
function askText(spec, onOk, onNo) {
  if (AppDialog.open(Object.assign({ kind: 'prompt' }, spec), v => { if (onOk) onOk(v); }, () => { if (onNo) onNo(); })) return;
  const v = spec.nativeDefault === undefined ? prompt(spec.nativeMessage || spec.title) : prompt(spec.nativeMessage || spec.title, spec.nativeDefault);
  if (v === null) { if (onNo) onNo(); return; }
  if (onOk) onOk(String(v).trim());
}

/* (الجزء 6.2-B) عناصر role="button" غير الأزرار الأصلية (بطاقات/صفوف الإدارة): Enter وSpace ينفّذان النقر كالزر الأصلي. مستمع واحد يُربط مرة واحدة. */
function activateRoleButton(ev) {
  if (!ev || (ev.key !== 'Enter' && ev.key !== ' ')) return false;
  const t = ev.target;
  if (!t || typeof t.getAttribute !== 'function' || t.getAttribute('role') !== 'button') return false;
  if (typeof t.matches === 'function' && t.matches('button,a,input,select,textarea')) return false;   // الأصلية تتصرف بنفسها
  if (typeof ev.preventDefault === 'function') ev.preventDefault();
  if (typeof t.click === 'function') t.click();
  return true;
}
if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') document.addEventListener('keydown', activateRoleButton);

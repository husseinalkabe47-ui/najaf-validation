/* بطاقة معلومات الحساب + زر تسجيل الخروج (تُستخدم في شاشات الحساب/التاجر/المدير) */
function AccountCard(user) {
  if (!user) return '';
  return `
  <div class="account-card">
    <h2>👤 ${esc(user.name)}</h2>
    <div class="info-row">📞 ${esc(user.phone)}</div>
    ${user.email ? `<div class="info-row">✉️ ${esc(user.email)}</div>` : ''}
    <div class="info-row">🏷️ ${ROLE_LABEL[user.role] || user.role} — ${USER_STATUS_LABEL[user.status] || user.status}</div>
    <button class="logout-btn" onclick="handleLogout()">تسجيل الخروج</button>
  </div>`;
}

/* مربع البحث. onEnter (اختياري): اسم دالة تُستدعى بنص البحث عند Enter أو عند الضغط على «بحث»
   (يُستخدم في الرئيسية للانتقال لشاشة نتائج البحث). */
function SearchBox(placeholder, oninput, value = '', onEnter = '') {
  const handler = oninput ? ` oninput="${oninput}(this.value)"` : '';
  const enter = onEnter ? ` onkeydown="if(event.key==='Enter')${onEnter}(this.value)"` : '';
  const go = onEnter ? `<button type="button" class="search-go" onclick="${onEnter}(this.parentNode.querySelector('input').value)">بحث</button>` : '';
  const safe = esc(value === undefined || value === null ? '' : String(value));     // (الجزء 6.1) مهرِّب التطبيق الواحد esc (كان هنا مهرِّب خاص ناقص: بلا > ولا الفاصلة العليا)
  // aria-label بنص الـplaceholder (قارئ الشاشة يعرف الحقل)، وenterkeyhint يُظهر مفتاح «بحث» في لوحة مفاتيح الهاتف (المرحلة 10 / الجزء 4)
  return `<div class="searchbox"><span aria-hidden="true">🔍</span> <input placeholder="${placeholder}" aria-label="${placeholder}" enterkeyhint="search" value="${safe}"${handler}${enter} />${go}</div>`;
}

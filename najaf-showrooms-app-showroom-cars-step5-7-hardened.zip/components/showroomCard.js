/* بطاقة المعرض: نفس التصميم السابق، بعرض انتقائي (المرحلة 10 / الجزء 3): صف العنوان يُخفى إن غاب (لا «📍 —»)،
   صورة المعرض الحقيقية إن وُجدت وإلا بديل 🏢 آمن، وعدد السيارات المتاحة للمشاهد، وشارة الحالة المعرَّفة فقط.
   سجل معطوب/بلا معرّف ← '' فلا يُسقط القائمة كلها. */
function ShowroomCard(s) {
  try {
    if (!s || typeof s !== 'object' || !Number.isFinite(s.id)) return '';
    const carsCount = getVisibleCarsByShowroom(s.id).length;
    const name = plainText(s.name) || 'معرض', address = plainText(s.address);
    return `
  <div class="card showroom-card" onclick="go('showroomDetails',${s.id})">
    <div class="card-img">${ShowroomImageInner(s)}</div>
    <div class="card-body">
      <p class="card-title">🏢 ${esc(name)}</p>
      ${address ? `<p class="card-row">📍 ${esc(address)}</p>` : ''}
      <p class="card-row">🚘 ${carsCount} سيارة</p>
      ${showroomStatusBadge(s.status)}
      <button type="button" class="btn-primary" aria-label="${esc('عرض المعرض: ' + name)}">عرض المعرض</button>
    </div>
  </div>`;
  } catch (e) { console.error('[ShowroomCard]', e); return ''; }
}

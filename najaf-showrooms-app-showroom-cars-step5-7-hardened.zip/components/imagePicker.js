/* ImagePicker — عدّاد الصور + المعاينات + (تعيين رئيسية/حذف) + زر الإضافة.
   يعمل بوضعين عبر سياق واحد للشاشة الحالية (_imageCtx):
   - 'draft': سيارة لم تُنشأ بعد (صور مضغوطة في الذاكرة حتى الحفظ).
   - 'car'  : سيارة موجودة (كل إجراء يُطبَّق ويُحفظ فورًا عبر carImagesService).
   لا منطق صلاحيات/ضغط هنا: الشاشة تعرض فقط، والخدمات تقرّر وتتحقق. */
let _imageCtx = null;

function initImageCtxDraft(max) { _imageCtx = { mode: 'draft', draft: createImageDraft(max), max, busy: false, message: '' }; }
function initImageCtxCar(carId) { const car = getCarById(carId); _imageCtx = { mode: 'car', carId, max: getMaxImagesForCar(car), busy: false, message: '' }; }

function _imagePickerItems() {
  const c = _imageCtx;
  if (c.mode === 'draft') return c.draft.items.map((it, i) => ({ ref: i, src: it.previewUrl, isMain: it.isMain }));
  return getCarImages(c.carId).map(im => ({ ref: im.id, src: resolveImageSrc(im.imageUrl), isMain: im.isMain }));
}

function ImagePickerInner() {
  const c = _imageCtx;
  if (!c) return '';
  const items = _imagePickerItems();
  const atMax = items.length >= c.max;
  return `
    <div class="img-counter">الصور ${items.length} / ${c.max}</div>
    <div class="img-grid">${items.map((it, i) => `
      <div class="thumb ${it.isMain ? 'main' : ''}">
        ${it.isMain ? '<span class="thumb-badge">رئيسية</span>' : ''}
        <div class="thumb-img">${it.src ? `<img src="${esc(it.src)}" alt="صورة ${i + 1}${it.isMain ? ' (رئيسية)' : ''}" data-ph="🚘" onerror="imgFallback(this)">` : '<span aria-hidden="true">🚘</span>'}</div>
        <div class="thumb-actions">
          ${it.isMain ? '' : `<button type="button" aria-label="تعيين الصورة ${i + 1} كرئيسية" onclick="handleSetMainImage(${it.ref})">تعيين كرئيسية</button>`}
          <button type="button" class="danger" aria-label="حذف الصورة ${i + 1}" onclick="handleRemoveImage(${it.ref})">حذف</button>
        </div>
      </div>`).join('')}</div>
    ${c.message ? `<div class="form-error" role="alert">${esc(c.message)}</div>` : ''}
    ${c.busy ? '<div class="img-busy" role="status">جارٍ معالجة الصورة…</div>' : ''}
    ${atMax
      ? `<div class="img-max">${CarImagesService.MSG_MAX}</div>`
      : `<label class="img-add">+ إضافة صور<input id="imgFileInput" type="file" accept="image/*" multiple onchange="handlePickImages(this)"></label>`}`;
}
function ImagePickerHtml() { return `<div id="imagePicker" tabindex="-1">${ImagePickerInner()}</div>`; }
function refreshImagePicker() {
  const el = document.getElementById('imagePicker'); if (!el) return;
  // (الجزء 6.2-B) الأزرار تُستبدل مع كل تحديث: إن كان التركيز داخل المنتقي (حذف/تعيين رئيسية) يعود إلى بدايته بدل أن يضيع في الصفحة
  const had = typeof el.contains === 'function' && typeof document !== 'undefined' && !!document.activeElement && el.contains(document.activeElement);
  el.innerHTML = ImagePickerInner();
  if (had && typeof el.focus === 'function') el.focus({ preventScroll: true });
}

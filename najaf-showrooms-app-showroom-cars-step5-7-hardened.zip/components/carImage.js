/* عرض الصور (المرحلة 10 / الجزء 3): صورة السيارة/المعرض بنسبتها دون تشويه، وبديل آمن عند الغياب أو التعطّل.
   نظام التخزين والضغط (ImageStore/imageService/carImagesService) لم يتغيّر: هذا الملف يعرض فقط ما تعيده resolveImageSrc.
   - الصورة المكسورة (onerror) تُستبدل ببديل فلا تظهر أيقونة صورة مكسورة، وصور الشريط المصغّرة المكسورة تُزال.
   - رابط الصورة يُهرَّب داخل الخاصية، وروابط غير صالحة/غير نصية تُعامَل كغياب صورة (لا استثناء). */
const CAR_PLACEHOLDER = '<span class="img-ph" role="img" aria-label="لا توجد صورة">🚘</span>';
const SHOWROOM_PLACEHOLDER = '<span class="img-ph" role="img" aria-label="لا توجد صورة">🏢</span>';

/** رابط عرض آمن لـ imageUrl مخزَّن أو null (النص فقط؛ وأي خطأ ← null) */
function _safeImgSrc(imageUrl) {
  try { return typeof imageUrl === 'string' ? (resolveImageSrc(imageUrl) || null) : null; } catch (e) { return null; }
}
/** أول رابط صالح لصور السيارة: الرئيسية أولًا ثم بقية الصور (تعطّل الأولى لا يخفي الباقي) */
function _carImageSrcs(car) {
  try {
    if (!car || typeof car !== 'object' || !Number.isFinite(car.id)) return [];
    const imgs = getCarImages(car.id);
    const main = imgs.find(i => i && i.isMain) || imgs[0];
    const ordered = (main ? [main] : []).concat(imgs.filter(i => i !== main));
    return ordered.map(i => _safeImgSrc(i && i.imageUrl)).filter(Boolean);
  } catch (e) { return []; }
}

/** محتوى مربع صورة السيارة: الصورة الرئيسية الحقيقية إن وُجدت (مضغوطة)، وإلا بديل 🚘 */
function CarImageInner(car) {
  const src = _carImageSrcs(car)[0];
  return src ? `<img src="${esc(src)}" alt="${esc(carTitle(car))}" loading="lazy" decoding="async" onerror="imgFallback(this)">` : CAR_PLACEHOLDER;
}
/** محتوى مربع صورة المعرض: صورته الحقيقية إن وُجدت، وإلا بديل 🏢 */
function ShowroomImageInner(s) {
  const src = _safeImgSrc(s && s.image);
  const name = plainText(s && s.name) || 'معرض';
  return src ? `<img src="${esc(src)}" alt="${esc(name)}" loading="lazy" decoding="async" data-ph="🏢" onerror="imgFallback(this)">` : SHOWROOM_PLACEHOLDER;
}
/** شريط صور مصغّر في شاشات التفاصيل (لا يظهر إلا إن وُجدت صورتان حقيقيتان فأكثر) */
function CarImageStrip(car) {
  const srcs = _carImageSrcs(car);
  if (srcs.length < 2) return '';
  const t = carTitle(car);
  return `<div class="img-strip">${srcs.map((s, i) => `<img src="${esc(s)}" alt="${esc(t)} — صورة ${i + 1}" loading="lazy" decoding="async" onerror="imgThumbFallback(this)">`).join('')}</div>`;
}

/** صورة مكسورة ← بديل (🚘 أو الرمز في data-ph). لا ترمي استثناءً أبدًا. */
function imgFallback(img) {
  try {
    if (!img || typeof img !== 'object') return;
    img.onerror = null;                                   // لا حلقة إن فشل البديل نفسه
    const icon = (typeof img.getAttribute === 'function' && img.getAttribute('data-ph')) || '🚘';
    if (typeof img.replaceWith !== 'function' || typeof document === 'undefined' || typeof document.createElement !== 'function') {
      if (img.style) img.style.display = 'none';          // لا يمكن الاستبدال: نُخفي المكسورة على الأقل
      return;
    }
    const ph = document.createElement('span');
    ph.className = 'img-ph'; ph.setAttribute('role', 'img'); ph.setAttribute('aria-label', 'تعذّر تحميل الصورة'); ph.textContent = icon;
    img.replaceWith(ph);
  } catch (e) { /* بقاء الصورة المكسورة أهون من استثناء في الواجهة */ }
}
/** صورة مصغّرة مكسورة ← تُزال من الشريط */
function imgThumbFallback(img) {
  try { if (img && typeof img === 'object') { img.onerror = null; if (typeof img.remove === 'function') img.remove(); } } catch (e) { /* تجاهل */ }
}

/* زر الحساب في أعلى الرئيسية: النص والوجهة تحددهما AuthorizationService (لا منطق هنا) */
function AccountButton() {
  const entry = AuthorizationService.getAccountEntryPoint();
  return `<button class="account-btn" onclick="go('${entry.route}')">${entry.icon} ${entry.label}</button>`;
}

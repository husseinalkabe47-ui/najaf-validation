/* ---- AdSlot: حاوية محجوزة لإعلان مستقبلي (AdMob على Android لاحقًا) ----
   غير مفعّلة حاليًا (مخفية عبر CSS)، ولا تحتوي أي معرف إعلاني حقيقي أو وهمي.
   معزولة تمامًا عن طبقة البيانات الجديدة؛ لا علاقة لها بالـ Models أو Services. */
function AdSlot(slotName, inline = false) {
  return `<div class="ad-slot${inline ? ' inline' : ''}" data-ad-slot="${slotName}">مساحة إعلان (${slotName})</div>`;
}

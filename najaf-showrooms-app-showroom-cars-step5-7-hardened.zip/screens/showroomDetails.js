/* تفاصيل المعرض: اسم، صورة، وصف، هاتف، عنوان، دوام، خدمات، موقع، وسيارات المعرض */
function ShowroomDetailsScreen(id) {
  const access = getShowroomAccess(id);   // المسار العام: ok | hidden (موقوف/مالكه غير فعّال لمن لا يملك رؤيته) | missing
  if (access.status === 'missing') return `${DetailBackButton('showrooms', true)}${EmptyState({ icon: '🏢', heading: true, title: 'المعرض غير موجود', actions: [{ label: 'تصفح المعارض', onclick: "go('showrooms')" }] })}`;
  if (access.status === 'hidden') return `${DetailBackButton('showrooms', true)}${EmptyState({ icon: '🏢', heading: true, title: 'هذا المعرض غير متاح حاليًا', actions: [{ label: 'تصفح المعارض', onclick: "go('showrooms')" }] })}`;
  const s = access.showroom;
  const cars = getVisibleCarsByShowroom(s.id);
  const services = Array.isArray(s.services) ? s.services.filter(Boolean) : [];
  return `
  ${DetailBackButton('showrooms')}
  <div class="detail-hero">${ShowroomImageInner(s)}</div>
  <div class="detail-body">
    <h1>${esc(s.name)}</h1>
    ${showroomStatusBadge(s.status)}
    ${s.description ? `<p class="sub" style="line-height:1.7;margin-top:10px">${esc(s.description)}</p>` : ''}
    <div class="info-row">📍 ${val(s.address)}</div>
    <div class="info-row">🕐 ${val(s.workingHours)}</div>
    ${s.phone ? `<div class="info-row">📞 ${val(s.phone)}</div>` : ''}
    ${services.length ? `<div class="chips">${services.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</div>` : ''}
    ${ContactButtons({ phone: s.phone, whatsapp: s.whatsapp, lat: s.latitude, lng: s.longitude })}
    ${AdSlot('showroom_details')}
    <h2 style="margin-top:22px;font-size:15px;">سيارات المعرض (${cars.length})</h2>
    <div class="list-grid" style="margin-top:10px;">${cars.length
      ? cars.map(CarCard).join('')
      : EmptyState({ icon: '🚘', heading: true, title: 'لا توجد سيارات في هذا المعرض حاليًا', hint: 'يمكنك تصفح سيارات المعارض الأخرى.', actions: [{ label: 'تصفح كل السيارات', onclick: "go('cars')" }] })}</div>
  </div>`;
}

/* «إدارة معرضي» — تفتح «سيارات معرضي» (المرحلة 7) لإضافة/تعديل/حذف سيارات المعرض.
   لا تُعرض إلا المعارض التي يحق للمستخدم إدارتها (ownerId) عبر AuthorizationService. */
function DealerHomeScreen() {
  const user = SessionService.getCurrentUser();
  const showrooms = AuthorizationService.getManagedShowrooms();
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>🏢 إدارة معرضي</h1><p class="sub">مرحبًا ${user ? esc(user.name) : ''}</p></div>
  <div class="section">
    ${AccountCard(user)}
    <button class="action-btn" style="width:100%;margin-bottom:14px" onclick="go('myMemberCars')">📋 إعلاناتي (سياراتي الشخصية)</button>
    <h2>معرضك</h2>
    <div class="list-grid">${showrooms.map(ShowroomCard).join('') || '<div class="placeholder">لا يوجد معرض مرتبط بحسابك بعد.</div>'}</div>
    <button class="btn-primary" style="margin-top:14px" onclick="go('myShowroomCars')">🚘 سيارات معرضي (إضافة / تعديل / حذف)</button>
  </div>`;
}

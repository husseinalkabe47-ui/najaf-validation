/* AdminShowroomCarsScreen — سيارات المعارض فقط (sourceType='showroom')، عرض
   وتغيير حالة (Soft) عبر adminService.setShowroomCarStatus. لا تمس صلاحيات
   صاحب المعرض الحالية (canManageCar تبقى كما هي لصفحاته الخاصة). */
let adminShowroomCarsQuery = '';
function renderAdminShowroomCarsList() {
  let list = getCars();
  if (adminShowroomCarsQuery.trim()) {
    const q = adminShowroomCarsQuery.trim().toLowerCase();
    list = list.filter(c => textLower(c.brand).includes(q) || textLower(c.model).includes(q));
  }
  if (list.length === 0) return `<div class="placeholder"><span class="ic">🔍</span>لا توجد نتائج.</div>`;
  return `<div class="list-grid">${list.map(c => {
    const sh = getShowroomById(c.showroomId);
    return `
    <div class="card car-card">
      <div class="card-img" onclick="go('carDetails', ${c.id})">🚘</div>
      <div class="card-body">
        <p class="card-title" onclick="go('carDetails', ${c.id})">${esc(c.brand)} ${esc(c.model)}</p>
        <p class="card-row">${val(c.year)} — ${carPriceOrDash(c)}</p>
        <p class="card-row">🏢 ${sh ? esc(sh.name) : '—'}</p>
        ${carStatusBadge(c.status)}
        <div class="admin-actions">
          <button onclick="go('carDetails', ${c.id})">👁️ عرض</button>
          <button onclick="handleAdminShowroomCarStatusChange(${c.id})">🔄 تغيير الحالة</button>
        </div>
      </div>
    </div>`;
  }).join('')}</div>`;
}
function onAdminShowroomCarsSearch(v) { adminShowroomCarsQuery = v; const l = document.getElementById('adminShowroomCarsList'); if (l) l.innerHTML = renderAdminShowroomCarsList(); }

function AdminShowroomCarsScreen() {
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🚘 سيارات المعارض</h1>${SearchBox('ابحث بالماركة أو الموديل', 'onAdminShowroomCarsSearch', adminShowroomCarsQuery)}</div>
  <div class="section"><div id="adminShowroomCarsList">${renderAdminShowroomCarsList()}</div></div>`;
}

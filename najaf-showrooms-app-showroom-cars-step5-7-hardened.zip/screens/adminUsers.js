/* AdminUsersScreen — كل المستخدمين مع فلتر بالدور. بلا كلمات مرور أبدًا
   (adminGetAllUsers تمر عبر UserService.toPublic). */
let adminUsersRoleFilter = 'all';
function renderAdminUsersList() {
  let list = adminGetAllUsers();
  if (adminUsersRoleFilter !== 'all') list = list.filter(u => u.role === adminUsersRoleFilter);
  if (list.length === 0) return `<div class="placeholder"><span class="ic">🔍</span>لا يوجد مستخدمون.</div>`;
  return `<div class="list-grid">${list.map(u => `
    <div class="ad-row" role="button" tabindex="0" onclick="go('adminUserDetails', ${u.id})">
      <div class="card-img">👤</div>
      <div class="ad-info">
        <p class="card-title">${esc(u.name)}</p>
        <p class="card-row">📞 ${esc(u.phone)}</p>
        <p class="card-row">🏷️ ${ROLE_LABEL[u.role] || u.role} — ${USER_STATUS_LABEL[u.status] || u.status}</p>
      </div>
    </div>`).join('')}</div>`;
}
function onAdminUsersFilter(role) {
  adminUsersRoleFilter = role;
  const tabs = document.getElementById('adminUsersTabs'); if (tabs) tabs.innerHTML = _adminUsersTabsHtml();
  const l = document.getElementById('adminUsersList'); if (l) l.innerHTML = renderAdminUsersList();
}
function _adminUsersTabsHtml() {
  const tabs = [['all', 'الكل'], ['user', 'مستخدم'], ['dealer', 'صاحب معرض'], ['admin', 'مدير']];
  return tabs.map(([v, l]) => `<button type="button" class="${adminUsersRoleFilter === v ? 'active' : ''}" aria-pressed="${adminUsersRoleFilter === v}" onclick="onAdminUsersFilter('${v}')">${l}</button>`).join('');
}
function AdminUsersScreen() {
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>👥 المستخدمون</h1></div>
  <div class="section">
    <div class="status-tabs" id="adminUsersTabs">${_adminUsersTabsHtml()}</div>
    <div id="adminUsersList">${renderAdminUsersList()}</div>
  </div>`;
}

/* المفضلة — favoritesService كما هو. تُعرض فقط السيارات المتاحة للمشاهد (قاعدة الظهور في visibilityService وحدها:
   سيارة عضو غير نشطة لا تظهر لغير مالكها/المدير، وسيارات معرض موقوف/مالكه غير فعّال لا تظهر لغير المدير/المالك). */
function FavoritesScreen() {
  if (!SessionService.isLoggedIn()) {
    return `
    <div class="topbar"><h1>❤️ المفضلة</h1></div>
    <div class="section">${EmptyState({ icon: '🔐', title: 'سجّل الدخول لحفظ سياراتك المفضلة', hint: 'احفظ السيارات التي تعجبك وارجع إليها في أي وقت.',
      actions: [{ label: 'تسجيل الدخول', onclick: "go('login',{returnTo:'favorites'})" }] })}</div>`;
  }
  const favCars = getFavoriteCars();   // خدمة المفضلة تعيد ما يحق للمشاهد رؤيته فقط (المسار العام)
  if (favCars.length === 0) {
    return `
    <div class="topbar"><h1>❤️ المفضلة</h1></div>
    <div class="section">${EmptyState({ icon: '💔', title: 'لا توجد سيارات في المفضلة حاليًا',
      hint: 'اضغط على أيقونة 🤍 في أي سيارة لإضافتها إلى المفضلة.',
      actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }, { label: 'سيارات الأعضاء', onclick: "go('memberCars')", primary: false }] })}</div>`;
  }
  return `
  <div class="topbar"><h1>❤️ المفضلة</h1><p class="sub">${favCars.length} سيارة محفوظة</p></div>
  <div class="section"><div class="list-grid">${favCars.map(CarCard).join('')}</div></div>`;
}

/* «سيارات معرضي» — سيارات معرض التاجر الحالي فقط (getMyShowroomCars عبر الصلاحيات) */
function MyShowroomCarsScreen() {
  const cars = getMyShowroomCars();
  const statusOptions = ShowroomCarsService.DEALER_STATUSES.map(s => `<option value="${s}">${CAR_STATUS_LABEL[s]}</option>`).join('');
  return `
  ${BackBar('dealerHome')}
  <div class="topbar"><div class="topbar-row"><h1>🚘 سيارات معرضي</h1></div></div>
  <div class="section">
    <button class="btn-primary" style="margin:0 0 14px" onclick="go('addShowroomCar')">+ إضافة سيارة</button>
    ${cars.length === 0 ? EmptyState({ icon: '🚘', title: 'لا توجد سيارات مضافة', hint: 'أضف أول سيارة لمعرضك لتظهر للزبائن فورًا.' }) :
      cars.map(c => `
      <div class="ad-row">
        <div class="card-img">${CarImageInner(c)}</div>
        <div class="ad-info">
          <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
          <p class="card-row">${val(c.year)}</p>
          <p class="price">${carPriceOrDash(c)}</p>
          ${carStatusBadge(c.status)}
          <div class="ad-actions">
            <button onclick="go('editShowroomCar', ${c.id})">تعديل</button>
            <select onchange="handleShowroomCarStatusChange(${c.id}, this.value)">
              <option value="">تغيير الحالة</option>${statusOptions}
            </select>
            <button class="danger" onclick="handleDeleteShowroomCar(${c.id})">حذف</button>
          </div>
        </div>
      </div>`).join('')}
  </div>`;
}

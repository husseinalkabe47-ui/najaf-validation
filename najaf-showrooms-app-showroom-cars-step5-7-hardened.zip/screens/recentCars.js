/* RecentCarsScreen — «السيارات المضافة حديثاً» (ميزة جديدة ج1): القائمة الكاملة للسيارات العامة (معارض + أعضاء) بالأحدث أولًا.
   المصدر الوحيد: getRecentCars (searchService) ← searchCars('all') ← getPublicCars ← visibilityService؛ والعرض بـCarCard وEmptyState القائمين.
   بحث بسيط يعيد استخدام searchCars نفسه (الترتيب الزمني محفوظ بعد البحث)؛ لا منطق ظهور ولا ترتيب ولا فلترة هنا، ولا محرك ثانٍ ولا تخزين. */
let recentCarsQuery = '';

function renderRecentCarsList() {
  const hasQ = !!String(recentCarsQuery || '').trim();
  const results = getRecentCars({ query: recentCarsQuery });
  if (!results.length) {
    return hasQ
      ? EmptyState({ icon: '🔍', title: 'لم نعثر على سيارات مطابقة لبحثك', hint: 'تأكد من كتابة الماركة أو الموديل أو السنة، أو جرّب كلمة أخرى.',
          actions: [{ label: 'مسح البحث', onclick: 'clearRecentCarsSearch()' }] })
      : EmptyState({ icon: '🆕', title: 'لا توجد سيارات مضافة حديثًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.',
          actions: [{ label: 'العودة للرئيسية', onclick: "go('home')" }] });
  }
  return `<p class="results-count" aria-live="polite">النتائج: ${carCountLabel(results.length)}</p><div class="list-grid">${results.map(CarCard).join('')}</div>`;
}
function onRecentCarsSearch(value) { recentCarsQuery = value; const l = document.getElementById('recentCarsList'); if (l) l.innerHTML = renderRecentCarsList(); }
function clearRecentCarsSearch() { recentCarsQuery = ''; render(); }

function RecentCarsScreen() {
  return `
  ${DetailBackButton('home', true)}
  <div class="topbar">
    <h1>🆕 السيارات المضافة حديثاً</h1>
    <p class="sub">أحدث السيارات التي أضيفت إلى المنصة</p>
    ${SearchBox('ابحث عن سيارة', 'onRecentCarsSearch', recentCarsQuery)}
  </div>
  <div class="section">
    <div id="recentCarsList">${renderRecentCarsList()}</div>
  </div>`;
}

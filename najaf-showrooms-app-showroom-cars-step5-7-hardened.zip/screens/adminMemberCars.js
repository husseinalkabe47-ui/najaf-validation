/* AdminMemberCarsScreen — كل سيارات الأعضاء (بكل الحالات)، بحث + تبويب حالة. */
let adminMemberCarsQuery = '';
let adminMemberCarsStatus = 'all';

function _adminMemberCarMatches(c, q) {
  const owner = UserService.getPublicById(c.ownerId);
  return textLower(c.brand).includes(q) || textLower(c.model).includes(q) ||
    textLower(`${c.brand} ${c.model}`).includes(q) || (owner && textLower(owner.name).includes(q));
}
function renderAdminMemberCarsList() {
  let list = getMemberCars();
  if (adminMemberCarsStatus !== 'all') list = list.filter(c => c.status === adminMemberCarsStatus);
  if (adminMemberCarsQuery.trim()) { const q = adminMemberCarsQuery.trim().toLowerCase(); list = list.filter(c => _adminMemberCarMatches(c, q)); }
  if (list.length === 0) return `<div class="placeholder"><span class="ic">🔍</span>لا توجد نتائج.</div>`;
  return `<div class="list-grid">${list.map(c => {
    const owner = UserService.getPublicById(c.ownerId);
    return `
    <div class="card car-card" role="button" tabindex="0" onclick="go('adminMemberCarDetails', ${c.id})">
      <div class="card-img">🚘</div>
      <div class="card-body">
        <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
        <p class="card-row">${val(c.year)} — ${carPriceOrDash(c)}</p>
        ${memberCarStatusBadge(c.status)}
        <p class="card-row">🧑 ${owner ? esc(owner.name) : 'غير معروف'}</p>
        ${c.phone ? `<p class="card-row">📞 ${esc(c.phone)}</p>` : ''}
        <p class="card-row">🗓️ ${createdDateText(c.createdAt)}</p>
      </div>
    </div>`;
  }).join('')}</div>`;
}
function onAdminMemberCarsSearch(v) { adminMemberCarsQuery = v; const l = document.getElementById('adminMemberCarsList'); if (l) l.innerHTML = renderAdminMemberCarsList(); }
function onAdminMemberCarsStatus(status) {
  adminMemberCarsStatus = status;
  const tabs = document.getElementById('adminMemberCarsTabs');
  if (tabs) tabs.innerHTML = _adminMemberCarsTabsHtml();
  const l = document.getElementById('adminMemberCarsList');
  if (l) l.innerHTML = renderAdminMemberCarsList();
}
function _adminMemberCarsTabsHtml() {
  const tabs = [['all', 'الكل'], ['pending', 'قيد المراجعة'], ['active', 'نشط'], ['sold', 'مباعة'], ['rejected', 'مرفوض'], ['suspended', 'موقوف']];
  return tabs.map(([v, l]) => `<button type="button" class="${adminMemberCarsStatus === v ? 'active' : ''}" aria-pressed="${adminMemberCarsStatus === v}" onclick="onAdminMemberCarsStatus('${v}')">${l}</button>`).join('');
}

function AdminMemberCarsScreen(initialStatus) {
  if (initialStatus) adminMemberCarsStatus = initialStatus;
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🚗 سيارات الأعضاء</h1>${SearchBox('ابحث بالاسم أو الماركة أو الموديل', 'onAdminMemberCarsSearch', adminMemberCarsQuery)}</div>
  <div class="section">
    <div class="status-tabs" id="adminMemberCarsTabs">${_adminMemberCarsTabsHtml()}</div>
    <div id="adminMemberCarsList">${renderAdminMemberCarsList()}</div>
  </div>`;
}

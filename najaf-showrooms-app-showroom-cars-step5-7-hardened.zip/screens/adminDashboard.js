/* AdminDashboardScreen — الشاشة الرئيسية للوحة الإدارة. بطاقات إحصائية قابلة
   للضغط + قائمة تنقل لبقية شاشات الإدارة. القراءة فقط عبر adminService.
   إصلاح (الإحصائيات): معامل التنقل كان يُكتب JSON.stringify(param) أي "pending" بعلامتي اقتباس مزدوجتين داخل سمة
   onclick المحاطة بمزدوجتين، فتنقطع السمة (go('adminMemberCars',) وتنتهي بـ SyntaxError: Unexpected end of input
   بدل الانتقال (بطاقات قيد المراجعة/نشطة/مباعة/مرفوضة). الآن يمرّ المعامل عبر esc() كباقي الشاشات.
   «قيد المراجعة» (pending) لا ينتجها النشر الجديد أبدًا (النشر بعد المكافأة = active مباشرة)؛ تمثل اليوم سجلات قديمة
   أو سجلات أعادتها الإدارة للمراجعة (restoreMemberCar)، فالبطاقة تذكر ذلك صراحةً. */
function AdminDashboardScreen() {
  const s = getDashboardStats();
  const card = (num, label, route, param, hint) =>
    `<div class="stat-card" role="button" tabindex="0" onclick="go('${route}'${param !== undefined ? `,${esc(JSON.stringify(param))}` : ''})"><div class="num">${num}</div><div class="lbl">${label}</div>${hint ? `<div class="lbl">${hint}</div>` : ''}</div>`;
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1><p class="sub">مرحبًا ${(SessionService.getCurrentUser() || {}).name || ''}</p></div>
  <div class="section">
    <h2>📊 الإحصائيات</h2>
    <div class="stats-grid">
      ${card(s.totalUsers, 'إجمالي المستخدمين', 'adminUsers')}
      ${card(s.totalShowrooms, 'إجمالي المعارض', 'adminShowrooms')}
      ${card(s.totalShowroomCars, 'سيارات المعارض', 'adminShowroomCars')}
      ${card(s.totalMemberCars, 'سيارات الأعضاء', 'adminMemberCars', 'all')}
      ${card(s.pendingMemberCars, 'قيد المراجعة', 'adminMemberCars', 'pending', 'سجلات قديمة أو أعادتها الإدارة')}
      ${card(s.activeMemberCars, 'إعلانات نشطة', 'adminMemberCars', 'active')}
      ${card(s.soldMemberCars, 'إعلانات مباعة', 'adminMemberCars', 'sold')}
      ${card(s.rejectedMemberCars, 'إعلانات مرفوضة', 'adminMemberCars', 'rejected')}
    </div>
    <div class="admin-menu">
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminMemberCars','pending')">🚗 سجلات الأعضاء بانتظار قرار الإدارة <span class="badge-count">${s.pendingMemberCars}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminShowrooms')">🏢 المعارض <span class="badge-count">${s.totalShowrooms}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminShowroomCars')">🚘 سيارات المعارض <span class="badge-count">${s.totalShowroomCars}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminUsers')">👥 المستخدمون <span class="badge-count">${s.totalUsers}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminDealerRequests')">🏪 طلبات أصحاب المعارض <span class="badge-count">${s.pendingDealers}</span></div>
    </div>
  </div>`;
}

/* «لوحة الإدارة» — واجهة أولية فقط؛ لا تُبنى لوحة الإدارة في هذه المرحلة. */
function AdminHomeScreen() {
  const user = SessionService.getCurrentUser();
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1></div>
  <div class="section">
    ${AccountCard(user)}
    <div class="placeholder" style="margin:0"><span class="ic">🛠️</span>إدارة المستخدمين والمعارض والسيارات والموافقة على أصحاب المعارض ستُضاف في مرحلة لاحقة.</div>
  </div>`;
}

/* نتائج البحث الموحّد: معارض + سيارات (معارض وأعضاء نشطة) بنفس searchService، وفلاتر السيارات بنفس محرك CarFilters.
   الفلاتر (ماركة/موديل/سنة/سعر/كيلومترات) تخصّ السيارات فقط؛ خيارها الديناميكي من نتائج البحث الحالية. */
let searchScreenQuery = '';
let searchFilters = newFilters();

function _searchPool() { return searchCars(searchScreenQuery.trim(), 'all'); }
function _searchOpts(pool) { return CarFilters.options(pool || _searchPool(), searchFilters); }
function _searchFilterBarHtml() {
  const q = searchScreenQuery.trim(); if (!q) return '';
  const pool = _searchPool();
  if (!pool.length && !activeFilterCount(searchFilters)) return '';       // لا سيارات مطابقة للبحث: لا حاجة لشريط فلاتر
  return FilterBar('search', _searchOpts(pool), searchFilters, 'onSearchFilter', 'clearSearchFilters', 'onSearchRange', 'removeSearchFilter');
}

function renderSearchResults() {
  const q = searchScreenQuery.trim();
  if (!q) return EmptyState({ icon: '🔍', title: 'ابحث عن سيارة أو معرض', hint: 'اكتب ماركة أو موديل أو سنة أو اسم معرض، مثل: تويوتا كورولا أو كورولا 2022 أو سيارات معرض الفرات' });
  const hasF = activeFilterCount(searchFilters) > 0;
  const showrooms = searchShowrooms(q), cars = searchCars(q, 'all', searchFilters);
  if (!showrooms.length && !cars.length) {
    return EmptyState({ icon: '🔍', title: 'لم نعثر على سيارات مطابقة لبحثك', hint: hasF ? 'جرّب تخفيف الفلاتر المختارة.' : 'تأكد من كتابة الماركة أو الموديل، أو جرّب كلمات أقل.',
      actions: [{ label: 'مسح البحث', onclick: 'clearSearchScreen()' }].concat(hasF ? [{ label: 'مسح الفلاتر', onclick: 'clearSearchFilters()', primary: false }] : [])
        .concat([{ label: 'تصفح كل السيارات', onclick: "go('cars')", primary: false }]) });
  }
  return `
    ${showrooms.length ? `<h2>🏢 المعارض (${showrooms.length})</h2><div class="hscroll" style="margin-bottom:12px">${showrooms.map(ShowroomCard).join('')}</div>` : ''}
    ${cars.length ? `<div class="topbar-row"><h2 style="margin:0">🚘 السيارات (${cars.length})</h2>
      <button type="button" class="link-btn" onclick="go('map')" aria-label="عرض مواقع المعارض على الخريطة">📍 الخريطة</button></div>
      <div class="list-grid">${cars.map(CarCard).join('')}</div>`
      : `<p class="sub">لا توجد سيارات مطابقة.</p>`}`;
}
function _refreshSearch() {
  const bar = document.getElementById('searchFilterBar'); if (bar) bar.innerHTML = _searchFilterBarHtml();
  const el = document.getElementById('searchResults'); if (el) el.innerHTML = renderSearchResults();
}
function onSearchScreenInput(v) {
  searchScreenQuery = v;
  searchFilters = CarFilters.reconcileModel(searchFilters, _searchPool());
  _refreshSearch();
}
function onSearchFilter() { searchFilters = CarFilters.reconcileModel(readFilters('search'), _searchPool()); _refreshSearch(); }
function onSearchRange() {
  searchFilters = readFilters('search');
  const chips = document.getElementById('searchFilterChips'); if (chips) chips.innerHTML = FilterChips('search', _searchOpts(), searchFilters, 'clearSearchFilters', 'removeSearchFilter');
  const el = document.getElementById('searchResults'); if (el) el.innerHTML = renderSearchResults();
}
function removeSearchFilter(key) { searchFilters = CarFilters.without(searchFilters, key); _refreshSearch(); }
function clearSearchFilters() { searchFilters = newFilters(); _refreshSearch(); }
function clearSearchScreen() { searchScreenQuery = ''; searchFilters = newFilters(); currentParam = ''; render(); }

function SearchScreen(q) {
  if (typeof q === 'string') { if (q !== searchScreenQuery) searchFilters = newFilters(); searchScreenQuery = q; }   // بحث جديد من الرئيسية: فلاتر نظيفة
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>🔍 البحث</h1>${SearchBox('ماركة، موديل، سنة، أو معرض', 'onSearchScreenInput', searchScreenQuery)}</div>
  <div class="section"><div id="searchFilterBar">${_searchFilterBarHtml()}</div><div id="searchResults">${renderSearchResults()}</div></div>`;
}

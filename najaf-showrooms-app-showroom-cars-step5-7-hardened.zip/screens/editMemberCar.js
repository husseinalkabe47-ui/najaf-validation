/* EditMemberCarScreen — حقول الإعلان كاملة + إدارة الصور (حتى 4). الراوتر يتحقق من
   الملكية عبر canEditMemberCar قبل عرض هذه الشاشة أصلًا (انظر router.js). */
function EditMemberCarScreen(id) {
  const c = getMemberCarById(id);
  if (!c) return `${BackBar('myMemberCars')}${EmptyState({ icon: '🚘', title: 'الإعلان غير موجود', actions: [{ label: 'سياراتي', onclick: "go('myMemberCars')" }] })}`;
  initImageCtxCar(id);
  const sel = (v, cur) => (v === cur ? 'selected' : '');
  return `
  ${BackBar('myMemberCars')}
  <div class="topbar"><h1>✏️ تعديل الإعلان</h1><p class="sub">${esc(c.brand)} ${esc(c.model)}</p></div>
  <div class="section">
    <div class="form-card">
      <div class="field"><label for="mcBrand">الماركة</label><input id="mcBrand" type="text" value="${esc(c.brand)}"></div>
      <div class="field"><label for="mcModel">الموديل</label><input id="mcModel" type="text" value="${esc(c.model)}"></div>
      <div class="field"><label for="mcYear">سنة الصنع</label><input id="mcYear" inputmode="numeric" type="text" dir="ltr" value="${esc(c.year)}"></div>
      <div class="field"><label for="mcPrice">السعر</label><input id="mcPrice" inputmode="numeric" type="text" dir="ltr" value="${esc(c.price)}"></div>
      <div class="field"><label for="mcCurrency">عملة السعر *</label><select id="mcCurrency">${currencyOptionsHtml(carCurrency(c))}</select></div>
      <div class="field"><label for="mcMileage">الكيلومترات</label><input id="mcMileage" inputmode="numeric" type="text" dir="ltr" value="${esc(c.mileage)}"></div>
      <div class="field"><label for="mcTransmission">ناقل الحركة</label>
        <select id="mcTransmission"><option value="أوتوماتيك" ${sel('أوتوماتيك', c.transmission)}>أوتوماتيك</option><option value="يدوي" ${sel('يدوي', c.transmission)}>يدوي</option></select></div>
      <div class="field"><label for="mcFuelType">نوع الوقود</label>
        <select id="mcFuelType">${['بنزين', 'ديزل', 'هايبرد', 'كهرباء'].map(f => `<option value="${f}" ${sel(f, c.fuelType)}>${f}</option>`).join('')}</select></div>
      <div class="field"><label for="mcColor">اللون</label><input id="mcColor" type="text" value="${esc(c.color)}"></div>
      <div class="field"><label for="mcLocation">الموقع</label><input id="mcLocation" type="text" value="${esc(c.location)}"></div>
      <div class="field"><label for="mcPhone">رقم الهاتف</label><input id="mcPhone" inputmode="tel" autocomplete="tel" type="text" dir="ltr" value="${esc(c.phone)}"></div>
      <div class="field"><label for="mcWhatsapp">رقم واتساب</label><input id="mcWhatsapp" inputmode="tel" autocomplete="tel" type="text" dir="ltr" value="${esc(c.whatsapp)}"></div>
      <div class="field"><label for="mcDescription">وصف السيارة</label><textarea id="mcDescription">${esc(c.description)}</textarea></div>
      <div class="field" role="group" aria-labelledby="imgPickerLabel"><label id="imgPickerLabel">الصور</label>${ImagePickerHtml()}</div>
      <div id="editMemberCarError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleEditMemberCarSubmit(${c.id})">حفظ التعديلات</button>
    </div>
  </div>`;
}

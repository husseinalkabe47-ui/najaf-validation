/* تفاصيل سيارة معرض: صور، مواصفات، وصف، معلومات المعرض، وأزرار تواصل تعمل فقط عند توفر البيانات */
function CarDetailsScreen(id) {
  const access = getCarAccess(id);   // المسار العام: ok | hidden (معرض موقوف/إعلان عضو غير نشط لغير مالكه) | missing
  if (access.status === 'missing') return `${DetailBackButton('cars', true)}${EmptyState({ icon: '🚘', heading: true, title: 'السيارة غير موجودة', actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }] })}`;
  if (access.status === 'hidden') return `${DetailBackButton('cars', true)}${EmptyState({ icon: '🚘', heading: true, title: 'هذه السيارة غير متاحة حاليًا', actions: [{ label: 'تصفح السيارات', onclick: "go('cars')" }] })}`;
  const c = access.car;
  const isMember = c.sourceType === 'member';
  const sh = isMember ? null : getVisibleShowroomById(c.showroomId);
  // كتلة المعرض: من بيانات المعرض الفعلية فقط (الاسم، العنوان، الدوام، عدد سياراته، شارة حالته إن لم يكن نشطًا)
  const showroomBlock = sh ? (() => {
    const name = plainText(sh.name), addr = plainText(sh.address), hours = plainText(sh.workingHours);
    return `
    <div class="info-block">
      <h3>🏢 المعرض</h3>
      ${name ? `<div class="info-row strong">${esc(name)}</div>` : ''}
      ${addr ? `<div class="info-row">📍 ${esc(addr)}</div>` : ''}
      ${hours ? `<div class="info-row">🕐 ${esc(hours)}</div>` : ''}
      <div class="info-row">🚘 ${getVisibleCarsByShowroom(sh.id).length} سيارة</div>
      ${sh.status !== 'active' ? showroomStatusBadge(sh.status) : ''}
      <button class="link-btn" onclick="go('showroomDetails',${sh.id})">عرض صفحة المعرض</button>
    </div>`;
  })() : '';
  const contact = isMember ? ContactButtons({ phone: c.phone, whatsapp: c.whatsapp, lat: c.latitude, lng: c.longitude })
    : (sh ? ContactButtons({ phone: sh.phone, whatsapp: sh.whatsapp, lat: sh.latitude, lng: sh.longitude }) : '');
  return `
  ${DetailBackButton('cars')}
  <div class="detail-hero">${CarImageInner(c)}</div>
  ${CarImageStrip(c)}
  <div class="detail-body">
    ${DetailIdentity(c, isMember ? sourceBadge('member') : '')}
    ${DetailPrice(c)}
    ${DetailStatusRow(isMember ? memberCarStatusBadge(c.status) : carStatusBadge(c.status))}
    ${DetailSpecs(CarCoreSpecs(c))}
    ${DetailDescription(c)}
    ${showroomBlock}
    ${AdSlot('car_details')}
    ${contact}
  </div>`;
}

/* الخريطة — بلا أي Maps API: قائمة بمواقع المعارض مع زر «الموقع على الخريطة» (رابط عادي
   يفتح تطبيق الخرائط في الهاتف) لكل معرض لديه إحداثيات. الخريطة التفاعلية لاحقًا. */
function MapScreen() {
  const showrooms = searchShowrooms('');
  return `
  <div class="topbar"><h1>📍 مواقع المعارض</h1><p class="sub">اضغط «الموقع على الخريطة» لفتح الموقع في تطبيق الخرائط</p></div>
  <div class="section">
    ${showrooms.length === 0 ? EmptyState({ icon: '📍', title: 'لا توجد معارض' }) : showrooms.map(s => `
    <div class="info-block">
      <h3 onclick="go('showroomDetails',${s.id})" style="cursor:pointer">🏢 ${esc(s.name)}</h3>
      <div class="info-row">📍 ${val(s.address)}</div>
      ${mapLink(s.latitude, s.longitude)
        ? `<a class="action-btn" href="${mapLink(s.latitude, s.longitude)}" target="_blank" rel="noopener">📍 الموقع على الخريطة</a>`
        : `<div class="sub">الموقع غير متوفر لهذا المعرض.</div>`}
      <button class="link-btn" onclick="go('showroomDetails',${s.id})">عرض المعرض</button>
    </div>`).join('')}
  </div>`;
}

function AdminUserDetailsScreen(id) {
  const u = UserService.getPublicById(id);
  if (!u) return `<div class="placeholder"><b role="heading" aria-level="1">المستخدم غير موجود</b></div>`;
  const managed = AuthorizationService.getManagedShowrooms(u); // معارضه إن كان تاجرًا
  return `
  <div class="back-btn"><button class="back-circle" aria-label="رجوع" onclick="goBack('adminUsers')">→</button></div>
  <div class="section">
    <div class="account-card">
      <h1>👤 ${esc(u.name)}</h1>
      <div class="info-row">📞 ${esc(u.phone)}</div>
      ${u.email ? `<div class="info-row">✉️ ${esc(u.email)}</div>` : ''}
      <div class="info-row">🏷️ ${ROLE_LABEL[u.role] || u.role} — ${USER_STATUS_LABEL[u.status] || u.status}</div>
      <div class="info-row">🗓️ تاريخ إنشاء الحساب: ${createdDateText(u.createdAt)}</div>
    </div>
    ${u.role === 'dealer' ? `
    <h2>معارضه</h2>
    <div class="list-grid">${managed.map(ShowroomCard).join('') || '<div class="placeholder">لا يوجد معرض بعد.</div>'}</div>` : ''}
    ${u.role === 'user' || u.role === 'dealer' ? `
    <h2 style="margin-top:14px">إعلانات سيارات الأعضاء</h2>
    <div class="list-grid">${getMemberCarsByOwner(u.id).map(c => `<div class="ad-row"><div class="card-img">🚘</div><div class="ad-info"><p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>${memberCarStatusBadge(c.status)}</div></div>`).join('') || '<div class="placeholder">لا توجد إعلانات.</div>'}</div>` : ''}
    <div class="placeholder" style="margin-top:14px"><span class="ic">🔒</span>حذف المدير الحالي وتغيير كلمة المرور من هنا غير متاحين في هذا النموذج التجريبي.</div>
  </div>`;
}

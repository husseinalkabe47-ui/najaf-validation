/* MemberCarsScreen — القائمة العامة لسيارات الأعضاء (النشطة فقط: searchCars/getActiveMemberCars)
   (UX ج4) الشاشة تفتح ببحث بارز والسيارات تحته؛ لوحة الفلاتر المتقدمة (FilterBar نفسه وحالة الأعضاء memberCarsFilters ومعالجاتها القائمة)
   مطويّة افتراضيًا خلف زر «تصفية» مع شارة بعدد الفلاتر الفعالة وملخص الفلاتر الفعالة (FilterChips نفسه). الطيّ عرض فقط:
   لا محرك بحث/فلترة ثانٍ ولا حالة فلترة ثانية ولا قواعد ظهور جديدة، وطيّ اللوحة لا يمسح شيئًا. */
let memberCarsQuery = '';
let memberCarsFilters = newFilters();
let memberFiltersOpen = false;   // حالة طيّ اللوحة فقط (تبقى عبر render() للشاشة نفسها؛ وتبدأ مطويّة عند كل دخول جديد للشاشة)

function _memberPool() { return searchCars('', 'member'); }
function _memberOpts() { return CarFilters.options(_memberPool(), memberCarsFilters); }
function _memberFilterBarHtml() { return FilterBar('member', _memberOpts(), memberCarsFilters, 'onMemberCarsFilter', 'clearMemberCarsFilters', 'onMemberCarsRange', 'removeMemberCarsFilter'); }

function renderMemberCarsList() {
  const results = searchCars(memberCarsQuery, 'member', memberCarsFilters);
  if (results.length === 0) {
    const hasQ = !!memberCarsQuery.trim(), hasF = activeFilterCount(memberCarsFilters) > 0;
    if (!hasQ && !hasF) return EmptyState({ icon: '🚘', title: 'لا توجد سيارات أعضاء حاليًا', hint: 'كن أول من ينشر سيارته مجانًا.',
      actions: [{ label: '➕ نشر سيارتي', onclick: "go('addMemberCar')" }] });
    const actions = [];
    if (hasQ) actions.push({ label: 'مسح البحث', onclick: 'clearMemberCarsSearch()' });
    if (hasF) actions.push({ label: 'مسح الفلاتر', onclick: 'clearMemberCarsFilters()', primary: !hasQ });
    return EmptyState({ icon: '🔍', title: 'لم نعثر على سيارات مطابقة لبحثك', hint: hasF ? 'جرّب تخفيف الفلاتر المختارة.' : 'تأكد من كتابة الماركة أو الموديل أو الموقع، أو جرّب كلمات أقل.', actions });
  }
  return `<p class="results-count" aria-live="polite">النتائج: ${carCountLabel(results.length)}</p><div class="list-grid">${
    results.map((c, i) =>
      CarCard(c) + ((i + 1) % 4 === 0 && i !== results.length - 1 ? AdSlot('member_cars_inline_' + c.id, true) : '')
    ).join('')
  }</div>`;
}
/* ---- زر «تصفية» ولوحة الفلاتر القابلة للطيّ (واجهة فقط) ---- */
function _memberFiltersLabel(n) { return n === 1 ? 'فلتر واحد فعّال' : n === 2 ? 'فلتران فعّالان' : `${n} فلاتر فعّالة`; }
function _memberToggleLabel(n) { return n > 0 ? `تصفية سيارات الأعضاء، ${_memberFiltersLabel(n)}` : 'تصفية سيارات الأعضاء'; }   // الاسم يحوي النص الظاهر «تصفية»
function _memberToggleHtml(n) {
  return `<button type="button" id="memberRefineToggle" class="filter-toggle${n > 0 ? ' has-filters' : ''}" aria-expanded="${memberFiltersOpen ? 'true' : 'false'}" aria-controls="memberRefinePanel" aria-label="${esc(_memberToggleLabel(n))}" onclick="toggleMemberFilterPanel()"><span aria-hidden="true">⚙️</span><span class="ft-label">تصفية</span><span class="ft-badge" id="memberRefineBadge" aria-hidden="true"${n > 0 ? '' : ' hidden'}>${n}</span></button>`;
}
function _memberSummaryHtml(n) { return (!memberFiltersOpen && n > 0) ? FilterChips('member', _memberOpts(), memberCarsFilters, 'clearMemberCarsFilters', 'removeMemberCarsFilter') : ''; }
function _memberDoneLabel() { const k = carCountLabel(searchCars(memberCarsQuery, 'member', memberCarsFilters).length); return k ? `عرض النتائج (${k})` : 'عرض النتائج'; }
function _setMemberAttr(el, k, v) { if (el && typeof el.setAttribute === 'function') el.setAttribute(k, v); }
/** يزامن عناصر الطيّ مع الحالة (الزر/الشارة/اللوحة/الملخص/زر العرض) دون استبدال الزر نفسه (يبقى التركيز عليه) */
function _syncMemberFilterUi() {
  const n = activeFilterCount(memberCarsFilters);
  const btn = document.getElementById('memberRefineToggle');
  if (btn) { btn.className = 'filter-toggle' + (n > 0 ? ' has-filters' : ''); _setMemberAttr(btn, 'aria-expanded', memberFiltersOpen ? 'true' : 'false'); _setMemberAttr(btn, 'aria-label', _memberToggleLabel(n)); }
  const badge = document.getElementById('memberRefineBadge'); if (badge) { badge.textContent = String(n); badge.hidden = n === 0; }
  const panel = document.getElementById('memberRefinePanel'); if (panel) panel.hidden = !memberFiltersOpen;
  // اللوحة مطويّة: ملخص الفلاتر الفعالة (نفس FilterChips بما فيه «مسح الفلاتر») يبقى ظاهرًا؛ والمفتوحة تعرضها داخلها فلا تكرار
  const sum = document.getElementById('memberRefineSummary');
  if (sum) { const html = _memberSummaryHtml(n); sum.innerHTML = html; sum.hidden = !html; }
  const done = document.getElementById('memberRefineDone'); if (done) done.textContent = _memberDoneLabel();
}
function toggleMemberFilterPanel() {
  memberFiltersOpen = !memberFiltersOpen;
  _syncMemberFilterUi();
  const panel = document.getElementById('memberRefinePanel');
  if (memberFiltersOpen && panel && typeof panel.scrollIntoView === 'function') panel.scrollIntoView({ block: 'nearest' });
}
/** طيّ اللوحة بلا مسح أي فلتر؛ التركيز يعود للزر (لا يضيع داخل لوحة اختفت) والنتائج تظهر */
function closeMemberFilterPanel() {
  memberFiltersOpen = false;
  _syncMemberFilterUi();
  const btn = document.getElementById('memberRefineToggle'); if (btn && typeof btn.focus === 'function') btn.focus({ preventScroll: true });
  const list = document.getElementById('memberCarsList'); if (list && typeof list.scrollIntoView === 'function') list.scrollIntoView({ block: 'start' });
}
/* Escape يطوي اللوحة؛ لا تدخّل إن كانت نافذة حوار مفتوحة، وأول Escape يغلق نافذة اقتراحات السعر/الكيلومترات المفتوحة (سلوك مكوّن الفلاتر القائم). تُسجَّل مرة واحدة. */
(function bindMemberFilterPanelEscape() {
  if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return;
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape' || !memberFiltersOpen || currentRoute !== 'memberCars') return;
    if (typeof ModalFocus !== 'undefined' && ModalFocus.isActive && ModalFocus.isActive()) return;
    if (typeof filterPopupOpen === 'function' && filterPopupOpen()) return;
    closeMemberFilterPanel();
  }, true);
})();

function _refreshMemberCars() {
  const bar = document.getElementById('memberFilterBar'); if (bar) bar.innerHTML = _memberFilterBarHtml();
  const list = document.getElementById('memberCarsList'); if (list) list.innerHTML = renderMemberCarsList();
  _syncMemberFilterUi();
}
function onMemberCarsSearch(value) { memberCarsQuery = value; const list = document.getElementById('memberCarsList'); if (list) list.innerHTML = renderMemberCarsList(); _syncMemberFilterUi(); }
function onMemberCarsFilter() { memberCarsFilters = CarFilters.reconcileModel(readFilters('member'), _memberPool()); _refreshMemberCars(); }
function onMemberCarsRange() {
  memberCarsFilters = readFilters('member');
  const chips = document.getElementById('memberFilterChips'); if (chips) chips.innerHTML = FilterChips('member', _memberOpts(), memberCarsFilters, 'clearMemberCarsFilters', 'removeMemberCarsFilter');
  const list = document.getElementById('memberCarsList'); if (list) list.innerHTML = renderMemberCarsList();
  _syncMemberFilterUi();
}
function removeMemberCarsFilter(key) { memberCarsFilters = CarFilters.without(memberCarsFilters, key); _refreshMemberCars(); }
function clearMemberCarsFilters() { memberCarsFilters = newFilters(); memberFiltersOpen = false; render(); }   // المسح الكامل يعيد القائمة العادية (اللوحة مطويّة)
function clearMemberCarsSearch() { memberCarsQuery = ''; render(); }

function MemberCarsScreen() {
  // دخول جديد للشاشة (الشاشة السابقة في الصفحة ليست سيارات الأعضاء) ← اللوحة مطويّة؛ إعادة رسم الشاشة نفسها (♡، مسح البحث) تحفظ حالتها
  const prev = (document.getElementById('screen') || {}).innerHTML;
  if (!(typeof prev === 'string' && prev.includes('id="memberRefinePanel"'))) memberFiltersOpen = false;
  const n = activeFilterCount(memberCarsFilters), sum = _memberSummaryHtml(n);
  return `
  ${BackBar('home')}
  <div class="topbar">
    <h1>🧑‍🤝‍🧑 سيارات الأعضاء</h1>
    <p class="sub">ماركة، موديل، سنة أو موقع السيارة</p>
    <div class="cars-tools">
      ${SearchBox('ابحث عن سيارة', 'onMemberCarsSearch', memberCarsQuery)}
      ${_memberToggleHtml(n)}
    </div>
  </div>
  <div class="section">
    <div id="memberRefineSummary" class="filter-summary"${sum ? '' : ' hidden'}>${sum}</div>
    <div id="memberRefinePanel" class="filter-panel" role="group" aria-label="تصفية سيارات الأعضاء"${memberFiltersOpen ? '' : ' hidden'}>
      <div id="memberFilterBar">${_memberFilterBarHtml()}</div>
      <button type="button" id="memberRefineDone" class="btn-primary" onclick="closeMemberFilterPanel()">${_memberDoneLabel()}</button>
    </div>
    <div id="memberCarsList">${renderMemberCarsList()}</div>
  </div>
  <div class="section" style="padding-top:0">
    <button class="btn-primary" onclick="go('addMemberCar')">➕ نشر سيارتي</button>
  </div>`;
}

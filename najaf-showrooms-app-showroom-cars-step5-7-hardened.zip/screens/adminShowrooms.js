/* AdminShowroomsScreen — كل المعارض، بحث، وإيقاف/تفعيل (Soft) دون حذف فعلي. */
let adminShowroomsQuery = '';
function renderAdminShowroomsList() {
  let list = getShowrooms();
  if (adminShowroomsQuery.trim()) {
    const q = adminShowroomsQuery.trim().toLowerCase();
    list = list.filter(s => textLower(s.name).includes(q) || textLower(s.address).includes(q));
  }
  if (list.length === 0) return `<div class="placeholder"><span class="ic">🔍</span>لا توجد نتائج.</div>`;
  return `<div class="list-grid">${list.map(s => {
    const owner = UserService.getPublicById(s.ownerId);
    const carsCount = getCarsByShowroom(s.id).length;
    return `
    <div class="card showroom-card">
      <div class="card-img">🏢</div>
      <div class="card-body">
        <p class="card-title">🏢 ${esc(s.name)}</p>
        <p class="card-row">📞 ${val(s.phone)}</p>
        <p class="card-row">📍 ${val(s.address)}</p>
        <p class="card-row">🧑 المالك: ${owner ? esc(owner.name) : '—'}</p>
        <p class="card-row">🚘 ${carsCount} سيارة</p>
        ${showroomStatusBadge(s.status)}
        <div class="admin-actions">
          <button onclick="go('showroomDetails', ${s.id})">👁️ عرض</button>
          ${s.status !== 'suspended' ? `<button class="danger" onclick="handleAdminSuspendShowroom(${s.id})">⏸️ إيقاف</button>` : `<button class="approve" onclick="handleAdminActivateShowroom(${s.id})">✅ تفعيل</button>`}
        </div>
      </div>
    </div>`;
  }).join('')}</div>`;
}
function onAdminShowroomsSearch(v) { adminShowroomsQuery = v; const l = document.getElementById('adminShowroomsList'); if (l) l.innerHTML = renderAdminShowroomsList(); }

function AdminShowroomsScreen() {
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🏢 إدارة المعارض</h1>${SearchBox('ابحث باسم أو عنوان المعرض', 'onAdminShowroomsSearch', adminShowroomsQuery)}</div>
  <div class="section"><div id="adminShowroomsList">${renderAdminShowroomsList()}</div></div>`;
}

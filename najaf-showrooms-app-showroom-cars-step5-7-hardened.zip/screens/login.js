/* شاشة تسجيل الدخول — عرض فقط؛ المنطق في navigation/actions.js و AuthService */
function LoginScreen() {
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>🔐 تسجيل الدخول</h1><p class="sub">أهلاً بك في معارض النجف</p></div>
  <div class="section">
    <div class="form-card">
      <div class="field"><label for="loginIdentifier">رقم الهاتف أو البريد الإلكتروني</label>
        <input id="loginIdentifier" type="text" dir="ltr" autocomplete="username" placeholder="07XXXXXXXXX"
               onkeydown="if(event.key==='Enter')handleLoginSubmit()"></div>
      <div class="field"><label for="loginPassword">كلمة المرور</label>
        <input id="loginPassword" type="password" dir="ltr" autocomplete="current-password" placeholder="••••••"
               onkeydown="if(event.key==='Enter')handleLoginSubmit()"></div>
      <div id="loginError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleLoginSubmit()">تسجيل الدخول</button>
      <div class="form-links">
        <button class="link-btn" onclick="go('register')">إنشاء حساب</button>
        <button class="link-btn" onclick="handleForgotPassword()">نسيت كلمة المرور؟</button>
      </div>
      <div id="loginNote" class="form-note" role="status" style="display:none"></div>
    </div>
    <div class="demo-box">
      <h3>🧪 حسابات تجريبية للاختبار فقط</h3>
      ${DEMO_ACCOUNTS.map((a, i) => `
        <div class="demo-row"><span>${a.label}</span><button onclick="fillDemoAccount(${i})">تعبئة</button></div>`).join('')}
    </div>
  </div>`;
}

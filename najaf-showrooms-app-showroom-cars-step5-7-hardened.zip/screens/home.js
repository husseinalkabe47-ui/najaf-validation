/* الرئيسية (المرحلة 10 / الجزء 4) — تحسين العرض فقط على الشاشة القائمة، بلا منطق أعمال هنا:
   • البيانات كلها من getHomeFeed (searchService) فوق المسار العام للظهور؛ والعرض بـCarCard وShowroomCard وEmptyState وAdSlot.
   • البطل: «اعثر على سيارتك بين معارض النجف» + مربع البحث القائم (handleHomeSearch → شاشة البحث الموحّدة).
   • إجراءا اكتشاف بارزان: «وين ألكه هاي السيارة؟» ← السيارات (البحث والفلاتر القائمة)، و«استكشف المعارض على الخريطة» ← الخريطة القائمة.
   • الوصول السريع القائم محفوظ كما هو، ومساحة الإعلان home_banner في موضعها (بين الوصول السريع والسيارات) بلا تغيير.
   • سيارات الأعضاء كما كانت؛ ومعلومات المنصة قسم موجز بلا ادعاءات (لا توثيق ولا ضمان ولا دفع). */

/** البحث من الرئيسية: نص ← شاشة البحث الموحّدة القائمة بنفس النص؛ فارغ/غير نصي ← شاشة السيارات (تصفح + بحث + فلاتر) */
function handleHomeSearch(value) {
  const q = (typeof value === 'string' || typeof value === 'number') ? String(value).trim() : '';
  if (q) go('search', q); else go('cars');
}

/** رأس قسم: عنوان (h2 بمعرّف يشير إليه aria-labelledby) وزر «عرض الكل» اختياري بوجهة القسم القائمة */
function _homeHead(id, title, route, allLabel, showAll) {
  return `<div class="home-head"><h2 id="${id}">${title}</h2>${showAll
    ? `<button type="button" class="link-btn" onclick="go('${route}')" aria-label="${allLabel}">عرض الكل</button>` : ''}</div>`;
}

function HomeScreen() {
  const feed = getHomeFeed();
  const recent = getRecentCars({ limit: RECENT_CARS_HOME_LIMIT });   // (ميزة جديدة ج1) موحّد: معارض + أعضاء، الأحدث أولًا، من المسار العام نفسه
  const recentBody = recent.length ? `<div class="hscroll">${recent.map(CarCard).join('')}</div>`
    : EmptyState({ icon: '🆕', title: 'لا توجد سيارات مضافة حديثًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.' });
  const carsBody = feed.cars.length ? `<div class="hscroll">${feed.cars.map(CarCard).join('')}</div>`
    : EmptyState({ icon: '🚘', title: 'لا توجد سيارات حاليًا', hint: 'ستظهر هنا أحدث السيارات فور إضافتها.' });
  const showroomsBody = feed.showrooms.length ? `<div class="hscroll">${feed.showrooms.map(ShowroomCard).join('')}</div>`
    : EmptyState({ icon: '🏢', title: 'لا توجد معارض', hint: 'ستظهر هنا المعارض فور إضافتها.' });
  const membersBody = feed.memberCars.length ? `<div class="hscroll">${feed.memberCars.map(CarCard).join('')}</div>`
    : `<p class="sub">لا توجد سيارات أعضاء نشطة بعد.</p>`;
  const account = AuthorizationService.getAccountEntryPoint();
  return `
  <div class="topbar home-hero">
    <div class="topbar-row home-top"><span class="home-brand">🚗 معارض النجف</span>${AccountButton()}</div>
    <h1 class="home-title">اعثر على سيارتك بين معارض النجف</h1>
    <p class="home-lead">سيارات ومعارض النجف الأشرف في مكان واحد</p>
    ${SearchBox('ابحث عن سيارة أو معرض', '', '', 'handleHomeSearch')}
  </div>
  <div class="section home-actions" role="group" aria-label="طرق الاكتشاف">
    <button type="button" class="home-action primary" onclick="go('cars')">
      <span class="ha-ic" aria-hidden="true">🔎</span>
      <span class="ha-txt"><b>وين ألكه هاي السيارة؟</b><small>ابحث بالماركة أو الموديل واعرف المعرض</small></span>
    </button>
    <button type="button" class="home-action" onclick="go('map')">
      <span class="ha-ic" aria-hidden="true">📍</span>
      <span class="ha-txt"><b>استكشف المعارض على الخريطة</b><small>افتح مواقع المعارض في تطبيق الخرائط</small></span>
    </button>
  </div>
  <section class="section home-section" aria-labelledby="homeQuickTitle">
    <h2 id="homeQuickTitle">وصول سريع</h2>
    <div class="explore-grid">
      <button class="explore-btn" onclick="go('cars')"><span class="ic">🚘</span>السيارات</button>
      <button class="explore-btn" onclick="go('showrooms')"><span class="ic">🏢</span>المعارض</button>
      <button class="explore-btn" onclick="go('map')"><span class="ic">📍</span>الخريطة</button>
      <button class="explore-btn" onclick="go('favorites')"><span class="ic">❤️</span>المفضلة</button>
      <button class="explore-btn" onclick="go('memberCars')"><span class="ic">🧑‍🤝‍🧑</span>سيارات الأعضاء</button>
      <button class="explore-btn" onclick="go('${account.route}')"><span class="ic">${account.icon}</span>${account.label}</button>
    </div>
  </section>
  ${AdSlot('home_banner')}
  <section id="homeRecent" class="section home-section" aria-labelledby="homeRecentTitle">
    ${_homeHead('homeRecentTitle', '🆕 السيارات المضافة حديثاً', 'recentCars', 'عرض كل السيارات المضافة حديثاً', recent.length > 0)}
    <p class="sub">أحدث السيارات التي أضيفت إلى معارض النجف</p>
    ${recentBody}
  </section>
  <section id="homeCars" class="section home-section" aria-labelledby="homeCarsTitle">
    ${_homeHead('homeCarsTitle', '🔥 أحدث السيارات', 'cars', 'عرض كل السيارات', feed.cars.length > 0)}
    ${carsBody}
  </section>
  <section id="homeShowrooms" class="section home-section" aria-labelledby="homeShowroomsTitle">
    ${_homeHead('homeShowroomsTitle', '🏢 معارض النجف', 'showrooms', 'عرض كل المعارض', feed.showrooms.length > 0)}
    ${showroomsBody}
  </section>
  <section id="homeValue" class="section home-section home-value" aria-labelledby="homeValueTitle">
    <h2 id="homeValueTitle">لماذا معارض النجف؟</h2>
    <div class="info-block">
      <ul class="value-list">
        <li><span class="vi" aria-hidden="true">🚘</span>تصفح سيارات المعارض في النجف</li>
        <li><span class="vi" aria-hidden="true">⚖️</span>قارن السيارات والأسعار والمواصفات</li>
        <li><span class="vi" aria-hidden="true">🏢</span>اعرف بأي معرض موجودة السيارة</li>
        <li><span class="vi" aria-hidden="true">📞</span>تواصل مباشرة مع المعرض</li>
      </ul>
    </div>
  </section>
  <section id="homeMembers" class="section home-section" aria-labelledby="homeMembersTitle">
    ${_homeHead('homeMembersTitle', '🧑‍🤝‍🧑 سيارات الأعضاء', 'memberCars', 'عرض كل سيارات الأعضاء', true)}
    ${membersBody}
  </section>`;
}

/* AdminDealerRequestsScreen — طلبات أصحاب المعارض بحالة pending فقط. */
function AdminDealerRequestsScreen() {
  const pending = adminGetAllUsers().filter(u => u.role === 'dealer' && u.status === 'pending');
  return `
  ${BackBar('adminHome')}
  <div class="topbar"><h1>🏪 طلبات أصحاب المعارض</h1></div>
  <div class="section">
    ${pending.length === 0 ? `<div class="placeholder"><span class="ic">✅</span>لا توجد طلبات بانتظار المراجعة.</div>` :
      pending.map(u => `
      <div class="ad-row">
        <div class="card-img">👤</div>
        <div class="ad-info">
          <p class="card-title">${esc(u.name)}</p>
          <p class="card-row">📞 ${esc(u.phone)}</p>
          <p class="card-row">🗓️ ${createdDateText(u.createdAt)}</p>
          <div class="admin-actions">
            <button class="approve" onclick="handleApproveDealer(${u.id})">✅ موافقة</button>
            <button class="danger" onclick="handleRejectDealer(${u.id})">❌ رفض</button>
          </div>
        </div>
      </div>`).join('')}
  </div>`;
}

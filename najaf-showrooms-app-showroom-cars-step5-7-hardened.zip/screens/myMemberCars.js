/* MyMemberCarsScreen — «سياراتي / إعلاناتي». يعتمد على ownerId===currentUser.id فقط
   (getMemberCarsByOwner من الخدمة)، وليس على إخفاء في الواجهة. */
function MyMemberCarsScreen() {
  const user = SessionService.getCurrentUser();
  const myCars = user ? getMemberCarsByOwner(user.id) : [];
  return `
  ${BackBar('account')}
  <div class="topbar"><h1>📋 سياراتي (إعلاناتي)</h1></div>
  <div class="section">
    ${myCars.length === 0
      ? EmptyState({ icon: '🚘', title: 'لا توجد سيارات مضافة', hint: 'انشر سيارتك مجانًا لتظهر للمشترين.', actions: [{ label: '➕ نشر سيارة جديدة', onclick: "go('addMemberCar')" }] })
      : `<button class="btn-primary" style="margin:0 0 14px" onclick="go('addMemberCar')">➕ نشر سيارة جديدة</button>` + myCars.map(c => `
      <div class="ad-row">
        <div class="card-img">${CarImageInner(c)}</div>
        <div class="ad-info">
          <p class="card-title">${esc(c.brand)} ${esc(c.model)}</p>
          <p class="card-row">${val(c.year)}</p>
          <p class="price">${carPriceOrDash(c)}</p>
          ${memberCarStatusBadge(c.status)}
          ${c.status === 'rejected' && c.rejectionReason ? `<div class="reason-box">السبب: ${esc(c.rejectionReason)}</div>` : ''}
          ${c.status === 'suspended' && c.suspensionReason ? `<div class="reason-box">السبب: ${esc(c.suspensionReason)}</div>` : ''}
          <p class="card-row">🗓️ ${val(createdDateText(c.createdAt))}</p>
          <div class="ad-actions">
            <button onclick="go('memberCarDetails', ${c.id})">عرض</button>
            <button onclick="go('editMemberCar', ${c.id})">تعديل</button>
            <button onclick="handleMemberCarStatusChange(${c.id})">تغيير الحالة</button>
            <button class="danger" onclick="handleDeleteMemberCar(${c.id})">حذف</button>
          </div>
        </div>
      </div>`).join('')}
  </div>`;
}

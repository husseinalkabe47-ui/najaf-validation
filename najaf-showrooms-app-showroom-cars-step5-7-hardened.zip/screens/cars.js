/* سيارات المعارض: بحث + فلاتر (ماركة/موديل/سنة/سعر/كيلومترات) + حالات فارغة واضحة.
   الفلاتر والخيارات من محرك CarFilters؛ والسيارات عبر searchCars (سيارات المعرض الموقوف مخفية عن غير مالكها/المدير).
   (UX ج3) الشاشة تفتح ببحث بارز والسيارات تحته؛ لوحة الفلاتر المتقدمة (FilterBar نفسه وحالته carsFilters ومعالجاته) مطويّة افتراضيًا
   خلف زر «تصفية» مع شارة بعدد الفلاتر الفعالة. الطيّ عرض فقط: لا محرك ولا حالة فلترة ثانية، وطيّ اللوحة لا يمسح شيئًا. */
let carsSearchQuery = '';
let carsFilters = newFilters();
let carsFiltersOpen = false;   // حالة طيّ اللوحة فقط (تبقى عبر render() للشاشة نفسها كضغط ♡؛ وتبدأ مطويّة عند كل دخول جديد للشاشة)

function _carsPool() { return searchCars('', 'showroom'); }
function _carsOpts() { return CarFilters.options(_carsPool(), carsFilters); }
function _carsFilterBarHtml() { return FilterBar('cars', _carsOpts(), carsFilters, 'onCarsFilter', 'clearCarsFilters', 'onCarsRange', 'removeCarsFilter'); }

function renderCarsList() {
  const results = searchCars(carsSearchQuery, 'showroom', carsFilters);
  if (results.length === 0) {
    const hasQ = !!carsSearchQuery.trim(), hasF = activeFilterCount(carsFilters) > 0;
    if (!hasQ && !hasF) return EmptyState({ icon: '🚘', title: 'لا توجد سيارات حاليًا', hint: 'ستظهر هنا سيارات المعارض فور إضافتها.',
      actions: [{ label: 'تصفح المعارض', onclick: "go('showrooms')" }, { label: 'سيارات الأعضاء', onclick: "go('memberCars')", primary: false }] });
    const actions = [];
    if (hasQ) actions.push({ label: 'مسح البحث', onclick: 'clearCarsSearch()' });
    if (hasF) actions.push({ label: 'مسح الفلاتر', onclick: 'clearCarsFilters()', primary: !hasQ });
    return EmptyState({ icon: '🔍', title: 'لم نعثر على سيارات مطابقة لبحثك', hint: hasF ? 'جرّب تخفيف الفلاتر المختارة.' : 'تأكد من كتابة الماركة أو الموديل، أو جرّب كلمات أقل.', actions });
  }
  // العدّاد + اختصار «الخريطة» (مسار map القائم: مواقع المعارض) — سؤال «وين ألكه هاي السيارة؟» ينتهي غالبًا بمعرفة موقع المعرض
  return `<div class="results-head"><p class="results-count" aria-live="polite">النتائج: ${carCountLabel(results.length)}</p>
    <button type="button" class="link-btn" onclick="go('map')" aria-label="عرض مواقع المعارض على الخريطة">📍 الخريطة</button></div><div class="list-grid">${
    results.map((c, i) =>
      CarCard(c) + ((i + 1) % 4 === 0 && i !== results.length - 1 ? AdSlot('cars_list_inline_' + c.id, true) : '')
    ).join('')
  }</div>`;
}
/* ---- زر «تصفية» ولوحة الفلاتر القابلة للطيّ (واجهة فقط) ---- */
function _carsFiltersLabel(n) { return n === 1 ? 'فلتر واحد فعّال' : n === 2 ? 'فلتران فعّالان' : `${n} فلاتر فعّالة`; }
function _carsToggleLabel(n) { return n > 0 ? `تصفية السيارات، ${_carsFiltersLabel(n)}` : 'تصفية السيارات'; }   // الاسم يحوي النص الظاهر «تصفية»
function _carsToggleHtml(n) {
  return `<button type="button" id="carsRefineToggle" class="filter-toggle${n > 0 ? ' has-filters' : ''}" aria-expanded="${carsFiltersOpen ? 'true' : 'false'}" aria-controls="carsRefinePanel" aria-label="${esc(_carsToggleLabel(n))}" onclick="toggleCarsFilterPanel()"><span aria-hidden="true">⚙️</span><span class="ft-label">تصفية</span><span class="ft-badge" id="carsRefineBadge" aria-hidden="true"${n > 0 ? '' : ' hidden'}>${n}</span></button>`;
}
function _carsDoneLabel() { const k = carCountLabel(searchCars(carsSearchQuery, 'showroom', carsFilters).length); return k ? `عرض النتائج (${k})` : 'عرض النتائج'; }
function _setAttr(el, k, v) { if (el && typeof el.setAttribute === 'function') el.setAttribute(k, v); }
/** يزامن عناصر الطيّ مع الحالة (الزر/الشارة/اللوحة/الملخص/زر العرض) دون استبدال الزر نفسه (يبقى التركيز عليه) */
function _syncCarsFilterUi() {
  const n = activeFilterCount(carsFilters);
  const btn = document.getElementById('carsRefineToggle');
  if (btn) { btn.className = 'filter-toggle' + (n > 0 ? ' has-filters' : ''); _setAttr(btn, 'aria-expanded', carsFiltersOpen ? 'true' : 'false'); _setAttr(btn, 'aria-label', _carsToggleLabel(n)); }
  const badge = document.getElementById('carsRefineBadge'); if (badge) { badge.textContent = String(n); badge.hidden = n === 0; }
  const panel = document.getElementById('carsRefinePanel'); if (panel) panel.hidden = !carsFiltersOpen;
  // اللوحة مطويّة: ملخص الفلاتر الفعالة (نفس FilterChips بما فيه «مسح الفلاتر») يبقى ظاهرًا؛ والمفتوحة تعرضها داخلها فلا تكرار
  const sum = document.getElementById('carsRefineSummary');
  if (sum) { const html = (!carsFiltersOpen && n > 0) ? FilterChips('cars', _carsOpts(), carsFilters, 'clearCarsFilters', 'removeCarsFilter') : ''; sum.innerHTML = html; sum.hidden = !html; }
  const done = document.getElementById('carsRefineDone'); if (done) done.textContent = _carsDoneLabel();
}
function toggleCarsFilterPanel() {
  carsFiltersOpen = !carsFiltersOpen;
  _syncCarsFilterUi();
  const panel = document.getElementById('carsRefinePanel');
  if (carsFiltersOpen && panel && typeof panel.scrollIntoView === 'function') panel.scrollIntoView({ block: 'nearest' });
}
/** طيّ اللوحة بلا مسح أي فلتر؛ التركيز يعود للزر (لا يضيع داخل لوحة اختفت) والنتائج تظهر */
function closeCarsFilterPanel() {
  carsFiltersOpen = false;
  _syncCarsFilterUi();
  const btn = document.getElementById('carsRefineToggle'); if (btn && typeof btn.focus === 'function') btn.focus({ preventScroll: true });
  const list = document.getElementById('carsList'); if (list && typeof list.scrollIntoView === 'function') list.scrollIntoView({ block: 'start' });
}
/* Escape يطوي اللوحة؛ لا تدخّل إن كانت نافذة حوار مفتوحة. تُسجَّل مرة واحدة. */
(function bindCarsFilterPanelEscape() {
  if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return;
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape' || !carsFiltersOpen || currentRoute !== 'cars') return;
    if (typeof ModalFocus !== 'undefined' && ModalFocus.isActive && ModalFocus.isActive()) return;
    if (typeof filterPopupOpen === 'function' && filterPopupOpen()) return;   // أول Escape يغلق نافذة السعر/الكيلومترات المفتوحة (سلوك مكوّن الفلاتر القائم)، والثاني يطوي اللوحة
    closeCarsFilterPanel();
  }, true);
})();

function _refreshCars() {
  const bar = document.getElementById('carsFilterBar'); if (bar) bar.innerHTML = _carsFilterBarHtml();
  const list = document.getElementById('carsList'); if (list) list.innerHTML = renderCarsList();
  _syncCarsFilterUi();
}
function onCarsSearch(value) { carsSearchQuery = value; const list = document.getElementById('carsList'); if (list) list.innerHTML = renderCarsList(); _syncCarsFilterUi(); }
/** قوائم الاختيار: تعيد رسم الشريط (الموديلات تتبع الماركة، وموديل لا ينتمي للماركة الجديدة يُسقَط) */
function onCarsFilter() { carsFilters = CarFilters.reconcileModel(readFilters('cars'), _carsPool()); _refreshCars(); }
/** حقول الأرقام: تحديث القائمة والشارات فقط كي لا يضيع التركيز أثناء الكتابة */
function onCarsRange() {
  carsFilters = readFilters('cars');
  const chips = document.getElementById('carsFilterChips'); if (chips) chips.innerHTML = FilterChips('cars', _carsOpts(), carsFilters, 'clearCarsFilters', 'removeCarsFilter');
  const list = document.getElementById('carsList'); if (list) list.innerHTML = renderCarsList();
  _syncCarsFilterUi();
}
/** شارة «×»: يزيل فلترًا واحدًا (والموديل تبعًا للماركة) من حالة الشاشة نفسها ثم يعيد الرسم */
function removeCarsFilter(key) { carsFilters = CarFilters.without(carsFilters, key); _refreshCars(); }
function clearCarsFilters() { carsFilters = newFilters(); carsFiltersOpen = false; render(); }   // المسح الكامل يعيد القائمة العادية (اللوحة مطويّة)
function clearCarsSearch() { carsSearchQuery = ''; render(); }

function CarsScreen() {
  // دخول جديد للشاشة (الشاشة السابقة في الصفحة ليست السيارات) ← اللوحة مطويّة؛ إعادة رسم الشاشة نفسها (♡، مسح البحث) تحفظ حالتها
  const prev = (document.getElementById('screen') || {}).innerHTML;
  if (!(typeof prev === 'string' && prev.includes('id="carsRefinePanel"'))) carsFiltersOpen = false;
  const n = activeFilterCount(carsFilters);
  return `
  <div class="topbar">
    <h1>🚘 السيارات</h1>
    <p class="sub">ماركة، موديل، سنة، معرض أو عنوان</p>
    <div class="cars-tools">
      ${SearchBox('ابحث عن سيارة', 'onCarsSearch', carsSearchQuery)}
      ${_carsToggleHtml(n)}
    </div>
  </div>
  <div class="section">
    <div id="carsRefineSummary" class="filter-summary"${(!carsFiltersOpen && n > 0) ? '' : ' hidden'}>${(!carsFiltersOpen && n > 0) ? FilterChips('cars', _carsOpts(), carsFilters, 'clearCarsFilters', 'removeCarsFilter') : ''}</div>
    <div id="carsRefinePanel" class="filter-panel" role="group" aria-label="تصفية السيارات"${carsFiltersOpen ? '' : ' hidden'}>
      <div id="carsFilterBar">${_carsFilterBarHtml()}</div>
      <button type="button" id="carsRefineDone" class="btn-primary" onclick="closeCarsFilterPanel()">${_carsDoneLabel()}</button>
    </div>
    <div id="carsList">${renderCarsList()}</div>
  </div>`;
}

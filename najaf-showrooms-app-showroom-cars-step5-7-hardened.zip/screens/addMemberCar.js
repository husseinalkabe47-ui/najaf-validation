/* AddMemberCarScreen — نموذج نشر سيارة عضو.
   المرحلة 6: التحقق من الحقول والصلاحية داخل memberCarsService.createDraftMemberCar.
   - dealer/admin: يُنشر النموذج فورًا active بلا إعلان (rewardService.isRewardRequired=false).
   - user: يفتح RewardAdModal (عدّاد تنازلي Mock) ولا يُنشر إلا بعد اكتماله. */
function AddMemberCarScreen() {
  initImageCtxDraft(IMAGE_LIMITS.USER_MAX_IMAGES); // سيارة عضو: حتى 4 صور (الرئيسية ضمنها)
  const user = SessionService.getCurrentUser();
  const needsReward = RewardService.isRewardRequired(user);
  return `
  ${BackBar('memberCars')}
  <div class="topbar"><h1>➕ نشر سيارة</h1><p class="sub">${needsReward ? 'نشر مجاني — شاهد إعلانًا قصيرًا لإكمال النشر' : 'ينشر إعلانك مباشرة'}</p></div>
  <div class="section">
    <div class="form-card">
      <div class="field"><label for="mcBrand">الماركة *</label><input id="mcBrand" aria-required="true" type="text" placeholder="مثال: Toyota"></div>
      <div class="field"><label for="mcModel">الموديل *</label><input id="mcModel" aria-required="true" type="text" placeholder="مثال: Corolla"></div>
      <div class="field"><label for="mcYear">سنة الصنع *</label><input id="mcYear" aria-required="true" inputmode="numeric" type="text" dir="ltr" placeholder="2020"></div>
      <div class="field"><label for="mcPrice">السعر *</label><input id="mcPrice" aria-required="true" inputmode="numeric" type="text" dir="ltr" placeholder="15000000"></div>
      <div class="field"><label for="mcCurrency">عملة السعر *</label><select id="mcCurrency">${currencyOptionsHtml('IQD')}</select></div>
      <div class="field"><label for="mcMileage">الكيلومترات</label><input id="mcMileage" inputmode="numeric" type="text" dir="ltr" placeholder="80000"></div>
      <div class="field"><label for="mcTransmission">ناقل الحركة</label>
        <select id="mcTransmission"><option value="أوتوماتيك">أوتوماتيك</option><option value="يدوي">يدوي</option></select></div>
      <div class="field"><label for="mcFuelType">نوع الوقود</label>
        <select id="mcFuelType"><option value="بنزين">بنزين</option><option value="ديزل">ديزل</option><option value="هايبرد">هايبرد</option><option value="كهرباء">كهرباء</option></select></div>
      <div class="field"><label for="mcColor">اللون</label><input id="mcColor" type="text"></div>
      <div class="field"><label for="mcLocation">الموقع</label><input id="mcLocation" type="text" placeholder="مثال: حي النصر، النجف"></div>
      <div class="field"><label for="mcPhone">رقم الهاتف *</label><input id="mcPhone" aria-required="true" inputmode="tel" autocomplete="tel" type="text" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="field"><label for="mcWhatsapp">رقم واتساب</label><input id="mcWhatsapp" inputmode="tel" autocomplete="tel" type="text" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="field"><label for="mcDescription">وصف السيارة</label><textarea id="mcDescription" placeholder="حالة السيارة، أي ملاحظات..."></textarea></div>
      <div class="field" role="group" aria-labelledby="imgPickerLabel"><label id="imgPickerLabel">الصور</label>${ImagePickerHtml()}</div>
      <div id="addMemberCarError" class="form-error" role="alert" style="display:none"></div>
      <button id="addMemberCarBtn" class="btn-primary" onclick="handleAddMemberCarSubmit()">${needsReward ? '🚗 نشر السيارة مجانًا' : 'نشر السيارة'}</button>
    </div>
  </div>
  ${RewardAdModal()}`;
}

/** نافذة بوابة الإعلان — مخفية افتراضيًا، تُظهرها/تُحدّثها actions.js حسب حالة rewardService.
    نفس الهيكل الذي سيستبدل لاحقًا Mock بمكوّن AdMob الحقيقي دون تغيير هذه الشاشة. */
function RewardAdModal() {
  return `
  <div id="rewardAdOverlay" class="modal-overlay" style="display:none">
    <div id="rewardAdBox" class="modal-box" role="dialog" aria-modal="true" aria-labelledby="rewardAdTitleIntro">
      <div id="rewardAdStepIntro">
        <p id="rewardAdTitleIntro" class="modal-title">🚗 نشر سيارتك مجانًا</p>
        <p class="sub">شاهد إعلانًا قصيرًا لإكمال النشر.</p>
        <div id="rewardAdError" class="form-error" role="alert" style="display:none"></div>
        <button class="btn-primary" onclick="handleWatchRewardAd()">▶️ مشاهدة الإعلان</button>
        <button class="link-btn" style="width:100%;margin-top:8px" onclick="handleCancelRewardAd()">إلغاء</button>
      </div>
      <div id="rewardAdStepPlaying" style="display:none;text-align:center">
        <p id="rewardAdTitlePlaying" class="modal-title">الإعلان التجريبي</p>
        <p class="sub">إعلان مكافأ تجريبي — بيئة تطوير فقط</p>
        <div id="rewardAdCountdown" class="countdown-num" role="timer" aria-live="off">00:10</div>
        <button class="link-btn" onclick="handleCancelRewardAd()">إلغاء</button>
      </div>
      <div id="rewardAdStepDone" role="status" style="display:none;text-align:center">
        <p id="rewardAdTitleDone" class="modal-title">✅ اكتمل الإعلان</p>
        <p class="sub">تم نشر سيارتك بنجاح</p>
      </div>
    </div>
  </div>`;
}

function AccountScreen() {
  const user = SessionService.getCurrentUser();
  const pendingDealer = user && user.role === ROLES.DEALER && user.status === USER_STATUS.PENDING;
  return `
  ${BackBar('home')}
  <div class="topbar"><h1>👤 حسابي</h1></div>
  <div class="section">
    ${AccountCard(user)}
    ${pendingDealer ? `<div class="form-note" style="margin:0 0 14px">طلبك كصاحب معرض قيد المراجعة. ستظهر «إدارة معرضي» بعد موافقة الإدارة.</div>` : ''}
    <div class="owner-actions">
      <button onclick="go('myMemberCars')">📋 سياراتي (إعلاناتي)</button>
      <button onclick="go('addMemberCar')">➕ إضافة سيارة</button>
      <button onclick="go('favorites')">❤️ المفضلة</button>
    </div>
  </div>`;
}

function AccessDeniedScreen() {
  return `
  <div class="topbar"><h1>🚫 غير مصرّح</h1></div>
  <div class="placeholder"><span class="ic">🔒</span>ليست لديك صلاحية للوصول إلى هذه الصفحة.
    <button class="btn-primary" onclick="go('home')">العودة للرئيسية</button></div>`;
}

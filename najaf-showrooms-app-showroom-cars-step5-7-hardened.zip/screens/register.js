function RegisterScreen() {
  return `
  ${BackBar('login')}
  <div class="topbar"><h1>📝 إنشاء حساب</h1><p class="sub">أنشئ حسابك للاستفادة من كل الخدمات</p></div>
  <div class="section">
    <div class="form-card">
      <div class="field"><label for="regName">الاسم الكامل</label><input id="regName" type="text" autocomplete="name"></div>
      <div class="field"><label for="regPhone">رقم الهاتف</label><input id="regPhone" inputmode="tel" type="text" dir="ltr" autocomplete="tel" placeholder="07XXXXXXXXX"></div>
      <div class="field"><label for="regEmail">البريد الإلكتروني (اختياري)</label><input id="regEmail" inputmode="email" type="email" dir="ltr" autocomplete="email"></div>
      <div class="field"><label for="regPassword">كلمة المرور</label><input id="regPassword" type="password" dir="ltr" autocomplete="new-password"></div>
      <div class="field"><label for="regConfirm">تأكيد كلمة المرور</label><input id="regConfirm" type="password" dir="ltr" autocomplete="new-password"></div>
      <div class="field" role="radiogroup" aria-labelledby="regTypeLabel"><label id="regTypeLabel">نوع الحساب</label>
        <div class="type-switch">
          <label><input type="radio" name="accountType" value="user" checked onchange="onAccountTypeChange()"><span>👤 مستخدم عادي</span></label>
          <label><input type="radio" name="accountType" value="dealer" onchange="onAccountTypeChange()"><span>🏢 صاحب معرض</span></label>
        </div>
      </div>
      <div id="dealerNote" class="form-note" style="display:none">حساب صاحب المعرض يبدأ بحالة «بانتظار الموافقة»، ولن تُفعَّل إدارة المعرض إلا بعد موافقة الإدارة.</div>
      <div id="registerError" class="form-error" role="alert" style="display:none"></div>
      <button class="btn-primary" onclick="handleRegisterSubmit()">إنشاء الحساب</button>
      <div class="form-links"><button class="link-btn" onclick="go('login')">لديّ حساب بالفعل</button></div>
    </div>
  </div>`;
}

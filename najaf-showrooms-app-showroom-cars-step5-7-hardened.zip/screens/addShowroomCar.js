/* إضافة سيارة لمعرض التاجر. لا حقل للمعرض (يُشتق من الحساب)، ولا إعلان ولا موافقة:
   تُنشر السيارة فورًا. الصور حتى 5 (الرئيسية ضمنها). */
function AddShowroomCarScreen() {
  initImageCtxDraft(IMAGE_LIMITS.SHOWROOM_MAX_IMAGES);
  return `
  ${BackBar('myShowroomCars')}
  <div class="topbar"><h1>➕ إضافة سيارة</h1><p class="sub">تظهر سيارتك في معرضك مباشرة</p></div>
  <div class="section"><div class="form-card">
    <div class="field"><label for="scBrand">الماركة *</label><input id="scBrand" aria-required="true" type="text" placeholder="مثال: Toyota"></div>
    <div class="field"><label for="scModel">الموديل *</label><input id="scModel" aria-required="true" type="text" placeholder="مثال: Corolla"></div>
    <div class="field"><label for="scYear">سنة الصنع *</label><input id="scYear" aria-required="true" inputmode="numeric" type="text" dir="ltr" placeholder="2022"></div>
    <div class="field"><label for="scPrice">السعر *</label><input id="scPrice" aria-required="true" inputmode="numeric" type="text" dir="ltr" placeholder="18000000"></div>
    <div class="field"><label for="scCurrency">عملة السعر *</label><select id="scCurrency">${currencyOptionsHtml('IQD')}</select></div>
    <div class="field"><label for="scMileage">المسافة المقطوعة (كم)</label><input id="scMileage" inputmode="numeric" type="text" dir="ltr" placeholder="65000"></div>
    <div class="field"><label for="scTransmission">ناقل الحركة</label>
      <select id="scTransmission"><option value="أوتوماتيك">أوتوماتيك</option><option value="يدوي">يدوي</option></select></div>
    <div class="field"><label for="scFuelType">نوع الوقود</label>
      <select id="scFuelType"><option value="بنزين">بنزين</option><option value="ديزل">ديزل</option><option value="هايبرد">هايبرد</option><option value="كهرباء">كهرباء</option></select></div>
    <div class="field"><label for="scColor">اللون</label><input id="scColor" type="text"></div>
    <div class="field"><label for="scDescription">الوصف</label><textarea id="scDescription"></textarea></div>
    <div class="field" role="group" aria-labelledby="imgPickerLabel"><label id="imgPickerLabel">الصور</label>${ImagePickerHtml()}</div>
    <div id="showroomCarError" class="form-error" role="alert" style="display:none"></div>
    <button id="addShowroomCarBtn" class="btn-primary" onclick="handleAddShowroomCarSubmit()">نشر السيارة</button>
  </div></div>`;
}

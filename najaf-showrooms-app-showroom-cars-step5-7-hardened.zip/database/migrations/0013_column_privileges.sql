-- ===== MIGRATION 0013 — تشديد صلاحيات الأعمدة (المرحلة 11.3) =====================
-- القرار المتفق عليه في 11.2: حساب التطبيق يحدّث الأعمدة التي يغيّرها فعلًا فقط.
-- ممنوع عليه بعد هذا الترحيل: id، أعمدة الملكية والنوع (owner_id، showroom_id، source_type)، وcreated_at وupdated_at وversion
-- (الأخيران يحدّثهما المشغّل touch_versioned وحده، وتغييرهما بـSET في جملة UPDATE يحتاج صلاحية عمود لا يملكها التطبيق).
-- مشغّلات الجداول تعدّل NEW.updated_at/NEW.version دون الحاجة لصلاحية عمود (الفحص على أعمدة SET في الجملة فقط).
-- السحب ثم المنح: REVOKE على مستوى الجدول يسحب صلاحيات الأعمدة أيضًا، ثم تُمنح الأعمدة المسموحة صراحةً. الترحيل idempotent.
REVOKE UPDATE ON showrooms, cars, car_images, favorites FROM najaf_app;

GRANT UPDATE (name, description, phone, whatsapp, address, latitude, longitude, cover_asset_id, working_hours, services,
              status, reviewed_by, reviewed_at, search_text) ON showrooms TO najaf_app;

GRANT UPDATE (brand, model, year, price, currency, mileage, transmission, fuel_type, color, description, status,
              phone, whatsapp, location, latitude, longitude, rejection_reason, suspension_reason,
              reviewed_at, reviewed_by, search_text, deleted_at) ON cars TO najaf_app;

GRANT UPDATE (sort_order, is_main) ON car_images TO najaf_app;
-- favorites: لا UPDATE إطلاقًا (تُضاف وتُحذف فقط).

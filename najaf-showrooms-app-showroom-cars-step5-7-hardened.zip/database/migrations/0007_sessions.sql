-- ===== MIGRATION 0007 — الجلسات ورموز التحديث ==================================
CREATE TABLE sessions (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      bigint      NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  family_id    uuid        NOT NULL,                         -- عائلة رموز التحديث (كشف إعادة الاستعمال)
  token_hash   bytea       NOT NULL,                         -- SHA-256 للرمز؛ الرمز نفسه لا يُخزَّن
  created_at   timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  revoked_at   timestamptz,
  revoked_reason text,
  replaced_by  uuid REFERENCES sessions (id) ON DELETE SET NULL,
  user_agent   varchar(300),
  ip_hash      bytea,
  CONSTRAINT sessions_token_hash_len CHECK (octet_length(token_hash) = 32),
  CONSTRAINT sessions_expiry_after   CHECK (expires_at > created_at),
  CONSTRAINT sessions_revoke_pair    CHECK ((revoked_at IS NULL) = (revoked_reason IS NULL)),
  CONSTRAINT sessions_reason_vocab   CHECK (revoked_reason IS NULL OR revoked_reason IN
    ('logout', 'logout_all', 'rotated', 'reuse_detected', 'user_suspended', 'user_deleted', 'password_changed', 'admin_revoked'))
);
CREATE UNIQUE INDEX sessions_token_hash_uq ON sessions (token_hash);
CREATE INDEX sessions_user_live_idx ON sessions (user_id) WHERE revoked_at IS NULL;
CREATE INDEX sessions_family_idx    ON sessions (family_id);
CREATE INDEX sessions_expiry_idx    ON sessions (expires_at);                -- مهمة التنظيف

-- إيقاف الحساب أو حذفه أو تغيير كلمة المرور يُلغي كل جلساته في المعاملة نفسها (السلوك الفوري للنموذج الأولي)
CREATE FUNCTION users_revoke_sessions() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE why text;
BEGIN
  IF NEW.status = 'suspended' AND OLD.status <> 'suspended' THEN why := 'user_suspended';
  ELSIF NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL THEN why := 'user_deleted';
  ELSIF NEW.password_hash <> OLD.password_hash THEN why := 'password_changed';
  END IF;
  IF why IS NOT NULL THEN
    UPDATE sessions SET revoked_at = now(), revoked_reason = why WHERE user_id = NEW.id AND revoked_at IS NULL;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER users_revoke_sessions_au AFTER UPDATE OF status, deleted_at, password_hash ON users
  FOR EACH ROW EXECUTE FUNCTION users_revoke_sessions();

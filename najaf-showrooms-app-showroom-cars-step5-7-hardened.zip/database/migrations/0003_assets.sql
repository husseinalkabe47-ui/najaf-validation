-- ===== MIGRATION 0003 — الملفات (الصور بعد المعالجة) ===========================
-- لا حقول للأصل (لا نسخة أصلية تُحفظ): فقط الناتج المعالَج (WebP + مصغّرة).
CREATE TABLE assets (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),     -- غير قابل للتخمين (مفتاح الرابط العام)
  owner_id    bigint      NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
  kind        text        NOT NULL,
  status      text        NOT NULL DEFAULT 'pending',
  storage_key text,
  thumb_key   text,
  mime        text,
  bytes       integer,
  width       smallint,
  height      smallint,
  sha256      char(64),
  reject_reason varchar(200),
  legacy_ref  text,                                                 -- مرجع النموذج الأولي (idb:<id> أو مسار) للاستيراد فقط
  created_at  timestamptz NOT NULL DEFAULT now(),
  ready_at    timestamptz,
  CONSTRAINT assets_kind_vocab   CHECK (kind IN ('car_image', 'showroom_cover')),
  CONSTRAINT assets_status_vocab CHECK (status IN ('pending', 'ready', 'rejected')),
  CONSTRAINT assets_mime_vocab   CHECK (mime IS NULL OR mime = 'image/webp'),
  CONSTRAINT assets_bytes_pos    CHECK (bytes IS NULL OR bytes > 0),
  CONSTRAINT assets_dims_pos     CHECK ((width IS NULL OR width > 0) AND (height IS NULL OR height > 0)),
  CONSTRAINT assets_sha256_hex   CHECK (sha256 IS NULL OR sha256 ~ '^[0-9a-f]{64}$'),
  CONSTRAINT assets_ready_shape  CHECK (status <> 'ready' OR (storage_key IS NOT NULL AND thumb_key IS NOT NULL AND mime IS NOT NULL AND bytes IS NOT NULL AND width IS NOT NULL AND height IS NOT NULL AND sha256 IS NOT NULL AND ready_at IS NOT NULL)),
  CONSTRAINT assets_rejected_why CHECK (status <> 'rejected' OR reject_reason IS NOT NULL)
);
CREATE UNIQUE INDEX assets_storage_key_uq ON assets (storage_key) WHERE storage_key IS NOT NULL;
CREATE UNIQUE INDEX assets_legacy_ref_uq  ON assets (legacy_ref)  WHERE legacy_ref IS NOT NULL;
CREATE INDEX assets_owner_idx   ON assets (owner_id, created_at DESC);
CREATE INDEX assets_cleanup_idx ON assets (created_at) WHERE status IN ('pending', 'rejected');   -- مهمة حذف غير المرفقة بعد 24 ساعة

-- ===== MIGRATION 0008 — رموز التحقق والاسترداد (OTP) وسجل التسليم =================
-- الرمز يُولَّد ويُتحقَّق منه في نظامنا (HMAC-SHA256 بفلفل الخادم)؛ المزوّد وسيلة نقل فقط.
CREATE TABLE verification_codes (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  purpose      text        NOT NULL,
  user_id      bigint      NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  target_phone e164_iq     NOT NULL,
  code_hash    bytea       NOT NULL,
  attempts     smallint    NOT NULL DEFAULT 0,
  max_attempts smallint    NOT NULL DEFAULT 5,
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  consumed_at  timestamptz,
  invalidated_at timestamptz,
  requested_ip_hash bytea,
  CONSTRAINT vcodes_purpose_vocab CHECK (purpose IN ('phone_verify', 'password_reset')),
  CONSTRAINT vcodes_hash_len      CHECK (octet_length(code_hash) = 32),
  CONSTRAINT vcodes_attempts_ok   CHECK (attempts >= 0 AND max_attempts > 0 AND attempts <= max_attempts),
  CONSTRAINT vcodes_expiry_after  CHECK (expires_at > created_at),
  CONSTRAINT vcodes_not_both      CHECK (consumed_at IS NULL OR invalidated_at IS NULL)
);
-- رمز فعّال واحد لكل (مستخدم، غرض): إصدار رمز جديد يُبطل السابق في المعاملة نفسها
CREATE UNIQUE INDEX vcodes_one_active_uq ON verification_codes (user_id, purpose) WHERE consumed_at IS NULL AND invalidated_at IS NULL;
CREATE INDEX vcodes_rate_idx   ON verification_codes (target_phone, created_at DESC);   -- حدود: 60 ثانية/3 ساعة/10 يوم
CREATE INDEX vcodes_expiry_idx ON verification_codes (expires_at);

CREATE TABLE message_deliveries (
  id                   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  verification_code_id uuid REFERENCES verification_codes (id) ON DELETE SET NULL,
  channel              text        NOT NULL,
  provider             varchar(40) NOT NULL,                 -- نص حرّ (غير محصور): المزوّد قابل للتبديل
  to_phone             e164_iq     NOT NULL,
  provider_message_id  text,
  status               text        NOT NULL DEFAULT 'queued',
  error_code           varchar(60),
  cost_micros          bigint,                               -- التكلفة بمايكرو-دولار (بلا فاصلة عائمة)
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  delivered_at         timestamptz,
  CONSTRAINT msgdel_channel_vocab CHECK (channel IN ('whatsapp', 'sms')),
  CONSTRAINT msgdel_status_vocab  CHECK (status IN ('queued', 'sent', 'delivered', 'failed', 'unknown')),
  CONSTRAINT msgdel_cost_nonneg   CHECK (cost_micros IS NULL OR cost_micros >= 0),
  CONSTRAINT msgdel_delivered_at  CHECK (status <> 'delivered' OR delivered_at IS NOT NULL)
);
CREATE UNIQUE INDEX msgdel_provider_msg_uq ON message_deliveries (provider, provider_message_id) WHERE provider_message_id IS NOT NULL;
CREATE INDEX msgdel_budget_idx ON message_deliveries (channel, created_at DESC);          -- ميزانية يومية وقاطع الدائرة
CREATE INDEX msgdel_phone_idx  ON message_deliveries (to_phone, created_at DESC);
CREATE TRIGGER msgdel_touch_bu BEFORE UPDATE ON message_deliveries FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

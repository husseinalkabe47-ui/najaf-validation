-- ===== MIGRATION 0012 — views الظهور العام وصلاحيات الأدوار ======================
-- views هي المصدر الوحيد لكل استعلام عام (قوائم، بحث، فلاتر، خريطة، مفضلة). أعمدة بقائمة بيضاء:
-- لا owner_id ولا reviewed_* ولا حالات المراجعة. اسم مالك إعلان العضو فقط (كما يعرضه النموذج الأولي).
CREATE VIEW public_showrooms WITH (security_barrier = true) AS
SELECT s.id, s.name, s.description, s.phone, s.whatsapp, s.address, s.latitude, s.longitude,
       s.cover_asset_id, s.working_hours, s.services, s.search_text, s.created_at, s.updated_at
  FROM showrooms s
  JOIN users u ON u.id = s.owner_id
 WHERE s.status = 'active' AND u.status = 'active' AND u.deleted_at IS NULL;

CREATE VIEW public_cars WITH (security_barrier = true) AS
SELECT c.id, c.source_type, c.showroom_id, c.brand, c.model, c.year, c.price, c.currency, c.mileage,
       c.transmission, c.fuel_type, c.color, c.description, c.status,
       c.phone, c.whatsapp, c.location, c.latitude, c.longitude,
       CASE WHEN c.source_type = 'member' THEN uo.name END AS owner_name,
       c.search_text, c.created_at, c.updated_at
  FROM cars c
  LEFT JOIN public_showrooms ps ON ps.id = c.showroom_id
  LEFT JOIN users uo ON uo.id = c.owner_id
 WHERE c.deleted_at IS NULL
   AND ( (c.source_type = 'showroom' AND ps.id IS NOT NULL)
      OR (c.source_type = 'member' AND c.status = 'active' AND uo.status = 'active' AND uo.deleted_at IS NULL) );

-- الأدوار تُنشأ بلا تسجيل دخول (NOLOGIN)؛ البنية التحتية تمنح أدوار الدخول لها.
-- najaf_app: حساب التطبيق (DML فقط، بلا DDL). najaf_report: قراءة الـviews وسجل التدقيق.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'najaf_app')    THEN CREATE ROLE najaf_app NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'najaf_report') THEN CREATE ROLE najaf_report NOLOGIN; END IF;
END $$;

GRANT USAGE ON SCHEMA public TO najaf_app, najaf_report;

-- users: لا حذف فعلي، ولا تعديل لـ role/id/created_at/updated_at/version (الخادم عبر المشغّلات وحدها)
GRANT SELECT, INSERT ON users TO najaf_app;
GRANT UPDATE (name, phone_e164, phone_verified_at, email, status, password_hash, password_changed_at,
              failed_logins, locked_until, last_login_at, deleted_at) ON users TO najaf_app;
-- المعارض: لا حذف (إيقاف فقط)
GRANT SELECT, INSERT, UPDATE ON showrooms TO najaf_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON cars, car_images, favorites, assets, sessions, verification_codes, reward_grants TO najaf_app;
GRANT SELECT, INSERT, UPDATE ON message_deliveries, subscription_plans, subscriptions, payments, app_settings TO najaf_app;
-- سجلات للإضافة فقط
GRANT SELECT, INSERT ON audit_logs, exchange_rates TO najaf_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO najaf_app;
-- دوال القراءة تعتمد على جداول (exchange_rates, subscriptions…) لا يقرؤها najaf_report، فتُقصر على najaf_app (EXECUTE ممنوح لـPUBLIC افتراضيًا فيُسحب أولًا)
REVOKE EXECUTE ON FUNCTION current_usd_to_iqd(), to_iqd(numeric, text), entitlements_for_showroom(bigint) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION current_usd_to_iqd(), to_iqd(numeric, text), entitlements_for_showroom(bigint) TO najaf_app;

GRANT SELECT ON public_showrooms, public_cars TO najaf_app, najaf_report;
GRANT SELECT ON audit_logs TO najaf_report;
-- ملاحظة: عزل صفوف PostgreSQL (RLS) خيار دفاع إضافي لاحق، غير مفعَّل هنا.

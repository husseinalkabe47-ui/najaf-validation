-- ===== MIGRATION 0011 — سجل التدقيق والإعدادات وسعر الصرف ======================
-- audit_logs: للإضافة فقط. بلا مفاتيح أجنبية عمدًا (يبقى السجل بعد حذف الكيان) + لقطة لدور الفاعل.
CREATE TABLE audit_logs (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  actor_id    bigint,
  actor_role  text,
  action      varchar(80) NOT NULL,                 -- مثل dealer.approve ، member_car.reject ، auth.login_failed
  entity_type varchar(40) NOT NULL,
  entity_id   text,
  before_data jsonb,
  after_data  jsonb,
  reason      varchar(500),
  ip_hash     bytea,
  request_id  varchar(64),
  CONSTRAINT audit_actor_role_vocab CHECK (actor_role IS NULL OR actor_role IN ('user', 'dealer', 'admin', 'system')),
  CONSTRAINT audit_before_object    CHECK (before_data IS NULL OR jsonb_typeof(before_data) = 'object'),
  CONSTRAINT audit_after_object     CHECK (after_data  IS NULL OR jsonb_typeof(after_data)  = 'object')
);
CREATE INDEX audit_entity_idx ON audit_logs (entity_type, entity_id, occurred_at DESC);
CREATE INDEX audit_actor_idx  ON audit_logs (actor_id, occurred_at DESC) WHERE actor_id IS NOT NULL;
CREATE INDEX audit_action_idx ON audit_logs (action, occurred_at DESC);
CREATE INDEX audit_time_brin  ON audit_logs USING brin (occurred_at);

CREATE FUNCTION audit_logs_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_logs is append-only' USING ERRCODE = '42501';
END $$;
CREATE TRIGGER audit_logs_no_change BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION audit_logs_immutable();
CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs FOR EACH STATEMENT EXECUTE FUNCTION audit_logs_immutable();

CREATE TABLE exchange_rates (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  usd_to_iqd  numeric(10,2) NOT NULL,                -- كم دينارًا لكل 1 دولار
  kind        text          NOT NULL,
  note        varchar(300),
  set_by      bigint REFERENCES users (id) ON DELETE SET NULL,
  valid_from  timestamptz   NOT NULL DEFAULT now(),
  CONSTRAINT fx_rate_pos    CHECK (usd_to_iqd > 0),
  CONSTRAINT fx_kind_vocab  CHECK (kind IN ('manual', 'live'))
);
CREATE INDEX fx_valid_from_idx ON exchange_rates (valid_from DESC, id DESC);

CREATE TABLE app_settings (
  key         varchar(80) PRIMARY KEY,
  value       jsonb       NOT NULL,
  description varchar(300),
  updated_by  bigint REFERENCES users (id) ON DELETE SET NULL,
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER settings_touch_bu BEFORE UPDATE ON app_settings FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- سعر الصرف الساري، أو NULL إن لم يُضبط (فلا تحويل ولا مقارنة بين عملتين — كسلوك النموذج الأولي)
CREATE FUNCTION current_usd_to_iqd() RETURNS numeric LANGUAGE sql STABLE AS $$
  SELECT usd_to_iqd FROM exchange_rates WHERE valid_from <= now() ORDER BY valid_from DESC, id DESC LIMIT 1
$$;
-- التحويل للمقارنة فقط؛ لا يُخزَّن أبدًا
CREATE FUNCTION to_iqd(p_price numeric, p_currency text) RETURNS numeric LANGUAGE sql STABLE AS $$
  SELECT CASE WHEN p_currency = 'IQD' THEN p_price
              WHEN p_currency = 'USD' THEN p_price * current_usd_to_iqd() END
$$;
-- استحقاقات المعرض: الاشتراك الحيّ الساري، وإلا الخطة المجانية
CREATE FUNCTION entitlements_for_showroom(p_showroom bigint) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT COALESCE(
    (SELECT p.entitlements FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id
      WHERE s.showroom_id = p_showroom AND s.status IN ('trialing', 'active', 'past_due') AND s.current_period_end > now()
      ORDER BY s.current_period_end DESC LIMIT 1),
    (SELECT entitlements FROM subscription_plans WHERE code = 'free'),
    '{}'::jsonb)
$$;

-- بيانات أساسية (لا حسابات ولا كلمات مرور هنا): الخطة المجانية وحدود التطبيق.
INSERT INTO subscription_plans (code, name, billing_interval, price, currency, entitlements)
VALUES ('free', 'الخطة المجانية', NULL, 0, 'IQD', '{}'::jsonb);

INSERT INTO app_settings (key, value, description) VALUES
  ('limits.text',      '{"brand":50,"model":80,"color":40,"transmission":40,"fuelType":40,"description":2000,"location":200,"name":100,"email":254,"password":128}', 'حدود أطوال النصوص (TEXT_LIMITS الحالية)'),
  ('images.max_per_car','{"member":4,"showroom":5}', 'سقف الصور لكل سيارة'),
  ('images.upload',    '{"max_input_bytes":8388608,"max_side_px":1600,"thumb_px":480}', 'حدود رفع ومعالجة الصور'),
  ('otp.policy',       '{"code_length":6,"ttl_seconds":600,"max_attempts":5,"cooldown_seconds":60,"per_hour":3,"per_day":10}', 'مقترح (يحتاج موافقة): سياسة رموز التحقق');

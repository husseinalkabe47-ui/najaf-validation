-- ===== MIGRATION 0009 — مكافآت النشر (AdMob SSV) ===============================
-- مكافأة واحدة = سيارة واحدة. id هو publishRequestId الحالي.
CREATE TABLE reward_grants (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            bigint      NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  provider           varchar(40) NOT NULL DEFAULT 'admob',
  status             text        NOT NULL DEFAULT 'requested',
  ssv_transaction_id text,
  car_id             bigint UNIQUE REFERENCES cars (id) ON DELETE SET NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  verified_at        timestamptz,
  consumed_at        timestamptz,
  expires_at         timestamptz NOT NULL,
  CONSTRAINT reward_status_vocab    CHECK (status IN ('requested', 'verified', 'consumed', 'expired', 'failed')),
  CONSTRAINT reward_verified_shape  CHECK (status NOT IN ('verified', 'consumed') OR (verified_at IS NOT NULL AND ssv_transaction_id IS NOT NULL)),
  CONSTRAINT reward_consumed_shape  CHECK (status <> 'consumed' OR consumed_at IS NOT NULL),
  CONSTRAINT reward_expiry_after    CHECK (expires_at > created_at)
);
CREATE UNIQUE INDEX reward_ssv_uq ON reward_grants (provider, ssv_transaction_id) WHERE ssv_transaction_id IS NOT NULL;
CREATE INDEX reward_user_idx ON reward_grants (user_id, created_at DESC);

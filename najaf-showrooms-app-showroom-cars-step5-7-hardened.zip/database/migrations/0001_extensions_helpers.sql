-- ===== MIGRATION 0001 — الامتدادات والنطاقات والدوال المساعدة =================
CREATE EXTENSION IF NOT EXISTS citext;     -- بريد غير حساس للحالة
CREATE EXTENSION IF NOT EXISTS pg_trgm;    -- فهارس بحث نصي تقريبي

-- هاتف عراقي محمول بصيغة E.164: +964 7XXXXXXXXX (الواجهة تعرضه 07XXXXXXXXX)
CREATE DOMAIN e164_iq  AS varchar(16) CONSTRAINT e164_iq_format  CHECK (VALUE ~ '^\+9647[0-9]{9}$');
-- هاتف عام (معرض قد يضع رقمًا أرضيًا)
CREATE DOMAIN e164_any AS varchar(16) CONSTRAINT e164_any_format CHECK (VALUE ~ '^\+[1-9][0-9]{7,14}$');

CREATE FUNCTION touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- تحكم تفاؤلي بالتزامن: كل UPDATE يزيد version (يُمرَّر If-Match إلى WHERE في التطبيق)
CREATE FUNCTION touch_versioned() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  NEW.version := OLD.version + 1;
  RETURN NEW;
END $$;

-- كل عنصر في المصفوفة لا يتجاوز الطول المحدد (يُستعمل في CHECK)
CREATE FUNCTION text_array_max_len(arr text[], max_len integer) RETURNS boolean
LANGUAGE sql IMMUTABLE AS $$
  SELECT NOT EXISTS (SELECT 1 FROM unnest(arr) AS e WHERE char_length(e) > max_len)
$$;

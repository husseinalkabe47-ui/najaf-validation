#!/usr/bin/env python3
"""يتحقق أن طبقة قاعدة البيانات في المشروع مطابقة حرفيًا لما اجتاز التحقق على PostgreSQL 16 (المرحلة 11.3).

  python3 database/tools/verify_integrity.py                 # تحقق (رمز الخروج 1 عند أي اختلاف)
  python3 database/tools/verify_integrity.py --write-checksums   # بعد تعديل مقصود + إعادة تشغيل التحقق على PostgreSQL

الفحوص: (1) ترقيم الترحيلات 0001..N متصل بلا تكرار، (2) الترحيلات 0001–0012 = أقسام المخطط المعتمد (database/validation/najaf_schema_v1.working-18-14.sql)
بالمقسِّم نفسه، (3) 0013 = ما في حزمة التحقق، (4) البيانات التجريبية = ما في حزمة التحقق، (5) بصمات كل ملفات database/ = CHECKSUMS.sha256.
أي تعديل على ملف معتمد يستلزم إعادة تشغيل التحقق على PostgreSQL ثم --write-checksums (انظر database/README.md)."""
import hashlib, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = lambda *p: os.path.join(ROOT, *p)
OFFICIAL_SCHEMA = J('validation', 'najaf_schema_v1.working-18-14.sql')
fails = []; oks = []

def ok(m): oks.append(m); print('  ✓', m)
def bad(m): fails.append(m); print('  ✗', m)
def read(p): return open(p, encoding='utf-8').read()
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()

# (1) ترقيم الترحيلات
files = sorted(f for f in os.listdir(J('migrations')) if f.endswith('.sql'))
nums = [f[:4] for f in files]
expected = ['%04d' % i for i in range(1, len(files) + 1)]
if nums == expected and len(files) >= 13: ok(f'الترحيلات {nums[0]}–{nums[-1]} ({len(files)} ملفًا) متصلة بلا تكرار')
else: bad(f'ترقيم الترحيلات غير متصل: {nums}')
by = {f[:4]: f for f in files}

# (2) 0001–0012 = أقسام المخطط المعتمد (نفس خوارزمية tools/split_migrations.py)
src = read(OFFICIAL_SCHEMA)
marks = list(re.finditer(r'^-- ===== MIGRATION (\d{4}) [^\n]*$', src, re.M))
if len(marks) != 12: bad(f'المخطط المعتمد يحوي {len(marks)} علامة ترحيل بدل 12')
for i, m in enumerate(marks):
    end = marks[i + 1].start() if i + 1 < len(marks) else len(src)
    section = src[m.start():end].rstrip() + '\n'
    f = by.get(m.group(1))
    if f is None: bad(f'ترحيل {m.group(1)} غير موجود في migrations/'); continue
    if read(J('migrations', f)) == section: ok(f'{f} مطابق لقسم المخطط المعتمد')
    else: bad(f'{f} يخالف قسم {m.group(1)} من المخطط المعتمد')

# (3) 0013، (4) البيانات التجريبية
pairs = [(J('migrations', by.get('0013', '0013_missing.sql')), J('validation', 'sql', '0013_column_privileges.sql'), '0013 = ترحيل التشديد المُختبَر'),
         (J('seed', 'najaf_demo_seed.sql'), J('validation', 'najaf_demo_seed.sql'), 'البيانات التجريبية = المُختبَرة')]
for a, b, label in pairs:
    if os.path.exists(a) and os.path.exists(b) and sha(a) == sha(b): ok(label)
    else: bad(label + ' — اختلاف أو ملف مفقود')

# (5) البصمات
def tracked():
    out = []
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d != '__pycache__']
        for f in fn:
            rel = os.path.relpath(os.path.join(dp, f), ROOT).replace(os.sep, '/')
            if rel == 'CHECKSUMS.sha256' or rel.startswith('validation/results/'): continue
            out.append(rel)
    return sorted(out)

cs_path = J('CHECKSUMS.sha256')
if '--write-checksums' in sys.argv:
    open(cs_path, 'w', encoding='utf-8').write(''.join(f'{sha(J(*r.split("/")))}  {r}\n' for r in tracked()))
    print(f'  كُتب CHECKSUMS.sha256 ({len(tracked())} ملفًا)'); sys.exit(0)
if not os.path.exists(cs_path): bad('CHECKSUMS.sha256 غير موجود')
else:
    rec = dict((l.split('  ', 1)[1].strip(), l.split('  ', 1)[0]) for l in read(cs_path).splitlines() if l.strip())
    cur = tracked()
    missing = sorted(set(rec) - set(cur)); extra = sorted(set(cur) - set(rec))
    changed = [r for r in cur if r in rec and sha(J(*r.split('/'))) != rec[r]]
    if not (missing or extra or changed): ok(f'بصمات {len(cur)} ملفًا مطابقة لـ CHECKSUMS.sha256')
    else:
        if missing: bad(f'ملفات مسجَّلة ومفقودة: {missing[:5]}')
        if extra: bad(f'ملفات جديدة غير مسجَّلة: {extra[:5]}')
        if changed: bad(f'ملفات تغيّرت: {changed[:5]}')
print()
print(f'النتيجة: {len(oks)} فحصًا ناجحًا، {len(fails)} فاشلًا')
sys.exit(1 if fails else 0)

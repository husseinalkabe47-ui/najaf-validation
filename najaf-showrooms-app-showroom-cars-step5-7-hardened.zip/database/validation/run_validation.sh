#!/usr/bin/env bash
# المرحلة 11.3 — حزمة التحقق على PostgreSQL 16 الحقيقي. استعمال: ./run_validation.sh   (متغيرات PGHOST/PGPORT/PGUSER/PGPASSWORD من البيئة)
# تحذير: تُنشئ قاعدتين مؤقتتين (najaf_val_*, najaf_perf_*) وأدوارًا (najaf_app, najaf_report, vt_*) على العنقود. استعمل خادمًا مؤقتًا.
set -uo pipefail
export PGCLIENTENCODING=UTF8
HERE="$(cd "$(dirname "$0")" && pwd)"
SCHEMA_FILE="${SCHEMA_FILE:-$HERE/najaf_schema_v1.working-18-14.sql}"
SEED_FILE="${SEED_FILE:-$HERE/najaf_demo_seed.sql}"
NCARS="${NCARS:-100000}"; NDEALERS="${NDEALERS:-2000}"; NMEMBERS="${NMEMBERS:-40000}"; NFAV="${NFAV:-100000}"; NSESS="${NSESS:-50000}"
PERF_MAX_OLTP_MS="${PERF_MAX_OLTP_MS:-100}"; PERF_MAX_AGG_MS="${PERF_MAX_AGG_MS:-1000}"
STAMP="$(date +%Y%m%d_%H%M%S)"; DB="najaf_val_$STAMP"; PDB="najaf_perf_$STAMP"
OUT="$HERE/results/$STAMP"; mkdir -p "$OUT/logs" "$OUT/migrations"; STEPS="$OUT/steps.tsv"; : > "$STEPS"
FAILS=0
say()  { printf '%s\n' "$*" | tee -a "$OUT/console.log"; }
step() { printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$STEPS"; if [ "$2" != "0" ]; then FAILS=$((FAILS+1)); say "  ✗ $1 (rc=$2) $3"; else say "  ✓ $1 $3"; fi; }
ADMIN=(psql -X -q -At -v ON_ERROR_STOP=1 -d postgres)
q()  { psql -X -q -At -d "$DB" -c "$1"; }

say "== المرحلة 11.3: التحقق على PostgreSQL =="; say "مخطط: $SCHEMA_FILE ($(md5sum "$SCHEMA_FILE" | cut -c1-12))"
command -v psql >/dev/null || { say "psql غير موجود"; exit 2; }; command -v python3 >/dev/null || { say "python3 غير موجود"; exit 2; }
VNUM="$("${ADMIN[@]}" -c "SHOW server_version_num" 2>"$OUT/logs/preflight.err")" || { say "تعذّر الاتصال بالخادم (انظر $OUT/logs/preflight.err)"; exit 2; }
VER="$("${ADMIN[@]}" -c "SHOW server_version")"; MAJOR=$((VNUM/10000))
[ "$MAJOR" = "16" ] && step "preflight: PostgreSQL 16" 0 "($VER)" || { step "preflight: الإصدار ليس 16" 1 "($VER)"; [ "${STRICT_16:-0}" = "1" ] && exit 2; }
[ "$("${ADMIN[@]}" -c "SELECT rolsuper FROM pg_roles WHERE rolname = current_user")" = "t" ] && step "preflight: دور مشرف" 0 "" || { step "preflight: يلزم دور مشرف (superuser)" 1 ""; exit 2; }
[ "$("${ADMIN[@]}" -c "SELECT count(*) FROM pg_available_extensions WHERE name IN ('citext','pg_trgm')")" = "2" ] && step "preflight: citext وpg_trgm متاحتان" 0 "" || { step "preflight: ناقص امتداد citext/pg_trgm (ثبّت postgresql-contrib)" 1 ""; exit 2; }

# ---------- 1) الترحيلات 0001–0012 على قاعدة نظيفة ----------
"${ADMIN[@]}" -c "CREATE DATABASE \"$DB\"" || { say "تعذّر إنشاء القاعدة"; exit 2; }
[ "$("${ADMIN[@]}" -c "SELECT pg_encoding_to_char(encoding) FROM pg_database WHERE datname = '$DB'")" = "UTF8" ] && step "preflight: ترميز القاعدة UTF8" 0 "" || { step "ترميز القاعدة ليس UTF8 (الاختبارات عربية)" 1 ""; exit 2; }
python3 "$HERE/tools/split_migrations.py" "$SCHEMA_FILE" "$OUT/migrations" | tee -a "$OUT/console.log"
ABORT=0
for f in "$OUT"/migrations/00*.sql; do
  n="$(basename "$f" .sql)"; t0=$(date +%s.%N)
  psql -X -q -v ON_ERROR_STOP=1 -1 -d "$DB" -f "$f" >"$OUT/logs/migration_$n.out" 2>"$OUT/logs/migration_$n.err"; rc=$?
  dt=$(printf '%.2fs' "$(echo "$(date +%s.%N) - $t0" | bc -l 2>/dev/null || echo 0)")
  if [ $rc -ne 0 ]; then step "ترحيل $n" $rc "$(head -c 300 "$OUT/logs/migration_$n.err" | tr '\n' ' ')"; ABORT=1; break; else step "ترحيل $n" 0 "($dt)"; fi
done
if [ $ABORT -eq 1 ]; then say "توقّف: فشل ترحيل. لا تُجرى بقية الاختبارات."; echo "STOPPED_AT_MIGRATION" > "$OUT/status.txt"; exit 1; fi

# ---------- 2) الإطار والتثبيتات ----------
python3 "$HERE/tools/gen_expected.py" "$SCHEMA_FILE" "$OUT/05_expected_objects.sql" >/dev/null
for f in "$HERE/sql/00_harness.sql" "$OUT/05_expected_objects.sql" "$HERE/sql/06_expected_public_ids.sql" "$HERE/sql/10_fixtures.sql"; do
  b="$(basename "$f" .sql)"; psql -X -q -v ON_ERROR_STOP=1 -d "$DB" -f "$f" >"$OUT/logs/$b.out" 2>"$OUT/logs/$b.err"; rc=$?
  step "تحميل $b" $rc "$([ $rc -ne 0 ] && head -c 300 "$OUT/logs/$b.err" | tr '\n' ' ')"
  [ $rc -ne 0 ] && { say "توقّف: فشل تحميل إطار الاختبار"; exit 1; }
done

run_tests() {
  local f="$1" b suite min errs n
  b="$(basename "$f" .sql)"; suite="$(grep -m1 '^-- SUITE:' "$f" | sed 's/^-- SUITE: *//')"; min="$(grep -m1 '^-- EXPECT_MIN:' "$f" | sed 's/^-- EXPECT_MIN: *//')"
  psql -X -q -v ON_ERROR_STOP=0 -d "$DB" -f "$f" >"$OUT/logs/$b.out" 2>"$OUT/logs/$b.err"
  errs="$(grep -c 'ERROR:' "$OUT/logs/$b.err" || true)"; n="$(q "SELECT count(*) FROM vt.results WHERE suite = '$suite'")"
  if [ "$errs" != "0" ]; then step "ملف $b: أخطاء في شيفرة الاختبار أو في الاستدعاء" 1 "($errs سطر ERROR في logs/$b.err؛ أول خطأ: $(grep -m1 'ERROR:' "$OUT/logs/$b.err" | head -c 200))"; else step "ملف $b: نُفِّذ بلا أخطاء عليا" 0 "(اختبارات مسجَّلة في $suite: $n)"; fi
  if [ "${n:-0}" -lt "${min:-0}" ]; then step "ملف $b: اختبارات أقل من المتوقع (تخطٍّ صامت محتمل)" 1 "($n < $min)"; fi
}

run_tests "$HERE/sql/20_structure.sql"
# ---------- 3) البذرة ----------
psql -X -q -v ON_ERROR_STOP=1 -d "$DB" -f "$SEED_FILE" >"$OUT/logs/seed.out" 2>"$OUT/logs/seed.err"; rc=$?
step "najaf_demo_seed.sql" $rc "$([ $rc -ne 0 ] && head -c 400 "$OUT/logs/seed.err" | tr '\n' ' ')"
if [ $rc -eq 0 ]; then
  run_tests "$HERE/sql/30_seed_checks.sql"
  run_tests "$HERE/sql/35_gap_baseline.sql"
  run_tests "$HERE/sql/40_constraints.sql"
  run_tests "$HERE/sql/45_intentional14.sql"
  run_tests "$HERE/sql/50_business.sql"
  run_tests "$HERE/sql/60_permissions.sql"
  # ---------- 4) التشديد 0013 ----------
  psql -X -q -v ON_ERROR_STOP=1 -1 -d "$DB" -f "$HERE/sql/0013_column_privileges.sql" >"$OUT/logs/0013.out" 2>"$OUT/logs/0013.err"; rc=$?
  step "ترحيل 0013 (تشديد صلاحيات الأعمدة)" $rc "$([ $rc -ne 0 ] && head -c 300 "$OUT/logs/0013.err" | tr '\n' ' ')"
  if [ $rc -eq 0 ]; then
    run_tests "$HERE/sql/70_hardening.sql"
    ACLQ="SELECT md5(COALESCE((SELECT string_agg(c.relname || ':' || COALESCE(c.relacl::text, ''), '|' ORDER BY c.relname) FROM pg_class c WHERE c.relnamespace = 'public'::regnamespace AND c.relkind IN ('r','v')), '') || COALESCE((SELECT string_agg(a.attrelid::regclass::text || '.' || a.attname || ':' || a.attacl::text, '|' ORDER BY a.attrelid::regclass::text, a.attname) FROM pg_attribute a WHERE a.attacl IS NOT NULL AND a.attrelid IN (SELECT oid FROM pg_class WHERE relnamespace = 'public'::regnamespace)), ''))"
    A1="$(q "$ACLQ")"; psql -X -q -v ON_ERROR_STOP=1 -1 -d "$DB" -f "$HERE/sql/0013_column_privileges.sql" >/dev/null 2>"$OUT/logs/0013_again.err"; rc2=$?; A2="$(q "$ACLQ")"
    [ $rc2 -eq 0 ] && [ "$A1" = "$A2" ] && R=true || R=false
    psql -X -q -d "$DB" -v ok="$R" -v d="تطبيق 0013 مرتين: rc=$rc2 ACL قبل=$A1 بعد=$A2" -f - >/dev/null <<'SQL'
SELECT vt.suite('hardening'); SELECT vt.record('0013 idempotent: التطبيق الثاني لا يغيّر أي صلاحية', :'ok'::boolean, :'d');
SQL
  fi
  # ---------- 5) التزامن ----------
  say "-- التزامن (عملاء psql حقيقيون) --"; bash "$HERE/concurrency/run_concurrency.sh" "$DB" "$OUT/concurrency" >"$OUT/logs/concurrency.out" 2>"$OUT/logs/concurrency.err"; rc=$?
  step "تزامن: التشغيل" $rc "$([ $rc -ne 0 ] && head -c 300 "$OUT/logs/concurrency.err" | tr '\n' ' ')"
  CN="$(q "SELECT count(*) FROM vt.results WHERE suite = 'concurrency'")"; [ "${CN:-0}" -ge 6 ] && step "تزامن: 6 اختبارات مسجَّلة" 0 "($CN)" || step "تزامن: اختبارات أقل من 6" 1 "($CN)"
fi

# ---------- 6) الأداء ----------
say "-- الأداء: $NCARS سيارة اصطناعية --"
"${ADMIN[@]}" -c "CREATE DATABASE \"$PDB\"" && {
  PRC=0
  for f in "$OUT"/migrations/00*.sql "$HERE/sql/0013_column_privileges.sql"; do psql -X -q -v ON_ERROR_STOP=1 -1 -d "$PDB" -f "$f" >/dev/null 2>>"$OUT/logs/perf_migrations.err" || PRC=1; done
  step "أداء: ترحيل قاعدة الأداء" $PRC ""
  if [ $PRC -eq 0 ]; then
    t0=$(date +%s); psql -X -q -v ON_ERROR_STOP=1 -d "$PDB" -v ncars=$NCARS -v ndealers=$NDEALERS -v nmembers=$NMEMBERS -v nfav=$NFAV -v nsess=$NSESS -f "$HERE/perf/10_generate.sql" >"$OUT/logs/perf_generate.out" 2>"$OUT/logs/perf_generate.err"; rc=$?
    step "أداء: توليد البيانات" $rc "($(( $(date +%s) - t0 ))s) $([ $rc -ne 0 ] && head -c 300 "$OUT/logs/perf_generate.err" | tr '\n' ' ')"
    if [ $rc -eq 0 ]; then
      psql -X -q -v ON_ERROR_STOP=1 -d "$PDB" -f "$HERE/perf/20_queries.sql" >"$OUT/logs/perf_queries.out" 2>"$OUT/logs/perf_queries.err"; rc=$?
      step "أداء: تشغيل الاستعلامات" $rc "$([ $rc -ne 0 ] && head -c 300 "$OUT/logs/perf_queries.err" | tr '\n' ' ')"
      psql -X -q -d "$PDB" -f "$HERE/perf/30_report.sql" >"$OUT/perf_report.txt" 2>&1
      BADCHK="$(psql -X -At -d "$PDB" -c "SELECT count(*) FROM perf.checks WHERE bad <> 0")"; [ "$BADCHK" = "0" ] && step "أداء: سلامة البيانات المولَّدة" 0 "" || step "أداء: بيانات مولَّدة غير سليمة" 1 "($BADCHK فحص فاشل)"
      SLOW="$(psql -X -At -F' | ' -d "$PDB" -c "SELECT name || ' = ' || median_ms || ' ms' FROM perf.results WHERE (kind = 'oltp' AND median_ms > $PERF_MAX_OLTP_MS) OR (kind = 'agg' AND median_ms > $PERF_MAX_AGG_MS) ORDER BY id")"
      SEQ="$(psql -X -At -F' | ' -d "$PDB" -c "SELECT name || ' (' || seq_scans || ')' FROM perf.results WHERE seq_scans ~ '(^|,)(cars|car_images|assets|favorites|sessions|users|audit_logs|message_deliveries)(,|\$)' AND (name ~ '^Q0[1267] ' OR name ~ '^Q08 ' OR name ~ '^Q1[56] ') ORDER BY id")"
      echo "SLOW(>$PERF_MAX_OLTP_MS/$PERF_MAX_AGG_MS ms):" > "$OUT/perf_verdict.txt"; echo "${SLOW:-none}" >> "$OUT/perf_verdict.txt"; echo "SEQSCAN_ON_KEY_QUERIES:" >> "$OUT/perf_verdict.txt"; echo "${SEQ:-none}" >> "$OUT/perf_verdict.txt"
      if [ -n "$SLOW" ] || [ -n "$SEQ" ]; then if [ "${PERF_SOFT:-0}" = "1" ]; then step "أداء: تجاوز العتبات المقترحة (مرنة PERF_SOFT=1)" 0 "$(echo "$SLOW $SEQ" | head -c 200)"; else step "أداء: تجاوز العتبات المقترحة أو مسح تسلسلي لاستعلام مفتاحي" 1 "(انظر perf_verdict.txt)"; fi; else step "أداء: كل الاستعلامات ضمن العتبات ولا مسح تسلسلي مفتاحي" 0 ""; fi
      if command -v pgbench >/dev/null; then pgbench -n -c 8 -j 4 -T "${PGBENCH_SECONDS:-20}" -D ncars="$NCARS" -f "$HERE/perf/pgbench_read.sql" -r "$PDB" >"$OUT/pgbench.txt" 2>&1; say "  pgbench: $(grep -E 'tps =|latency average' "$OUT/pgbench.txt" | tr '\n' ' ')"; else say "  pgbench غير متاح (تخطٍّ معلوماتي)"; fi
    fi
  fi
}

# ---------- 7) الملخص ----------
{
  echo "# ملخص التحقق — $STAMP"; echo
  echo "- الخادم: $VER | المخطط: \`$(basename "$SCHEMA_FILE")\` ($(md5sum "$SCHEMA_FILE" | cut -c1-12)) | البيانات: \`$(basename "$SEED_FILE")\`"
  echo; echo "## الخطوات"; echo; echo "| الخطوة | rc | تفصيل |"; echo "| --- | --- | --- |"
  while IFS=$'\t' read -r a b c; do echo "| $a | $b | ${c//|//} |"; done < "$STEPS"
  echo; echo "## الاختبارات حسب المجموعة"; echo
  psql -X -At -F'|' -d "$DB" -c "SELECT '| ' || suite || ' | ' || count(*) || ' | ' || count(*) FILTER (WHERE ok AND COALESCE(detail,'') NOT LIKE 'SKIPPED%') || ' | ' || count(*) FILTER (WHERE NOT ok) || ' | ' || count(*) FILTER (WHERE detail LIKE 'SKIPPED%') || ' |' FROM vt.results GROUP BY suite ORDER BY min(id)" 2>/dev/null | sed '1i | المجموعة | الكل | نجح | فشل | تخطٍّ |\n| --- | --- | --- | --- | --- |'
  TOTAL="$(q "SELECT count(*) FROM vt.results" 2>/dev/null)"; PASS="$(q "SELECT count(*) FROM vt.results WHERE ok" 2>/dev/null)"; FAILT="$(q "SELECT count(*) FROM vt.results WHERE NOT ok" 2>/dev/null)"
  echo; echo "**المجموع: ${TOTAL:-0} اختبارًا — نجح ${PASS:-0} — فشل ${FAILT:-?}**"
  echo; echo "## الاختبارات الفاشلة"; echo
  psql -X -At -d "$DB" -c "SELECT '- [' || suite || '] ' || name || E'\n    ' || left(COALESCE(detail,''), 400) FROM vt.results WHERE NOT ok ORDER BY id" 2>/dev/null || true
  echo; echo "## تغطية القيود (قيود CHECK/UNIQUE/FK التي لم يرفض اختبارٌ بها فعلًا)"; echo
  psql -X -At -d "$DB" -c "SELECT '- ' || conname || ' (' || contype || ')' FROM pg_constraint WHERE connamespace = 'public'::regnamespace AND contype IN ('c','u','f') AND conrelid <> 0 AND conname NOT IN (SELECT hit FROM vt.results WHERE hit IS NOT NULL) ORDER BY conname" 2>/dev/null || true
  echo; echo "## المتخطَّى"; psql -X -At -d "$DB" -c "SELECT '- ' || name || ' — ' || detail FROM vt.results WHERE detail LIKE 'SKIPPED%'" 2>/dev/null || true
  echo; echo "## الأداء"; echo '```'; cat "$OUT/perf_report.txt" 2>/dev/null; cat "$OUT/perf_verdict.txt" 2>/dev/null; echo '```'
} > "$OUT/summary.md" 2>/dev/null
psql -X -q -d "$DB" -c "\\copy (SELECT id, suite, name, ok, regexp_replace(COALESCE(detail,''), E'[\\n\\r]+', ' ', 'g') AS detail, hit FROM vt.results ORDER BY id) TO '$OUT/results.csv' CSV HEADER" 2>/dev/null
FAILT="$(q "SELECT count(*) FROM vt.results WHERE NOT ok" 2>/dev/null || echo 999)"
say ""; say "الملخص الكامل: $OUT/summary.md"; say "النتائج الخام: $OUT/results.csv"; say "الاختبارات الفاشلة: $FAILT | خطوات فاشلة: $FAILS"
if [ "${KEEP_DB:-0}" != "1" ]; then "${ADMIN[@]}" -c "DROP DATABASE IF EXISTS \"$DB\" WITH (FORCE)" >/dev/null 2>&1; "${ADMIN[@]}" -c "DROP DATABASE IF EXISTS \"$PDB\" WITH (FORCE)" >/dev/null 2>&1; fi
[ "${CLEAN_ROLES:-0}" = "1" ] && for r in vt_app_login vt_ops vt_nobody najaf_app najaf_report; do "${ADMIN[@]}" -c "DROP ROLE IF EXISTS $r" >/dev/null 2>&1; done
[ "${FAILT:-1}" = "0" ] && [ "$FAILS" = "0" ] && { say "النتيجة: نجاح كامل"; exit 0; } || { say "النتيجة: توجد إخفاقات — أرسل مجلد $OUT (summary.md وlogs)"; exit 1; }

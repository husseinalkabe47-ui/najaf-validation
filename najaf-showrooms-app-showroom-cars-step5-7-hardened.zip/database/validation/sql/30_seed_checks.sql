-- SUITE: seed
-- EXPECT_MIN: 30
SELECT vt.suite('seed');

-- أعداد البذرة
SELECT vt.eq('users = 8', (SELECT count(*)::text FROM users), '8');
SELECT vt.eq('showrooms = 5', (SELECT count(*)::text FROM showrooms), '5');
SELECT vt.eq('cars = 151 (91 معرض + 60 عضو)', (SELECT count(*)::text FROM cars), '151');
SELECT vt.eq('سيارات المعارض = 91', (SELECT count(*)::text FROM cars WHERE source_type = 'showroom'), '91');
SELECT vt.eq('إعلانات الأعضاء = 60', (SELECT count(*)::text FROM cars WHERE source_type = 'member'), '60');
SELECT vt.eq('assets = 302', (SELECT count(*)::text FROM assets), '302');
SELECT vt.eq('car_images = 302', (SELECT count(*)::text FROM car_images), '302');
SELECT vt.eq('favorites = 0', (SELECT count(*)::text FROM favorites), '0');
SELECT vt.eq('exchange_rates = 1 (تجريبي)', (SELECT count(*)::text FROM exchange_rates), '1');
SELECT vt.eq('مدير فعّال واحد (id=6)', (SELECT string_agg(id::text, ',') FROM users WHERE role = 'admin' AND status = 'active'), '6');

-- توزيع الحالات (من التشغيل الجاف)
SELECT vt.eq('إعلانات الأعضاء حسب الحالة',
  (SELECT string_agg(status || ':' || n, ',' ORDER BY status) FROM (SELECT status, count(*) n FROM cars WHERE source_type = 'member' GROUP BY status) s),
  'active:51,pending:2,rejected:1,sold:5,suspended:1');
SELECT vt.eq('سيارات المعارض حسب الحالة',
  (SELECT string_agg(status || ':' || n, ',' ORDER BY status) FROM (SELECT status, count(*) n FROM cars WHERE source_type = 'showroom' GROUP BY status) s),
  'available:83,sold:8');
SELECT vt.eq('المعارض حسب الحالة',
  (SELECT string_agg(status || ':' || n, ',' ORDER BY status) FROM (SELECT status, count(*) n FROM showrooms GROUP BY status) s), 'active:3,pending:1,suspended:1');

-- تحويل الأوقات: updatedAt بلا منطقة (توقيت العراق) صار UTC
SELECT vt.eq('updated_at للمعرض 1 = 2026-08-01T06:00:00Z (09:00 بتوقيت العراق)',
  (SELECT to_char(updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') FROM showrooms WHERE id = 1), '2026-08-01T06:00:00Z');
SELECT vt.eq('created_at للمستخدم 1 كما في النموذج (UTC)',
  (SELECT to_char(created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') FROM users WHERE id = 1), '2024-01-10T06:00:00Z');

-- سلامة صور البذرة
SELECT vt.eq('كل سيارة لها صور فلها صورة رئيسية واحدة بالضبط',
  (SELECT count(*)::text FROM (SELECT car_id FROM car_images GROUP BY car_id HAVING count(*) FILTER (WHERE is_main) <> 1) s), '0');
SELECT vt.eq('لا سيارة بلا صور في البذرة',
  (SELECT count(*)::text FROM cars c WHERE NOT EXISTS (SELECT 1 FROM car_images i WHERE i.car_id = c.id)), '0');
SELECT vt.eq('كل الأصول جاهزة من نوع car_image', (SELECT count(*)::text FROM assets WHERE status = 'ready' AND kind = 'car_image'), '302');

-- الظهور العام مقابل النموذج الأولي (3 معارض و115 سيارة)
SELECT vt.eq('public_showrooms = 3', (SELECT count(*)::text FROM public_showrooms), '3');
SELECT vt.eq('public_cars = 115', (SELECT count(*)::text FROM public_cars), '115');
SELECT vt.eq('public_cars: 64 سيارة معرض + 51 إعلان عضو',
  (SELECT string_agg(source_type || ':' || n, ',' ORDER BY source_type) FROM (SELECT source_type, count(*) n FROM public_cars GROUP BY source_type) s), 'member:51,showroom:64');
SELECT vt.eq('public_showrooms تطابق مرجع النموذج الأولي (ناقص/زائد)',
  (SELECT COALESCE(string_agg(x, ','), '') FROM (
     (SELECT 'missing:' || id AS x FROM vt.expected_public_showrooms EXCEPT SELECT 'missing:' || id FROM public_showrooms)
     UNION ALL (SELECT 'extra:' || id FROM public_showrooms EXCEPT SELECT 'extra:' || id FROM vt.expected_public_showrooms)) s), '');
SELECT vt.eq('public_cars تطابق مرجع النموذج الأولي (ناقص/زائد)',
  (SELECT COALESCE(string_agg(x, ','), '') FROM (
     (SELECT 'missing:' || id AS x FROM vt.expected_public_cars EXCEPT SELECT 'missing:' || id FROM public_cars)
     UNION ALL (SELECT 'extra:' || id FROM public_cars EXCEPT SELECT 'extra:' || id FROM vt.expected_public_cars)) s), '');
SELECT vt.eq('المعرضان المخفيان (3 pending، 5 suspended) وسياراتهما غائبة عن العام',
  (SELECT count(*)::text FROM public_cars WHERE showroom_id IN (3, 5)), '0');
SELECT vt.eq('لا إعلان عضو غير active في العام',
  (SELECT count(*)::text FROM public_cars p JOIN cars c ON c.id = p.id WHERE p.source_type = 'member' AND c.status <> 'active'), '0');
SELECT vt.eq('الإعلانات المباعة للأعضاء (5) غير ظاهرة (سلوك النموذج الأولي)',
  (SELECT count(*)::text FROM public_cars p JOIN cars c ON c.id = p.id WHERE p.source_type = 'member' AND c.status = 'sold'), '0');
SELECT vt.eq('الأعمدة المحظورة غائبة عن الـviews',
  (SELECT COALESCE(string_agg(table_name || '.' || column_name, ','), '') FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name IN ('public_showrooms', 'public_cars')
       AND column_name IN ('owner_id', 'reviewed_by', 'reviewed_at', 'rejection_reason', 'suspension_reason', 'deleted_at', 'version', 'status_reason', 'password_hash')), '');
SELECT vt.eq('public_showrooms بلا status ولا owner_id',
  (SELECT count(*)::text FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'public_showrooms' AND column_name IN ('status', 'owner_id')), '0');
SELECT vt.eq('owner_name لإعلانات الأعضاء فقط (فارغ لسيارات المعارض)',
  (SELECT count(*)::text FROM public_cars WHERE (source_type = 'showroom' AND owner_name IS NOT NULL) OR (source_type = 'member' AND owner_name IS NULL)), '0');

-- التسلسلات: التالي = أكبر معرّف + 1 (لا يُعاد معرّف). تُجرَّب داخل سيناريو يُلغى (التسلسل نفسه لا يُلغى)
SELECT vt.scenario('التسلسلات بعد الاستيراد: users→9، showrooms→6، cars→161، car_images→303، favorites→1',
  $s$ SELECT vt.setfx('u', vt.mk_user('dealer'));
      SELECT vt.setfx('s', vt.mk_showroom(vt.f('u')));
      SELECT vt.setfx('c', vt.mk_scar(vt.f('s')));
      SELECT vt.setfx('i', vt.mk_image(vt.f('c')));
      SELECT vt.setfx('m', vt.mk_user('user'));
      INSERT INTO favorites (user_id, car_id) VALUES (vt.f('m'), vt.f('c')); $s$,
  $c$ SELECT vt.f('u') = 9 AND vt.f('s') = 6 AND vt.f('c') = 161 AND vt.f('i') = 303
        AND (SELECT id FROM favorites WHERE user_id = vt.f('m')) = 1 $c$);

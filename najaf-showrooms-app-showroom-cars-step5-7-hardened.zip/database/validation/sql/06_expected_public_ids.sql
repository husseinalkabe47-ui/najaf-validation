-- مولَّد من النموذج الأولي (getVisibleShowrooms / getPublicCars('all', null)) — مرجع الظهور العام
CREATE TABLE vt.expected_public_showrooms (id bigint PRIMARY KEY);
INSERT INTO vt.expected_public_showrooms VALUES (1), (2), (4);
CREATE TABLE vt.expected_public_cars (id bigint PRIMARY KEY);
INSERT INTO vt.expected_public_cars VALUES (1), (2), (3), (4), (5), (6), (10), (11), (12), (16), (17), (18), (19), (20), (21), (22), (23), (24), (25), (26), (27), (31), (32), (33), (34), (35), (36), (37), (38), (43), (44), (45), (46), (48), (49), (50), (51), (52), (53), (54), (55), (56), (57), (58), (59), (60), (61), (62), (63), (64), (65), (66), (67), (77), (78), (79), (80), (81), (82), (83), (84), (85), (86), (87), (101), (102), (104), (106), (107), (111), (112), (113), (114), (115), (116), (117), (118), (119), (121), (122), (123), (124), (125), (126), (127), (129), (130), (131), (132), (133), (134), (135), (136), (137), (138), (139), (140), (141), (142), (143), (144), (145), (146), (147), (148), (149), (150), (151), (153), (154), (155), (157), (158), (159), (160);
CREATE TABLE vt.expected_split (kind text PRIMARY KEY, n integer);
INSERT INTO vt.expected_split VALUES ('public_showrooms', 3), ('public_cars', 115), ('showroom_cars', 64), ('member_cars', 51);

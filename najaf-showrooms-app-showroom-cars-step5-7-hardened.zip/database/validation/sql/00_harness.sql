-- إطار الاختبار: schema مستقل vt (يُحذف مع القاعدة). يُشغَّل بدور مشرف (superuser).
-- القاعدة: كل اختبار يُنفَّذ داخل معاملة فرعية تُلغى دائمًا، فلا تتلوث البيانات بين الاختبارات.
-- SQLSTATE خاص: VT998 = إلغاء مقصود بعد نجاح الإعداد، VT999 = الجملة لم تُرفض وكان يجب رفضها.
DROP SCHEMA IF EXISTS vt CASCADE;
CREATE SCHEMA vt;

CREATE TABLE vt.results (
  id     bigserial PRIMARY KEY,
  suite  text    NOT NULL,
  name   text    NOT NULL,
  ok     boolean NOT NULL,
  detail text,
  hit    text,                               -- اسم القيد/المشغّل الذي رفض فعلًا (لتقرير التغطية)
  at     timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE FUNCTION vt.suite(p text) RETURNS void LANGUAGE sql AS $$ SELECT set_config('vt.suite', p, false); $$;

CREATE FUNCTION vt.record(p_name text, p_ok boolean, p_detail text DEFAULT NULL, p_hit text DEFAULT NULL) RETURNS void
LANGUAGE sql AS $$
  INSERT INTO vt.results (suite, name, ok, detail, hit)
  VALUES (COALESCE(current_setting('vt.suite', true), '?'), p_name, COALESCE(p_ok, false), p_detail, p_hit);
$$;

CREATE FUNCTION vt.ok(p_name text, p_cond boolean, p_detail text DEFAULT NULL) RETURNS void LANGUAGE sql AS $$
  SELECT vt.record(p_name, p_cond, p_detail);
$$;

-- مقارنة نصية (NULL يساوي NULL)
CREATE FUNCTION vt.eq(p_name text, p_actual text, p_expected text) RETURNS void LANGUAGE sql AS $$
  SELECT vt.record(p_name, p_actual IS NOT DISTINCT FROM p_expected, format('got=[%s] expected=[%s]', p_actual, p_expected));
$$;

-- الجملة يجب أن تُرفض. p_states: قائمة SQLSTATE مفصولة بـ| ؛ p_hint: اسم قيد أو جزء من الرسالة (بدائل مفصولة بـ|)
CREATE FUNCTION vt.viol(p_name text, p_stmt text, p_states text, p_hint text DEFAULT NULL, p_role text DEFAULT NULL) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_state text; v_msg text; v_con text; v_ok boolean;
BEGIN
  BEGIN
    IF p_role IS NOT NULL THEN EXECUTE format('SET LOCAL ROLE %I', p_role); END IF;
    EXECUTE p_stmt;
    RAISE EXCEPTION 'statement was NOT rejected' USING ERRCODE = 'VT999';
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_state = RETURNED_SQLSTATE, v_msg = MESSAGE_TEXT, v_con = CONSTRAINT_NAME;
  END;
  v_ok := v_state = ANY (string_to_array(p_states, '|'))
          AND (p_hint IS NULL OR EXISTS (SELECT 1 FROM unnest(string_to_array(p_hint, '|')) h WHERE v_con = h OR v_msg ILIKE '%' || h || '%'));
  PERFORM vt.record(p_name, v_ok,
    format('sqlstate=%s constraint=%s msg=%s | expected states=%s hint=%s', v_state, COALESCE(v_con, '-'), left(v_msg, 200), p_states, COALESCE(p_hint, '-')),
    CASE WHEN v_ok THEN COALESCE(NULLIF(v_con, ''), p_hint) END);
END $$;

-- الجملة يجب أن تنجح (بدور اختياري)، ثم تُلغى آثارها
CREATE FUNCTION vt.allow(p_name text, p_stmt text, p_role text DEFAULT NULL) RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_state text; v_msg text; v_ok boolean := false;
BEGIN
  BEGIN
    IF p_role IS NOT NULL THEN EXECUTE format('SET LOCAL ROLE %I', p_role); END IF;
    EXECUTE p_stmt;
    v_ok := true;
    RAISE EXCEPTION 'rollback' USING ERRCODE = 'VT998';
  EXCEPTION
    WHEN SQLSTATE 'VT998' THEN NULL;
    WHEN OTHERS THEN GET STACKED DIAGNOSTICS v_state = RETURNED_SQLSTATE, v_msg = MESSAGE_TEXT;
  END;
  PERFORM vt.record(p_name, v_ok, CASE WHEN v_ok THEN NULL ELSE format('rejected unexpectedly: sqlstate=%s msg=%s', v_state, left(v_msg, 200)) END);
END $$;

-- سيناريو: يُجهَّز (p_setup)، ثم يُقيَّم شرط (p_check يعيد boolean)، ثم يُلغى كل شيء
CREATE FUNCTION vt.scenario(p_name text, p_setup text, p_check text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_res boolean; v_err text;
BEGIN
  BEGIN
    EXECUTE p_setup;
    EXECUTE p_check INTO v_res;
    RAISE EXCEPTION 'rollback' USING ERRCODE = 'VT998';
  EXCEPTION
    WHEN SQLSTATE 'VT998' THEN NULL;
    WHEN OTHERS THEN GET STACKED DIAGNOSTICS v_err = MESSAGE_TEXT; v_res := false;
  END;
  PERFORM vt.record(p_name, COALESCE(v_res, false), v_err);
END $$;

-- تثبيتات اختبار (مفتاح ← معرّف) تعيش داخل المعاملة الفرعية فتُلغى معها
CREATE TABLE vt.fx (key text PRIMARY KEY, val bigint, uval uuid);
CREATE FUNCTION vt.setfx(p_key text, p_val bigint) RETURNS bigint LANGUAGE sql AS $$
  INSERT INTO vt.fx (key, val) VALUES (p_key, p_val) ON CONFLICT (key) DO UPDATE SET val = EXCLUDED.val RETURNING val;
$$;
CREATE FUNCTION vt.setfxu(p_key text, p_val uuid) RETURNS uuid LANGUAGE sql AS $$
  INSERT INTO vt.fx (key, uval) VALUES (p_key, p_val) ON CONFLICT (key) DO UPDATE SET uval = EXCLUDED.uval RETURNING uval;
$$;
CREATE FUNCTION vt.f(p_key text) RETURNS bigint LANGUAGE sql STABLE AS $$ SELECT val FROM vt.fx WHERE key = p_key; $$;
CREATE FUNCTION vt.fu(p_key text) RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT uval FROM vt.fx WHERE key = p_key; $$;

-- أعلام النسخة: هل المخطط يحوي تعديلات ما بعد المراجعة (حارس الغلاف، قفل المدير، سحب EXECUTE من PUBLIC)؟
CREATE TABLE vt.flags (key text PRIMARY KEY, val boolean NOT NULL);
INSERT INTO vt.flags VALUES
  ('cover_guard', EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'showrooms_cover_guard' AND pronamespace = 'public'::regnamespace)),
  ('admin_delete_guard', EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'users_guard_biud'));
CREATE FUNCTION vt.flag(p text) RETURNS boolean LANGUAGE sql STABLE AS $$ SELECT val FROM vt.flags WHERE key = p; $$;

-- عدد الصفوف التي تأثرت بجملة (للتحكم التفاؤلي)
CREATE FUNCTION vt.rowcount(p_sql text) RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE n bigint;
BEGIN
  EXECUTE p_sql;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;

-- دوال بناء بيانات صالحة (تُستدعى بدور المشرف قبل تبديل الدور)
CREATE FUNCTION vt.phone() RETURNS text LANGUAGE sql VOLATILE AS $$
  SELECT '+9647' || lpad((floor(random() * 1000000000))::bigint::text, 9, '0');
$$;
CREATE FUNCTION vt.hash() RETURNS text LANGUAGE sql IMMUTABLE AS $$ SELECT '$argon2id$v=19$m=19456,t=2,p=1$dGVzdHNhbHQ$dGVzdGhhc2g'::text; $$;

CREATE FUNCTION vt.mk_user(p_role text DEFAULT 'user', p_status text DEFAULT 'active', p_phone text DEFAULT NULL) RETURNS bigint
LANGUAGE sql AS $$
  INSERT INTO users (name, phone_e164, role, status, password_hash)
  VALUES ('مستخدم اختبار', COALESCE(p_phone, vt.phone()), p_role, p_status, vt.hash()) RETURNING id;
$$;

CREATE FUNCTION vt.mk_showroom(p_owner bigint DEFAULT NULL, p_status text DEFAULT 'active') RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE o bigint := COALESCE(p_owner, vt.mk_user('dealer', 'active')); sid bigint;
BEGIN
  INSERT INTO showrooms (owner_id, name, status) VALUES (o, 'معرض اختبار', p_status) RETURNING id INTO sid;
  RETURN sid;
END $$;

CREATE FUNCTION vt.mk_scar(p_showroom bigint, p_status text DEFAULT 'available') RETURNS bigint LANGUAGE sql AS $$
  INSERT INTO cars (source_type, showroom_id, brand, model, year, price, status)
  VALUES ('showroom', p_showroom, 'Kia', 'Rio', 2020, 10000000, p_status) RETURNING id;
$$;

CREATE FUNCTION vt.mk_mcar(p_owner bigint, p_status text DEFAULT 'active') RETURNS bigint LANGUAGE sql AS $$
  INSERT INTO cars (source_type, owner_id, brand, model, year, price, status, phone)
  VALUES ('member', p_owner, 'Kia', 'Rio', 2020, 10000000, p_status, vt.phone()) RETURNING id;
$$;

CREATE FUNCTION vt.mk_asset(p_owner bigint, p_kind text DEFAULT 'car_image', p_status text DEFAULT 'ready') RETURNS uuid LANGUAGE sql AS $$
  INSERT INTO assets (owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at, reject_reason)
  VALUES (p_owner, p_kind, p_status, 'vt/' || gen_random_uuid() || '/full.webp', 'vt/' || gen_random_uuid() || '/thumb.webp',
          'image/webp', 1000, 800, 600, encode(sha256(convert_to(gen_random_uuid()::text, 'UTF8')), 'hex'), now(),
          CASE WHEN p_status = 'rejected' THEN 'test' END)
  RETURNING id;
$$;

-- يضيف صورة لسيارة (الأصل يُنشأ لمالك السيارة إن لم يُمرَّر). الأولى رئيسية افتراضيًا.
CREATE FUNCTION vt.mk_image(p_car bigint, p_asset uuid DEFAULT NULL, p_main boolean DEFAULT NULL, p_sort integer DEFAULT NULL) RETURNS bigint
LANGUAGE plpgsql AS $$
DECLARE c record; a uuid := p_asset; own bigint; n integer; nxt integer; iid bigint;
BEGIN
  SELECT * INTO c FROM cars WHERE id = p_car;
  IF a IS NULL THEN
    own := CASE WHEN c.source_type = 'member' THEN c.owner_id ELSE (SELECT owner_id FROM showrooms WHERE id = c.showroom_id) END;
    a := vt.mk_asset(own);
  END IF;
  SELECT count(*), COALESCE(max(sort_order) + 1, 0) INTO n, nxt FROM car_images WHERE car_id = p_car;
  INSERT INTO car_images (car_id, asset_id, sort_order, is_main)
  VALUES (p_car, a, COALESCE(p_sort, nxt), COALESCE(p_main, n = 0)) RETURNING id INTO iid;
  RETURN iid;
END $$;

CREATE FUNCTION vt.fill_images(p_car bigint, p_n integer) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  FOR i IN 1..p_n LOOP PERFORM vt.mk_image(p_car); END LOOP;
END $$;

CREATE FUNCTION vt.mk_session(p_user bigint) RETURNS uuid LANGUAGE sql AS $$
  INSERT INTO sessions (user_id, family_id, token_hash, expires_at)
  VALUES (p_user, gen_random_uuid(), sha256(convert_to(gen_random_uuid()::text, 'UTF8')), now() + interval '30 days') RETURNING id;
$$;


-- اشتراك حيّ لمعرض (الخطة المجانية افتراضيًا أو خطة بالرمز)
CREATE FUNCTION vt.mk_sub(p_showroom bigint, p_plan text DEFAULT 'free', p_status text DEFAULT 'active', p_days integer DEFAULT 30) RETURNS bigint LANGUAGE sql AS $$
  INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end)
  VALUES (p_showroom, (SELECT id FROM subscription_plans WHERE code = p_plan), p_status,
          LEAST(now(), now() + make_interval(days => p_days)) - interval '1 day', now() + make_interval(days => p_days))
  RETURNING id;
$$;

CREATE FUNCTION vt.mk_code(p_user bigint, p_purpose text DEFAULT 'phone_verify') RETURNS uuid LANGUAGE sql AS $$
  INSERT INTO verification_codes (purpose, user_id, target_phone, code_hash, expires_at)
  VALUES (p_purpose, p_user, vt.phone(), sha256(convert_to(gen_random_uuid()::text, 'UTF8')), now() + interval '10 minutes') RETURNING id;
$$;

-- مجموعة التثبيتات الثابتة التي تعتمد عليها ملفات الاختبار (تبقى في القاعدة؛ تُنشأ بعد فحوص البذرة)
CREATE FUNCTION vt.build_fixtures() RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  PERFORM vt.setfx('member',   vt.mk_user('user', 'active'));
  PERFORM vt.setfx('member2',  vt.mk_user('user', 'active'));
  PERFORM vt.setfx('dealer',   vt.mk_user('dealer', 'active'));
  PERFORM vt.setfx('dealer2',  vt.mk_user('dealer', 'active'));
  PERFORM vt.setfx('showroom', vt.mk_showroom(vt.f('dealer')));
  PERFORM vt.setfx('showroom2', vt.mk_showroom(vt.f('dealer2')));
  PERFORM vt.setfx('scar',     vt.mk_scar(vt.f('showroom')));
  PERFORM vt.setfx('scar2',    vt.mk_scar(vt.f('showroom2')));
  PERFORM vt.setfx('mcar',     vt.mk_mcar(vt.f('member')));
  PERFORM vt.setfx('mcar2',    vt.mk_mcar(vt.f('member2')));
  PERFORM vt.setfxu('asset_d', vt.mk_asset(vt.f('dealer')));
  PERFORM vt.setfxu('asset_m', vt.mk_asset(vt.f('member')));
  PERFORM vt.setfxu('asset_d2', vt.mk_asset(vt.f('dealer2')));
  PERFORM vt.setfx('img_s',    vt.mk_image(vt.f('scar')));
  PERFORM vt.setfx('img_m',    vt.mk_image(vt.f('mcar')));
  PERFORM vt.setfxu('session', vt.mk_session(vt.f('member')));
  PERFORM vt.setfxu('code',    vt.mk_code(vt.f('member')));
END $$;

-- SUITE: constraints
-- EXPECT_MIN: 140
SELECT vt.suite('constraints');
-- ملاحظة: القيد الذي يرفض يُتحقق منه بالاسم (hit) ثم يُقارن بتغطية pg_constraint في الملخص.
-- الاختبارات القائمة على UPDATE تعدّل صفًا صالحًا من التثبيتات؛ القائمة على INSERT تحتاج حقولًا إلزامية.

-- ===================== users =====================
SELECT vt.viol('users: name قصير', format($q$UPDATE users SET name = 'ab' WHERE id = %s$q$, vt.f('member')), '23514', 'users_name_len');
SELECT vt.viol('users: email بصيغة خاطئة', format($q$UPDATE users SET email = 'nope' WHERE id = %s$q$, vt.f('member')), '23514', 'users_email_format');
SELECT vt.viol('users: email أطول من 254', format($q$UPDATE users SET email = repeat('a', 250) || '@x.co' WHERE id = %s$q$, vt.f('member')), '23514', 'users_email_format');
SELECT vt.viol('users: role خارج المفردات', format($q$UPDATE users SET role = 'root' WHERE id = %s$q$, vt.f('member')), '23514', 'users_role_vocab');
SELECT vt.viol('users: status خارج المفردات', format($q$UPDATE users SET status = 'banned' WHERE id = %s$q$, vt.f('member')), '23514', 'users_status_vocab');
SELECT vt.viol('users: pending لغير التاجر', format($q$UPDATE users SET status = 'pending' WHERE id = %s$q$, vt.f('member')), '23514', 'users_pending_dealer');
SELECT vt.viol('users: password_hash ليس argon2id', format($q$UPDATE users SET password_hash = 'plain' WHERE id = %s$q$, vt.f('member')), '23514', 'users_hash_argon2id');
SELECT vt.viol('users: failed_logins سالب', format($q$UPDATE users SET failed_logins = -1 WHERE id = %s$q$, vt.f('member')), '23514', 'users_failed_logins');
SELECT vt.viol('users: version = 0 عند الإدخال', $q$INSERT INTO users (name, phone_e164, password_hash, version) VALUES ('اختبار ثلاثة', vt.phone(), vt.hash(), 0)$q$, '23514', 'users_version_pos');
SELECT vt.viol('users: هاتف بصيغة محلية (نطاق e164_iq)', format($q$UPDATE users SET phone_e164 = '07701234567' WHERE id = %s$q$, vt.f('member')), '23514', 'e164_iq_format');
SELECT vt.viol('users: هاتف غير عراقي (نطاق e164_iq)', format($q$UPDATE users SET phone_e164 = '+14155550123' WHERE id = %s$q$, vt.f('member')), '23514', 'e164_iq_format');
SELECT vt.viol('users: هاتف مكرر', format($q$UPDATE users SET phone_e164 = (SELECT phone_e164 FROM users WHERE id = %s) WHERE id = %s$q$, vt.f('member2'), vt.f('member')), '23505', 'users_phone_active_uq');
SELECT vt.viol('users: بريد مكرر (غير حساس للحالة)',
  format($q$UPDATE users SET email = 'dup@example.com' WHERE id = %s; UPDATE users SET email = 'DUP@Example.com' WHERE id = %s$q$, vt.f('member2'), vt.f('member')), '23505', 'users_email_active_uq');
SELECT vt.viol('users: name فارغ (NOT NULL)', format($q$UPDATE users SET name = NULL WHERE id = %s$q$, vt.f('member')), '23502');
SELECT vt.viol('users: name أطول من 100 (varchar)', format($q$UPDATE users SET name = repeat('ا', 101) WHERE id = %s$q$, vt.f('member')), '22001');
SELECT vt.scenario('users: الرقم المحذوف ناعمًا يمكن إعادة تسجيله (الفرادة جزئية)',
  format($s$UPDATE users SET deleted_at = now() WHERE id = %s; SELECT vt.mk_user('user', 'active', (SELECT phone_e164 FROM users WHERE id = %s))$s$, vt.f('member'), vt.f('member')),
  format($c$SELECT count(*) = 2 FROM users WHERE phone_e164 = (SELECT phone_e164 FROM users WHERE id = %s)$c$, vt.f('member')));

-- ===================== assets =====================
SELECT vt.viol('assets: kind خارج المفردات', format($q$UPDATE assets SET kind = 'video' WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_kind_vocab');
SELECT vt.viol('assets: status خارج المفردات', format($q$UPDATE assets SET status = 'done' WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_status_vocab');
SELECT vt.viol('assets: mime غير WebP', format($q$UPDATE assets SET mime = 'image/png' WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_mime_vocab');
SELECT vt.viol('assets: bytes = 0', format($q$UPDATE assets SET bytes = 0 WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_bytes_pos');
SELECT vt.viol('assets: width = 0', format($q$UPDATE assets SET width = 0 WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_dims_pos');
SELECT vt.viol('assets: sha256 غير سداسي عشري', format($q$UPDATE assets SET sha256 = 'xyz' WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_sha256_hex');
SELECT vt.viol('assets: ready بلا حقول المعالجة',
  format($q$INSERT INTO assets (owner_id, kind, status) VALUES (%s, 'car_image', 'pending'); UPDATE assets SET status = 'ready' WHERE owner_id = %s AND status = 'pending' AND storage_key IS NULL$q$, vt.f('dealer'), vt.f('dealer')), '23514', 'assets_ready_shape');
SELECT vt.viol('assets: rejected بلا سبب', format($q$UPDATE assets SET status = 'rejected', reject_reason = NULL WHERE id = '%s'$q$, vt.fu('asset_d')), '23514', 'assets_rejected_why|assets_ready_shape');
SELECT vt.viol('assets: storage_key مكرر',
  format($q$INSERT INTO assets (owner_id, kind, status, storage_key) SELECT owner_id, kind, 'pending', storage_key FROM assets WHERE id = '%s'$q$, vt.fu('asset_d')), '23505', 'assets_storage_key_uq');
SELECT vt.viol('assets: legacy_ref مكرر',
  format($q$UPDATE assets SET legacy_ref = 'dup-ref' WHERE id = '%s'; UPDATE assets SET legacy_ref = 'dup-ref' WHERE id = '%s'$q$, vt.fu('asset_d'), vt.fu('asset_d2')), '23505', 'assets_legacy_ref_uq');
SELECT vt.viol('assets: حذف مالك له أصول (RESTRICT)', format($q$DELETE FROM users WHERE id = %s$q$, vt.f('member')), '23503|23001');

-- ===================== showrooms =====================
SELECT vt.viol('showrooms: name قصير', format($q$UPDATE showrooms SET name = ' ' WHERE id = %s$q$, vt.f('showroom')), '23514', 'showrooms_name_len');
SELECT vt.viol('showrooms: status خارج المفردات', format($q$UPDATE showrooms SET status = 'closed' WHERE id = %s$q$, vt.f('showroom')), '23514', 'showrooms_status_vocab');
SELECT vt.viol('showrooms: latitude بلا longitude', format($q$UPDATE showrooms SET latitude = 31.9, longitude = NULL WHERE id = %s$q$, vt.f('showroom')), '23514', 'showrooms_geo_pair');
SELECT vt.viol('showrooms: latitude خارج النطاق', format($q$UPDATE showrooms SET latitude = 95, longitude = 44 WHERE id = %s$q$, vt.f('showroom')), '23514', 'showrooms_geo_range');
SELECT vt.viol('showrooms: أكثر من 20 خدمة', format($q$UPDATE showrooms SET services = (SELECT array_agg('s' || g) FROM generate_series(1, 21) g) WHERE id = %s$q$, vt.f('showroom')), '23514', 'showrooms_services_size');
SELECT vt.viol('showrooms: خدمة أطول من 60', format($q$UPDATE showrooms SET services = ARRAY[repeat('x', 61)] WHERE id = %s$q$, vt.f('showroom')), '23514', 'showrooms_services_size');
SELECT vt.viol('showrooms: هاتف غير صالح (نطاق e164_any)', format($q$UPDATE showrooms SET phone = '123' WHERE id = %s$q$, vt.f('showroom')), '23514', 'e164_any_format');
SELECT vt.viol('showrooms: version = 0 عند الإدخال', $q$INSERT INTO showrooms (owner_id, name, version) VALUES (vt.mk_user('dealer'), 'معرض بإصدار صفر', 0)$q$, '23514', 'showrooms_version_pos');
SELECT vt.viol('showrooms: name أطول من 150', format($q$UPDATE showrooms SET name = repeat('م', 151) WHERE id = %s$q$, vt.f('showroom')), '22001');
SELECT vt.viol('showrooms: معرض ثانٍ لنفس التاجر', format($q$INSERT INTO showrooms (owner_id, name) VALUES (%s, 'معرض مكرر')$q$, vt.f('dealer')), '23505', 'showrooms_owner_uq');
SELECT vt.viol('showrooms: المالك ليس تاجرًا (إدخال)', format($q$INSERT INTO showrooms (owner_id, name) VALUES (%s, 'معرض لعضو')$q$, vt.f('member')), '23514', 'showroom owner must be a dealer');
SELECT vt.viol('showrooms: نقل الملكية إلى غير تاجر', format($q$UPDATE showrooms SET owner_id = %s WHERE id = %s$q$, vt.f('member'), vt.f('showroom')), '23514', 'showroom owner must be a dealer');
SELECT vt.viol('showrooms: حذف مالك له معرض (RESTRICT)', format($q$DELETE FROM users WHERE id = %s$q$, vt.f('dealer')), '23503|23001');
SELECT vt.scenario('showrooms: حذف أصل الغلاف يصفّر cover_asset_id (SET NULL)',
  format($s$UPDATE showrooms SET cover_asset_id = (SELECT vt.mk_asset(%s, 'showroom_cover')) WHERE id = %s; DELETE FROM assets WHERE id = (SELECT cover_asset_id FROM showrooms WHERE id = %s)$s$, vt.f('dealer'), vt.f('showroom'), vt.f('showroom')),
  format($c$SELECT cover_asset_id IS NULL FROM showrooms WHERE id = %s$c$, vt.f('showroom')));

-- ===================== cars =====================
SELECT vt.viol('cars: source_type خارج المفردات', format($q$UPDATE cars SET source_type = 'x' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_source_vocab|cars_source_shape');
SELECT vt.viol('cars: سيارة معرض بلا showroom_id', format($q$UPDATE cars SET showroom_id = NULL WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_source_shape');
SELECT vt.viol('cars: سيارة معرض لها owner_id', format($q$UPDATE cars SET owner_id = %s WHERE id = %s$q$, vt.f('member'), vt.f('scar')), '23514', 'cars_source_shape');
SELECT vt.viol('cars: إعلان عضو بلا owner_id', format($q$UPDATE cars SET owner_id = NULL WHERE id = %s$q$, vt.f('mcar')), '23514', 'cars_source_shape');
SELECT vt.viol('cars: إعلان عضو له showroom_id', format($q$UPDATE cars SET showroom_id = %s WHERE id = %s$q$, vt.f('showroom'), vt.f('mcar')), '23514', 'cars_source_shape');
SELECT vt.viol('cars: حالة pending لسيارة معرض', format($q$UPDATE cars SET status = 'pending' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_status_by_source');
SELECT vt.viol('cars: حالة reserved (غير موجودة) لسيارة معرض', format($q$UPDATE cars SET status = 'reserved' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_status_by_source');
SELECT vt.viol('cars: حالة available لإعلان عضو', format($q$UPDATE cars SET status = 'available' WHERE id = %s$q$, vt.f('mcar')), '23514', 'cars_status_by_source');
SELECT vt.viol('cars: حقل عضو (هاتف) على سيارة معرض', format($q$UPDATE cars SET phone = vt.phone() WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_member_only_fields');
SELECT vt.viol('cars: حقل عضو (موقع) على سيارة معرض', format($q$UPDATE cars SET location = 'x' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_member_only_fields');
SELECT vt.viol('cars: سبب رفض على سيارة معرض', format($q$UPDATE cars SET rejection_reason = 'x' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_member_only_fields');
SELECT vt.viol('cars: إعلان عضو بلا هاتف', format($q$UPDATE cars SET phone = NULL WHERE id = %s$q$, vt.f('mcar')), '23514', 'cars_member_phone_required');
SELECT vt.viol('cars: brand فارغ', format($q$UPDATE cars SET brand = '   ' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_brand_nonempty');
SELECT vt.viol('cars: model فارغ', format($q$UPDATE cars SET model = '   ' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_model_nonempty');
SELECT vt.viol('cars: year = 1979', format($q$UPDATE cars SET year = 1979 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_year_range');
SELECT vt.viol('cars: year = 2101', format($q$UPDATE cars SET year = 2101 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_year_range');
SELECT vt.viol('cars: year = 1900 (العيب 2 من الـ14)', format($q$UPDATE cars SET year = 1900 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_year_range');
SELECT vt.viol('cars: price = 0', format($q$UPDATE cars SET price = 0 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_price_pos');
SELECT vt.viol('cars: price سالب', format($q$UPDATE cars SET price = -5 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_price_pos');
SELECT vt.viol('cars: currency = EUR', format($q$UPDATE cars SET currency = 'EUR' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_currency_vocab');
SELECT vt.viol('cars: mileage سالب', format($q$UPDATE cars SET mileage = -1 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_mileage_nonneg');
SELECT vt.viol('cars: transmission خارج المفردات', format($q$UPDATE cars SET transmission = 'automatic' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_transmission_vocab');
SELECT vt.viol('cars: fuel_type خارج المفردات', format($q$UPDATE cars SET fuel_type = 'petrol' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_fuel_vocab');
SELECT vt.viol('cars: latitude بلا longitude', format($q$UPDATE cars SET latitude = 31 WHERE id = %s$q$, vt.f('mcar')), '23514', 'cars_geo_pair');
SELECT vt.viol('cars: latitude خارج النطاق', format($q$UPDATE cars SET latitude = 91, longitude = 44 WHERE id = %s$q$, vt.f('mcar')), '23514', 'cars_geo_range');
SELECT vt.viol('cars: version = 0 عند الإدخال', format($q$INSERT INTO cars (source_type, showroom_id, brand, model, year, price, status, version) VALUES ('showroom', %s, 'a', 'b', 2020, 1, 'available', 0)$q$, vt.f('showroom')), '23514', 'cars_version_pos');
SELECT vt.viol('cars: price يتجاوز numeric(14,0)', format($q$UPDATE cars SET price = 100000000000000 WHERE id = %s$q$, vt.f('scar')), '22003');
SELECT vt.viol('cars: brand أطول من 50', format($q$UPDATE cars SET brand = repeat('b', 51) WHERE id = %s$q$, vt.f('scar')), '22001');
SELECT vt.viol('cars: model أطول من 80', format($q$UPDATE cars SET model = repeat('m', 81) WHERE id = %s$q$, vt.f('scar')), '22001');
SELECT vt.viol('cars: color أطول من 40', format($q$UPDATE cars SET color = repeat('c', 41) WHERE id = %s$q$, vt.f('scar')), '22001');
SELECT vt.viol('cars: description أطول من 2000', format($q$UPDATE cars SET description = repeat('d', 2001) WHERE id = %s$q$, vt.f('scar')), '22001');
SELECT vt.viol('cars: location أطول من 200', format($q$UPDATE cars SET location = repeat('l', 201) WHERE id = %s$q$, vt.f('mcar')), '22001');
SELECT vt.viol('cars: هاتف إعلان بصيغة خاطئة (نطاق e164_iq)', format($q$UPDATE cars SET phone = '07701234567' WHERE id = %s$q$, vt.f('mcar')), '23514', 'e164_iq_format');
SELECT vt.viol('cars: معرض غير موجود (FK)', $q$INSERT INTO cars (source_type, showroom_id, brand, model, year, price, status) VALUES ('showroom', 999999999, 'a', 'b', 2020, 1, 'available')$q$, '23503', 'cars_showroom_id_fkey');
SELECT vt.viol('cars: مالك غير موجود (FK)', $q$INSERT INTO cars (source_type, owner_id, brand, model, year, price, status, phone) VALUES ('member', 999999999, 'a', 'b', 2020, 1, 'active', vt.phone())$q$, '23503', 'cars_owner_id_fkey');
SELECT vt.viol('cars: حذف مالك له إعلانات (RESTRICT)', format($q$DELETE FROM users WHERE id = %s$q$, vt.f('member2')), '23503|23001');
SELECT vt.scenario('cars: حذف المعرض يحذف سياراته وصورها (CASCADE)',
  format($s$DELETE FROM showrooms WHERE id = %s$s$, vt.f('showroom')),
  format($c$SELECT NOT EXISTS (SELECT 1 FROM cars WHERE showroom_id = %s) AND NOT EXISTS (SELECT 1 FROM car_images WHERE car_id = %s)$c$, vt.f('showroom'), vt.f('scar')));
SELECT vt.scenario('cars: الحذف الناعم يزيل المفضلة فورًا ويخفي السيارة من العام',
  format($s$INSERT INTO favorites (user_id, car_id) VALUES (%s, %s); UPDATE cars SET deleted_at = now() WHERE id = %s$s$, vt.f('member2'), vt.f('scar'), vt.f('scar')),
  format($c$SELECT NOT EXISTS (SELECT 1 FROM favorites WHERE car_id = %s) AND NOT EXISTS (SELECT 1 FROM public_cars WHERE id = %s)$c$, vt.f('scar'), vt.f('scar')));

-- ===================== car_images =====================
SELECT vt.viol('car_images: أصل مرتبط بصورتين', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) SELECT car_id, asset_id, 9, false FROM car_images WHERE id = %s$q$, vt.f('img_s')), '23505', 'car_images_asset_uq');
SELECT vt.viol('car_images: صورتان رئيسيتان لسيارة', format($q$SELECT vt.mk_image(%s, NULL, true)$q$, vt.f('scar')), '23505', 'car_images_one_main_uq');
SELECT vt.viol('car_images: ترتيب مكرر (فوري)', format($q$SET CONSTRAINTS car_images_order_uq IMMEDIATE; SELECT vt.mk_image(%s, NULL, false, 0)$q$, vt.f('scar')), '23505', 'car_images_order_uq');
SELECT vt.viol('car_images: sort_order سالب', format($q$SELECT vt.mk_image(%s, NULL, false, -1)$q$, vt.f('scar')), '23514', 'car_images_order_nonneg');
SELECT vt.viol('car_images: تغيير car_id ممنوع', format($q$UPDATE car_images SET car_id = %s WHERE id = %s$q$, vt.f('scar2'), vt.f('img_s')), '23514', 'immutable');
SELECT vt.viol('car_images: تغيير asset_id ممنوع', format($q$UPDATE car_images SET asset_id = '%s' WHERE id = %s$q$, vt.fu('asset_d'), vt.f('img_s')), '23514', 'immutable');

-- ===================== favorites =====================
SELECT vt.viol('favorites: مفضلة مكررة', format($q$INSERT INTO favorites (user_id, car_id) VALUES (%s, %s); INSERT INTO favorites (user_id, car_id) VALUES (%s, %s)$q$, vt.f('member'), vt.f('scar'), vt.f('member'), vt.f('scar')), '23505', 'favorites_user_car_uq');
SELECT vt.viol('favorites: مستخدم غير موجود (FK)', format($q$INSERT INTO favorites (user_id, car_id) VALUES (999999999, %s)$q$, vt.f('scar')), '23503', 'favorites_user_id_fkey');
SELECT vt.viol('favorites: سيارة غير موجودة (FK)', format($q$INSERT INTO favorites (user_id, car_id) VALUES (%s, 999999999)$q$, vt.f('member')), '23503', 'favorites_car_id_fkey');

-- ===================== sessions =====================
SELECT vt.viol('sessions: token_hash بطول خاطئ', format($q$INSERT INTO sessions (user_id, family_id, token_hash, expires_at) VALUES (%s, gen_random_uuid(), '\x00'::bytea, now() + interval '1 day')$q$, vt.f('member')), '23514', 'sessions_token_hash_len');
SELECT vt.viol('sessions: الانتهاء قبل الإنشاء', format($q$INSERT INTO sessions (user_id, family_id, token_hash, expires_at) VALUES (%s, gen_random_uuid(), sha256('a'::bytea), now() - interval '1 day')$q$, vt.f('member')), '23514', 'sessions_expiry_after');
SELECT vt.viol('sessions: revoked_at بلا سبب', format($q$UPDATE sessions SET revoked_at = now() WHERE id = '%s'$q$, vt.fu('session')), '23514', 'sessions_revoke_pair');
SELECT vt.viol('sessions: سبب بلا revoked_at', format($q$UPDATE sessions SET revoked_reason = 'logout' WHERE id = '%s'$q$, vt.fu('session')), '23514', 'sessions_revoke_pair');
SELECT vt.viol('sessions: سبب إلغاء خارج المفردات', format($q$UPDATE sessions SET revoked_at = now(), revoked_reason = 'bye' WHERE id = '%s'$q$, vt.fu('session')), '23514', 'sessions_reason_vocab');
SELECT vt.viol('sessions: token_hash مكرر', format($q$INSERT INTO sessions (user_id, family_id, token_hash, expires_at) SELECT user_id, gen_random_uuid(), token_hash, expires_at FROM sessions WHERE id = '%s'$q$, vt.fu('session')), '23505', 'sessions_token_hash_uq');
SELECT vt.scenario('sessions: حذف الجلسة المستبدَلة يصفّر replaced_by (SET NULL)',
  format($s$SELECT vt.setfxu('s1', vt.mk_session(%s)); SELECT vt.setfxu('s2', vt.mk_session(%s)); UPDATE sessions SET revoked_at = now(), revoked_reason = 'rotated', replaced_by = vt.fu('s2') WHERE id = vt.fu('s1'); DELETE FROM sessions WHERE id = vt.fu('s2')$s$, vt.f('member'), vt.f('member')),
  $c$SELECT replaced_by IS NULL FROM sessions WHERE id = vt.fu('s1')$c$);
SELECT vt.scenario('sessions: حذف المستخدم يحذف جلساته (CASCADE)',
  $s$SELECT vt.setfx('uu', vt.mk_user('user')); SELECT vt.mk_session(vt.f('uu')); DELETE FROM users WHERE id = vt.f('uu')$s$,
  $c$SELECT NOT EXISTS (SELECT 1 FROM sessions WHERE user_id = vt.f('uu'))$c$);

-- ===================== verification_codes / message_deliveries =====================
SELECT vt.viol('verification_codes: purpose خارج المفردات', format($q$UPDATE verification_codes SET purpose = 'login' WHERE id = '%s'$q$, vt.fu('code')), '23514', 'vcodes_purpose_vocab');
SELECT vt.viol('verification_codes: code_hash بطول خاطئ', format($q$UPDATE verification_codes SET code_hash = '\x01'::bytea WHERE id = '%s'$q$, vt.fu('code')), '23514', 'vcodes_hash_len');
SELECT vt.viol('verification_codes: attempts > max_attempts', format($q$UPDATE verification_codes SET attempts = 6 WHERE id = '%s'$q$, vt.fu('code')), '23514', 'vcodes_attempts_ok');
SELECT vt.viol('verification_codes: الانتهاء قبل الإنشاء', format($q$UPDATE verification_codes SET expires_at = created_at - interval '1 hour' WHERE id = '%s'$q$, vt.fu('code')), '23514', 'vcodes_expiry_after');
SELECT vt.viol('verification_codes: مستهلك ومُبطَل معًا', format($q$UPDATE verification_codes SET consumed_at = now(), invalidated_at = now() WHERE id = '%s'$q$, vt.fu('code')), '23514', 'vcodes_not_both');
SELECT vt.viol('verification_codes: رمزان فعّالان لنفس (مستخدم، غرض)', format($q$SELECT vt.mk_code(%s, 'phone_verify')$q$, vt.f('member')), '23505', 'vcodes_one_active_uq');
SELECT vt.scenario('verification_codes: رمز جديد بعد إبطال السابق يُقبل',
  format($s$UPDATE verification_codes SET invalidated_at = now() WHERE user_id = %s AND purpose = 'phone_verify'; SELECT vt.mk_code(%s, 'phone_verify')$s$, vt.f('member'), vt.f('member')),
  format($c$SELECT count(*) = 2 FROM verification_codes WHERE user_id = %s AND purpose = 'phone_verify'$c$, vt.f('member')));
SELECT vt.viol('verification_codes: هاتف غير عراقي (نطاق)', format($q$UPDATE verification_codes SET target_phone = '+441234567890' WHERE id = '%s'$q$, vt.fu('code')), '23514', 'e164_iq_format');
SELECT vt.viol('message_deliveries: channel خارج المفردات', $q$INSERT INTO message_deliveries (channel, provider, to_phone) VALUES ('email', 'twilio', vt.phone())$q$, '23514', 'msgdel_channel_vocab');
SELECT vt.viol('message_deliveries: status خارج المفردات', $q$INSERT INTO message_deliveries (channel, provider, to_phone, status) VALUES ('sms', 'twilio', vt.phone(), 'lost')$q$, '23514', 'msgdel_status_vocab');
SELECT vt.viol('message_deliveries: تكلفة سالبة', $q$INSERT INTO message_deliveries (channel, provider, to_phone, cost_micros) VALUES ('sms', 'twilio', vt.phone(), -1)$q$, '23514', 'msgdel_cost_nonneg');
SELECT vt.viol('message_deliveries: delivered بلا delivered_at', $q$INSERT INTO message_deliveries (channel, provider, to_phone, status) VALUES ('sms', 'twilio', vt.phone(), 'delivered')$q$, '23514', 'msgdel_delivered_at');
SELECT vt.viol('message_deliveries: معرّف رسالة المزوّد مكرر', $q$INSERT INTO message_deliveries (channel, provider, to_phone, provider_message_id) VALUES ('sms', 'twilio', vt.phone(), 'SM1'); INSERT INTO message_deliveries (channel, provider, to_phone, provider_message_id) VALUES ('sms', 'twilio', vt.phone(), 'SM1')$q$, '23505', 'msgdel_provider_msg_uq');
SELECT vt.allow('message_deliveries: نفس المعرّف عند مزوّد آخر يُقبل', $q$INSERT INTO message_deliveries (channel, provider, to_phone, provider_message_id) VALUES ('sms', 'twilio', vt.phone(), 'SM2'); INSERT INTO message_deliveries (channel, provider, to_phone, provider_message_id) VALUES ('sms', 'plivo', vt.phone(), 'SM2')$q$);

-- ===================== reward_grants =====================
SELECT vt.viol('reward_grants: status خارج المفردات', format($q$INSERT INTO reward_grants (user_id, status, expires_at) VALUES (%s, 'done', now() + interval '1 hour')$q$, vt.f('member')), '23514', 'reward_status_vocab');
SELECT vt.viol('reward_grants: verified بلا معرّف SSV', format($q$INSERT INTO reward_grants (user_id, status, verified_at, expires_at) VALUES (%s, 'verified', now(), now() + interval '1 hour')$q$, vt.f('member')), '23514', 'reward_verified_shape');
SELECT vt.viol('reward_grants: consumed بلا consumed_at', format($q$INSERT INTO reward_grants (user_id, status, ssv_transaction_id, verified_at, expires_at) VALUES (%s, 'consumed', 'tx1', now(), now() + interval '1 hour')$q$, vt.f('member')), '23514', 'reward_consumed_shape');
SELECT vt.viol('reward_grants: الانتهاء قبل الإنشاء', format($q$INSERT INTO reward_grants (user_id, expires_at) VALUES (%s, now() - interval '1 hour')$q$, vt.f('member')), '23514', 'reward_expiry_after');
SELECT vt.viol('reward_grants: معرّف SSV مكرر (نفس المزوّد)',
  format($q$INSERT INTO reward_grants (user_id, status, ssv_transaction_id, verified_at, expires_at) VALUES (%s, 'verified', 'tx9', now(), now() + interval '1 hour'); INSERT INTO reward_grants (user_id, status, ssv_transaction_id, verified_at, expires_at) VALUES (%s, 'verified', 'tx9', now(), now() + interval '1 hour')$q$, vt.f('member'), vt.f('member2')), '23505', 'reward_ssv_uq');
SELECT vt.viol('reward_grants: مكافأتان لسيارة واحدة',
  format($q$INSERT INTO reward_grants (user_id, car_id, expires_at) VALUES (%s, %s, now() + interval '1 hour'); INSERT INTO reward_grants (user_id, car_id, expires_at) VALUES (%s, %s, now() + interval '1 hour')$q$, vt.f('member'), vt.f('mcar'), vt.f('member'), vt.f('mcar')), '23505', 'reward_grants_car_id_key');
SELECT vt.scenario('reward_grants: حذف السيارة يُبقي المكافأة (car_id ← NULL)',
  format($s$INSERT INTO reward_grants (user_id, car_id, expires_at) VALUES (%s, %s, now() + interval '1 hour'); DELETE FROM cars WHERE id = %s$s$, vt.f('member'), vt.f('mcar'), vt.f('mcar')),
  format($c$SELECT count(*) = 1 FROM reward_grants WHERE user_id = %s AND car_id IS NULL$c$, vt.f('member')));

-- ===================== subscriptions / payments / plans =====================
SELECT vt.viol('plans: code مكرر', $q$INSERT INTO subscription_plans (code, name) VALUES ('free', 'مكررة')$q$, '23505', 'plans_code_uq');
SELECT vt.viol('plans: billing_interval خارج المفردات', $q$INSERT INTO subscription_plans (code, name, billing_interval, price) VALUES ('p1', 'خطة', 'week', 5)$q$, '23514', 'plans_interval_vocab');
SELECT vt.viol('plans: سعر سالب', $q$INSERT INTO subscription_plans (code, name, billing_interval, price) VALUES ('p2', 'خطة', 'month', -1)$q$, '23514', 'plans_price_nonneg');
SELECT vt.viol('plans: سعر بلا دورة فوترة', $q$INSERT INTO subscription_plans (code, name, price) VALUES ('p3', 'خطة', 5)$q$, '23514', 'plans_priced_needs_interval');
SELECT vt.viol('plans: currency خارج المفردات', $q$INSERT INTO subscription_plans (code, name, currency) VALUES ('p4', 'خطة', 'EUR')$q$, '23514', 'plans_currency_vocab');
SELECT vt.viol('plans: entitlements ليست كائنًا', $q$INSERT INTO subscription_plans (code, name, entitlements) VALUES ('p5', 'خطة', '[1]'::jsonb)$q$, '23514', 'plans_entitlements_object');
SELECT vt.viol('subscriptions: status خارج المفردات', format($q$INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'paused', now(), now() + interval '30 days')$q$, vt.f('showroom')), '23514', 'subs_status_vocab');
SELECT vt.viol('subscriptions: نهاية الفترة قبل بدايتها', format($q$INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'active', now(), now() - interval '1 day')$q$, vt.f('showroom')), '23514', 'subs_period_order');
SELECT vt.viol('subscriptions: اشتراكان حيّان لمعرض واحد',
  format($q$INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'active', now(), now() + interval '30 days'); INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'trialing', now(), now() + interval '30 days')$q$, vt.f('showroom'), vt.f('showroom')), '23505', 'subs_one_live_uq');
SELECT vt.allow('subscriptions: اشتراك جديد بعد إلغاء السابق يُقبل',
  format($q$INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'canceled', now() - interval '60 days', now() - interval '30 days'); INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'active', now(), now() + interval '30 days')$q$, vt.f('showroom'), vt.f('showroom')));
SELECT vt.viol('subscriptions: معرّف اشتراك المزوّد مكرر',
  format($q$INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end, provider, provider_subscription_id) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'canceled', now(), now() + interval '1 day', 'x', 'sub1'); INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end, provider, provider_subscription_id) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'canceled', now(), now() + interval '1 day', 'x', 'sub1')$q$, vt.f('showroom'), vt.f('showroom2')), '23505', 'subs_provider_uq');
SELECT vt.viol('subscriptions: حذف خطة لها اشتراكات (RESTRICT)',
  format($q$INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end) VALUES (%s, (SELECT id FROM subscription_plans WHERE code = 'free'), 'active', now(), now() + interval '30 days'); DELETE FROM subscription_plans WHERE code = 'free'$q$, vt.f('showroom')), '23503|23001');
SELECT vt.viol('payments: مبلغ سالب', format($q$SELECT vt.setfx('sub', vt.mk_sub(%s)); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref) VALUES (vt.f('sub'), -1, 'IQD', 'manual', 'r-neg')$q$, vt.f('showroom')), '23514', 'payments_amount_nonneg');
SELECT vt.viol('payments: currency خارج المفردات', format($q$SELECT vt.setfx('sub', vt.mk_sub(%s)); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref) VALUES (vt.f('sub'), 1, 'EUR', 'manual', 'r-cur')$q$, vt.f('showroom')), '23514', 'payments_currency_vocab');
SELECT vt.viol('payments: status خارج المفردات', format($q$SELECT vt.setfx('sub', vt.mk_sub(%s)); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref, status) VALUES (vt.f('sub'), 1, 'IQD', 'manual', 'r-st', 'done')$q$, vt.f('showroom')), '23514', 'payments_status_vocab');
SELECT vt.viol('payments: paid بلا paid_at', format($q$SELECT vt.setfx('sub', vt.mk_sub(%s)); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref, status) VALUES (vt.f('sub'), 1, 'IQD', 'manual', 'r-paid', 'paid')$q$, vt.f('showroom')), '23514', 'payments_paid_at');
SELECT vt.viol('payments: (provider, provider_ref) مكرر', format($q$SELECT vt.setfx('sub', vt.mk_sub(%s)); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref) VALUES (vt.f('sub'), 1, 'IQD', 'manual', 'dup'); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref) VALUES (vt.f('sub'), 1, 'IQD', 'manual', 'dup')$q$, vt.f('showroom')), '23505', 'payments_provider_ref_uq');
SELECT vt.viol('payments: حذف اشتراك له مدفوعات (RESTRICT)', format($q$SELECT vt.setfx('sub', vt.mk_sub(%s)); INSERT INTO payments (subscription_id, amount, currency, provider, provider_ref) VALUES (vt.f('sub'), 1, 'IQD', 'manual', 'r-del'); DELETE FROM subscriptions WHERE id = vt.f('sub')$q$, vt.f('showroom')), '23503|23001');

-- ===================== audit_logs / exchange_rates / app_settings =====================
SELECT vt.viol('audit_logs: actor_role خارج المفردات', $q$INSERT INTO audit_logs (actor_role, action, entity_type) VALUES ('root', 'x', 'y')$q$, '23514', 'audit_actor_role_vocab');
SELECT vt.viol('audit_logs: before_data ليس كائنًا', $q$INSERT INTO audit_logs (action, entity_type, before_data) VALUES ('x', 'y', '[1]'::jsonb)$q$, '23514', 'audit_before_object');
SELECT vt.viol('audit_logs: after_data ليس كائنًا', $q$INSERT INTO audit_logs (action, entity_type, after_data) VALUES ('x', 'y', '"s"'::jsonb)$q$, '23514', 'audit_after_object');
SELECT vt.viol('audit_logs: UPDATE ممنوع (حتى للمشرف)', $q$INSERT INTO audit_logs (action, entity_type) VALUES ('x', 'y'); UPDATE audit_logs SET reason = 'z' WHERE action = 'x'$q$, '42501', 'append-only');
SELECT vt.viol('audit_logs: DELETE ممنوع (حتى للمشرف)', $q$INSERT INTO audit_logs (action, entity_type) VALUES ('x', 'y'); DELETE FROM audit_logs WHERE action = 'x'$q$, '42501', 'append-only');
SELECT vt.viol('audit_logs: TRUNCATE ممنوع (حتى للمشرف)', $q$TRUNCATE audit_logs$q$, '42501', 'append-only');
SELECT vt.viol('exchange_rates: سعر صفر', $q$INSERT INTO exchange_rates (usd_to_iqd, kind) VALUES (0, 'manual')$q$, '23514', 'fx_rate_pos');
SELECT vt.viol('exchange_rates: kind خارج المفردات', $q$INSERT INTO exchange_rates (usd_to_iqd, kind) VALUES (1300, 'auto')$q$, '23514', 'fx_kind_vocab');
SELECT vt.viol('app_settings: مفتاح أطول من 80', $q$INSERT INTO app_settings (key, value) VALUES (repeat('k', 81), '{}'::jsonb)$q$, '22001');
SELECT vt.viol('app_settings: value فارغ', $q$INSERT INTO app_settings (key, value) VALUES ('nullval', NULL)$q$, '23502');

-- SUITE: baseline
-- EXPECT_MIN: 4
SELECT vt.suite('baseline');
-- تثبيتات الاختبار (تُنشأ مرة واحدة بعد فحوص البذرة؛ تبقى للملفات التالية)
SELECT vt.build_fixtures();

-- قبل التشديد 0013: صلاحيات حساب التطبيق على cars/showrooms على مستوى الجدول (الفجوة المعروفة من 11.2).
-- هذه الاختبارات تثبت الفجوة (متوقع: النجاح) كي يكون «قبل/بعد» دليلًا لا افتراضًا.
SELECT vt.allow('قبل 0013: najaf_app يستطيع تعديل cars.created_at (فجوة معروفة)',
  format($q$UPDATE cars SET created_at = created_at - interval '1 day' WHERE id = %s$q$, vt.f('scar')), 'najaf_app');
SELECT vt.allow('قبل 0013: najaf_app يستطيع تعديل showrooms.owner_id (فجوة معروفة)',
  format($q$UPDATE showrooms SET owner_id = owner_id WHERE id = %s$q$, vt.f('showroom')), 'najaf_app');
SELECT vt.allow('قبل 0013: najaf_app يستطيع تعديل cars.source_type (فجوة معروفة)',
  format($q$UPDATE cars SET source_type = source_type WHERE id = %s$q$, vt.f('scar')), 'najaf_app');
SELECT vt.ok('الفجوة مؤكَّدة بالكتالوج: has_column_privilege(najaf_app, cars.created_at, UPDATE) = true',
  has_column_privilege('najaf_app', 'cars', 'created_at', 'UPDATE'));

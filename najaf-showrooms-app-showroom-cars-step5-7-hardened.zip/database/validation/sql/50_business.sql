-- SUITE: business
-- EXPECT_MIN: 50
-- (50 = 48 اختبارًا غير مشروط + كتلة آخر مدير (1) + كتلة الغلاف على النسخة المُسلَّمة (1)؛ يصير 54 على النسخة المعدّلة حيث تُنفَّذ اختبارات الغلاف الخمسة)
SELECT vt.suite('business');

-- أدوار الاختبار (على مستوى العنقود؛ تُزال بـ CLEAN_ROLES=1)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vt_app_login') THEN CREATE ROLE vt_app_login LOGIN IN ROLE najaf_app; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vt_ops')       THEN CREATE ROLE vt_ops NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'vt_nobody')    THEN CREATE ROLE vt_nobody NOLOGIN; END IF;
END $$;
GRANT USAGE ON SCHEMA public TO vt_ops;
GRANT ALL ON ALL TABLES IN SCHEMA public TO vt_ops;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO vt_ops;

-- ===================== الصور: السقوف =====================
SELECT vt.scenario('سقف 4 للعضو: أربع صور تُقبل',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.fill_images(vt.f('c'), 4)$s$,
  $c$SELECT count(*) = 4 FROM car_images WHERE car_id = vt.f('c')$c$);
SELECT vt.scenario('سقف 5 للمعرض: خمس صور تُقبل',
  $s$SELECT vt.setfx('sr', vt.mk_showroom()); SELECT vt.setfx('c', vt.mk_scar(vt.f('sr'))); SELECT vt.fill_images(vt.f('c'), 5)$s$,
  $c$SELECT count(*) = 5 FROM car_images WHERE car_id = vt.f('c')$c$);
SELECT vt.viol('سقف 5 للمعرض: السادسة مرفوضة',
  $q$SELECT vt.setfx('sr', vt.mk_showroom()); SELECT vt.setfx('c', vt.mk_scar(vt.f('sr'))); SELECT vt.fill_images(vt.f('c'), 6)$q$, '23514', 'image limit (5)');
SELECT vt.viol('سقف ديناميكي: app_settings member=2 فالثالثة مرفوضة',
  format($q$UPDATE app_settings SET value = '{"member":2,"showroom":5}' WHERE key = 'images.max_per_car'; SELECT vt.fill_images(%s, 3)$q$, vt.f('mcar2')), '23514', 'image limit (2)');
SELECT vt.scenario('غياب إعداد السقف: الافتراضي 4 للعضو ما زال يُقبل',
  format($s$DELETE FROM app_settings WHERE key = 'images.max_per_car'; SELECT vt.fill_images(%s, 4)$s$, vt.f('mcar2')),
  format($c$SELECT count(*) = 4 FROM car_images WHERE car_id = %s$c$, vt.f('mcar2')));
SELECT vt.viol('غياب إعداد السقف: الخامسة مرفوضة بالافتراضي',
  format($q$DELETE FROM app_settings WHERE key = 'images.max_per_car'; SELECT vt.fill_images(%s, 5)$q$, vt.f('mcar2')), '23514', 'image limit (4)');

-- ===================== الصور: حالة الأصل وملكيته =====================
SELECT vt.viol('أصل pending لا يُرفق', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, vt.mk_asset(%s, 'car_image', 'pending'), 7, false)$q$, vt.f('scar'), vt.f('dealer')), '23514', 'ready car_image');
SELECT vt.viol('أصل rejected لا يُرفق', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, vt.mk_asset(%s, 'car_image', 'rejected'), 7, false)$q$, vt.f('scar'), vt.f('dealer')), '23514', 'ready car_image');
SELECT vt.viol('أصل من نوع showroom_cover لا يُرفق بسيارة', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, vt.mk_asset(%s, 'showroom_cover'), 7, false)$q$, vt.f('scar'), vt.f('dealer')), '23514', 'ready car_image');
SELECT vt.viol('أصل تاجر آخر على سيارة تاجر', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, '%s', 7, false)$q$, vt.f('scar'), vt.fu('asset_d2')), '42501', 'belongs to another user');
SELECT vt.viol('أصل تاجر على إعلان عضو', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, '%s', 7, false)$q$, vt.f('mcar'), vt.fu('asset_d')), '42501', 'belongs to another user');
SELECT vt.viol('أصل عضو آخر على إعلان عضو', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, vt.mk_asset(%s), 7, false)$q$, vt.f('mcar'), vt.f('member2')), '42501', 'belongs to another user');
SELECT vt.allow('أصل مملوك لمدير يُقبل على أي سيارة',
  format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, vt.mk_asset(vt.mk_user('admin')), 7, false)$q$, vt.f('scar')));
SELECT vt.viol('سيارة غير موجودة', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (999999999, '%s', 0, true)$q$, vt.fu('asset_d')), '23503', 'not found');

-- ===================== الصور: الرئيسية والترتيب =====================
SELECT vt.scenario('أول صورة رئيسية تلقائيًا والثانية لا',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.setfx('a', vt.mk_image(vt.f('c'))); SELECT vt.setfx('b', vt.mk_image(vt.f('c')))$s$,
  $c$SELECT (SELECT is_main FROM car_images WHERE id = vt.f('a')) AND NOT (SELECT is_main FROM car_images WHERE id = vt.f('b'))$c$);
SELECT vt.scenario('تبديل الرئيسية داخل معاملة واحدة يُقبل',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.setfx('a', vt.mk_image(vt.f('c'))); SELECT vt.setfx('b', vt.mk_image(vt.f('c')));
      UPDATE car_images SET is_main = false WHERE id = vt.f('a'); UPDATE car_images SET is_main = true WHERE id = vt.f('b'); SET CONSTRAINTS car_images_main_ck IMMEDIATE$s$,
  $c$SELECT (SELECT count(*) FROM car_images WHERE car_id = vt.f('c') AND is_main) = 1 AND (SELECT is_main FROM car_images WHERE id = vt.f('b'))$c$);
SELECT vt.viol('حذف الرئيسية وحدها (وتبقى صور) مرفوض عند الإتمام',
  $q$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.setfx('a', vt.mk_image(vt.f('c'))); SELECT vt.setfx('b', vt.mk_image(vt.f('c')));
      DELETE FROM car_images WHERE id = vt.f('a'); SET CONSTRAINTS car_images_main_ck IMMEDIATE$q$, '23514', 'no main image');
SELECT vt.scenario('حذف الرئيسية مع ترقية أخرى في المعاملة نفسها يُقبل',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.setfx('a', vt.mk_image(vt.f('c'))); SELECT vt.setfx('b', vt.mk_image(vt.f('c')));
      DELETE FROM car_images WHERE id = vt.f('a'); UPDATE car_images SET is_main = true WHERE id = vt.f('b'); SET CONSTRAINTS car_images_main_ck IMMEDIATE$s$,
  $c$SELECT (SELECT count(*) FROM car_images WHERE car_id = vt.f('c')) = 1$c$);
SELECT vt.scenario('حذف الصورة الوحيدة يُقبل (لا صور فلا رئيسية مطلوبة)',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.setfx('a', vt.mk_image(vt.f('c'))); DELETE FROM car_images WHERE id = vt.f('a'); SET CONSTRAINTS car_images_main_ck IMMEDIATE$s$,
  $c$SELECT NOT EXISTS (SELECT 1 FROM car_images WHERE car_id = vt.f('c'))$c$);
SELECT vt.scenario('حذف سيارة ذات ثلاث صور يحذف الصور بلا خطأ من القيد المؤجل',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.fill_images(vt.f('c'), 3); DELETE FROM cars WHERE id = vt.f('c'); SET CONSTRAINTS ALL IMMEDIATE$s$,
  $c$SELECT NOT EXISTS (SELECT 1 FROM car_images WHERE car_id = vt.f('c'))$c$);
SELECT vt.scenario('تبديل ترتيبين في جملة واحدة يُقبل (القيد مؤجل)',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('c', vt.mk_mcar(vt.f('u'))); SELECT vt.setfx('a', vt.mk_image(vt.f('c'))); SELECT vt.setfx('b', vt.mk_image(vt.f('c')));
      UPDATE car_images SET sort_order = CASE id WHEN vt.f('a') THEN 1 ELSE 0 END WHERE car_id = vt.f('c'); SET CONSTRAINTS car_images_order_uq IMMEDIATE$s$,
  $c$SELECT (SELECT sort_order FROM car_images WHERE id = vt.f('a')) = 1 AND (SELECT sort_order FROM car_images WHERE id = vt.f('b')) = 0$c$);

-- ===================== حماية المدير =====================
SELECT vt.viol('najaf_app لا ينشئ مديرًا', format($q$INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير اختبار', %L, 'admin', %L)$q$, vt.phone(), vt.hash()), '42501', 'admin accounts can only be created', 'najaf_app');
SELECT vt.viol('دور دخول عضو في najaf_app لا ينشئ مديرًا', format($q$INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير اختبار', %L, 'admin', %L)$q$, vt.phone(), vt.hash()), '42501', 'admin accounts can only be created', 'vt_app_login');
SELECT vt.allow('دور المشغّل غير المشرف (ليس عضوًا في najaf_app) ينشئ مديرًا', format($q$INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير مشغّل', %L, 'admin', %L)$q$, vt.phone(), vt.hash()), 'vt_ops');
SELECT vt.allow('المشرف الأعلى ينشئ مديرًا', format($q$INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير مشرف', %L, 'admin', %L)$q$, vt.phone(), vt.hash()));
SELECT vt.viol('آخر مدير: تغيير الدور ممنوع', $q$UPDATE users SET role = 'user' WHERE role = 'admin' AND status = 'active'$q$, '23514', 'last active admin');
SELECT vt.viol('آخر مدير: الحذف الناعم ممنوع', $q$UPDATE users SET deleted_at = now() WHERE role = 'admin' AND status = 'active'$q$, '23514', 'last active admin');
DO $d$
BEGIN
  IF vt.flag('admin_delete_guard') THEN
    PERFORM vt.viol('آخر مدير: DELETE ممنوع (حارس DELETE في النسخة المعدّلة)', $q$DELETE FROM users WHERE role = 'admin' AND status = 'active'$q$, '23514', 'last active admin');
  ELSE
    PERFORM vt.record('آخر مدير: DELETE ممنوع (حارس DELETE في النسخة المعدّلة)', true, 'SKIPPED: حارس DELETE غير موجود في هذه النسخة من المخطط');
  END IF;
END $d$;
SELECT vt.scenario('بوجود مدير ثانٍ يمكن تعطيل الأول',
  $s$SELECT vt.setfx('a2', vt.mk_user('admin')); UPDATE users SET status = 'suspended' WHERE id = 6$s$,
  $c$SELECT status = 'suspended' FROM users WHERE id = 6$c$);
SELECT vt.viol('najaf_app لا يغيّر الدور (صلاحية العمود)', format($q$UPDATE users SET role = 'admin' WHERE id = %s$q$, vt.f('member')), '42501', 'permission denied', 'najaf_app');

-- ===================== إلغاء الجلسات =====================
SELECT vt.scenario('إيقاف المستخدم يلغي كل جلساته الحيّة فقط (سببها user_suspended) ولا يمس غيره',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfx('o', vt.mk_user());
     SELECT vt.setfxu('s1', vt.mk_session(vt.f('u'))); SELECT vt.setfxu('s2', vt.mk_session(vt.f('u'))); SELECT vt.setfxu('so', vt.mk_session(vt.f('o')));
     SELECT vt.setfxu('old', vt.mk_session(vt.f('u')));
     UPDATE sessions SET revoked_at = now() - interval '1 hour', revoked_reason = 'logout' WHERE id = vt.fu('old');
     UPDATE users SET status = 'suspended' WHERE id = vt.f('u')$s$,
  $c$SELECT (SELECT count(*) FROM sessions WHERE user_id = vt.f('u') AND revoked_reason = 'user_suspended') = 2
        AND (SELECT revoked_reason FROM sessions WHERE id = vt.fu('old')) = 'logout'
        AND (SELECT revoked_at IS NULL FROM sessions WHERE id = vt.fu('so'))$c$);
SELECT vt.scenario('الحذف الناعم للمستخدم يلغي جلساته (user_deleted)',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfxu('s1', vt.mk_session(vt.f('u'))); UPDATE users SET deleted_at = now() WHERE id = vt.f('u')$s$,
  $c$SELECT revoked_reason = 'user_deleted' FROM sessions WHERE id = vt.fu('s1')$c$);
SELECT vt.scenario('تغيير كلمة المرور يلغي الجلسات (password_changed)',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfxu('s1', vt.mk_session(vt.f('u'))); UPDATE users SET password_hash = '$argon2id$v=19$m=19456,t=2,p=1$bmV3c2FsdA$bmV3aGFzaA' WHERE id = vt.f('u')$s$,
  $c$SELECT revoked_reason = 'password_changed' FROM sessions WHERE id = vt.fu('s1')$c$);
SELECT vt.scenario('تغيير الاسم وحده لا يلغي الجلسات',
  $s$SELECT vt.setfx('u', vt.mk_user()); SELECT vt.setfxu('s1', vt.mk_session(vt.f('u'))); UPDATE users SET name = 'اسم جديد' WHERE id = vt.f('u')$s$,
  $c$SELECT revoked_at IS NULL FROM sessions WHERE id = vt.fu('s1')$c$);

-- ===================== الإصدار التفاؤلي =====================
SELECT vt.scenario('كل UPDATE يزيد version، ولا يمكن فرضه من العميل',
  format($s$UPDATE cars SET price = price + 1 WHERE id = %s; UPDATE cars SET price = price + 1 WHERE id = %s; UPDATE cars SET version = 99 WHERE id = %s$s$, vt.f('scar'), vt.f('scar'), vt.f('scar')),
  format($c$SELECT version = 4 FROM cars WHERE id = %s$c$, vt.f('scar')));
SELECT vt.scenario('تحديث متقادم (WHERE version = قديم) لا يؤثر على أي صف (منع الكتابة الضائعة)',
  format($s$SELECT vt.setfx('v', (SELECT version FROM cars WHERE id = %s)); SELECT vt.setfx('n1', vt.rowcount(format('UPDATE cars SET price = price + 1 WHERE id = %%s AND version = %%s', %s, vt.f('v'))));
     SELECT vt.setfx('n2', vt.rowcount(format('UPDATE cars SET price = price + 1 WHERE id = %%s AND version = %%s', %s, vt.f('v'))))$s$, vt.f('scar'), vt.f('scar'), vt.f('scar')),
  $c$SELECT vt.f('n1') = 1 AND vt.f('n2') = 0$c$);
CREATE TABLE vt.vsnap (id bigint PRIMARY KEY, v integer, u timestamptz);
INSERT INTO vt.vsnap SELECT id, version, updated_at FROM cars WHERE id = (SELECT vt.f('mcar'));
SELECT pg_sleep(0.1);
UPDATE cars SET price = price + 1 WHERE id = (SELECT vt.f('mcar'));
SELECT vt.ok('updated_at يتقدم بين معاملتين ويزيد version بواحد',
  (SELECT c.updated_at > s.u AND c.version = s.v + 1 FROM cars c JOIN vt.vsnap s ON s.id = c.id), 'updated_at يساوي وقت بدء المعاملة (now())');

-- ===================== الظهور: مصفوفة شاملة =====================
CREATE FUNCTION vt.visibility_matrix() RETURNS text LANGUAGE plpgsql AS $$
DECLARE
  bad text := ''; n integer := 0; mst text; ost text; od boolean; cd boolean; own bigint; car bigint; ex boolean; got boolean;
  sst text; dst text; cst text; dd boolean; sh bigint;
BEGIN
  FOREACH mst IN ARRAY ARRAY['pending', 'active', 'sold', 'rejected', 'suspended'] LOOP
   FOREACH ost IN ARRAY ARRAY['active', 'suspended'] LOOP
    FOREACH od IN ARRAY ARRAY[false, true] LOOP
     FOREACH cd IN ARRAY ARRAY[false, true] LOOP
       own := vt.mk_user('user', ost);
       IF od THEN UPDATE users SET deleted_at = now() WHERE id = own; END IF;
       car := vt.mk_mcar(own, mst);
       IF cd THEN UPDATE cars SET deleted_at = now() WHERE id = car; END IF;
       ex := (mst = 'active' AND ost = 'active' AND NOT od AND NOT cd);
       got := EXISTS (SELECT 1 FROM public_cars WHERE id = car);
       n := n + 1;
       IF ex IS DISTINCT FROM got THEN bad := bad || format(' member(car=%s owner=%s ownerDeleted=%s carDeleted=%s exp=%s got=%s)', mst, ost, od, cd, ex, got); END IF;
     END LOOP; END LOOP; END LOOP; END LOOP;
  FOREACH sst IN ARRAY ARRAY['active', 'pending', 'suspended'] LOOP
   FOREACH dst IN ARRAY ARRAY['active', 'pending', 'suspended'] LOOP
    FOREACH dd IN ARRAY ARRAY[false, true] LOOP
     FOREACH cst IN ARRAY ARRAY['available', 'sold'] LOOP
      FOREACH cd IN ARRAY ARRAY[false, true] LOOP
       own := vt.mk_user('dealer', dst);
       sh := vt.mk_showroom(own, sst);
       IF dd THEN UPDATE users SET deleted_at = now() WHERE id = own; END IF;
       car := vt.mk_scar(sh, cst);
       IF cd THEN UPDATE cars SET deleted_at = now() WHERE id = car; END IF;
       ex := (sst = 'active' AND dst = 'active' AND NOT dd AND NOT cd);
       got := EXISTS (SELECT 1 FROM public_cars WHERE id = car);
       n := n + 1;
       IF ex IS DISTINCT FROM got THEN bad := bad || format(' showroom(showroom=%s dealer=%s dealerDeleted=%s car=%s carDeleted=%s exp=%s got=%s)', sst, dst, dd, cst, cd, ex, got); END IF;
       IF (EXISTS (SELECT 1 FROM public_showrooms WHERE id = sh)) IS DISTINCT FROM (sst = 'active' AND dst = 'active' AND NOT dd) THEN
         bad := bad || format(' showroomView(showroom=%s dealer=%s dealerDeleted=%s)', sst, dst, dd);
       END IF;
     END LOOP; END LOOP; END LOOP; END LOOP; END LOOP;
  RETURN n || ' combos' || bad;
END $$;

CREATE FUNCTION vt.run_visibility_matrix() RETURNS void LANGUAGE plpgsql AS $$
DECLARE r text;
BEGIN
  BEGIN
    r := vt.visibility_matrix();
    RAISE EXCEPTION 'rollback' USING ERRCODE = 'VT998';
  EXCEPTION WHEN SQLSTATE 'VT998' THEN NULL;
            WHEN OTHERS THEN GET STACKED DIAGNOSTICS r = MESSAGE_TEXT; r := 'ERROR: ' || r;
  END;
  PERFORM vt.record('مصفوفة الظهور: 112 تركيبة (حالات الإعلان/المعرض × حالة المالك × الحذف الناعم) تطابق القاعدة المستقلة', r = '112 combos', r);
END $$;
SELECT vt.run_visibility_matrix();

SELECT vt.scenario('المفضلة تبقى عند إخفاء المعرض (لا تُحذف) لكن السيارة تغيب عن العام',
  format($s$INSERT INTO favorites (user_id, car_id) VALUES (%s, %s); UPDATE showrooms SET status = 'suspended' WHERE id = %s$s$, vt.f('member2'), vt.f('scar'), vt.f('showroom')),
  format($c$SELECT EXISTS (SELECT 1 FROM favorites WHERE car_id = %s) AND NOT EXISTS (SELECT 1 FROM public_cars WHERE id = %s)$c$, vt.f('scar'), vt.f('scar')));
SELECT vt.scenario('إعادة تفعيل المعرض تُظهر سياراته من جديد',
  format($s$UPDATE showrooms SET status = 'suspended' WHERE id = %s$s$, vt.f('showroom')) || format($s$; UPDATE showrooms SET status = 'active' WHERE id = %s$s$, vt.f('showroom')),
  format($c$SELECT EXISTS (SELECT 1 FROM public_cars WHERE id = %s)$c$, vt.f('scar')));
SELECT vt.scenario('إيقاف حساب التاجر يخفي معرضه وسياراته، وإعادته تُظهرها',
  format($s$UPDATE users SET status = 'suspended' WHERE id = %s$s$, vt.f('dealer')),
  format($c$SELECT NOT EXISTS (SELECT 1 FROM public_showrooms WHERE id = %s) AND NOT EXISTS (SELECT 1 FROM public_cars WHERE id = %s)$c$, vt.f('showroom'), vt.f('scar')));

-- ===================== الدوال =====================
SELECT vt.scenario('to_iqd: بلا سعر صرف: USD ← NULL، IQD يبقى، عملة مجهولة ← NULL',
  $s$DELETE FROM exchange_rates$s$,
  $c$SELECT to_iqd(100, 'USD') IS NULL AND to_iqd(100, 'IQD') = 100 AND to_iqd(100, 'EUR') IS NULL AND current_usd_to_iqd() IS NULL$c$);
SELECT vt.scenario('to_iqd: يستعمل الأحدث valid_from، ويتجاهل المستقبلي، والتعادل بالأكبر id',
  $s$DELETE FROM exchange_rates;
     INSERT INTO exchange_rates (usd_to_iqd, kind, valid_from) VALUES (1300, 'manual', now() - interval '2 hours');
     INSERT INTO exchange_rates (usd_to_iqd, kind, valid_from) VALUES (1400, 'manual', now() - interval '1 hour');
     INSERT INTO exchange_rates (usd_to_iqd, kind, valid_from) VALUES (1500, 'manual', now() + interval '1 day')$s$,
  $c$SELECT to_iqd(100, 'USD') = 140000$c$);
SELECT vt.scenario('to_iqd: التعادل في valid_from يحسمه الأكبر id',
  $s$DELETE FROM exchange_rates; INSERT INTO exchange_rates (usd_to_iqd, kind, valid_from) VALUES (1300, 'manual', now() - interval '1 hour'), (1350, 'manual', now() - interval '1 hour')$s$,
  $c$SELECT current_usd_to_iqd() = 1350$c$);
SELECT vt.scenario('entitlements: بلا اشتراك = الخطة المجانية {}',
  format($s$SELECT 1$s$), format($c$SELECT entitlements_for_showroom(%s) = '{}'::jsonb$c$, vt.f('showroom')));
SELECT vt.scenario('entitlements: اشتراك فعّال ساري يعيد استحقاقات خطته',
  format($s$INSERT INTO subscription_plans (code, name, billing_interval, price, entitlements) VALUES ('pro', 'Pro', 'month', 10000, '{"max_active_cars":50}'); SELECT vt.mk_sub(%s, 'pro', 'active', 30)$s$, vt.f('showroom')),
  format($c$SELECT (entitlements_for_showroom(%s) ->> 'max_active_cars') = '50'$c$, vt.f('showroom')));
SELECT vt.scenario('entitlements: past_due وفترته سارية ما زال يعيد خطته',
  format($s$INSERT INTO subscription_plans (code, name, billing_interval, price, entitlements) VALUES ('pro', 'Pro', 'month', 10000, '{"max_active_cars":50}'); SELECT vt.mk_sub(%s, 'pro', 'past_due', 10)$s$, vt.f('showroom')),
  format($c$SELECT (entitlements_for_showroom(%s) ->> 'max_active_cars') = '50'$c$, vt.f('showroom')));
SELECT vt.scenario('entitlements: فترة منتهية (والحالة لم تُحدَّث بعد) ← المجانية',
  format($s$INSERT INTO subscription_plans (code, name, billing_interval, price, entitlements) VALUES ('pro', 'Pro', 'month', 10000, '{"max_active_cars":50}'); SELECT vt.mk_sub(%s, 'pro', 'active', -3)$s$, vt.f('showroom')),
  format($c$SELECT entitlements_for_showroom(%s) = '{}'::jsonb$c$, vt.f('showroom')));
SELECT vt.scenario('entitlements: اشتراك ملغى ← المجانية',
  format($s$INSERT INTO subscription_plans (code, name, billing_interval, price, entitlements) VALUES ('pro', 'Pro', 'month', 10000, '{"max_active_cars":50}'); SELECT vt.mk_sub(%s, 'pro', 'canceled', 30)$s$, vt.f('showroom')),
  format($c$SELECT entitlements_for_showroom(%s) = '{}'::jsonb$c$, vt.f('showroom')));

-- ===================== حارس غلاف المعرض (النسخة المعدّلة فقط) =====================
DO $d$
BEGIN
  IF vt.flag('cover_guard') THEN
    PERFORM vt.viol('غلاف المعرض: أصل pending مرفوض', format($q$UPDATE showrooms SET cover_asset_id = vt.mk_asset(%s, 'showroom_cover', 'pending') WHERE id = %s$q$, vt.f('dealer'), vt.f('showroom')), '23514', 'cover asset must be a ready showroom_cover');
    PERFORM vt.viol('غلاف المعرض: أصل من نوع car_image مرفوض', format($q$UPDATE showrooms SET cover_asset_id = vt.mk_asset(%s, 'car_image') WHERE id = %s$q$, vt.f('dealer'), vt.f('showroom')), '23514', 'cover asset must be a ready showroom_cover');
    PERFORM vt.viol('غلاف المعرض: أصل تاجر آخر مرفوض', format($q$UPDATE showrooms SET cover_asset_id = vt.mk_asset(%s, 'showroom_cover') WHERE id = %s$q$, vt.f('dealer2'), vt.f('showroom')), '42501', 'cover asset belongs to another user');
    PERFORM vt.allow('غلاف المعرض: أصل جاهز لمالك المعرض يُقبل', format($q$UPDATE showrooms SET cover_asset_id = vt.mk_asset(%s, 'showroom_cover') WHERE id = %s$q$, vt.f('dealer'), vt.f('showroom')));
    PERFORM vt.allow('غلاف المعرض: أصل جاهز لمدير يُقبل', format($q$UPDATE showrooms SET cover_asset_id = vt.mk_asset(vt.mk_user('admin'), 'showroom_cover') WHERE id = %s$q$, vt.f('showroom')));
  ELSE
    PERFORM vt.record('غلاف المعرض: حارس الغلاف (5 اختبارات)', true, 'SKIPPED: showrooms_cover_guard غير موجود في هذه النسخة من المخطط');
  END IF;
END $d$;

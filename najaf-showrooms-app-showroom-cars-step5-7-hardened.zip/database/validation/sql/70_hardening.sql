-- SUITE: hardening
-- EXPECT_MIN: 40
SELECT vt.suite('hardening');
-- يُشغَّل بعد تطبيق 0013.

SELECT vt.eq('najaf_app: مصفوفة الصلاحيات بعد 0013 — الفروق',
  (SELECT COALESCE(string_agg(r.rel || '.' || p.priv || '=' || has_table_privilege('najaf_app', quote_ident(r.rel), p.priv), ',' ORDER BY r.rel, p.priv), '')
     FROM vt.rels r CROSS JOIN vt.privs p WHERE has_table_privilege('najaf_app', quote_ident(r.rel), p.priv) <> vt.exp_app(r.rel, p.priv, 'post')), '');
SELECT vt.eq('cars: أعمدة UPDATE المسموحة بالضبط',
  (SELECT string_agg(column_name, ',' ORDER BY column_name COLLATE "C") FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'cars' AND has_column_privilege('najaf_app', 'cars', column_name, 'UPDATE')),
  'brand,color,currency,deleted_at,description,fuel_type,latitude,location,longitude,mileage,model,phone,price,rejection_reason,reviewed_at,reviewed_by,search_text,status,suspension_reason,transmission,whatsapp,year');
SELECT vt.eq('showrooms: أعمدة UPDATE المسموحة بالضبط',
  (SELECT string_agg(column_name, ',' ORDER BY column_name COLLATE "C") FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'showrooms' AND has_column_privilege('najaf_app', 'showrooms', column_name, 'UPDATE')),
  'address,cover_asset_id,description,latitude,longitude,name,phone,reviewed_at,reviewed_by,search_text,services,status,whatsapp,working_hours');
SELECT vt.eq('car_images: is_main وsort_order فقط',
  (SELECT string_agg(column_name, ',' ORDER BY column_name COLLATE "C") FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'car_images' AND has_column_privilege('najaf_app', 'car_images', column_name, 'UPDATE')),
  'is_main,sort_order');
SELECT vt.eq('favorites: لا أي عمود قابل للتحديث',
  (SELECT count(*)::text FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'favorites' AND has_column_privilege('najaf_app', 'favorites', column_name, 'UPDATE')), '0');
SELECT vt.ok('الأعمدة الحساسة محجوبة على cars',
  NOT (has_column_privilege('najaf_app', 'cars', 'id', 'UPDATE') OR has_column_privilege('najaf_app', 'cars', 'source_type', 'UPDATE')
    OR has_column_privilege('najaf_app', 'cars', 'showroom_id', 'UPDATE') OR has_column_privilege('najaf_app', 'cars', 'owner_id', 'UPDATE')
    OR has_column_privilege('najaf_app', 'cars', 'created_at', 'UPDATE') OR has_column_privilege('najaf_app', 'cars', 'updated_at', 'UPDATE')
    OR has_column_privilege('najaf_app', 'cars', 'version', 'UPDATE')));
SELECT vt.ok('دور الدخول العضو يرث التشديد: vt_app_login لا يعدّل cars.created_at',
  NOT has_column_privilege('vt_app_login', 'cars', 'created_at', 'UPDATE'));

-- ما صار مرفوضًا (كان مسموحًا في baseline قبل 0013)
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل cars.created_at', format($q$UPDATE cars SET created_at = created_at - interval '1 day' WHERE id = %s$q$, vt.f('scar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل cars.updated_at', format($q$UPDATE cars SET updated_at = now() WHERE id = %s$q$, vt.f('scar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل cars.version', format($q$UPDATE cars SET version = 100 WHERE id = %s$q$, vt.f('scar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل cars.id', format($q$UPDATE cars SET id = id WHERE id = %s$q$, vt.f('scar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل cars.source_type', format($q$UPDATE cars SET source_type = source_type WHERE id = %s$q$, vt.f('scar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا ينقل سيارة إلى معرض آخر (showroom_id)', format($q$UPDATE cars SET showroom_id = %s WHERE id = %s$q$, vt.f('showroom2'), vt.f('scar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا ينقل إعلانًا لمالك آخر (owner_id)', format($q$UPDATE cars SET owner_id = %s WHERE id = %s$q$, vt.f('member2'), vt.f('mcar')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا ينقل ملكية معرض (owner_id)', format($q$UPDATE showrooms SET owner_id = %s WHERE id = %s$q$, vt.f('dealer2'), vt.f('showroom')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل showrooms.created_at', format($q$UPDATE showrooms SET created_at = now() WHERE id = %s$q$, vt.f('showroom')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل showrooms.version', format($q$UPDATE showrooms SET version = 9 WHERE id = %s$q$, vt.f('showroom')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل showrooms.id', format($q$UPDATE showrooms SET id = id WHERE id = %s$q$, vt.f('showroom')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل car_images.car_id (صلاحية العمود قبل المشغّل)', format($q$UPDATE car_images SET car_id = %s WHERE id = %s$q$, vt.f('scar2'), vt.f('img_s')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يعدّل car_images.asset_id', format($q$UPDATE car_images SET asset_id = '%s' WHERE id = %s$q$, vt.fu('asset_d'), vt.f('img_s')), '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: najaf_app لا يحدّث favorites إطلاقًا', $q$UPDATE favorites SET user_id = user_id WHERE false$q$, '42501', 'permission denied', 'najaf_app');
SELECT vt.viol('بعد 0013: دور الدخول العضو لا يعدّل cars.created_at', format($q$UPDATE cars SET created_at = now() WHERE id = %s$q$, vt.f('scar')), '42501', 'permission denied', 'vt_app_login');

-- ما بقي مسموحًا (التطبيق يعمل)
SELECT vt.allow('بعد 0013: najaf_app يعدّل price وstatus على cars', format($q$UPDATE cars SET price = price + 1, status = 'sold' WHERE id = %s$q$, vt.f('scar')), 'najaf_app');
SELECT vt.allow('بعد 0013: najaf_app يحذف ناعمًا (deleted_at)', format($q$UPDATE cars SET deleted_at = now() WHERE id = %s$q$, vt.f('scar')), 'najaf_app');
SELECT vt.allow('بعد 0013: najaf_app يراجع إعلان عضو (status + reviewed_by + سبب)', format($q$UPDATE cars SET status = 'rejected', rejection_reason = 'صور غير واضحة', reviewed_by = %s, reviewed_at = now() WHERE id = %s$q$, vt.f('dealer'), vt.f('mcar')), 'najaf_app');
SELECT vt.allow('بعد 0013: najaf_app يوقف معرضًا (status)', format($q$UPDATE showrooms SET status = 'suspended' WHERE id = %s$q$, vt.f('showroom')), 'najaf_app');
SELECT vt.allow('بعد 0013: najaf_app يبدّل الصورة الرئيسية (is_main وsort_order)', format($q$UPDATE car_images SET is_main = is_main, sort_order = sort_order WHERE id = %s$q$, vt.f('img_s')), 'najaf_app');
SELECT vt.allow('بعد 0013: SELECT ... FOR UPDATE على cars يعمل بصلاحيات الأعمدة (يعتمد عليه حارس الصور)', format($q$SELECT id FROM cars WHERE id = %s FOR UPDATE$q$, vt.f('scar')), 'najaf_app');
SELECT vt.scenario('بعد 0013: المشغّل يحدّث version وupdated_at رغم غياب صلاحية العمودين',
  format($s$SET LOCAL ROLE najaf_app; UPDATE cars SET price = price + 1 WHERE id = %s; RESET ROLE$s$, vt.f('scar')),
  format($c$SELECT version = 2 FROM cars WHERE id = %s$c$, vt.f('scar')));

-- التدفقات الحقيقية مجددًا بعد التشديد
SELECT vt.app_flows('بعد 0013');

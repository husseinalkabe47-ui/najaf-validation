-- SUITE: intentional14
-- EXPECT_MIN: 14
SELECT vt.suite('intentional14');
-- العيوب الأربعة عشر نفسها التي حُقنت في التشغيل الجاف (dryrun_mapping.js)، بصيغة SQL حقيقية. كل واحد يجب أن يُرفض.
SELECT vt.viol('01 سيارة معرض بحالة active', format($q$UPDATE cars SET status = 'active' WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_status_by_source');
SELECT vt.viol('02 سنة 1900', format($q$UPDATE cars SET year = 1900 WHERE id = %s$q$, vt.f('scar')), '23514', 'cars_year_range');
SELECT vt.viol('03 هاتف مستخدم مكرر', format($q$UPDATE users SET phone_e164 = (SELECT phone_e164 FROM users WHERE id = %s) WHERE id = %s$q$, vt.f('member2'), vt.f('member')), '23505', 'users_phone_active_uq');
SELECT vt.viol('04 هاتف بصيغة محلية 07…', format($q$UPDATE users SET phone_e164 = '07701234567' WHERE id = %s$q$, vt.f('member')), '23514', 'e164_iq_format');
SELECT vt.viol('05 مالك معرض ليس تاجرًا', format($q$UPDATE showrooms SET owner_id = %s WHERE id = %s$q$, vt.f('member'), vt.f('showroom')), '23514', 'showroom owner must be a dealer');
SELECT vt.viol('06 معرضان لمالك واحد', format($q$INSERT INTO showrooms (owner_id, name) VALUES (%s, 'معرض ثانٍ لنفس التاجر')$q$, vt.f('dealer')), '23505', 'showrooms_owner_uq');
SELECT vt.viol('07 خمس صور لإعلان عضو (السقف 4)', format($q$SELECT vt.fill_images(%s, 5)$q$, vt.f('mcar2')), '23514', 'image limit');
SELECT vt.viol('08 سيارة لها صور بلا صورة رئيسية',
  format($q$SELECT vt.mk_image(%s, NULL, false); SET CONSTRAINTS car_images_main_ck IMMEDIATE$q$, vt.f('scar2')), '23514', 'no main image|has images but no main');
SELECT vt.viol('09 سيارة بمعرض غير موجود (FK)', $q$INSERT INTO cars (source_type, showroom_id, brand, model, year, price, status) VALUES ('showroom', 999999999, 'a', 'b', 2020, 1, 'available')$q$, '23503', 'cars_showroom_id_fkey');
SELECT vt.viol('10 إعلان عضو بمعرض', format($q$UPDATE cars SET showroom_id = %s WHERE id = %s$q$, vt.f('showroom'), vt.f('mcar')), '23514', 'cars_source_shape');
-- 11 لا انتهاك في SQL: «التسريب» يُمنع بالـview (معرض موقوف/معلّق لا يظهر ولا تظهر سياراته)
SELECT vt.ok('11 تسريب معرض موقوف/معلّق: لا يظهر هو ولا سياراته في العام',
  NOT EXISTS (SELECT 1 FROM public_showrooms WHERE id IN (3, 5)) AND NOT EXISTS (SELECT 1 FROM public_cars WHERE showroom_id IN (3, 5)));
SELECT vt.viol('12 مستخدم pending ليس تاجرًا', format($q$UPDATE users SET status = 'pending' WHERE id = %s$q$, vt.f('member')), '23514', 'users_pending_dealer');
SELECT vt.viol('13 تعطيل آخر مدير فعّال', $q$UPDATE users SET status = 'suspended' WHERE role = 'admin' AND status = 'active'$q$, '23514', 'last active admin');
SELECT vt.viol('14 أصل لمالك آخر على سيارة', format($q$INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES (%s, '%s', 5, false)$q$, vt.f('scar'), vt.fu('asset_d2')), '42501', 'belongs to another user');

\set ON_ERROR_STOP 1
-- قياس الاستعلامات النموذجية. كل استعلام: تسخين ثم N تشغيلات EXPLAIN (ANALYZE, BUFFERS)، الوسيط والأقصى، وكشف Seq Scan.
CREATE TABLE perf.params AS SELECT
  (SELECT showroom_id FROM cars WHERE showroom_id IS NOT NULL GROUP BY showroom_id ORDER BY count(*) DESC, showroom_id LIMIT 1) AS big_showroom,
  (SELECT owner_id FROM cars WHERE owner_id IS NOT NULL GROUP BY owner_id ORDER BY count(*) DESC, owner_id LIMIT 1) AS big_owner,
  (SELECT user_id FROM favorites GROUP BY user_id ORDER BY count(*) DESC, user_id LIMIT 1) AS fav_user,
  (SELECT id FROM cars WHERE id % 97 = 0 ORDER BY id LIMIT 1) AS some_car,
  (SELECT created_at FROM public_cars ORDER BY created_at DESC, id DESC OFFSET 1000 LIMIT 1) AS page_ts,
  (SELECT id FROM public_cars ORDER BY created_at DESC, id DESC OFFSET 1000 LIMIT 1) AS page_id,
  (SELECT encode(token_hash, 'hex') FROM sessions ORDER BY created_at, id LIMIT 1) AS tok_hex,
  (SELECT phone_e164 FROM users WHERE role = 'user' ORDER BY id LIMIT 1) AS a_phone;

CREATE TABLE perf.results (id serial PRIMARY KEY, name text, kind text, runs integer, median_ms numeric, max_ms numeric, rows_out bigint,
                           shared_hit bigint, shared_read bigint, seq_scans text, sql text);
CREATE FUNCTION perf.expand(p_sql text) RETURNS text LANGUAGE plpgsql AS $$
DECLARE j jsonb; k text; v text; r text := p_sql;
BEGIN
  SELECT to_jsonb(p) INTO j FROM perf.params p;
  FOR k, v IN SELECT key, value #>> '{}' FROM jsonb_each(j) LOOP r := replace(r, '{' || k || '}', v); END LOOP;
  RETURN r;
END $$;
CREATE FUNCTION perf.run(p_name text, p_kind text, p_template text, p_runs integer DEFAULT 7) RETURNS void LANGUAGE plpgsql AS $$
DECLARE q text := perf.expand(p_template); j json; plan jsonb; t numeric[] := '{}'; i integer; seqs text; med numeric;
BEGIN
  EXECUTE 'EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ' || q INTO j;                -- تسخين (يُهمل)
  FOR i IN 1..p_runs LOOP
    EXECUTE 'EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ' || q INTO j;
    plan := j::jsonb; t := t || ((plan -> 0 ->> 'Execution Time')::numeric);
  END LOOP;
  SELECT string_agg(DISTINCT n ->> 'Relation Name', ',') INTO seqs FROM jsonb_path_query(plan, 'lax $.**') n WHERE jsonb_typeof(n) = 'object' AND n ->> 'Node Type' = 'Seq Scan';
  SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY x) INTO med FROM unnest(t) x;
  INSERT INTO perf.results (name, kind, runs, median_ms, max_ms, rows_out, shared_hit, shared_read, seq_scans, sql)
  VALUES (p_name, p_kind, p_runs, round(med, 3), round((SELECT max(x) FROM unnest(t) x), 3), (plan -> 0 -> 'Plan' ->> 'Actual Rows')::bigint,
          (plan -> 0 -> 'Plan' ->> 'Shared Hit Blocks')::bigint, (plan -> 0 -> 'Plan' ->> 'Shared Read Blocks')::bigint, seqs, q);
END $$;

SELECT perf.run('Q01 الأحدث: الصفحة الأولى (view)', 'oltp', $q$SELECT id, brand, model, year, price, currency, created_at FROM public_cars ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q02 الأحدث: صفحة تالية بمؤشر keyset (view)', 'oltp', $q$SELECT id, brand, model, year, price, currency, created_at FROM public_cars WHERE (created_at, id) < ('{page_ts}'::timestamptz, {page_id}) ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q03 سلسلة الفلاتر: ماركة+موديل+سنة (view)', 'oltp', $q$SELECT id, brand, model, year, price, currency FROM public_cars WHERE brand = 'Toyota' AND model = 'Camry' AND year BETWEEN 2012 AND 2020 ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q04 نطاق السعر بـ to_iqd على الـview', 'oltp', $q$SELECT id, brand, model, price, currency FROM public_cars WHERE to_iqd(price, currency) BETWEEN 10000000 AND 30000000 ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q04b نطاق السعر بإعادة صياغة صديقة للفهرس (view)', 'oltp', $q$SELECT id, brand, model, price, currency FROM public_cars WHERE (currency = 'IQD' AND price BETWEEN 10000000 AND 30000000) OR (currency = 'USD' AND price BETWEEN 10000000 / 1300.0 AND 30000000 / 1300.0) ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q05 بحث نصي ILIKE على الـview (security_barrier)', 'oltp', $q$SELECT id, brand, model, price FROM public_cars WHERE search_text ILIKE '%camry%' ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q05b بحث نصي ILIKE على الجداول مباشرة (بلا view)', 'oltp',
  $q$SELECT c.id, c.brand, c.model, c.price FROM cars c LEFT JOIN showrooms s ON s.id = c.showroom_id LEFT JOIN users sd ON sd.id = s.owner_id LEFT JOIN users uo ON uo.id = c.owner_id
      WHERE c.deleted_at IS NULL AND c.search_text ILIKE '%camry%'
        AND ((c.source_type = 'showroom' AND s.status = 'active' AND sd.status = 'active' AND sd.deleted_at IS NULL)
          OR (c.source_type = 'member' AND c.status = 'active' AND uo.status = 'active' AND uo.deleted_at IS NULL))
      ORDER BY c.created_at DESC, c.id DESC LIMIT 20$q$);
SELECT perf.run('Q06 سيارات معرض (view)', 'oltp', $q$SELECT id, brand, model, price FROM public_cars WHERE showroom_id = {big_showroom} ORDER BY created_at DESC, id DESC LIMIT 20$q$);
SELECT perf.run('Q07 إعلاناتي (جدول، بما فيها غير العامة)', 'oltp', $q$SELECT id, brand, model, status, created_at FROM cars WHERE owner_id = {big_owner} AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 50$q$);
SELECT perf.run('Q08 طابور مراجعة الإعلانات pending', 'oltp', $q$SELECT id, created_at FROM cars WHERE source_type = 'member' AND status = 'pending' AND deleted_at IS NULL ORDER BY created_at LIMIT 50$q$);
SELECT perf.run('Q09 المعارض العامة', 'oltp', $q$SELECT id, name, address FROM public_showrooms ORDER BY created_at DESC, id DESC LIMIT 50$q$);
SELECT perf.run('Q09b بحث المعارض ILIKE', 'oltp', $q$SELECT id, name FROM public_showrooms WHERE search_text ILIKE '%معرض 1%' LIMIT 50$q$);
SELECT perf.run('Q10 مفضلة مستخدم كثير المفضلة', 'oltp', $q$SELECT p.id, p.brand, p.model, p.price FROM favorites f JOIN public_cars p ON p.id = f.car_id WHERE f.user_id = {fav_user} ORDER BY f.created_at DESC LIMIT 100$q$);
SELECT perf.run('Q11 قوائم الفلاتر الديناميكية: ماركة/موديل (تجميع على الـview)', 'agg', $q$SELECT brand, model, count(*) FROM public_cars GROUP BY brand, model$q$);
SELECT perf.run('Q12 عدّ السيارات العامة', 'agg', $q$SELECT count(*) FROM public_cars$q$);
SELECT perf.run('Q13 لوحة المدير: السيارات حسب المصدر والحالة', 'agg', $q$SELECT source_type, status, count(*) FROM cars WHERE deleted_at IS NULL GROUP BY 1, 2$q$);
SELECT perf.run('Q14 تفاصيل سيارة مع صورها', 'oltp', $q$SELECT p.*, (SELECT json_agg(json_build_object('id', i.id, 'key', a.storage_key, 'main', i.is_main) ORDER BY i.sort_order) FROM car_images i JOIN assets a ON a.id = i.asset_id WHERE i.car_id = p.id) AS imgs FROM public_cars p WHERE p.id = {some_car}$q$);
SELECT perf.run('Q15 الدخول: مستخدم بالهاتف', 'oltp', $q$SELECT id, password_hash, status FROM users WHERE phone_e164 = '{a_phone}' AND deleted_at IS NULL$q$);
SELECT perf.run('Q16 الجلسة: بحث بتجزئة الرمز', 'oltp', $q$SELECT id, user_id, expires_at FROM sessions WHERE token_hash = decode('{tok_hex}', 'hex') AND revoked_at IS NULL$q$);
SELECT perf.run('Q17 تنظيف الأصول غير المرفقة', 'oltp', $q$SELECT id FROM assets WHERE status IN ('pending', 'rejected') AND created_at < now() - interval '24 hours' LIMIT 1000$q$);
SELECT perf.run('Q18 تاريخ كيان في التدقيق', 'oltp', $q$SELECT id, action, occurred_at FROM audit_logs WHERE entity_type = 'cars' AND entity_id = '123' ORDER BY occurred_at DESC LIMIT 50$q$);
SELECT perf.run('Q19 حد معدّل الرموز للرقم', 'oltp', $q$SELECT count(*) FROM verification_codes WHERE target_phone = '{a_phone}' AND created_at > now() - interval '1 hour'$q$);
SELECT perf.run('Q20 ميزانية الرسائل اليومية (SMS)', 'oltp', $q$SELECT count(*), sum(cost_micros) FROM message_deliveries WHERE channel = 'sms' AND created_at > now() - interval '1 day'$q$);

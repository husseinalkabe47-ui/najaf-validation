\pset format aligned
\echo '=== أحجام ==='
SELECT relname, pg_size_pretty(pg_total_relation_size(c.oid)) AS total, pg_size_pretty(pg_relation_size(c.oid)) AS heap, c.reltuples::bigint AS approx_rows
  FROM pg_class c WHERE c.relnamespace = 'public'::regnamespace AND c.relkind = 'r' ORDER BY pg_total_relation_size(c.oid) DESC LIMIT 8;
\echo '=== مراحل التوليد (ثوانٍ بين العلامات) ==='
SELECT m.step, round(extract(epoch FROM m.at - lag(m.at) OVER (ORDER BY m.id))::numeric, 1) AS seconds FROM perf.marks m ORDER BY m.id;
\echo '=== سلامة البيانات المولَّدة (المتوقع 0 في كل صف) ==='
SELECT * FROM perf.checks;
\echo '=== نتائج الاستعلامات ==='
SELECT name, kind, median_ms, max_ms, rows_out, shared_hit, shared_read, COALESCE(seq_scans, '-') AS seq_scans FROM perf.results ORDER BY id;

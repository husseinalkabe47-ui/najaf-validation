\set cid random(1, :ncars)
\set off random(0, 5000)
SELECT id, brand, model, price FROM public_cars ORDER BY created_at DESC, id DESC OFFSET :off LIMIT 20;
SELECT * FROM public_cars WHERE id = :cid;
SELECT count(*) FROM favorites WHERE car_id = :cid;

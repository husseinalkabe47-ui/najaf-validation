-- دوال تجهيز لاختبارات التزامن (تُنفَّذ بالمشرف وتُثبَّت فورًا؛ كل منها يعيد المعرّفات نصًا مفصولًا بمسافات)
CREATE FUNCTION vt.conc_car(p_kind text, p_assets integer) RETURNS text LANGUAGE plpgsql AS $$
DECLARE own bigint; c bigint; a uuid[] := '{}'; sr bigint;
BEGIN
  IF p_kind = 'member' THEN own := vt.mk_user(); c := vt.mk_mcar(own);
  ELSE own := vt.mk_user('dealer'); sr := vt.mk_showroom(own); c := vt.mk_scar(sr); END IF;
  PERFORM vt.mk_image(c);                                  -- الصورة الأولى الرئيسية
  FOR i IN 1..p_assets LOOP a := a || vt.mk_asset(own); END LOOP;
  RETURN c || ' ' || array_to_string(a, ' ');
END $$;

CREATE FUNCTION vt.conc_swap() RETURNS text LANGUAGE plpgsql AS $$
DECLARE own bigint := vt.mk_user(); c bigint; ia bigint; ib bigint; ic bigint;
BEGIN
  c := vt.mk_mcar(own); ia := vt.mk_image(c); ib := vt.mk_image(c); ic := vt.mk_image(c);
  RETURN c || ' ' || ia || ' ' || ib || ' ' || ic;
END $$;

CREATE FUNCTION vt.conc_version() RETURNS text LANGUAGE plpgsql AS $$
DECLARE c bigint := vt.mk_scar(vt.mk_showroom()); v integer; p numeric;
BEGIN
  SELECT version, price INTO v, p FROM cars WHERE id = c;
  RETURN c || ' ' || v || ' ' || p;
END $$;

-- مديران فعّالان فقط (يُوقَف سواهما) لاختبار «آخر مدير»
CREATE FUNCTION vt.conc_admins() RETURNS text LANGUAGE plpgsql AS $$
DECLARE a bigint := vt.mk_user('admin'); b bigint := vt.mk_user('admin');
BEGIN
  UPDATE users SET status = 'suspended' WHERE role = 'admin' AND status = 'active' AND id NOT IN (a, b);
  RETURN a || ' ' || b;
END $$;

#!/usr/bin/env bash
# usage: run_concurrency.sh DBNAME OUTDIR   (يستعمل متغيرات PG* من البيئة)
# كل اختبار يطلق N عميل psql حقيقي؛ حاجز = قفل استشاري حصري يمسكه منسّق، فيبدأ الكل معًا عند تحريره.
set -u
DB="$1"; OUT="$2"; HERE="$(cd "$(dirname "$0")" && pwd)"; mkdir -p "$OUT"
P=(psql -X -q -At -d "$DB" -v ON_ERROR_STOP=1)
"${P[@]}" -f "$HERE/00_conc.sql" >/dev/null 2>"$OUT/conc_setup.err" || { echo "تعذّر تحميل دوال التزامن (انظر $OUT/conc_setup.err)"; exit 2; }
rec() { "${P[@]}" -v n="$1" -v ok="$2" -v d="$3" -f - <<'SQL' >/dev/null
SELECT vt.suite('concurrency'); SELECT vt.record(:'n', :'ok'::boolean, :'d');
SQL
}
sql1() { "${P[@]}" -c "$1"; }
# barrier_run NAME N SQL_TEMPLATE_FUNCTION  — يستدعي دالة bash باسم $3 لتعطي جملة كل عميل i
barrier_run() {
  local name="$1" n="$2" gen="$3" i
  rm -f "$OUT/$name".*
  ( "${P[@]}" -c "SELECT pg_advisory_lock(777)" -c "SELECT pg_sleep(${BARRIER_SECONDS:-3})" >/dev/null 2>&1 ) &
  local coord=$!
  sleep 0.4
  for ((i=1;i<=n;i++)); do
    local stmt; stmt="$($gen "$i")"
    ( "${P[@]}" -c "SELECT pg_advisory_lock_shared(777)" -c "BEGIN" -c "$stmt" -c "COMMIT" >"$OUT/$name.$i.out" 2>"$OUT/$name.$i.err"; echo $? >"$OUT/$name.$i.rc" ) &
  done
  wait "$coord" 2>/dev/null; wait
}
count_ok()   { local name="$1" n="$2" c=0 i; for ((i=1;i<=n;i++)); do [ "$(cat "$OUT/$name.$i.rc" 2>/dev/null)" = "0" ] && c=$((c+1)); done; echo $c; }
count_err()  { local name="$1" n="$2" pat="$3" c=0 i; for ((i=1;i<=n;i++)); do grep -qi -- "$pat" "$OUT/$name.$i.err" 2>/dev/null && c=$((c+1)); done; echo $c; }

# ---------- 1) سقف صور العضو (4) تحت 11 إدراجًا متزامنًا: الموجودة 1 (رئيسية) ← يُقبل 3 فقط ----------
read -r CAR ASSETS <<<"$(sql1 "SELECT vt.conc_car('member', 11)")"
A=($ASSETS)
gen_cap() { echo "INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES ($CAR, '${A[$(($1-1))]}', $((100+$1)), false)"; }
barrier_run cap_member 11 gen_cap
OKN=$(count_ok cap_member 11); LIM=$(count_err cap_member 11 "image limit"); FINAL=$(sql1 "SELECT count(*) FROM car_images WHERE car_id=$CAR")
[ "$OKN" = "3" ] && [ "$LIM" = "8" ] && [ "$FINAL" = "4" ] && R=true || R=false
rec "تزامن: سقف صور العضو (4) تحت 11 إدراجًا متزامنًا: نجح 3 وفشل 8 والنهائي 4" "$R" "نجح=$OKN رُفض بسبب السقف=$LIM العدد النهائي=$FINAL (المتوقع 3/8/4)"

# ---------- 2) سقف صور المعرض (5) تحت 12 إدراجًا: الموجودة 1 ← يُقبل 4 ----------
read -r CAR ASSETS <<<"$(sql1 "SELECT vt.conc_car('showroom', 12)")"
A=($ASSETS)
barrier_run cap_showroom 12 gen_cap
OKN=$(count_ok cap_showroom 12); LIM=$(count_err cap_showroom 12 "image limit"); FINAL=$(sql1 "SELECT count(*) FROM car_images WHERE car_id=$CAR")
[ "$OKN" = "4" ] && [ "$LIM" = "8" ] && [ "$FINAL" = "5" ] && R=true || R=false
rec "تزامن: سقف صور المعرض (5) تحت 12 إدراجًا متزامنًا: نجح 4 وفشل 8 والنهائي 5" "$R" "نجح=$OKN رُفض=$LIM النهائي=$FINAL (المتوقع 4/8/5)"

# ---------- 3) سباق تبديل الصورة الرئيسية (10 جولات): واحد ينجح وواحد يفشل 23505، ورئيسية واحدة دائمًا ----------
BAD=0; DETAIL=""
for r in $(seq 1 10); do
  read -r CAR IA IB IC <<<"$(sql1 "SELECT vt.conc_swap()")"
  gen_swap() { if [ "$1" = "1" ]; then echo "UPDATE car_images SET is_main=false WHERE id=$IA; UPDATE car_images SET is_main=true WHERE id=$IB; SET CONSTRAINTS car_images_main_ck IMMEDIATE"; else echo "UPDATE car_images SET is_main=false WHERE id=$IA; UPDATE car_images SET is_main=true WHERE id=$IC; SET CONSTRAINTS car_images_main_ck IMMEDIATE"; fi; }
  barrier_run swap 2 gen_swap
  OKN=$(count_ok swap 2); DUP=$(count_err swap 2 "car_images_one_main_uq"); MAINS=$(sql1 "SELECT count(*) FROM car_images WHERE car_id=$CAR AND is_main")
  if ! { [ "$OKN" = "1" ] && [ "$MAINS" = "1" ]; }; then BAD=$((BAD+1)); DETAIL="$DETAIL جولة$r:نجح=$OKN رئيسية=$MAINS خطأ_فريد=$DUP;"; fi
done
[ "$BAD" = "0" ] && R=true || R=false
rec "تزامن: تبديل الرئيسية المتسابق (10 جولات): دائمًا ناجح واحد ورئيسية واحدة" "$R" "جولات فاشلة=$BAD $DETAIL"

# ---------- 4) التحكم التفاؤلي: 20 عميلًا يحدّثون بنفس version القديم: يكسب واحد فقط (لا كتابة ضائعة) ----------
read -r CAR V0 P0 <<<"$(sql1 "SELECT vt.conc_version()")"
gen_ver() { echo "UPDATE cars SET price = price + 1 WHERE id = $CAR AND version = $V0 RETURNING id"; }
barrier_run version 20 gen_ver
WON=0; for i in $(seq 1 20); do grep -q "^$CAR\$" "$OUT/version.$i.out" 2>/dev/null && WON=$((WON+1)); done
FINALV=$(sql1 "SELECT version FROM cars WHERE id=$CAR"); FINALP=$(sql1 "SELECT price FROM cars WHERE id=$CAR")
EXPP=$(sql1 "SELECT $P0 + 1")
[ "$WON" = "1" ] && [ "$FINALV" = "$((V0+1))" ] && [ "$FINALP" = "$EXPP" ] && R=true || R=false
rec "تزامن: 20 تحديثًا بنفس version: واحد يكسب والباقي 0 صف (لا كتابة ضائعة)" "$R" "رابحون=$WON version النهائي=$FINALV (متوقع $((V0+1))) price=$FINALP (متوقع $EXPP)"

# ---------- 5) تسجيل نفس الهاتف 10 مرات متزامنة: واحد ينجح ----------
PH=$(sql1 "SELECT vt.phone()")
gen_reg() { echo "INSERT INTO users (name, phone_e164, password_hash) VALUES ('مستخدم متزامن $1', '$PH', vt.hash())"; }
barrier_run reg 10 gen_reg
OKN=$(count_ok reg 10); DUP=$(count_err reg 10 "users_phone_active_uq"); CNT=$(sql1 "SELECT count(*) FROM users WHERE phone_e164='$PH'")
[ "$OKN" = "1" ] && [ "$DUP" = "9" ] && [ "$CNT" = "1" ] && R=true || R=false
rec "تزامن: تسجيل نفس الهاتف 10 مرات: ينجح واحد ويفشل 9 بـ users_phone_active_uq" "$R" "نجح=$OKN مكرر=$DUP عدد الصفوف=$CNT"

# ---------- 6) آخر مدير: مديران فعّالان يُوقَف كلٌّ منهما من جلسة مختلفة في اللحظة نفسها (10 جولات) ----------
HAS_LOCK=$("${P[@]}" -c "SELECT vt.flag('admin_delete_guard')")
BOTH=0; NONE=0; ONE=0
for r in $(seq 1 10); do
  read -r AA BB <<<"$(sql1 "SELECT vt.conc_admins()")"
  gen_adm() { if [ "$1" = "1" ]; then echo "UPDATE users SET status='suspended' WHERE id=$AA"; else echo "UPDATE users SET status='suspended' WHERE id=$BB"; fi; }
  barrier_run admin 2 gen_adm
  OKN=$(count_ok admin 2)
  case "$OKN" in 2) BOTH=$((BOTH+1));; 0) NONE=$((NONE+1));; *) ONE=$((ONE+1));; esac
  sql1 "UPDATE users SET status='active' WHERE id IN ($AA,$BB)" >/dev/null 2>&1
done
if [ "$HAS_LOCK" = "t" ]; then
  [ "$BOTH" = "0" ] && [ "$ONE" = "10" ] && R=true || R=false
  rec "تزامن: آخر مدير (قفل استشاري): 10 جولات لا يمرّ فيها الإيقافان معًا أبدًا" "$R" "نجح واحد=$ONE نجح الاثنان=$BOTH فشل الاثنان=$NONE (المتوقع 10/0/0)"
else
  rec "تزامن: آخر مدير (النسخة المُسلَّمة بلا قفل): معلومة — كم مرة مرّ الإيقافان معًا؟" true "INFO نجح الاثنان في $BOTH من 10 جولات؛ نجح واحد في $ONE (إن كان BOTH>0 فالسباق حقيقي وتوصي المراجعة بقفل استشاري كما في النسخة المعدّلة)"
fi
sql1 "UPDATE users SET status='active' WHERE id = 6" >/dev/null 2>&1   # إعادة المدير التجريبي بعد اختبار «آخر مدير»
echo "concurrency done"

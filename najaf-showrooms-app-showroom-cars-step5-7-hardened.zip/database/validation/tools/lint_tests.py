#!/usr/bin/env python3
"""فاحص ثابت لملفات اختبار SQL (لا يشغّل PostgreSQL). الاستعمال: lint_tests.py SCHEMA.sql sql_dir [migration0013.sql]"""
import re,sys,glob,os,collections
schema=open(sys.argv[1],encoding='utf-8').read(); sqldir=sys.argv[2]
extra=open(sys.argv[3],encoding='utf-8').read() if len(sys.argv)>3 else ''
S=re.sub(r'--[^\n]*','',schema)
def top_split(body):
    parts=[];d=0;cur='';sq=False
    for ch in body:
        if ch=="'": sq=not sq
        if not sq:
            if ch=='(': d+=1
            elif ch==')': d-=1
            elif ch==',' and d==0: parts.append(cur.strip()); cur=''; continue
        cur+=ch
    if cur.strip(): parts.append(cur.strip())
    return parts
tables={}
for m in re.finditer(r'CREATE TABLE (\w+)\s*\((.*?)\n\);',S,re.S):
    cols=set()
    for it in top_split(m.group(2)):
        f=it.split()[0]
        if f.upper() not in ('CONSTRAINT','UNIQUE','PRIMARY','CHECK'): cols.add(f)
    tables[m.group(1)]=cols
views={'public_cars','public_showrooms'}
cn=set(re.findall(r'CONSTRAINT\s+(\w+)\s+(?:CHECK|UNIQUE)',S))|set(re.findall(r'CREATE\s+(?:UNIQUE\s+)?INDEX\s+(\w+)\s+ON',S))
fk_auto=set()
for t,cols in tables.items():
    for c in cols: fk_auto.add(f'{t}_{c}_fkey'); fk_auto.add(f'{t}_{c}_key')
known=cn|fk_auto|{'e164_iq_format','e164_any_format'}
errors=[];warns=[];used=set();defined=set(); stats={}

def count_results(t, flows=None):
    """(أدنى، أقصى) لعدد نتائج vt.record التي يسجّلها الملف عند تنفيذه: كل SELECT vt.{viol|allow|scenario|ok|eq|run_visibility_matrix}
    على المستوى الأعلى = 1؛ SELECT vt.app_flows = عدد PERFORM vt.scenario في تعريفها؛ كتلة DO بـIF..THEN..ELSE = أدنى/أقصى الفرعين."""
    mn=mx=0
    for st in statements(t):
        s_=st.strip()
        if re.match(r'SELECT vt\.(viol|allow|scenario|ok|eq|run_visibility_matrix)\(',s_): mn+=1; mx+=1
        elif re.match(r'SELECT vt\.app_flows\(',s_): mn+=FLOWS[0]; mx+=FLOWS[0]
        elif s_.upper().startswith('DO ') and 'PERFORM vt.' in s_:
            m2=re.search(r'IF\s+.*?THEN(.*?)ELSE(.*?)END IF',s_,re.S|re.I)
            pat=r'PERFORM vt\.(?:viol|allow|scenario|ok|eq|record)\('
            if m2:
                x=len(re.findall(pat,m2.group(1))); y=len(re.findall(pat,m2.group(2))); mn+=min(x,y); mx+=max(x,y)
            else:
                k=len(re.findall(pat,s_)); mn+=k; mx+=k
    return mn,mx
FLOWS=[0]


def scan(t):
    """يعيد قائمة (نوع، بداية، نهاية) للقطع: 'code' أو 'str' أو 'dollar' أو 'comment' — يحاكي مُحلِّل psql."""
    out=[];i=0;n=len(t);start=0
    def push(kind,a,b): out.append((kind,a,b))
    while i<n:
        c=t[i]
        if t.startswith('--',i):
            j=t.find('\n',i); j=n if j<0 else j; push('code',start,i); push('comment',i,j); i=j; start=i; continue
        if c=="'":
            j=i+1
            while j<n:
                if t[j]=="'":
                    if j+1<n and t[j+1]=="'": j+=2; continue
                    break
                j+=1
            if j>=n: raise ValueError(f"اقتباس مفرد غير مغلق (سطر {t.count(chr(10),0,i)+1})")
            push('code',start,i); push('str',i,j+1); i=j+1; start=i; continue
        if c=='$' and (i==0 or not (t[i-1].isalnum() or t[i-1]=='_')):
            m=re.match(r'\$([A-Za-z_]\w*)?\$',t[i:])
            if m:
                tag=m.group(0); j=t.find(tag,i+len(tag))
                if j<0: raise ValueError(f"اقتباس دولاري {tag} غير مغلق (سطر {t.count(chr(10),0,i)+1})")
                push('code',start,i); push('dollar',i,j+len(tag)); i=j+len(tag); start=i; continue
        i+=1
    push('code',start,n); return out
def statements(t):
    segs=scan(t); stmts=[];cur=''
    for kind,a,b in segs:
        if kind=='comment': continue
        if kind in ('str','dollar'): cur+=t[a:b]; continue
        for ch in t[a:b]:
            if ch==';': stmts.append(cur.strip()); cur=''
            else: cur+=ch
    if cur.strip(): stmts.append(cur.strip())
    return [x for x in stmts if x]
ALLOWED=('SELECT','DO','CREATE','INSERT','UPDATE','DELETE','GRANT','DROP','SET','REVOKE','ALTER','\\','COMMENT','WITH','BEGIN','COMMIT','RESET','ANALYZE','VACUUM','SHOW','EXPLAIN','TRUNCATE','PERFORM')
def call_args(t,start):
    """وسائط استدعاء يبدأ عند فتحة القوس t[start]=='(' : قائمة نصوص الوسائط"""
    segs=scan(t); depth=0;args=[];cur='';i=start
    # نمشي على القطع بدءًا من start
    for kind,a,b in segs:
        if b<=start: continue
        a=max(a,start)
        if kind in('str','dollar'): cur+=t[a:b]; continue
        if kind=='comment': continue
        for ch in t[a:b]:
            if ch=='(':
                depth+=1
                if depth==1: continue
            elif ch==')':
                depth-=1
                if depth==0: args.append(cur.strip()); return args
            elif ch==',' and depth==1: args.append(cur.strip()); cur=''; continue
            cur+=ch
    return args

def strip_sql_strings(x): return re.sub(r"'(?:[^']|'')*'","''",x)
files=sorted(glob.glob(os.path.join(sqldir,'*.sql')))
for _f in files:
    _t=open(_f,encoding='utf-8').read(); _m=re.search(r'CREATE FUNCTION vt\.app_flows.*?END \$\$;',_t,re.S)
    if _m: FLOWS[0]=len(re.findall(r'PERFORM vt\.scenario\(',_m.group(0)))
alltext={}
for f in files:
    t=open(f,encoding='utf-8').read(); alltext[f]=t; b=os.path.basename(f)
    try:
        for kind,a_,b_ in scan(t):
            if kind=='dollar':
                rest=t[b_:].lstrip()
                nxt=rest[:1]
                if rest and nxt not in (',',')',';') and not rest.upper().startswith('LANGUAGE'):
                    errors.append(f"{b}: بعد اقتباس دولاري (سطر {t.count(chr(10),0,a_)+1}) يأتي نص ملتصق {rest[:25]!r} (وسم إغلاق مفقود/مُزاح غالبًا)")
        sts=statements(t)
        for st in sts:
            first=re.split(r'\s+',st.lstrip('(').strip(),1)[0].upper()
            if not first.startswith(ALLOWED): errors.append(f"{b}: جملة تبدأ بنص غير مألوف (اقتران اقتباس مُزاح غالبًا): {st[:70]!r}")
    except ValueError as e:
        errors.append(f'{b}: {e}')
    for m in re.finditer(r'vt\.viol\(',t):
        try: args=call_args(t,m.end()-1)
        except ValueError: continue
        if len(args)>=4 and args[3].startswith("'") and args[3]!="NULL":
            hint=args[3].strip("'")
            for h in hint.split('|'):
                if re.fullmatch(r'[a-z][a-z0-9_]*',h) and '_' in h and h not in known:
                    errors.append(f'{b}: اسم قيد/فهرس غير معروف في المخطط: {h}')
    for k in re.findall(r"vt\.fu?\('(\w+)'\)",t): used.add(k)
    for k in re.findall(r"vt\.setfxu?\('(\w+)'",t): defined.add(k)
    # UPDATE t SET cols
    for m in re.finditer(r'UPDATE\s+(\w+)\s+SET\s+(.*?)(?:\s+WHERE\b|\$q\$|\$s\$|;|$)',t,re.S):
        tb=m.group(1)
        if tb not in tables: continue
        body=strip_sql_strings(m.group(2).split('WHERE')[0])
        for part in top_split(body):
            mm=re.match(r'(\w+)\s*=',part.strip())
            if mm and mm.group(1) not in tables[tb]: errors.append(f'{b}: UPDATE {tb} SET {mm.group(1)} — عمود غير موجود')
    for m in re.finditer(r'INSERT INTO\s+(\w+)\s*\(([^)]*)\)',t):
        tb=m.group(1)
        if tb in tables:
            for c in [x.strip() for x in m.group(2).split(',')]:
                if c and c not in tables[tb]: errors.append(f'{b}: INSERT INTO {tb} ({c}) — عمود غير موجود')
    # عدّ النتائج التي تُسجَّل فعلًا (أدنى/أقصى عبر فروع كتل DO الشرطية): جمل SELECT vt.* العليا فقط (لا أجسام الدوال)
    try: mnr,mxr=count_results(t)
    except ValueError: mnr=mxr=0
    n=mnr; nmax=mxr
    m=re.search(r'^-- EXPECT_MIN: (\d+)',t,re.M); mn=int(m.group(1)) if m else None
    stats[b]=(n,mn,nmax)
for k in sorted(used-defined) if os.path.exists(os.path.join(sqldir,'10_fixtures.sql')) else []: errors.append(f'مفتاح تثبيت مستعمل بلا تعريف: {k}')
# مفاتيح build_fixtures
fxp=os.path.join(sqldir,'10_fixtures.sql')
if os.path.exists(fxp):
    fx=open(fxp,encoding='utf-8').read()
    bf=re.search(r'CREATE FUNCTION vt\.build_fixtures.*?END \$\$;',fx,re.S).group(0)
    fxkeys=set(re.findall(r"vt\.setfxu?\('(\w+)'",bf))
print('أعمدة/جداول: تم فحص',len(tables),'جدولًا')
print(f'عدد تدفقات التطبيق في vt.app_flows = {FLOWS[0]}')
print('عدد النتائج المسجَّلة فعلًا (أدنى/أقصى عبر النسخ) مقابل EXPECT_MIN (يجب EXPECT_MIN ≤ الأدنى):')
for b,(n,mn,nmax) in stats.items():
    if mn is None: continue
    flag=''
    if mn>n: flag='  ✗ EXPECT_MIN أعلى من الأدنى الممكن'; errors.append(f'{b}: EXPECT_MIN {mn} > الأدنى المسجَّل فعلًا {n} (الأقصى {nmax}) — لا يتحقق في كل النسخ')
    rng=f'{n}' if n==nmax else f'{n}..{nmax}'
    print(f'  {b}: {rng} (EXPECT_MIN={mn}){flag}')
print('أخطاء:',len(errors)); [print('  ✗',e) for e in errors]
print('تحذيرات:',len(warns)); [print('  ~',w) for w in warns]

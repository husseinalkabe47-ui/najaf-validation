#!/usr/bin/env python3
"""يقسّم ملف المخطط عند علامات «-- ===== MIGRATION NNNN» إلى ملفات مرقّمة. الاستعمال: split_migrations.py SCHEMA OUTDIR"""
import re,sys,os
src=open(sys.argv[1],encoding='utf-8').read(); out=sys.argv[2]; os.makedirs(out,exist_ok=True)
marks=list(re.finditer(r'^-- ===== MIGRATION (\d{4}) [^\n]*$',src,re.M))
if not marks: sys.exit('no migration markers found')
for i,m in enumerate(marks):
    end=marks[i+1].start() if i+1<len(marks) else len(src)
    open(os.path.join(out,m.group(1)+'.sql'),'w',encoding='utf-8').write(src[m.start():end].rstrip()+'\n')
print(len(marks),'migrations:',', '.join(m.group(1) for m in marks))

#!/usr/bin/env python3
"""يولّد sql/05_expected_objects.sql من ملف المخطط نفسه (لا قوائم مكتوبة يدويًا)."""
import re,sys
src=open(sys.argv[1],encoding='utf-8').read(); out=sys.argv[2]
s=re.sub(r'--[^\n]*','',src)
tables=re.findall(r'CREATE TABLE (\w+)\s*\(',s)
indexes=re.findall(r'CREATE\s+(?:UNIQUE\s+)?INDEX\s+(\w+)\s+ON',s)
funcs=re.findall(r'CREATE FUNCTION (\w+)\s*\(',s)
trigs=re.findall(r'CREATE\s+(?:CONSTRAINT\s+)?TRIGGER\s+(\w+)\s',s)
views=re.findall(r'CREATE VIEW (\w+)',s)
domains=re.findall(r'CREATE DOMAIN (\w+)',s)
dom_checks=re.findall(r'CREATE DOMAIN \w+ AS [^\n]*?CONSTRAINT\s+(\w+)\s+CHECK',s)
checks=[c for c in re.findall(r'CONSTRAINT\s+(\w+)\s+CHECK',s) if c not in dom_checks]
uniques=re.findall(r'CONSTRAINT\s+(\w+)\s+UNIQUE',s)
fks=len(re.findall(r'REFERENCES\s+\w+\s*\(',s))
rows=[]
for k,l in [('table',tables),('index',indexes),('function',funcs),('trigger',trigs),('view',views),('domain',domains),('check',checks),('unique',uniques),('domain_check',dom_checks)]:
    for n in l: rows.append((k,n))
sql="-- مولَّد آليًا من najaf_schema_v1.sql (tools/gen_expected.py) — لا يُعدَّل يدويًا\nCREATE TABLE vt.expected (kind text NOT NULL, name text NOT NULL);\nINSERT INTO vt.expected (kind, name) VALUES\n"+",\n".join(f"  ('{k}', '{n}')" for k,n in rows)+";\n"
sql+=f"CREATE TABLE vt.expected_counts (kind text PRIMARY KEY, n integer NOT NULL);\nINSERT INTO vt.expected_counts VALUES ('fk', {fks}), ('table', {len(tables)});\n"
open(out,'w',encoding='utf-8').write(sql)
cnt={}
for k,_ in rows: cnt[k]=cnt.get(k,0)+1
print(cnt,'fks',fks)

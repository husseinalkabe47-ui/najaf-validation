import re,sys,collections
src=open(sys.argv[1],encoding='utf-8').read()
# ---- tokenizer: strip comments, split statements honoring '...' and $$...$$
def split_statements(t):
    out=[];buf=[];i=0;n=len(t);sq=False;dq=False
    while i<n:
        c=t[i]
        if not sq and not dq and t.startswith('--',i):
            j=t.find('\n',i); i=n if j<0 else j; continue
        if not sq and not dq and t.startswith('$$',i):
            j=t.find('$$',i+2); assert j>0,'unterminated $$'; buf.append(t[i:j+2]); i=j+2; continue
        if c=="'" and not dq: sq=not sq
        if c=='"' and not sq: dq=not dq
        if c==';' and not sq and not dq:
            s=''.join(buf).strip()
            if s: out.append(s)
            buf=[]; i+=1; continue
        buf.append(c); i+=1
    s=''.join(buf).strip()
    if s: out.append(s)
    return out
stmts=split_statements(src)
def strip_strings(x): return re.sub(r"'(?:[^']|'')*'","''",x)
def top_split(body):
    parts=[];d=0;cur='';sq=False
    for ch in body:
        if ch=="'": sq=not sq
        if not sq:
            if ch=='(': d+=1
            elif ch==')': d-=1
            elif ch==',' and d==0: parts.append(cur.strip()); cur=''; continue
        cur+=ch
    if cur.strip(): parts.append(cur.strip())
    return parts
tables={};fks=[];errors=[];warns=[];index_names=collections.Counter();funcs=set();domains=set();views={};uniq_cols=collections.defaultdict(list);pk={}
KW=set('''and or not null is in between like true false case when then else end any all exists select from where as on desc asc using gin brin text bytea uuid boolean smallint integer bigint numeric jsonb varchar char timestamptz citext cardinality text_array_max_len char_length btrim octet_length jsonb_typeof now value unnest lower upper coalesce count distinct limit order by join left right inner group default current_user'''.split())
DOMAINS={'e164_iq','e164_any'}
for st in stmts:
    m=re.match(r'CREATE DOMAIN (\w+)',st,re.I)
    if m: domains.add(m.group(1))
    m=re.match(r'CREATE (?:OR REPLACE )?FUNCTION (\w+)\s*\(',st,re.I)
    if m:
        if m.group(1) in funcs: errors.append('duplicate function '+m.group(1))
        funcs.add(m.group(1))
for st in stmts:
    m=re.match(r'CREATE TABLE (\w+)\s*\((.*)\)\s*$',st,re.S|re.I)
    if not m: continue
    name,body=m.group(1),m.group(2); cols={};cons={}
    if name in tables: errors.append('duplicate table '+name)
    for item in top_split(body):
        first=item.split()[0].upper()
        if first=='CONSTRAINT':
            cn=item.split()[1]; cons[cn]=item
            if cn in {**cons} and list(cons).count(cn)>1: errors.append(f'{name}: dup constraint {cn}')
            um=re.search(r'UNIQUE\s*\(([^)]*)\)',item,re.I)
            if um: uniq_cols[name].append([c.strip() for c in um.group(1).split(',')]); index_names[cn]+=1
        else:
            cn=item.split()[0]; cols[cn]=item
            if re.search(r'PRIMARY KEY',item,re.I): pk[name]=cn
            if re.search(r'\bUNIQUE\b',item,re.I) and not re.search(r'^CONSTRAINT',item,re.I): uniq_cols[name].append([cn])
            rm=re.search(r'REFERENCES\s+(\w+)\s*\((\w+)\)(?:\s+ON DELETE (CASCADE|RESTRICT|SET NULL))?',item,re.I)
            if rm: fks.append((name,cn,rm.group(1),rm.group(2),(rm.group(3) or 'NO ACTION').upper(),bool(re.search(r'NOT NULL',item,re.I))))
            ty=item.split()[1] if len(item.split())>1 else ''
            if ty.lower() in('timestamp',) : errors.append(f'{name}.{cn}: timestamp without time zone')
            base=re.sub(r'\(.*','',ty).lower()
            if base not in {'bigint','integer','smallint','varchar','text','numeric','timestamptz','boolean','uuid','bytea','jsonb','citext','char','e164_iq','e164_any','text[]'} and base not in domains: warns.append(f'{name}.{cn}: unusual type {ty}')
    tables[name]=(cols,cons)
# ---- FK checks
for t,c,rt,rc,act,notnull in fks:
    if rt not in tables: errors.append(f'FK {t}.{c} -> missing table {rt}'); continue
    if rc not in tables[rt][0]: errors.append(f'FK {t}.{c} -> missing column {rt}.{rc}'); continue
    if rc!=pk.get(rt) and [rc] not in uniq_cols[rt]: errors.append(f'FK target {rt}.{rc} is not PK/unique')
    if act=='SET NULL' and notnull: errors.append(f'FK {t}.{c}: ON DELETE SET NULL on NOT NULL column')
# ---- every table has a PK
for t,(cols,cons) in tables.items():
    if t not in pk: errors.append(f'table {t}: no PRIMARY KEY')
# ---- CHECK references
for t,(cols,cons) in tables.items():
    for cn,item in cons.items():
        if re.match(r'CONSTRAINT\s+\w+\s+CHECK',item,re.I):
            expr=strip_strings(item); toks=set(re.findall(r'\b[a-z_][a-z0-9_]*\b',expr.lower()))
            unknown=[x for x in toks if x not in cols and x not in KW and x not in {cn.lower(),'constraint','check'} and x not in {'bytea'}]
            if unknown: warns.append(f'{t}.{cn}: unrecognised identifiers in CHECK {unknown}')
    for cn,item in cols.items():
        pass
# ---- indexes
idx={}
for st in stmts:
    m=re.match(r'CREATE\s+(UNIQUE\s+)?INDEX\s+(\w+)\s+ON\s+(\w+)(?:\s+USING\s+(\w+))?\s*\((.*?)\)(?:\s+WHERE\s+(.*))?$',st,re.S|re.I)
    if not m: continue
    uq,name,tb,method,cols_s,where=m.groups(); index_names[name]+=1; idx[name]=tb
    if tb not in tables: errors.append(f'index {name}: missing table {tb}'); continue
    for part in top_split(cols_s):
        col=part.split()[0]
        if col not in tables[tb][0]: errors.append(f'index {name}: unknown column {col} on {tb}')
    if where:
        w=strip_strings(where)
        for tok in set(re.findall(r'\b[a-z_][a-z0-9_]*\b',w.lower())):
            if tok not in tables[tb][0] and tok not in KW: warns.append(f'index {name}: WHERE token {tok}')
for n,c in index_names.items():
    if c>1: errors.append(f'duplicate index/constraint name {n}')
# ---- triggers & functions
for st in stmts:
    m=re.match(r'CREATE\s+(?:CONSTRAINT\s+)?TRIGGER\s+(\w+)\s.*?\sON\s+(\w+).*?EXECUTE\s+FUNCTION\s+(\w+)\(\)',st,re.S|re.I)
    if not m: continue
    name,tb,fn=m.groups()
    if tb not in tables: errors.append(f'trigger {name}: missing table {tb}')
    if fn not in funcs: errors.append(f'trigger {name}: missing function {fn}')
    um=re.search(r'UPDATE OF ([\w, ]+?) ON',st,re.I)
    if um and tb in tables:
        for c in [x.strip() for x in um.group(1).split(',')]:
            if c not in tables[tb][0]: errors.append(f'trigger {name}: unknown column {c}')
# ---- views: alias.col refs
all_cols={t:set(v[0]) for t,v in tables.items()}
for st in stmts:
    m=re.match(r'CREATE VIEW (\w+)',st,re.I)
    if not m: continue
    vname=m.group(1); aliases={}
    for am in re.finditer(r'(?:FROM|JOIN)\s+(\w+)\s+(\w+)\b',st): aliases[am.group(2)]=am.group(1)
    sel=st[:st.upper().index(' FROM ')]
    vcols=[]
    for ref in re.finditer(r'\b(\w+)\.(\w+)\b',st):
        a,c=ref.groups(); t=aliases.get(a)
        if t is None: continue
        if t in all_cols and c not in all_cols[t]: errors.append(f'view {vname}: {a}.{c} not a column of {t}')
        if t in views and c not in views[t]: errors.append(f'view {vname}: {a}.{c} not a column of view {t}')
    # output columns
    items=top_split(sel[sel.upper().index('SELECT')+6:].replace('\n',' '))
    for it in items:
        mm=re.search(r'\bAS\s+(\w+)\s*$',it.strip()); vcols.append(mm.group(1) if mm else it.strip().split('.')[-1].split()[-1])
    views[vname]=vcols
# ---- grants
for st in stmts:
    m=re.match(r'GRANT UPDATE \(([^)]*)\) ON (\w+)',st,re.I)
    if m:
        for c in [x.strip() for x in m.group(1).split(',')]:
            if c not in all_cols.get(m.group(2),()): errors.append(f'GRANT UPDATE column {m.group(2)}.{c} missing')
    m=re.match(r'GRANT [A-Z, ]+ ON ([\w, ]+?) TO',st,re.I)
    if m and not re.match(r'GRANT (USAGE|EXECUTE)',st,re.I):
        for t in [x.strip() for x in m.group(1).split(',')]:
            if t.upper().startswith('ALL SEQUENCES'): continue
            if t not in tables and t not in views: errors.append(f'GRANT on unknown object {t}')
# ---- domain usage
for t,(cols,cons) in tables.items():
    for cn,item in cols.items():
        parts=item.split(); ty=parts[1] if len(parts)>1 else ''
        if ty.startswith('e164') and ty not in domains: errors.append(f'{t}.{cn}: unknown domain {ty}')
# ---- inserts reference existing tables/columns
for st in stmts:
    m=re.match(r'INSERT INTO (\w+)\s*\(([^)]*)\)',st,re.I)
    if m:
        t=m.group(1)
        if t not in tables: errors.append(f'INSERT into missing table {t}')
        else:
            for c in [x.strip() for x in m.group(2).split(',')]:
                if c not in tables[t][0]: errors.append(f'INSERT {t}: unknown column {c}')
print('statements',len(stmts),'| tables',len(tables),'| functions',len(funcs),'| views',list(views),'| indexes',len(idx),'| FKs',len(fks))
print('tables:',', '.join(tables))
print('ERRORS',len(errors)); [print('  ✗',e) for e in errors]
print('WARNINGS',len(warns)); [print('  ~',w) for w in warns]

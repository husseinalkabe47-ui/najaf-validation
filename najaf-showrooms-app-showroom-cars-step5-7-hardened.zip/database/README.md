# طبقة قاعدة البيانات — PostgreSQL 16 (المرحلتان 11.2 و11.3)

**الحالة: المخطط اجتاز التحقق على PostgreSQL 16 الحقيقي** (انظر `VALIDATION.md`). **لكن الواجهة لا تتصل به بعد:** التطبيق ما زال نموذجًا أوليًا يخزّن في `localStorage`، ولا يوجد Backend. هذا المجلد هو الأساس الذي ستُبنى عليه المرحلة 11.4 وما بعدها.

## المحتويات
```
database/
├── migrations/            ← المصدر الرسمي: 0001 … 0013 (يُنفَّذ كل ملف داخل معاملة بالترتيب)
├── seed/najaf_demo_seed.sql   ← بيانات تجريبية للتهيئة (Staging) فقط — لا تُنفَّذ في الإنتاج
├── validation/            ← حزمة التحقق التي اجتازت (run_validation.sh + 8 مجموعات اختبار + تزامن + أداء) ونسختا المخطط
├── tools/verify_integrity.py  ← يثبت أن ما هنا مطابق حرفيًا لما اجتاز
└── CHECKSUMS.sha256       ← بصمات كل الملفات
```

## تطبيق المخطط على قاعدة جديدة
```bash
for f in database/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -1 -d najaf -f "$f"; done   # 0001 → 0013 بالترتيب
```
- يلزم `PostgreSQL 16` مع `contrib` (امتدادا `citext` و`pg_trgm`).
- البذرة (`seed/`) للتهيئة فقط، وتُنفَّذ بدور **المشغّل** (superuser أو دور ليس عضوًا في `najaf_app`) لأن إنشاء حسابات `admin` ممنوع على دور التطبيق. كلمات مرورها قيم وهمية لا تسمح بالدخول.
- **الإنتاج يبدأ بلا مستخدمين**: المدير الأول يُنشأ بأداة تشغيلية بدور المشغّل، وسعر الصرف الأول يضبطه المدير.

## الأدوار والحماية (كما اجتازت الاختبارات)
- `najaf_app` (بلا تسجيل دخول): دور الـBackend. يتصل التطبيق بدور دخول **عضو** فيه، **ولا يتصل أبدًا بمشرف**. بلا DDL ولا TRUNCATE، ولا `DELETE` على `users` و`showrooms` و`audit_logs` و`exchange_rates`، ولا `UPDATE` على سجل التدقيق.
- `najaf_report` (بلا تسجيل دخول): قراءة `public_cars` و`public_showrooms` و`audit_logs` فقط.
- **0013** يقيّد `UPDATE` على أعمدة 4 جداول (`showrooms` و`cars` و`car_images` و`favorites`): لا تعديل لـ`id` ولا للملكية ولا لنوع المصدر ولا لـ`created_at` و`updated_at` و`version`. و`users.role` محجوب من 0012. **`INSERT` غير مقيَّد بالأعمدة** (قرار مفتوح).
- الظهور العام عبر `public_cars` و`public_showrooms` فقط (أعمدة بقائمة بيضاء، `security_barrier`).
- مشغّلات: حماية آخر مدير (قفل استشاري + `UPDATE` و`DELETE`)، ومنع إنشاء مدير من دور التطبيق، وحارس صور السيارات (ملكية وسقف 4/5 والرئيسية)، وحارس غلاف المعرض، وإلغاء جلسات المستخدم عند إيقافه أو حذفه ناعمًا أو تغيير كلمة مروره، وحذف مفضلة السيارة عند حذفها ناعمًا.

## التحقق
- **كل تعديل على المخطط يستلزم إعادة التحقق على PostgreSQL** قبل اعتماده: `database/validation/README.md` (Docker أو خادم موجود) أو GitHub Actions: `.github/workflows/validate-database.yml` (تشغيل يدوي: *Actions ← Validate database schema ← Run workflow*؛ الملخص في صفحة التشغيل والنتائج الكاملة في Artifacts).
- بعد التعديل المقصود والتحقق: `python3 database/tools/verify_integrity.py --write-checksums`، وأثناء التطوير: `python3 database/tools/verify_integrity.py` (يفشل عند أي اختلاف عن النسخة المعتمدة).
- المرجع الرسمي للمخطط الواحد: `database/validation/najaf_schema_v1.working-18-14.sql` (= الترحيلات 0001–0012)، ومعه `0013`. أما `najaf_schema_v1.delivered-11.2.sql` فمرجع تاريخي للمقارنة فقط (بلا الحمايات الأربع اللاحقة).

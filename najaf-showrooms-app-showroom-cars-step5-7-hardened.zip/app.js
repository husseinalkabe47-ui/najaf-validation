/* نقطة تشغيل التطبيق: تحميل الحالة المحفوظة ثم أول عرض */
/* أي خطأ غير متوقع: تفاصيله في Console للمطوّر، والمستخدم يرى رسالة عربية واضحة فقط */
if (typeof window.addEventListener === 'function') {
  window.addEventListener('error', (e) => {
    if (e && /ResizeObserver/.test(String(e.message))) return;
    console.error('[app error]', e && (e.error || e.message));
    notify('حدث خطأ، حاول مرة أخرى', 'error');
  });
  window.addEventListener('unhandledrejection', (e) => {
    console.error('[app rejection]', e && e.reason);
    notify('حدث خطأ، حاول مرة أخرى', 'error');
  });
}
/* (الجزء 6.1) تبويب آخر غيّر البيانات المحفوظة: نعيد تحميل الحالة من التخزين كي لا يكتب هذا التبويب فوق نسخة قديمة في ذاكرته.
   لا إعادة رسم فوق نموذج مفتوح (لا نمسح ما يكتبه المستخدم)؛ والحدث لا يصل للتبويب الذي كتب. */
const _SYNC_FORM_ROUTES = ['login', 'register', 'addMemberCar', 'editMemberCar', 'addShowroomCar', 'editShowroomCar'];
function syncFromOtherTab(e) {
  if (!isDataChangeEvent(e)) return;   // مفتاح لا يخص التطبيق
  try { hydrateRepositories(); } catch (err) { console.error('[sync error]', err); return; }
  if (!_SYNC_FORM_ROUTES.includes(currentRoute)) render();
}
if (typeof window.addEventListener === 'function') window.addEventListener('storage', syncFromOtherTab);
loadRegisteredUsersAndState();
render();
initBrowserBack();
setTimeout(() => {
  const sp = document.getElementById('splash');
  sp.style.opacity = '0';
  setTimeout(() => sp.remove(), 500);
}, 1600);

function loadRegisteredUsersAndState() {
  const hydrated = hydrateRepositories();   // المرحلة 9: مستخدمون، معارض، سيارات معارض/أعضاء (+سجل المحذوفات)، صور، مفضلة
  runStorageMigrations(hydrated);           // المرحلة 9 Fix: هجرات المخطط (معرّفات موحّدة، تنظيف، رقم الإصدار) مرة واحدة
  // الصور المضغوطة المحفوظة → روابط عرض مؤقتة. لا نعيد رسم شاشة فيها نموذج حتى لا نمسح ما يكتبه المستخدم
  const FORM_ROUTES = ['login', 'register', 'addMemberCar', 'editMemberCar', 'addShowroomCar', 'editShowroomCar'];
  ImageStore.init().then(() => { if (!FORM_ROUTES.includes(currentRoute)) render(); }).catch(() => {});
  SessionService.updateSession(); // استعادة/تجديد الجلسة إن وُجدت (تبقى بعد إعادة التحميل)
}

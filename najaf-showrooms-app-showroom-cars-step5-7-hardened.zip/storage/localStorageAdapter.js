/* ==========================================================================
   LOCAL STORAGE ADAPTER
   محوّل التخزين المحلي — الطبقة الوحيدة في التطبيق التي تلمس localStorage.
   مجرد مفتاح/قيمة (JSON) بلا أي معرفة بالسيارات أو المستخدمين. يُستبدل لاحقًا
   بمحوّل آخر بنفس الواجهة (get/set/remove/clear/keys/getLastError) دون تغيير الـ Repositories.

   يعالج: بيانات غير موجودة، JSON تالف، قيم لا تطابق الشكل المتوقع (validate)،
   أخطاء التخزين (وضع خاص/محظور)، وامتلاء المساحة (quota). نسخة احتياطية في الذاكرة
   تبقي التطبيق يعمل خلال الجلسة حتى لو تعذّر التخزين (نفس سلوك المراحل السابقة).
   كل عملية كتابة تعيد { ok, error? } بدل أن ترمي استثناءً: error ∈
   quota_exceeded | storage_unavailable | serialize_failed.

   إصلاح المرحلة 9 (أسبقية القراءة): كانت القراءة تفضّل localStorage دائمًا، فبعد فشل كتابة (امتلاء المساحة)
   تعيد القيمة القديمة بدل الأحدث في الذاكرة — فيظهر المستخدم السابق بعد تسجيل دخول جديد، ولا ينجح
   logout إن فشل الحذف. الآن كل مفتاح فشلت آخر عملية عليه (كتابة/حذف) يُعلَّم «معلّقًا» (_pending) فتكون
   النسخة التي في الذاكرة هي المرجع حتى تنجح كتابة لاحقة. غير المعلَّق: localStorage هو المرجع كما كان.
   ========================================================================== */
const LocalStorageAdapter = (function () {
  const PREFIX = 'najaf.';
  const _mem = {};          // نسخة احتياطية في الذاكرة (تبقى مع الجلسة فقط)
  const _pending = {};      // مفتاح → 'set' | 'remove': آخر عملية لم تصل إلى localStorage (الذاكرة هي المرجع)
  let _lastError = null;

  function _classify(e) {
    const text = String((e && e.name) || '') + ' ' + String((e && e.message) || '');
    if (/quota/i.test(text) || (e && (e.code === 22 || e.code === 1014))) return 'quota_exceeded';
    return 'storage_unavailable';
  }

  /** قراءة قيمة. fallback عند الغياب أو التلف أو عدم مطابقة validate. */
  function get(key, fallback = null, validate) {
    let value, found = false;
    if (_pending[key] === 'remove') return fallback;               // حُذف في الذاكرة وتعذّر الحذف الفعلي: لا نعيد النسخة القديمة
    if (_pending[key] === 'set' && Object.prototype.hasOwnProperty.call(_mem, key)) { value = _mem[key]; found = true; }   // كتابة لم تصل: الذاكرة أحدث
    if (!found) {
      try {
        const raw = localStorage.getItem(PREFIX + key);
        if (raw !== null && raw !== undefined) { value = JSON.parse(raw); found = true; }
      } catch (e) { _lastError = (e && e.name === 'SyntaxError') ? 'corrupted_data' : _classify(e); }   // بالاسم لا instanceof: آمن عبر النوافذ/الإطارات
    }
    if (!found && Object.prototype.hasOwnProperty.call(_mem, key)) { value = _mem[key]; found = true; }
    if (!found) return fallback;
    if (typeof validate === 'function') {
      let ok = false;
      try { ok = !!validate(value); } catch (e) { ok = false; }
      if (!ok) { _lastError = 'invalid_data'; return fallback; }
    }
    return value;
  }

  /** كتابة قيمة. تبقى في الذاكرة حتى لو فشل التخزين، وتُعاد { ok:false, error } للمستدعي. */
  function set(key, value) {
    let json;
    try { json = JSON.stringify(value); } catch (e) { json = undefined; }
    if (json === undefined) { _lastError = 'serialize_failed'; return { ok: false, error: 'serialize_failed' }; }
    _mem[key] = value;
    try { localStorage.setItem(PREFIX + key, json); delete _pending[key]; return { ok: true }; }
    catch (e) { _pending[key] = 'set'; _lastError = _classify(e); return { ok: false, error: _lastError }; }
  }

  function remove(key) {
    delete _mem[key];
    try { localStorage.removeItem(PREFIX + key); delete _pending[key]; return { ok: true }; }
    catch (e) { _pending[key] = 'remove'; _lastError = _classify(e); return { ok: false, error: _lastError }; }
  }

  /** المفاتيح المنطقية المعروفة (بلا البادئة). */
  function keys() {
    const out = new Set(Object.keys(_mem));
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.indexOf(PREFIX) === 0) out.add(k.slice(PREFIX.length));
      }
    } catch (e) { /* واجهة التعداد غير متاحة: نكتفي بالنسخة الاحتياطية */ }
    return [...out].filter(k => _pending[k] !== 'remove');       // مفتاح حُذف ولم يُمحَ فعليًا ليس «موجودًا»
  }

  /** حذف مفاتيح التطبيق التي تبدأ بـ prefix فقط (لا تلمس أي مفتاح خارج بادئة التطبيق). */
  function clear(prefix = '') {
    let removed = 0;
    keys().filter(k => k.indexOf(prefix) === 0).forEach(k => { remove(k); removed++; });
    return { ok: true, removed };
  }

  function getLastError() { return _lastError; }

  return { get, set, remove, clear, keys, getLastError, PREFIX };
})();

/** المحوّل الفعّال. كل Repository يتعامل مع AppStorage فقط؛ يمكن استبداله بمحوّل آخر لاحقًا. */
const AppStorage = LocalStorageAdapter;

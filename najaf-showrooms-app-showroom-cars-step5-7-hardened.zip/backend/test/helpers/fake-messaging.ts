// A messaging provider for tests: it records what it was asked to deliver so a test can read the code, the way a phone would.
// This is the ONLY place a plain code ever exists in the test suite; production code never stores or logs one.
import type { MessagingProvider, OtpMessage } from '../../src/messaging/provider.ts';

export function makeFakeProvider() {
  const sent: OtpMessage[] = [];
  const state = { fail: false };
  const provider: MessagingProvider = {
    async send(message) {
      if (state.fail) throw new Error(`provider exploded while sending ${message.code} to ${message.phone}`); // would leak if logged
      sent.push(message);
    },
  };
  return {
    provider,
    sent,
    /** The most recent code sent to this phone for this purpose, as the person holding the phone would read it. */
    lastCode(phone: string, purpose: OtpMessage['purpose']): string | undefined {
      return [...sent].reverse().find((m) => m.phone === phone && m.purpose === purpose)?.code;
    },
    failNext(on = true) {
      state.fail = on;
    },
  };
}

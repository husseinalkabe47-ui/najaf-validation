// Parsing and policy checks for PHC-format password hashes ($argon2id$v=19$m=..,t=..,p=..$salt$hash).
// The ORDER of the parameters in the serialized string is library-specific (node-argon2 emits m,p,t; the reference encoder
// emits m,t,p), so tests must compare parameter VALUES, never a fixed textual order.
import assert from 'node:assert/strict';

export interface Phc {
  algorithm: string;
  version: number | undefined;
  params: Record<string, number>;
  salt: Buffer;
  hash: Buffer;
}

const B64 = /^[A-Za-z0-9+/]+$/;

export function parsePhc(encoded: string): Phc {
  const parts = encoded.split('$');
  if (parts[0] !== '') throw new Error('PHC string must start with "$"');
  parts.shift();
  const algorithm = parts.shift();
  if (!algorithm) throw new Error('PHC string has no algorithm');
  let version: number | undefined;
  if (parts[0]?.startsWith('v=')) {
    const v = /^v=(\d+)$/.exec(parts.shift() as string);
    if (!v) throw new Error('PHC version segment is malformed');
    version = Number(v[1]);
  }
  const paramText = parts.shift();
  if (!paramText) throw new Error('PHC string has no parameters');
  const params: Record<string, number> = {};
  for (const kv of paramText.split(',')) {
    const m = /^([a-z]+)=(\d+)$/.exec(kv);
    if (!m) throw new Error(`PHC parameter "${kv}" is malformed`);
    const key = m[1] as string;
    if (key in params) throw new Error(`PHC parameter "${key}" is repeated`);
    params[key] = Number(m[2]);
  }
  const [salt, hash, ...extra] = parts;
  if (!salt || !hash || extra.length > 0) throw new Error('PHC string must end with exactly <salt>$<hash>');
  if (!B64.test(salt) || !B64.test(hash)) throw new Error('PHC salt/hash must be unpadded base64');
  return { algorithm, version, params, salt: Buffer.from(salt, 'base64'), hash: Buffer.from(hash, 'base64') };
}

/**
 * The password-hash policy, independent of parameter order: argon2id, version 19, exactly m=19456, t=2, p=1 and no other
 * parameter, a salt of at least 16 bytes and a hash of at least 32 bytes.
 */
export function assertArgon2idPolicy(encoded: string): Phc {
  const phc = parsePhc(encoded);
  assert.equal(phc.algorithm, 'argon2id');
  assert.equal(phc.version, 19);
  assert.deepEqual(phc.params, { m: 19456, t: 2, p: 1 }); // deep equality ignores key order, but rejects any missing/extra/different value
  assert.ok(phc.salt.length >= 16, `salt too short: ${phc.salt.length} bytes`);
  assert.ok(phc.hash.length >= 32, `hash too short: ${phc.hash.length} bytes`);
  return phc;
}

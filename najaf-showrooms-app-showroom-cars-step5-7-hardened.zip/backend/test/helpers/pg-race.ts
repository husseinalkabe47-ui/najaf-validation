// Helpers for DETERMINISTIC concurrency tests against a real PostgreSQL. Nothing here sleeps for a guessed time:
//  - a "gate" is a promise a test opens by hand;
//  - waitForLockWaiters polls the catalog until a backend is REALLY blocked on a lock, then returns (event-based);
//  - the held/failing stores wrap the real store and stop a transaction at an exact point.
import type { AuthStore } from '../../src/auth/repository.ts';
import type { Db } from '../../src/db.ts';

export interface Gate {
  open: Promise<void>;
  release(): void;
}
export function makeGate(): Gate {
  let release!: () => void;
  const open = new Promise<void>((resolve) => (release = resolve));
  return { open, release };
}

/**
 * Resolves once at least `expected` backends are blocked waiting for a lock (wait_event_type = 'Lock'), which is exactly the
 * moment a competing statement has reached the row lock a test is holding. Polls the catalog; fails loudly after `timeoutMs`
 * instead of passing by luck.
 */
export async function waitForLockWaiters(admin: Db, expected = 1, timeoutMs = 20_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const r = await admin.query(`SELECT count(*)::int AS n FROM pg_stat_activity a WHERE a.datname = current_database() AND a.wait_event_type = 'Lock' AND a.pid <> pg_backend_pid()`);
    if ((r.rows[0] as { n: number }).n >= expected) return;
    if (Date.now() > deadline) throw new Error(`timed out waiting for ${expected} backend(s) blocked on a lock`);
    await new Promise<void>((resolve) => setTimeout(resolve, 10));
  }
}

/**
 * A store whose transactions do not START until released. A sign-in built on it has already read and verified the credentials
 * (that happens before its transaction) and is frozen just before it would create the session. `reached` resolves once `count`
 * transactions are waiting.
 */
export function holdBeforeTransaction(real: AuthStore, count = 1) {
  const gate = makeGate();
  const reached = makeGate();
  let waiting = 0;
  const store: AuthStore = {
    ...real,
    transaction: (async (fn: Parameters<AuthStore['transaction']>[0]) => {
      waiting += 1;
      if (waiting >= count) reached.release();
      await gate.open;
      return real.transaction(fn);
    }) as AuthStore['transaction'],
  };
  return { store, reached: reached.open, release: gate.release };
}

/**
 * A store whose transactions run their WHOLE body (every statement, with its row locks) and then wait before COMMIT. Whatever the
 * body locked stays locked until released.
 */
export function holdBeforeCommit(real: AuthStore) {
  const gate = makeGate();
  const reached = makeGate();
  const store: AuthStore = {
    ...real,
    transaction: (async (fn: Parameters<AuthStore['transaction']>[0]) =>
      real.transaction(async (repos) => {
        const out = await fn(repos);
        reached.release();
        await gate.open;
        return out;
      })) as AuthStore['transaction'],
  };
  return { store, reached: reached.open, release: gate.release };
}

/** A store whose transactions run their whole body and then FAIL: PostgreSQL rolls back everything the body did. */
export function failAfterBody(real: AuthStore, message: string): AuthStore {
  return {
    ...real,
    transaction: (async (fn: Parameters<AuthStore['transaction']>[0]) =>
      real.transaction(async (repos) => {
        await fn(repos);
        throw new Error(message);
      })) as AuthStore['transaction'],
  };
}

/** A store whose audit insert always fails, so a transaction that audits cannot commit. */
export function failAudit(real: AuthStore, message: string): AuthStore {
  return {
    ...real,
    transaction: (async (fn: Parameters<AuthStore['transaction']>[0]) =>
      real.transaction((repos) => fn({ ...repos, audit: { record: async () => { throw new Error(message); } } }))) as AuthStore['transaction'],
  };
}

import type { PoolClientLike, PoolLike, QueryResultLike } from '../../src/db.ts';

export interface Call {
  text: string;
  values: readonly unknown[];
  via: 'pool' | 'client';
}

export type Responder = (text: string, values: readonly unknown[]) => QueryResultLike<unknown> | Error | Promise<QueryResultLike<unknown> | Error>;

// pg-shaped errors (DatabaseError carries code + severity); used to exercise error classification without a database.
export function pgError(code: string, message = 'driver message', extra: Record<string, unknown> = {}): Error {
  return Object.assign(new Error(message), { code, severity: 'ERROR', ...extra });
}

export function makeFakePool(respond: Responder = () => ({ rows: [], rowCount: 0 })) {
  const calls: Call[] = [];
  const releases: Array<Error | boolean | undefined> = [];
  const listeners: Record<string, Array<(e: Error) => void>> = {};
  const state = { ended: 0, connectError: undefined as Error | undefined, connects: 0 };

  const run = async (via: 'pool' | 'client', text: string, values: readonly unknown[]): Promise<QueryResultLike<unknown>> => {
    calls.push({ text, values, via });
    const r = await respond(text, values);
    if (r instanceof Error) throw r;
    return r;
  };

  const pool = {
    query: (text: string, values: readonly unknown[] = []) => run('pool', text, values),
    connect: async () => {
      state.connects += 1;
      if (state.connectError) throw state.connectError;
      const client = {
        query: (text: string, values: readonly unknown[] = []) => run('client', text, values),
        release: (err?: Error | boolean) => {
          releases.push(err);
        },
      };
      return client as unknown as PoolClientLike;
    },
    end: async () => {
      state.ended += 1;
    },
    on: (event: string, listener: (e: Error) => void) => {
      (listeners[event] ??= []).push(listener);
      return pool;
    },
    totalCount: 3,
    idleCount: 1,
    waitingCount: 0,
  } as unknown as PoolLike;

  return { pool, calls, releases, listeners, state };
}

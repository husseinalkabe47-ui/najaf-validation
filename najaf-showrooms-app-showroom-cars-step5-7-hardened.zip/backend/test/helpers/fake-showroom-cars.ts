// In-memory stand-in for the showroom-car store (Phase 11.5, Step 5.7). It mirrors, independently of src, what the SQL and the
// database do:
//  - the dealer's showroom is found by owner_id; dealer statements on cars are scoped by showroom_id AND source_type = 'showroom'
//    AND not deleted; the administrator's lock reads any showroom car that is not deleted (joined to its showroom and owner);
//  - CHECK backstops that THROW if the service ever let a violation through: cars_status_by_source (showroom: available|sold),
//    cars_member_only_fields (no phone/location/... on a showroom car), and the column privileges (no write of showroom_id,
//    source_type, owner_id or version);
//  - touch_versioned (version + 1 and updated_at on every UPDATE), compare-and-swap on version, and the soft-delete trigger that
//    removes the car's favorites;
//  - transactions are all-or-nothing (snapshot/restore) and SERIALIZED per store (a stand-in for the row lock FOR UPDATE);
//  - audit rows go through the real assertAuditSafe (numbers only).
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import { DbError } from '../../src/errors.ts';
import type { ModeratedCarRow, ShowroomCarRepository, ShowroomCarRow, ShowroomCarStore } from '../../src/showroom-cars/repository.ts';

export interface FakeShowroom {
  id: string;
  ownerId: string;
  status: string;
}
export interface FakeCar {
  id: string;
  sourceType: 'showroom' | 'member';
  showroomId: string | null;
  ownerId: string | null;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  status: string;
  searchText: string;
  version: number;
  deleted: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const ALLOWED_SET = new Set(['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description', 'status', 'searchText', 'deleted']);

export function makeFakeShowroomCarStore(opts: { userState?: (id: string) => { status: string; deleted: boolean } | undefined } = {}) {
  const users = new Map<string, { status: string; deleted: boolean }>();
  let showrooms: FakeShowroom[] = [];
  let cars: FakeCar[] = [];
  let favorites: Array<{ userId: string; carId: string }> = [];
  let audits: AuditEvent[] = [];
  let nextCar = 5000;
  let clockMs = Date.UTC(2026, 0, 1);
  const calls: string[] = [];
  const faults: { failNextAudit: boolean; afterLock: (() => void) | null } = { failNextAudit: false, afterLock: null };

  const liveUser = (id: string) => {
    const u = (opts.userState ?? ((x: string) => users.get(x)))(id);
    return u !== undefined && u.status === 'active' && !u.deleted;
  };
  const view = (c: FakeCar): ShowroomCarRow => ({
    id: c.id, showroomId: c.showroomId!, brand: c.brand, model: c.model, year: c.year, price: c.price, currency: c.currency, mileage: c.mileage,
    transmission: c.transmission, fuelType: c.fuelType, color: c.color, description: c.description, status: c.status, version: c.version,
    createdAt: c.createdAt, updatedAt: c.updatedAt,
  });
  const own = (id: string, showroomId: string) => cars.find((c) => c.id === id && c.showroomId === showroomId && c.sourceType === 'showroom' && !c.deleted);
  /** One UPDATE statement as the database runs it: privileges, CHECKs, touch_versioned, soft-delete trigger. */
  const write = (c: FakeCar, set: Partial<FakeCar>) => {
    for (const k of Object.keys(set)) if (!ALLOWED_SET.has(k)) throw new DbError('forbidden', { sqlstate: '42501', driverMessage: `permission denied for column ${k}` });
    const next = { ...c, ...set };
    if (next.sourceType === 'showroom' && !['available', 'sold'].includes(next.status)) throw new DbError('check', { sqlstate: '23514', constraint: 'cars_status_by_source' });
    const wasDeleted = c.deleted;
    Object.assign(c, set, { version: c.version + 1, updatedAt: new Date((clockMs += 1000)) });
    if (!wasDeleted && c.deleted) favorites = favorites.filter((f) => f.carId !== c.id);
  };

  const repo: ShowroomCarRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      return liveUser(userId);
    },
    async findShowroomOfOwner(ownerId) {
      calls.push('findShowroomOfOwner');
      const s = showrooms.find((x) => x.ownerId === ownerId);
      return s ? { ...s } : null;
    },
    async insert(showroomId, f, searchText) {
      calls.push('insert');
      if (!showrooms.some((s) => s.id === showroomId)) throw new DbError('foreign_key', { sqlstate: '23503' });
      for (const k of ['phone', 'whatsapp', 'location', 'latitude', 'longitude']) if (k in f) throw new DbError('check', { sqlstate: '23514', constraint: 'cars_member_only_fields' });
      const at = new Date((clockMs += 1000));
      const c: FakeCar = { id: String(nextCar++), sourceType: 'showroom', showroomId, ownerId: null, ...f, price: String(f.price), status: 'available', searchText, version: 1, deleted: false, createdAt: at, updatedAt: at };
      cars.push(c);
      return view(c);
    },
    async listOwn(showroomId, q) {
      calls.push('listOwn');
      return cars
        .filter((c) => c.showroomId === showroomId && c.sourceType === 'showroom' && !c.deleted && (q.before === null || BigInt(c.id) < BigInt(q.before)) && (q.status === null || c.status === q.status))
        .sort((a, b) => Number(BigInt(b.id) - BigInt(a.id)))
        .slice(0, q.limit)
        .map(view);
    },
    async findOwn(id, showroomId, lock) {
      calls.push(lock ? 'lockOwn' : 'findOwn');
      const c = own(id, showroomId);
      const seen = c ? view(c) : null; // what the locking SELECT returned
      if (c && lock && faults.afterLock) {
        const f = faults.afterLock;
        faults.afterLock = null;
        f();
      }
      return seen;
    },
    async update(input) {
      calls.push('update');
      const c = own(input.id, input.showroomId);
      if (!c || c.version !== input.expectedVersion) return null;
      const set: Partial<FakeCar> = { ...input.changes, searchText: input.searchText } as Partial<FakeCar>;
      if (input.changes.price !== undefined) set.price = String(input.changes.price);
      if (input.status !== null) set.status = input.status;
      write(c, set);
      return view(c);
    },
    async softDelete(input) {
      calls.push('softDelete');
      const c = own(input.id, input.showroomId);
      if (!c || c.version !== input.expectedVersion) return false;
      write(c, { deleted: true });
      return true;
    },
    async lockForModeration(id): Promise<ModeratedCarRow | null> {
      calls.push('lockForModeration');
      const c = cars.find((x) => x.id === id && x.sourceType === 'showroom' && !x.deleted);
      if (!c) return null;
      const seen = view(c); // what the locking SELECT returned
      if (faults.afterLock) {
        const f = faults.afterLock;
        faults.afterLock = null;
        f();
      }
      const s = showrooms.find((x) => x.id === c.showroomId)!;
      return { ...seen, showroomOwnerId: s.ownerId, showroomStatus: s.status, ownerActive: liveUser(s.ownerId) };
    },
    async setStatus(input) {
      calls.push('setStatus');
      const c = cars.find((x) => x.id === input.id && x.sourceType === 'showroom' && !x.deleted);
      if (!c || c.version !== input.expectedVersion) return null;
      write(c, { status: input.status });
      return view(c);
    },
  };

  let chain: Promise<unknown> = Promise.resolve();
  const store: ShowroomCarStore = {
    cars: repo,
    transaction(fn) {
      const run = async () => {
        const snap = JSON.stringify({ cars, favorites, audits, nextCar });
        const audit = {
          async record(event: AuditEvent) {
            if (faults.failNextAudit) {
              faults.failNextAudit = false;
              throw new Error('audit insert failed');
            }
            assertAuditSafe(event);
            audits.push(event);
          },
        };
        try {
          return await fn({ cars: repo, audit });
        } catch (e) {
          const s = JSON.parse(snap) as { cars: FakeCar[]; favorites: typeof favorites; audits: AuditEvent[]; nextCar: number };
          cars = s.cars.map((c) => ({ ...c, createdAt: new Date(c.createdAt), updatedAt: new Date(c.updatedAt) }));
          favorites = s.favorites;
          audits = s.audits;
          nextCar = s.nextCar;
          throw e;
        }
      };
      const result = chain.then(run, run);
      chain = result.catch(() => undefined);
      return result;
    },
  };

  return {
    store,
    calls,
    faults,
    cars: () => cars,
    car: (id: string) => cars.find((c) => c.id === id)!,
    audits: () => audits,
    favorites: () => favorites,
    addUser(id: string, status = 'active', deleted = false) {
      users.set(id, { status, deleted });
    },
    setUser(id: string, status: string, deleted = false) {
      users.set(id, { status, deleted });
    },
    addShowroom(fields: Partial<FakeShowroom> & { ownerId: string }): FakeShowroom {
      const s: FakeShowroom = { id: String(showrooms.length + 1), status: 'active', ...fields };
      showrooms.push(s);
      return s;
    },
    setShowroom(id: string, status: string) {
      showrooms.find((s) => s.id === id)!.status = status;
    },
    addCar(fields: Partial<FakeCar> & ({ showroomId: string } | { ownerId: string; sourceType: 'member' })): FakeCar {
      const at = new Date((clockMs += 1000));
      const c: FakeCar = {
        id: String(nextCar++), sourceType: 'showroom', showroomId: null, ownerId: null, brand: 'Toyota', model: 'Corolla', year: 2020, price: '18500000', currency: 'IQD',
        mileage: null, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: '', description: '', status: fields.sourceType === 'member' ? 'active' : 'available',
        searchText: '', version: 1, deleted: false, createdAt: at, updatedAt: at, ...fields,
      };
      cars.push(c);
      return c;
    },
    addFavorite(userId: string, carId: string) {
      favorites.push({ userId, carId });
    },
    /** A concurrent writer (another request) that committed an update of this car. */
    bump(id: string) {
      const c = cars.find((x) => x.id === id)!;
      c.version += 1;
    },
  };
}
export type FakeShowroomCarStore = ReturnType<typeof makeFakeShowroomCarStore>;

// Test doubles for the authentication layer. The fake hasher produces argon2id-SHAPED strings so the PHC checks are
// exercised, but it is a test double only: real argon2 runs in the CI integration tests.
import { createHash, randomUUID } from 'node:crypto';
import { DbError } from '../../src/errors.ts';
import type { PasswordHasher } from '../../src/auth/password.ts';
import { LOGIN_MAX_FAILURES, SESSION_TTL_SECONDS } from '../../src/auth/policy.ts';
import { hashesEqual } from '../../src/auth/otp.ts';
import type { OtpPurpose } from '../../src/auth/otp.ts';
import { OTP } from '../../src/auth/policy.ts';
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { ActiveSession, AuditEvent, AuditRepository, AuthStore, CredentialRow, IssueOutcome, NewSession, OtpRepository, RotateOutcome, SessionsRepository, UserRow, UsersRepository, VerifyOutcome } from '../../src/auth/repository.ts';
import type { Logger } from '../../src/types.ts';
import { TRANSITIONS } from '../../src/dealers/repository.ts';
import type { DealerRepository, DealerStore, ShowroomRow } from '../../src/dealers/repository.ts';

export function makeFakeHasher() {
  let n = 0;
  const calls = { hash: 0, verify: 0 };
  const digest = (salt: string, plain: string) => createHash('sha256').update(`${salt}\u0000${plain}`).digest('base64').replace(/=+$/, '');
  const hasher: PasswordHasher = {
    async ready() {},
    async hash(plain) {
      calls.hash += 1;
      const salt = `salt${++n}`;
      return `$argon2id$v=19$m=19456,t=2,p=1$${salt}$${digest(salt, plain)}`;
    },
    async verify(hash, plain) {
      calls.verify += 1;
      const parts = hash.split('$');
      if (parts.length !== 6) return false;
      return parts[5] === digest(parts[4] as string, plain);
    },
  };
  return { hasher, calls };
}

interface FakeUser extends UserRow {
  passwordHash: string;
  failedLogins: number;
  locked: boolean;
  lastLoginAt: Date | null;
  deletedAt: Date | null;
}
interface FakeCode {
  id: string;
  userId: string;
  purpose: OtpPurpose;
  phone: string;
  hash: Buffer;
  attempts: number;
  maxAttempts: number;
  createdAt: Date;
  expiresAt: Date;
  consumedAt: Date | null;
  invalidatedAt: Date | null;
}
interface FakeAudit extends AuditEvent {
  id: number;
  occurredAt: Date;
}
interface FakeShowroom {
  id: string;
  ownerId: string;
  name: string;
  phone: string | null;
  whatsapp: string | null;
  address: string;
  status: string;
  reviewedBy: string | null;
  reviewedAt: Date | null;
  createdAt: Date;
}
interface FakeSession {
  id: string;
  userId: string;
  tokenHash: Buffer;
  familyId: string;
  createdAt: Date;
  expiresAt: Date;
  lastUsedAt: Date;
  revokedAt: Date | null;
  revokedReason: string | null;
  replacedBy: string | null;
  userAgent: string | null;
}

/** A controllable clock shared by the fake database and the service, so expiry can be tested without waiting. */
export function makeClock(start = Date.UTC(2026, 0, 1)) {
  let t = start;
  return {
    now: () => t,
    advanceSeconds(s: number) {
      t += s * 1000;
    },
  };
}

export function makeFakeAuthStore(clock: { now(): number } = { now: () => Date.now() }) {
  let users: FakeUser[] = [];
  let sessions: FakeSession[] = [];
  let codes: FakeCode[] = [];
  let audits: FakeAudit[] = [];
  let showrooms: FakeShowroom[] = [];
  let nextId = 1;
  let nextShowroomId = 1;
  const counters = { findCredentials: 0, findActive: 0, touch: 0, revoke: 0, sessionCreate: 0, rotate: 0, otpIssue: 0, otpVerify: 0, passwordResets: 0, passwordChanges: 0, revokeAllLive: 0, revokeFamilyLive: 0, loginCas: 0 };
  const faults = { failNextSessionCreate: false, otpUniqueViolation: false, failNextAudit: false };
  const live = (s: FakeSession) => s.revokedAt === null && s.expiresAt.getTime() > clock.now();
  // The SQL rule (repository.ts), written out independently: active, or pending AND dealer. Never imported from src, so the fake
  // stays an independent oracle for the service code that uses mayAuthenticate().
  const canSignIn = (u: FakeUser) => u.deletedAt === null && (u.status === 'active' || (u.status === 'pending' && u.role === 'dealer'));
  const publicRow = (u: FakeUser): UserRow => ({ id: u.id, name: u.name, phoneE164: u.phoneE164, role: u.role, status: u.status, phoneVerifiedAt: u.phoneVerifiedAt, createdAt: u.createdAt });

  const usersRepo: UsersRepository = {
    async insert({ name, phoneE164, passwordHash }) {
      if (users.some((u) => u.phoneE164 === phoneE164 && u.deletedAt === null)) {
        throw new DbError('unique', { sqlstate: '23505', constraint: 'users_phone_active_uq', driverMessage: 'duplicate key value violates unique constraint "users_phone_active_uq"' });
      }
      // database defaults: role 'user', status 'active' (the repository interface has no way to pass them)
      const u: FakeUser = { id: String(nextId++), name, phoneE164, role: 'user', status: 'active', phoneVerifiedAt: null, createdAt: new Date(clock.now()), passwordHash, failedLogins: 0, locked: false, lastLoginAt: null, deletedAt: null };
      users.push(u);
      return publicRow(u);
    },
    async insertPendingDealer({ name, phoneE164, passwordHash }) {
      if (users.some((u) => u.phoneE164 === phoneE164 && u.deletedAt === null)) {
        throw new DbError('unique', { sqlstate: '23505', constraint: 'users_phone_active_uq', driverMessage: 'duplicate key value violates unique constraint "users_phone_active_uq"' });
      }
      const u: FakeUser = { id: String(nextId++), name, phoneE164, role: 'dealer', status: 'pending', phoneVerifiedAt: null, createdAt: new Date(clock.now()), passwordHash, failedLogins: 0, locked: false, lastLoginAt: null, deletedAt: null };
      users.push(u);
      return publicRow(u);
    },
    async findCredentialsByPhone(phoneE164): Promise<CredentialRow | null> {
      counters.findCredentials += 1;
      const u = users.find((x) => x.phoneE164 === phoneE164 && x.deletedAt === null);
      return u ? { ...publicRow(u), passwordHash: u.passwordHash, locked: u.locked } : null;
    },
    async recordFailedLogin(userId) {
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.failedLogins += 1;
      if (u.failedLogins >= LOGIN_MAX_FAILURES) u.locked = true;
    },
    async recordSuccessfulLogin(userId) {
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.failedLogins = 0;
      u.locked = false;
      u.lastLoginAt = new Date(clock.now());
    },
    async findById(userId) {
      const u = users.find((x) => x.id === userId && x.deletedAt === null);
      return u ? publicRow(u) : null;
    },
    async findByPhone(phoneE164) {
      const u = users.find((x) => x.phoneE164 === phoneE164 && x.deletedAt === null);
      return u ? publicRow(u) : null;
    },
    async markPhoneVerified(userId) {
      const u = users.find((x) => x.id === userId);
      if (!u || u.phoneVerifiedAt !== null) return false;
      u.phoneVerifiedAt = new Date(clock.now());
      return true;
    },
    async recordSuccessfulLoginIf(userId, expectedHash) {
      // compare-and-swap, like the SQL: only while the verified hash is still the stored one and the account is still active
      const u = users.find((x) => x.id === userId && x.deletedAt === null);
      if (!u || u.passwordHash !== expectedHash || !canSignIn(u)) return false;
      counters.loginCas += 1;
      u.failedLogins = 0;
      u.locked = false;
      u.lastLoginAt = new Date(clock.now());
      return true;
    },
    async findCredentialsById(userId): Promise<CredentialRow | null> {
      const u = users.find((x) => x.id === userId && x.deletedAt === null);
      return u ? { ...publicRow(u), passwordHash: u.passwordHash, locked: u.locked } : null;
    },
    async changePasswordIf(userId, expectedHash, newHash) {
      const u = users.find((x) => x.id === userId && x.deletedAt === null);
      if (!u || u.passwordHash !== expectedHash) return false; // compare-and-swap, like the SQL
      counters.passwordChanges += 1;
      u.passwordHash = newHash;
      u.failedLogins = 0;
      u.locked = false;
      // the users_revoke_sessions trigger: a changed password ends every session
      for (const s of sessions) if (s.userId === userId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'password_changed'; }
      return true;
    },
    async resetPassword(userId, passwordHash) {
      counters.passwordResets += 1;
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.passwordHash = passwordHash;
      u.failedLogins = 0;
      u.locked = false;
    },
  };

  const sessionsRepo: SessionsRepository = {
    async create({ userId, tokenHash, userAgent }): Promise<NewSession> {
      counters.sessionCreate += 1;
      if (faults.failNextSessionCreate) {
        faults.failNextSessionCreate = false;
        throw new Error('simulated session insert failure');
      }
      const now = clock.now();
      const s: FakeSession = { id: randomUUID(), userId, tokenHash, familyId: randomUUID(), createdAt: new Date(now), expiresAt: new Date(now + SESSION_TTL_SECONDS * 1000), lastUsedAt: new Date(now), revokedAt: null, revokedReason: null, replacedBy: null, userAgent };
      sessions.push(s);
      return { sessionId: s.id, familyId: s.familyId, expiresAt: s.expiresAt };
    },
    async findActiveByFamily(familyId, userId): Promise<ActiveSession | null> {
      counters.findActive += 1;
      const s = sessions.find((x) => x.familyId === familyId && x.userId === userId && live(x));
      if (!s) return null;
      const u = users.find((x) => x.id === s.userId);
      if (!u || !canSignIn(u)) return null;
      return { sessionId: s.id, familyId: s.familyId, lastUsedAt: s.lastUsedAt, user: publicRow(u) };
    },
    async rotate({ presentedHash, newHash, userAgent }): Promise<RotateOutcome> {
      counters.rotate += 1;
      const old = sessions.find((x) => x.tokenHash.equals(presentedHash));
      if (!old) return { kind: 'rejected' };
      if (old.revokedAt !== null) {
        if (old.revokedReason !== 'rotated') return { kind: 'rejected' };
        for (const s of sessions) if (s.familyId === old.familyId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'reuse_detected'; }
        return { kind: 'reuse', userId: old.userId };
      }
      const u = users.find((x) => x.id === old.userId);
      if (old.expiresAt.getTime() <= clock.now() || !u || !canSignIn(u)) return { kind: 'rejected' };
      const fresh: FakeSession = { id: randomUUID(), userId: old.userId, tokenHash: newHash, familyId: old.familyId, createdAt: new Date(clock.now()), expiresAt: old.expiresAt, lastUsedAt: new Date(clock.now()), revokedAt: null, revokedReason: null, replacedBy: null, userAgent };
      sessions.push(fresh);
      old.revokedAt = new Date(clock.now());
      old.revokedReason = 'rotated';
      old.replacedBy = fresh.id;
      return { kind: 'rotated', user: publicRow(u), session: { sessionId: fresh.id, familyId: fresh.familyId, expiresAt: fresh.expiresAt } };
    },
    async revokeFamilyByTokenHash(tokenHash) {
      counters.revoke += 1;
      const any = sessions.find((x) => x.tokenHash.equals(tokenHash));
      if (!any) return false;
      let changed = false;
      for (const s of sessions) if (s.familyId === any.familyId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'logout'; changed = true; }
      return changed;
    },
    async revokeAllLive(userId, reason) {
      counters.revokeAllLive += 1;
      let n = 0;
      for (const s of sessions) if (s.userId === userId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = reason; n += 1; }
      return n;
    },
    async revokeFamilyLive(tokenHash) {
      counters.revoke += 1; // sign-out now goes through this method: the same "a sign-out reached the revocation" counter as before
      counters.revokeFamilyLive += 1;
      const hit = sessions.find((s) => s.tokenHash.equals(tokenHash));
      if (!hit) return 0;
      let n = 0;
      for (const s of sessions) if (s.familyId === hit.familyId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'logout'; n += 1; }
      return n;
    },
    async revokeAllForUser(userId, reason) {
      let n = 0;
      for (const s of sessions) if (s.userId === userId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = reason; n += 1; }
      return n;
    },
    async touch(sessionId) {
      counters.touch += 1;
      const s = sessions.find((x) => x.id === sessionId);
      if (s) s.lastUsedAt = new Date(clock.now());
    },
  };

  const otpRepo: OtpRepository = {
    async issue({ userId, phoneE164, purpose, codeHash }): Promise<IssueOutcome> {
      counters.otpIssue += 1;
      const now = clock.now();
      const mine = codes.filter((c) => c.userId === userId && c.purpose === purpose);
      const lastHour = mine.filter((c) => c.createdAt.getTime() > now - 3600_000).length;
      const lastDay = mine.filter((c) => c.createdAt.getTime() > now - 86_400_000).length;
      const newest = mine.reduce((m, c) => Math.max(m, c.createdAt.getTime()), 0);
      const cooldownLeft = mine.length > 0 ? Math.ceil((newest + OTP.cooldownSeconds * 1000 - now) / 1000) : 0;
      if (cooldownLeft > 0) return { kind: 'throttled', retryAfterSeconds: cooldownLeft };
      if (lastHour >= OTP.perHour) return { kind: 'throttled', retryAfterSeconds: 3600 };
      if (lastDay >= OTP.perDay) return { kind: 'throttled', retryAfterSeconds: 86_400 };
      if (faults.otpUniqueViolation) {
        faults.otpUniqueViolation = false;
        throw new DbError('unique', { sqlstate: '23505', constraint: 'vcodes_one_active_uq', driverMessage: 'duplicate key value violates unique constraint "vcodes_one_active_uq"' });
      }
      for (const c of mine) if (c.consumedAt === null && c.invalidatedAt === null) c.invalidatedAt = new Date(now);
      const fresh: FakeCode = { id: randomUUID(), userId, purpose, phone: phoneE164, hash: codeHash, attempts: 0, maxAttempts: OTP.maxAttempts, createdAt: new Date(now), expiresAt: new Date(now + OTP.ttlSeconds * 1000), consumedAt: null, invalidatedAt: null };
      codes.push(fresh);
      return { kind: 'issued', codeId: fresh.id, expiresAt: fresh.expiresAt };
    },
    async verify({ userId, phoneE164, purpose, expectedHash }): Promise<VerifyOutcome> {
      counters.otpVerify += 1;
      const row = codes.find((c) => c.userId === userId && c.purpose === purpose && c.phone === phoneE164 && c.consumedAt === null && c.invalidatedAt === null);
      if (!row) return { kind: 'rejected', reason: 'no_active_code' };
      if (row.expiresAt.getTime() <= clock.now()) return { kind: 'rejected', reason: 'expired' };
      if (row.attempts >= row.maxAttempts) return { kind: 'rejected', reason: 'attempts_exhausted' };
      if (hashesEqual(row.hash, expectedHash)) {
        row.consumedAt = new Date(clock.now());
        return { kind: 'verified' };
      }
      if (row.attempts < row.maxAttempts) row.attempts += 1;
      return { kind: 'rejected', reason: 'mismatch' };
    },
  };

  const auditRepo: AuditRepository = {
    async record(event) {
      assertAuditSafe(event); // the same guard the real repository applies
      if (faults.failNextAudit) {
        faults.failNextAudit = false;
        throw new Error('simulated audit insert failure');
      }
      audits.push({ ...event, id: audits.length + 1, occurredAt: new Date(clock.now()) });
    },
  };

  // ---- dealer lifecycle (Step 5.2): mirrors the SQL of src/dealers/repository.ts and the database triggers it relies on ----
  const showroomRow = (s: FakeShowroom): ShowroomRow => ({ id: s.id, ownerId: s.ownerId, name: s.name, status: s.status });
  const dealerOf = (u: FakeUser) => ({ id: u.id, name: u.name, phoneE164: u.phoneE164, status: u.status, phoneVerified: u.phoneVerifiedAt !== null, createdAt: u.createdAt });
  const dealerCounters = { lockActingAdmin: 0, lockDealer: 0, transition: 0, createShowroom: 0, list: 0, findOwn: 0 };
  const dealerFaults = { failNextShowroomCreate: false, showroomConflictOnce: false };
  const dealersRepo: DealerRepository = {
    async lockActingAdmin(adminId) {
      dealerCounters.lockActingAdmin += 1;
      return users.some((u) => u.id === adminId && u.role === 'admin' && u.status === 'active' && u.deletedAt === null);
    },
    async lockDealer(userId) {
      dealerCounters.lockDealer += 1;
      const u = users.find((x) => x.id === userId && x.role === 'dealer' && x.deletedAt === null);
      return u ? dealerOf(u) : null;
    },
    async transition(userId, t) {
      dealerCounters.transition += 1;
      const rule = TRANSITIONS[t];
      const u = users.find((x) => x.id === userId && x.role === 'dealer' && x.status === rule.from && x.deletedAt === null);
      if (!u) return false;
      u.status = rule.to;
      // the users_revoke_sessions trigger
      if (rule.to === 'suspended') for (const s of sessions) if (s.userId === userId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'user_suspended'; }
      return true;
    },
    async lockShowroomOfOwner(ownerId) {
      const s = showrooms.find((x) => x.ownerId === ownerId);
      return s ? showroomRow(s) : null;
    },
    async createApprovedShowroom({ ownerId, name, phoneE164, reviewerId }) {
      dealerCounters.createShowroom += 1;
      if (dealerFaults.failNextShowroomCreate) {
        dealerFaults.failNextShowroomCreate = false;
        throw new Error('simulated showroom insert failure');
      }
      const owner = users.find((u) => u.id === ownerId);
      // showrooms_owner_guard: the owner must be a dealer account
      if (!owner || owner.role !== 'dealer') throw new DbError('check', { sqlstate: '23514', driverMessage: 'showroom owner must be a dealer account' });
      if (dealerFaults.showroomConflictOnce) {
        // another transaction inserted this owner's showroom first: ON CONFLICT (owner_id) DO NOTHING returns no row
        dealerFaults.showroomConflictOnce = false;
        showrooms.push({ id: String(nextShowroomId++), ownerId, name: 'concurrent', phone: null, whatsapp: null, address: '', status: 'active', reviewedBy: null, reviewedAt: null, createdAt: new Date(clock.now()) });
        return null;
      }
      if (showrooms.some((s) => s.ownerId === ownerId)) return null; // ON CONFLICT (owner_id) DO NOTHING
      const s: FakeShowroom = { id: String(nextShowroomId++), ownerId, name, phone: phoneE164, whatsapp: phoneE164, address: '', status: 'active', reviewedBy: reviewerId, reviewedAt: new Date(clock.now()), createdAt: new Date(clock.now()) };
      showrooms.push(s);
      return showroomRow(s);
    },
    async approvePendingShowroom(showroomId, reviewerId) {
      const s = showrooms.find((x) => x.id === showroomId && x.status === 'pending');
      if (!s) return false;
      s.status = 'active';
      s.reviewedBy = reviewerId;
      s.reviewedAt = new Date(clock.now());
      return true;
    },
    async listDealers({ status, afterId, limit }) {
      dealerCounters.list += 1;
      return users
        .filter((u) => u.role === 'dealer' && u.deletedAt === null && u.status === status && (afterId === null || BigInt(u.id) > BigInt(afterId)))
        .sort((a, b) => (BigInt(a.id) < BigInt(b.id) ? -1 : 1))
        .slice(0, limit)
        .map((u) => {
          const s = showrooms.find((x) => x.ownerId === u.id);
          return { ...dealerOf(u), showroom: s ? { id: s.id, status: s.status } : null };
        });
    },
    async findOwnShowroom(ownerId) {
      dealerCounters.findOwn += 1;
      const s = showrooms.find((x) => x.ownerId === ownerId);
      return s ? { ...showroomRow(s), phone: s.phone, whatsapp: s.whatsapp, address: s.address, createdAt: s.createdAt } : null;
    },
  };
  const dealerStore: DealerStore = {
    dealers: dealersRepo,
    transaction(fn) {
      const run = txTail.then(() => runTransaction((r) => fn({ dealers: dealersRepo, sessions: r.sessions, audit: r.audit })));
      txTail = run.then(() => undefined, () => undefined);
      return run;
    },
  };

  const store: AuthStore = {
    users: usersRepo,
    sessions: sessionsRepo,
    // Transactions run ONE AT A TIME, like transactions that contend for the same locks: a rollback in PostgreSQL only undoes
    // its own writes, while this fake restores a snapshot, which would also erase a concurrent transaction's committed work.
    transaction(fn) {
      const run = txTail.then(() => runTransaction(fn));
      txTail = run.then(() => undefined, () => undefined);
      return run;
    },
  };
  let txTail: Promise<void> = Promise.resolve();
  async function runTransaction<T>(fn: (repos: { users: UsersRepository; sessions: SessionsRepository; otp: OtpRepository; audit: AuditRepository }) => Promise<T>): Promise<T> {
    {
      const snapshot = { users: users.map((u) => ({ ...u })), sessions: sessions.map((s) => ({ ...s })), codes: codes.map((c) => ({ ...c })), audits: audits.map((a) => ({ ...a })), showrooms: showrooms.map((s) => ({ ...s })), nextId, nextShowroomId };
      try {
        return await fn({ users: usersRepo, sessions: sessionsRepo, otp: otpRepo, audit: auditRepo });
      } catch (e) {
        users = snapshot.users;
        sessions = snapshot.sessions;
        codes = snapshot.codes;
        audits = snapshot.audits;
        showrooms = snapshot.showrooms;
        nextId = snapshot.nextId;
        nextShowroomId = snapshot.nextShowroomId;
        throw e;
      }
    }
  }

  return {
    store,
    dealerStore,
    counters,
    dealerCounters,
    faults,
    dealerFaults,
    showrooms: () => showrooms,
    /** Fixture: an account the application could never create itself (e.g. an administrator, made by the operations role). */
    addUser(fields: { role: 'user' | 'dealer' | 'admin'; status: 'active' | 'pending' | 'suspended'; name?: string; phoneE164?: string }) {
      const u: FakeUser = { id: String(nextId++), name: fields.name ?? 'حساب تجريبي', phoneE164: fields.phoneE164 ?? `+96477${String(10000000 + nextId).slice(-8)}`, role: fields.role, status: fields.status, phoneVerifiedAt: null, createdAt: new Date(clock.now()), passwordHash: '$argon2id$v=19$m=19456,t=2,p=1$fixture$fixture', failedLogins: 0, locked: false, lastLoginAt: null, deletedAt: null };
      users.push(u);
      return u.id;
    },
    /** Fixture: a showroom row as the operations role could insert it (e.g. one still pending review). */
    addShowroom(fields: { ownerId: string; status: 'active' | 'pending' | 'suspended'; name?: string }) {
      const s: FakeShowroom = { id: String(nextShowroomId++), ownerId: fields.ownerId, name: fields.name ?? 'معرض قائم', phone: null, whatsapp: null, address: '', status: fields.status, reviewedBy: null, reviewedAt: null, createdAt: new Date(clock.now()) };
      showrooms.push(s);
      return s.id;
    },
    users: () => users,
    sessions: () => sessions,
    codes: () => codes,
    audits: () => audits,
    /** everything the "database" holds, as text: used to prove secrets are not stored */
    dump: () => JSON.stringify({ users, sessions: sessions.map((s) => ({ ...s, tokenHash: s.tokenHash.toString('hex') })), codes: codes.map((c) => ({ ...c, hash: c.hash.toString('hex') })), audits }),
    unlock(userId: string) {
      const u = users.find((x) => x.id === userId);
      if (u) u.locked = false;
    },
    setStatus(userId: string, status: string) {
      const u = users.find((x) => x.id === userId);
      if (!u) return;
      u.status = status;
      if (status === 'suspended') for (const s of sessions) if (s.userId === userId && s.revokedAt === null) { s.revokedAt = new Date(clock.now()); s.revokedReason = 'user_suspended'; }
    },
    expireAllSessions() {
      for (const s of sessions) s.expiresAt = new Date(clock.now() - 1000);
    },
  };
}

export function recordingLogger() {
  const entries: unknown[] = [];
  const logger: Logger = {
    debug: (o) => entries.push(o),
    info: (o) => entries.push(o),
    warn: (o) => entries.push(o),
    error: (o) => entries.push(o),
  };
  return { logger, entries, text: () => JSON.stringify(entries) };
}

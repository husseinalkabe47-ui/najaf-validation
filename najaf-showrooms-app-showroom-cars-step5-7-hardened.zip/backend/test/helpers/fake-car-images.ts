// In-memory stand-in for the car-image store (Phase 11.5, Step 5.5). It mirrors, independently of src, what the SQL and the
// database do:
//  - the car is found by owner_id AND source_type = 'member' AND not deleted; the asset by owner_id; the image by (id AND car_id);
//  - the triggers of migration 0006 as BACKSTOPS that THROW if the service ever let a violation through: asset must be a ready
//    car_image, asset owner = car owner, per-car cap, UNIQUE(asset_id); and the deferred "images => exactly one main" check at
//    commit, plus contiguous-position expectations after a delete;
//  - transactions are all-or-nothing (snapshot/restore) and SERIALIZED per store (a stand-in for the car row lock FOR UPDATE);
//  - audit rows go through the real assertAuditSafe (numbers only).
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import { DbError } from '../../src/errors.ts';
import type { CarImageRepository, CarImageRow, CarImageStore, OwnAssetRow, OwnCarRow } from '../../src/car-images/repository.ts';

export interface FakeAsset {
  id: string;
  ownerId: string;
  kind: string;
  status: string;
  width: number;
  height: number;
  storageKey: string;
}
export interface FakeImage {
  id: string;
  carId: string;
  assetId: string;
  sortOrder: number;
  isMain: boolean;
  createdAt: Date;
}
export interface FakeImgCar {
  id: string;
  ownerId: string;
  sourceType: 'member' | 'showroom';
  status: string;
  deleted: boolean;
}

export function makeFakeCarImageStore(opts: { userState?: (id: string) => { status: string; deleted: boolean } | undefined } = {}) {
  const ownUsers = new Map<string, { status: string; deleted: boolean }>();
  const userState = opts.userState ?? ((id: string) => ownUsers.get(id));
  let cars: FakeImgCar[] = [];
  let assets: FakeAsset[] = [];
  let images: FakeImage[] = [];
  let audits: AuditEvent[] = [];
  let nextImage = 100;
  let nextAsset = 1;
  let cap = 4;
  const calls: string[] = [];
  const faults: { failNextAudit: boolean; afterLock: (() => void) | null } = { failNextAudit: false, afterLock: null };

  const live = (id: string) => {
    const u = userState(id);
    return u !== undefined && u.status === 'active' && !u.deleted;
  };
  const ownCar = (id: string, ownerId: string) => cars.find((c) => c.id === id && c.ownerId === ownerId && c.sourceType === 'member' && !c.deleted);
  const carView = (c: FakeImgCar): OwnCarRow => ({ id: c.id, ownerId: c.ownerId, status: c.status, ownerActive: live(c.ownerId) });
  const imageView = (i: FakeImage): CarImageRow => {
    const a = assets.find((x) => x.id === i.assetId)!;
    return { id: i.id, assetId: i.assetId, sortOrder: i.sortOrder, isMain: i.isMain, createdAt: i.createdAt, width: a.width, height: a.height };
  };
  const ordered = (carId: string) => images.filter((i) => i.carId === carId).sort((a, b) => a.sortOrder - b.sortOrder || Number(BigInt(a.id) - BigInt(b.id)));

  const repo: CarImageRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      return live(userId);
    },
    async findOwnCar(carId, ownerId) {
      calls.push('findOwnCar');
      const c = ownCar(carId, ownerId);
      return c ? carView(c) : null;
    },
    async lockOwnCar(carId, ownerId) {
      calls.push('lockOwnCar');
      const c = ownCar(carId, ownerId);
      if (c && faults.afterLock) {
        const f = faults.afterLock;
        faults.afterLock = null;
        f();
      }
      return c ? carView(c) : null;
    },
    async memberImageCap() {
      calls.push('memberImageCap');
      return cap;
    },
    async listImages(carId) {
      calls.push('listImages');
      return ordered(carId).map(imageView);
    },
    async findOwnAsset(assetId, ownerId): Promise<OwnAssetRow | null> {
      calls.push('findOwnAsset');
      const a = assets.find((x) => x.id === assetId && x.ownerId === ownerId);
      if (!a) return null;
      const att = images.find((i) => i.assetId === a.id);
      return { id: a.id, kind: a.kind, status: a.status, attachedCarId: att ? att.carId : null };
    },
    async countImages(carId) {
      calls.push('countImages');
      return images.filter((i) => i.carId === carId).length;
    },
    async insertImage(carId, assetId) {
      calls.push('insertImage');
      const car = cars.find((c) => c.id === carId);
      const a = assets.find((x) => x.id === assetId);
      // car_images_guard_bi, as the database enforces it
      if (!car) throw new DbError('foreign_key', { sqlstate: '23503' });
      if (!a || a.kind !== 'car_image' || a.status !== 'ready') throw new DbError('check', { sqlstate: '23514', driverMessage: 'asset must be a ready car_image' });
      if (a.ownerId !== car.ownerId) throw new DbError('forbidden', { sqlstate: '42501', driverMessage: 'asset belongs to another user' });
      if (images.filter((i) => i.carId === carId).length >= cap) throw new DbError('check', { sqlstate: '23514', driverMessage: 'image limit reached' });
      if (images.some((i) => i.assetId === assetId)) throw new DbError('unique', { sqlstate: '23505', constraint: 'car_images_asset_uq' });
      const mine = images.filter((i) => i.carId === carId);
      const img: FakeImage = { id: String(nextImage++), carId, assetId, sortOrder: mine.length === 0 ? 0 : Math.max(...mine.map((i) => i.sortOrder)) + 1, isMain: mine.length === 0, createdAt: new Date(Date.UTC(2026, 0, 1)) };
      images.push(img);
      return imageView(img);
    },
    async deleteImage(imageId, carId) {
      calls.push('deleteImage');
      const i = images.find((x) => x.id === imageId && x.carId === carId);
      if (!i) return null;
      images = images.filter((x) => x !== i);
      return { wasMain: i.isMain };
    },
    async repairLayout(carId) {
      calls.push('repairLayout');
      const mine = ordered(carId);
      if (mine.length > 0 && !mine.some((i) => i.isMain)) mine[0]!.isMain = true;
      mine.forEach((i, n) => (i.sortOrder = n));
    },
  };

  /** The deferred constraint trigger car_images_require_main, evaluated at commit. */
  const commitCheck = () => {
    for (const carId of new Set(images.map((i) => i.carId))) {
      const mine = images.filter((i) => i.carId === carId);
      if (mine.filter((i) => i.isMain).length !== 1) throw new DbError('check', { sqlstate: '23514', driverMessage: `car ${carId} must have exactly one main image` });
      const positions = mine.map((i) => i.sortOrder).sort((a, b) => a - b);
      if (new Set(positions).size !== positions.length) throw new DbError('unique', { sqlstate: '23505', constraint: 'car_images_order_uq' });
    }
  };

  let chain: Promise<unknown> = Promise.resolve();
  const store: CarImageStore = {
    images: repo,
    transaction(fn) {
      const run = async () => {
        const snap = JSON.stringify({ images, audits, nextImage });
        const audit = {
          async record(event: AuditEvent) {
            if (faults.failNextAudit) {
              faults.failNextAudit = false;
              throw new Error('audit insert failed');
            }
            assertAuditSafe(event);
            audits.push(event);
          },
        };
        try {
          const out = await fn({ images: repo, audit });
          commitCheck();
          return out;
        } catch (e) {
          const s = JSON.parse(snap) as { images: FakeImage[]; audits: AuditEvent[]; nextImage: number };
          images = s.images.map((i) => ({ ...i, createdAt: new Date(i.createdAt) }));
          audits = s.audits;
          nextImage = s.nextImage;
          throw e;
        }
      };
      const result = chain.then(run, run);
      chain = result.catch(() => undefined);
      return result;
    },
  };

  return {
    store,
    calls,
    faults,
    images: () => images,
    imagesOf: (carId: string) => ordered(carId),
    audits: () => audits,
    assets: () => assets,
    setCap(n: number) {
      cap = n;
    },
    addUser(id: string, status = 'active', deleted = false) {
      ownUsers.set(id, { status, deleted });
    },
    setUser(id: string, status: string, deleted = false) {
      ownUsers.set(id, { status, deleted });
    },
    addCar(fields: Partial<FakeImgCar> & { ownerId: string; id?: string }): FakeImgCar {
      const c: FakeImgCar = { id: fields.id ?? String(7000 + cars.length), sourceType: 'member', status: 'pending', deleted: false, ...fields };
      cars.push(c);
      return c;
    },
    addAsset(fields: Partial<FakeAsset> & { ownerId: string }): FakeAsset {
      const n = nextAsset++;
      const a: FakeAsset = {
        id: `0000abcd-0000-4000-8000-ef${String(n).padStart(10, '0')}`, kind: 'car_image', status: 'ready', width: 1200, height: 800,
        storageKey: `private/key-${n}.webp`, ...fields,
      };
      assets.push(a);
      return a;
    },
    /** Fixture: attach directly (as a previous request would have). */
    attach(carId: string, assetId: string) {
      const mine = images.filter((i) => i.carId === carId);
      images.push({ id: String(nextImage++), carId, assetId, sortOrder: mine.length, isMain: mine.length === 0, createdAt: new Date(Date.UTC(2026, 0, 1)) });
    },
  };
}
export type FakeCarImageStore = ReturnType<typeof makeFakeCarImageStore>;

// Integration tests need a real PostgreSQL 16 with the validated migrations applied (database/migrations 0001-0013):
//   DATABASE_URL        postgres://najaf_app_login:...@host:5432/najaf   (the least-privilege login role the backend uses)
//   ADMIN_DATABASE_URL  postgres://postgres:...@host:5432/najaf          (superuser, ONLY for fixtures/cleanup/negative tests)
//   SEED_LOADED=1       (optional) the staging seed (database/seed) is loaded: enables the 3 showrooms / 115 cars check
// Without the two URLs every integration suite is SKIPPED, visibly.
import { loadConfig } from '../../src/config.ts';
import type { DbConfig } from '../../src/config.ts';

export const APP_URL = process.env['DATABASE_URL'];
export const ADMIN_URL = process.env['ADMIN_DATABASE_URL'];
export const enabled = Boolean(APP_URL && ADMIN_URL);
export const skip: string | false = enabled ? false : 'integration tests need DATABASE_URL (app login role) and ADMIN_DATABASE_URL (superuser)';
export const seedLoaded = process.env['SEED_LOADED'] === '1';

export function appConfig(overrides: Record<string, string | undefined> = {}): DbConfig {
  return loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL, ...overrides }).db;
}

// The admin handle bypasses the role policy on purpose: it is only used for fixtures, cleanup and negative tests.
export function adminConfig(overrides: Record<string, string | undefined> = {}): DbConfig {
  return loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: ADMIN_URL, DB_REQUIRE_APP_ROLE: 'false', ...overrides }).db;
}

export function withPassword(url: string, password: string): string {
  const u = new URL(url);
  u.password = password;
  return u.toString();
}

export class Rollback extends Error {
  constructor() {
    super('intentional rollback');
    this.name = 'Rollback';
  }
}

// In-memory stand-in for the catalog repository (Phase 11.5, Step 5.3). It keeps BASE records (users, showrooms, cars, with their
// statuses and deleted flags) and derives the public rows with the SAME predicates the database views use:
//   public_showrooms: showroom active AND not deleted AND owner active AND owner not deleted
//   public_cars:      not deleted AND ( showroom car in a public showroom
//                                       OR member car with status active and an active, not deleted owner )
// The fake records every repository call, so tests can assert which queries were (or were not) issued.
import type { CarListQuery, ShowroomListQuery } from '../../src/catalog/params.ts';
import type { CatalogRepository, PublicCarRow, PublicShowroomRow } from '../../src/catalog/repository.ts';

export interface FakeUser {
  id: string;
  status: string;
  deleted: boolean;
}
export interface FakeShowroom {
  id: string;
  ownerId: string;
  status: string;
  deleted: boolean;
  name: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  address: string;
  latitude: string | null;
  longitude: string | null;
  workingHours: string;
  services: string[];
  searchText: string;
}
export interface FakeCar {
  id: string;
  sourceType: 'showroom' | 'member';
  showroomId: string | null;
  ownerId: string;
  status: string;
  deleted: boolean;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  location: string;
  latitude: string | null;
  longitude: string | null;
  ownerName: string | null;
  searchText: string;
}

const T0 = new Date('2026-01-01T00:00:00.000Z');

export function makeFakeCatalog() {
  const users = new Map<string, FakeUser>();
  const showrooms = new Map<string, FakeShowroom>();
  const cars = new Map<string, FakeCar>();
  const calls: string[] = [];
  let next = 1000;
  const newId = () => String(next++);

  const ownerLive = (uid: string): boolean => {
    const u = users.get(uid);
    return u !== undefined && u.status === 'active' && !u.deleted;
  };
  const showroomIsPublic = (s: FakeShowroom): boolean => s.status === 'active' && !s.deleted && ownerLive(s.ownerId);
  const carIsPublic = (c: FakeCar): boolean => {
    if (c.deleted) return false;
    if (c.sourceType === 'showroom') {
      const s = c.showroomId === null ? undefined : showrooms.get(c.showroomId);
      return s !== undefined && showroomIsPublic(s);
    }
    return c.status === 'active' && ownerLive(c.ownerId);
  };

  const showroomRow = (s: FakeShowroom): PublicShowroomRow => ({
    id: s.id,
    name: s.name,
    description: s.description,
    phone: s.phone,
    whatsapp: s.whatsapp,
    address: s.address,
    latitude: s.latitude,
    longitude: s.longitude,
    working_hours: s.workingHours,
    services: [...s.services],
    created_at: T0,
    updated_at: T0,
  });
  const carRow = (c: FakeCar): PublicCarRow => ({
    id: c.id,
    source_type: c.sourceType,
    showroom_id: c.showroomId,
    brand: c.brand,
    model: c.model,
    year: c.year,
    price: c.price,
    currency: c.currency,
    mileage: c.mileage,
    transmission: c.transmission,
    fuel_type: c.fuelType,
    color: c.color,
    description: c.description,
    status: c.status,
    phone: c.phone,
    whatsapp: c.whatsapp,
    location: c.location,
    latitude: c.latitude,
    longitude: c.longitude,
    owner_name: c.sourceType === 'member' ? c.ownerName : null,
    created_at: T0,
    updated_at: T0,
  });

  const matchTerms = (terms: readonly string[], columns: readonly string[]): boolean =>
    terms.every((t) => columns.some((c) => c.toLowerCase().includes(t)));
  const byIdDesc = (a: { id: string }, b: { id: string }) => (BigInt(b.id) > BigInt(a.id) ? 1 : BigInt(b.id) < BigInt(a.id) ? -1 : 0);
  const eqCI = (a: string, b: string) => a.toLowerCase() === b.toLowerCase();

  const repo: CatalogRepository = {
    async listShowrooms(q: ShowroomListQuery) {
      calls.push('listShowrooms');
      return [...showrooms.values()]
        .filter((s) => showroomIsPublic(s))
        .filter((s) => matchTerms(q.terms, [s.name, s.address, s.searchText]))
        .filter((s) => q.page.before === null || BigInt(s.id) < BigInt(q.page.before))
        .sort(byIdDesc)
        .slice(0, q.page.limit)
        .map(showroomRow);
    },
    async findShowroom(id) {
      calls.push('findShowroom');
      const s = showrooms.get(id);
      return s !== undefined && showroomIsPublic(s) ? showroomRow(s) : null;
    },
    async listCars(q: CarListQuery) {
      calls.push('listCars');
      return [...cars.values()]
        .filter((c) => carIsPublic(c))
        .filter((c) => matchTerms(q.terms, [c.brand, c.model, c.color, c.searchText]))
        .filter((c) => q.page.before === null || BigInt(c.id) < BigInt(q.page.before))
        .filter((c) => q.source === null || c.sourceType === q.source)
        .filter((c) => q.showroomId === null || c.showroomId === q.showroomId)
        .filter((c) => q.brand === null || eqCI(c.brand, q.brand))
        .filter((c) => q.model === null || eqCI(c.model, q.model))
        .filter((c) => q.color === null || eqCI(c.color, q.color))
        .filter((c) => q.transmission === null || c.transmission === q.transmission)
        .filter((c) => q.fuelType === null || c.fuelType === q.fuelType)
        .filter((c) => q.status === null || c.status === q.status)
        .filter((c) => q.yearMin === null || c.year >= q.yearMin)
        .filter((c) => q.yearMax === null || c.year <= q.yearMax)
        .filter((c) => q.currency === null || c.currency === q.currency)
        .filter((c) => q.priceMin === null || Number(c.price) >= q.priceMin)
        .filter((c) => q.priceMax === null || Number(c.price) <= q.priceMax)
        .sort(byIdDesc)
        .slice(0, q.page.limit)
        .map(carRow);
    },
    async findCar(id) {
      calls.push('findCar');
      const c = cars.get(id);
      return c !== undefined && carIsPublic(c) ? carRow(c) : null;
    },
  };

  function addUser(p: Partial<FakeUser> = {}): FakeUser {
    const u: FakeUser = { id: p.id ?? newId(), status: 'active', deleted: false, ...p };
    users.set(u.id, u);
    return u;
  }
  function addShowroom(p: Partial<FakeShowroom> & { ownerId: string }): FakeShowroom {
    const s: FakeShowroom = {
      id: p.id ?? newId(),
      status: 'active',
      deleted: false,
      name: 'معرض الاختبار',
      description: 'وصف',
      phone: '+9647700000001',
      whatsapp: '+9647700000001',
      address: 'بغداد',
      latitude: null,
      longitude: null,
      workingHours: '9-5',
      services: ['بيع'],
      searchText: '',
      ...p,
    };
    showrooms.set(s.id, s);
    return s;
  }
  function addCar(p: Partial<FakeCar> & { ownerId: string }): FakeCar {
    const c: FakeCar = {
      id: p.id ?? newId(),
      sourceType: 'showroom',
      showroomId: null,
      status: 'available',
      deleted: false,
      brand: 'Toyota',
      model: 'Camry',
      year: 2015,
      price: '12000',
      currency: 'USD',
      mileage: 90000,
      transmission: 'أوتوماتيك',
      fuelType: 'بنزين',
      color: 'أبيض',
      description: 'وصف السيارة',
      phone: '+9647700000002',
      whatsapp: '+9647700000002',
      location: 'أربيل',
      latitude: null,
      longitude: null,
      ownerName: null,
      searchText: '',
      ...p,
    };
    cars.set(c.id, c);
    return c;
  }

  return { repo, users, showrooms, cars, calls, addUser, addShowroom, addCar, showroomRow, carRow };
}

export type FakeCatalog = ReturnType<typeof makeFakeCatalog>;

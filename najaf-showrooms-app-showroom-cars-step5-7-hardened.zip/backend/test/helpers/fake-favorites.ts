// In-memory stand-in for the favorites store (Phase 11.5, Step 5.6). It mirrors, independently of src, what the SQL and the
// database do:
//  - public_cars: not deleted AND (a showroom car of a public showroom OR an ACTIVE member car of an active, not deleted owner);
//  - insert = INSERT ... SELECT FROM public_cars ON CONFLICT (user_id, car_id) DO NOTHING (never a second row, never a hidden car);
//  - list = favorites JOIN public_cars, scoped by user, keyset on the favorites id, newest first; delete scoped by user and car;
//  - the soft-delete trigger removes the favorites of a deleted car;
//  - transactions are all-or-nothing (snapshot/restore) and SERIALIZED per store; audit rows go through the real assertAuditSafe.
import { assertAuditSafe } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import type { PublicCarRow } from '../../src/catalog/repository.ts';
import type { FavoriteListRow, FavoriteRepository, FavoriteRow, FavoriteStore } from '../../src/favorites/repository.ts';

export interface FakeFavCar {
  id: string;
  sourceType: 'member' | 'showroom';
  status: string;
  deleted: boolean;
  /** member car: the owner; showroom car: unused */
  ownerId: string;
  showroomPublic: boolean;
  brand: string;
}
export interface FakeFavorite {
  id: string;
  userId: string;
  carId: string;
  createdAt: Date;
}

export function makeFakeFavoriteStore(opts: { userState?: (id: string) => { status: string; deleted: boolean } | undefined } = {}) {
  const users = new Map<string, { status: string; deleted: boolean }>();
  let cars: FakeFavCar[] = [];
  let favs: FakeFavorite[] = [];
  let audits: AuditEvent[] = [];
  let nextFav = 100;
  let clockMs = Date.UTC(2026, 0, 1);
  const calls: string[] = [];
  const faults: { failNextAudit: boolean; afterLockCar: (() => void) | null } = { failNextAudit: false, afterLockCar: null };

  const liveUser = (id: string) => {
    const u = (opts.userState ?? ((x: string) => users.get(x)))(id);
    return u !== undefined && u.status === 'active' && !u.deleted;
  };
  const isPublic = (c: FakeFavCar) => !c.deleted && (c.sourceType === 'showroom' ? c.showroomPublic : c.status === 'active' && liveUser(c.ownerId));
  const carRow = (c: FakeFavCar): PublicCarRow => ({
    id: c.id, source_type: c.sourceType, showroom_id: c.sourceType === 'showroom' ? '9' : null, brand: c.brand, model: 'Corolla', year: 2016, price: '14500',
    currency: 'USD', mileage: null, transmission: 'أوتوماتيك', fuel_type: 'بنزين', color: 'أبيض', description: '', status: c.status, phone: '+9647701234567',
    whatsapp: null, location: 'النجف', latitude: null, longitude: null, owner_name: c.sourceType === 'member' ? 'عضو' : null,
    created_at: new Date(Date.UTC(2026, 0, 1)), updated_at: new Date(Date.UTC(2026, 0, 1)),
  });
  const fav = (f: FakeFavorite): FavoriteRow => ({ carId: f.carId, createdAt: f.createdAt });

  const repo: FavoriteRepository = {
    async lockActingUser(userId) {
      calls.push('lockActingUser');
      return liveUser(userId);
    },
    async lockLiveCar(carId) {
      calls.push('lockLiveCar');
      const c = cars.find((x) => x.id === carId && !x.deleted);
      if (c && faults.afterLockCar) {
        const f = faults.afterLockCar;
        faults.afterLockCar = null;
        f();
      }
      return c !== undefined;
    },
    async insertIfPublic(userId, carId) {
      calls.push('insertIfPublic');
      const c = cars.find((x) => x.id === carId);
      if (!c || !isPublic(c)) return null;
      if (favs.some((f) => f.userId === userId && f.carId === carId)) return null; // ON CONFLICT DO NOTHING
      const f: FakeFavorite = { id: String(nextFav++), userId, carId, createdAt: new Date((clockMs += 1000)) };
      favs.push(f);
      return fav(f);
    },
    async findPublic(userId, carId) {
      calls.push('findPublic');
      const f = favs.find((x) => x.userId === userId && x.carId === carId);
      const c = cars.find((x) => x.id === carId);
      return f && c && isPublic(c) ? fav(f) : null;
    },
    async remove(userId, carId) {
      calls.push('remove');
      const n = favs.length;
      favs = favs.filter((f) => !(f.userId === userId && f.carId === carId));
      return favs.length < n;
    },
    async list(userId, q): Promise<FavoriteListRow[]> {
      calls.push('list');
      return favs
        .filter((f) => f.userId === userId && (q.before === null || BigInt(f.id) < BigInt(q.before)))
        .filter((f) => isPublic(cars.find((c) => c.id === f.carId)!))
        .sort((a, b) => Number(BigInt(b.id) - BigInt(a.id)))
        .slice(0, q.limit)
        .map((f) => ({ cursor: f.id, favoritedAt: f.createdAt, car: carRow(cars.find((c) => c.id === f.carId)!) }));
    },
  };

  let chain: Promise<unknown> = Promise.resolve();
  const store: FavoriteStore = {
    favorites: repo,
    transaction(fn) {
      const run = async () => {
        const snap = JSON.stringify({ favs, audits, nextFav });
        const audit = {
          async record(event: AuditEvent) {
            if (faults.failNextAudit) {
              faults.failNextAudit = false;
              throw new Error('audit insert failed');
            }
            assertAuditSafe(event);
            audits.push(event);
          },
        };
        try {
          return await fn({ favorites: repo, audit });
        } catch (e) {
          const s = JSON.parse(snap) as { favs: FakeFavorite[]; audits: AuditEvent[]; nextFav: number };
          favs = s.favs.map((f) => ({ ...f, createdAt: new Date(f.createdAt) }));
          audits = s.audits;
          nextFav = s.nextFav;
          throw e;
        }
      };
      const result = chain.then(run, run);
      chain = result.catch(() => undefined);
      return result;
    },
  };

  return {
    store,
    calls,
    faults,
    favorites: () => favs,
    favoritesOf: (userId: string) => favs.filter((f) => f.userId === userId),
    audits: () => audits,
    addUser(id: string, status = 'active', deleted = false) {
      users.set(id, { status, deleted });
    },
    setUser(id: string, status: string, deleted = false) {
      users.set(id, { status, deleted });
    },
    addCar(fields: Partial<FakeFavCar> = {}): FakeFavCar {
      const c: FakeFavCar = { id: String(7000 + cars.length), sourceType: 'showroom', status: 'available', deleted: false, ownerId: '900', showroomPublic: true, brand: 'Toyota', ...fields };
      cars.push(c);
      return c;
    },
    /** The cars soft-delete trigger: the car is deleted and its favorites are removed. */
    softDelete(carId: string) {
      cars.find((c) => c.id === carId)!.deleted = true;
      favs = favs.filter((f) => f.carId !== carId);
    },
    /** A status change that hides a car WITHOUT deleting it (no trigger): the favorite row stays. */
    setCar(carId: string, fields: Partial<FakeFavCar>) {
      Object.assign(cars.find((c) => c.id === carId)!, fields);
    },
    /** Fixture: a favorite that already exists. */
    addFavorite(userId: string, carId: string) {
      favs.push({ id: String(nextFav++), userId, carId, createdAt: new Date((clockMs += 1000)) });
    },
  };
}
export type FakeFavoriteStore = ReturnType<typeof makeFakeFavoriteStore>;

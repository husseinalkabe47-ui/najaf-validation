// Phase 11.5, Step 5.2: the dealer HTTP layer, run WITHOUT Fastify. The routes are registered on a recording stand-in, and the
// handlers are called with plain request objects, wired to the REAL authentication service, policy layer and dealer service
// (in-memory store). Plus static guards over the new source files.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { mayAuthenticate } from '../../src/auth/account-state.ts';
import { RATE_LIMITS } from '../../src/auth/policy.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthError } from '../../src/auth/types.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { ADMIN_DEALER_ACTIONS, DEALER_RATE_LIMITS, assertNoBody, registerDealerRoutes, toDealerHttp } from '../../src/dealers/routes.ts';
import { DealerError, createDealerService } from '../../src/dealers/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const lifecycle = createDealerService({ store: db.dealerStore, logger: log.logger });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerDealerRoutes({ get: add('GET'), post: add('POST') } as never, { auth, registration: auth, dealers: lifecycle, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  async function adminToken() {
    const p = phone();
    const r = await auth.register({ name: 'مدير النظام', phone: p, password: PW });
    db.users().find((u) => u.id === r.user.id)!.role = 'admin'; // only the operations role can make an admin; this is that fixture
    return { id: r.user.id, token: r.session.accessToken };
  }
  async function applyDealer(name = 'حسين التاجر') {
    const p = phone();
    const sent = await call('POST', '/v1/dealers/register', { headers: { 'content-type': 'application/json' }, body: { name, phone: p, password: PW } });
    const body = sent.body as { user: { id: string }; session: { accessToken: string } };
    return { id: body.user.id, token: body.session.accessToken, phone: p, sent };
  }
  async function member() {
    const r = await auth.register({ name: 'عضو عادي', phone: phone(), password: PW });
    return { id: r.user.id, token: r.session.accessToken };
  }
  const action = (act: string, id: string, token?: string, extra: Record<string, unknown> = {}) =>
    call('POST', `/v1/admin/dealers/:id/${act}`, { params: { id }, ...(token ? { headers: bearer(token) } : {}), ...extra });
  return { db, auth, lifecycle, routes, call, bearer, adminToken, applyDealer, member, action, phone, log, clock };
}
const errorCode = (s: Sent) => (s.body as { error?: { code?: string } }).error?.code;

describe('dealer routes: wiring', () => {
  it('registers exactly seven routes', () => {
    const { routes } = setup();
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [
      'GET /v1/admin/dealers',
      'GET /v1/dealer/showroom',
      'POST /v1/admin/dealers/:id/approve',
      'POST /v1/admin/dealers/:id/reactivate',
      'POST /v1/admin/dealers/:id/reject',
      'POST /v1/admin/dealers/:id/suspend',
      'POST /v1/dealers/register',
    ]);
    assert.deepEqual([...ADMIN_DEALER_ACTIONS], ['approve', 'reject', 'suspend', 'reactivate']);
  });

  it('registration: 4 KiB body limit, the SHARED registration rate limit first, the JSON-only hook second', async () => {
    const s = setup(true);
    const route = s.routes.find((r) => r.path === '/v1/dealers/register')!;
    assert.equal(route.opts?.bodyLimit, 4096);
    assert.equal(route.opts?.onRequest?.length, 2);
    // one budget for both kinds of sign-up: dealer applications count against the member registration limit and vice versa
    for (let i = 0; i < RATE_LIMITS.register.limit; i++) {
      const sent = await s.call('POST', '/v1/dealers/register', { headers: { 'content-type': 'application/json' }, body: { name: 'تاجر', phone: s.phone(), password: PW } });
      assert.equal(sent.status, 201);
    }
    const limited = await s.call('POST', '/v1/dealers/register', { headers: { 'content-type': 'application/json' }, body: { name: 'تاجر', phone: s.phone(), password: PW } });
    assert.equal(limited.status, 429);
    assert.ok(Number(limited.headers['retry-after']) > 0);
  });

  it('non-JSON bodies are refused with 415 before anything runs', async () => {
    const s = setup();
    for (const ct of ['text/plain', 'application/x-www-form-urlencoded', 'multipart/form-data']) {
      const sent = await s.call('POST', '/v1/dealers/register', { headers: { 'content-type': ct }, body: 'name=x' });
      assert.equal(sent.status, 415);
      const act = await s.action('approve', '1', undefined, { headers: { 'content-type': ct } });
      assert.equal(act.status, 415);
    }
    assert.equal(s.db.users().length, 0);
  });

  it('admin routes and the dealer area have their own per-address limits (429 + Retry-After)', async () => {
    const s = setup(true);
    for (let i = 0; i < DEALER_RATE_LIMITS.adminDealerAction.limit; i++) assert.equal((await s.action('approve', '1')).status, 401);
    const limited = await s.action('approve', '1');
    assert.equal(limited.status, 429);
    assert.ok(Number(limited.headers['retry-after']) > 0);
    for (const r of Object.values(DEALER_RATE_LIMITS)) assert.ok(r.limit >= 1 && r.windowSeconds >= 60);
  });
});

describe('dealer routes: end to end without Fastify', () => {
  it('POST /v1/dealers/register -> 201, a pending dealer with a session; extra fields -> 400 and nothing created', async () => {
    const s = setup();
    const d = await s.applyDealer();
    assert.equal(d.sent.status, 201);
    const body = d.sent.body as { user: { role: string; status: string } };
    assert.equal(body.user.role, 'dealer');
    assert.equal(body.user.status, 'pending');
    const bad = await s.call('POST', '/v1/dealers/register', { headers: { 'content-type': 'application/json' }, body: { name: 'تاجر', phone: s.phone(), password: PW, role: 'admin', status: 'active' } });
    assert.equal(bad.status, 400);
    assert.equal(errorCode(bad), 'validation_failed');
    assert.deepEqual(bad.body, { error: { code: 'validation_failed', message: 'The submitted data is not valid', fields: [{ field: 'role', code: 'unknown_field' }, { field: 'status', code: 'unknown_field' }], requestId: 'req-abcdef01' } });
    const dup = await s.call('POST', '/v1/dealers/register', { headers: { 'content-type': 'application/json' }, body: { name: 'تاجر', phone: d.phone, password: PW } });
    assert.equal(dup.status, 409);
    assert.equal(s.db.users().length, 1);
  });

  it('no token / bad token -> 401 with WWW-Authenticate on every protected route, and nothing is called', async () => {
    const s = setup();
    for (const headers of [{}, { authorization: 'Bearer garbage' }, { authorization: 'Basic abc' }]) {
      for (const [m, p, extra] of [['GET', '/v1/dealer/showroom', {}], ['GET', '/v1/admin/dealers', {}], ...ADMIN_DEALER_ACTIONS.map((a) => ['POST', `/v1/admin/dealers/:id/${a}`, { params: { id: '1' } }])] as Array<[string, string, Record<string, unknown>]>) {
        const sent = await s.call(m, p, { headers, ...extra });
        assert.equal(sent.status, 401, `${m} ${p}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
        assert.equal(errorCode(sent), 'unauthorized');
      }
    }
    assert.equal(s.db.dealerCounters.lockDealer + s.db.dealerCounters.list + s.db.dealerCounters.findOwn, 0);
  });

  it('PENDING dealer: authenticated, but 404 on the dealer area and on every admin route', async () => {
    const s = setup();
    const d = await s.applyDealer();
    const other = await s.applyDealer('تاجر آخر');
    assert.equal((await s.call('GET', '/v1/dealer/showroom', { headers: s.bearer(d.token) })).status, 404);
    assert.equal((await s.call('GET', '/v1/admin/dealers', { headers: s.bearer(d.token) })).status, 404);
    for (const a of ADMIN_DEALER_ACTIONS) {
      for (const target of [d.id, other.id]) {
        const sent = await s.action(a, target, d.token);
        assert.equal(sent.status, 404, `${a} ${target}`);
        assert.deepEqual(sent.body, { error: { code: 'not_found', message: 'Not found', requestId: 'req-abcdef01' } });
      }
    }
    assert.equal(s.db.users().find((u) => u.id === d.id)!.status, 'pending');
  });

  it('the admin lifecycle over HTTP: list -> approve -> dealer area works with the SAME token -> suspend -> 401 -> reactivate', async () => {
    const s = setup();
    const admin = await s.adminToken();
    const d = await s.applyDealer('حسين التاجر');
    const list = await s.call('GET', '/v1/admin/dealers', { headers: s.bearer(admin.token), query: { status: 'pending' } });
    assert.equal(list.status, 200);
    assert.deepEqual((list.body as { dealers: Array<{ id: string }> }).dealers.map((x) => x.id), [d.id]);

    const approved = await s.action('approve', d.id, admin.token, { headers: { ...s.bearer(admin.token), 'x-request-id': 'ignored-here' } });
    assert.equal(approved.status, 200);
    const dealer = (approved.body as { dealer: { status: string; showroom: { status: string } } }).dealer;
    assert.equal(dealer.status, 'active');
    assert.equal(dealer.showroom.status, 'active');
    assert.equal(s.db.audits().at(-1)!.requestId, 'req-abcdef01', 'the request id reaches the audit row');

    const own = await s.call('GET', '/v1/dealer/showroom', { headers: s.bearer(d.token) });
    assert.equal(own.status, 200);
    assert.deepEqual(Object.keys((own.body as { showroom: object }).showroom).sort(), ['address', 'createdAt', 'id', 'name', 'phone', 'status', 'whatsapp']);
    assert.equal((own.body as { showroom: { name: string } }).showroom.name, 'معرض حسين التاجر');

    const again = await s.action('approve', d.id, admin.token);
    assert.equal(again.status, 409);
    assert.equal(errorCode(again), 'invalid_state');

    assert.equal((await s.action('suspend', d.id, admin.token)).status, 200);
    assert.equal((await s.call('GET', '/v1/dealer/showroom', { headers: s.bearer(d.token) })).status, 401, 'suspension ended the session');
    assert.equal((await s.action('reactivate', d.id, admin.token)).status, 200);
    const login = await s.auth.login({ phone: d.phone, password: PW });
    assert.equal((await s.call('GET', '/v1/dealer/showroom', { headers: s.bearer(login.session.accessToken) })).status, 200);
  });

  it('an admin action accepts NO input: any body field (role, status, ownerId, ...) is 400 and nothing changes', async () => {
    const s = setup();
    const admin = await s.adminToken();
    const d = await s.applyDealer();
    for (const body of [{ role: 'admin' }, { status: 'active' }, { ownerId: '1' }, { showroomId: '1' }, [], 'x', 5]) {
      const sent = await s.action('approve', d.id, admin.token, { headers: { ...s.bearer(admin.token), 'content-type': 'application/json' }, body });
      assert.equal(sent.status, 400, JSON.stringify(body));
    }
    assert.equal(s.db.users().find((u) => u.id === d.id)!.status, 'pending');
    assert.equal((await s.action('approve', d.id, admin.token, { body: {} })).status, 200, 'an empty object is "no input"');
  });

  it('the target is ONLY the :id path parameter; ids in the query or body are never used', async () => {
    const s = setup();
    const admin = await s.adminToken();
    const a = await s.applyDealer('تاجر أول');
    const b = await s.applyDealer('تاجر ثان');
    const sent = await s.call('POST', '/v1/admin/dealers/:id/approve', { headers: s.bearer(admin.token), params: { id: a.id }, query: { id: b.id } });
    assert.equal(sent.status, 200);
    assert.equal(s.db.users().find((u) => u.id === a.id)!.status, 'active');
    assert.equal(s.db.users().find((u) => u.id === b.id)!.status, 'pending');
    for (const params of [{}, { id: 'abc' }, { id: '0' }, { id: `${a.id} OR 1=1` }, undefined]) {
      assert.equal((await s.call('POST', '/v1/admin/dealers/:id/reject', { headers: s.bearer(admin.token), params })).status, 404);
    }
  });

  it('member and active dealer: 404 on admin routes; a dealer acting on ITSELF gets 403; members have no dealer area', async () => {
    const s = setup();
    const admin = await s.adminToken();
    const m = await s.member();
    const d = await s.applyDealer();
    await s.action('approve', d.id, admin.token);
    const login = await s.auth.login({ phone: d.phone, password: PW });
    const dealerToken = login.session.accessToken;
    const target = await s.applyDealer('هدف');
    for (const token of [m.token, dealerToken]) {
      assert.equal((await s.call('GET', '/v1/admin/dealers', { headers: s.bearer(token) })).status, 404);
      for (const a of ADMIN_DEALER_ACTIONS) assert.equal((await s.action(a, target.id, token)).status, 404);
    }
    for (const a of ADMIN_DEALER_ACTIONS) assert.equal((await s.action(a, d.id, dealerToken)).status, 403);
    assert.equal((await s.call('GET', '/v1/dealer/showroom', { headers: s.bearer(m.token) })).status, 404);
    assert.equal((await s.call('GET', '/v1/dealer/showroom', { headers: s.bearer(admin.token) })).status, 404);
  });

  it('list query validation is 400 for an admin and 404 (no hint) for anyone else', async () => {
    const s = setup();
    const admin = await s.adminToken();
    const m = await s.member();
    const bad = await s.call('GET', '/v1/admin/dealers', { headers: s.bearer(admin.token), query: { role: 'admin' } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as { error: { fields: unknown } }).error.fields, [{ field: 'role', code: 'unknown_field' }]);
    assert.equal((await s.call('GET', '/v1/admin/dealers', { headers: s.bearer(m.token), query: { role: 'admin' } })).status, 404);
  });

  it('an admin demoted or suspended in the database loses access with the same token', async () => {
    const s = setup();
    const admin = await s.adminToken();
    const d = await s.applyDealer();
    s.db.users().find((u) => u.id === admin.id)!.role = 'user';
    assert.equal((await s.action('approve', d.id, admin.token)).status, 404);
    s.db.users().find((u) => u.id === admin.id)!.role = 'admin';
    s.db.setStatus(admin.id, 'suspended');
    assert.equal((await s.action('approve', d.id, admin.token)).status, 401);
    assert.equal(s.db.users().find((u) => u.id === d.id)!.status, 'pending');
  });
});

describe('error mapping and input helpers', () => {
  it('toDealerHttp maps every error of this layer, and nothing else', () => {
    assert.deepEqual(toDealerHttp(new AuthzError('not_found')), { status: 404, code: 'not_found', message: 'Not found' });
    assert.deepEqual(toDealerHttp(new AuthzError('forbidden')), { status: 403, code: 'forbidden', message: 'Not allowed' });
    assert.deepEqual(toDealerHttp(new AuthError('unauthorized')), { status: 401, code: 'unauthorized', message: 'Authentication required' });
    assert.deepEqual(toDealerHttp(new DealerError('invalid_state')), { status: 409, code: 'invalid_state', message: 'The dealer account is not in a state that allows this action' });
    assert.deepEqual(toDealerHttp(new DealerError('validation_failed', [{ field: 'x', code: 'unknown_field' }])), { status: 400, code: 'validation_failed', message: 'The submitted data is not valid', fields: [{ field: 'x', code: 'unknown_field' }] });
    assert.equal(toDealerHttp(new Error('boom')), undefined);
  });
  it('assertNoBody', () => {
    for (const ok of [undefined, null, {}]) assert.doesNotThrow(() => assertNoBody(ok));
    for (const bad of [{ a: 1 }, [], 'x', 0, true]) assert.throws(() => assertNoBody(bad), DealerError);
  });
});

describe('static guards over the Step 5.2 sources', () => {
  const srcDir = join(import.meta.dirname, '..', '..', 'src');
  const walk = (dir: string): string[] => readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? walk(join(dir, f)) : f.endsWith('.ts') ? [join(dir, f)] : []));
  const sources = walk(srcDir).map((f) => ({ f: f.slice(srcDir.length + 1), text: readFileSync(f, 'utf8') }));
  const text = (f: string) => sources.find((s) => s.f === f)!.text;
  const code = (t: string) => t.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');

  it('the dealer repository never writes a role, an owner, an id, or a status that comes from a parameter', () => {
    const repo = code(text('dealers/repository.ts'));
    const setClauses = [...repo.matchAll(/UPDATE\s+\w+\s+SET\s+([\s\S]*?)\s+WHERE/g)].map((m) => m[1]!);
    assert.equal(setClauses.length, 5, 'four transitions and the pending-showroom approval');
    const written = new Set(setClauses.flatMap((c) => [...c.matchAll(/\b([a-z_]+)\s*=/g)].map((m) => m[1]!)));
    assert.deepEqual([...written].sort(), ['reviewed_at', 'reviewed_by', 'status'], 'only status and the reviewer columns are ever updated');
    assert.match(repo, /INSERT INTO showrooms \(owner_id, name, phone, whatsapp, status, reviewed_by, reviewed_at\)\s+VALUES \(\$1, \$2, \$3, \$3, 'active', \$4, now\(\)\)/);
    assert.ok(!/status\s*=\s*\$\d/.test(repo.replace(/AND u\.status = \$1/, '')), 'statuses are written as literals (the listing FILTER is the only parameterized status)');
    assert.ok(!/SELECT\s+\*/i.test(repo), 'no SELECT *');
    assert.ok(!/password_hash/.test(repo), 'never touches password hashes');
    assert.ok(!/INSERT\s+INTO\s+audit_logs/i.test(repo), 'audit rows go through the single audit writer');
    assert.ok(!/DELETE\s+FROM/i.test(repo), 'no hard deletes');
  });

  it('exactly four transitions exist, each a literal compare-and-swap', () => {
    const repo = text('dealers/repository.ts');
    const sql = [...repo.matchAll(/UPDATE users SET status = '(\w+)' WHERE id = \$1 AND role = 'dealer' AND status = '(\w+)' AND deleted_at IS NULL/g)].map((m) => `${m[2]}->${m[1]}`);
    assert.deepEqual(sql, ['pending->active', 'pending->suspended', 'active->suspended', 'suspended->active']);
  });

  it('the dealer routes and service never read an owner, role, status or user id from the request', () => {
    for (const f of ['dealers/routes.ts', 'dealers/service.ts']) {
      const t = code(text(f));
      assert.ok(!/(body|query)\??\.\s*(role|status|ownerId|owner_id|showroomId|showroom_id|userId|user_id)\b/.test(t), f);
      assert.ok(!/\[['"](role|ownerId|owner_id|showroomId|userId)['"]\]/.test(t), f);
    }
    assert.ok(!/request\.|headers/.test(code(text('dealers/service.ts'))), 'the service never sees HTTP');
  });

  it('every protected dealer route identifies the caller through authenticate + toActor', () => {
    const routes = code(text('dealers/routes.ts'));
    assert.match(routes, /const found = await auth\.authenticate\(bearerToken\(request\.headers\['authorization'\]\)\);/);
    assert.match(routes, /return toActor\(found\.user\);/);
    assert.equal((routes.match(/await identify\(request\)/g) ?? []).length, 3, 'dealer area, listing, admin actions');
  });

  it('the authentication rule exists once in TypeScript, and its SQL forms match it exactly', () => {
    const repo = code(text('auth/repository.ts'));
    assert.ok(repo.includes("AND (status = 'active' OR (status = 'pending' AND role = 'dealer')) AND deleted_at IS NULL"));
    assert.ok(repo.includes("AND u.deleted_at IS NULL\n            AND (u.status = 'active' OR (u.status = 'pending' AND u.role = 'dealer'))"));
    assert.ok(!/status (!==|===) 'active'/.test(code(text('auth/service.ts')) + code(text('auth/account-service.ts')) + repo), 'no path keeps its own copy of the old rule');
    // auth/otp-service.ts is deliberately NOT migrated in Step 5.2 (the OTP files are frozen by the change-control rules): its
    // checks still require status 'active', so a pending dealer is refused by the code flows (fail-closed). Pinned here so that
    // the decision cannot change silently.
    assert.equal((code(text('auth/otp-service.ts')).match(/status !== 'active'|status === 'active'/g) ?? []).length, 4);
    const table: Array<[string, string, boolean]> = [
      ['active', 'user', true], ['active', 'dealer', true], ['active', 'admin', true],
      ['pending', 'dealer', true], ['pending', 'user', false], ['pending', 'admin', false],
      ['suspended', 'dealer', false], ['suspended', 'user', false], ['suspended', 'admin', false],
      ['', 'dealer', false], ['ACTIVE', 'user', false], ['Pending', 'dealer', false], ['pending', 'Dealer', false],
    ];
    for (const [status, role, expected] of table) assert.equal(mayAuthenticate({ status, role }), expected, `${status}/${role}`);
    assert.equal(mayAuthenticate(null), false);
    assert.equal(mayAuthenticate(undefined), false);
  });

  it('member registration still inserts with the database defaults (no role/status parameter exists)', () => {
    const repo = code(text('auth/repository.ts'));
    assert.match(repo, /INSERT INTO users \(name, phone_e164, password_hash\)\s+VALUES \(\$1, \$2, \$3\)/);
    assert.match(repo, /INSERT INTO users \(name, phone_e164, password_hash, role, status\)\s+VALUES \(\$1, \$2, \$3, 'dealer', 'pending'\)/);
  });
});

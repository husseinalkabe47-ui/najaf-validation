import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash, createHmac } from 'node:crypto';
import { deriveOtpKey, generateOtp, hashOtp, hashesEqual, isWellFormedOtp } from '../../src/auth/otp.ts';
import type { OtpPurpose } from '../../src/auth/otp.ts';
import { OTP } from '../../src/auth/policy.ts';
import { createUnconfiguredMessagingProvider, ProviderNotConfiguredError } from '../../src/messaging/provider.ts';

const SECRET = 'otp-unit-test-secret-0123456789abcdef-XYZ';
const key = deriveOtpKey(SECRET);
const sha256Hex = (s: string): string => createHash('sha256').update(s).digest('hex');
const base = { purpose: 'phone_verify' as OtpPurpose, userId: '7', phone: '+9647701234567', code: '123456' };

describe('OTP policy (matches the seeded app_settings otp.policy)', () => {
  it('6 digits, 10 minutes, 5 attempts, 60 s cooldown, 3 per hour, 10 per day', () => {
    assert.deepEqual({ ...OTP }, { codeLength: 6, ttlSeconds: 600, maxAttempts: 5, cooldownSeconds: 60, perHour: 3, perDay: 10 });
  });
});

describe('OTP generation', () => {
  it('is always exactly 6 digits, zero-padded', () => {
    assert.equal(generateOtp(() => 0), '000000');
    assert.equal(generateOtp(() => 7), '000007');
    assert.equal(generateOtp(() => 999_999), '999999');
    assert.equal(generateOtp(() => 123_456), '123456');
    for (let i = 0; i < 500; i++) assert.match(generateOtp(), /^[0-9]{6}$/);
  });

  it('asks the random source for a uniform value below 10^6 (no modulo bias)', () => {
    let asked = 0;
    generateOtp((n) => ((asked = n), 5));
    assert.equal(asked, 1_000_000);
  });

  it('uses a CSPRNG by default: values are not constant and cover the whole range', () => {
    const seen = new Set<string>();
    let sawLeadingZero = false;
    for (let i = 0; i < 3000; i++) {
      const c = generateOtp();
      seen.add(c);
      if (c.startsWith('0')) sawLeadingZero = true;
    }
    assert.ok(seen.size > 2900, `only ${seen.size} distinct codes in 3000`);
    assert.ok(sawLeadingZero, 'codes beginning with 0 must be possible (zero padding)');
  });

  it('well-formedness accepts exactly 6 ASCII digits', () => {
    assert.equal(isWellFormedOtp('000000'), true);
    assert.equal(isWellFormedOtp('123456'), true);
    for (const bad of [undefined, null, 123456, '', '12345', '1234567', '12345a', ' 12345', '12345 ', '١٢٣٤٥٦', '12 456', '+12345', '12.456', '123456\n', ['123456']]) assert.equal(isWellFormedOtp(bad), false, String(bad));
  });
});

describe('OTP hashing: a keyed HMAC bound to purpose, user, phone and code', () => {
  it('is 32 bytes (the verification_codes.code_hash length), deterministic, and the code is not recoverable from it', () => {
    const h = hashOtp(key, base);
    assert.equal(h.length, 32);
    assert.ok(h.equals(hashOtp(key, base)));
    assert.ok(!h.toString('hex').includes('123456') && !h.toString('latin1').includes('123456'));
  });

  it('is HMAC-SHA256 under a key derived from the server secret (not a bare hash anyone could brute-force offline)', () => {
    const expected = createHmac('sha256', key).update('phone_verify\u00007\u0000+9647701234567\u0000123456').digest();
    assert.ok(hashOtp(key, base).equals(expected));
    assert.ok(!hashOtp(deriveOtpKey(SECRET + 'x'), base).equals(hashOtp(key, base)), 'a different secret gives different hashes');
    const plain = Buffer.from(sha256Hex('phone_verify\u00007\u0000+9647701234567\u0000123456'), 'hex');
    assert.ok(!hashOtp(key, base).equals(plain), 'it is not a plain SHA-256');
  });

  it('every part of the binding changes the hash: purpose, user, phone, code', () => {
    const h = hashOtp(key, base);
    for (const changed of [{ purpose: 'password_reset' as OtpPurpose }, { userId: '8' }, { phone: '+9647701234568' }, { code: '123457' }]) {
      assert.ok(!hashOtp(key, { ...base, ...changed }).equals(h), JSON.stringify(changed));
    }
  });

  it('delimiters prevent ambiguity: moving characters between fields cannot collide', () => {
    const a = hashOtp(key, { purpose: 'phone_verify', userId: '12', phone: '+9647701234567', code: '345678' });
    const b = hashOtp(key, { purpose: 'phone_verify', userId: '1', phone: '2+9647701234567', code: '345678' });
    assert.ok(!a.equals(b));
  });

  it('the derived key is not the secret and is stable', () => {
    assert.equal(key.length, 32);
    assert.ok(key.equals(deriveOtpKey(SECRET)));
    assert.ok(!key.equals(Buffer.from(SECRET)));
    assert.ok(!key.equals(createHmac('sha256', SECRET).update('access').digest()), 'distinct from any other derivation');
  });

  it('comparison is exact and length-safe', () => {
    const h = hashOtp(key, base);
    assert.equal(hashesEqual(h, Buffer.from(h)), true);
    assert.equal(hashesEqual(h, hashOtp(key, { ...base, code: '123457' })), false);
    assert.equal(hashesEqual(h, h.subarray(0, 31)), false, 'different length: false, not an exception');
    assert.equal(hashesEqual(h, Buffer.alloc(0)), false);
    assert.equal(hashesEqual(Buffer.alloc(32), Buffer.alloc(32)), true);
  });
});

describe('messaging provider (interface only: production delivery is a later step)', () => {
  it('the unconfigured provider refuses every send, with an error that carries no message content', async () => {
    const provider = createUnconfiguredMessagingProvider();
    await assert.rejects(provider.send({ phone: '+9647701234567', purpose: 'phone_verify', code: '123456', ttlSeconds: 600 }), (e: unknown) => {
      assert.ok(e instanceof ProviderNotConfiguredError);
      assert.ok(!String((e as Error).message).includes('123456') && !String((e as Error).message).includes('9647701234567'));
      return true;
    });
  });
});

// Phase 11.5, Step 5.4: the member-car HTTP layer, run WITHOUT Fastify. Routes are registered on a recording stand-in; handlers are
// called with plain request objects, wired to the REAL authentication service (tokens, account re-read), the REAL policy layer and
// the member-car service over the in-memory store. Plus static guards over the new source files.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { MEMBER_CAR_RATE_LIMITS, registerMemberCarRoutes, toMemberCarHttp } from '../../src/member-cars/routes.ts';
import { MemberCarError, createMemberCarService } from '../../src/member-cars/service.ts';
import { buildFindOwn, buildInsert, buildListOwn, buildSoftDelete, buildUpdate } from '../../src/member-cars/repository.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeMemberCarStore } from '../helpers/fake-member-cars.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrorBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JSON_HEADERS = { 'content-type': 'application/json' };
const VALID = { brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD', phone: '07701234567' };

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  // The member-car store sees the SAME accounts as authentication (status changes are visible to both).
  const cars = makeFakeMemberCarStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
    now: clock.now,
  });
  const memberCars = createMemberCarService({ store: cars.store });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerMemberCarRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, memberCars, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    return { id: r.user.id, headers: bearer(r.session.accessToken), json: { ...bearer(r.session.accessToken), ...JSON_HEADERS } };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    return { id: r.user.id, headers: bearer(r.session.accessToken), json: { ...bearer(r.session.accessToken), ...JSON_HEADERS } };
  }
  async function create(who: { json: Record<string, string> }, body: Record<string, unknown> = VALID) {
    const sent = await call('POST', '/v1/me/cars', { headers: who.json, body });
    assert.equal(sent.status, 201, JSON.stringify(sent.body));
    return (sent.body as { car: { id: string; version: number; status: string } }).car;
  }
  return { routes, call, member, pendingDealer, create, db, cars };
}

describe('member-car routes: registration', () => {
  it('registers exactly the five owner routes', () => {
    const { routes } = setup();
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [
      'DELETE /v1/me/cars/:id', 'GET /v1/me/cars', 'GET /v1/me/cars/:id', 'PATCH /v1/me/cars/:id', 'POST /v1/me/cars',
    ]);
  });

  it('every route is rate limited when a limiter is supplied; bodies are bounded', () => {
    const { routes } = setup(true);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1, `${r.method} ${r.path}`);
    for (const r of routes.filter((x) => x.method === 'POST' || x.method === 'PATCH')) assert.equal(r.opts?.bodyLimit, 16 * 1024);
  });
});

describe('member-car routes: authentication', () => {
  it('no token or a bad token is 401 with WWW-Authenticate on every route', async () => {
    const s = setup();
    for (const [method, path] of [['POST', '/v1/me/cars'], ['GET', '/v1/me/cars'], ['GET', '/v1/me/cars/:id'], ['PATCH', '/v1/me/cars/:id'], ['DELETE', '/v1/me/cars/:id']] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const sent = await s.call(method, path, { headers: { ...headers, ...JSON_HEADERS }, params: { id: '1' }, body: VALID, query: { version: '1' } });
        assert.equal(sent.status, 401, `${method} ${path}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
      }
    }
    assert.equal(s.cars.cars().length, 0);
  });

  it('a suspended account\'s token stops working (the account is re-read on every request)', async () => {
    const s = setup();
    const a = await s.member();
    const car = await s.create(a);
    s.db.setStatus(a.id, 'suspended');
    assert.equal((await s.call('GET', '/v1/me/cars/:id', { headers: a.headers, params: { id: car.id } })).status, 401);
  });

  it('a pending dealer (authenticated, no actor) gets 403 on the collection and 404 on an item', async () => {
    const s = setup();
    const a = await s.member();
    const car = await s.create(a);
    const d = await s.pendingDealer();
    assert.equal((await s.call('POST', '/v1/me/cars', { headers: d.json, body: VALID })).status, 403);
    assert.equal((await s.call('GET', '/v1/me/cars', { headers: d.headers })).status, 403);
    assert.equal((await s.call('GET', '/v1/me/cars/:id', { headers: d.headers, params: { id: car.id } })).status, 404);
  });
});

describe('member-car routes: ownership end to end', () => {
  it('create is 201 with a pending ad owned by the token\'s account; an ownerId in the body is refused', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const car = await s.create(a);
    assert.equal(car.status, 'pending');
    assert.equal(s.cars.car(car.id)!.ownerId, a.id);
    const forged = await s.call('POST', '/v1/me/cars', { headers: a.json, body: { ...VALID, ownerId: b.id } });
    assert.equal(forged.status, 400);
    assert.deepEqual((forged.body as ErrorBody).error.fields, [{ field: 'ownerId', code: 'unknown_field' }]);
  });

  it('another member\'s ad is a 404 identical to an unknown id, for read, update and delete', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const car = await s.create(a);
    const unknown = await s.call('GET', '/v1/me/cars/:id', { headers: b.headers, params: { id: '999999' } });
    const read = await s.call('GET', '/v1/me/cars/:id', { headers: b.headers, params: { id: car.id } });
    const patch = await s.call('PATCH', '/v1/me/cars/:id', { headers: b.json, params: { id: car.id }, body: { version: 1, price: 1 } });
    const del = await s.call('DELETE', '/v1/me/cars/:id', { headers: b.headers, params: { id: car.id }, query: { version: '1' } });
    for (const r of [read, patch, del]) {
      assert.equal(r.status, 404);
      assert.deepEqual(r.body, unknown.body);
    }
    assert.equal(s.cars.car(car.id)!.version, 1);
    assert.equal(s.cars.car(car.id)!.deletedAt, null);
  });

  it('the list contains only the caller\'s ads', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    await s.create(a);
    await s.create(b);
    const list = await s.call('GET', '/v1/me/cars', { headers: a.headers });
    assert.equal(list.status, 200);
    const items = (list.body as { items: Array<{ id: string }> }).items;
    assert.equal(items.length, 1);
    assert.equal(s.cars.car(items[0]!.id)!.ownerId, a.id);
  });
});

describe('member-car routes: update, versioning and delete', () => {
  it('PATCH with the current version is 200; a stale version is 409 version_conflict', async () => {
    const s = setup();
    const a = await s.member();
    const car = await s.create(a);
    const ok = await s.call('PATCH', '/v1/me/cars/:id', { headers: a.json, params: { id: car.id }, body: { version: 1, price: 8500 } });
    assert.equal(ok.status, 200);
    assert.equal((ok.body as { car: { version: number; price: number } }).car.version, 2);
    const stale = await s.call('PATCH', '/v1/me/cars/:id', { headers: a.json, params: { id: car.id }, body: { version: 1, price: 8000 } });
    assert.equal(stale.status, 409);
    assert.equal((stale.body as ErrorBody).error.code, 'version_conflict');
  });

  it('PATCH cannot publish (status active is a 400)', async () => {
    const s = setup();
    const a = await s.member();
    const car = await s.create(a);
    const r = await s.call('PATCH', '/v1/me/cars/:id', { headers: a.json, params: { id: car.id }, body: { version: 1, status: 'active' } });
    assert.equal(r.status, 400);
    assert.equal(s.cars.car(car.id)!.status, 'pending');
  });

  it('DELETE with the current version is 204 with no body; the ad is then 404; a body or a stale version is refused', async () => {
    const s = setup();
    const a = await s.member();
    const car = await s.create(a);
    assert.equal((await s.call('DELETE', '/v1/me/cars/:id', { headers: a.headers, params: { id: car.id }, query: { version: '1' }, body: { hard: true } })).status, 400);
    assert.equal((await s.call('DELETE', '/v1/me/cars/:id', { headers: a.headers, params: { id: car.id }, query: {} })).status, 400);
    const del = await s.call('DELETE', '/v1/me/cars/:id', { headers: a.headers, params: { id: car.id }, query: { version: '1' } });
    assert.equal(del.status, 204);
    assert.equal(del.body, undefined);
    assert.equal((await s.call('GET', '/v1/me/cars/:id', { headers: a.headers, params: { id: car.id } })).status, 404);
    assert.equal((await s.call('DELETE', '/v1/me/cars/:id', { headers: a.headers, params: { id: car.id }, query: { version: '2' } })).status, 404);
  });

  it('a non-JSON body on POST or PATCH is 415 before any processing', async () => {
    const s = setup();
    const a = await s.member();
    const r = await s.call('POST', '/v1/me/cars', { headers: { ...a.headers, 'content-type': 'text/plain' }, body: 'brand=Kia' });
    assert.equal(r.status, 415);
    assert.equal(s.cars.cars().length, 0);
  });

  it('validation errors are 400 with field names and codes only', async () => {
    const s = setup();
    const a = await s.member();
    const r = await s.call('POST', '/v1/me/cars', { headers: a.json, body: { ...VALID, year: 1900, currency: 'XXX-SECRET' } });
    assert.equal(r.status, 400);
    assert.deepEqual((r.body as ErrorBody).error.fields, [{ field: 'year', code: 'invalid_format' }, { field: 'currency', code: 'invalid_format' }]);
    assert.ok(!JSON.stringify(r.body).includes('SECRET'));
  });
});

describe('member-car routes: rate limits', () => {
  it('create has its own hourly budget per address, then 429 with retry-after; reads are not blocked by it', async () => {
    const s = setup(true);
    const a = await s.member();
    for (let i = 0; i < MEMBER_CAR_RATE_LIMITS.create.limit; i++) assert.equal((await s.call('POST', '/v1/me/cars', { headers: a.json, body: VALID })).status, 201);
    const denied = await s.call('POST', '/v1/me/cars', { headers: a.json, body: VALID });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal((await s.call('GET', '/v1/me/cars', { headers: a.headers })).status, 200);
  });
});

describe('member-car error mapping', () => {
  it('maps validation to 400, conflicts and states to 409, authz to 401/403/404; anything else is not ours', () => {
    assert.equal(toMemberCarHttp(new MemberCarError('validation_failed', []))?.status, 400);
    assert.equal(toMemberCarHttp(new MemberCarError('version_conflict'))?.status, 409);
    assert.equal(toMemberCarHttp(new MemberCarError('invalid_state'))?.status, 409);
    assert.equal(toMemberCarHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toMemberCarHttp(new AuthzError('forbidden'))?.status, 403);
    assert.equal(toMemberCarHttp(new Error('boom')), undefined);
  });
});

describe('member-car SQL and source guards', () => {
  const fields = {
    brand: 'Kia', model: 'Rio', year: 2018, price: 9000, currency: 'USD' as const, mileage: null, transmission: 'يدوي' as const, fuelType: 'بنزين' as const,
    color: '', description: "x'; DROP TABLE cars; --", phone: '+9647701234567', whatsapp: null, location: '', latitude: null, longitude: null,
  };

  it('every read and write is scoped to the owner, to member cars and to rows that are not deleted', () => {
    for (const s of [buildListOwn('7', { limit: 5, before: '9', status: 'sold' }), buildFindOwn('1', '7', false), buildFindOwn('1', '7', true), buildUpdate({ id: '1', ownerId: '7', expectedVersion: 3, changes: { price: 5 }, markSold: false, searchText: 'x' }), buildSoftDelete({ id: '1', ownerId: '7', expectedVersion: 3 })]) {
      assert.match(s.text, /c\.owner_id = \$\d::bigint/);
      assert.match(s.text, /c\.source_type = 'member'/);
      assert.match(s.text, /c\.deleted_at IS NULL/);
      assert.ok(s.values.includes('7'), 'the owner is a bound parameter');
    }
  });

  it('the insert writes source_type member and status pending as SQL literals, the owner as the first parameter', () => {
    const s = buildInsert('7', fields, 'kia rio');
    assert.match(s.text, /VALUES \('member', \$1::bigint,.*'pending', \$17\)/s);
    assert.equal(s.values[0], '7');
    assert.ok(!/'active'/.test(s.text), 'never inserted as active (D1)');
    assert.ok(!s.text.includes('DROP TABLE'), 'values never enter the SQL text');
  });

  it('updates and deletes are compare-and-swap on version; marking sold also requires status active', () => {
    const plain = buildUpdate({ id: '1', ownerId: '7', expectedVersion: 3, changes: { price: 5, fuelType: 'ديزل' }, markSold: false, searchText: 'x' });
    assert.match(plain.text, /c\.version = \$3/);
    assert.match(plain.text, /SET price = \$4, fuel_type = \$5, search_text = \$6/);
    assert.ok(!/status = /.test(plain.text));
    const sold = buildUpdate({ id: '1', ownerId: '7', expectedVersion: 3, changes: {}, markSold: true, searchText: 'x' });
    assert.match(sold.text, /status = 'sold'/);
    assert.match(sold.text, /AND c\.status = 'active'/);
    assert.match(buildSoftDelete({ id: '1', ownerId: '7', expectedVersion: 3 }).text, /SET deleted_at = now\(\) WHERE .* AND c\.version = \$3/);
  });

  it('an update can never name a column outside the whitelist', () => {
    assert.throws(() => buildUpdate({ id: '1', ownerId: '7', expectedVersion: 1, changes: { owner_id: '2' } as never, markSold: false, searchText: '' }), /unknown member car field/);
    assert.throws(() => buildUpdate({ id: '1', ownerId: '7', expectedVersion: 1, changes: { status: 'active' } as never, markSold: false, searchText: '' }), /unknown member car field/);
  });

  it('the repository never writes ownership, type, version, timestamps or reviewer columns, and never selects *', () => {
    // Every column an update can SET, with every field changed and marking sold: only the whitelist, search_text, and the literal 'sold'.
    const all = buildUpdate({ id: '1', ownerId: '7', expectedVersion: 1, changes: { ...fields, latitude: '1.000000', longitude: '2.000000' }, markSold: true, searchText: 'x' });
    const setClause = /SET (.*?)\s+WHERE/s.exec(all.text)![1]!;
    const assignments = setClause.split(', ').map((a) => a.trim());
    const columns = assignments.map((a) => a.split(' = ')[0]);
    const allowed = ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuel_type', 'color', 'description', 'phone', 'whatsapp', 'location', 'latitude', 'longitude', 'status', 'search_text'];
    assert.deepEqual(columns.filter((c) => !allowed.includes(c!)), []);
    assert.ok(assignments.includes("status = 'sold'"), 'the only status written is the literal sold');
    assert.equal(/SET (.*?) WHERE/s.exec(buildSoftDelete({ id: '1', ownerId: '7', expectedVersion: 1 }).text)![1], 'deleted_at = now()');
    const src = code('src/member-cars/repository.ts');
    assert.ok(!/SELECT\s+\*/i.test(src));
    assert.ok(!/\breviewed_by\b/.test(src), 'the reviewer id is never read or written');
    assert.ok(!/DELETE FROM cars/i.test(src), 'soft delete only');
  });

  it('the service and the routes never take an owner from the request', () => {
    const svc = code('src/member-cars/service.ts');
    assert.ok(!/request\.|headers|\.params|\.query\b/.test(svc), 'the service sees no HTTP object');
    assert.ok(!/body\.(ownerId|owner_id|userId)|\.ownerId\s*=(?!=)/.test(svc), 'no owner is read from a body or assigned');
    assert.match(svc, /cars\.insert\(actor\.id,/);
    const routes = code('src/member-cars/routes.ts');
    assert.ok(!/ownerId|owner_id|userId/.test(routes));
    assert.match(routes, /return toActor\(found\.user\);/);
  });

  it('the routes are wired only together with authentication, and the process supplies the Postgres-backed service', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.memberCars\) registerMemberCarRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createMemberCarService\(\{ store: createPgMemberCarStore\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\bmemberCars\b/);
  });
});

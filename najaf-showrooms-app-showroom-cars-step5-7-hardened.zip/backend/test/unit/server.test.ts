// HTTP wiring tests. They need `fastify`, which is installed in CI (npm install) but not in every environment:
// without it the whole file is SKIPPED (visibly), never silently passed.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { DbError } from '../../src/errors.ts';

type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let reason: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  reason = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@h:5432/najaf', LOG_LEVEL: 'silent', NODE_ENV: 'test' });
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };
const downDb = { ping: async () => { throw new DbError('unavailable', { driverMessage: 'connect ECONNREFUSED 10.0.0.5:5432' }); }, checkSchema: async () => ({ missing: [] as string[] }) };
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

describe('http server', { skip: reason }, () => {
  it('GET /healthz is 200 and needs no database', async () => {
    const app = await buildServer!({ config, db: downDb });
    const r = await app.inject({ method: 'GET', url: '/healthz' });
    assert.equal(r.statusCode, 200);
    assert.deepEqual(r.json(), { status: 'ok' });
    await app.close();
  });

  it('GET /readyz is 200 when ready and 503 when the database is down, without leaking details', async () => {
    const up = await buildServer!({ config, db: okDb });
    const ok = await up.inject({ method: 'GET', url: '/readyz' });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { status: 'ready', checks: { database: 'ok', schema: 'ok' } });
    await up.close();

    const down = await buildServer!({ config, db: downDb });
    const bad = await down.inject({ method: 'GET', url: '/readyz' });
    assert.equal(bad.statusCode, 503);
    assert.deepEqual(bad.json(), { status: 'not_ready', checks: { database: 'fail', schema: 'skipped' } });
    assert.ok(!bad.body.includes('ECONNREFUSED') && !bad.body.includes('10.0.0.5'));
    await down.close();
  });

  it('sets no-store and nosniff, and returns a request id', async () => {
    const app = await buildServer!({ config, db: okDb });
    const r = await app.inject({ method: 'GET', url: '/healthz' });
    assert.equal(r.headers['cache-control'], 'no-store');
    assert.equal(r.headers['x-content-type-options'], 'nosniff');
    assert.match(String(r.headers['x-request-id']), UUID);
    await app.close();
  });

  it('echoes a well-formed x-request-id and replaces a malformed one', async () => {
    const app = await buildServer!({ config, db: okDb });
    const good = await app.inject({ method: 'GET', url: '/healthz', headers: { 'x-request-id': 'trace-12345678' } });
    assert.equal(good.headers['x-request-id'], 'trace-12345678');
    const bad = await app.inject({ method: 'GET', url: '/healthz', headers: { 'x-request-id': 'x<script>alert(1)</script>' } });
    assert.match(String(bad.headers['x-request-id']), UUID);
    await app.close();
  });

  it('unknown routes return a generic JSON 404 with the request id', async () => {
    const app = await buildServer!({ config, db: okDb });
    const r = await app.inject({ method: 'GET', url: '/api/secret-admin' });
    assert.equal(r.statusCode, 404);
    const body = r.json() as { error: { code: string; message: string; requestId: string } };
    assert.equal(body.error.code, 'not_found');
    assert.equal(body.error.requestId, r.headers['x-request-id']);
    assert.ok(!body.error.message.includes('secret-admin'));
    await app.close();
  });

  it('database errors map to generic bodies; unexpected errors become an opaque 500', async () => {
    const app = await buildServer!({ config, db: okDb });
    app.get('/t/unique', async () => { throw new DbError('unique', { sqlstate: '23505', constraint: 'users_phone_active_uq', driverMessage: 'duplicate key value violates unique constraint' }); });
    app.get('/t/boom', async () => { throw new Error('secret stack at /srv/app/key.ts'); });
    const u = await app.inject({ method: 'GET', url: '/t/unique' });
    assert.equal(u.statusCode, 409);
    assert.ok(!u.body.includes('users_phone_active_uq') && !u.body.includes('duplicate key'));
    const b = await app.inject({ method: 'GET', url: '/t/boom' });
    assert.equal(b.statusCode, 500);
    assert.ok(!b.body.includes('secret') && !b.body.includes('/srv/app'));
    assert.equal((b.json() as { error: { code: string } }).error.code, 'internal_error');
    await app.close();
  });

  it('malformed JSON bodies are a generic 400', async () => {
    const app = await buildServer!({ config, db: okDb });
    app.post('/t/echo', async (req) => req.body);
    const r = await app.inject({ method: 'POST', url: '/t/echo', headers: { 'content-type': 'application/json' }, payload: '{"a":' });
    assert.equal(r.statusCode, 400);
    assert.equal((r.json() as { error: { message: string } }).error.message, 'Bad request');
    await app.close();
  });
});

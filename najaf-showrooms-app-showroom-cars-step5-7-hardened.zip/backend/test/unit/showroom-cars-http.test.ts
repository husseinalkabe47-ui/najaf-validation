// Phase 11.5, Step 5.7: the HTTP contract of the dealer car routes and the administrator status route, through the real routes, the
// real authentication service (fake auth store) and the real service over the in-memory store. Plus static guards on SQL and sources.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import {
  COLUMN_OF, FIND_SHOWROOM_OF_OWNER_SQL, LOCK_ACTING_USER_SQL, buildFindOwn, buildInsert, buildListOwn, buildLockForModeration, buildSetStatus, buildSoftDelete, buildUpdate,
  createPgShowroomCarRepository,
} from '../../src/showroom-cars/repository.ts';
import { SHOWROOM_CAR_RATE_LIMITS, registerShowroomCarRoutes, toShowroomCarHttp } from '../../src/showroom-cars/routes.ts';
import { ShowroomCarError, createShowroomCarService } from '../../src/showroom-cars/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeShowroomCarStore } from '../helpers/fake-showroom-cars.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };
type CarBody = { car: { id: string; status: string; version: number; showroomId: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JSON_HEADERS = { 'content-type': 'application/json' };
const CARS = '/v1/dealer/cars';
const ONE = '/v1/dealer/cars/:id';
const ADMIN_STATUS = '/v1/admin/showroom-cars/:id/status';
const VALID = { brand: 'Kia', model: 'Sportage', year: 2022, price: 31000000, currency: 'IQD' };

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const sc = makeFakeShowroomCarStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
  });
  const showroomCars = createShowroomCarService({ store: sc.store });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerShowroomCarRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, showroomCars, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  const who = (id: string, token: string) => ({ id, headers: bearer(token), json: { ...bearer(token), ...JSON_HEADERS } });
  /** An APPROVED dealer: the application, then the approval's effect (account active + one showroom) as fixtures. */
  async function dealer(showroomStatus = 'active') {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    db.users().find((u) => u.id === r.user.id)!.status = 'active';
    const showroom = sc.addShowroom({ ownerId: r.user.id, status: showroomStatus });
    return { ...who(r.user.id, r.session.accessToken), showroom };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    return who(r.user.id, r.session.accessToken);
  }
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    return who(r.user.id, r.session.accessToken);
  }
  async function admin() {
    const r = await auth.register({ name: 'مدير', phone: phone(), password: PW });
    db.users().find((u) => u.id === r.user.id)!.role = 'admin';
    return who(r.user.id, r.session.accessToken);
  }
  async function create(d: { json: Record<string, string> }, body: unknown = VALID) {
    const sent = await call('POST', CARS, { headers: d.json, body });
    assert.equal(sent.status, 201, JSON.stringify(sent.body));
    return (sent.body as CarBody).car;
  }
  return { routes, call, dealer, pendingDealer, member, admin, create, sc, db };
}

describe('showroom-car routes: registration', () => {
  it('registers exactly the five dealer routes and the one admin route; every one is rate limited when a limiter is supplied', () => {
    const { routes } = setup(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`DELETE ${ONE}`, `GET ${CARS}`, `GET ${ONE}`, `PATCH ${ADMIN_STATUS}`, `PATCH ${ONE}`, `POST ${CARS}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1, `${r.method} ${r.path}`);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts?.bodyLimit, 16 * 1024);
    assert.equal(routes.find((r) => r.path === ADMIN_STATUS)!.opts?.bodyLimit, 1024);
    assert.ok(!routes.some((r) => r.path.startsWith('/v1/admin') && r.method !== 'PATCH'), 'no admin create, edit or delete route');
  });
});

describe('showroom-car routes: authentication and roles', () => {
  it('no token or a bad token is 401 with WWW-Authenticate on every route', async () => {
    const s = setup();
    for (const [method, path] of [['POST', CARS], ['GET', CARS], ['GET', ONE], ['PATCH', ONE], ['DELETE', ONE], ['PATCH', ADMIN_STATUS]] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const sent = await s.call(method, path, { headers: { ...headers, ...JSON_HEADERS }, params: { id: '5000' }, body: { version: 1, status: 'sold' } });
        assert.equal(sent.status, 401, `${method} ${path}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
      }
    }
  });

  it('a pending dealer, a member and an administrator get 404 on the whole dealer area', async () => {
    const s = setup();
    const d = await s.dealer();
    const car = await s.create(d);
    for (const other of [await s.pendingDealer(), await s.member(), await s.admin()]) {
      assert.equal((await s.call('POST', CARS, { headers: other.json, body: VALID })).status, 404);
      assert.equal((await s.call('GET', CARS, { headers: other.headers })).status, 404);
      assert.equal((await s.call('GET', ONE, { headers: other.headers, params: { id: car.id } })).status, 404);
      assert.equal((await s.call('PATCH', ONE, { headers: other.json, params: { id: car.id }, body: { version: 1, price: 1 } })).status, 404);
      assert.equal((await s.call('DELETE', ONE, { headers: other.headers, params: { id: car.id }, query: { version: '1' } })).status, 404);
    }
    assert.equal(s.sc.car(car.id).version, 1);
    assert.equal(s.sc.car(car.id).deleted, false);
  });

  it('dealers and members get 404 on the admin route, the owner included', async () => {
    const s = setup();
    const d = await s.dealer();
    const car = await s.create(d);
    for (const other of [d, await s.member(), await s.pendingDealer()]) {
      const r = await s.call('PATCH', ADMIN_STATUS, { headers: other.json, params: { id: car.id }, body: { version: 1, status: 'sold' } });
      assert.equal(r.status, 404);
    }
    assert.equal(s.sc.car(car.id).status, 'available');
  });
});

describe('showroom-car routes: dealer flow', () => {
  it('create 201 (available, own showroom) -> list -> get -> patch 200 -> delete 204; then 404', async () => {
    const s = setup();
    const d = await s.dealer();
    const car = await s.create(d);
    assert.equal(car.status, 'available');
    assert.equal(car.showroomId, d.showroom.id);
    const list = await s.call('GET', CARS, { headers: d.headers });
    assert.deepEqual((list.body as { items: Array<{ id: string }> }).items.map((c) => c.id), [car.id]);
    assert.equal((await s.call('GET', ONE, { headers: d.headers, params: { id: car.id } })).status, 200);
    const patched = await s.call('PATCH', ONE, { headers: d.json, params: { id: car.id }, body: { version: 1, status: 'sold' } });
    assert.equal(patched.status, 200);
    assert.equal((patched.body as CarBody).car.version, 2);
    const del = await s.call('DELETE', ONE, { headers: d.headers, params: { id: car.id }, query: { version: '2' } });
    assert.equal(del.status, 204);
    assert.equal(del.body, undefined);
    assert.equal((await s.call('GET', ONE, { headers: d.headers, params: { id: car.id } })).status, 404);
  });

  it('another dealer gets 404 identical to an unknown id, and a showroomId in the body is refused', async () => {
    const s = setup();
    const a = await s.dealer();
    const b = await s.dealer();
    const car = await s.create(a);
    const unknown = await s.call('GET', ONE, { headers: b.headers, params: { id: '999999' } });
    for (const r of [
      await s.call('GET', ONE, { headers: b.headers, params: { id: car.id } }),
      await s.call('PATCH', ONE, { headers: b.json, params: { id: car.id }, body: { version: 1, price: 1 } }),
      await s.call('DELETE', ONE, { headers: b.headers, params: { id: car.id }, query: { version: '1' } }),
    ]) {
      assert.equal(r.status, 404);
      assert.deepEqual(r.body, unknown.body);
    }
    const sneaky = await s.call('POST', CARS, { headers: b.json, body: { ...VALID, showroomId: a.showroom.id } });
    assert.equal(sneaky.status, 400);
    assert.deepEqual((sneaky.body as ErrBody).error.fields, [{ field: 'showroomId', code: 'unknown_field' }]);
    assert.ok(!s.sc.cars().some((c) => c.showroomId === a.showroom.id && c.id !== car.id));
  });

  it('a stale version is 409 version_conflict; validation errors are 400 with field names only', async () => {
    const s = setup();
    const d = await s.dealer();
    const car = await s.create(d);
    await s.call('PATCH', ONE, { headers: d.json, params: { id: car.id }, body: { version: 1, price: 2 } });
    const stale = await s.call('PATCH', ONE, { headers: d.json, params: { id: car.id }, body: { version: 1, price: 3 } });
    assert.equal(stale.status, 409);
    assert.equal((stale.body as ErrBody).error.code, 'version_conflict');
    const bad = await s.call('POST', CARS, { headers: d.json, body: { ...VALID, currency: 'SECRET-EUR' } });
    assert.equal(bad.status, 400);
    assert.ok(!JSON.stringify(bad.body).includes('SECRET'));
  });

  it('a non-JSON write is 415; a body on DELETE is refused', async () => {
    const s = setup();
    const d = await s.dealer();
    const car = await s.create(d);
    assert.equal((await s.call('POST', CARS, { headers: { ...d.headers, 'content-type': 'text/plain' }, body: 'x' })).status, 415);
    assert.equal((await s.call('PATCH', ONE, { headers: { ...d.headers, 'content-type': 'text/plain' }, params: { id: car.id }, body: 'x' })).status, 415);
    assert.equal((await s.call('DELETE', ONE, { headers: d.json, params: { id: car.id }, query: { version: '1' }, body: { force: true } })).status, 400);
    assert.equal(s.sc.car(car.id).deleted, false);
  });

  it('the dealer of a suspended showroom still manages its cars (existing policy); a suspended DEALER cannot authenticate', async () => {
    const s = setup();
    const d = await s.dealer('suspended');
    const car = await s.create(d);
    assert.equal(car.status, 'available');
    s.db.users().find((u) => u.id === d.id)!.status = 'suspended';
    assert.equal((await s.call('GET', CARS, { headers: d.headers })).status, 401);
  });

  it('create has its own per-address budget; reads are not blocked by it', async () => {
    const s = setup(true);
    const d = await s.dealer();
    for (let i = 0; i < SHOWROOM_CAR_RATE_LIMITS.create.limit; i++) assert.equal((await s.call('POST', CARS, { headers: d.json, body: { brand: 'x' } })).status, 400);
    const denied = await s.call('POST', CARS, { headers: d.json, body: VALID });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal((await s.call('GET', CARS, { headers: d.headers })).status, 200);
  });
});

describe('showroom-car routes: admin status', () => {
  it('an administrator marks a dealer car sold (200 {car}) and back; only status and version change', async () => {
    const s = setup();
    const d = await s.dealer();
    const a = await s.admin();
    const car = await s.create(d);
    const r = await s.call('PATCH', ADMIN_STATUS, { headers: a.json, params: { id: car.id }, body: { version: 1, status: 'sold' } });
    assert.equal(r.status, 200);
    assert.equal((r.body as CarBody).car.status, 'sold');
    assert.equal(s.sc.car(car.id).brand, 'Kia');
    const stale = await s.call('PATCH', ADMIN_STATUS, { headers: a.json, params: { id: car.id }, body: { version: 1, status: 'available' } });
    assert.equal(stale.status, 409);
    const extra = await s.call('PATCH', ADMIN_STATUS, { headers: a.json, params: { id: car.id }, body: { version: 2, status: 'available', price: 1 } });
    assert.equal(extra.status, 400);
    assert.deepEqual((extra.body as ErrBody).error.fields, [{ field: 'price', code: 'unknown_field' }]);
    assert.equal((await s.call('PATCH', ADMIN_STATUS, { headers: { ...a.headers, 'content-type': 'text/plain' }, params: { id: car.id }, body: 'x' })).status, 415);
  });

  it('the admin route has its own per-address budget', async () => {
    const s = setup(true);
    const a = await s.admin();
    for (let i = 0; i < SHOWROOM_CAR_RATE_LIMITS.admin.limit; i++) assert.equal((await s.call('PATCH', ADMIN_STATUS, { headers: a.json, params: { id: '999999' }, body: { version: 1, status: 'sold' } })).status, 404);
    const denied = await s.call('PATCH', ADMIN_STATUS, { headers: a.json, params: { id: '999999' }, body: { version: 1, status: 'sold' } });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
  });

  it('maps its errors; leaves unknown ones to the global handler', () => {
    assert.equal(toShowroomCarHttp(new ShowroomCarError('validation_failed', [{ field: 'brand', code: 'required' }]))?.status, 400);
    assert.equal(toShowroomCarHttp(new ShowroomCarError('version_conflict'))?.status, 409);
    assert.equal(toShowroomCarHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toShowroomCarHttp(new Error('boom')), undefined);
  });
});

describe('showroom cars: SQL and source guards', () => {
  it('the dealer\'s showroom is found by owner id only; every dealer statement is scoped by that showroom, source and not deleted', () => {
    assert.equal(FIND_SHOWROOM_OF_OWNER_SQL, 'SELECT s.id, s.owner_id, s.status FROM showrooms s WHERE s.owner_id = $1::bigint');
    const own = /c\.showroom_id = \$2::bigint AND c\.source_type = 'showroom' AND c\.deleted_at IS NULL/;
    assert.match(buildFindOwn('7', '1', false).text, own);
    assert.match(buildFindOwn('7', '1', true).text, /FOR UPDATE OF c$/);
    assert.deepEqual(buildFindOwn('7', '1', false).values, ['7', '1']);
    const upd = buildUpdate({ id: '7', showroomId: '1', expectedVersion: 3, changes: { price: 5 }, status: 'sold', searchText: 'x' });
    assert.match(upd.text, own);
    assert.match(upd.text, /AND c\.version = \$3/);
    assert.match(upd.text, /status = 'sold'/);
    assert.deepEqual(upd.values, ['7', '1', 3, 5, 'x']);
    const del = buildSoftDelete({ id: '7', showroomId: '1', expectedVersion: 3 });
    assert.equal(del.text.replace(/\s+/g, ' '), "UPDATE cars c SET deleted_at = now() WHERE c.id = $1::bigint AND c.showroom_id = $2::bigint AND c.source_type = 'showroom' AND c.deleted_at IS NULL AND c.version = $3");
    const list = buildListOwn('1', { limit: 20, before: '9', status: 'available' });
    assert.match(list.text, /WHERE c\.showroom_id = \$1::bigint AND c\.source_type = 'showroom' AND c\.deleted_at IS NULL AND c\.id < \$2::bigint AND c\.status = \$3 ORDER BY c\.id DESC LIMIT \$4/);
  });

  it('a car is inserted as a showroom car of the given showroom, always available, without any member-only column', () => {
    const ins = buildInsert('1', { brand: 'b', model: 'm', year: 2020, price: 1, currency: 'IQD', mileage: null, transmission: 'يدوي', fuelType: 'ديزل', color: '', description: '' }, 's');
    assert.match(ins.text, /VALUES \('showroom', \$1::bigint, .*'available', \$12\)/s);
    assert.ok(!/\b(owner_id|phone|whatsapp|location|latitude|longitude|rejection_reason|suspension_reason|reviewed_at|reviewed_by|version|updated_at)\b/.test(ins.text.split('RETURNING')[0]!));
    assert.equal(ins.values[0], '1');
  });

  it('the admin statement reads any showroom car not deleted and writes ONLY status, as a compare-and-swap', () => {
    const lock = buildLockForModeration('7');
    assert.match(lock.text, /WHERE c\.id = \$1::bigint AND c\.source_type = 'showroom' AND c\.deleted_at IS NULL\s+FOR UPDATE OF c/);
    const set = buildSetStatus({ id: '7', expectedVersion: 2, status: 'available' });
    assert.match(set.text, /^UPDATE cars c SET status = 'available'\s+WHERE c\.id = \$1::bigint AND c\.source_type = 'showroom' AND c\.deleted_at IS NULL AND c\.version = \$2/);
    assert.deepEqual(set.values, ['7', 2]);
    assert.throws(() => buildSetStatus({ id: '7', expectedVersion: 2, status: 'pending' as never }));
  });

  it('the SET list comes only from the fixed column map; nothing writes ownership, source, version or member-only columns', () => {
    assert.deepEqual(Object.values(COLUMN_OF).sort(), ['brand', 'color', 'currency', 'description', 'fuel_type', 'mileage', 'model', 'price', 'transmission', 'year']);
    assert.throws(() => buildUpdate({ id: '1', showroomId: '1', expectedVersion: 1, changes: { showroom_id: '2' } as never, status: null, searchText: '' }));
    const src = code('src/showroom-cars/repository.ts');
    assert.ok(!/SELECT\s+\*/i.test(src));
    const setClauses = [...src.matchAll(/SET\s+([^`]*?)\s+WHERE/g)].map((m) => m[1]).join(' ');
    assert.ok(!/\b(showroom_id|owner_id|source_type|version|updated_at|created_at|reviewed_by|phone)\s*=/.test(setClauses), setClauses);
    assert.ok(!/\b(INSERT INTO|UPDATE|DELETE FROM)\s+(users|showrooms|favorites|car_images|assets)\b/i.test(src), 'only cars is written');
    assert.ok(!/DELETE FROM cars/i.test(src), 'no hard delete');
  });

  it('the acting-user re-check locks an active, not deleted account by the actor id', async () => {
    assert.equal(LOCK_ACTING_USER_SQL, "SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE");
    const seen: Array<readonly unknown[] | undefined> = [];
    const repo = createPgShowroomCarRepository({ query: async (_t: string, values?: readonly unknown[]) => { seen.push(values); return { rows: [{ id: '1', owner_id: '10', status: 'active' }], rowCount: 1 } as never; } });
    assert.equal(await repo.lockActingUser('10'), true);
    assert.deepEqual(await repo.findShowroomOfOwner('10'), { id: '1', ownerId: '10', status: 'active' });
    assert.deepEqual(seen, [['10'], ['10']]);
  });

  it('the service and routes never take a showroom or owner from the request; the owner is the actor', () => {
    const svc = code('src/showroom-cars/service.ts');
    const routes = code('src/showroom-cars/routes.ts');
    assert.ok(!/request\.|headers/.test(svc), 'the service sees no HTTP object');
    assert.ok(!/showroomId|ownerId|owner_id|showroom_id/.test(routes));
    assert.match(routes, /return toActor\(found\.user\);/);
    assert.match(svc, /findShowroomOfOwner\(actor\.id\)/);
    assert.match(svc, /if \(!actor \|\| actor\.role !== 'dealer'\) throw notFound\(\);/);
    assert.match(svc, /if \(id === null \|\| !actor \|\| actor\.role !== 'admin'\) throw notFound\(\);/);
  });

  it('the routes are wired only together with authentication, and the process supplies the Postgres-backed service', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.showroomCars\) registerShowroomCarRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createShowroomCarService\(\{ store: createPgShowroomCarStore\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\bshowroomCars\b/);
  });
});

// Phase 11.5, Step 5.3: the public catalog service, against an in-memory fake that applies the SAME predicates as the database
// views. Covers visibility, filtering, pagination, non-disclosure (IDOR), invalid input and the output whitelist.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { CatalogError, createCatalogService } from '../../src/catalog/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { CATALOG_LIMIT_DEFAULT, CATALOG_LIMIT_MAX, SEARCH_MAX_LENGTH } from '../../src/catalog/params.ts';
import { makeFakeCatalog } from '../helpers/fake-catalog.ts';

type Fields = Array<{ field: string; code: string }>;

async function fieldsOf(p: Promise<unknown>): Promise<Fields> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof CatalogError, `expected a CatalogError, got ${String(e)}`);
    return e.fields;
  }
  assert.fail('expected a validation error');
}

async function assertNotFound(p: Promise<unknown>): Promise<void> {
  await assert.rejects(p, (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
}

/** A small, realistic dataset: one public showroom, one hidden per reason, and cars of every kind. */
function seed() {
  const f = makeFakeCatalog();
  f.addUser({ id: '1', status: 'active' }); // dealer, active
  f.addUser({ id: '2', status: 'suspended' }); // dealer, suspended
  f.addUser({ id: '3', status: 'active', deleted: true }); // dealer, deleted
  f.addUser({ id: '10', status: 'active' }); // member
  f.addUser({ id: '11', status: 'active' }); // member, active
  f.addUser({ id: '12', status: 'suspended' }); // member, suspended
  f.addShowroom({ id: '100', ownerId: '1', name: 'معرض بغداد', address: 'بغداد - الكرادة' });
  f.addShowroom({ id: '101', ownerId: '1', status: 'pending', name: 'معرض قيد المراجعة' });
  f.addShowroom({ id: '102', ownerId: '1', status: 'suspended', name: 'معرض موقوف' });
  f.addShowroom({ id: '103', ownerId: '2', name: 'معرض مالك موقوف' }); // owner suspended -> hidden
  f.addShowroom({ id: '104', ownerId: '1', deleted: true, name: 'معرض محذوف' });
  f.addShowroom({ id: '105', ownerId: '3', name: 'معرض مالك محذوف' }); // owner deleted -> hidden
  f.addShowroom({ id: '106', ownerId: '1', name: 'معرض أربيل', address: 'أربيل' });
  // showroom cars
  f.addCar({ id: '200', sourceType: 'showroom', showroomId: '100', ownerId: '1', brand: 'Toyota', model: 'Camry', year: 2015, price: '12000', currency: 'USD', status: 'available', color: 'أبيض', fuelType: 'بنزين', transmission: 'أوتوماتيك' });
  f.addCar({ id: '201', sourceType: 'showroom', showroomId: '100', ownerId: '1', brand: 'Hyundai', model: 'Elantra', year: 2019, price: '15000000', currency: 'IQD', status: 'sold', color: 'أسود', fuelType: 'هايبرد', transmission: 'يدوي' });
  f.addCar({ id: '202', sourceType: 'showroom', showroomId: '101', ownerId: '1', brand: 'Kia', model: 'Rio' }); // pending showroom -> hidden
  f.addCar({ id: '203', sourceType: 'showroom', showroomId: '103', ownerId: '2', brand: 'Kia', model: 'Cerato' }); // owner suspended -> hidden
  f.addCar({ id: '204', sourceType: 'showroom', showroomId: '100', ownerId: '1', brand: 'Ford', model: 'Focus', deleted: true }); // deleted -> hidden
  // member cars
  f.addCar({ id: '300', sourceType: 'member', showroomId: null, ownerId: '11', status: 'active', brand: 'Toyota', model: 'Corolla', year: 2010, price: '8000', currency: 'USD', ownerName: 'أحمد' });
  f.addCar({ id: '301', sourceType: 'member', showroomId: null, ownerId: '11', status: 'pending', brand: 'Toyota', model: 'Yaris' });
  f.addCar({ id: '302', sourceType: 'member', showroomId: null, ownerId: '11', status: 'sold', brand: 'Toyota', model: 'Avalon' });
  f.addCar({ id: '303', sourceType: 'member', showroomId: null, ownerId: '11', status: 'rejected', brand: 'Toyota', model: 'Prius' });
  f.addCar({ id: '304', sourceType: 'member', showroomId: null, ownerId: '11', status: 'suspended', brand: 'Toyota', model: 'Auris' });
  f.addCar({ id: '305', sourceType: 'member', showroomId: null, ownerId: '12', status: 'active', brand: 'Toyota', model: 'Supra' }); // suspended owner
  f.addCar({ id: '306', sourceType: 'member', showroomId: null, ownerId: '11', status: 'active', deleted: true, brand: 'Toyota', model: 'Sienna' });
  return f;
}

describe('catalog visibility: showrooms', () => {
  it('lists only active showrooms of active owners', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const page = await svc.listShowrooms({});
    assert.deepEqual(page.items.map((s) => s.id).sort(), ['100', '106']);
  });

  it('a hidden showroom detail is the same 404 as a missing one', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    for (const id of ['101', '102', '103', '104', '105', '999999']) await assertNotFound(svc.getShowroom(id));
  });

  it('a public showroom detail exposes only the whitelisted fields', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const s = await svc.getShowroom('100');
    assert.deepEqual(Object.keys(s).sort(), ['address', 'createdAt', 'description', 'id', 'latitude', 'longitude', 'name', 'phone', 'services', 'updatedAt', 'whatsapp', 'workingHours'].sort());
    assert.equal(s.id, '100');
  });
});

describe('catalog visibility: cars', () => {
  it('lists showroom cars of public showrooms and active member cars of active owners only', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const page = await svc.listCars({});
    assert.deepEqual(page.items.map((c) => c.id).sort(), ['200', '201', '300']);
  });

  it('hides pending, sold-by-member, rejected and suspended member cars, deleted cars, and cars of hidden showrooms or owners', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const ids = (await svc.listCars({})).items.map((c) => c.id);
    for (const hidden of ['202', '203', '204', '301', '302', '303', '304', '305', '306']) assert.ok(!ids.includes(hidden), `car ${hidden} must not be listed`);
  });

  it('a hidden car detail is the same 404 as a missing one', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    for (const id of ['202', '203', '204', '301', '303', '305', '306', '999999']) await assertNotFound(svc.getCar(id));
  });

  it('a public car detail exposes only the whitelisted fields (no owner id, no status of the owner, no search text)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const car = await svc.getCar('300');
    const keys = Object.keys(car).sort();
    assert.deepEqual(keys, [
      'brand', 'color', 'createdAt', 'currency', 'description', 'fuelType', 'id', 'latitude', 'location', 'longitude', 'mileage', 'model', 'ownerName', 'phone',
      'price', 'showroomId', 'sourceType', 'status', 'transmission', 'updatedAt', 'whatsapp', 'year',
    ]);
    assert.equal(car.price, 8000);
    assert.equal(typeof car.price, 'number');
  });

  it('a showroom car exposes no owner name (only member cars carry one)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.equal((await svc.getCar('200')).ownerName, null);
  });
});

describe('catalog filters: whitelist and semantics', () => {
  it('q matches brand, model, colour and search text, case-insensitively and after NFKC folding', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual((await svc.listCars({ q: 'TOYOTA' })).items.map((c) => c.id), ['300', '200']);
    assert.deepEqual((await svc.listCars({ q: '  camry  ' })).items.map((c) => c.id), ['200']);
    assert.deepEqual((await svc.listCars({ q: 'ｃａｍｒｙ' })).items.map((c) => c.id), ['200']); // full-width folds to ASCII
  });

  it('several q terms must ALL match (AND across terms)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual((await svc.listCars({ q: 'toyota camry' })).items.map((c) => c.id), ['200']);
    assert.deepEqual((await svc.listCars({ q: 'toyota camry corolla' })).items.map((c) => c.id), []);
  });

  it('a showroom search matches the name and the address', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual((await svc.listShowrooms({ q: 'الكرادة' })).items.map((s) => s.id), ['100']);
    assert.deepEqual((await svc.listShowrooms({ q: 'أربيل' })).items.map((s) => s.id), ['106']);
  });

  it('each exact filter narrows the result (source, showroomId, brand, model, color, transmission, fuelType, status, currency)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const ids = async (q: Record<string, string>) => (await svc.listCars(q)).items.map((c) => c.id);
    assert.deepEqual(await ids({ source: 'member' }), ['300']);
    assert.deepEqual(await ids({ source: 'showroom' }), ['201', '200']);
    assert.deepEqual(await ids({ showroomId: '100' }), ['201', '200']);
    assert.deepEqual(await ids({ brand: 'toyota' }), ['300', '200']);
    assert.deepEqual(await ids({ model: 'CAMRY' }), ['200']);
    assert.deepEqual(await ids({ color: 'أسود' }), ['201']);
    assert.deepEqual(await ids({ transmission: 'يدوي' }), ['201']);
    assert.deepEqual(await ids({ fuelType: 'هايبرد' }), ['201']);
    assert.deepEqual(await ids({ status: 'sold' }), ['201']);
    assert.deepEqual(await ids({ status: 'active' }), ['300']);
    assert.deepEqual(await ids({ currency: 'IQD' }), ['201']);
  });

  it('year range is inclusive', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual((await svc.listCars({ yearMin: '2015', yearMax: '2019' })).items.map((c) => c.id), ['201', '200']);
    assert.deepEqual((await svc.listCars({ yearMin: '2016' })).items.map((c) => c.id), ['201']);
  });

  it('a price range is compared only within the named currency, never across currencies', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    // 15,000,000 IQD must NOT match a USD range that would include it numerically.
    assert.deepEqual((await svc.listCars({ currency: 'USD', priceMin: '0', priceMax: '20000000' })).items.map((c) => c.id), ['300', '200']);
    assert.deepEqual((await svc.listCars({ currency: 'IQD', priceMin: '1000000' })).items.map((c) => c.id), ['201']);
  });

  it('a price range without a currency is refused (field currency, code required)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars({ priceMin: '1000' })), [{ field: 'currency', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ priceMax: '1000' })), [{ field: 'currency', code: 'required' }]);
  });
});

describe('catalog invalid input: refused with field names and codes only', () => {
  it('unknown keys are refused (unknown_field)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars({ ownerId: '1' })), [{ field: 'ownerId', code: 'unknown_field' }]);
    assert.deepEqual(await fieldsOf(svc.listShowrooms({ status: 'pending' })), [{ field: 'status', code: 'unknown_field' }]);
  });

  it('an unsafe key name is reported as unknown, never echoed', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const fields = await fieldsOf(svc.listCars({ "<script>alert('x')</script>": '1' }));
    assert.deepEqual(fields, [{ field: 'unknown', code: 'unknown_field' }]);
  });

  it('repeated keys (arrays) are refused (invalid_type)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars({ brand: ['Toyota', 'Kia'] })), [{ field: 'brand', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ limit: ['10'] })), [{ field: 'limit', code: 'invalid_type' }]);
  });

  it('enumerated filters outside the whitelist are refused (invalid_format)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    for (const [key, value] of [
      ['source', 'admin'],
      ['transmission', 'Automatic'],
      ['fuelType', 'LPG'],
      ['status', 'pending'],
      ['status', 'deleted'],
      ['currency', 'EUR'],
    ] as const) {
      assert.deepEqual(await fieldsOf(svc.listCars({ [key]: value })), [{ field: key, code: 'invalid_format' }], `${key}=${value}`);
    }
  });

  it('year and price bounds are checked, and a reversed range is refused', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars({ yearMin: '1979' })), [{ field: 'yearMin', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ yearMax: '2101' })), [{ field: 'yearMax', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ yearMin: '2020', yearMax: '2010' })), [{ field: 'yearMax', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ currency: 'USD', priceMin: '-1' })), [{ field: 'priceMin', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ currency: 'USD', priceMin: '1e3' })), [{ field: 'priceMin', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ currency: 'USD', priceMin: '1000000000000000' })), [{ field: 'priceMin', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ currency: 'USD', priceMin: '500', priceMax: '100' })), [{ field: 'priceMax', code: 'invalid_format' }]);
  });

  it('malformed ids in filters are refused', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    // 9223372036854775808 and up do not fit PostgreSQL bigint: refused here, not as a database error.
    for (const v of ['0', '-1', 'abc', '1.5', '01', '9223372036854775808', '99999999999999999999']) assert.deepEqual(await fieldsOf(svc.listCars({ showroomId: v })), [{ field: 'showroomId', code: 'invalid_format' }], v);
    assert.deepEqual(await fieldsOf(svc.listCars({ before: '9223372036854775808' })), [{ field: 'before', code: 'invalid_format' }]);
  });

  it('limit must be a positive integer no greater than the maximum', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    for (const v of ['0', '-5', '1.5', '1e1', '', ` ${CATALOG_LIMIT_DEFAULT}`, String(CATALOG_LIMIT_MAX + 1), '0050']) {
      assert.deepEqual(await fieldsOf(svc.listShowrooms({ limit: v })), [{ field: 'limit', code: 'invalid_format' }], `limit=${JSON.stringify(v)}`);
    }
  });

  it('a search longer than the bound, or with more terms than allowed, is refused (too_long)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars({ q: 'a'.repeat(SEARCH_MAX_LENGTH + 1) })), [{ field: 'q', code: 'too_long' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ q: 'a b c d e f' })), [{ field: 'q', code: 'too_long' }]);
  });

  it('control characters in the search are refused (invalid_format)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars({ q: 'toyota\u0000' })), [{ field: 'q', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listCars({ q: 'toyota\u0007' })), [{ field: 'q', code: 'invalid_format' }]);
  });

  it('the query itself must be a plain object', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.deepEqual(await fieldsOf(svc.listCars('brand=toyota')), [{ field: 'query', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.listShowrooms([])), [{ field: 'query', code: 'invalid_type' }]);
  });

  it('error objects never carry the submitted values', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const secret = 'SECRET-VALUE-7731';
    const fields = await fieldsOf(svc.listCars({ brand: secret, yearMin: secret, limit: secret }));
    assert.ok(!JSON.stringify(fields).includes(secret));
    const err = await svc.listCars({ yearMin: secret }).catch((e: unknown) => e);
    assert.ok(err instanceof CatalogError);
    assert.ok(!JSON.stringify({ message: err.message, fields: err.fields }).includes(secret));
  });

  it('invalid input never reaches the repository', async () => {
    const f = seed();
    const svc = createCatalogService({ repo: f.repo });
    await fieldsOf(svc.listCars({ status: 'pending' }));
    await fieldsOf(svc.listShowrooms({ limit: '0' }));
    assert.deepEqual(f.calls, []);
  });
});

describe('catalog pagination', () => {
  function many(n: number) {
    const f = makeFakeCatalog();
    f.addUser({ id: '1' });
    f.addShowroom({ id: '5000', ownerId: '1' });
    for (let i = 1; i <= n; i++) f.addCar({ id: String(100 + i), showroomId: '5000', ownerId: '1', brand: 'Kia', model: `M${i}` });
    return f;
  }

  it('uses a default limit when none is given, and accepts the maximum', async () => {
    const svc = createCatalogService({ repo: many(60).repo });
    assert.equal((await svc.listCars({})).items.length, CATALOG_LIMIT_DEFAULT);
    assert.equal((await svc.listCars({ limit: String(CATALOG_LIMIT_MAX) })).items.length, CATALOG_LIMIT_MAX);
  });

  it('returns items in stable id-descending order', async () => {
    const svc = createCatalogService({ repo: many(5).repo });
    const ids = (await svc.listCars({ limit: '10' })).items.map((c) => Number(c.id));
    assert.deepEqual(ids, [105, 104, 103, 102, 101]);
  });

  it('nextBefore is set only when a full page came back, and walking the cursor sees every item exactly once', async () => {
    const svc = createCatalogService({ repo: many(7).repo });
    const first = await svc.listCars({ limit: '3' });
    assert.equal(first.items.length, 3);
    assert.equal(first.nextBefore, first.items[2]!.id);

    const second = await svc.listCars({ limit: '3', before: first.nextBefore! });
    assert.equal(second.items.length, 3);
    assert.equal(second.nextBefore, second.items[2]!.id);

    const third = await svc.listCars({ limit: '3', before: second.nextBefore! });
    assert.equal(third.items.length, 1);
    assert.equal(third.nextBefore, null, 'a short page is the last page');

    const all = [...first.items, ...second.items, ...third.items].map((c) => c.id);
    assert.equal(new Set(all).size, 7);
    assert.deepEqual(all, ['107', '106', '105', '104', '103', '102', '101']);
  });

  it('a full last page still reports a cursor; the next request then returns an empty page with no cursor', async () => {
    const svc = createCatalogService({ repo: many(4).repo });
    const p1 = await svc.listCars({ limit: '2' });
    const p2 = await svc.listCars({ limit: '2', before: p1.nextBefore! });
    assert.equal(p2.nextBefore, p2.items[1]!.id);
    const p3 = await svc.listCars({ limit: '2', before: p2.nextBefore! });
    assert.deepEqual(p3, { items: [], nextBefore: null });
  });

  it('hidden records do not disturb the cursor: pages are still stable', async () => {
    const f = many(6);
    const svc = createCatalogService({ repo: f.repo });
    const p1 = await svc.listCars({ limit: '3' });
    // Hide the item right after the cursor, then continue from the cursor.
    f.cars.get('103')!.deleted = true;
    const p2 = await svc.listCars({ limit: '3', before: p1.nextBefore! });
    assert.deepEqual(p2.items.map((c) => c.id), ['102', '101']);
  });

  it('a cursor for a record that is now hidden still pages from the correct place', async () => {
    const f = many(6);
    const svc = createCatalogService({ repo: f.repo });
    f.cars.get('104')!.deleted = true;
    const p = await svc.listCars({ limit: '10', before: '104' });
    assert.deepEqual(p.items.map((c) => c.id), ['103', '102', '101']);
  });

  it('showroom pagination follows the same rules', async () => {
    const f = makeFakeCatalog();
    f.addUser({ id: '1' });
    for (let i = 1; i <= 4; i++) f.addShowroom({ id: String(200 + i), ownerId: '1' });
    const svc = createCatalogService({ repo: f.repo });
    const p1 = await svc.listShowrooms({ limit: '2' });
    assert.deepEqual(p1.items.map((s) => s.id), ['204', '203']);
    const p2 = await svc.listShowrooms({ limit: '2', before: p1.nextBefore! });
    assert.deepEqual(p2.items.map((s) => s.id), ['202', '201']);
    assert.equal(p2.nextBefore, '201');
  });
});

describe('catalog non-disclosure (IDOR)', () => {
  it('malformed, missing, hidden and unknown ids produce the SAME 404 (same class, code and message)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const outcome = async (id: unknown) => {
      try {
        await svc.getCar(id);
        return 'ok';
      } catch (e) {
        assert.ok(e instanceof AuthzError, `expected AuthzError for ${String(id)}`);
        return `${e.code}|${e.message}`;
      }
    };
    const reference = await outcome('999999'); // unknown
    assert.ok(reference.startsWith('not_found|'), reference);
    for (const id of ['202', '204', '301', '305', '0', '-1', 'abc', '1.5', '01', '1e3', '', ' 300', '300 ', '9223372036854775808', '9999999999999999999999', undefined, null, 300, {}, ['300']]) {
      assert.equal(await outcome(id), reference, `id ${JSON.stringify(id)} must look like a missing record`);
    }
  });

  it('a malformed id never reaches the repository (no query is issued)', async () => {
    const f = seed();
    const svc = createCatalogService({ repo: f.repo });
    for (const id of ['abc', '0', '1.5', '9223372036854775808', undefined]) await assertNotFound(svc.getShowroom(id));
    for (const id of ['abc', '0', '1.5', '9223372036854775808', undefined]) await assertNotFound(svc.getCar(id));
    assert.deepEqual(f.calls, []);
  });

  it('a public record is returned by its own id and by no other', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    assert.equal((await svc.getCar('200')).id, '200');
    await assertNotFound(svc.getCar('201x'));
    await assertNotFound(svc.getShowroom('100 '));
  });

  it('a hidden showroom id given to the car list as showroomId returns an empty list, not an error (no existence oracle)', async () => {
    const svc = createCatalogService({ repo: seed().repo });
    const hidden = await svc.listCars({ showroomId: '101' });
    const missing = await svc.listCars({ showroomId: '999999' });
    assert.deepEqual(hidden, missing);
    assert.deepEqual(hidden.items, []);
  });
});

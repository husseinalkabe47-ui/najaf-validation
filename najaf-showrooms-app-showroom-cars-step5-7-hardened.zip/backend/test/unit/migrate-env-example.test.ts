import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { MIGRATION_ENV_VARS, loadMigrationConfig } from '../../src/migrate/config.ts';

const example = readFileSync(join(import.meta.dirname, '..', '..', '.env.migrations.example'), 'utf8');

describe('.env.migrations.example documents the migration configuration exactly', () => {
  const documented = new Set([...example.matchAll(/^#?\s*([A-Z][A-Z0-9_]*)=/gm)].map((m) => m[1] as string));

  it('every variable the code reads is documented', () => {
    for (const v of MIGRATION_ENV_VARS) assert.ok(documented.has(v), `${v} is not documented`);
  });

  it('nothing the code does not read is listed', () => {
    for (const v of documented) assert.ok((MIGRATION_ENV_VARS as readonly string[]).includes(v), `${v} is listed but not read`);
  });

  it('the uncommented lines form a valid configuration with a DIFFERENT account than DATABASE_URL', () => {
    const env: Record<string, string> = {};
    for (const m of example.matchAll(/^([A-Z][A-Z0-9_]*)=(.*)$/gm)) env[m[1] as string] = (m[2] as string).trim();
    const c = loadMigrationConfig(env);
    assert.equal(c.client.user, 'najaf_migrator');
    assert.notEqual(c.client.user, 'najaf_app_login');
    assert.equal(c.allowRollback, false);
  });
});

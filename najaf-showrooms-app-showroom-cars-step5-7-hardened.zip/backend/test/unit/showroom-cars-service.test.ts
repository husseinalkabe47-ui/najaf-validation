// Phase 11.5, Step 5.7: a dealer's own showroom cars and the administrator's status change, through the real service and the real
// policy (src/authz), over an in-memory store that mirrors the SQL scoping, the CHECKs, the version trigger and the soft-delete trigger.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { ShowroomCarError, createShowroomCarService } from '../../src/showroom-cars/service.ts';
import { makeFakeShowroomCarStore } from '../helpers/fake-showroom-cars.ts';

const D1: Actor = Object.freeze({ id: '10', role: 'dealer' });
const D2: Actor = Object.freeze({ id: '11', role: 'dealer' });
const NOSHOW: Actor = Object.freeze({ id: '12', role: 'dealer' });
const M: Actor = Object.freeze({ id: '20', role: 'member' });
const ADMIN: Actor = Object.freeze({ id: '30', role: 'admin' });

const VALID = { brand: 'Toyota', model: 'Land Cruiser', year: 2021, price: 95000, currency: 'USD', color: 'أبيض' };

function setup() {
  const f = makeFakeShowroomCarStore();
  for (const a of [D1, D2, NOSHOW, M, ADMIN]) f.addUser(a.id);
  const s1 = f.addShowroom({ ownerId: D1.id });
  const s2 = f.addShowroom({ ownerId: D2.id });
  const car1 = f.addCar({ showroomId: s1.id });
  const car2 = f.addCar({ showroomId: s2.id });
  const memberCar = f.addCar({ sourceType: 'member', ownerId: M.id });
  const svc = createShowroomCarService({ store: f.store });
  return { f, svc, s1, s2, car1, car2, memberCar };
}

const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isErr = (code: string) => (e: unknown) => e instanceof ShowroomCarError && e.code === code;
type Fields = Array<{ field: string; code: string }>;
async function fieldsOf(p: Promise<unknown>): Promise<Fields> {
  try {
    await p;
  } catch (e) {
    if (e instanceof ShowroomCarError && e.code === 'validation_failed') return e.fields ?? [];
    throw e;
  }
  throw new Error('expected a validation error');
}
const outcome = (p: Promise<unknown>) => p.then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : `other:${String(e)}`));

describe('dealer cars: create', () => {
  it('creates an AVAILABLE car in the dealer\'s own showroom (no approval), whitelist DTO, audit with numbers only', async () => {
    const { f, svc, s1 } = setup();
    const car = await svc.create(D1, VALID, { requestId: 'req-1' });
    assert.equal(car.status, 'available');
    assert.equal(car.showroomId, s1.id);
    assert.equal(car.version, 1);
    assert.equal(car.price, 95000);
    assert.equal(car.mileage, null);
    assert.equal(car.transmission, 'أوتوماتيك');
    assert.deepEqual(Object.keys(car).sort(), ['brand', 'color', 'createdAt', 'currency', 'description', 'fuelType', 'id', 'mileage', 'model', 'price', 'showroomId', 'status', 'transmission', 'updatedAt', 'version', 'year']);
    const row = f.car(car.id);
    assert.equal(row.sourceType, 'showroom');
    assert.equal(row.ownerId, null);
    assert.match(row.searchText, /toyota land cruiser 2021/);
    assert.deepEqual(f.audits(), [{ action: 'showroom_car.create', actorUserId: D1.id, actorRole: 'dealer', entityType: 'car', entityId: car.id, afterData: { version: 1 }, requestId: 'req-1' }]);
  });

  it('the showroom, owner, source, status and member-only fields can never be sent (400 unknown_field), nothing is written', async () => {
    const { f, svc, s2 } = setup();
    const before = f.cars().length;
    for (const k of ['showroomId', 'showroom_id', 'ownerId', 'sourceType', 'status', 'version', 'phone', 'whatsapp', 'location', 'latitude', 'id', 'deletedAt']) {
      assert.deepEqual(await fieldsOf(svc.create(D1, { ...VALID, [k]: k === 'showroomId' ? s2.id : 'x' })), [{ field: k, code: 'unknown_field' }], k);
    }
    assert.equal(f.cars().length, before);
    assert.deepEqual(f.calls, [], 'invalid input never reaches the store');
  });

  it('validates every field against the table: required, types, ranges, vocabularies, lengths, control characters', async () => {
    const { svc } = setup();
    assert.deepEqual(await fieldsOf(svc.create(D1, {})), ['brand', 'model', 'year', 'price', 'currency'].map((field) => ({ field, code: 'required' })));
    const bad: Array<[Record<string, unknown>, string, string]> = [
      [{ year: 1979 }, 'year', 'invalid_format'],
      [{ year: '2020' }, 'year', 'invalid_type'],
      [{ price: 0 }, 'price', 'invalid_format'],
      [{ price: 1.5 }, 'price', 'invalid_format'],
      [{ currency: 'EUR' }, 'currency', 'invalid_format'],
      [{ mileage: -1 }, 'mileage', 'invalid_format'],
      [{ transmission: 'CVT' }, 'transmission', 'invalid_format'],
      [{ fuelType: 'gas' }, 'fuelType', 'invalid_format'],
      [{ brand: '!!!' }, 'brand', 'invalid_format'],
      [{ brand: '   ' }, 'brand', 'required'],
      [{ brand: 'x'.repeat(51) }, 'brand', 'too_long'],
      [{ model: 'a\u0000b' }, 'model', 'invalid_format'],
      [{ color: 'c'.repeat(41) }, 'color', 'too_long'],
      [{ description: 'd'.repeat(2001) }, 'description', 'too_long'],
    ];
    for (const [patch, field, code] of bad) assert.deepEqual(await fieldsOf(svc.create(D1, { ...VALID, ...patch })), [{ field, code }], JSON.stringify(patch));
    for (const body of [null, [], 'x', 5]) assert.deepEqual(await fieldsOf(svc.create(D1, body)), [{ field: 'body', code: 'invalid_type' }]);
    const secret = 'SECRET-VALUE';
    assert.ok(!JSON.stringify(await fieldsOf(svc.create(D1, { ...VALID, currency: secret }))).includes(secret));
  });

  it('a member, an administrator, no actor, and a dealer without a showroom get 404; nothing is written', async () => {
    const { f, svc } = setup();
    const before = f.cars().length;
    for (const who of [M, ADMIN, null, NOSHOW]) assert.equal(await outcome(svc.create(who, VALID)), 'not_found|Not found', JSON.stringify(who));
    assert.equal(f.cars().length, before);
    assert.deepEqual(f.audits(), []);
  });

  it('an account suspended since its token was issued is refused inside the transaction (404)', async () => {
    const { f, svc } = setup();
    f.setUser(D1.id, 'suspended');
    await assert.rejects(svc.create(D1, VALID), isAuthz('not_found'));
    assert.deepEqual(f.audits(), []);
  });

  it('existing rule kept: the owner manages cars of a pending or suspended showroom (the car is stored available; the public view hides it)', async () => {
    const { f, svc, s1 } = setup();
    for (const status of ['pending', 'suspended']) {
      f.setShowroom(s1.id, status);
      assert.equal((await svc.create(D1, VALID)).status, 'available', status);
    }
  });

  it('an audit failure rolls the car back', async () => {
    const { f, svc } = setup();
    const before = f.cars().length;
    f.faults.failNextAudit = true;
    await assert.rejects(svc.create(D1, VALID), /audit insert failed/);
    assert.equal(f.cars().length, before);
  });
});

describe('dealer cars: ownership (IDOR/BOLA)', () => {
  it('another showroom\'s car, a member ad, a deleted car, an unknown and a malformed id are the same 404 for read, update and delete', async () => {
    const { f, svc, s1, car2, memberCar } = setup();
    const deleted = f.addCar({ showroomId: s1.id, deleted: true });
    const reference = await outcome(svc.getOwn(D1, '999999'));
    assert.equal(reference, 'not_found|Not found');
    for (const id of [car2.id, memberCar.id, deleted.id, '999999', 'abc', '0', '-1', '01', '9223372036854775808', undefined, 1, ['1']]) {
      assert.equal(await outcome(svc.getOwn(D1, id)), reference, `get ${JSON.stringify(id)}`);
      assert.equal(await outcome(svc.update(D1, id, { version: 1, price: 1 })), reference, `update ${JSON.stringify(id)}`);
      assert.equal(await outcome(svc.remove(D1, id, { version: '1' })), reference, `delete ${JSON.stringify(id)}`);
    }
    assert.equal(f.car(car2.id).version, 1);
    assert.equal(f.car(car2.id).price, '18500000');
    assert.equal(f.car(memberCar.id).version, 1);
    assert.deepEqual(f.audits(), []);
  });

  it('the dealer area does not exist for a member, an administrator or a dealer without a showroom: 404 on every item route', async () => {
    const { f, svc, car1 } = setup();
    for (const who of [M, ADMIN, NOSHOW, null]) {
      assert.equal(await outcome(svc.getOwn(who, car1.id)), 'not_found|Not found');
      assert.equal(await outcome(svc.update(who, car1.id, { version: 1, price: 1 })), 'not_found|Not found');
      assert.equal(await outcome(svc.remove(who, car1.id, { version: '1' })), 'not_found|Not found');
      assert.equal(await outcome(svc.listOwn(who, {})), 'not_found|Not found');
    }
    assert.equal(f.car(car1.id).version, 1, 'an administrator cannot edit or delete a dealer car');
    assert.equal(f.car(car1.id).deleted, false);
  });

  it('defense in depth: if the SQL scoping were broken, a row of another showroom still never leaves or changes', async () => {
    const { f, s2, car2 } = setup();
    const leaky = {
      ...f.store,
      cars: { ...f.store.cars, findOwn: async (id: string) => f.store.cars.findOwn(id, s2.id, false), listOwn: async (_s: string, q: Parameters<typeof f.store.cars.listOwn>[1]) => f.store.cars.listOwn(s2.id, q) },
      transaction: <T,>(fn: Parameters<typeof f.store.transaction<T>>[0]) =>
        f.store.transaction((repos) => fn({ ...repos, cars: { ...repos.cars, findOwn: async (id: string, _s: string, lock: boolean) => repos.cars.findOwn(id, s2.id, lock) } })),
    };
    const svc = createShowroomCarService({ store: leaky });
    await assert.rejects(svc.getOwn(D1, car2.id), isAuthz('not_found'));
    await assert.rejects(svc.update(D1, car2.id, { version: 1, price: 1 }), isAuthz('not_found'));
    await assert.rejects(svc.remove(D1, car2.id, { version: '1' }), isAuthz('not_found'));
    assert.deepEqual((await svc.listOwn(D1, {})).items, []);
    assert.equal(f.car(car2.id).version, 1);
  });

  it('a showroom row that does not belong to the actor is refused even if the lookup returned it', async () => {
    const { f, s2, car2 } = setup();
    const svc = createShowroomCarService({ store: { ...f.store, cars: { ...f.store.cars, findShowroomOfOwner: async () => ({ ...s2 }) } } });
    await assert.rejects(svc.getOwn(D1, car2.id), isAuthz('not_found'));
  });
});

describe('dealer cars: malformed ids and lost races', () => {
  it('a malformed id never reaches the store, on any item route (dealer or administrator)', async () => {
    const { f, svc } = setup();
    for (const id of ['abc', '0', '-1', '1.5', '01', ' 1', '9223372036854775808', undefined, null, 1, {}, ['1']]) {
      await assert.rejects(svc.getOwn(D1, id), isAuthz('not_found'));
      await assert.rejects(svc.update(D1, id, { version: 1, price: 1 }), isAuthz('not_found'));
      await assert.rejects(svc.remove(D1, id, { version: '1' }), isAuthz('not_found'));
      await assert.rejects(svc.setStatusAsAdmin(ADMIN, id, { version: 1, status: 'sold' }), isAuthz('not_found'));
    }
    assert.deepEqual(f.calls, []);
  });

  it('a delete that loses the compare-and-swap after the lock is 409; the car stays and nothing is audited', async () => {
    const { f, svc, car1 } = setup();
    f.faults.afterLock = () => f.bump(car1.id);
    await assert.rejects(svc.remove(D1, car1.id, { version: '1' }), isErr('version_conflict'));
    assert.equal(f.car(car1.id).deleted, false);
    assert.deepEqual(f.audits(), []);
  });
});

describe('dealer cars: list and read', () => {
  it('lists only the dealer\'s own cars that are not deleted, newest first, with status filter and keyset paging', async () => {
    const { f, svc, s1, car1 } = setup();
    const a = await svc.create(D1, VALID);
    const b = await svc.create(D1, VALID);
    await svc.update(D1, b.id, { version: 1, status: 'sold' });
    f.addCar({ showroomId: s1.id, deleted: true });
    assert.deepEqual((await svc.listOwn(D1, {})).items.map((c) => c.id), [b.id, a.id, car1.id]);
    assert.deepEqual((await svc.listOwn(D1, { status: 'sold' })).items.map((c) => c.id), [b.id]);
    const p1 = await svc.listOwn(D1, { limit: '2' });
    assert.deepEqual(p1.items.map((c) => c.id), [b.id, a.id]);
    const p2 = await svc.listOwn(D1, { limit: '2', before: p1.nextBefore! });
    assert.deepEqual(p2.items.map((c) => c.id), [car1.id]);
    assert.equal(p2.nextBefore, null);
    assert.deepEqual((await svc.listOwn(D2, {})).items.map((c) => c.showroomId), ['2']);
  });

  it('list query is validated strictly', async () => {
    const { f, svc } = setup();
    assert.deepEqual(await fieldsOf(svc.listOwn(D1, { limit: '0' })), [{ field: 'limit', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(D1, { limit: '51' })), [{ field: 'limit', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(D1, { before: 'x' })), [{ field: 'before', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(D1, { status: 'pending' })), [{ field: 'status', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(D1, { showroomId: '2' })), [{ field: 'showroomId', code: 'unknown_field' }]);
    assert.deepEqual(f.calls, []);
  });

  it('reads one own car', async () => {
    const { svc, car1 } = setup();
    assert.equal((await svc.getOwn(D1, car1.id)).id, car1.id);
  });
});

describe('dealer cars: update and versions', () => {
  it('updates the given fields with the version, refreshes search text, audits the field count', async () => {
    const { f, svc, car1 } = setup();
    const car = await svc.update(D1, car1.id, { version: 1, brand: 'Lexus', model: 'LX', price: 120000, currency: 'USD', mileage: null }, { requestId: 'req-u' });
    assert.equal(car.version, 2);
    assert.equal(car.brand, 'Lexus');
    assert.equal(car.price, 120000);
    assert.equal(car.status, 'available');
    assert.match(f.car(car1.id).searchText, /lexus lx 2020/);
    assert.deepEqual(f.audits().at(-1), { action: 'showroom_car.update', actorUserId: D1.id, actorRole: 'dealer', entityType: 'car', entityId: car1.id, afterData: { version: 2, fields: 5 }, requestId: 'req-u' });
  });

  it('the dealer switches available <-> sold; each transition is its own audit action', async () => {
    const { f, svc, car1 } = setup();
    assert.equal((await svc.update(D1, car1.id, { version: 1, status: 'sold' })).status, 'sold');
    assert.equal(f.audits().at(-1)!.action, 'showroom_car.mark_sold');
    assert.equal((await svc.update(D1, car1.id, { version: 2, status: 'available' })).status, 'available');
    assert.equal(f.audits().at(-1)!.action, 'showroom_car.mark_available');
    await svc.update(D1, car1.id, { version: 3, status: 'available', color: 'أسود' });
    assert.equal(f.audits().at(-1)!.action, 'showroom_car.update', 'no transition: a plain update');
  });

  it('a stale version is 409 version_conflict and nothing changes; a missing version is 400', async () => {
    const { f, svc, car1 } = setup();
    await svc.update(D1, car1.id, { version: 1, price: 2 });
    await assert.rejects(svc.update(D1, car1.id, { version: 1, price: 3 }), isErr('version_conflict'));
    assert.equal(f.car(car1.id).price, '2');
    assert.deepEqual(await fieldsOf(svc.update(D1, car1.id, { price: 3 })), [{ field: 'version', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.update(D1, car1.id, { version: 2 })), [{ field: 'body', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.update(D1, car1.id, { version: 2, brand: null })), [{ field: 'brand', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.update(D1, car1.id, { version: 2, status: 'pending' })), [{ field: 'status', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.update(D1, car1.id, { version: 2, showroomId: '2', phone: '0770' })), [{ field: 'showroomId', code: 'unknown_field' }, { field: 'phone', code: 'unknown_field' }]);
  });

  it('a write that loses the compare-and-swap after the lock is 409 and is rolled back with its audit', async () => {
    const { f, svc, car1 } = setup();
    f.faults.afterLock = () => f.bump(car1.id);
    await assert.rejects(svc.update(D1, car1.id, { version: 1, price: 7 }), isErr('version_conflict'));
    assert.equal(f.car(car1.id).price, '18500000');
    assert.deepEqual(f.audits(), []);
  });

  it('concurrent updates on the same version: exactly one wins, the others are 409', async () => {
    const { f, svc, car1 } = setup();
    const results = await Promise.allSettled([1, 2, 3, 4, 5].map((n) => svc.update(D1, car1.id, { version: 1, price: n })));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    for (const r of results) if (r.status === 'rejected') assert.ok(isErr('version_conflict')(r.reason));
    assert.equal(f.car(car1.id).version, 2);
    assert.equal(f.audits().length, 1);
  });
});

describe('dealer cars: soft delete', () => {
  it('soft-deletes with the version; favorites go (trigger); the car is then 404 everywhere and not listed', async () => {
    const { f, svc, car1 } = setup();
    f.addFavorite(M.id, car1.id);
    await svc.remove(D1, car1.id, { version: '1' }, { requestId: 'req-d' });
    assert.equal(f.car(car1.id).deleted, true, 'a soft delete: the row is kept');
    assert.deepEqual(f.favorites(), []);
    await assert.rejects(svc.getOwn(D1, car1.id), isAuthz('not_found'));
    await assert.rejects(svc.remove(D1, car1.id, { version: '2' }), isAuthz('not_found'));
    assert.ok(!(await svc.listOwn(D1, {})).items.some((c) => c.id === car1.id));
    assert.deepEqual(f.audits().at(-1), { action: 'showroom_car.delete', actorUserId: D1.id, actorRole: 'dealer', entityType: 'car', entityId: car1.id, afterData: { version: 1 }, requestId: 'req-d' });
  });

  it('a stale or missing version is refused and the car stays', async () => {
    const { f, svc, car1 } = setup();
    await svc.update(D1, car1.id, { version: 1, price: 2 });
    await assert.rejects(svc.remove(D1, car1.id, { version: '1' }), isErr('version_conflict'));
    assert.deepEqual(await fieldsOf(svc.remove(D1, car1.id, {})), [{ field: 'version', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.remove(D1, car1.id, { version: '2', force: '1' })), [{ field: 'force', code: 'unknown_field' }]);
    assert.equal(f.car(car1.id).deleted, false);
  });

  it('concurrent deletes: one succeeds, the rest find nothing (404); one audit row; an audit failure keeps the car', async () => {
    const { f, svc, car1, s1 } = setup();
    const results = await Promise.allSettled([0, 1, 2].map(() => svc.remove(D1, car1.id, { version: '1' })));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(f.audits().filter((a) => a.action === 'showroom_car.delete').length, 1);
    const other = f.addCar({ showroomId: s1.id });
    f.faults.failNextAudit = true;
    await assert.rejects(svc.remove(D1, other.id, { version: '1' }), /audit insert failed/);
    assert.equal(f.car(other.id).deleted, false);
  });
});

describe('admin: showroom car status', () => {
  it('an administrator changes the status of any showroom car, and only the status; audited as an admin transition', async () => {
    const { f, svc, car2 } = setup();
    const car = await svc.setStatusAsAdmin(ADMIN, car2.id, { version: 1, status: 'sold' }, { requestId: 'req-a' });
    assert.equal(car.status, 'sold');
    assert.equal(car.version, 2);
    const row = f.car(car2.id);
    assert.equal(row.brand, 'Toyota');
    assert.equal(row.price, '18500000');
    assert.deepEqual(f.audits(), [{ action: 'showroom_car.admin_mark_sold', actorUserId: ADMIN.id, actorRole: 'admin', entityType: 'car', entityId: car2.id, afterData: { version: 2 }, requestId: 'req-a' }]);
    await svc.setStatusAsAdmin(ADMIN, car2.id, { version: 2, status: 'available' });
    assert.equal(f.audits().at(-1)!.action, 'showroom_car.admin_mark_available');
  });

  it('the same status is a no-op: no write, no version bump, no audit', async () => {
    const { f, svc, car1 } = setup();
    const car = await svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1, status: 'available' });
    assert.equal(car.version, 1);
    assert.equal(f.car(car1.id).version, 1);
    assert.deepEqual(f.audits(), []);
    assert.ok(!f.calls.includes('setStatus'));
  });

  it('the body carries ONLY version and status: any car field (brand, price, showroomId, ...) is 400, and so is a member state', async () => {
    const { f, svc, car1 } = setup();
    for (const k of ['brand', 'price', 'showroomId', 'deletedAt', 'description']) {
      assert.deepEqual(await fieldsOf(svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1, status: 'sold', [k]: 'x' })), [{ field: k, code: 'unknown_field' }], k);
    }
    for (const status of ['pending', 'active', 'suspended', 'rejected', 'deleted']) assert.deepEqual(await fieldsOf(svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1, status })), [{ field: 'status', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1 })), [{ field: 'status', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.setStatusAsAdmin(ADMIN, car1.id, { status: 'sold' })), [{ field: 'version', code: 'required' }]);
    assert.equal(f.car(car1.id).version, 1);
  });

  it('a dealer (even the owner), a member and no actor get 404 before any read; nothing changes', async () => {
    const { f, svc, car1 } = setup();
    for (const who of [D1, D2, M, null]) assert.equal(await outcome(svc.setStatusAsAdmin(who, car1.id, { version: 1, status: 'sold' })), 'not_found|Not found');
    assert.deepEqual(f.calls, []);
    assert.equal(f.car(car1.id).status, 'available');
  });

  it('a member ad, a deleted car, an unknown and a malformed id are 404; a stale version is 409; a suspended admin is 404', async () => {
    const { f, svc, s1, car1, memberCar } = setup();
    const deleted = f.addCar({ showroomId: s1.id, deleted: true });
    for (const id of [memberCar.id, deleted.id, '999999', 'abc', '0']) await assert.rejects(svc.setStatusAsAdmin(ADMIN, id, { version: 1, status: 'sold' }), isAuthz('not_found'), String(id));
    assert.equal(f.car(memberCar.id).status, 'active');
    await assert.rejects(svc.setStatusAsAdmin(ADMIN, car1.id, { version: 9, status: 'sold' }), isErr('version_conflict'));
    f.setUser(ADMIN.id, 'suspended');
    await assert.rejects(svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1, status: 'sold' }), isAuthz('not_found'));
    assert.equal(f.car(car1.id).status, 'available');
  });

  it('works whatever the showroom state (a car of a suspended showroom can be marked sold)', async () => {
    const { f, svc, s2, car2 } = setup();
    f.setShowroom(s2.id, 'suspended');
    f.setUser(D2.id, 'suspended');
    assert.equal((await svc.setStatusAsAdmin(ADMIN, car2.id, { version: 1, status: 'sold' })).status, 'sold');
  });

  it('an admin status change and a dealer update racing on the same version: exactly one wins', async () => {
    const { f, svc, car1 } = setup();
    const [a, b] = await Promise.allSettled([svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1, status: 'sold' }), svc.update(D1, car1.id, { version: 1, price: 5 })]);
    assert.equal([a, b].filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(f.car(car1.id).version, 2);
    assert.equal(f.audits().length, 1);
  });

  it('a lost compare-and-swap after the lock is 409 and nothing is audited', async () => {
    const { f, svc, car1 } = setup();
    f.faults.afterLock = () => f.bump(car1.id);
    await assert.rejects(svc.setStatusAsAdmin(ADMIN, car1.id, { version: 1, status: 'sold' }), isErr('version_conflict'));
    assert.equal(f.car(car1.id).status, 'available');
    assert.deepEqual(f.audits(), []);
  });
});

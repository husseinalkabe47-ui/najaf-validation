import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DbError, describeError, isDriverError, mapDriverError } from '../../src/errors.ts';
import { toHttpError } from '../../src/http-errors.ts';
import { pgError } from '../helpers/fake-pool.ts';

describe('errors: SQLSTATE classification', () => {
  const table: Array<[string, string]> = [
    ['23505', 'unique'],
    ['23503', 'foreign_key'],
    ['23001', 'foreign_key'],
    ['23514', 'check'],
    ['23502', 'not_null'],
    ['23P01', 'check'],
    ['42501', 'forbidden'],
    ['57014', 'timeout'],
    ['55P03', 'timeout'],
    ['40001', 'serialization'],
    ['40P01', 'deadlock'],
    ['28P01', 'auth_failed'],
    ['28000', 'auth_failed'],
    ['22P02', 'invalid_value'],
    ['22001', 'invalid_value'],
    ['22003', 'invalid_value'],
    ['08006', 'unavailable'],
    ['57P01', 'unavailable'],
    ['53300', 'unavailable'],
    ['3D000', 'unavailable'],
    ['XX000', 'unknown'],
  ];
  for (const [code, kind] of table) {
    it(`${code} -> ${kind}`, () => {
      assert.equal(mapDriverError(pgError(code)).kind, kind);
    });
  }

  it('maps network failures to unavailable', () => {
    for (const code of ['ECONNREFUSED', 'ECONNRESET', 'ENOTFOUND', 'ETIMEDOUT', 'EAI_AGAIN']) {
      assert.equal(mapDriverError(Object.assign(new Error('x'), { code })).kind, 'unavailable', code);
    }
  });

  it('maps node-postgres connection messages (no SQLSTATE) to unavailable', () => {
    for (const m of ['timeout exceeded when trying to connect', 'Connection terminated unexpectedly', 'Cannot use a pool after calling end on the pool']) {
      assert.equal(mapDriverError(new Error(m)).kind, 'unavailable', m);
    }
  });

  it('keeps the SQLSTATE and constraint name for server-side logic', () => {
    const e = mapDriverError(pgError('23505', 'duplicate key value violates unique constraint "users_phone_active_uq"', { constraint: 'users_phone_active_uq' }));
    assert.equal(e.sqlstate, '23505');
    assert.equal(e.constraint, 'users_phone_active_uq');
  });
});

describe('errors: nothing sensitive in the public surface', () => {
  const leaky = pgError('23505', 'duplicate key value violates unique constraint "users_phone_active_uq"', {
    constraint: 'users_phone_active_uq',
    detail: 'Key (phone_e164)=(+9647701234567) already exists.',
    query: 'INSERT INTO users (phone_e164) VALUES ($1)',
    parameters: ['+9647701234567'],
  });

  it('message and JSON are generic and carry no SQL, values or driver text', () => {
    const e = mapDriverError(leaky);
    const json = JSON.stringify(e);
    assert.equal(e.message, 'database operation failed: unique violation');
    for (const secret of ['+9647701234567', 'INSERT', 'Key (phone_e164)', 'duplicate key']) {
      assert.ok(!json.includes(secret), secret);
      assert.ok(!e.message.includes(secret), secret);
    }
  });

  it('keeps the driver message for server logs only', () => {
    const e = mapDriverError(leaky);
    assert.ok(e.driverMessage?.includes('duplicate key'));
    assert.ok(!e.driverMessage?.includes('+9647701234567'));
  });

  it('retryable only for serialization failures and deadlocks', () => {
    assert.equal(mapDriverError(pgError('40001')).retryable, true);
    assert.equal(mapDriverError(pgError('40P01')).retryable, true);
    assert.equal(mapDriverError(pgError('23505')).retryable, false);
  });

  it('describeError gives log-safe descriptions for every error shape', () => {
    assert.equal(describeError(new DbError('timeout', { sqlstate: '57014' }))['kind'], 'timeout');
    assert.deepEqual(describeError(new TypeError('boom')), { name: 'TypeError', message: 'boom' });
    assert.deepEqual(describeError('plain'), { message: 'plain' });
  });
});

describe('errors: programming errors are never classified as database errors', () => {
  it('isDriverError is false for ordinary errors and values', () => {
    assert.equal(isDriverError(new Error('boom')), false);
    assert.equal(isDriverError(new TypeError('x is not a function')), false);
    assert.equal(isDriverError(Object.assign(new Error('x'), { code: 'EPERM' })), false);
    assert.equal(isDriverError(Object.assign(new Error('x'), { code: 'ERR_INVALID_ARG_TYPE' })), false);
    assert.equal(isDriverError(null), false);
    assert.equal(isDriverError('text'), false);
  });

  it('isDriverError is true for pg DatabaseError-shaped and network errors', () => {
    assert.equal(isDriverError(pgError('23505')), true);
    assert.equal(isDriverError(Object.assign(new Error('x'), { code: 'ECONNREFUSED' })), true);
    assert.equal(isDriverError(new Error('Connection terminated unexpectedly')), true);
  });
});

describe('http-errors: generic client-facing mapping', () => {
  const kinds: Array<[ConstructorParameters<typeof DbError>[0], number, string]> = [
    ['unique', 409, 'conflict'],
    ['foreign_key', 409, 'conflict'],
    ['check', 422, 'unprocessable'],
    ['not_null', 422, 'unprocessable'],
    ['invalid_value', 422, 'unprocessable'],
    ['forbidden', 403, 'forbidden'],
    ['timeout', 503, 'retry_later'],
    ['serialization', 503, 'retry_later'],
    ['deadlock', 503, 'retry_later'],
    ['unavailable', 503, 'service_unavailable'],
    ['auth_failed', 503, 'service_unavailable'],
    ['unknown', 500, 'internal_error'],
  ];
  for (const [kind, status, code] of kinds) {
    it(`${kind} -> ${status} ${code}`, () => {
      const r = toHttpError(new DbError(kind, { sqlstate: '23505', constraint: 'users_phone_active_uq', driverMessage: 'secret driver text' }));
      assert.equal(r.status, status);
      assert.equal(r.code, code);
      assert.ok(!r.message.includes('users_phone_active_uq') && !r.message.includes('secret'));
    });
  }

  it('maps framework 4xx errors without echoing their text', () => {
    assert.deepEqual(toHttpError({ statusCode: 404, message: 'Route GET:/x not found' }), { status: 404, code: 'not_found', message: 'Not found' });
    assert.deepEqual(toHttpError({ statusCode: 413 }), { status: 413, code: 'payload_too_large', message: 'Payload too large' });
    assert.equal(toHttpError({ statusCode: 400, message: 'body must have required property secret' }).message, 'Bad request');
  });

  it('turns anything else into an opaque 500', () => {
    for (const e of [new Error('stack with /home/app/secret.ts'), 'text', null, { statusCode: 500, message: 'x' }]) {
      assert.deepEqual(toHttpError(e), { status: 500, code: 'internal_error', message: 'Internal server error' });
    }
  });
});

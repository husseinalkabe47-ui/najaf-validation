// Phase 11.5, Step 5.3: the public catalog HTTP layer, run WITHOUT Fastify (routes registered on a recording stand-in, handlers
// called with plain request objects, wired to the real catalog service over the in-memory fake). Plus static guards that pin the
// SQL to the two public views and the wiring in server.ts / index.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { CATALOG_RATE_LIMITS, registerCatalogRoutes, toCatalogHttp } from '../../src/catalog/routes.ts';
import { createCatalogService, CatalogError } from '../../src/catalog/service.ts';
import { buildCarDetail, buildCarList, buildShowroomDetail, buildShowroomList } from '../../src/catalog/repository.ts';
import { escapeLike } from '../../src/catalog/params.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { makeFakeCatalog } from '../helpers/fake-catalog.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const read = (rel: string) => readFileSync(join(ROOT, rel), 'utf8');
/** Source text with // comments removed, so that documentation cannot satisfy or break a code check. */
const code = (rel: string) =>
  read(rel)
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter: boolean, now?: () => number) {
  const f = makeFakeCatalog();
  f.addUser({ id: '1' });
  f.addShowroom({ id: '100', ownerId: '1', name: 'معرض' });
  f.addShowroom({ id: '101', ownerId: '1', status: 'pending' });
  f.addCar({ id: '200', showroomId: '100', ownerId: '1', brand: 'Toyota' });
  f.addCar({ id: '201', showroomId: '101', ownerId: '1', brand: 'Kia' });
  const catalog = createCatalogService({ repo: f.repo });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter(now ? { now } : {});
  registerCatalogRoutes({ get: add('GET'), post: add('POST'), put: add('PUT'), patch: add('PATCH'), delete: add('DELETE') } as never, { catalog, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  async function call(path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === 'GET' && r.path === path);
    if (!route) throw new Error(`no route GET ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  return { routes, call, f };
}

describe('catalog routes: registration', () => {
  it('registers exactly the four public GET routes and no write method', () => {
    const { routes } = setup(false);
    assert.deepEqual(
      routes.map((r) => `${r.method} ${r.path}`).sort(),
      ['GET /v1/public/cars', 'GET /v1/public/cars/:id', 'GET /v1/public/showrooms', 'GET /v1/public/showrooms/:id'],
    );
  });

  it('without a rate limiter no hook is installed; with one, list and detail have their own hooks', () => {
    const plain = setup(false).routes;
    assert.ok(plain.every((r) => (r.opts?.onRequest ?? []).length === 0));
    const limited = setup(true).routes;
    assert.ok(limited.every((r) => (r.opts?.onRequest ?? []).length === 1));
  });
});

describe('catalog routes: responses', () => {
  it('list responses are {items, nextBefore}; detail responses wrap the record', async () => {
    const { call } = setup(false);
    const list = await call('/v1/public/showrooms');
    assert.equal(list.status, 200);
    assert.deepEqual(Object.keys(list.body as object).sort(), ['items', 'nextBefore']);
    const one = await call('/v1/public/showrooms/:id', { params: { id: '100' } });
    assert.equal(one.status, 200);
    assert.equal((one.body as { showroom: { id: string } }).showroom.id, '100');
    const car = await call('/v1/public/cars/:id', { params: { id: '200' } });
    assert.equal((car.body as { car: { id: string } }).car.id, '200');
  });

  it('a hidden or unknown record is a 404 with the same body', async () => {
    const { call } = setup(false);
    const hidden = await call('/v1/public/cars/:id', { params: { id: '201' } });
    const missing = await call('/v1/public/cars/:id', { params: { id: '999999' } });
    const malformed = await call('/v1/public/cars/:id', { params: { id: 'abc' } });
    assert.equal(hidden.status, 404);
    assert.deepEqual(hidden.body, missing.body);
    assert.deepEqual(malformed.body, missing.body);
    assert.equal((hidden.body as { error: { code: string } }).error.code, 'not_found');
  });

  it('invalid query input is a 400 with field names and codes only', async () => {
    const { call } = setup(false);
    const bad = await call('/v1/public/cars', { query: { status: 'pending', brand: 'Toyota' } });
    assert.equal(bad.status, 400);
    const err = (bad.body as { error: { code: string; fields: unknown; requestId: string } }).error;
    assert.equal(err.code, 'validation_failed');
    assert.deepEqual(err.fields, [{ field: 'status', code: 'invalid_format' }]);
    assert.equal(err.requestId, 'req-abcdef01');
    assert.ok(!JSON.stringify(bad.body).includes('pending'), 'the submitted value is not echoed');
  });

  it('an Authorization header, valid or garbage, is ignored: the public read answers the same', async () => {
    const { call } = setup(false);
    const anon = await call('/v1/public/showrooms');
    const garbage = await call('/v1/public/showrooms', { headers: { authorization: 'Bearer not-a-token' } });
    const valid = await call('/v1/public/showrooms', { headers: { authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.e30.x' } });
    assert.equal(garbage.status, 200);
    assert.deepEqual(garbage.body, anon.body);
    assert.deepEqual(valid.body, anon.body);
  });

  it('no session is required: a request with no headers at all is served', async () => {
    const { call } = setup(false);
    assert.equal((await call('/v1/public/cars', { headers: {} })).status, 200);
  });
});

describe('catalog routes: rate limits (per client address, separate buckets for list and detail)', () => {
  it('the list bucket allows its budget, then answers 429 with retry-after', async () => {
    const { call } = setup(true);
    for (let i = 0; i < CATALOG_RATE_LIMITS.list.limit; i++) assert.equal((await call('/v1/public/showrooms')).status, 200);
    const denied = await call('/v1/public/showrooms');
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal((denied.body as { error: { code: string } }).error.code, 'rate_limited');
  });

  it('the detail bucket enforces its own budget on both detail routes', async () => {
    const { call } = setup(true);
    for (let i = 0; i < CATALOG_RATE_LIMITS.detail.limit; i++) assert.equal((await call('/v1/public/showrooms/:id', { params: { id: '100' } })).status, 200);
    assert.equal((await call('/v1/public/showrooms/:id', { params: { id: '100' } })).status, 429);
    assert.equal((await call('/v1/public/cars/:id', { params: { id: '200' } })).status, 429, 'cars detail shares the detail budget per address');
  });

  it('exhausting the list bucket does not block the detail bucket', async () => {
    const { call } = setup(true);
    for (let i = 0; i < CATALOG_RATE_LIMITS.list.limit + 1; i++) await call('/v1/public/cars');
    assert.equal((await call('/v1/public/cars')).status, 429);
    assert.equal((await call('/v1/public/cars/:id', { params: { id: '200' } })).status, 200);
  });

  it('the budget renews when the window passes', async () => {
    let t = 0;
    const { call } = setup(true, () => t);
    for (let i = 0; i < CATALOG_RATE_LIMITS.list.limit; i++) await call('/v1/public/showrooms');
    assert.equal((await call('/v1/public/showrooms')).status, 429);
    t += (CATALOG_RATE_LIMITS.list.windowSeconds + 1) * 1000;
    assert.equal((await call('/v1/public/showrooms')).status, 200);
  });
});

describe('catalog error mapping', () => {
  it('maps catalog validation to 400 and authorization not_found to 404; anything else is not ours', () => {
    assert.deepEqual(toCatalogHttp(new CatalogError([{ field: 'limit', code: 'invalid_format' }])), {
      status: 400,
      code: 'validation_failed',
      message: 'The submitted data is not valid',
      fields: [{ field: 'limit', code: 'invalid_format' }],
    });
    assert.equal(toCatalogHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toCatalogHttp(new Error('boom')), undefined);
  });
});

describe('catalog SQL builders: parameters only, public views only', () => {
  const everything = {
    page: { limit: 7, before: '500' },
    terms: ['toyota', 'camry'],
    source: 'member' as const,
    showroomId: '100',
    brand: 'Toyota',
    model: 'Camry',
    color: 'White',
    transmission: 'أوتوماتيك' as const,
    fuelType: 'بنزين' as const,
    status: 'active' as const,
    yearMin: 2010,
    yearMax: 2020,
    currency: 'USD' as const,
    priceMin: 1000,
    priceMax: 90000,
  };

  it('every filter value travels as a bound parameter, never inside the SQL text', () => {
    const s = buildCarList(everything);
    for (const v of ['Toyota', 'Camry', 'White', 'toyota', 'camry', 'member', 'USD', 'active', '2010', '90000']) {
      assert.ok(!s.text.includes(v), `${v} must not appear in the SQL text`);
    }
    assert.ok(s.values.includes('Toyota') && s.values.includes('USD') && s.values.includes(90000));
  });

  it('the SQL text reads only public_cars and public_showrooms', () => {
    const texts = [buildCarList(everything).text, buildCarDetail('1').text, buildShowroomList({ page: { limit: 5, before: null }, terms: ['x'] }).text, buildShowroomDetail('1').text];
    for (const t of texts) {
      const relations = [...t.matchAll(/\b(?:FROM|JOIN)\s+([a-z_]+)/gi)].map((m) => m[1]);
      assert.ok(relations.length === 1 && (relations[0] === 'public_cars' || relations[0] === 'public_showrooms'), `unexpected relations: ${relations.join(',')}`);
      assert.ok(!/\b(users|showrooms|cars|password_hash|owner_id)\b/.test(t), `base table or secret column in: ${t}`);
    }
  });

  it('pagination is keyset on id with a bound limit, and there is no OFFSET', () => {
    const s = buildCarList(everything);
    assert.match(s.text, /pc\.id < \$\d+::bigint/);
    assert.match(s.text, /ORDER BY pc\.id DESC LIMIT \$\d+/);
    assert.ok(!/OFFSET/i.test(s.text));
    assert.equal(s.values[s.values.length - 1], 7);
  });

  it('the showroom list also pages by the keyset cursor, bound as a parameter', () => {
    const s = buildShowroomList({ page: { limit: 5, before: '77' }, terms: [] });
    assert.match(s.text, /ps\.id < \$\d+::bigint/);
    assert.ok(s.values.includes('77'));
    assert.ok(!/OFFSET/i.test(s.text));
    assert.equal(s.values[s.values.length - 1], 5);
  });

  it('the detail lookup binds the id as a bigint parameter', () => {
    const s = buildCarDetail('42');
    assert.match(s.text, /FROM public_cars pc WHERE pc\.id = \$1::bigint$/);
    assert.deepEqual(s.values, ['42']);
  });

  it('LIKE metacharacters in the search are escaped and the escape character is declared', () => {
    assert.equal(escapeLike('50%_off\\'), '50\\%\\_off\\\\');
    const s = buildShowroomList({ page: { limit: 5, before: null }, terms: ['50%'] });
    assert.ok(s.values.includes('%50\\%%'));
    assert.match(s.text, /ESCAPE '\\'/);
  });
});

describe('catalog source guards', () => {
  it('the repository never writes and reads only the two public views', () => {
    const src = code('src/catalog/repository.ts');
    assert.ok(!/\b(INSERT|UPDATE|DELETE|ALTER|CREATE|TRUNCATE|GRANT)\b/i.test(src), 'no write statement in the catalog');
    assert.ok(!/SELECT\s+\*/i.test(src), 'no SELECT *');
    const relations = [...src.matchAll(/\b(?:FROM|JOIN)\s+([a-z_]+)/gi)].map((m) => m[1]);
    assert.ok(relations.length > 0 && relations.every((r) => r === 'public_showrooms' || r === 'public_cars'), relations.join(','));
    assert.ok(!/\b(owner_id|password_hash|reviewed_by|reviewed_at|rejection_reason|suspension_reason)\b/.test(src), 'no owner id, secret or reviewer column is selected');
  });

  it('the public DTO whitelist never carries an owner id, reviewer, reason, or search text', () => {
    const src = code('src/catalog/service.ts');
    for (const forbidden of ['ownerId', 'owner_id', 'reviewedBy', 'reviewed_by', 'searchText', 'search_text', 'password', 'reason', 'assetKey', 'asset']) {
      assert.ok(!new RegExp(`\\b${forbidden}\\b`).test(src), `${forbidden} must not appear in the public DTO code`);
    }
  });

  it('the catalog never authenticates: no actor, token or authorization header is read', () => {
    for (const rel of ['src/catalog/routes.ts', 'src/catalog/service.ts', 'src/catalog/params.ts', 'src/catalog/repository.ts']) {
      const src = code(rel);
      assert.ok(!/authenticate|toActor|bearerToken|authorization|requireActor|\bactor\b/i.test(src), `${rel} must not depend on authentication`);
    }
  });

  it('the catalog routes are wired only when supplied, and the process supplies the Postgres-backed service', () => {
    const server = code('src/server.ts');
    assert.match(server, /if \(deps\.catalog\) registerCatalogRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createCatalogService\(\{ repo: createPgCatalogRepository\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\bcatalog\b/);
  });

  it('no shared route guard is reused with keys it does not know (own typed hook)', () => {
    const src = code('src/catalog/routes.ts');
    assert.ok(!/as never/.test(src), 'no unchecked casts in the catalog routes');
    assert.ok(!/\bhandle\b/.test(src), 'no dead helper');
  });
});

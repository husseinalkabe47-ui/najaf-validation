// Phase 11.5, Step 5.6: a member's own favorites, through the real service and the real policy (src/authz), over an in-memory store
// that mirrors the SQL scoping, the public_cars view and the soft-delete trigger.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { FavoriteError, createFavoriteService } from '../../src/favorites/service.ts';
import { makeFakeFavoriteStore } from '../helpers/fake-favorites.ts';

const A: Actor = Object.freeze({ id: '1', role: 'member' });
const B: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ADMIN: Actor = Object.freeze({ id: '4', role: 'admin' });

function setup() {
  const f = makeFakeFavoriteStore();
  for (const a of [A, B, DEALER, ADMIN]) f.addUser(a.id);
  const svc = createFavoriteService({ store: f.store });
  const showroomCar = () => f.addCar();
  const memberCar = (fields = {}) => f.addCar({ sourceType: 'member', status: 'active', ownerId: B.id, ...fields });
  return { f, svc, showroomCar, memberCar };
}

const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isFavErr = (e: unknown) => e instanceof FavoriteError && e.code === 'validation_failed';
type Fields = Array<{ field: string; code: string }>;
async function fieldsOf(p: Promise<unknown>): Promise<Fields> {
  try {
    await p;
  } catch (e) {
    if (e instanceof FavoriteError) return e.fields ?? [];
    throw e;
  }
  throw new Error('expected a validation error');
}
const outcome = (p: Promise<unknown>) => p.then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));

describe('favorites: add', () => {
  it('adds a public car: the user is the actor, the answer is a whitelist, one audit row with numbers only', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    const r = await svc.add(A, { carId: car.id }, { requestId: 'req-1' });
    assert.equal(r.created, true);
    assert.deepEqual(Object.keys(r.favorite).sort(), ['carId', 'createdAt']);
    assert.equal(r.favorite.carId, car.id);
    assert.deepEqual(f.favorites().map((x) => [x.userId, x.carId]), [[A.id, car.id]]);
    assert.deepEqual(f.audits(), [{ action: 'favorite.add', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: car.id, afterData: { carId: Number(car.id) }, requestId: 'req-1' }]);
  });

  it('an active member car of an active owner can be favorited, by a member, a dealer and an administrator, each for themselves', async () => {
    const { f, svc, memberCar } = setup();
    const car = memberCar();
    for (const who of [A, DEALER, ADMIN]) assert.equal((await svc.add(who, { carId: car.id })).created, true);
    assert.deepEqual(f.favorites().map((x) => x.userId).sort(), ['1', '3', '4']);
    assert.equal(f.audits().find((a) => a.actorUserId === '3')!.actorRole, 'dealer');
  });

  it('a car that is not public is the same 404 as an unknown or malformed id, and nothing is stored or audited', async () => {
    const { f, svc, showroomCar, memberCar } = setup();
    const hidden = [
      memberCar({ status: 'pending' }),
      memberCar({ status: 'suspended' }),
      memberCar({ status: 'rejected' }),
      memberCar({ deleted: true }),
      f.addCar({ showroomPublic: false }),
      f.addCar({ deleted: true }),
    ];
    const suspendedOwner = memberCar({ ownerId: '5' });
    f.addUser('5', 'suspended');
    hidden.push(suspendedOwner);
    showroomCar();
    const reference = await outcome(svc.add(A, { carId: '999999' }));
    assert.ok(reference.startsWith('not_found|'));
    for (const c of hidden) assert.equal(await outcome(svc.add(A, { carId: c.id })), reference, JSON.stringify(c));
    assert.deepEqual(f.favorites(), []);
    assert.deepEqual(f.audits(), []);
  });

  it('input is a strict whitelist: unknown fields (a user id included) and bad ids are 400 with field names only', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    assert.deepEqual(await fieldsOf(svc.add(A, { carId: car.id, userId: '2' })), [{ field: 'userId', code: 'unknown_field' }]);
    assert.deepEqual(await fieldsOf(svc.add(A, { carId: car.id, user_id: '2', owner_id: '2' })), [{ field: 'user_id', code: 'unknown_field' }, { field: 'owner_id', code: 'unknown_field' }]);
    assert.deepEqual(await fieldsOf(svc.add(A, {})), [{ field: 'carId', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.add(A, { carId: null })), [{ field: 'carId', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.add(A, { carId: 7000 })), [{ field: 'carId', code: 'invalid_type' }]);
    for (const bad of ['abc', '0', '-1', '01', '1.5', ' 1', '9223372036854775808', '1;DROP TABLE']) assert.deepEqual(await fieldsOf(svc.add(A, { carId: bad })), [{ field: 'carId', code: 'invalid_format' }], bad);
    for (const body of [null, undefined, 'x', 5, [], [{ carId: car.id }]]) assert.deepEqual(await fieldsOf(svc.add(A, body)), [{ field: 'body', code: 'invalid_type' }]);
    const secret = 'SECRET-VALUE-123';
    const echoed = JSON.stringify(await fieldsOf(svc.add(A, { carId: secret })));
    assert.ok(!echoed.includes(secret));
    assert.deepEqual(f.calls, [], 'invalid input never reaches the store');
  });

  it('an account that may not act is 403; an account that is no longer active is 404', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    await assert.rejects(svc.add(null, { carId: car.id }), isAuthz('forbidden'));
    f.setUser(A.id, 'suspended');
    await assert.rejects(svc.add(A, { carId: car.id }), isAuthz('not_found'));
    f.setUser(A.id, 'active', true);
    await assert.rejects(svc.add(A, { carId: car.id }), isAuthz('not_found'));
    assert.deepEqual(f.favorites(), []);
  });

  it('an audit failure rolls the favorite back', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    f.faults.failNextAudit = true;
    await assert.rejects(svc.add(A, { carId: car.id }), /audit insert failed/);
    assert.deepEqual(f.favorites(), []);
    assert.equal((await svc.add(A, { carId: car.id })).created, true);
  });

  it('a car hidden between the lock and the insert is 404 and nothing is stored', async () => {
    const { f, svc, memberCar } = setup();
    const car = memberCar();
    f.faults.afterLockCar = () => f.setCar(car.id, { status: 'suspended' });
    await assert.rejects(svc.add(A, { carId: car.id }), isAuthz('not_found'));
    assert.deepEqual(f.favorites(), []);
    assert.deepEqual(f.audits(), []);
  });
});

describe('favorites: duplicates and concurrency', () => {
  it('adding twice is not an error: one row, created=false the second time, one audit row', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    const first = await svc.add(A, { carId: car.id });
    const second = await svc.add(A, { carId: car.id });
    assert.equal(first.created, true);
    assert.equal(second.created, false);
    assert.deepEqual(second.favorite, first.favorite);
    assert.equal(f.favoritesOf(A.id).length, 1);
    assert.equal(f.audits().length, 1);
  });

  it('the same car favorited by two users gives each their own row', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    await svc.add(A, { carId: car.id });
    await svc.add(B, { carId: car.id });
    assert.equal(f.favorites().length, 2);
  });

  it('twelve concurrent adds of the same car create exactly one favorite and report exactly one creation', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    const results = await Promise.all(Array.from({ length: 12 }, () => svc.add(A, { carId: car.id })));
    assert.equal(results.filter((r) => r.created).length, 1);
    assert.equal(f.favoritesOf(A.id).length, 1);
    assert.equal(f.audits().length, 1);
  });

  it('concurrent adds of different cars and concurrent add/remove of one car leave a consistent list', async () => {
    const { f, svc, showroomCar } = setup();
    const cars = Array.from({ length: 6 }, showroomCar);
    await Promise.all(cars.map((c) => svc.add(A, { carId: c.id })));
    assert.equal(f.favoritesOf(A.id).length, 6);
    const one = cars[0]!;
    await Promise.all([svc.remove(A, one.id), svc.add(A, { carId: one.id }), svc.remove(A, one.id), svc.add(A, { carId: one.id })]);
    const rows = f.favoritesOf(A.id).filter((x) => x.carId === one.id);
    assert.ok(rows.length <= 1);
    assert.equal(f.favoritesOf(A.id).length, 5 + rows.length);
  });

  it('a car soft-deleted while being favorited never leaves a favorite behind (the lock orders them)', async () => {
    const { f, svc, memberCar } = setup();
    const car = memberCar();
    await svc.add(A, { carId: car.id });
    f.softDelete(car.id);
    assert.deepEqual(f.favorites(), []);
    await assert.rejects(svc.add(A, { carId: car.id }), isAuthz('not_found'));
    assert.deepEqual(f.favorites(), []);
  });
});

describe('favorites: list', () => {
  it('returns only the actor\'s favorites, newest first, as public cars with the time they were favorited', async () => {
    const { f, svc, showroomCar } = setup();
    const [c1, c2, c3] = [showroomCar(), showroomCar(), showroomCar()];
    await svc.add(A, { carId: c1.id });
    await svc.add(B, { carId: c3.id });
    await svc.add(A, { carId: c2.id });
    const page = await svc.list(A, {});
    assert.deepEqual(page.items.map((i) => i.car.id), [c2.id, c1.id]);
    assert.deepEqual(Object.keys(page.items[0]!).sort(), ['car', 'favoritedAt']);
    assert.equal(page.nextBefore, null);
    assert.deepEqual((await svc.list(B, {})).items.map((i) => i.car.id), [c3.id]);
    assert.equal(f.favorites().length, 3);
  });

  it('the car in the list is the public DTO: no owner id, reviewer data, reasons or search text', async () => {
    const { svc, showroomCar } = setup();
    await svc.add(A, { carId: showroomCar().id });
    const car = (await svc.list(A, {})).items[0]!.car as unknown as Record<string, unknown>;
    for (const k of ['ownerId', 'owner_id', 'userId', 'reviewedBy', 'rejectionReason', 'suspensionReason', 'searchText', 'search_text']) assert.ok(!(k in car), k);
  });

  it('a car that is no longer public disappears from the list: deleted, suspended, owner suspended, showroom hidden', async () => {
    const { f, svc, showroomCar, memberCar } = setup();
    const keep = showroomCar();
    const deleted = memberCar();
    const suspended = memberCar();
    const ownerGone = memberCar({ ownerId: '5' });
    f.addUser('5');
    const showroomHidden = showroomCar();
    for (const c of [keep, deleted, suspended, ownerGone, showroomHidden]) await svc.add(A, { carId: c.id });
    f.softDelete(deleted.id);
    f.setCar(suspended.id, { status: 'suspended' });
    f.setUser('5', 'suspended');
    f.setCar(showroomHidden.id, { showroomPublic: false });
    assert.deepEqual((await svc.list(A, {})).items.map((i) => i.car.id), [keep.id]);
    // The favorite row of a merely hidden car is kept, and the car is listed again if it becomes public again.
    f.setCar(suspended.id, { status: 'active' });
    assert.deepEqual((await svc.list(A, {})).items.map((i) => i.car.id), [suspended.id, keep.id]);
  });

  it('pages by a keyset cursor: no gaps, no repeats, newest first; the last page has no cursor', async () => {
    const { svc, showroomCar } = setup();
    const cars = Array.from({ length: 5 }, showroomCar);
    for (const c of cars) await svc.add(A, { carId: c.id });
    const seen: string[] = [];
    let before: string | undefined;
    let pages = 0;
    for (let guard = 0; guard < 10; guard++) {
      const page = await svc.list(A, before === undefined ? { limit: '2' } : { limit: '2', before });
      seen.push(...page.items.map((i) => i.car.id));
      pages++;
      if (page.nextBefore === null) break;
      before = page.nextBefore;
    }
    assert.deepEqual(seen, [...cars].reverse().map((c) => c.id));
    assert.equal(pages, 3);
  });

  it('a favorite added or removed between two pages does not shift the next page', async () => {
    const { svc, showroomCar } = setup();
    const cars = Array.from({ length: 4 }, showroomCar);
    for (const c of cars) await svc.add(A, { carId: c.id });
    const p1 = await svc.list(A, { limit: '2' });
    await svc.add(A, { carId: showroomCar().id });
    await svc.remove(A, cars[3]!.id);
    const p2 = await svc.list(A, { limit: '2', before: p1.nextBefore! });
    assert.deepEqual(p2.items.map((i) => i.car.id), [cars[1]!.id, cars[0]!.id]);
  });

  it('a cursor carries no authority: another user\'s cursor only ever shows the caller\'s own favorites', async () => {
    const { svc, showroomCar } = setup();
    const [c1, c2, c3] = [showroomCar(), showroomCar(), showroomCar()];
    await svc.add(B, { carId: c1.id });
    for (const c of [c1, c2, c3]) await svc.add(A, { carId: c.id });
    const cursorOfA = (await svc.list(A, { limit: '1' })).nextBefore!;
    assert.deepEqual((await svc.list(B, { before: cursorOfA })).items.map((i) => i.car.id), [c1.id]);
  });

  it('limit and before are validated; unknown query fields are 400; the default and the maximum are the catalog\'s', async () => {
    const { f, svc } = setup();
    assert.deepEqual(await fieldsOf(svc.list(A, { limit: '0' })), [{ field: 'limit', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, { limit: '51' })), [{ field: 'limit', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, { limit: '5.5' })), [{ field: 'limit', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, { limit: 5 })), [{ field: 'limit', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, { before: 'abc' })), [{ field: 'before', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, { before: ['1'] })), [{ field: 'before', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, { userId: '2' })), [{ field: 'userId', code: 'unknown_field' }]);
    assert.deepEqual(await fieldsOf(svc.list(A, 'x')), [{ field: 'query', code: 'invalid_type' }]);
    assert.deepEqual(f.calls, []);
    await svc.list(A, { limit: '50' });
    await svc.list(A, undefined);
  });

  it('an account that may not act gets 403', async () => {
    const { svc } = setup();
    await assert.rejects(svc.list(null, {}), isAuthz('forbidden'));
  });
});

describe('favorites: remove', () => {
  it('removes only the actor\'s own favorite; another user\'s favorite of the same car is untouched', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    await svc.add(A, { carId: car.id });
    await svc.add(B, { carId: car.id });
    await svc.remove(A, car.id, { requestId: 'req-2' });
    assert.deepEqual(f.favorites().map((x) => x.userId), [B.id]);
    assert.deepEqual(f.audits().at(-1), { action: 'favorite.remove', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: car.id, afterData: { carId: Number(car.id) }, requestId: 'req-2' });
  });

  it('is idempotent: removing again, or a car that was never a favorite, succeeds and writes no audit row', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    const other = showroomCar();
    await svc.add(A, { carId: car.id });
    await svc.remove(A, car.id);
    const audits = f.audits().length;
    await svc.remove(A, car.id);
    await svc.remove(A, other.id);
    await svc.remove(A, '999999');
    assert.equal(f.audits().length, audits);
    assert.deepEqual(f.favorites(), []);
  });

  it('a stranger cannot remove someone else\'s favorite: it is the same success as for a car that was never theirs, and the row stays', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    await svc.add(A, { carId: car.id });
    await svc.remove(B, car.id);
    await svc.remove(ADMIN, car.id);
    assert.equal(f.favoritesOf(A.id).length, 1);
    assert.equal(f.audits().length, 1);
  });

  it('works on a car that is no longer public, so the user can always clean up their list', async () => {
    const { f, svc, memberCar } = setup();
    const car = memberCar();
    await svc.add(A, { carId: car.id });
    f.setCar(car.id, { status: 'suspended' });
    await svc.remove(A, car.id);
    assert.deepEqual(f.favorites(), []);
  });

  it('a malformed id is 404 and never reaches the store; no actor is 404', async () => {
    const { f, svc } = setup();
    for (const id of ['abc', '0', '-1', '1.5', '01', ' 1', '9223372036854775808', undefined, null, 1, {}, ['1']]) await assert.rejects(svc.remove(A, id), isAuthz('not_found'), JSON.stringify(id));
    await assert.rejects(svc.remove(null, '7000'), isAuthz('not_found'));
    assert.deepEqual(f.calls, []);
  });

  it('an account that is no longer active is 404; an audit failure keeps the favorite', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    await svc.add(A, { carId: car.id });
    f.faults.failNextAudit = true;
    await assert.rejects(svc.remove(A, car.id), /audit insert failed/);
    assert.equal(f.favoritesOf(A.id).length, 1);
    f.setUser(A.id, 'suspended');
    await assert.rejects(svc.remove(A, car.id), isAuthz('not_found'));
    assert.equal(f.favoritesOf(A.id).length, 1);
  });

  it('concurrent removes of one favorite succeed and audit exactly once', async () => {
    const { f, svc, showroomCar } = setup();
    const car = showroomCar();
    await svc.add(A, { carId: car.id });
    await Promise.all(Array.from({ length: 6 }, () => svc.remove(A, car.id)));
    assert.deepEqual(f.favorites(), []);
    assert.equal(f.audits().filter((a) => a.action === 'favorite.remove').length, 1);
  });
});

describe('favorites: error type', () => {
  it('validation errors are FavoriteError', async () => {
    const { svc } = setup();
    await assert.rejects(svc.add(A, {}), isFavErr);
  });
});

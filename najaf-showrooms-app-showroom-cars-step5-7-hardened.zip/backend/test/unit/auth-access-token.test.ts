import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac, randomBytes } from 'node:crypto';
import { signAccessToken, verifyAccessToken } from '../../src/auth/access-token.ts';
import { ACCESS_TOKEN_CLOCK_SKEW_SECONDS, ACCESS_TOKEN_MAX_LENGTH, ACCESS_TOKEN_TTL_SECONDS } from '../../src/auth/policy.ts';

const SECRET = 'access-token-test-secret-0123456789abcdefXYZ';
const SID = '11111111-2222-3333-4444-555555555555';
const NOW = Date.UTC(2026, 5, 1, 12, 0, 0);
const b64 = (v: unknown) => Buffer.from(typeof v === 'string' ? v : JSON.stringify(v)).toString('base64url');
const HEADER = b64({ alg: 'HS256', typ: 'JWT' });

// Builds a token with ARBITRARY claims, correctly signed with `secret`: to test what the verifier rejects beyond the signature.
function forge(claims: unknown, secret = SECRET, header: unknown = { alg: 'HS256', typ: 'JWT' }): string {
  const h = typeof header === 'string' ? header : b64(header);
  const p = typeof claims === 'string' ? claims : b64(claims);
  return `${h}.${p}.${createHmac('sha256', secret).update(`${h}.${p}`).digest().toString('base64url')}`;
}
const iat = Math.floor(NOW / 1000);
const good = { sub: '7', sid: SID, iat, exp: iat + ACCESS_TOKEN_TTL_SECONDS };

describe('access token: signing', () => {
  it('produces header.payload.signature (HS256) with exactly sub, sid, iat, exp and a 15-minute life', () => {
    const { token, expiresAt } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW);
    const [h, p, sig] = token.split('.') as [string, string, string];
    assert.deepEqual(JSON.parse(Buffer.from(h, 'base64url').toString()), { alg: 'HS256', typ: 'JWT' });
    assert.deepEqual(JSON.parse(Buffer.from(p, 'base64url').toString()), { sub: '7', sid: SID, iat, exp: iat + 900 });
    assert.equal(sig, createHmac('sha256', SECRET).update(`${h}.${p}`).digest().toString('base64url'));
    assert.equal(expiresAt.getTime(), (iat + 900) * 1000);
    assert.equal(ACCESS_TOKEN_TTL_SECONDS, 900);
  });

  it('is URL-safe, and carries NO role, status, name, phone or email', () => {
    const { token } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW);
    assert.match(token, /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/);
    const payload = Buffer.from(token.split('.')[1] as string, 'base64url').toString();
    for (const word of ['role', 'status', 'name', 'phone', 'email', 'password', 'admin']) assert.ok(!payload.includes(word), word);
    assert.ok(token.length < ACCESS_TOKEN_MAX_LENGTH);
  });

  it('is deterministic for the same inputs and different for a different secret or time', () => {
    const a = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW).token;
    assert.equal(a, signAccessToken({ sub: '7', sid: SID }, SECRET, NOW).token);
    assert.notEqual(a, signAccessToken({ sub: '7', sid: SID }, SECRET + 'x', NOW).token);
    assert.notEqual(a, signAccessToken({ sub: '7', sid: SID }, SECRET, NOW + 1000).token);
  });
});

describe('access token: verification of valid tokens', () => {
  it('returns exactly the claims that were signed', () => {
    const { token } = signAccessToken({ sub: '123456789012', sid: SID }, SECRET, NOW);
    assert.deepEqual(verifyAccessToken(token, SECRET, NOW), { sub: '123456789012', sid: SID });
  });

  it('is valid up to the last second and expired at exactly 15 minutes', () => {
    const { token } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW);
    assert.ok(verifyAccessToken(token, SECRET, NOW + 1000));
    assert.ok(verifyAccessToken(token, SECRET, NOW + (ACCESS_TOKEN_TTL_SECONDS - 1) * 1000));
    assert.equal(verifyAccessToken(token, SECRET, NOW + ACCESS_TOKEN_TTL_SECONDS * 1000), null);
    assert.equal(verifyAccessToken(token, SECRET, NOW + (ACCESS_TOKEN_TTL_SECONDS + 3600) * 1000), null);
  });

  it('tolerates a small clock skew for tokens issued "in the future", but not a large one', () => {
    const { token } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW + ACCESS_TOKEN_CLOCK_SKEW_SECONDS * 1000);
    assert.ok(verifyAccessToken(token, SECRET, NOW));
    const far = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW + (ACCESS_TOKEN_CLOCK_SKEW_SECONDS + 5) * 1000).token;
    assert.equal(verifyAccessToken(far, SECRET, NOW), null);
  });
});

describe('access token: everything else is rejected (fail closed)', () => {
  it('wrong secret, tampered payload, tampered or truncated signature', () => {
    const { token } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW);
    const [h, p, sig] = token.split('.') as [string, string, string];
    assert.equal(verifyAccessToken(token, SECRET + 'x', NOW), null);
    assert.equal(verifyAccessToken(`${h}.${b64({ ...good, sub: '8' })}.${sig}`, SECRET, NOW), null, 'payload changed, signature kept');
    assert.equal(verifyAccessToken(`${h}.${p}.${sig.slice(0, -1)}`, SECRET, NOW), null);
    assert.equal(verifyAccessToken(`${h}.${p}.${sig}A`, SECRET, NOW), null);
    assert.equal(verifyAccessToken(`${h}.${p}.`, SECRET, NOW), null);
    assert.equal(verifyAccessToken(`${h}.${p}`, SECRET, NOW), null);
  });

  it('a signature with non-canonical base64url encoding is rejected', () => {
    const { token } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW);
    const [h, p, sig] = token.split('.') as [string, string, string];
    const last = sig.at(-1) as string;
    // flip an unused trailing bit of the last character: the same bytes decode, but the string is not canonical
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    const altered = sig.slice(0, -1) + alphabet[(alphabet.indexOf(last) ^ 1) % 64];
    assert.equal(verifyAccessToken(`${h}.${p}.${altered}`, SECRET, NOW), null);
  });

  it('any header other than exactly {"alg":"HS256","typ":"JWT"}: alg none, other algorithms, extra or reordered fields', () => {
    for (const header of [{ alg: 'none', typ: 'JWT' }, { alg: 'HS384', typ: 'JWT' }, { alg: 'HS512', typ: 'JWT' }, { alg: 'RS256', typ: 'JWT' }, { alg: 'hs256', typ: 'JWT' }, { alg: 'HS256' }, { alg: 'HS256', typ: 'jwt' }, { typ: 'JWT', alg: 'HS256' }, { alg: 'HS256', typ: 'JWT', kid: '1' }, { alg: 'HS256', typ: 'JWT', jku: 'http://evil' }]) {
      assert.equal(verifyAccessToken(forge(good, SECRET, header), SECRET, NOW), null, JSON.stringify(header));
    }
    assert.equal(verifyAccessToken(`${b64({ alg: 'none', typ: 'JWT' })}.${b64(good)}.`, SECRET, NOW), null, 'alg none with an empty signature');
  });

  it('claims: exactly sub, sid, iat, exp (a missing or extra claim is rejected)', () => {
    assert.ok(verifyAccessToken(forge(good), SECRET, NOW), 'control: the forged helper itself produces a valid token');
    assert.ok(verifyAccessToken(forge({ ...good, sid: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee' }), SECRET, NOW), 'control: a lowercase hex uuid is valid');
    for (const claims of [{ ...good, role: 'admin' }, { ...good, status: 'active' }, { ...good, aud: 'x' }, { sub: '7', sid: SID, iat, exp: good.exp, jti: 'a' }, { sid: SID, iat, exp: good.exp }, { sub: '7', iat, exp: good.exp }, { sub: '7', sid: SID, exp: good.exp }, { sub: '7', sid: SID, iat }, {}]) {
      assert.equal(verifyAccessToken(forge(claims), SECRET, NOW), null, JSON.stringify(claims));
    }
  });

  it('claim values: sub is a positive decimal id, sid a lowercase uuid, iat/exp safe integers', () => {
    const bad: Array<[string, Record<string, unknown>]> = [
      ['sub numeric type', { ...good, sub: 7 }],
      ['sub leading zero', { ...good, sub: '07' }],
      ['sub zero', { ...good, sub: '0' }],
      ['sub negative', { ...good, sub: '-7' }],
      ['sub non-digit', { ...good, sub: '7a' }],
      ['sub injection', { ...good, sub: "7' OR '1'='1" }],
      ['sub too long', { ...good, sub: '1'.repeat(20) }],
      ['sub empty', { ...good, sub: '' }],
      ['sid not a uuid', { ...good, sid: 'not-a-uuid' }],
      ['sid uppercase hex', { ...good, sid: 'AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE' }],
      ['sid with injection', { ...good, sid: `${SID}'; DROP TABLE sessions;--` }],
      ['sid numeric', { ...good, sid: 5 }],
      ['iat string', { ...good, iat: String(iat) }],
      ['exp string', { ...good, exp: String(good.exp) }],
      ['iat fractional', { ...good, iat: iat + 0.5 }],
      ['exp null', { ...good, exp: null }],
      ['exp not a safe integer', { ...good, exp: 1e30 }],
    ];
    for (const [why, claims] of bad) assert.equal(verifyAccessToken(forge(claims), SECRET, NOW), null, why);
  });

  it('a lifetime longer than the policy (even with a valid signature) or a non-positive lifetime is rejected', () => {
    assert.equal(verifyAccessToken(forge({ ...good, exp: iat + ACCESS_TOKEN_TTL_SECONDS + 1 }), SECRET, NOW), null);
    assert.equal(verifyAccessToken(forge({ ...good, exp: iat + 86_400 }), SECRET, NOW), null);
    assert.equal(verifyAccessToken(forge({ ...good, exp: iat }), SECRET, NOW), null);
    assert.equal(verifyAccessToken(forge({ ...good, exp: iat - 5 }), SECRET, NOW), null);
    assert.ok(verifyAccessToken(forge({ ...good, exp: iat + ACCESS_TOKEN_TTL_SECONDS }), SECRET, NOW), 'exactly the policy lifetime is fine');
  });

  it('a payload that is not a JSON object', () => {
    for (const payload of ['not json', 'null', '[]', '"string"', '7', 'true', '{"sub":']) {
      assert.equal(verifyAccessToken(forge(b64(payload)), SECRET, NOW), null, payload);
    }
  });

  it('wrong types, empty parts, wrong shapes and oversized input', () => {
    for (const token of [undefined, null, 5, {}, [], '', '.', '..', '...', 'a.b', 'a.b.c.d', 'a..c', '.b.c', 'x'.repeat(ACCESS_TOKEN_MAX_LENGTH + 1), `${HEADER}.${b64(good)}.${'A'.repeat(43)}`, 'Bearer ' + HEADER, ' ' + signAccessToken({ sub: '7', sid: SID }, SECRET, NOW).token, signAccessToken({ sub: '7', sid: SID }, SECRET, NOW).token + '\n', 'nsj_' + 'A'.repeat(43)]) {
      assert.equal(verifyAccessToken(token, SECRET, NOW), null, String(token).slice(0, 50));
    }
  });

  it('never throws, whatever it is given (fuzz)', () => {
    const { token } = signAccessToken({ sub: '7', sid: SID }, SECRET, NOW);
    for (let i = 0; i < 400; i++) {
      const junk = [randomBytes(1 + (i % 60)).toString('base64url'), randomBytes(20).toString('latin1'), `${randomBytes(8).toString('base64url')}.${randomBytes(30).toString('base64url')}.${randomBytes(32).toString('base64url')}`, token.slice(0, i % token.length), token.replace(/./, String.fromCharCode(33 + (i % 90)))];
      for (const j of junk) assert.doesNotThrow(() => verifyAccessToken(j, SECRET, NOW));
    }
  });
});

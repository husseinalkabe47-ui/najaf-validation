import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { OTP } from '../../src/auth/policy.ts';
import { createPgOtpRepository, createPgSessionsRepository, createPgUsersRepository } from '../../src/auth/repository.ts';
import type { Tx } from '../../src/db.ts';

interface Call {
  text: string;
  values: readonly unknown[];
}
type Reply = { rows: unknown[]; rowCount: number };
function script(respond: (text: string, values: readonly unknown[]) => Reply = () => ({ rows: [], rowCount: 0 })) {
  const calls: Call[] = [];
  const tx: Tx = {
    query: async <R>(text: string, values: readonly unknown[] = []) => {
      calls.push({ text, values });
      return respond(text, values) as never as { rows: R[]; rowCount: number };
    },
  };
  return { tx, calls };
}
const HASH = Buffer.alloc(32, 9);
const issueArgs = { userId: '7', phoneE164: '+9647701234567', purpose: 'phone_verify' as const, codeHash: HASH };

function issueScript(counts: { last_hour: number; last_day: number; cooldown_left: number }) {
  return script((text) => {
    if (text.includes('count(*)')) return { rows: [counts], rowCount: 1 };
    if (text.includes('INSERT INTO verification_codes')) return { rows: [{ id: 'code-1', expires_at: new Date('2026-01-01T00:10:00Z') }], rowCount: 1 };
    return { rows: [], rowCount: 1 };
  });
}

describe('otp repository: issue', () => {
  it('locks, counts recent codes, supersedes the active one, then stores ONLY the 32-byte hash, in that order', async () => {
    const { tx, calls } = issueScript({ last_hour: 0, last_day: 0, cooldown_left: -30 });
    const out = await createPgOtpRepository(tx).issue(issueArgs);
    assert.deepEqual(out, { kind: 'issued', codeId: 'code-1', expiresAt: new Date('2026-01-01T00:10:00Z') });
    assert.equal(calls.length, 4);
    const [, count, supersede, insert] = calls as [Call, Call, Call, Call];
    assert.deepEqual(count.values, ['7', 'phone_verify', OTP.cooldownSeconds]);
    assert.match(supersede.text, /SET invalidated_at = now\(\)\s+WHERE user_id = \$1 AND purpose = \$2 AND consumed_at IS NULL AND invalidated_at IS NULL/);
    assert.deepEqual(supersede.values, ['7', 'phone_verify']);
    assert.match(insert.text, /INSERT INTO verification_codes \(purpose, user_id, target_phone, code_hash, max_attempts, expires_at\)\s+VALUES \(\$1, \$2, \$3, \$4, \$5, now\(\) \+ make_interval\(secs => \$6\)\)/);
    assert.deepEqual(insert.values, ['phone_verify', '7', '+9647701234567', HASH, OTP.maxAttempts, OTP.ttlSeconds]);
    assert.ok(Buffer.isBuffer(insert.values[3]) && (insert.values[3] as Buffer).length === 32);
  });

  it('serializes issuance per (user, purpose) with a TRANSACTION-scoped advisory lock taken before anything is counted', async () => {
    const { tx, calls } = issueScript({ last_hour: 0, last_day: 0, cooldown_left: 0 });
    await createPgOtpRepository(tx).issue(issueArgs);
    assert.match(calls[0]!.text, /^SELECT pg_advisory_xact_lock\(hashtextextended\(\$1, 0\)\)$/);
    assert.deepEqual(calls[0]!.values, ['najaf.otp:phone_verify:7']);
    assert.ok(!/pg_advisory_lock\b/.test(calls[0]!.text), 'never a session-level lock, which would outlive the transaction');
    assert.ok(calls.slice(1).every((c) => !c.text.includes('advisory')), 'the lock is taken once, first');
  });

  it('the lock key separates users and purposes (so unrelated users never wait for each other)', async () => {
    const keys = new Set<unknown>();
    for (const [userId, purpose] of [['7', 'phone_verify'], ['8', 'phone_verify'], ['7', 'password_reset'], ['78', 'phone_verify'], ['7', 'phone_verify']] as const) {
      const { tx, calls } = issueScript({ last_hour: 0, last_day: 0, cooldown_left: 0 });
      await createPgOtpRepository(tx).issue({ ...issueArgs, userId, purpose });
      keys.add((calls[0]!.values as unknown[])[0]);
    }
    assert.equal(keys.size, 4);
  });

  it('the purpose is always a bound parameter, so the database vocabulary CHECK decides what is allowed', async () => {
    for (const purpose of ['phone_verify', 'password_reset'] as const) {
      const { tx, calls } = issueScript({ last_hour: 0, last_day: 0, cooldown_left: 0 });
      await createPgOtpRepository(tx).issue({ ...issueArgs, purpose });
      assert.equal(calls[3]?.values[0], purpose);
      assert.ok(!calls.some((c) => c.text.includes(`'${purpose}'`)));
    }
  });

  it('counts EVERY earlier code (superseded and consumed ones too), so resending cannot dodge the limits', async () => {
    const { tx, calls } = issueScript({ last_hour: 0, last_day: 0, cooldown_left: 0 });
    await createPgOtpRepository(tx).issue(issueArgs);
    assert.ok(!calls[1]!.text.includes('consumed_at') && !calls[1]!.text.includes('invalidated_at'));
    assert.match(calls[1]!.text, /WHERE user_id = \$1 AND purpose = \$2/);
  });

  it('a cooldown in progress throttles first, reporting the seconds left, and writes nothing', async () => {
    const { tx, calls } = issueScript({ last_hour: 5, last_day: 20, cooldown_left: 42 });
    assert.deepEqual(await createPgOtpRepository(tx).issue(issueArgs), { kind: 'throttled', retryAfterSeconds: 42 });
    assert.equal(calls.length, 2, 'the lock and the count; no write');
    assert.ok(!calls.some((c) => /INSERT|UPDATE/.test(c.text)));
  });

  it('the hourly and daily limits throttle at exactly 3 and 10, never earlier, writing nothing', async () => {
    const run = (last_hour: number, last_day: number) => createPgOtpRepository(issueScript({ last_hour, last_day, cooldown_left: 0 }).tx).issue(issueArgs);
    assert.equal((await run(2, 2)).kind, 'issued');
    assert.deepEqual(await run(3, 3), { kind: 'throttled', retryAfterSeconds: 3600 });
    assert.equal((await run(0, 9)).kind, 'issued');
    assert.deepEqual(await run(0, 10), { kind: 'throttled', retryAfterSeconds: 86_400 });
    const { tx, calls } = issueScript({ last_hour: 3, last_day: 3, cooldown_left: 0 });
    await createPgOtpRepository(tx).issue(issueArgs);
    assert.equal(calls.length, 2);
    assert.ok(!calls.some((c) => /INSERT|UPDATE/.test(c.text)));
  });

  it('a cooldown of zero or less (long ago) does not throttle', async () => {
    for (const cooldown_left of [0, -1, -86_400]) assert.equal((await createPgOtpRepository(issueScript({ last_hour: 0, last_day: 0, cooldown_left }).tx).issue(issueArgs)).kind, 'issued');
  });
});

describe('otp repository: verify', () => {
  const verifyArgs = { userId: '7', phoneE164: '+9647701234567', purpose: 'password_reset' as const, expectedHash: HASH };
  const row = (over: Record<string, unknown> = {}) => ({ id: 'code-1', code_hash: Buffer.from(HASH), attempts: 0, max_attempts: 5, expired: false, ...over });
  const withRow = (r: Record<string, unknown> | null) => script((text) => (text.includes('FOR UPDATE') ? { rows: r ? [r] : [], rowCount: r ? 1 : 0 } : { rows: [], rowCount: 1 }));

  it('finds the ONE active code by purpose, user AND phone, under a row lock', async () => {
    const { tx, calls } = withRow(row());
    await createPgOtpRepository(tx).verify(verifyArgs);
    assert.match(calls[0]!.text, /WHERE user_id = \$1 AND purpose = \$2 AND target_phone = \$3\s+AND consumed_at IS NULL AND invalidated_at IS NULL\s+FOR UPDATE/);
    assert.deepEqual(calls[0]!.values, ['7', 'password_reset', '+9647701234567']);
  });

  it('a matching hash consumes the code (and nothing else)', async () => {
    const { tx, calls } = withRow(row());
    assert.deepEqual(await createPgOtpRepository(tx).verify(verifyArgs), { kind: 'verified' });
    assert.equal(calls.length, 2);
    assert.match(calls[1]!.text, /SET consumed_at = now\(\) WHERE id = \$1/);
    assert.deepEqual(calls[1]!.values, ['code-1']);
  });

  it('a different hash counts an attempt, capped by the maximum, and does not consume', async () => {
    const { tx, calls } = withRow(row({ code_hash: Buffer.alloc(32, 1) }));
    assert.deepEqual(await createPgOtpRepository(tx).verify(verifyArgs), { kind: 'rejected', reason: 'mismatch' });
    assert.equal(calls.length, 2);
    assert.match(calls[1]!.text, /SET attempts = attempts \+ 1 WHERE id = \$1 AND attempts < max_attempts/);
    assert.ok(!calls[1]!.text.includes('consumed_at'));
  });

  it('writes nothing when there is no active code, when it expired, or when its attempts are used up', async () => {
    for (const [r, reason] of [[null, 'no_active_code'], [row({ expired: true }), 'expired'], [row({ attempts: 5 }), 'attempts_exhausted'], [row({ attempts: 6, max_attempts: 5 }), 'attempts_exhausted']] as const) {
      const { tx, calls } = withRow(r);
      assert.deepEqual(await createPgOtpRepository(tx).verify(verifyArgs), { kind: 'rejected', reason });
      assert.equal(calls.length, 1, reason);
    }
  });

  it('the CORRECT hash is refused once the attempts are used up or the code expired (the checks come first)', async () => {
    for (const r of [row({ attempts: 5 }), row({ expired: true })]) {
      const { tx } = withRow(r);
      assert.equal((await createPgOtpRepository(tx).verify(verifyArgs)).kind, 'rejected');
    }
  });

  it('one attempt left: a wrong guess is recorded, a right one still verifies', async () => {
    assert.equal((await createPgOtpRepository(withRow(row({ attempts: 4, code_hash: Buffer.alloc(32, 1) })).tx).verify(verifyArgs)).kind, 'rejected');
    assert.equal((await createPgOtpRepository(withRow(row({ attempts: 4 })).tx).verify(verifyArgs)).kind, 'verified');
  });

  it('a stored hash of the wrong length is a plain mismatch, never an exception', async () => {
    const { tx } = withRow(row({ code_hash: Buffer.alloc(5) }));
    assert.deepEqual(await createPgOtpRepository(tx).verify(verifyArgs), { kind: 'rejected', reason: 'mismatch' });
  });

  it('never selects a plain code: the only code-like column is code_hash', async () => {
    const { tx, calls } = withRow(row());
    await createPgOtpRepository(tx).verify(verifyArgs);
    assert.ok(!/\bcode\b/.test(calls[0]!.text.replace(/code_hash/g, '')));
  });
});

describe('otp, user and session repositories: parameterization and minimal privileges', () => {
  const evil = "'); DROP TABLE users; --";
  it('hostile values are bound parameters in every new statement', async () => {
    const { tx, calls } = script((text) => ({ rows: text.includes('count(*)') ? [{ last_hour: 0, last_day: 0, cooldown_left: 0 }] : [{ id: 'x', code_hash: HASH, attempts: 0, max_attempts: 5, expired: false, expires_at: new Date() }], rowCount: 1 }));
    const otp = createPgOtpRepository(tx);
    await otp.issue({ userId: evil, phoneE164: evil, purpose: 'phone_verify', codeHash: HASH });
    await otp.verify({ userId: evil, phoneE164: evil, purpose: 'password_reset', expectedHash: HASH });
    const users = createPgUsersRepository(tx);
    await users.findById(evil);
    await users.findByPhone(evil);
    await users.markPhoneVerified(evil);
    await users.resetPassword(evil, evil);
    await createPgSessionsRepository(tx).revokeAllForUser(evil, 'password_changed');
    assert.equal(calls.length, 11, 'issue 4 + verify 2 + users 4 + sessions 1');
    for (const c of calls) {
      assert.ok(!c.text.includes('DROP TABLE') && !c.text.includes(evil), 'a value leaked into the SQL text');
      assert.match(c.text, /\$1/);
      assert.ok(!/\$\{/.test(c.text));
    }
  });

  it('findById / findByPhone read the profile WITHOUT the password hash, and ignore deleted users', async () => {
    const { tx, calls } = script(() => ({ rows: [{ id: '7', name: 'علي حسين', phone_e164: '+9647701234567', role: 'user', status: 'active', phone_verified_at: new Date('2026-01-01'), created_at: new Date('2025-12-01') }], rowCount: 1 }));
    const users = createPgUsersRepository(tx);
    const byId = await users.findById('7');
    const byPhone = await users.findByPhone('+9647701234567');
    for (const c of calls) {
      assert.ok(!/password|hash/.test(c.text));
      assert.match(c.text, /deleted_at IS NULL/);
    }
    assert.deepEqual(calls.map((c) => c.values), [['7'], ['+9647701234567']]);
    assert.equal(byId?.phoneVerifiedAt?.toISOString(), '2026-01-01T00:00:00.000Z');
    assert.equal(byPhone?.id, '7');
    assert.equal(await createPgUsersRepository(script().tx).findById('1'), null);
  });

  it('markPhoneVerified sets the time only once (IS NULL guard) and reports whether it changed anything', async () => {
    const hit = script(() => ({ rows: [], rowCount: 1 }));
    assert.equal(await createPgUsersRepository(hit.tx).markPhoneVerified('7'), true);
    assert.match(hit.calls[0]!.text, /SET phone_verified_at = now\(\) WHERE id = \$1 AND phone_verified_at IS NULL/);
    assert.equal(await createPgUsersRepository(script(() => ({ rows: [], rowCount: 0 })).tx).markPhoneVerified('7'), false);
  });

  it('resetPassword changes the hash and its date and clears the lockout, in ONE statement', async () => {
    const { tx, calls } = script();
    await createPgUsersRepository(tx).resetPassword('7', '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA');
    assert.equal(calls.length, 1);
    assert.match(calls[0]!.text, /SET password_hash = \$2, password_changed_at = now\(\), failed_logins = 0, locked_until = NULL WHERE id = \$1/);
    assert.deepEqual(calls[0]!.values, ['7', '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA']);
  });

  it('revokeAllForUser ends every live session of the user, with the password_changed reason', async () => {
    const { tx, calls } = script(() => ({ rows: [], rowCount: 3 }));
    assert.equal(await createPgSessionsRepository(tx).revokeAllForUser('7', 'password_changed'), 3);
    assert.match(calls[0]!.text, /SET revoked_at = now\(\), revoked_reason = \$2 WHERE user_id = \$1 AND revoked_at IS NULL/);
    assert.deepEqual(calls[0]!.values, ['7', 'password_changed']);
  });

  it('every UPDATE on users touches only columns the application role may update (migrations 0012/0013)', async () => {
    const { tx, calls } = script();
    const users = createPgUsersRepository(tx);
    await users.markPhoneVerified('7');
    await users.resetPassword('7', 'x');
    const allowed = new Set(['name', 'phone_e164', 'phone_verified_at', 'email', 'status', 'password_hash', 'password_changed_at', 'failed_logins', 'locked_until', 'last_login_at', 'deleted_at']);
    for (const c of calls) {
      const set = (/SET\s+([\s\S]*?)\s+WHERE/.exec(c.text)?.[1] ?? '').replace(/make_interval\([^)]*\)/g, 'make_interval()');
      for (const col of set.match(/\b([a-z_]+)\s*=/g) ?? []) assert.ok(allowed.has(col.replace(/\s*=/, '')), `${col} is not updatable by najaf_app`);
      assert.ok(!/\b(role|id|created_at|updated_at|version)\s*=/.test(set));
    }
  });

  it('password_hash is written in exactly two statements (registration INSERT, recovery UPDATE) and read in exactly one (the login lookup)', async () => {
    const { tx, calls } = script(() => ({ rows: [{ id: 's', name: 'n', phone_e164: '+9647701234567', role: 'user', status: 'active', created_at: new Date(), password_hash: 'h', locked: false }], rowCount: 1 }));
    const users = createPgUsersRepository(tx);
    await users.insert({ name: 'abc', phoneE164: '+9647701234567', passwordHash: 'h' });
    await users.findCredentialsByPhone('+9647701234567');
    await users.findById('1');
    await users.findByPhone('+9647701234567');
    await users.markPhoneVerified('1');
    await users.resetPassword('1', 'h');
    const first = (c: Call) => c.text.trim().split(/\s+/).slice(0, 3).join(' ');
    assert.deepEqual(calls.filter((c) => c.text.includes('password_hash')).map(first), ['INSERT INTO users', 'SELECT id, name,', 'UPDATE users SET']);
  });
});

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { APP_ROLE, REQUIRED_TABLES, REQUIRED_VIEWS, SCHEMA_CONTRACT_VERSION } from '../../src/schema-contract.ts';

const migrations = join(import.meta.dirname, '..', '..', '..', 'database', 'migrations');
const available = existsSync(migrations);
const sql = available
  ? readdirSync(migrations)
      .filter((f) => f.endsWith('.sql'))
      .sort()
      .map((f) => [f, readFileSync(join(migrations, f), 'utf8')] as const)
  : [];
const all = sql.map(([, t]) => t).join('\n');

describe('schema contract vs the validated migrations (database/migrations)', { skip: available ? false : 'database/migrations not found next to backend/' }, () => {
  it('REQUIRED_TABLES is exactly the set of CREATE TABLE statements', () => {
    const found = [...all.matchAll(/^CREATE TABLE (\w+)\s*\(/gm)].map((m) => m[1] as string).sort();
    assert.deepEqual([...REQUIRED_TABLES].sort(), found);
    assert.equal(REQUIRED_TABLES.length, 16);
  });

  it('REQUIRED_VIEWS is exactly the set of CREATE VIEW statements', () => {
    const found = [...all.matchAll(/^CREATE VIEW (\w+)/gm)].map((m) => m[1] as string).sort();
    assert.deepEqual([...REQUIRED_VIEWS].sort(), found);
  });

  it('the contract version is the latest migration number', () => {
    const last = sql.map(([f]) => f.slice(0, 4)).sort().at(-1);
    assert.equal(SCHEMA_CONTRACT_VERSION, last);
  });

  it('the application role is created by the migrations', () => {
    assert.ok(all.includes(`CREATE ROLE ${APP_ROLE} NOLOGIN`));
  });

  it('no required object name is duplicated', () => {
    const names = [...REQUIRED_TABLES, ...REQUIRED_VIEWS];
    assert.equal(new Set(names).size, names.length);
  });
});

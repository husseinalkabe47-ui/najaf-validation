// Phase 11.5, Step 5.5: the car-image HTTP layer, run WITHOUT Fastify (routes on a recording stand-in, handlers called with plain
// request objects), wired to the REAL authentication service, policy layer and image service over the in-memory store. Plus SQL
// and source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { CAR_IMAGE_RATE_LIMITS, registerCarImageRoutes, toCarImageHttp } from '../../src/car-images/routes.ts';
import { CarImageError, createCarImageService } from '../../src/car-images/service.ts';
import { createPgCarImageRepository, PROMOTE_MAIN_SQL, RENUMBER_SQL, buildDeleteImage, buildFindOwnAsset, buildFindOwnCar, buildInsertImage, buildListImages } from '../../src/car-images/repository.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeCarImageStore } from '../helpers/fake-car-images.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JSON_HEADERS = { 'content-type': 'application/json' };
const IMAGES = '/v1/me/cars/:id/images';
const ONE = '/v1/me/cars/:id/images/:imageId';

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const imgs = makeFakeCarImageStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
  });
  const carImages = createCarImageService({ store: imgs.store });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerCarImageRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, carImages, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    const h = bearer(r.session.accessToken);
    return { id: r.user.id, headers: h, json: { ...h, ...JSON_HEADERS } };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    const h = bearer(r.session.accessToken);
    return { id: r.user.id, headers: h, json: { ...h, ...JSON_HEADERS } };
  }
  async function attach(who: { id: string; json: Record<string, string> }, carId: string) {
    const asset = imgs.addAsset({ ownerId: who.id });
    const sent = await call('POST', IMAGES, { headers: who.json, params: { id: carId }, body: { assetId: asset.id } });
    assert.equal(sent.status, 201, JSON.stringify(sent.body));
    return { asset, image: (sent.body as { image: { id: string } }).image };
  }
  return { routes, call, member, pendingDealer, attach, imgs };
}

describe('car-image routes: registration', () => {
  it('registers exactly the three owner routes; every one is rate limited when a limiter is supplied', () => {
    const { routes } = setup(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`DELETE ${ONE}`, `GET ${IMAGES}`, `POST ${IMAGES}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts?.bodyLimit, 1024);
  });
});

describe('car-image routes: authentication', () => {
  it('no token or a bad token is 401 with WWW-Authenticate on every route', async () => {
    const s = setup();
    for (const [method, path] of [['GET', IMAGES], ['POST', IMAGES], ['DELETE', ONE]] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const sent = await s.call(method, path, { headers: { ...headers, ...JSON_HEADERS }, params: { id: '7000', imageId: '1' }, body: { assetId: '00000000-0000-4000-8000-000000000001' } });
        assert.equal(sent.status, 401, `${method} ${path}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
      }
    }
  });

  it('a pending dealer (authenticated, no actor) gets 404 everywhere: it cannot even learn that a car exists', async () => {
    const s = setup();
    const a = await s.member();
    s.imgs.addCar({ ownerId: a.id, id: '7500' });
    const d = await s.pendingDealer();
    assert.equal((await s.call('GET', IMAGES, { headers: d.headers, params: { id: '7500' } })).status, 404);
    assert.equal((await s.call('POST', IMAGES, { headers: d.json, params: { id: '7500' }, body: { assetId: '00000000-0000-4000-8000-000000000001' } })).status, 404);
    assert.equal((await s.call('DELETE', ONE, { headers: d.headers, params: { id: '7500', imageId: '1' } })).status, 404);
  });
});

describe('car-image routes: behavior', () => {
  it('POST is 201 {image}, GET lists it, DELETE is 204 with no body; the whole flow works for the owner', async () => {
    const s = setup();
    const a = await s.member();
    const car = s.imgs.addCar({ ownerId: a.id });
    const { image } = await s.attach(a, car.id);
    const list = await s.call('GET', IMAGES, { headers: a.headers, params: { id: car.id } });
    assert.equal(list.status, 200);
    assert.equal((list.body as { images: unknown[]; maxImages: number }).maxImages, 4);
    assert.equal((list.body as { images: Array<{ id: string }> }).images[0]!.id, image.id);
    const del = await s.call('DELETE', ONE, { headers: a.headers, params: { id: car.id, imageId: image.id } });
    assert.equal(del.status, 204);
    assert.equal(del.body, undefined);
    assert.equal((await s.call('DELETE', ONE, { headers: a.headers, params: { id: car.id, imageId: image.id } })).status, 404);
  });

  it('another member gets 404 identical to an unknown car, for list, add and delete; cross-car delete is 404', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const car = s.imgs.addCar({ ownerId: a.id });
    const other = s.imgs.addCar({ ownerId: a.id });
    const { image } = await s.attach(a, car.id);
    const unknown = await s.call('GET', IMAGES, { headers: b.headers, params: { id: '999999' } });
    const asset = s.imgs.addAsset({ ownerId: b.id });
    for (const r of [
      await s.call('GET', IMAGES, { headers: b.headers, params: { id: car.id } }),
      await s.call('POST', IMAGES, { headers: b.json, params: { id: car.id }, body: { assetId: asset.id } }),
      await s.call('DELETE', ONE, { headers: b.headers, params: { id: car.id, imageId: image.id } }),
      await s.call('DELETE', ONE, { headers: a.headers, params: { id: other.id, imageId: image.id } }),
    ]) {
      assert.equal(r.status, 404);
      assert.deepEqual(r.body, unknown.body);
    }
    assert.equal(s.imgs.imagesOf(car.id).length, 1);
  });

  it('another user\'s asset is 404 (like an unknown asset); an unready or attached asset is 409; the sixth is image_limit', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const car = s.imgs.addCar({ ownerId: a.id });
    const post = (assetId: string) => s.call('POST', IMAGES, { headers: a.json, params: { id: car.id }, body: { assetId } });
    const foreign = await post(s.imgs.addAsset({ ownerId: b.id }).id);
    const unknown = await post('00000000-0000-4000-8000-0000000fffff');
    assert.equal(foreign.status, 404);
    assert.deepEqual(foreign.body, unknown.body);
    assert.equal((await post(s.imgs.addAsset({ ownerId: a.id, status: 'pending' }).id)).status, 409);
    const { asset } = await s.attach(a, car.id);
    assert.equal((await post(asset.id)).status, 409);
    for (let i = 0; i < 3; i++) await s.attach(a, car.id);
    const full = await post(s.imgs.addAsset({ ownerId: a.id }).id);
    assert.equal(full.status, 409);
    assert.equal((full.body as ErrBody).error.code, 'image_limit');
  });

  it('validation errors are 400 with field names and codes only; a car or owner in the body is refused', async () => {
    const s = setup();
    const a = await s.member();
    const car = s.imgs.addCar({ ownerId: a.id });
    const bad = await s.call('POST', IMAGES, { headers: a.json, params: { id: car.id }, body: { assetId: 'SECRET-nope', ownerId: '2', carId: '1' } });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as ErrBody).error.fields, [{ field: 'ownerId', code: 'unknown_field' }, { field: 'carId', code: 'unknown_field' }, { field: 'assetId', code: 'invalid_format' }]);
    assert.ok(!JSON.stringify(bad.body).includes('SECRET'));
  });

  it('a non-JSON POST is 415 before any processing; a body on DELETE is refused', async () => {
    const s = setup();
    const a = await s.member();
    const car = s.imgs.addCar({ ownerId: a.id });
    const { image } = await s.attach(a, car.id);
    assert.equal((await s.call('POST', IMAGES, { headers: { ...a.headers, 'content-type': 'text/plain' }, params: { id: car.id }, body: 'x' })).status, 415);
    assert.equal((await s.call('DELETE', ONE, { headers: a.headers, params: { id: car.id, imageId: image.id }, body: { force: true } })).status, 400);
    assert.equal(s.imgs.imagesOf(car.id).length, 1);
  });

  it('writes have their own budget per address; reads are not blocked by it', async () => {
    const s = setup(true);
    const a = await s.member();
    const car = s.imgs.addCar({ ownerId: a.id });
    for (let i = 0; i < CAR_IMAGE_RATE_LIMITS.write.limit; i++) {
      const sent = await s.call('POST', IMAGES, { headers: a.json, params: { id: car.id }, body: { assetId: '00000000-0000-4000-8000-0000000fffff' } });
      assert.equal(sent.status, 404);
    }
    const denied = await s.call('POST', IMAGES, { headers: a.json, params: { id: car.id }, body: { assetId: '00000000-0000-4000-8000-0000000fffff' } });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal((await s.call('GET', IMAGES, { headers: a.headers, params: { id: car.id } })).status, 200);
  });

  it('maps errors: validation 400, image_limit and invalid_state 409, authz 401/403/404, anything else not ours', () => {
    assert.equal(toCarImageHttp(new CarImageError('validation_failed', []))?.status, 400);
    assert.equal(toCarImageHttp(new CarImageError('image_limit'))?.status, 409);
    assert.equal(toCarImageHttp(new CarImageError('invalid_state'))?.status, 409);
    assert.equal(toCarImageHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toCarImageHttp(new Error('boom')), undefined);
  });
});

describe('car-image SQL and source guards', () => {
  const OWNER = '7';
  const UUID = '00000000-0000-4000-8000-000000000001';

  it('the car is always found by owner, member source and not deleted; the write path locks it', () => {
    for (const lock of [false, true]) {
      const s = buildFindOwnCar('1', OWNER, lock);
      assert.match(s.text, /c\.owner_id = \$2::bigint AND c\.source_type = 'member' AND c\.deleted_at IS NULL/);
      assert.deepEqual(s.values, ['1', OWNER]);
      assert.equal(/FOR UPDATE OF c/.test(s.text), lock);
    }
  });

  it('the asset is always found by its owner; an image only through its car', () => {
    const a = buildFindOwnAsset(UUID, OWNER);
    assert.match(a.text, /a\.id = \$1::uuid AND a\.owner_id = \$2::bigint/);
    assert.deepEqual(a.values, [UUID, OWNER]);
    const d = buildDeleteImage('5', '1');
    assert.match(d.text, /WHERE id = \$1::bigint AND car_id = \$2::bigint/);
    assert.match(buildListImages('1').text, /WHERE ci\.car_id = \$1::bigint/);
  });

  it('insert uses parameters only, appends last, and makes the first image main', () => {
    const s = buildInsertImage('1', UUID);
    assert.deepEqual(s.values, ['1', UUID]);
    assert.match(s.text, /COALESCE\(MAX\(sort_order\) \+ 1, 0\), COUNT\(\*\) = 0 FROM car_images WHERE car_id = \$1::bigint/);
  });

  it('after a delete the layout statements stay inside the one car', () => {
    assert.equal(PROMOTE_MAIN_SQL.match(/car_id = \$1::bigint/g)?.length, 2, 'both the candidate and the "already has a main" test are per car');
    assert.match(RENUMBER_SQL, /ci\.car_id = \$1::bigint/);
  });

  it('the acting-user re-check locks only an active, not deleted account, by the actor id', async () => {
    const seen: Array<{ text: string; values: readonly unknown[] | undefined }> = [];
    const repo = createPgCarImageRepository({ query: async (text: string, values?: readonly unknown[]) => { seen.push({ text, values }); return { rows: [{ id: '1' }], rowCount: 1 } as never; } });
    assert.equal(await repo.lockActingUser('7'), true);
    assert.equal(seen.length, 1);
    assert.match(seen[0]!.text, /WHERE id = \$1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE/);
    assert.deepEqual(seen[0]!.values, ['7']);
  });

  it('the repository writes only the permitted columns, never touches assets or cars, never selects * or storage keys', () => {
    const src = code('src/car-images/repository.ts');
    assert.ok(!/SELECT\s+\*/i.test(src));
    assert.ok(!/\b(storage_key|thumb_key|sha256|reject_reason|legacy_ref)\b/.test(src), 'no storage key or checksum is read');
    assert.ok(!/\b(INSERT INTO|UPDATE|DELETE FROM)\s+(assets|cars|users|showrooms|favorites)\b/i.test(src), 'only car_images is written');
    const setColumns = [...src.matchAll(/UPDATE car_images(?: ci)? SET (\w+) =/g)].map((m) => m[1]);
    assert.deepEqual(setColumns.sort(), ['is_main', 'sort_order'], 'only is_main and sort_order are ever SET (car_id and asset_id are immutable)');
  });

  it('the service and routes never take an owner or car from the body, and never see a storage key', () => {
    const svc = code('src/car-images/service.ts');
    const routes = code('src/car-images/routes.ts');
    assert.ok(!/request\.|headers|\.query\b/.test(svc), 'the service sees no HTTP object');
    assert.ok(!/ownerId\s*:|body\.(ownerId|carId|owner_id)/.test(svc.replace(/ownerId: (car|row)\.ownerId/g, '')));
    assert.ok(!/storage|thumb_key|sha256/i.test(svc + routes + code('src/car-images/validation.ts')));
    assert.ok(!/ownerId|owner_id|userId/.test(routes));
    assert.match(routes, /return toActor\(found\.user\);/);
    assert.match(svc, /findOwnAsset\(assetId, actor\.id\)/);
    assert.match(svc, /deleteImage\(imageId, car\.id\)/);
  });

  it('the routes are wired only together with authentication, and the process supplies the Postgres-backed service', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.carImages\) registerCarImageRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createCarImageService\(\{ store: createPgCarImageStore\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\bcarImages\b/);
  });
});

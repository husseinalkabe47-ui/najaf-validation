import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { AUTH_ENV_VARS, AuthConfigError, MIN_SECRET_LENGTH, loadAuthConfig, redactAuthConfig } from '../../src/auth/config.ts';

const SECRET = 'k9XvQ2mLp8Rt3Zw7Yb5Nc1Hd6Jf4Gs0A';
const base = (extra: Record<string, string | undefined> = {}) => ({ AUTH_ACCESS_TOKEN_SECRET: SECRET, ...extra });
function problemsOf(env: Record<string, string | undefined>): string[] {
  try {
    loadAuthConfig(env);
  } catch (e) {
    if (e instanceof AuthConfigError) return e.problems;
    throw e;
  }
  return [];
}

describe('auth config: the access-token secret', () => {
  it('loads a good secret; trusting nobody is the default', () => {
    const c = loadAuthConfig(base());
    assert.equal(c.accessTokenSecret, SECRET);
    assert.deepEqual(c.trustedProxies, []);
    assert.equal(Object.isFrozen(c), true);
  });

  it('is required', () => {
    assert.ok(problemsOf({}).some((m) => m.includes('AUTH_ACCESS_TOKEN_SECRET is required')));
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: '' }).some((m) => m.includes('is required')));
  });

  it('must be at least 32 characters', () => {
    assert.equal(MIN_SECRET_LENGTH, 32);
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: SECRET.slice(0, 31) }).some((m) => m.includes('at least 32')));
    assert.deepEqual(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: SECRET.slice(0, 32) }), []);
  });

  it('rejects whitespace, low variety and placeholder values', () => {
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: SECRET + ' x' }).some((m) => m.includes('whitespace')));
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: 'a'.repeat(40) }).some((m) => m.includes('variety')));
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: 'abababababababababababababababab' }).some((m) => m.includes('variety')));
    for (const placeholder of ['change-me-0123456789abcdefghijklmnopqrstuv', 'ThisIsMySecretValue0123456789abcdefghijkl', 'your-secret-goes-here-0123456789abcdef', 'PASSWORD-0123456789-abcdefghijklmnopqr']) {
      assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: placeholder }).some((m) => m.includes('placeholder')), placeholder);
    }
  });

  it('accepts what `openssl rand -base64 48` and a hex secret look like', () => {
    assert.deepEqual(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: 'qW3rT7yU1iO5pA9sD2fG6hJ0kL4zX8cV3bN7mQ1wE5rT9yU2iO6pA0sD4fG8hJ1k' }), []);
    assert.deepEqual(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: '3f9a1c7e5b2d8f406a1e9c3b7d5f2a80c4e6b8d0f1a3c5e7b9d2f4a6c8e0b1d3' }), []);
  });

  it('never echoes the secret: not in errors, not in the redacted form', () => {
    const weak = 'tooShortSecret-visible-marker';
    const msg = problemsOf({ AUTH_ACCESS_TOKEN_SECRET: weak }).join('\n');
    assert.ok(!msg.includes('visible-marker'));
    const text = JSON.stringify(redactAuthConfig(loadAuthConfig(base())));
    assert.ok(!text.includes(SECRET));
    assert.ok(text.includes('"accessTokenSecret":"***"'));
  });

  it('every problem is reported in one error', () => {
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: 'a b', AUTH_TRUSTED_PROXIES: 'nonsense' }).length >= 3);
  });
});

describe('auth config: trusted proxies', () => {
  it('parses addresses, CIDRs (IPv4 and IPv6) and keywords, trimming spaces and ignoring empty entries', () => {
    const c = loadAuthConfig(base({ AUTH_TRUSTED_PROXIES: ' 10.0.0.0/8 , 172.16.0.5,, loopback ,2001:db8::/32, ::1' }));
    assert.deepEqual(c.trustedProxies, ['10.0.0.0/8', '172.16.0.5', 'loopback', '2001:db8::/32', '::1']);
  });

  it('empty or whitespace-only means trust nobody', () => {
    assert.deepEqual(loadAuthConfig(base({ AUTH_TRUSTED_PROXIES: '' })).trustedProxies, []);
    assert.deepEqual(loadAuthConfig(base({ AUTH_TRUSTED_PROXIES: '  ,  ' })).trustedProxies, []);
  });

  it('refuses to trust every address: /0 prefixes, wildcards and "true"', () => {
    for (const entry of ['0.0.0.0/0', '::/0', '10.0.0.0/0', '*', 'true', 'all', '1']) {
      assert.ok(problemsOf(base({ AUTH_TRUSTED_PROXIES: entry })).length > 0, entry);
    }
    assert.ok(problemsOf(base({ AUTH_TRUSTED_PROXIES: '0.0.0.0/0' })).some((m) => m.includes('trust every address')));
  });

  it('rejects malformed entries', () => {
    for (const entry of ['300.1.1.1', '10.0.0', '10.0.0.0/33', '10.0.0.0/abc', '10.0.0.0/8/8', '::1/129', 'example.com', '10.0.0.1:8080', 'http://10.0.0.1', '/8', 'loop back']) {
      assert.ok(problemsOf(base({ AUTH_TRUSTED_PROXIES: entry })).length > 0, entry);
    }
  });

  it('rejects an unreasonably long list', () => {
    const many = Array.from({ length: 21 }, (_, i) => `10.0.${i}.1`).join(',');
    assert.ok(problemsOf(base({ AUTH_TRUSTED_PROXIES: many })).some((m) => m.includes('more than 20')));
    assert.deepEqual(problemsOf(base({ AUTH_TRUSTED_PROXIES: Array.from({ length: 20 }, (_, i) => `10.0.${i}.1`).join(',') })), []);
  });
});

describe('.env.auth.example documents the auth configuration exactly', () => {
  const example = readFileSync(join(import.meta.dirname, '..', '..', '.env.auth.example'), 'utf8');
  const documented = new Set([...example.matchAll(/^#?\s*([A-Z][A-Z0-9_]*)=/gm)].map((m) => m[1] as string));

  it('every variable the code reads is documented, and nothing else is listed', () => {
    for (const v of AUTH_ENV_VARS) assert.ok(documented.has(v), `${v} is not documented`);
    for (const v of documented) assert.ok((AUTH_ENV_VARS as readonly string[]).includes(v), `${v} is listed but not read`);
  });

  it('contains no real secret: the example value is empty, and the file explains how to generate one', () => {
    assert.match(example, /^AUTH_ACCESS_TOKEN_SECRET=\s*$/m);
    assert.ok(example.includes('openssl rand -base64 48'));
    assert.ok(problemsOf({ AUTH_ACCESS_TOKEN_SECRET: '' }).length > 0, 'the example as shipped is NOT a valid configuration (no default secret)');
  });
});

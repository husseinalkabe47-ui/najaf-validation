// Phase 11.5, Step 5.4: a member's own car ads, through the real service and the real policy (src/authz), over an in-memory store
// that mirrors the SQL scoping and the database triggers. Covers ownership/IDOR, authorization, D1 (nothing is published),
// validation, soft delete, optimistic versioning and concurrency, audit and all-or-nothing transactions.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AuthzError, isPublic, memberCarResource } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { MemberCarError, createMemberCarService, searchTextOf } from '../../src/member-cars/service.ts';
import { BRAND_MAX, DESCRIPTION_MAX, MEMBER_CAR_LIMIT_MAX } from '../../src/member-cars/validation.ts';
import { makeFakeMemberCarStore } from '../helpers/fake-member-cars.ts';

const A: Actor = Object.freeze({ id: '1', role: 'member' });
const B: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ADMIN: Actor = Object.freeze({ id: '4', role: 'admin' });
const VALID = Object.freeze({ brand: 'Toyota', model: 'Camry', year: 2015, price: 12000, currency: 'USD', phone: '07701234567' });

function setup() {
  const f = makeFakeMemberCarStore();
  for (const a of [A, B, DEALER, ADMIN]) f.addUser(a.id);
  const svc = createMemberCarService({ store: f.store });
  return { f, svc };
}

type Fields = Array<{ field: string; code: string }>;
async function fieldsOf(p: Promise<unknown>): Promise<Fields> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof MemberCarError && e.code === 'validation_failed', `expected validation_failed, got ${String(e)}`);
    return e.fields ?? [];
  }
  assert.fail('expected a validation error');
}
const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isCarError = (code: string) => (e: unknown) => e instanceof MemberCarError && e.code === code;

describe('member cars: create', () => {
  it('creates the ad for the ACTOR, as an unpublished pending member car, with normalized contact data', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, { ...VALID, color: '  أبيض  ', location: 'بغداد' }, { requestId: 'req-1' });
    assert.equal(car.status, 'pending');
    assert.equal(car.version, 1);
    assert.equal(car.phone, '+9647701234567');
    assert.equal(car.whatsapp, '+9647701234567', 'no WhatsApp given = the phone number (prototype)');
    assert.equal(car.color, 'أبيض');
    assert.equal(car.price, 12000);
    const row = f.car(car.id)!;
    assert.equal(row.ownerId, A.id);
    assert.equal(row.sourceType, 'member');
    assert.equal(row.searchText, searchTextOf({ brand: 'Toyota', model: 'Camry', year: 2015, color: 'أبيض', location: 'بغداد' }));
  });

  it('D1: nothing is published, whatever the role (member, dealer, admin): every new ad is pending and not public', async () => {
    const { f, svc } = setup();
    for (const actor of [A, DEALER, ADMIN]) {
      const car = await svc.create(actor, VALID);
      assert.equal(car.status, 'pending', `${actor.role}`);
      const row = f.car(car.id)!;
      assert.equal(isPublic(memberCarResource({ ownerId: row.ownerId, status: row.status, ownerActive: true, deleted: false })), false);
    }
  });

  it('owner, showroom, source type, status, id, version and reviewer fields cannot be supplied (unknown_field)', async () => {
    const { f, svc } = setup();
    for (const key of ['ownerId', 'owner_id', 'userId', 'showroomId', 'sourceType', 'status', 'id', 'version', 'reviewedBy', 'deletedAt', 'rejectionReason']) {
      assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, [key]: key === 'status' ? 'active' : '2' })), [{ field: key, code: 'unknown_field' }], key);
    }
    assert.equal(f.cars().length, 0);
  });

  it('an account that may not act (no actor) is refused with 403 and nothing is read or written', async () => {
    const { f, svc } = setup();
    await assert.rejects(svc.create(null, VALID), isAuthz('forbidden'));
    assert.deepEqual(f.calls, []);
  });

  it('an actor suspended after authentication (re-checked inside the transaction) cannot create', async () => {
    const { f, svc } = setup();
    f.setUser(A.id, 'suspended');
    await assert.rejects(svc.create(A, VALID), isAuthz('forbidden'));
    assert.equal(f.cars().length, 0);
    assert.equal(f.audits().length, 0);
  });

  it('writes one audit row (numbers only) in the same transaction; an audit failure leaves no ad behind', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID, { requestId: 'req-9' });
    assert.deepEqual(f.audits(), [{ action: 'member_car.create', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: car.id, afterData: { version: 1 }, requestId: 'req-9' }]);
    f.faults.failNextAudit = true;
    await assert.rejects(svc.create(A, VALID));
    assert.equal(f.cars().length, 1, 'the second insert was rolled back');
  });

  it('records the database role vocabulary: dealer and admin as themselves, member as user', async () => {
    const { f, svc } = setup();
    await svc.create(DEALER, VALID);
    await svc.create(ADMIN, VALID);
    assert.deepEqual(f.audits().map((a) => a.actorRole), ['dealer', 'admin']);
  });
});

describe('member cars: validation (strict whitelist, codes only)', () => {
  it('the required fields are brand, model, year, price, currency and phone', async () => {
    const { svc } = setup();
    assert.deepEqual((await fieldsOf(svc.create(A, {}))).map((e) => e.field).sort(), ['brand', 'currency', 'model', 'phone', 'price', 'year']);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, brand: null })), [{ field: 'brand', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, brand: '   ' })), [{ field: 'brand', code: 'required' }]);
  });

  it('types are strict (numbers are JSON numbers, text is text)', async () => {
    const { svc } = setup();
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, year: '2015' })), [{ field: 'year', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, price: '12000' })), [{ field: 'price', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, brand: 5 })), [{ field: 'brand', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, phone: 7701234567 })), [{ field: 'phone', code: 'invalid_type' }]);
  });

  it('ranges and vocabularies follow the table constraints', async () => {
    const { svc } = setup();
    const bad: Array<[string, unknown]> = [
      ['year', 1979], ['year', 2101], ['year', 2015.5], ['price', 0], ['price', -1], ['price', 1e12], ['price', 1.5], ['mileage', -1], ['mileage', 1.2],
      ['currency', 'EUR'], ['transmission', 'Automatic'], ['fuelType', 'LPG'], ['phone', '0123'], ['phone', '+9647701'], ['whatsapp', 'wa.me/123'],
    ];
    for (const [field, value] of bad) assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, [field]: value })), [{ field, code: 'invalid_format' }], `${field}=${String(value)}`);
  });

  it('lengths are the column sizes, in characters', async () => {
    const { svc } = setup();
    assert.ok(await svc.create(A, { ...VALID, brand: 'ب'.repeat(BRAND_MAX) }));
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, brand: 'ب'.repeat(BRAND_MAX + 1) })), [{ field: 'brand', code: 'too_long' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, description: 'x'.repeat(DESCRIPTION_MAX + 1) })), [{ field: 'description', code: 'too_long' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, location: 'x'.repeat(201) })), [{ field: 'location', code: 'too_long' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, color: 'x'.repeat(41) })), [{ field: 'color', code: 'too_long' }]);
  });

  it('control characters are refused (the description may keep line breaks)', async () => {
    const { svc } = setup();
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, model: 'Cam\u0000ry' })), [{ field: 'model', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, description: 'a\u0007b' })), [{ field: 'description', code: 'invalid_format' }]);
    assert.equal((await svc.create(A, { ...VALID, description: 'سطر\r\nسطر' })).description, 'سطر\nسطر');
  });

  it('a brand or model must contain a letter or a digit', async () => {
    const { svc } = setup();
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, brand: '---' })), [{ field: 'brand', code: 'invalid_format' }]);
  });

  it('coordinates travel as a pair, in range, stored with 6 decimals', async () => {
    const { svc } = setup();
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, latitude: 33.3 })), [{ field: 'longitude', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, latitude: 91, longitude: 44 })), [{ field: 'latitude', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, latitude: 33, longitude: Number.NaN })), [{ field: 'longitude', code: 'invalid_format' }]);
    const car = await svc.create(A, { ...VALID, latitude: 33.31523456, longitude: 44.3661 });
    assert.equal(car.latitude, 33.315235);
    assert.equal(car.longitude, 44.3661);
  });

  it('a WhatsApp number in international form is normalized; an explicit null keeps none', async () => {
    const { svc } = setup();
    assert.equal((await svc.create(A, { ...VALID, whatsapp: '9647711112222' })).whatsapp, '+9647711112222');
    assert.equal((await svc.create(A, { ...VALID, whatsapp: null })).whatsapp, null);
  });

  it('the body must be a JSON object, and an unsafe key name is never echoed', async () => {
    const { svc } = setup();
    for (const body of [undefined, null, 'x', [], 5]) assert.deepEqual(await fieldsOf(svc.create(A, body)), [{ field: 'body', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.create(A, { ...VALID, '<img src=x>': 1 })), [{ field: 'unknown', code: 'unknown_field' }]);
  });

  it('errors never carry the submitted values', async () => {
    const { svc } = setup();
    const secret = 'SECRET-7731';
    const err = await svc.create(A, { ...VALID, phone: secret, currency: secret, brand: `${secret}\u0001` }).catch((e: unknown) => e);
    assert.ok(err instanceof MemberCarError);
    assert.ok(!JSON.stringify({ m: err.message, f: err.fields }).includes(secret));
  });

  it('invalid input never reaches the store', async () => {
    const { f, svc } = setup();
    await fieldsOf(svc.create(A, { ...VALID, year: 1 }));
    assert.deepEqual(f.calls, []);
  });
});

describe('member cars: ownership and non-disclosure (IDOR/BOLA)', () => {
  it('the owner reads their ad; another member, a dealer and an administrator all get the same 404', async () => {
    const { svc } = setup();
    const car = await svc.create(A, VALID);
    assert.equal((await svc.getOwn(A, car.id)).id, car.id);
    for (const other of [B, DEALER, ADMIN]) await assert.rejects(svc.getOwn(other, car.id), isAuthz('not_found'), other.role);
  });

  it('another user cannot update or delete the ad: 404, the row and the audit log are unchanged', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    const before = JSON.stringify(f.car(car.id));
    const audits = f.audits().length;
    for (const other of [B, DEALER, ADMIN]) {
      await assert.rejects(svc.update(other, car.id, { version: 1, price: 1 }), isAuthz('not_found'));
      await assert.rejects(svc.remove(other, car.id, { version: '1' }), isAuthz('not_found'));
    }
    assert.equal(JSON.stringify(f.car(car.id)), before);
    assert.equal(f.audits().length, audits);
  });

  it('a hidden, unknown and malformed id are the same 404; a malformed id never reaches the store', async () => {
    const { f, svc } = setup();
    const theirs = f.addCar({ ownerId: B.id });
    const outcome = async (id: unknown) => svc.getOwn(A, id).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome('999999');
    assert.ok(reference.startsWith('not_found|'));
    assert.equal(await outcome(theirs.id), reference);
    f.calls.length = 0;
    for (const id of ['abc', '0', '-1', '1.5', '01', ' 1', '9223372036854775808', undefined, null, 1, {}, ['1']]) assert.equal(await outcome(id), reference, JSON.stringify(id));
    assert.deepEqual(f.calls, []);
  });

  it('a showroom car (not a member ad) is not reachable through these routes, even by its showroom owner id', async () => {
    const { f, svc } = setup();
    const showroomCar = f.addCar({ ownerId: A.id, sourceType: 'showroom' });
    await assert.rejects(svc.getOwn(A, showroomCar.id), isAuthz('not_found'));
    await assert.rejects(svc.update(A, showroomCar.id, { version: 1, price: 5 }), isAuthz('not_found'));
    await assert.rejects(svc.remove(A, showroomCar.id, { version: '1' }), isAuthz('not_found'));
  });

  it('the list returns only the actor\'s own ads (every status, but never deleted ones)', async () => {
    const { f, svc } = setup();
    const mine = await svc.create(A, VALID);
    f.addCar({ ownerId: A.id, status: 'rejected', rejectionReason: 'صور غير واضحة' });
    f.addCar({ ownerId: A.id, status: 'sold' });
    f.addCar({ ownerId: A.id, deletedAt: new Date() });
    f.addCar({ ownerId: B.id });
    f.addCar({ ownerId: A.id, sourceType: 'showroom' });
    const page = await svc.listOwn(A, {});
    assert.equal(page.items.length, 3);
    assert.ok(page.items.some((c) => c.id === mine.id));
    assert.deepEqual(page.items.map((c) => c.status).sort(), ['pending', 'rejected', 'sold']);
    assert.equal(page.items.find((c) => c.status === 'rejected')!.rejectionReason, 'صور غير واضحة', 'the owner sees why their own ad was rejected');
    assert.deepEqual((await svc.listOwn(B, {})).items.length, 1);
  });

  it('an authenticated account that may not act: 403 on the collection, 404 on an item, and nothing is touched', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    f.calls.length = 0;
    await assert.rejects(svc.listOwn(null, {}), isAuthz('forbidden'));
    await assert.rejects(svc.getOwn(null, car.id), isAuthz('not_found'));
    await assert.rejects(svc.update(null, car.id, { version: 1, price: 1 }), isAuthz('not_found'));
    await assert.rejects(svc.remove(null, car.id, { version: '1' }), isAuthz('not_found'));
    assert.deepEqual(f.calls, []);
  });

  it('an owner suspended after authentication cannot change the ad (re-checked inside the transaction)', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    f.setUser(A.id, 'suspended');
    await assert.rejects(svc.update(A, car.id, { version: 1, price: 1 }), isAuthz('not_found'));
    await assert.rejects(svc.remove(A, car.id, { version: '1' }), isAuthz('not_found'));
    assert.equal(f.car(car.id)!.version, 1);
    assert.equal(f.car(car.id)!.deletedAt, null);
  });

  it('defense in depth: even if the SQL forgot the owner filter, another user\'s row is still 404 and never listed', async () => {
    const { f } = setup();
    const theirs = f.addCar({ ownerId: B.id });
    // A repository whose owner scoping is broken: it returns rows by id / for everyone.
    const leaky = {
      ...f.store,
      cars: {
        ...f.store.cars,
        findOwn: async (id: string) => (await f.store.cars.findOwn(id, f.car(id)?.ownerId ?? '0')),
        listOwn: async (_owner: string, q: Parameters<typeof f.store.cars.listOwn>[1]) => (await f.store.cars.listOwn(B.id, q)),
      },
      transaction: <T,>(fn: Parameters<typeof f.store.transaction<T>>[0]) =>
        f.store.transaction((repos) => fn({ ...repos, cars: { ...repos.cars, lockOwn: async (id: string) => repos.cars.lockOwn(id, f.car(id)?.ownerId ?? '0') } })),
    };
    const svc = createMemberCarService({ store: leaky });
    for (const actor of [A, ADMIN]) {
      await assert.rejects(svc.getOwn(actor, theirs.id), isAuthz('not_found'));
      await assert.rejects(svc.update(actor, theirs.id, { version: 1, price: 1 }), isAuthz('not_found'));
      await assert.rejects(svc.remove(actor, theirs.id, { version: '1' }), isAuthz('not_found'));
      assert.deepEqual((await svc.listOwn(actor, {})).items, []);
    }
    assert.equal(f.car(theirs.id)!.version, 1);
  });

  it('the owner view is a whitelist: no owner id, reviewer, search text or deletion data', async () => {
    const { svc } = setup();
    const car = await svc.create(A, VALID);
    assert.deepEqual(Object.keys(car).sort(), [
      'brand', 'color', 'createdAt', 'currency', 'description', 'fuelType', 'id', 'latitude', 'location', 'longitude', 'mileage', 'model', 'phone', 'price',
      'rejectionReason', 'status', 'suspensionReason', 'transmission', 'updatedAt', 'version', 'whatsapp', 'year',
    ]);
  });
});

describe('member cars: update with optimistic versioning', () => {
  it('updates only the given fields, bumps the version, refreshes the search text and audits the change', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, { ...VALID, color: 'أبيض' });
    const updated = await svc.update(A, car.id, { version: 1, price: 11000, model: 'Corolla' }, { requestId: 'req-u' });
    assert.equal(updated.price, 11000);
    assert.equal(updated.model, 'Corolla');
    assert.equal(updated.brand, 'Toyota');
    assert.equal(updated.color, 'أبيض');
    assert.equal(updated.version, 2);
    assert.equal(updated.status, 'pending', 'an edit never publishes');
    assert.equal(f.car(car.id)!.searchText, searchTextOf({ brand: 'Toyota', model: 'Corolla', year: 2015, color: 'أبيض', location: '' }));
    assert.deepEqual(f.audits().at(-1), { action: 'member_car.update', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: car.id, afterData: { version: 2, fields: 2 }, requestId: 'req-u' });
  });

  it('a stale version is 409 version_conflict and changes nothing', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    await svc.update(A, car.id, { version: 1, price: 2 });
    const audits = f.audits().length;
    await assert.rejects(svc.update(A, car.id, { version: 1, price: 3 }), isCarError('version_conflict'));
    assert.equal(f.car(car.id)!.price, '2');
    assert.equal(f.car(car.id)!.version, 2);
    assert.equal(f.audits().length, audits);
  });

  it('two concurrent updates from the same version: exactly one wins, the other is 409', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    const results = await Promise.allSettled([svc.update(A, car.id, { version: 1, price: 100 }), svc.update(A, car.id, { version: 1, price: 200 })]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    const rejected = results.find((r) => r.status === 'rejected') as PromiseRejectedResult;
    assert.ok(isCarError('version_conflict')(rejected.reason));
    assert.equal(f.car(car.id)!.version, 2);
    assert.equal(f.audits().filter((a) => a.action === 'member_car.update').length, 1);
  });

  it('if the row changed between the lock and the write, the compare-and-swap refuses it (409) and the transaction rolls back', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    f.faults.beforeUpdate = () => {
      f.car(car.id)!.version = 7; // a writer that bypassed the lock
    };
    await assert.rejects(svc.update(A, car.id, { version: 1, price: 999 }), isCarError('version_conflict'));
    assert.equal(f.car(car.id)!.price, '12000');
    assert.equal(f.audits().filter((a) => a.action === 'member_car.update').length, 0);
  });

  it('an audit failure rolls the update back', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    f.faults.failNextAudit = true;
    await assert.rejects(svc.update(A, car.id, { version: 1, price: 5 }));
    assert.equal(f.car(car.id)!.price, '12000');
    assert.equal(f.car(car.id)!.version, 1);
  });

  it('optional fields are cleared with null; required fields cannot be', async () => {
    const { svc } = setup();
    const car = await svc.create(A, { ...VALID, mileage: 1000, latitude: 33, longitude: 44 });
    const cleared = await svc.update(A, car.id, { version: 1, mileage: null, whatsapp: null, latitude: null, longitude: null });
    assert.equal(cleared.mileage, null);
    assert.equal(cleared.whatsapp, null);
    assert.equal(cleared.latitude, null);
    assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: 2, phone: null })), [{ field: 'phone', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: 2, latitude: 1, longitude: null })), [{ field: 'longitude', code: 'invalid_type' }]);
  });

  it('version is required and must be a positive integer; an update must change something', async () => {
    const { svc } = setup();
    const car = await svc.create(A, VALID);
    assert.deepEqual(await fieldsOf(svc.update(A, car.id, { price: 5 })), [{ field: 'version', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: '1', price: 5 })), [{ field: 'version', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: 0, price: 5 })), [{ field: 'version', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: 1 })), [{ field: 'body', code: 'required' }]);
  });

  it('owner, source, reviewer and deletion fields cannot be changed (unknown_field)', async () => {
    const { svc } = setup();
    const car = await svc.create(A, VALID);
    for (const key of ['ownerId', 'showroomId', 'sourceType', 'reviewedBy', 'rejectionReason', 'suspensionReason', 'deletedAt', 'id', 'createdAt']) {
      assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: 1, [key]: '2' })), [{ field: key, code: 'unknown_field' }], key);
    }
  });
});

describe('member cars: status (D1: no publishing)', () => {
  it('no status can publish: active, pending and the moderation states are refused as input', async () => {
    const { svc } = setup();
    const car = await svc.create(A, VALID);
    for (const status of ['active', 'pending', 'rejected', 'suspended', 'available', 'ACTIVE']) {
      assert.deepEqual(await fieldsOf(svc.update(A, car.id, { version: 1, status })), [{ field: 'status', code: 'invalid_format' }], status);
    }
  });

  it('the owner marks an ACTIVE ad as sold (audited as mark_sold); from any other state it is 409 invalid_state', async () => {
    const { f, svc } = setup();
    const active = f.addCar({ ownerId: A.id, status: 'active' });
    const sold = await svc.update(A, active.id, { version: 1, status: 'sold' });
    assert.equal(sold.status, 'sold');
    assert.equal(f.audits().at(-1)!.action, 'member_car.mark_sold');
    await assert.rejects(svc.update(A, active.id, { version: 2, status: 'sold' }), isCarError('invalid_state'));
    for (const status of ['pending', 'rejected', 'suspended']) {
      const c = f.addCar({ ownerId: A.id, status });
      await assert.rejects(svc.update(A, c.id, { version: 1, status: 'sold' }), isCarError('invalid_state'), status);
      assert.equal(f.car(c.id)!.status, status);
    }
  });

  it('editing an ad keeps its status (a rejected or suspended ad is not re-activated by an edit)', async () => {
    const { f, svc } = setup();
    const c = f.addCar({ ownerId: A.id, status: 'suspended', suspensionReason: 'مخالفة' });
    const edited = await svc.update(A, c.id, { version: 1, description: 'تم التصحيح' });
    assert.equal(edited.status, 'suspended');
    assert.equal(edited.suspensionReason, 'مخالفة');
  });
});

describe('member cars: soft delete', () => {
  it('soft-deletes with the current version: the row stays (deleted_at), favorites go, it is 404 afterwards, and it is audited', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    f.addFavorite(B.id, car.id);
    await svc.remove(A, car.id, { version: '1' }, { requestId: 'req-d' });
    const row = f.car(car.id)!;
    assert.ok(row.deletedAt instanceof Date, 'soft delete only');
    assert.equal(row.version, 2);
    assert.deepEqual(f.favorites(), []);
    await assert.rejects(svc.getOwn(A, car.id), isAuthz('not_found'));
    await assert.rejects(svc.update(A, car.id, { version: 2, price: 1 }), isAuthz('not_found'));
    await assert.rejects(svc.remove(A, car.id, { version: '2' }), isAuthz('not_found'));
    assert.equal((await svc.listOwn(A, {})).items.length, 0);
    assert.deepEqual(f.audits().at(-1), { action: 'member_car.delete', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: car.id, afterData: { version: 1 }, requestId: 'req-d' });
  });

  it('a stale version is 409 and the ad is not deleted', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    await svc.update(A, car.id, { version: 1, price: 2 });
    await assert.rejects(svc.remove(A, car.id, { version: '1' }), isCarError('version_conflict'));
    assert.equal(f.car(car.id)!.deletedAt, null);
  });

  it('an audit failure rolls the deletion back (favorites included)', async () => {
    const { f, svc } = setup();
    const car = await svc.create(A, VALID);
    f.addFavorite(B.id, car.id);
    f.faults.failNextAudit = true;
    await assert.rejects(svc.remove(A, car.id, { version: '1' }));
    assert.equal(f.car(car.id)!.deletedAt, null);
    assert.equal(f.favorites().length, 1);
  });

  it('the version is required in the query, as a canonical positive integer; nothing else is accepted', async () => {
    const { svc } = setup();
    const car = await svc.create(A, VALID);
    assert.deepEqual(await fieldsOf(svc.remove(A, car.id, {})), [{ field: 'version', code: 'required' }]);
    for (const v of ['0', '-1', '1.0', '01', 'x', '99999999999']) assert.deepEqual(await fieldsOf(svc.remove(A, car.id, { version: v })), [{ field: 'version', code: 'invalid_format' }], v);
    assert.deepEqual(await fieldsOf(svc.remove(A, car.id, { version: ['1'] })), [{ field: 'version', code: 'invalid_type' }]);
    assert.deepEqual(await fieldsOf(svc.remove(A, car.id, { version: '1', hard: 'true' })), [{ field: 'hard', code: 'unknown_field' }]);
  });
});

describe('member cars: own list paging and filters', () => {
  it('pages by id descending with a cursor; nextBefore only after a full page', async () => {
    const { svc } = setup();
    const ids: string[] = [];
    for (let i = 0; i < 5; i++) ids.push((await svc.create(A, VALID)).id);
    const p1 = await svc.listOwn(A, { limit: '2' });
    assert.deepEqual(p1.items.map((c) => c.id), [ids[4], ids[3]]);
    const p2 = await svc.listOwn(A, { limit: '2', before: p1.nextBefore! });
    assert.deepEqual(p2.items.map((c) => c.id), [ids[2], ids[1]]);
    const p3 = await svc.listOwn(A, { limit: '2', before: p2.nextBefore! });
    assert.deepEqual(p3.items.map((c) => c.id), [ids[0]]);
    assert.equal(p3.nextBefore, null);
  });

  it('filters by status; query input is strict', async () => {
    const { f, svc } = setup();
    await svc.create(A, VALID);
    f.addCar({ ownerId: A.id, status: 'sold' });
    assert.deepEqual((await svc.listOwn(A, { status: 'sold' })).items.map((c) => c.status), ['sold']);
    assert.deepEqual(await fieldsOf(svc.listOwn(A, { status: 'deleted' })), [{ field: 'status', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(A, { ownerId: '2' })), [{ field: 'ownerId', code: 'unknown_field' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(A, { limit: String(MEMBER_CAR_LIMIT_MAX + 1) })), [{ field: 'limit', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(A, { before: '9223372036854775808' })), [{ field: 'before', code: 'invalid_format' }]);
    assert.deepEqual(await fieldsOf(svc.listOwn(A, { limit: ['5'] })), [{ field: 'limit', code: 'invalid_type' }]);
  });
});

// Phase 11.5, Step 5.5: images of a member's own car, through the real service and the real policy (src/authz), over an in-memory
// store that mirrors the SQL scoping and the database triggers (which THROW if the service lets a violation through).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { CarImageError, createCarImageService } from '../../src/car-images/service.ts';
import { makeFakeCarImageStore } from '../helpers/fake-car-images.ts';

const A: Actor = Object.freeze({ id: '1', role: 'member' });
const B: Actor = Object.freeze({ id: '2', role: 'member' });
const DEALER: Actor = Object.freeze({ id: '3', role: 'dealer' });
const ADMIN: Actor = Object.freeze({ id: '4', role: 'admin' });

function setup() {
  const f = makeFakeCarImageStore();
  for (const a of [A, B, DEALER, ADMIN]) f.addUser(a.id);
  const carA = f.addCar({ ownerId: A.id });
  const carA2 = f.addCar({ ownerId: A.id });
  const carB = f.addCar({ ownerId: B.id });
  const svc = createCarImageService({ store: f.store });
  const asset = (owner = A.id) => f.addAsset({ ownerId: owner }).id;
  return { f, svc, carA, carA2, carB, asset };
}

const isAuthz = (code: string) => (e: unknown) => e instanceof AuthzError && e.code === code;
const isImgErr = (code: string) => (e: unknown) => e instanceof CarImageError && e.code === code;
type Fields = Array<{ field: string; code: string }>;
async function fieldsOf(p: Promise<unknown>): Promise<Fields> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof CarImageError && e.code === 'validation_failed', `expected validation_failed, got ${String(e)}`);
    return e.fields ?? [];
  }
  assert.fail('expected a validation error');
}

describe('car images: add', () => {
  it('attaches the caller\'s own ready asset to the caller\'s own car; the first image is main, the next ones follow', async () => {
    const { f, svc, carA, asset } = setup();
    const first = await svc.add(A, carA.id, { assetId: asset() }, { requestId: 'req-1' });
    const second = await svc.add(A, carA.id, { assetId: asset() });
    assert.deepEqual([first.sortOrder, first.isMain, second.sortOrder, second.isMain], [0, true, 1, false]);
    assert.equal(first.width, 1200);
    assert.deepEqual(f.imagesOf(carA.id).map((i) => i.id), [first.id, second.id]);
    assert.deepEqual(f.audits()[0], { action: 'member_car.image_add', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: carA.id, afterData: { imageId: Number(first.id), images: 1 }, requestId: 'req-1' });
  });

  it('a mixed-case asset id is accepted and normalized', async () => {
    const { svc, carA, asset } = setup();
    const id = asset();
    const img = await svc.add(A, carA.id, { assetId: id.toUpperCase() });
    assert.equal(img.assetId, id);
  });

  it('the response is a whitelist: no storage key, thumbnail key, checksum, owner or car id', async () => {
    const { svc, carA, asset } = setup();
    const img = await svc.add(A, carA.id, { assetId: asset() });
    assert.deepEqual(Object.keys(img).sort(), ['assetId', 'createdAt', 'height', 'id', 'isMain', 'sortOrder', 'width']);
  });

  it('unknown fields are refused: car, owner, position, main flag, keys, URLs can never be supplied', async () => {
    const { f, svc, carA, asset } = setup();
    for (const key of ['carId', 'car_id', 'ownerId', 'owner_id', 'userId', 'sortOrder', 'isMain', 'storageKey', 'url', 'status', 'kind', 'id']) {
      assert.deepEqual(await fieldsOf(svc.add(A, carA.id, { assetId: asset(), [key]: key === 'isMain' ? true : '2' })), [{ field: key, code: 'unknown_field' }], key);
    }
    assert.equal(f.images().length, 0);
  });

  it('assetId must be a canonical UUID', async () => {
    const { svc, carA } = setup();
    assert.deepEqual(await fieldsOf(svc.add(A, carA.id, {})), [{ field: 'assetId', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.add(A, carA.id, { assetId: null })), [{ field: 'assetId', code: 'required' }]);
    assert.deepEqual(await fieldsOf(svc.add(A, carA.id, { assetId: 5 })), [{ field: 'assetId', code: 'invalid_type' }]);
    for (const v of ['', '1', 'not-a-uuid', '00000000-0000-4000-8000-00000000000g', '00000000000040008000000000000001', "00000000-0000-4000-8000-000000000001'--"]) {
      assert.deepEqual(await fieldsOf(svc.add(A, carA.id, { assetId: v })), [{ field: 'assetId', code: 'invalid_format' }], v);
    }
    for (const body of [undefined, null, 'x', [], 5]) assert.deepEqual(await fieldsOf(svc.add(A, carA.id, body)), [{ field: 'body', code: 'invalid_type' }]);
  });

  it('errors never carry the submitted values, and an unsafe key is never echoed', async () => {
    const { svc, carA } = setup();
    const secret = 'SECRET-7731';
    const err = await svc.add(A, carA.id, { assetId: secret, [`<${secret}>`]: 1 }).catch((e: unknown) => e);
    assert.ok(err instanceof CarImageError);
    assert.ok(!JSON.stringify({ m: err.message, f: err.fields }).includes(secret));
  });

  it('invalid input never reaches the store', async () => {
    const { f, svc, carA } = setup();
    await fieldsOf(svc.add(A, carA.id, { assetId: 'x' }));
    assert.deepEqual(f.calls, []);
  });
});

describe('car images: ownership and non-disclosure (IDOR/BOLA)', () => {
  it('another member, a dealer, an administrator and a caller with no actor all get 404 on the car, and nothing changes', async () => {
    const { f, svc, carA, asset } = setup();
    const img = await svc.add(A, carA.id, { assetId: asset() });
    const before = JSON.stringify(f.images());
    const audits = f.audits().length;
    for (const other of [B, DEALER, ADMIN, null]) {
      await assert.rejects(svc.list(other, carA.id), isAuthz('not_found'));
      await assert.rejects(svc.add(other, carA.id, { assetId: asset(other?.id ?? A.id) }), isAuthz('not_found'));
      await assert.rejects(svc.remove(other, carA.id, img.id), isAuthz('not_found'));
    }
    assert.equal(JSON.stringify(f.images()), before);
    assert.equal(f.audits().length, audits);
  });

  it('a stranger\'s car, an unknown car, a deleted car, a showroom car and a malformed car id are the same 404', async () => {
    const { f, svc, carB, asset } = setup();
    const deleted = f.addCar({ ownerId: A.id, deleted: true });
    const showroom = f.addCar({ ownerId: A.id, sourceType: 'showroom' });
    const outcome = (carId: unknown) => svc.list(A, carId).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome('999999');
    assert.ok(reference.startsWith('not_found|'));
    for (const id of [carB.id, deleted.id, showroom.id]) assert.equal(await outcome(id), reference, id);
    f.calls.length = 0;
    for (const id of ['abc', '0', '-1', '1.5', '01', ' 1', '9223372036854775808', undefined, null, 1, {}, ['1']]) assert.equal(await outcome(id), reference, JSON.stringify(id));
    assert.deepEqual(f.calls, [], 'a malformed id never reaches the store');
    await assert.rejects(svc.add(A, deleted.id, { assetId: asset() }), isAuthz('not_found'));
    await assert.rejects(svc.add(A, showroom.id, { assetId: asset() }), isAuthz('not_found'));
  });

  it('CROSS-CAR: an image of another car is 404 even when the caller owns both cars, and is not deleted', async () => {
    const { f, svc, carA, carA2, asset } = setup();
    const onA = await svc.add(A, carA.id, { assetId: asset() });
    await svc.add(A, carA2.id, { assetId: asset() });
    await assert.rejects(svc.remove(A, carA2.id, onA.id), isAuthz('not_found'));
    assert.equal(f.imagesOf(carA.id).length, 1);
    assert.equal(f.imagesOf(carA2.id).length, 1);
  });

  it('CROSS-USER: an image id of someone else\'s car, given with the caller\'s own car, is 404 and not deleted', async () => {
    const { f, svc, carA, carB, asset } = setup();
    await svc.add(A, carA.id, { assetId: asset() });
    const theirs = await svc.add(B, carB.id, { assetId: asset(B.id) });
    await assert.rejects(svc.remove(A, carA.id, theirs.id), isAuthz('not_found'));
    await assert.rejects(svc.remove(A, carB.id, theirs.id), isAuthz('not_found'));
    assert.equal(f.imagesOf(carB.id).length, 1);
  });

  it('an unknown image id and a malformed image id are the same 404', async () => {
    const { f, svc, carA, asset } = setup();
    await svc.add(A, carA.id, { assetId: asset() });
    const outcome = (id: unknown) => svc.remove(A, carA.id, id).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? e.code : 'other'));
    for (const id of ['999999', 'abc', '0', '1.5', undefined, null, 5, ['1']]) assert.equal(await outcome(id), 'not_found', JSON.stringify(id));
    assert.equal(f.images().length, 1);
  });

  it('ASSET OWNERSHIP: another user\'s asset is the same 404 as an unknown asset, and is not attached', async () => {
    const { f, svc, carA, asset } = setup();
    const foreign = asset(B.id);
    const adminAsset = asset(ADMIN.id); // the database trigger would allow an admin-owned asset; the service is stricter
    const outcome = (assetId: string) => svc.add(A, carA.id, { assetId }).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome('00000000-0000-4000-8000-0000000fffff');
    assert.ok(reference.startsWith('not_found|'));
    assert.equal(await outcome(foreign), reference);
    assert.equal(await outcome(adminAsset), reference);
    assert.equal(f.images().length, 0);
  });

  it('an owner suspended after authentication cannot add or delete (re-checked inside the transaction)', async () => {
    const { f, svc, carA, asset } = setup();
    const img = await svc.add(A, carA.id, { assetId: asset() });
    f.setUser(A.id, 'suspended');
    await assert.rejects(svc.add(A, carA.id, { assetId: asset() }), isAuthz('not_found'));
    await assert.rejects(svc.remove(A, carA.id, img.id), isAuthz('not_found'));
    assert.equal(f.imagesOf(carA.id).length, 1);
  });

  it('defense in depth: if the SQL scoping were broken, the service still refuses another user\'s car', async () => {
    const { f, carB, asset } = setup();
    const leaky = {
      ...f.store,
      images: { ...f.store.images, findOwnCar: async (id: string) => f.store.images.findOwnCar(id, carB.ownerId) },
      transaction: <T,>(fn: Parameters<typeof f.store.transaction<T>>[0]) =>
        f.store.transaction((repos) => fn({ ...repos, images: { ...repos.images, lockOwnCar: async (id: string) => repos.images.lockOwnCar(id, carB.ownerId) } })),
    };
    const svc = createCarImageService({ store: leaky });
    await assert.rejects(svc.list(A, carB.id), isAuthz('not_found'));
    await assert.rejects(svc.add(A, carB.id, { assetId: asset() }), isAuthz('not_found'));
    assert.equal(f.images().length, 0);
  });
});

describe('car images: stale reads and malformed image ids', () => {
  it('an asset attached by a concurrent request after it was read as free is 409 invalid_state (unique backstop), nothing changes', async () => {
    const { f, carA, carA2, asset } = setup();
    const id = asset();
    f.attach(carA2.id, id);
    const stale = {
      ...f.store,
      transaction: <T,>(fn: Parameters<typeof f.store.transaction<T>>[0]) =>
        f.store.transaction((repos) => fn({ ...repos, images: { ...repos.images, findOwnAsset: async (assetId: string, ownerId: string) => {
          const a = await repos.images.findOwnAsset(assetId, ownerId);
          return a ? { ...a, attachedCarId: null } : a;
        } } })),
    };
    const svc = createCarImageService({ store: stale });
    await assert.rejects(svc.add(A, carA.id, { assetId: id }), isImgErr('invalid_state'));
    assert.equal(f.imagesOf(carA.id).length, 0);
    assert.equal(f.imagesOf(carA2.id).length, 1);
  });

  it('a malformed image id is the same 404 and never reaches the store', async () => {
    const { f, svc, carA } = setup();
    const real = await svc.add(A, carA.id, { assetId: f.addAsset({ ownerId: A.id }).id });
    const outcome = (imageId: unknown) => svc.remove(A, carA.id, imageId).then(() => 'ok', (e: unknown) => (e instanceof AuthzError ? `${e.code}|${e.message}` : 'other'));
    const reference = await outcome('999999');
    assert.ok(reference.startsWith('not_found|'));
    f.calls.length = 0;
    for (const id of ['abc', '0', '-1', '1.5', '01', ' 1', '9223372036854775808', '1;DROP', undefined, null, 1, {}, [real.id]]) assert.equal(await outcome(id), reference, JSON.stringify(id));
    assert.deepEqual(f.calls, []);
    assert.equal(f.imagesOf(carA.id).length, 1);
  });

  it('defense in depth: neither the ownership re-check nor the policy alone lets a stranger\'s car through, and both together are required', async () => {
    const { f, carB, asset } = setup();
    const leaky = {
      ...f.store,
      transaction: <T,>(fn: Parameters<typeof f.store.transaction<T>>[0]) =>
        f.store.transaction((repos) => fn({ ...repos, images: { ...repos.images, lockOwnCar: async (id: string) => repos.images.lockOwnCar(id, carB.ownerId) } })),
    };
    const svc = createCarImageService({ store: leaky });
    for (let i = 0; i < 2; i++) await assert.rejects(svc.add(A, carB.id, { assetId: asset() }), isAuthz('not_found'));
    assert.equal(f.images().length, 0);
  });
});

describe('car images: asset state', () => {
  it('only a READY car_image asset can be attached (pending, rejected, showroom_cover: 409 invalid_state)', async () => {
    const { f, svc, carA } = setup();
    for (const fields of [{ status: 'pending' }, { status: 'rejected' }, { kind: 'showroom_cover' }]) {
      const a = f.addAsset({ ownerId: A.id, ...fields });
      await assert.rejects(svc.add(A, carA.id, { assetId: a.id }), isImgErr('invalid_state'), JSON.stringify(fields));
    }
    assert.equal(f.images().length, 0);
  });

  it('an asset already attached (to this car or to another of the caller\'s) is 409 and stays where it is', async () => {
    const { f, svc, carA, carA2, asset } = setup();
    const id = asset();
    await svc.add(A, carA.id, { assetId: id });
    await assert.rejects(svc.add(A, carA.id, { assetId: id }), isImgErr('invalid_state'));
    await assert.rejects(svc.add(A, carA2.id, { assetId: id }), isImgErr('invalid_state'));
    assert.equal(f.imagesOf(carA.id).length, 1);
    assert.equal(f.imagesOf(carA2.id).length, 0);
  });

  it('two requests racing for the SAME asset: exactly one wins', async () => {
    const { f, svc, carA, carA2, asset } = setup();
    const id = asset();
    const results = await Promise.allSettled([svc.add(A, carA.id, { assetId: id }), svc.add(A, carA2.id, { assetId: id })]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.ok(isImgErr('invalid_state')((results.find((r) => r.status === 'rejected') as PromiseRejectedResult).reason));
    assert.equal(f.images().length, 1);
  });
});

describe('car images: limit', () => {
  it('the member cap (4) is enforced: the fifth image is 409 image_limit and nothing changes', async () => {
    const { f, svc, carA, asset } = setup();
    for (let i = 0; i < 4; i++) await svc.add(A, carA.id, { assetId: asset() });
    const audits = f.audits().length;
    await assert.rejects(svc.add(A, carA.id, { assetId: asset() }), isImgErr('image_limit'));
    assert.equal(f.imagesOf(carA.id).length, 4);
    assert.equal(f.audits().length, audits);
  });

  it('the cap is per car and read from the settings', async () => {
    const { f, svc, carA, carA2, asset } = setup();
    for (let i = 0; i < 4; i++) await svc.add(A, carA.id, { assetId: asset() });
    await svc.add(A, carA2.id, { assetId: asset() });
    f.setCap(1);
    await assert.rejects(svc.add(A, carA2.id, { assetId: asset() }), isImgErr('image_limit'));
    assert.equal((await svc.list(A, carA.id)).maxImages, 1);
  });

  it('seven concurrent adds on one car: exactly 4 succeed, no more, and one main image', async () => {
    const { f, svc, carA, asset } = setup();
    const results = await Promise.allSettled(Array.from({ length: 7 }, () => svc.add(A, carA.id, { assetId: asset() })));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 4);
    assert.ok(results.filter((r) => r.status === 'rejected').every((r) => isImgErr('image_limit')((r as PromiseRejectedResult).reason)));
    assert.equal(f.imagesOf(carA.id).length, 4);
    assert.equal(f.imagesOf(carA.id).filter((i) => i.isMain).length, 1);
  });

  it('a deleted image frees a slot', async () => {
    const { svc, carA, asset } = setup();
    const imgs = [];
    for (let i = 0; i < 4; i++) imgs.push(await svc.add(A, carA.id, { assetId: asset() }));
    await svc.remove(A, carA.id, imgs[3]!.id);
    assert.ok(await svc.add(A, carA.id, { assetId: asset() }));
  });
});

describe('car images: list', () => {
  it('returns the car\'s images in order with the limit, for the owner only', async () => {
    const { svc, carA, carB, asset } = setup();
    const a = await svc.add(A, carA.id, { assetId: asset() });
    const b = await svc.add(A, carA.id, { assetId: asset() });
    const list = await svc.list(A, carA.id);
    assert.deepEqual(list.images.map((i) => i.id), [a.id, b.id]);
    assert.equal(list.maxImages, 4);
    await assert.rejects(svc.list(A, carB.id), isAuthz('not_found'));
  });
});

describe('car images: delete', () => {
  it('removes the link only: the asset stays, owned by the caller and free to attach again', async () => {
    const { f, svc, carA, asset } = setup();
    const id = asset();
    const img = await svc.add(A, carA.id, { assetId: id });
    await svc.remove(A, carA.id, img.id, { requestId: 'req-d' });
    assert.equal(f.images().length, 0);
    assert.equal(f.assets().length, 1, 'the asset row is kept for the cleanup job (its stored files are not touched here)');
    assert.deepEqual(f.audits().at(-1), { action: 'member_car.image_delete', actorUserId: '1', actorRole: 'user', entityType: 'car', entityId: carA.id, afterData: { imageId: Number(img.id), images: 0 }, requestId: 'req-d' });
    assert.ok(await svc.add(A, carA.id, { assetId: id }), 're-attachable');
    await assert.rejects(svc.remove(A, carA.id, img.id), isAuthz('not_found'));
  });

  it('deleting the MAIN image promotes the first remaining one and keeps positions contiguous', async () => {
    const { f, svc, carA, asset } = setup();
    const [i0, i1, i2] = [await svc.add(A, carA.id, { assetId: asset() }), await svc.add(A, carA.id, { assetId: asset() }), await svc.add(A, carA.id, { assetId: asset() })];
    await svc.remove(A, carA.id, i0.id);
    const left = f.imagesOf(carA.id);
    assert.deepEqual(left.map((i) => [i.id, i.sortOrder, i.isMain]), [[i1.id, 0, true], [i2.id, 1, false]]);
  });

  it('deleting a middle image renumbers and keeps the main image', async () => {
    const { f, svc, carA, asset } = setup();
    const [i0, i1, i2] = [await svc.add(A, carA.id, { assetId: asset() }), await svc.add(A, carA.id, { assetId: asset() }), await svc.add(A, carA.id, { assetId: asset() })];
    await svc.remove(A, carA.id, i1.id);
    assert.deepEqual(f.imagesOf(carA.id).map((i) => [i.id, i.sortOrder, i.isMain]), [[i0.id, 0, true], [i2.id, 1, false]]);
  });

  it('deleting the last image leaves a car with no images', async () => {
    const { f, svc, carA, asset } = setup();
    const img = await svc.add(A, carA.id, { assetId: asset() });
    await svc.remove(A, carA.id, img.id);
    assert.deepEqual(f.imagesOf(carA.id), []);
  });

  it('an audit failure rolls the deletion back (and the same for an add)', async () => {
    const { f, svc, carA, asset } = setup();
    const img = await svc.add(A, carA.id, { assetId: asset() });
    f.faults.failNextAudit = true;
    await assert.rejects(svc.remove(A, carA.id, img.id));
    assert.equal(f.imagesOf(carA.id).length, 1);
    f.faults.failNextAudit = true;
    await assert.rejects(svc.add(A, carA.id, { assetId: asset() }));
    assert.equal(f.imagesOf(carA.id).length, 1);
  });

  it('two concurrent deletes of the same image: one succeeds, the other is 404', async () => {
    const { f, svc, carA, asset } = setup();
    const img = await svc.add(A, carA.id, { assetId: asset() });
    await svc.add(A, carA.id, { assetId: asset() });
    const results = await Promise.allSettled([svc.remove(A, carA.id, img.id), svc.remove(A, carA.id, img.id)]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.ok(isAuthz('not_found')((results.find((r) => r.status === 'rejected') as PromiseRejectedResult).reason));
    assert.deepEqual(f.imagesOf(carA.id).map((i) => [i.sortOrder, i.isMain]), [[0, true]]);
  });
});

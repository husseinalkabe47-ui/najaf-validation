import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeIraqiPhone } from '../../src/auth/phone.ts';
import { NAME_MAX, PASSWORD_MAX } from '../../src/auth/policy.ts';
import { parseLoginInput, parseRegisterInput } from '../../src/auth/validation.ts';
import type { FieldError } from '../../src/auth/validation.ts';

const good = { name: 'علي حسين', phone: '07701234567', password: 'secret1' };
const errorsOf = (r: ReturnType<typeof parseRegisterInput>): FieldError[] => (r.ok ? [] : r.errors);
const has = (errors: FieldError[], field: string, code: string) => errors.some((e) => e.field === field && e.code === code);

describe('phone normalization (same accepted formats as the prototype, canonical E.164 out)', () => {
  const E164 = '+9647701234567';
  it('accepts every supported format', () => {
    for (const input of ['07701234567', '+9647701234567', '009647701234567', '9647701234567', '0770 123 4567', '0770-123-4567', '(0770) 123-4567', ' 07701234567 ', '+964 770 123 4567']) {
      assert.equal(normalizeIraqiPhone(input), E164, input);
    }
  });

  it('accepts Arabic-Indic and Persian digits', () => {
    assert.equal(normalizeIraqiPhone('٠٧٧٠١٢٣٤٥٦٧'), E164);
    assert.equal(normalizeIraqiPhone('۰۷۷۰۱۲۳۴۵۶۷'), E164);
    assert.equal(normalizeIraqiPhone('+٩٦٤٧٧٠١٢٣٤٥٦٧'), E164);
  });

  it('rejects everything else', () => {
    const bad = ['', ' ', '0770123456', '077012345678', '+9646701234567', '+96407701234567', '7701234567', '0770123456a', '+1 202 555 0100', '07701234567; DROP TABLE users', 'x'.repeat(100), '+964770123456789'];
    for (const input of bad) assert.equal(normalizeIraqiPhone(input), null, input);
  });

  it('076x/075x/078x/079x style numbers are valid, exactly as in the prototype (/^07\\d{9}$/) and in the database domain', () => {
    for (const input of ['07601234567', '07501234567', '07801234567', '07901234567']) assert.equal(normalizeIraqiPhone(input), '+964' + input.slice(1));
  });

  it('the result always satisfies the database domain e164_iq (^\\+9647[0-9]{9}$)', () => {
    for (const input of ['07701234567', '009647911112222', '٠٧٥١٢٣٤٥٦٧٨']) {
      const out = normalizeIraqiPhone(input);
      assert.ok(out === null || /^\+9647[0-9]{9}$/.test(out), input);
    }
  });
});

describe('register input validation', () => {
  it('accepts a valid body and canonicalizes name and phone; the password is untouched', () => {
    const r = parseRegisterInput({ name: '  علي حسين  ', phone: '+964 770 123 4567', password: '  keep spaces  ' });
    assert.deepEqual(r, { ok: true, value: { name: 'علي حسين', phone: '+9647701234567', password: '  keep spaces  ' } });
  });

  it('rejects non-objects', () => {
    for (const body of [null, undefined, 5, 'x', true, [], [good]]) assert.deepEqual(errorsOf(parseRegisterInput(body)), [{ field: 'body', code: 'invalid_type' }]);
  });

  it('rejects unknown fields strictly: the client can never choose role, status or id', () => {
    for (const extra of ['role', 'status', 'id', 'passwordHash', 'isAdmin', 'accountType']) {
      assert.ok(has(errorsOf(parseRegisterInput({ ...good, [extra]: 'admin' })), extra, 'unknown_field'), extra);
    }
  });

  it('reports a missing field as required, a wrong type as invalid_type', () => {
    assert.ok(has(errorsOf(parseRegisterInput({ phone: good.phone, password: good.password })), 'name', 'required'));
    assert.ok(has(errorsOf(parseRegisterInput({ name: good.name, password: good.password })), 'phone', 'required'));
    assert.ok(has(errorsOf(parseRegisterInput({ name: good.name, phone: good.phone })), 'password', 'required'));
    for (const f of ['name', 'phone', 'password'] as const) assert.ok(has(errorsOf(parseRegisterInput({ ...good, [f]: 12345 })), f, 'invalid_type'), f);
    for (const f of ['name', 'phone', 'password'] as const) assert.ok(has(errorsOf(parseRegisterInput({ ...good, [f]: { a: 1 } })), f, 'invalid_type'), f);
  });

  it('enforces name bounds in code points (3..100) and rejects control characters', () => {
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, name: 'ab' })), 'name', 'too_short'));
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, name: '   ' })), 'name', 'required'));
    assert.equal(parseRegisterInput({ ...good, name: 'abc' }).ok, true);
    assert.equal(parseRegisterInput({ ...good, name: 'ع'.repeat(NAME_MAX) }).ok, true);
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, name: 'ع'.repeat(NAME_MAX + 1) })), 'name', 'too_long'));
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, name: 'Ali\u0000Hassan' })), 'name', 'invalid_format'));
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, name: 'Ali\nHassan' })), 'name', 'invalid_format'));
  });

  it('enforces phone format', () => {
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, phone: '12345' })), 'phone', 'invalid_format'));
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, phone: '' })), 'phone', 'required'));
  });

  it('enforces password bounds (min 6 for new passwords, max 128) and rejects NUL', () => {
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, password: '12345' })), 'password', 'too_short'));
    assert.equal(parseRegisterInput({ ...good, password: '123456' }).ok, true);
    assert.equal(parseRegisterInput({ ...good, password: 'x'.repeat(PASSWORD_MAX) }).ok, true);
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, password: 'x'.repeat(PASSWORD_MAX + 1) })), 'password', 'too_long'));
    assert.ok(has(errorsOf(parseRegisterInput({ ...good, password: 'abc\u0000def' })), 'password', 'invalid_format'));
  });

  it('reports every problem at once, capped', () => {
    const errors = errorsOf(parseRegisterInput({ name: 1, phone: 2, password: 3, a: 1, b: 2 }));
    assert.equal(errors.length, 5);
    const many = Object.fromEntries(Array.from({ length: 40 }, (_, i) => [`f${i}`, i]));
    assert.ok(errorsOf(parseRegisterInput(many)).length <= 10);
  });

  it('never echoes submitted values in its errors', () => {
    const secret = 'SuperSecretPassw0rd!';
    const text = JSON.stringify(parseRegisterInput({ name: 'ab', phone: 'bad-phone-value', password: secret, [`weird key ${secret}`]: 1 }));
    assert.ok(!text.includes(secret) && !text.includes('bad-phone-value') && !text.includes('weird key'));
    assert.ok(text.includes('"field":"unknown"'));
  });

  it('is not fooled by prototype tricks', () => {
    const polluted = JSON.parse('{"name":"Ali Hassan","phone":"07701234567","password":"secret1","__proto__":{"role":"admin"},"constructor":{"x":1}}');
    const r = parseRegisterInput(polluted);
    assert.equal(r.ok, false);
    assert.ok(Object.getPrototypeOf(parseRegisterInput(Object.create({ role: 'admin' }))) === Object.prototype || true);
    assert.equal(parseRegisterInput(Object.create({ name: 'x' })).ok, false);
  });
});

describe('login input validation', () => {
  it('accepts a valid body and normalizes the phone', () => {
    assert.deepEqual(parseLoginInput({ phone: '٠٧٧٠١٢٣٤٥٦٧٨', password: 'x' }), { ok: false, errors: [{ field: 'phone', code: 'invalid_format' }] });
    assert.deepEqual(parseLoginInput({ phone: '07701234567', password: 'p' }), { ok: true, value: { phone: '+9647701234567', password: 'p' } });
  });

  it('does not enforce the password minimum on login (it only bounds the size)', () => {
    assert.equal(parseLoginInput({ phone: '07701234567', password: 'a' }).ok, true);
    assert.equal(parseLoginInput({ phone: '07701234567', password: 'x'.repeat(PASSWORD_MAX + 1) }).ok, false);
  });

  it('is strict: unknown fields, non-objects, wrong types, NUL', () => {
    assert.ok(!parseLoginInput({ phone: '07701234567', password: 'p', name: 'x' }).ok);
    assert.ok(!parseLoginInput(null).ok);
    assert.ok(!parseLoginInput({ phone: 7701234567, password: 'p' }).ok);
    assert.ok(!parseLoginInput({ phone: '07701234567', password: ['p'] }).ok);
    assert.ok(!parseLoginInput({ phone: '07701234567', password: 'a\u0000b' }).ok);
    assert.ok(!parseLoginInput({ phone: '07701234567' }).ok);
    assert.ok(!parseLoginInput({ password: 'p' }).ok);
  });
});

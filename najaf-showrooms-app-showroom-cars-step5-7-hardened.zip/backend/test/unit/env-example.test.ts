import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { ENV_VARS, loadConfig } from '../../src/config.ts';

const root = join(import.meta.dirname, '..', '..');
const example = readFileSync(join(root, '.env.example'), 'utf8');

describe('.env.example documents the configuration exactly', () => {
  const documented = new Set([...example.matchAll(/^#?\s*([A-Z][A-Z0-9_]*)=/gm)].map((m) => m[1] as string));

  it('every variable the code reads is documented', () => {
    for (const v of ENV_VARS) assert.ok(documented.has(v), `${v} is not documented in .env.example`);
  });

  it('nothing undocumented-by-code is listed', () => {
    for (const v of documented) assert.ok((ENV_VARS as readonly string[]).includes(v), `${v} is in .env.example but not read by config.ts`);
  });

  it('the uncommented example values form a valid development configuration', () => {
    const env: Record<string, string> = {};
    for (const m of example.matchAll(/^([A-Z][A-Z0-9_]*)=(.*)$/gm)) env[m[1] as string] = (m[2] as string).trim();
    const c = loadConfig(env);
    assert.equal(c.env, 'development');
    assert.equal(c.db.user, 'najaf_app_login');
  });

  it('the example never uses the superuser and .env is git-ignored', () => {
    assert.ok(!/postgres:\/\/postgres:/.test(example));
    assert.ok(readFileSync(join(root, '.gitignore'), 'utf8').split('\n').includes('.env'));
  });
});

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAuthService } from '../../src/auth/service.ts';
import { ACCESS_TOKEN_TTL_SECONDS, REFRESH_TOKEN_TTL_SECONDS } from '../../src/auth/policy.ts';
import { hashSessionToken } from '../../src/auth/tokens.ts';
import { AuthError } from '../../src/auth/types.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const SECRET = 'refresh-test-access-secret-0123456789abcdef-QWE';
const PASSWORD = 'Corr3ct-Horse-Battery';
const reg = { name: 'علي حسين', phone: '07701234567', password: PASSWORD };
const DAY = 24 * 60 * 60;

function setup() {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  return { clock, db, log, auth };
}
const rt = (r: { session: { refreshToken: string } }) => ({ refreshToken: r.session.refreshToken });
async function failure(p: Promise<unknown>): Promise<AuthError> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
    return e;
  }
  throw new Error('expected a failure');
}
const shape = (e: AuthError) => JSON.stringify({ code: e.code, message: e.message, fields: e.fields });

describe('refresh: rotation', () => {
  it('exchanges a refresh token for a NEW pair; the new access token authenticates the same user', async () => {
    const { auth, clock } = setup();
    const a = await auth.register(reg);
    clock.advanceSeconds(600);
    const b = await auth.refresh(rt(a), { userAgent: 'Rotated/2.0' });
    assert.notEqual(b.session.refreshToken, a.session.refreshToken);
    assert.notEqual(b.session.accessToken, a.session.accessToken);
    assert.deepEqual(b.user, a.user);
    assert.deepEqual((await auth.authenticate(b.session.accessToken))?.user, a.user);
    assert.equal(new Date(b.session.accessExpiresAt).getTime() - clock.now(), ACCESS_TOKEN_TTL_SECONDS * 1000, 'a fresh 15-minute access token');
  });

  it('records the rotation in the database: same family, the old row revoked as "rotated" and linked to the new row', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const b = await auth.refresh(rt(a), { userAgent: 'Rotated/2.0' });
    const [oldRow, newRow] = db.sessions();
    assert.equal(db.sessions().length, 2);
    assert.equal(oldRow?.familyId, newRow?.familyId);
    assert.equal(oldRow?.revokedReason, 'rotated');
    assert.notEqual(oldRow?.revokedAt, null);
    assert.equal(oldRow?.replacedBy, newRow?.id);
    assert.equal(newRow?.revokedAt, null);
    assert.equal(newRow?.userAgent, 'Rotated/2.0');
    assert.ok(newRow?.tokenHash.equals(hashSessionToken(b.session.refreshToken)));
  });

  it('the refresh lifetime is ABSOLUTE: rotation never extends it', async () => {
    const { auth, clock } = setup();
    const a = await auth.register(reg);
    let latest = a;
    for (let day = 5; day <= 25; day += 5) {
      clock.advanceSeconds(5 * DAY);
      latest = await auth.refresh(rt(latest));
      assert.equal(latest.session.refreshExpiresAt, a.session.refreshExpiresAt, `after ${day} days the expiry is still the original one`);
    }
    assert.equal(new Date(a.session.refreshExpiresAt).getTime() - Date.UTC(2026, 0, 1), REFRESH_TOKEN_TTL_SECONDS * 1000);
  });

  it('after 30 days the refresh token no longer works, however recently it was rotated', async () => {
    const { auth, clock } = setup();
    const a = await auth.register(reg);
    clock.advanceSeconds(29 * DAY);
    const b = await auth.refresh(rt(a));
    clock.advanceSeconds(1 * DAY + 1);
    assert.equal((await failure(auth.refresh(rt(b)))).code, 'unauthorized');
    assert.equal(await auth.authenticate(b.session.accessToken), null);
  });

  it('a chain of rotations works, and every earlier token in the chain is dead', async () => {
    const { auth, db } = setup();
    const chain = [await auth.register(reg)];
    for (let i = 0; i < 6; i++) chain.push(await auth.refresh(rt(chain[i]!)));
    assert.equal(db.sessions().length, 7);
    assert.equal(db.sessions().filter((s) => s.revokedAt === null).length, 1, 'exactly one live row per login session');
    assert.deepEqual(db.sessions().map((s) => s.revokedReason), ['rotated', 'rotated', 'rotated', 'rotated', 'rotated', 'rotated', null]);
    assert.ok((await auth.authenticate(chain[6]!.session.accessToken))?.user);
  });

  it('an older ACCESS token keeps working until its own 15 minutes end (it names the login session, not a refresh token)', async () => {
    const { auth, clock } = setup();
    const a = await auth.register(reg);
    clock.advanceSeconds(60);
    await auth.refresh(rt(a));
    assert.ok(await auth.authenticate(a.session.accessToken));
    clock.advanceSeconds(ACCESS_TOKEN_TTL_SECONDS);
    assert.equal(await auth.authenticate(a.session.accessToken), null);
  });

  it('another login session of the same user is independent', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const b = await auth.login({ phone: reg.phone, password: PASSWORD });
    await auth.refresh(rt(a));
    assert.equal(new Set(db.sessions().map((s) => s.familyId)).size, 2);
    assert.ok(await auth.refresh(rt(b)));
  });

  it('only hashes are stored: neither the old nor the new refresh token, nor any access token', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const b = await auth.refresh(rt(a));
    for (const secret of [a.session.refreshToken, b.session.refreshToken, a.session.accessToken, b.session.accessToken, PASSWORD, SECRET]) assert.ok(!db.dump().includes(secret));
  });

  it('the result has the public shape only: no password, hash or counters', async () => {
    const { auth } = setup();
    const b = await auth.refresh(rt(await auth.register(reg)));
    const text = JSON.stringify(b);
    assert.ok(!text.includes(PASSWORD) && !text.includes('$argon2') && !/password|hash|failed|locked/i.test(text));
    assert.deepEqual(Object.keys(b.user).sort(), ['createdAt', 'id', 'name', 'phone', 'phoneVerified', 'role', 'status']);
  });
});

describe('refresh: reuse detection', () => {
  it('presenting an already-exchanged token fails and revokes the whole login session', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const b = await auth.refresh(rt(a)); // the legitimate client rotated
    const e = await failure(auth.refresh(rt(a))); // the thief presents the OLD token
    assert.equal(e.code, 'unauthorized');
    // the legitimate holder of the NEW token is cut off too: both tokens are suspect
    assert.equal((await failure(auth.refresh(rt(b)))).code, 'unauthorized');
    assert.equal(await auth.authenticate(b.session.accessToken), null, 'the access token dies at once, before its 15 minutes');
    assert.equal(await auth.authenticate(a.session.accessToken), null);
    assert.ok(db.sessions().every((s) => s.revokedAt !== null));
    assert.equal(db.sessions().filter((s) => s.revokedReason === 'reuse_detected').length, 1, 'the live row is marked reuse_detected');
    assert.equal(db.sessions().filter((s) => s.revokedReason === 'rotated').length, 1, 'history is preserved');
    assert.equal(db.sessions().length, 2, 'a detected reuse issues nothing');
  });

  it('detects reuse of ANY earlier token in a long chain, not only the previous one', async () => {
    const { auth, db } = setup();
    const chain = [await auth.register(reg)];
    for (let i = 0; i < 4; i++) chain.push(await auth.refresh(rt(chain[i]!)));
    await assert.rejects(auth.refresh(rt(chain[1]!)), (e: unknown) => e instanceof AuthError && e.code === 'unauthorized');
    assert.equal(await auth.authenticate(chain[4]!.session.accessToken), null);
    assert.ok(db.sessions().every((s) => s.revokedAt !== null));
  });

  it('is contained to that login session: the same user\'s other sessions survive', async () => {
    const { auth } = setup();
    const a = await auth.register(reg);
    const other = await auth.login({ phone: reg.phone, password: PASSWORD });
    await auth.refresh(rt(a));
    await auth.refresh(rt(a)).catch(() => undefined); // reuse in session A
    assert.ok(await auth.authenticate(other.session.accessToken), 'session B is untouched');
    assert.ok(await auth.refresh(rt(other)));
  });

  it('a second presentation of the stolen token after the revocation is just rejected', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    await auth.refresh(rt(a));
    await auth.refresh(rt(a)).catch(() => undefined);
    await auth.refresh(rt(a)).catch(() => undefined);
    assert.equal(db.sessions().filter((s) => s.revokedReason === 'reuse_detected').length, 1);
  });

  it('two concurrent refreshes of the same token: one rotation wins, the other is a reuse, and the session ends (strict, by design)', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const results = await Promise.allSettled([auth.refresh(rt(a)), auth.refresh(rt(a))]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(results.filter((r) => r.status === 'rejected').length, 1);
    const winner = results.find((r) => r.status === 'fulfilled') as PromiseFulfilledResult<Awaited<ReturnType<typeof auth.refresh>>>;
    assert.equal((await failure(auth.refresh(rt(winner.value)))).code, 'unauthorized', 'the winner is cut off as well');
    assert.ok(db.sessions().every((s) => s.revokedAt !== null));
  });

  it('logs a warning with the user id only (no token, no family, no secret)', async () => {
    const { auth, log } = setup();
    const a = await auth.register(reg);
    const b = await auth.refresh(rt(a));
    await auth.refresh(rt(a)).catch(() => undefined);
    const text = log.text();
    assert.ok(text.includes('auth.refresh.reuse_detected') && text.includes('auth.refresh.rotated'));
    for (const secret of [a.session.refreshToken, b.session.refreshToken, a.session.accessToken, b.session.accessToken, SECRET, PASSWORD, 'nsj_', '9647701234567']) assert.ok(!text.includes(secret), `log must not contain ${secret.slice(0, 12)}`);
  });
});

describe('refresh: invalid tokens, all with the same answer', () => {
  it('unknown, expired, logged out, reused, suspended and deleted-user tokens are the SAME error', async () => {
    const shapes: Record<string, string> = {};

    const unknown = setup();
    shapes['unknown'] = shape(await failure(unknown.auth.refresh({ refreshToken: 'nsj_' + 'Q'.repeat(43) })));

    const expired = setup();
    const e1 = await expired.auth.register(reg);
    expired.clock.advanceSeconds(31 * DAY);
    shapes['expired'] = shape(await failure(expired.auth.refresh(rt(e1))));

    const loggedOut = setup();
    const l1 = await loggedOut.auth.register(reg);
    await loggedOut.auth.logout(rt(l1));
    shapes['logged out'] = shape(await failure(loggedOut.auth.refresh(rt(l1))));

    const reused = setup();
    const r1 = await reused.auth.register(reg);
    await reused.auth.refresh(rt(r1));
    shapes['reused'] = shape(await failure(reused.auth.refresh(rt(r1))));

    const suspended = setup();
    const s1 = await suspended.auth.register(reg);
    suspended.db.setStatus(s1.user.id, 'suspended');
    shapes['suspended'] = shape(await failure(suspended.auth.refresh(rt(s1))));

    const deleted = setup();
    const d1 = await deleted.auth.register(reg);
    deleted.db.users()[0]!.deletedAt = new Date();
    shapes['deleted'] = shape(await failure(deleted.auth.refresh(rt(d1))));

    assert.equal(new Set(Object.values(shapes)).size, 1, JSON.stringify(shapes));
    assert.equal(JSON.parse(Object.values(shapes)[0] as string).code, 'unauthorized');
  });

  it('a pending (not yet approved) account cannot refresh either, and nothing is created', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    db.setStatus(a.user.id, 'pending');
    await assert.rejects(auth.refresh(rt(a)), (e: unknown) => e instanceof AuthError && e.code === 'unauthorized');
    assert.equal(db.sessions().length, 1);
  });

  it('a failed refresh that is NOT a reuse changes nothing (and does not revoke the session)', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    await auth.refresh({ refreshToken: 'nsj_' + 'Z'.repeat(43) }).catch(() => undefined);
    assert.equal(db.sessions().length, 1);
    assert.equal(db.sessions()[0]?.revokedAt, null);
    assert.ok(await auth.authenticate(a.session.accessToken));
  });

  it('malformed input is a validation failure with no database work: missing, wrong type, wrong shape, extra fields, an access token', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    for (const body of [undefined, null, 'x', [], {}, { refreshToken: '' }, { refreshToken: null }, { refreshToken: 5 }, { refreshToken: 'nsj_short' }, { refreshToken: 'x'.repeat(47) }, { refreshToken: a.session.accessToken }, { refreshToken: a.session.refreshToken, role: 'admin' }, { token: a.session.refreshToken }, { refreshToken: ['nsj_' + 'A'.repeat(43)] }]) {
      const e = await failure(auth.refresh(body));
      assert.equal(e.code, 'validation_failed', JSON.stringify(body)?.slice(0, 60));
    }
    assert.equal(db.counters.rotate, 0);
  });

  it('validation errors never echo the submitted token', async () => {
    const { auth } = setup();
    const e = await failure(auth.refresh({ refreshToken: 'nsj_this-is-a-secret-looking-but-too-short' }));
    assert.ok(!JSON.stringify({ m: e.message, f: e.fields }).includes('secret-looking'));
  });
});

describe('refresh and logout interplay', () => {
  it('after logout the refresh token is rejected as an ordinary invalid token, not as a reuse', async () => {
    const { auth, db, log } = setup();
    const a = await auth.register(reg);
    await auth.logout(rt(a));
    assert.equal((await failure(auth.refresh(rt(a)))).code, 'unauthorized');
    assert.equal(db.sessions().filter((s) => s.revokedReason === 'reuse_detected').length, 0);
    assert.ok(!log.text().includes('reuse_detected'));
  });

  it('logout of a rotated session revokes the live descendant', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const b = await auth.refresh(rt(a));
    await auth.logout(rt(b));
    assert.equal(db.sessions().find((s) => s.revokedReason === 'logout')?.tokenHash.equals(hashSessionToken(b.session.refreshToken)), true);
    assert.equal(await auth.authenticate(b.session.accessToken), null);
    assert.equal((await failure(auth.refresh(rt(b)))).code, 'unauthorized');
  });

  it('a suspension ends access immediately, and a later refresh fails', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    const b = await auth.refresh(rt(a));
    db.setStatus(a.user.id, 'suspended');
    assert.equal(await auth.authenticate(b.session.accessToken), null);
    assert.equal((await failure(auth.refresh(rt(b)))).code, 'unauthorized');
  });

  it('login after logout starts a brand-new login session (new family)', async () => {
    const { auth, db } = setup();
    const a = await auth.register(reg);
    await auth.logout(rt(a));
    const b = await auth.login({ phone: reg.phone, password: PASSWORD });
    assert.equal(new Set(db.sessions().map((s) => s.familyId)).size, 2);
    assert.ok(await auth.authenticate(b.session.accessToken));
    assert.equal(await auth.authenticate(a.session.accessToken), null);
  });
});

describe('the access-token secret', () => {
  it('a weak secret is refused when the service is created', () => {
    const { db } = setup();
    for (const secret of ['', 'short', 'x'.repeat(31)]) {
      assert.throws(() => createAuthService({ store: db.store, hasher: makeFakeHasher().hasher, accessTokenSecret: secret }), /at least 32 characters/);
    }
  });
  it('tokens signed with one secret are not accepted by a service using another', async () => {
    const { db, auth } = setup();
    const a = await auth.register(reg);
    const other = createAuthService({ store: db.store, hasher: makeFakeHasher().hasher, accessTokenSecret: 'another-secret-value-0123456789-abcdefghij', now: () => Date.UTC(2026, 0, 1) });
    assert.equal(await other.authenticate(a.session.accessToken), null);
    assert.ok(await other.refresh(rt(a)), 'refresh tokens do not depend on the signing secret');
  });
});

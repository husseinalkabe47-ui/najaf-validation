import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAuthService } from '../../src/auth/service.ts';
import { loadActor, toActor, isValidId } from '../../src/authz/index.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const ACCESS_SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';

function setup() {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: ACCESS_SECRET, logger: recordingLogger().logger, now: clock.now });
  return { db, auth };
}
async function registered(s: ReturnType<typeof setup>, phone: string) {
  const r = await s.auth.register({ name: 'علي حسين', phone, password: PW });
  return { id: r.user.id, token: r.session.accessToken };
}

describe('actor: identity comes only from the verified token and the current database state', () => {
  it('a valid token for an ordinary account yields a member actor with exactly {id, role}', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    const actor = await loadActor(s.auth, u.token);
    assert.deepEqual(actor, { id: u.id, role: 'member' });
    assert.ok(Object.isFrozen(actor));
  });

  it('no token, a malformed token and a forged token yield no actor', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    assert.equal(await loadActor(s.auth, undefined), null);
    assert.equal(await loadActor(s.auth, ''), null);
    assert.equal(await loadActor(s.auth, 'not-a-token'), null);
    const [h, p, sig] = u.token.split('.');
    assert.equal(await loadActor(s.auth, `${h}.${p}.${sig!.slice(0, -2)}AA`), null);
  });

  it('ROLE ESCALATION: the role is re-read from the database on every call, so the token cannot carry or keep a role', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    assert.equal((await loadActor(s.auth, u.token))?.role, 'member');
    s.db.users()[0]!.role = 'admin'; // promoted in the database: the SAME token now reflects it
    assert.equal((await loadActor(s.auth, u.token))?.role, 'admin');
    s.db.users()[0]!.role = 'user'; // demoted: the same token loses it at once
    assert.equal((await loadActor(s.auth, u.token))?.role, 'member');
  });

  it('the access token carries only sub and sid: no role, status or permission claim exists to be forged', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    const claims = JSON.parse(Buffer.from(u.token.split('.')[1]!, 'base64url').toString('utf8')) as Record<string, unknown>;
    for (const k of ['role', 'status', 'permissions', 'owner_id', 'showroom_id']) assert.equal(k in claims, false, k);
  });

  it('SUSPENDED: a suspended account is no actor, even with a still-unexpired access token', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    s.db.setStatus(u.id, 'suspended');
    assert.equal(await loadActor(s.auth, u.token), null);
    s.db.setStatus(u.id, 'active'); // reactivated: a revoked session does NOT come back
    assert.equal(await loadActor(s.auth, u.token), null);
  });

  it('DELETED: a soft-deleted account is no actor', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    s.db.users()[0]!.deletedAt = new Date();
    assert.equal(await loadActor(s.auth, u.token), null);
  });

  it('PENDING: a pending dealer has no dealer powers', async () => {
    const s = setup();
    const u = await registered(s, '07701234567');
    s.db.users()[0]!.role = 'dealer';
    s.db.users()[0]!.status = 'pending';
    assert.equal(await loadActor(s.auth, u.token), null);
  });

  it('a token of user A never yields user B (identity is the verified sub)', async () => {
    const s = setup();
    const a = await registered(s, '07701234567');
    const b = await registered(s, '07709876543');
    assert.equal((await loadActor(s.auth, a.token))?.id, a.id);
    assert.equal((await loadActor(s.auth, b.token))?.id, b.id);
    assert.notEqual(a.id, b.id);
  });
});

describe('toActor fails closed', () => {
  const ok = { id: '7', role: 'user', status: 'active' };
  it('accepts user→member, dealer, admin when active', () => {
    assert.equal(toActor(ok)?.role, 'member');
    assert.equal(toActor({ ...ok, role: 'dealer' })?.role, 'dealer');
    assert.equal(toActor({ ...ok, role: 'admin' })?.role, 'admin');
  });
  it('rejects every non-active, deleted, unknown-role or malformed-id source', () => {
    for (const bad of [
      null, undefined, 'x' as never,
      { ...ok, status: 'suspended' }, { ...ok, status: 'pending' }, { ...ok, status: 'ACTIVE' }, { ...ok, status: '' },
      { ...ok, deletedAt: new Date() }, { ...ok, deletedAt: '2026-01-01' }, { ...ok, deleted: true },
      { ...ok, role: 'superadmin' }, { ...ok, role: 'member' }, { ...ok, role: 'constructor' }, { ...ok, role: '__proto__' }, { ...ok, role: 'toString' }, { ...ok, role: 'Admin' },
      { ...ok, id: '' }, { ...ok, id: '0' }, { ...ok, id: '01' }, { ...ok, id: '-1' }, { ...ok, id: '1e3' }, { ...ok, id: ' 7' }, { ...ok, id: '7 ' }, { ...ok, id: '7;DROP' }, { ...ok, id: 7 as never },
    ]) assert.equal(toActor(bad as never), null, JSON.stringify(bad));
  });
  it('isValidId accepts only canonical positive bigint strings', () => {
    assert.equal(isValidId('1'), true);
    assert.equal(isValidId('9223372036854775807'), true);
    for (const v of ['', '0', '007', '-5', '1.5', 'abc', null, undefined, 5, {}, ['1']]) assert.equal(isValidId(v), false);
  });
});

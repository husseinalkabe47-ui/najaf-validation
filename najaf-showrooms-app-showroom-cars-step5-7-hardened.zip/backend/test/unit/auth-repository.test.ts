import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DbError } from '../../src/errors.ts';
import { LOGIN_LOCK_SECONDS, LOGIN_MAX_FAILURES, SESSION_TOUCH_INTERVAL_SECONDS, SESSION_TTL_SECONDS } from '../../src/auth/policy.ts';
import { createPgAuthStore, createPgSessionsRepository, createPgUsersRepository } from '../../src/auth/repository.ts';
import type { Db, QueryResultLike, Tx } from '../../src/db.ts';
import { pgError } from '../helpers/fake-pool.ts';

interface Call {
  text: string;
  values: readonly unknown[];
}
type Responder = (text: string, values: readonly unknown[]) => QueryResultLike<unknown> | Error;

function recordingTx(respond: Responder = () => ({ rows: [], rowCount: 0 })) {
  const calls: Call[] = [];
  const tx: Tx = {
    query: async <R>(text: string, values: readonly unknown[] = []) => {
      calls.push({ text, values });
      const r = respond(text, values);
      if (r instanceof Error) throw r;
      return r as QueryResultLike<R>;
    },
  };
  return { tx, calls };
}

const userSql = { id: '7', name: 'علي حسين', phone_e164: '+9647701234567', role: 'user', status: 'active', created_at: new Date('2026-01-02T03:04:05Z') };
const HASH = '$argon2id$v=19$m=19456,t=2,p=1$c2FsdA$aGFzaA';

describe('users repository: every statement is parameterized and minimal', () => {
  it('insert: values are bound parameters; role and status are not columns, so the database defaults apply', async () => {
    const { tx, calls } = recordingTx(() => ({ rows: [userSql], rowCount: 1 }));
    const row = await createPgUsersRepository(tx).insert({ name: 'علي حسين', phoneE164: '+9647701234567', passwordHash: HASH });
    const c = calls[0]!;
    assert.match(c.text, /INSERT INTO users \(name, phone_e164, password_hash\)\s+VALUES \(\$1, \$2, \$3\)/);
    assert.deepEqual(c.values, ['علي حسين', '+9647701234567', HASH]);
    assert.ok(!/\brole\b[^,]*=|\(.*\brole\b.*\)\s+VALUES/.test(c.text.split('RETURNING')[0] as string), 'role must not be inserted');
    assert.ok(!c.text.split('RETURNING')[0]!.includes('status'));
    assert.deepEqual(row, { id: '7', name: 'علي حسين', phoneE164: '+9647701234567', role: 'user', status: 'active', phoneVerifiedAt: null, createdAt: userSql.created_at });
    assert.ok(!c.text.includes(HASH) && !c.text.includes('9647701234567'));
  });

  it('insert: a unique violation reaches the caller as the classified DbError', async () => {
    const { tx } = recordingTx(() => pgError('23505', 'duplicate key', { constraint: 'users_phone_active_uq' }));
    await assert.rejects(createPgUsersRepository(tx).insert({ name: 'abc', phoneE164: '+9647701234567', passwordHash: HASH }).catch((e) => {
      throw e instanceof Error ? e : new Error('x');
    }), (e: unknown) => (e as { code?: string }).code === '23505' || e instanceof DbError);
  });

  it('findCredentialsByPhone: ignores soft-deleted users, binds the phone, returns the hash and the lock flag', async () => {
    const { tx, calls } = recordingTx(() => ({ rows: [{ ...userSql, password_hash: HASH, locked: true }], rowCount: 1 }));
    const cred = await createPgUsersRepository(tx).findCredentialsByPhone('+9647701234567');
    assert.match(calls[0]!.text, /WHERE phone_e164 = \$1 AND deleted_at IS NULL/);
    assert.match(calls[0]!.text, /locked_until > now\(\)/);
    assert.deepEqual(calls[0]!.values, ['+9647701234567']);
    assert.equal(cred?.passwordHash, HASH);
    assert.equal(cred?.locked, true);
  });

  it('findCredentialsByPhone: null when there is no such user, and locked is strictly boolean', async () => {
    const none = recordingTx();
    assert.equal(await createPgUsersRepository(none.tx).findCredentialsByPhone('+9647700000000'), null);
    const odd = recordingTx(() => ({ rows: [{ ...userSql, password_hash: HASH, locked: 'yes' }], rowCount: 1 }));
    assert.equal((await createPgUsersRepository(odd.tx).findCredentialsByPhone('+9647701234567'))?.locked, false);
  });

  it('recordFailedLogin: one atomic UPDATE with the policy numbers as parameters', async () => {
    const { tx, calls } = recordingTx();
    await createPgUsersRepository(tx).recordFailedLogin('7');
    assert.match(calls[0]!.text, /SET failed_logins = LEAST\(failed_logins \+ 1, 100\)/);
    assert.match(calls[0]!.text, /locked_until = CASE WHEN failed_logins \+ 1 >= \$2 THEN now\(\) \+ make_interval\(secs => \$3\)/);
    assert.deepEqual(calls[0]!.values, ['7', LOGIN_MAX_FAILURES, LOGIN_LOCK_SECONDS]);
    assert.equal(calls.length, 1, 'a read-then-write would lose concurrent failures');
  });

  it('recordSuccessfulLogin: resets the counter and the lock', async () => {
    const { tx, calls } = recordingTx();
    await createPgUsersRepository(tx).recordSuccessfulLogin('7');
    assert.match(calls[0]!.text, /SET failed_logins = 0, locked_until = NULL, last_login_at = now\(\) WHERE id = \$1/);
    assert.deepEqual(calls[0]!.values, ['7']);
  });

  it('uses only columns the application role may update (migrations 0012/0013)', async () => {
    const { tx, calls } = recordingTx();
    const repo = createPgUsersRepository(tx);
    await repo.recordFailedLogin('7');
    await repo.recordSuccessfulLogin('7');
    const allowed = new Set(['name', 'phone_e164', 'phone_verified_at', 'email', 'status', 'password_hash', 'password_changed_at', 'failed_logins', 'locked_until', 'last_login_at', 'deleted_at']);
    for (const c of calls) {
      // function calls such as make_interval(secs => $3) use named arguments, which are not column assignments
      const set = (/SET\s+([\s\S]*?)\s+WHERE/.exec(c.text)?.[1] ?? '').replace(/make_interval\([^)]*\)/g, 'make_interval()');
      for (const col of set.match(/\b([a-z_]+)\s*=/g) ?? []) assert.ok(allowed.has(col.replace(/\s*=/, '')), `${col} is not updatable by najaf_app`);
      assert.ok(!/\b(role|id|created_at|updated_at|version)\s*=/.test(set));
    }
  });
});

describe('sessions repository', () => {
  it('create: binds a 32-byte token hash, never the token; a new family; expiry from the database clock', async () => {
    const { tx, calls } = recordingTx(() => ({ rows: [{ id: 'sess-1', family_id: 'fam-1', expires_at: new Date('2026-02-01T00:00:00Z') }], rowCount: 1 }));
    const tokenHash = Buffer.alloc(32, 7);
    const out = await createPgSessionsRepository(tx).create({ userId: '7', tokenHash, userAgent: 'UA' });
    assert.match(calls[0]!.text, /INSERT INTO sessions \(user_id, family_id, token_hash, expires_at, user_agent\)/);
    assert.match(calls[0]!.text, /gen_random_uuid\(\)/);
    assert.match(calls[0]!.text, /now\(\) \+ make_interval\(secs => \$3\)/);
    assert.match(calls[0]!.text, /RETURNING id, family_id, expires_at/);
    assert.deepEqual(calls[0]!.values, ['7', tokenHash, SESSION_TTL_SECONDS, 'UA']);
    assert.ok(Buffer.isBuffer(calls[0]!.values[1]) && (calls[0]!.values[1] as Buffer).length === 32);
    assert.deepEqual(out, { sessionId: 'sess-1', familyId: 'fam-1', expiresAt: new Date('2026-02-01T00:00:00Z') });
  });

  it('findActiveByFamily: only the live session of that family and user, for an active non-deleted user; never password_hash', async () => {
    const { tx, calls } = recordingTx(() => ({ rows: [{ ...userSql, session_id: 's1', family_id: 'fam-1', last_used_at: new Date() }], rowCount: 1 }));
    const found = await createPgSessionsRepository(tx).findActiveByFamily('fam-1', '7');
    const sql = calls[0]!.text;
    for (const part of ['s.family_id = $1', 's.user_id = $2', 's.revoked_at IS NULL', 's.expires_at > now()', 'u.deleted_at IS NULL', "u.status = 'active'"]) assert.ok(sql.includes(part), part);
    assert.ok(!/password|hash_|failed_logins|locked_until/.test(sql.replace('s.token_hash', '')), 'no credential or counter column may be read');
    assert.deepEqual(calls[0]!.values, ['fam-1', '7']);
    assert.equal(found?.sessionId, 's1');
    assert.equal(found?.familyId, 'fam-1');
    assert.equal(found?.user.phoneE164, '+9647701234567');
  });

  it('findActiveByFamily: null when no row matches', async () => {
    const { tx } = recordingTx();
    assert.equal(await createPgSessionsRepository(tx).findActiveByFamily('fam', '7'), null);
  });

  it('revokeFamilyByTokenHash: ends the live session of the token\'s family with reason logout, and reports whether anything changed', async () => {
    const hit = recordingTx(() => ({ rows: [], rowCount: 1 }));
    assert.equal(await createPgSessionsRepository(hit.tx).revokeFamilyByTokenHash(Buffer.alloc(32, 1)), true);
    assert.match(hit.calls[0]!.text, /SET revoked_at = now\(\), revoked_reason = 'logout'/);
    assert.match(hit.calls[0]!.text, /WHERE revoked_at IS NULL AND family_id = \(SELECT family_id FROM sessions WHERE token_hash = \$1\)/);
    assert.deepEqual(hit.calls[0]!.values, [Buffer.alloc(32, 1)]);
    const miss = recordingTx(() => ({ rows: [], rowCount: 0 }));
    assert.equal(await createPgSessionsRepository(miss.tx).revokeFamilyByTokenHash(Buffer.alloc(32, 1)), false);
  });

  it('touch: throttled in SQL', async () => {
    const { tx, calls } = recordingTx();
    await createPgSessionsRepository(tx).touch('s1');
    assert.match(calls[0]!.text, /last_used_at < now\(\) - make_interval\(secs => \$2\)/);
    assert.deepEqual(calls[0]!.values, ['s1', SESSION_TOUCH_INTERVAL_SECONDS]);
  });
});

describe('sessions repository: rotate (refresh-token rotation and reuse detection)', () => {
  const presented = Buffer.alloc(32, 1);
  const fresh = Buffer.alloc(32, 2);
  const sessionRow = { id: 'old-id', family_id: 'fam-1', user_id: '7', revoked: false, revoked_reason: null, expired: false, status: 'active', deleted: false, name: 'علي حسين', phone_e164: '+9647701234567', role: 'user', created_at: new Date('2026-01-02T03:04:05Z') };
  const script = (row: Record<string, unknown> | null) =>
    recordingTx((text) => {
      if (text.includes('FOR UPDATE OF s')) return { rows: row ? [row] : [], rowCount: row ? 1 : 0 };
      if (text.includes('INSERT INTO sessions')) return { rows: [{ id: 'new-id', expires_at: new Date('2026-02-01T00:00:00Z') }], rowCount: 1 };
      return { rows: [], rowCount: 1 };
    });
  const rotate = (tx: Tx) => createPgSessionsRepository(tx).rotate({ presentedHash: presented, newHash: fresh, userAgent: 'UA' });

  it('rotates in three statements: lock the presented row, copy it into the SAME family with the SAME expiry, revoke the old row as "rotated"', async () => {
    const { tx, calls } = script(sessionRow);
    const out = await rotate(tx);
    assert.equal(calls.length, 3);
    const [lock, insert, revoke] = calls as [Call, Call, Call];
    assert.match(lock.text, /WHERE s\.token_hash = \$1\s+FOR UPDATE OF s/);
    assert.deepEqual(lock.values, [presented]);
    assert.match(insert.text, /INSERT INTO sessions \(user_id, family_id, token_hash, expires_at, user_agent\)\s+SELECT user_id, family_id, \$2::bytea, expires_at, \$3::text FROM sessions WHERE id = \$1/);
    assert.deepEqual(insert.values, ['old-id', fresh, 'UA']);
    assert.match(revoke.text, /SET revoked_at = now\(\), revoked_reason = 'rotated', replaced_by = \$2 WHERE id = \$1/);
    assert.deepEqual(revoke.values, ['old-id', 'new-id']);
    assert.deepEqual(out, {
      kind: 'rotated',
      user: { id: '7', name: 'علي حسين', phoneE164: '+9647701234567', role: 'user', status: 'active', phoneVerifiedAt: null, createdAt: sessionRow.created_at },
      session: { sessionId: 'new-id', familyId: 'fam-1', expiresAt: new Date('2026-02-01T00:00:00Z') },
    });
  });

  it('the new row inherits the expiry inside SQL: the refresh lifetime is absolute (no new lifetime parameter exists)', async () => {
    const { tx, calls } = script(sessionRow);
    await rotate(tx);
    assert.ok(!calls[1]!.text.includes('make_interval'));
    assert.ok(!calls[1]!.values.some((v) => typeof v === 'number'));
  });

  it('reuse of an already-rotated token: revokes every live row of the family as "reuse_detected" and issues nothing', async () => {
    const { tx, calls } = script({ ...sessionRow, revoked: true, revoked_reason: 'rotated' });
    const out = await rotate(tx);
    assert.deepEqual(out, { kind: 'reuse', userId: '7' });
    assert.equal(calls.length, 2, 'the lock, then the family revocation: no INSERT');
    assert.match(calls[1]!.text, /SET revoked_at = now\(\), revoked_reason = 'reuse_detected' WHERE family_id = \$1 AND revoked_at IS NULL/);
    assert.deepEqual(calls[1]!.values, ['fam-1']);
    assert.ok(!calls.some((c) => c.text.includes('INSERT')));
  });

  it('writes nothing for an unknown token', async () => {
    const { tx, calls } = script(null);
    assert.deepEqual(await rotate(tx), { kind: 'rejected' });
    assert.equal(calls.length, 1);
  });

  it('writes nothing for a token revoked for any reason other than rotation (logout, suspension, an earlier reuse...)', async () => {
    for (const reason of ['logout', 'logout_all', 'user_suspended', 'user_deleted', 'password_changed', 'admin_revoked', 'reuse_detected']) {
      const { tx, calls } = script({ ...sessionRow, revoked: true, revoked_reason: reason });
      assert.deepEqual(await rotate(tx), { kind: 'rejected' }, reason);
      assert.equal(calls.length, 1, reason);
    }
  });

  it('writes nothing for an expired session, a deleted user or an account that is not active', async () => {
    for (const patch of [{ expired: true }, { deleted: true }, { status: 'suspended' }, { status: 'pending' }]) {
      const { tx, calls } = script({ ...sessionRow, ...patch });
      assert.deepEqual(await rotate(tx), { kind: 'rejected' }, JSON.stringify(patch));
      assert.equal(calls.length, 1, JSON.stringify(patch));
    }
  });

  it('never reads credentials: the locking SELECT has no password_hash', async () => {
    const { tx, calls } = script(sessionRow);
    await rotate(tx);
    assert.ok(!calls.some((c) => /password|hash_/.test(c.text.replace(/token_hash/g, ''))));
  });

  it('propagates a database failure (the surrounding transaction rolls back)', async () => {
    const { tx } = recordingTx((text) => (text.includes('INSERT') ? pgError('40001', 'could not serialize') : { rows: [sessionRow], rowCount: 1 }));
    await assert.rejects(rotate(tx), (e: unknown) => (e as { code?: string }).code === '40001');
  });
});

describe('SQL injection and secrets: nothing a client sends is ever part of SQL text', () => {
  it('hostile values are bound parameters in every statement of a full flow', async () => {
    const evil = "'); DROP TABLE users; --";
    const { tx, calls } = recordingTx(() => ({ rows: [{ ...userSql, password_hash: HASH, locked: false, session_id: 's', family_id: 'f', last_used_at: new Date(), id: '7', user_id: '7', expires_at: new Date(), revoked: false, expired: false, deleted: false }], rowCount: 1 }));
    const users = createPgUsersRepository(tx);
    const sessions = createPgSessionsRepository(tx);
    await users.insert({ name: evil, phoneE164: evil, passwordHash: evil });
    await users.findCredentialsByPhone(evil);
    await users.recordFailedLogin(evil);
    await users.recordSuccessfulLogin(evil);
    await sessions.create({ userId: evil, tokenHash: Buffer.alloc(32), userAgent: evil });
    await sessions.findActiveByFamily(evil, evil);
    await sessions.rotate({ presentedHash: Buffer.alloc(32, 1), newHash: Buffer.alloc(32, 2), userAgent: evil });
    await sessions.revokeFamilyByTokenHash(Buffer.alloc(32, 3));
    await sessions.touch(evil);
    assert.ok(calls.length >= 11);
    for (const c of calls) {
      assert.ok(!c.text.includes('DROP TABLE') && !c.text.includes(evil), 'a value leaked into the SQL text');
      assert.match(c.text, /\$1/);
      assert.ok(!/\$\{|\+\s*'/.test(c.text));
    }
  });

  it('password_hash appears in exactly one read and one write of the whole module: the credentials lookup and the INSERT that stores it', async () => {
    const { tx, calls } = recordingTx(() => ({ rows: [{ ...userSql, password_hash: HASH, locked: false, session_id: 's', family_id: 'f', last_used_at: new Date(), id: 's', user_id: '7', expires_at: new Date(), revoked: false, expired: false, deleted: false }], rowCount: 1 }));
    const users = createPgUsersRepository(tx);
    const sessions = createPgSessionsRepository(tx);
    await users.insert({ name: 'abc', phoneE164: '+9647701234567', passwordHash: HASH });
    await users.findCredentialsByPhone('+9647701234567');
    await users.recordFailedLogin('7');
    await users.recordSuccessfulLogin('7');
    await sessions.create({ userId: '7', tokenHash: Buffer.alloc(32), userAgent: null });
    await sessions.findActiveByFamily('f', '7');
    await sessions.rotate({ presentedHash: Buffer.alloc(32, 1), newHash: Buffer.alloc(32, 2), userAgent: null });
    await sessions.revokeFamilyByTokenHash(Buffer.alloc(32));
    await sessions.touch('s');
    const touching = calls.filter((c) => c.text.includes('password_hash')).map((c) => c.text.trim().split(/\s+/).slice(0, 3).join(' '));
    assert.deepEqual(touching, ['INSERT INTO users', 'SELECT id, name,']);
  });
});

describe('auth store', () => {
  it('transaction() runs on db.tx and hands the repositories the TRANSACTION connection, not the pool', async () => {
    const pool = recordingTx();
    const inner = recordingTx();
    const db = { query: pool.tx.query, tx: async <T>(fn: (t: Tx) => Promise<T>) => fn(inner.tx) } as unknown as Db;
    const store = createPgAuthStore(db);
    await store.transaction(async ({ users, sessions }) => {
      await users.recordSuccessfulLogin('7');
      await sessions.touch('s');
    });
    assert.equal(inner.calls.length, 2);
    assert.equal(pool.calls.length, 0);
    await store.users.recordSuccessfulLogin('7');
    assert.equal(pool.calls.length, 1, 'non-transactional use goes through the pool');
  });
});

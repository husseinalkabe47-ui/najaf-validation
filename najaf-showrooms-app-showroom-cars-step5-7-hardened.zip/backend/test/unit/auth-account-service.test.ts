import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAccountService } from '../../src/auth/account-service.ts';
import { LOGIN_MAX_FAILURES, PASSWORD_MAX, PASSWORD_MIN } from '../../src/auth/policy.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthError } from '../../src/auth/types.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';

const ACCESS_SECRET = 'account-test-access-secret-0123456789abcdef-QWE';
const OLD = 'Old-Passw0rd-123';
const NEW = 'Brand-New-Passw0rd';
const reg = { name: 'علي حسين', phone: '07701234567', password: OLD };
const OTHER = { name: 'مستخدم آخر', phone: '07709999999', password: 'Other-Passw0rd-9' };

function setup() {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher, calls } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: ACCESS_SECRET, logger: log.logger, now: clock.now });
  const account = createAccountService({ store: db.store, hasher, logger: log.logger });
  return { clock, db, calls, log, auth, account };
}
type Env = ReturnType<typeof setup>;
const live = (env: Env, userId?: string) => env.db.sessions().filter((s) => s.revokedAt === null && (userId === undefined || s.userId === userId));
async function failure(p: Promise<unknown>): Promise<AuthError> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
    return e;
  }
  throw new Error('expected a failure');
}
const shape = (e: AuthError) => JSON.stringify({ code: e.code, message: e.message, fields: e.fields });
const refresh = (r: { session: { refreshToken: string } }) => ({ refreshToken: r.session.refreshToken });

/** a user with `n` independent logins (the first from registration) */
async function withSessions(env: Env, n = 3, creds = reg) {
  const first = await env.auth.register(creds);
  const all = [first];
  for (let i = 1; i < n; i++) all.push(await env.auth.login({ phone: creds.phone, password: creds.password }));
  return { userId: first.user.id, all };
}

describe('change password: success', () => {
  it('sets the new password: the new one signs in, the old one does not; the stored value is a hash and the plain text exists nowhere', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    assert.deepEqual(await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }), { status: 'password_changed' });
    assert.equal((await env.auth.login({ phone: reg.phone, password: NEW })).user.id, userId);
    assert.equal((await failure(env.auth.login({ phone: reg.phone, password: OLD }))).code, 'invalid_credentials');
    assert.ok(env.db.users()[0]!.passwordHash.startsWith('$argon2id$'));
    assert.ok(!env.db.dump().includes(NEW) && !env.db.dump().includes(OLD), 'neither password is stored');
  });

  it('ends EVERY session, including the one that made the request: access tokens at once, refresh tokens too', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 3);
    const rotated = await env.auth.refresh(refresh(all[1]!)); // a rotated chain as well
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW });
    for (const s of [...all, rotated]) {
      assert.equal(await env.auth.authenticate(s.session.accessToken), null, 'the access token died at once, not after 15 minutes');
    }
    for (const s of [all[0]!, all[2]!, rotated]) assert.equal((await failure(env.auth.refresh(refresh(s)))).code, 'unauthorized');
    assert.equal(live(env, userId).length, 0);
    assert.ok(env.db.sessions().filter((s) => s.revokedReason === 'password_changed').length >= 3);
    assert.equal(env.db.sessions().filter((s) => s.revokedReason === 'reuse_detected').length, 0, 'a refresh after a password change is just refused, not a reuse');
  });

  it('afterwards a new sign-in works and its session is alive', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 2);
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW });
    const fresh = await env.auth.login({ phone: reg.phone, password: NEW });
    assert.ok(await env.auth.authenticate(fresh.session.accessToken));
    assert.equal(live(env, userId).length, 1);
  });

  it('clears the failed-login counter and the lockout, and returns nothing but a status', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    for (let i = 0; i < 3; i++) await env.auth.login({ phone: reg.phone, password: 'wrong-' + i }).catch(() => undefined);
    assert.equal(env.db.users()[0]?.failedLogins, 3);
    const out = await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW });
    assert.equal(env.db.users()[0]?.failedLogins, 0);
    assert.deepEqual(Object.keys(out), ['status']);
    assert.deepEqual(out, { status: 'password_changed' });
    assert.ok(!JSON.stringify(out).includes(NEW) && !JSON.stringify(out).includes(OLD) && !/\$argon2|hash/i.test(JSON.stringify(out)));
  });

  it('accepts the policy minimum and maximum lengths', async () => {
    for (const pw of ['x'.repeat(PASSWORD_MIN), 'y'.repeat(PASSWORD_MAX)]) {
      const env = setup();
      const { userId } = await withSessions(env, 1);
      assert.deepEqual(await env.account.changePassword(userId, { currentPassword: OLD, newPassword: pw }), { status: 'password_changed' });
    }
  });

  it('does not touch the phone verification state or the account status', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    env.db.users()[0]!.phoneVerifiedAt = new Date(0);
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW });
    assert.equal(env.db.users()[0]?.phoneVerifiedAt?.getTime(), 0);
    assert.equal(env.db.users()[0]?.status, 'active');
  });
});

describe('change password: refused', () => {
  it('a wrong current password: nothing changes, the sessions stay, one failed login is counted, and no new hash is computed', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    const hashesBefore = env.calls.hash;
    const before = env.db.users()[0]!.passwordHash;
    const e = await failure(env.account.changePassword(userId, { currentPassword: 'definitely-wrong', newPassword: NEW }));
    assert.equal(e.code, 'invalid_current_password');
    assert.equal(env.db.users()[0]?.passwordHash, before);
    assert.equal(env.db.users()[0]?.failedLogins, 1);
    assert.equal(env.calls.hash, hashesBefore, 'a wrong password cannot be used to burn argon2 CPU');
    assert.equal(live(env, userId).length, 2);
    assert.ok(await env.auth.authenticate(all[0]!.session.accessToken), 'the session is untouched');
    assert.equal(env.db.audits().length, 0);
  });

  it('wrong attempts count toward the lockout: after 5, even the CORRECT current password is refused, and nothing changes', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    const before = env.db.users()[0]!.passwordHash;
    for (let i = 0; i < LOGIN_MAX_FAILURES; i++) assert.equal((await failure(env.account.changePassword(userId, { currentPassword: 'wrong-' + i, newPassword: NEW }))).code, 'invalid_current_password');
    assert.equal(env.db.users()[0]?.locked, true);
    const e = await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }));
    assert.equal(e.code, 'invalid_current_password');
    assert.equal(env.db.users()[0]?.passwordHash, before);
    assert.equal(env.db.users()[0]?.failedLogins, LOGIN_MAX_FAILURES, 'attempts during the lock are not counted');
    assert.equal(env.db.audits().length, 0);
    env.db.unlock(userId);
    assert.deepEqual(await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }), { status: 'password_changed' });
  });

  it('a locked account answers exactly like a wrong password (the lock is not revealed)', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    const wrong = await failure(env.account.changePassword(userId, { currentPassword: 'wrong', newPassword: NEW }));
    for (let i = 0; i < LOGIN_MAX_FAILURES; i++) await env.auth.login({ phone: reg.phone, password: 'x' + i }).catch(() => undefined);
    assert.equal(env.db.users()[0]?.locked, true);
    const locked = await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }));
    assert.equal(shape(wrong), shape(locked));
  });

  it('a weak new password is a validation failure that costs nothing: no check of the current password, no attempt, no hashing', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    const verifies = env.calls.verify;
    const hashes = env.calls.hash;
    for (const newPassword of ['', '12345', 'x'.repeat(PASSWORD_MAX + 1), 'ab\u0000cd12', 123456, null]) {
      const e = await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword }));
      assert.equal(e.code, 'validation_failed');
      assert.ok(e.fields?.some((f) => f.field === 'newPassword'), JSON.stringify(newPassword));
    }
    assert.equal(env.calls.verify, verifies);
    assert.equal(env.calls.hash, hashes);
    assert.equal(env.db.users()[0]?.failedLogins, 0);
    assert.equal(live(env, userId).length, 1);
  });

  it('the new password may not equal the current one, and nothing changes', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    const before = env.db.users()[0]!.passwordHash;
    const e = await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: OLD }));
    assert.equal(e.code, 'validation_failed');
    assert.deepEqual(e.fields, [{ field: 'newPassword', code: 'same_as_current' }]);
    assert.equal(env.db.users()[0]?.passwordHash, before);
    assert.equal(live(env, userId).length, 2);
    assert.ok(await env.auth.authenticate(all[1]!.session.accessToken));
    assert.equal(env.db.audits().length, 0);
  });

  it('"same as current" is only ever said to someone who proved the current password (a wrong one gets the generic refusal)', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    const e = await failure(env.account.changePassword(userId, { currentPassword: 'not-the-password', newPassword: 'not-the-password' }));
    assert.equal(e.code, 'invalid_current_password');
  });

  it('a one-character change is a different password', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    assert.deepEqual(await env.account.changePassword(userId, { currentPassword: OLD, newPassword: OLD + '1' }), { status: 'password_changed' });
  });

  it('malformed input is a validation failure that touches nothing, and a user id in the body is refused (the owner is the token)', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    const before = env.db.users()[0]!.passwordHash;
    for (const body of [null, undefined, 'x', [], {}, { newPassword: NEW }, { currentPassword: OLD }, { currentPassword: 5, newPassword: NEW }, { currentPassword: OLD, newPassword: NEW, userId: '999' }, { currentPassword: OLD, newPassword: NEW, user_id: '999' }, { currentPassword: OLD, newPassword: NEW, role: 'admin' }]) {
      assert.equal((await failure(env.account.changePassword(userId, body))).code, 'validation_failed', JSON.stringify(body));
    }
    assert.equal(env.db.users()[0]?.passwordHash, before);
    assert.equal(env.db.users()[0]?.failedLogins, 0);
  });

  it('an unknown or deleted user, and suspended or pending accounts, are refused as unauthorized even with the right password', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    assert.equal((await failure(env.account.changePassword('99999', { currentPassword: OLD, newPassword: NEW }))).code, 'unauthorized');
    const before = env.db.users()[0]!.passwordHash;
    for (const status of ['suspended', 'pending']) {
      env.db.setStatus(userId, status);
      assert.equal((await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }))).code, 'unauthorized', status);
    }
    env.db.setStatus(userId, 'active');
    env.db.users()[0]!.deletedAt = new Date();
    assert.equal((await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }))).code, 'unauthorized', 'deleted');
    assert.equal(env.db.users()[0]?.passwordHash, before);
    assert.equal(env.db.audits().length, 0);
  });
});

describe('change password: concurrency and atomicity', () => {
  it('two simultaneous changes that both proved the current password: exactly one applies (compare-and-swap), the other is refused and changes nothing', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 2);
    const results = await Promise.allSettled([
      env.account.changePassword(userId, { currentPassword: OLD, newPassword: 'First-Candidate-1' }),
      env.account.changePassword(userId, { currentPassword: OLD, newPassword: 'Second-Candidate-2' }),
    ]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    const loser = results.find((x) => x.status === 'rejected') as PromiseRejectedResult;
    assert.equal((loser.reason as AuthError).code, 'invalid_current_password');
    assert.equal(env.db.counters.passwordChanges, 1);
    assert.equal(env.db.audits().length, 1, 'the loser left no audit event');
    const winner = results[0]?.status === 'fulfilled' ? 'First-Candidate-1' : 'Second-Candidate-2';
    assert.ok(await env.auth.login({ phone: reg.phone, password: winner }));
    assert.equal((await failure(env.auth.login({ phone: reg.phone, password: winner === 'First-Candidate-1' ? 'Second-Candidate-2' : 'First-Candidate-1' }))).code, 'invalid_credentials');
  });

  it('the password change and its audit event are ONE unit: if the audit insert fails, nothing changed and the user can retry', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    const before = env.db.users()[0]!.passwordHash;
    env.db.faults.failNextAudit = true;
    await assert.rejects(env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }), /simulated audit insert failure/);
    assert.equal(env.db.users()[0]?.passwordHash, before, 'the password was not changed');
    assert.equal(live(env, userId).length, 2, 'the sessions were not revoked');
    assert.ok(await env.auth.authenticate(all[0]!.session.accessToken));
    assert.deepEqual(await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }), { status: 'password_changed' });
    assert.equal(env.db.audits().length, 1);
  });

  it('a refresh racing with a password change cannot keep a session alive, in either order', async () => {
    for (const order of ['refresh-first', 'change-first'] as const) {
      const env = setup();
      const { userId, all } = await withSessions(env, 1);
      const ops = [() => env.auth.refresh(refresh(all[0]!)), () => env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW })];
      if (order === 'change-first') ops.reverse();
      await Promise.allSettled(ops.map((f) => f()));
      assert.equal(live(env, userId).length, 0, order);
    }
  });
});

describe('change password: audit trail', () => {
  it('records exactly one event with the right actor, entity and request id, and only a count in the data', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 3);
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }, { requestId: 'req-abc-123' });
    assert.equal(env.db.audits().length, 1);
    const a = env.db.audits()[0]!;
    assert.equal(a.action, 'auth.password_changed');
    assert.equal(a.actorUserId, userId);
    assert.equal(a.actorRole, 'user');
    assert.equal(a.entityType, 'user');
    assert.equal(a.entityId, userId);
    assert.deepEqual(a.afterData, { sessions_revoked: 3 });
    assert.equal(a.requestId, 'req-abc-123');
  });

  it('contains no secret: no password, hash, token, code, phone number or name', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }, { requestId: 'req-1' });
    const text = JSON.stringify(env.db.audits());
    for (const secret of [OLD, NEW, '$argon2', 'nsj_', 'eyJ', ACCESS_SECRET, '9647701234567', '07701234567', 'علي', all[0]!.session.refreshToken, all[0]!.session.accessToken]) {
      assert.ok(!text.includes(secret), `the audit trail must not contain ${secret}`);
    }
  });

  it('wrong attempts and refusals write NO audit event (only completed changes are events)', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    await env.account.changePassword(userId, { currentPassword: 'wrong', newPassword: NEW }).catch(() => undefined);
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: OLD }).catch(() => undefined);
    await env.account.changePassword(userId, { currentPassword: OLD, newPassword: '1' }).catch(() => undefined);
    assert.equal(env.db.audits().length, 0);
  });

  it('the audit data guard refuses anything that is not a plain number under a harmless key', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    await env.db.store.transaction(async ({ audit }) => {
      const base = { action: 'auth.password_changed' as const, actorUserId: userId, actorRole: 'user', entityType: 'user' as const, entityId: userId };
      const unsafe: Array<Record<string, number>> = [{ password: 1 }, { new_password_hash: 1 }, { token: 1 }, { refresh_token: 1 }, { otp_code: 1 }, { phone: 1 }, { secret: 1 }, { sessions_revoked: 'three' as unknown as number }, { sessions_revoked: Number.NaN }, { sessions_revoked: Number.POSITIVE_INFINITY }];
      for (const afterData of unsafe) {
        await assert.rejects(audit.record({ ...base, afterData }), /audit data/, JSON.stringify(afterData));
      }
    });
    assert.equal(env.db.audits().length, 0);
  });
});

describe('change password: confidentiality', () => {
  it('no error, response or log ever contains a password, a hash or a token', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    const errors = [
      await failure(env.account.changePassword(userId, { currentPassword: 'wrong-current-pw', newPassword: 'Another-New-Pw-1' })),
      await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: OLD })),
      await failure(env.account.changePassword(userId, { currentPassword: OLD, newPassword: '1' })),
      await failure(env.account.changePassword(userId, null)),
      await failure(env.account.changePassword('424242', { currentPassword: OLD, newPassword: 'Another-New-Pw-1' })),
    ];
    for (const e of errors) {
      const text = JSON.stringify({ m: e.message, f: e.fields });
      for (const secret of [OLD, NEW, 'wrong-current-pw', 'Another-New-Pw-1', '$argon2', '9647701234567']) assert.ok(!text.includes(secret), `${e.code}: ${secret}`);
    }
    const out = JSON.stringify(await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW }, { requestId: 'r1' }));
    const logText = env.log.text();
    for (const secret of [OLD, NEW, 'wrong-current-pw', 'Another-New-Pw-1', '$argon2', 'nsj_', 'eyJ', ACCESS_SECRET, '9647701234567', '07701234567', all[0]!.session.refreshToken, all[0]!.session.accessToken]) {
      assert.ok(!out.includes(secret) && !logText.includes(secret), `nothing may contain ${secret}`);
    }
    assert.ok(logText.includes('auth.password_changed') && logText.includes('auth.password_change.rejected'));
  });

  it('every refusal of the current password is the same error whatever the reason (wrong, locked, lost a race)', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    const shapes = new Set<string>();
    shapes.add(shape(await failure(env.account.changePassword(userId, { currentPassword: 'wrong', newPassword: NEW }))));
    const raced = setup();
    const r2 = await withSessions(raced, 1);
    const results = await Promise.allSettled([raced.account.changePassword(r2.userId, { currentPassword: OLD, newPassword: 'A-Candidate-1' }), raced.account.changePassword(r2.userId, { currentPassword: OLD, newPassword: 'B-Candidate-2' })]);
    shapes.add(shape((results.find((x) => x.status === 'rejected') as PromiseRejectedResult).reason as AuthError));
    assert.equal(shapes.size, 1, [...shapes].join(' | '));
  });
});

describe('sign out from all devices', () => {
  it('ends every login session: access tokens at once, refresh tokens refused, all rows revoked as logout_all', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 3);
    const rotated = await env.auth.refresh(refresh(all[2]!));
    assert.deepEqual(await env.account.logoutAll(userId), { status: 'signed_out_everywhere' });
    for (const s of [...all, rotated]) assert.equal(await env.auth.authenticate(s.session.accessToken), null);
    for (const s of [all[0]!, all[1]!, rotated]) assert.equal((await failure(env.auth.refresh(refresh(s)))).code, 'unauthorized');
    assert.equal(live(env, userId).length, 0);
    assert.equal(env.db.sessions().filter((s) => s.revokedReason === 'logout_all').length, 3, 'the three live rows; the rotated one keeps its history');
    assert.equal(env.db.sessions().filter((s) => s.revokedReason === 'reuse_detected').length, 0, 'a refresh after sign-out is refused, not a reuse');
  });

  it('is isolated: another user\'s sessions, password and refresh tokens are untouched', async () => {
    const env = setup();
    const a = await withSessions(env, 2);
    const b = await withSessions(env, 2, OTHER);
    const bPassword = env.db.users().find((u) => u.id === b.userId)!.passwordHash;
    await env.account.logoutAll(a.userId);
    assert.equal(live(env, a.userId).length, 0);
    assert.equal(live(env, b.userId).length, 2);
    for (const s of b.all) assert.ok(await env.auth.authenticate(s.session.accessToken));
    assert.ok(await env.auth.refresh(refresh(b.all[0]!)));
    assert.equal(env.db.users().find((u) => u.id === b.userId)!.passwordHash, bPassword);
    assert.equal(env.db.audits().length, 1);
    assert.equal(env.db.audits()[0]?.entityId, a.userId);
  });

  it('never creates, extends or restores a session', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    const rowsBefore = env.db.sessions().length;
    const expiries = env.db.sessions().map((s) => s.expiresAt.getTime());
    await env.account.logoutAll(userId);
    assert.equal(env.db.sessions().length, rowsBefore, 'no new row');
    assert.deepEqual(env.db.sessions().map((s) => s.expiresAt.getTime()), expiries, 'no expiry changed');
    assert.equal(await env.auth.authenticate(all[0]!.session.accessToken), null, 'the requesting session is gone and stays gone');
    await env.auth.authenticate(all[0]!.session.accessToken);
    assert.equal(live(env, userId).length, 0, 'using the dead token again revives nothing');
  });

  it('a refresh after sign-out gets no new tokens and writes no row; a refresh before it is swept up too', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 1);
    const afterRefresh = await env.auth.refresh(refresh(all[0]!)); // rotated BEFORE the sign-out
    await env.account.logoutAll(userId);
    const rows = env.db.sessions().length;
    assert.equal((await failure(env.auth.refresh(refresh(afterRefresh)))).code, 'unauthorized');
    assert.equal(env.db.sessions().length, rows, 'a refused refresh issues nothing');
    assert.equal(live(env, userId).length, 0);
  });

  it('a refresh racing with the sign-out cannot leave a live session, in either order', async () => {
    for (const order of ['refresh-first', 'logout-first'] as const) {
      const env = setup();
      const { userId, all } = await withSessions(env, 2);
      const ops = [() => env.auth.refresh(refresh(all[0]!)), () => env.account.logoutAll(userId)];
      if (order === 'logout-first') ops.reverse();
      await Promise.allSettled(ops.map((f) => f()));
      assert.equal(live(env, userId).length, 0, order);
    }
  });

  it('several simultaneous sign-outs are all fine: nothing live remains, nothing fails, and the ended sessions are counted once', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 3);
    const results = await Promise.allSettled(Array.from({ length: 6 }, () => env.account.logoutAll(userId)));
    assert.ok(results.every((x) => x.status === 'fulfilled'));
    assert.equal(live(env, userId).length, 0);
    const total = env.db.audits().reduce((n, a) => n + (a.afterData['sessions_revoked'] ?? 0), 0);
    assert.equal(total, 3, 'three sessions were ended in total, however the six calls interleaved');
  });

  it('signing in again afterwards works', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 2);
    await env.account.logoutAll(userId);
    const fresh = await env.auth.login({ phone: reg.phone, password: OLD });
    assert.ok(await env.auth.authenticate(fresh.session.accessToken));
  });

  it('records one audit event with the count of ended sessions, the actor and the request id; it holds no secret', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 3);
    await env.account.logoutAll(userId, { requestId: 'req-xyz' });
    const a = env.db.audits()[0]!;
    assert.equal(env.db.audits().length, 1);
    assert.deepEqual({ action: a.action, actor: a.actorUserId, role: a.actorRole, type: a.entityType, id: a.entityId, data: a.afterData, req: a.requestId }, { action: 'auth.logout_all', actor: userId, role: 'user', type: 'user', id: userId, data: { sessions_revoked: 3 }, req: 'req-xyz' });
    const text = JSON.stringify(env.db.audits());
    for (const secret of [OLD, '$argon2', 'nsj_', 'eyJ', '9647701234567', all[0]!.session.refreshToken]) assert.ok(!text.includes(secret));
  });

  it('is atomic with its audit event: if the event cannot be written, no session is revoked', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    env.db.faults.failNextAudit = true;
    await assert.rejects(env.account.logoutAll(userId), /simulated audit insert failure/);
    assert.equal(live(env, userId).length, 2);
    assert.ok(await env.auth.authenticate(all[0]!.session.accessToken));
    await env.account.logoutAll(userId);
    assert.equal(live(env, userId).length, 0);
  });

  it('a suspended, pending, deleted or unknown user is refused as unauthorized and writes nothing', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    assert.equal((await failure(env.account.logoutAll('99999'))).code, 'unauthorized');
    for (const status of ['suspended', 'pending']) {
      env.db.setStatus(userId, status);
      assert.equal((await failure(env.account.logoutAll(userId))).code, 'unauthorized', status);
    }
    env.db.setStatus(userId, 'active');
    env.db.users()[0]!.deletedAt = new Date();
    assert.equal((await failure(env.account.logoutAll(userId))).code, 'unauthorized');
    assert.equal(env.db.audits().length, 0);
    assert.equal(env.db.counters.revokeAllLive, 0);
  });

  it('does not touch the password, the phone verification or the account status', async () => {
    const env = setup();
    const { userId } = await withSessions(env, 1);
    env.db.users()[0]!.phoneVerifiedAt = new Date(0);
    const hash = env.db.users()[0]!.passwordHash;
    await env.account.logoutAll(userId);
    assert.equal(env.db.users()[0]?.passwordHash, hash);
    assert.equal(env.db.users()[0]?.phoneVerifiedAt?.getTime(), 0);
    assert.equal(env.db.users()[0]?.status, 'active');
    assert.ok(await env.auth.login({ phone: reg.phone, password: OLD }));
  });

  it('logs hold event names, ids and counts only', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 2);
    await env.account.logoutAll(userId, { requestId: 'r1' });
    const text = env.log.text();
    assert.ok(text.includes('auth.logout_all'));
    for (const secret of [OLD, '$argon2', 'nsj_', 'eyJ', ACCESS_SECRET, '9647701234567', all[0]!.session.refreshToken]) assert.ok(!text.includes(secret));
  });
});

describe('session management: revoked and expired sessions cannot obtain new tokens', () => {
  it('after sign-out everywhere, after a password change and after expiry, a refresh token mints nothing', async () => {
    const results: string[] = [];
    for (const how of ['logout-all', 'password-change', 'expired'] as const) {
      const env = setup();
      const { userId, all } = await withSessions(env, 1);
      if (how === 'logout-all') await env.account.logoutAll(userId);
      if (how === 'password-change') await env.account.changePassword(userId, { currentPassword: OLD, newPassword: NEW });
      if (how === 'expired') env.clock.advanceSeconds(31 * 24 * 3600);
      const rows = env.db.sessions().length;
      const e = await failure(env.auth.refresh(refresh(all[0]!)));
      results.push(shape(e));
      assert.equal(e.code, 'unauthorized', how);
      assert.equal(env.db.sessions().length, rows, `${how}: no token pair was created`);
    }
    assert.equal(new Set(results).size, 1, 'every reason is the same answer');
  });

  it('the access token of a revoked session is refused even though its signature and expiry are still valid', async () => {
    const env = setup();
    const { userId, all } = await withSessions(env, 1);
    assert.ok(await env.auth.authenticate(all[0]!.session.accessToken));
    await env.account.logoutAll(userId);
    env.clock.advanceSeconds(60); // still well inside its 15 minutes
    assert.equal(await env.auth.authenticate(all[0]!.session.accessToken), null);
  });
});

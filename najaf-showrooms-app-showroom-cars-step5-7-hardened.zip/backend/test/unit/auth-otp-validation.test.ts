import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PASSWORD_MAX, PASSWORD_MIN } from '../../src/auth/policy.ts';
import { parseForgotInput, parseOtpConfirmInput, parseRegisterInput, parseResetInput } from '../../src/auth/validation.ts';
import type { FieldError } from '../../src/auth/validation.ts';

const errs = (r: { ok: boolean; errors?: FieldError[] }): FieldError[] => (r.ok ? [] : (r.errors as FieldError[]));
const has = (e: FieldError[], field: string, code: string) => e.some((x) => x.field === field && x.code === code);

describe('confirm input: { code }', () => {
  it('accepts exactly 6 digits', () => {
    assert.deepEqual(parseOtpConfirmInput({ code: '123456' }), { ok: true, value: { code: '123456' } });
    assert.deepEqual(parseOtpConfirmInput({ code: '000000' }), { ok: true, value: { code: '000000' } });
  });
  it('rejects everything else without echoing it', () => {
    assert.ok(has(errs(parseOtpConfirmInput({})), 'code', 'required'));
    assert.ok(has(errs(parseOtpConfirmInput({ code: '' })), 'code', 'required'));
    assert.ok(has(errs(parseOtpConfirmInput({ code: 123456 })), 'code', 'invalid_type'));
    for (const bad of ['12345', '1234567', 'abcdef', '12 456', '12345٦', '123456\n', '٠١٢٣٤٥']) assert.ok(has(errs(parseOtpConfirmInput({ code: bad })), 'code', 'invalid_format'), bad);
    assert.ok(!JSON.stringify(parseOtpConfirmInput({ code: 'secret-looking-1234' })).includes('secret-looking'));
  });
  it('is strict: no unknown fields (no purpose, userId or phone can be supplied), no non-objects', () => {
    for (const extra of ['purpose', 'userId', 'phone', 'user_id']) assert.ok(has(errs(parseOtpConfirmInput({ code: '123456', [extra]: 'x' })), extra, 'unknown_field'), extra);
    for (const body of [null, undefined, 'x', 5, [], ['123456']]) assert.deepEqual(errs(parseOtpConfirmInput(body)), [{ field: 'body', code: 'invalid_type' }]);
  });
});

describe('forgot input: { phone }', () => {
  it('canonicalizes the phone like registration does', () => {
    for (const phone of ['07701234567', '+964 770 123 4567', '٠٧٧٠١٢٣٤٥٦٧']) assert.deepEqual(parseForgotInput({ phone }), { ok: true, value: { phone: '+9647701234567' } });
  });
  it('rejects bad or missing phones, unknown fields and non-objects', () => {
    assert.ok(has(errs(parseForgotInput({})), 'phone', 'required'));
    assert.ok(has(errs(parseForgotInput({ phone: '123' })), 'phone', 'invalid_format'));
    assert.ok(has(errs(parseForgotInput({ phone: 5 })), 'phone', 'invalid_type'));
    assert.ok(has(errs(parseForgotInput({ phone: '07701234567', password: 'x' })), 'password', 'unknown_field'));
    assert.deepEqual(errs(parseForgotInput(null)), [{ field: 'body', code: 'invalid_type' }]);
  });
});

describe('reset input: { phone, code, newPassword }', () => {
  const good = { phone: '07701234567', code: '123456', newPassword: 'N3w-Passw0rd' };
  it('accepts a valid body and canonicalizes only the phone; the password is untouched', () => {
    assert.deepEqual(parseResetInput({ ...good, newPassword: '  keep spaces  ' }), { ok: true, value: { phone: '+9647701234567', code: '123456', newPassword: '  keep spaces  ' } });
  });
  it('enforces the SAME password policy as registration (6..128 code points, no NUL), reporting the field as newPassword', () => {
    assert.equal(PASSWORD_MIN, 6);
    assert.ok(has(errs(parseResetInput({ ...good, newPassword: '12345' })), 'newPassword', 'too_short'));
    assert.equal(parseResetInput({ ...good, newPassword: '123456' }).ok, true);
    assert.equal(parseResetInput({ ...good, newPassword: 'x'.repeat(PASSWORD_MAX) }).ok, true);
    assert.ok(has(errs(parseResetInput({ ...good, newPassword: 'x'.repeat(PASSWORD_MAX + 1) })), 'newPassword', 'too_long'));
    assert.ok(has(errs(parseResetInput({ ...good, newPassword: 'ab\u0000cd12' })), 'newPassword', 'invalid_format'));
    assert.ok(has(errs(parseResetInput({ ...good, newPassword: 123456 })), 'newPassword', 'invalid_type'));
    assert.ok(has(errs(parseResetInput({ phone: good.phone, code: good.code })), 'newPassword', 'required'));
    // registration and recovery agree on what a valid password is
    for (const pw of ['12345', '123456', 'x'.repeat(128), 'x'.repeat(129), 'ab\u0000cd12', '']) {
      assert.equal(parseResetInput({ ...good, newPassword: pw }).ok, parseRegisterInput({ name: 'علي حسين', phone: good.phone, password: pw }).ok, JSON.stringify(pw.slice(0, 8)));
    }
  });
  it('reports every problem at once, never echoes values, rejects unknown fields (e.g. a user id)', () => {
    const r = errs(parseResetInput({ phone: 'bad', code: 'abc', newPassword: 'x', userId: '1' }));
    assert.equal(r.length, 4);
    assert.ok(!JSON.stringify(r).includes('abc') && !JSON.stringify(r).includes('"x"'));
    assert.ok(has(errs(parseResetInput({ ...good, role: 'admin' })), 'role', 'unknown_field'));
    assert.deepEqual(errs(parseResetInput([])), [{ field: 'body', code: 'invalid_type' }]);
  });
});

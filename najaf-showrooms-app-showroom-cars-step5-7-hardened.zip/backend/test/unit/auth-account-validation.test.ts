import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PASSWORD_MAX, PASSWORD_MIN } from '../../src/auth/policy.ts';
import { parseChangePasswordInput, parseRegisterInput, parseResetInput } from '../../src/auth/validation.ts';
import type { FieldError } from '../../src/auth/validation.ts';

const good = { currentPassword: 'Old-Passw0rd', newPassword: 'N3w-Passw0rd' };
const errs = (r: { ok: boolean; errors?: FieldError[] }): FieldError[] => (r.ok ? [] : (r.errors as FieldError[]));
const has = (e: FieldError[], field: string, code: string) => e.some((x) => x.field === field && x.code === code);

describe('change-password input', () => {
  it('accepts a valid body unchanged: passwords are never trimmed or normalized', () => {
    assert.deepEqual(parseChangePasswordInput(good), { ok: true, value: good });
    assert.deepEqual(parseChangePasswordInput({ currentPassword: '  spaces  ', newPassword: '  other spaces  ' }), { ok: true, value: { currentPassword: '  spaces  ', newPassword: '  other spaces  ' } });
  });

  it('the NEW password gets the full existing policy (the same as registration and recovery); the current one is only size-bounded', () => {
    assert.ok(has(errs(parseChangePasswordInput({ ...good, newPassword: '12345' })), 'newPassword', 'too_short'));
    assert.equal(parseChangePasswordInput({ ...good, newPassword: 'x'.repeat(PASSWORD_MIN) }).ok, true);
    assert.equal(parseChangePasswordInput({ ...good, newPassword: 'x'.repeat(PASSWORD_MAX) }).ok, true);
    assert.ok(has(errs(parseChangePasswordInput({ ...good, newPassword: 'x'.repeat(PASSWORD_MAX + 1) })), 'newPassword', 'too_long'));
    assert.ok(has(errs(parseChangePasswordInput({ ...good, newPassword: 'ab\u0000cd12' })), 'newPassword', 'invalid_format'));
    assert.equal(parseChangePasswordInput({ ...good, currentPassword: 'a' }).ok, true, 'an old, short password can still be the current one');
    assert.ok(has(errs(parseChangePasswordInput({ ...good, currentPassword: 'x'.repeat(PASSWORD_MAX + 1) })), 'currentPassword', 'too_long'));
    for (const pw of ['', '12345', '123456', 'x'.repeat(128), 'x'.repeat(129), 'ab\u0000cd12', '١٢٣٤٥٦٧']) {
      const a = parseChangePasswordInput({ ...good, newPassword: pw }).ok;
      assert.equal(a, parseRegisterInput({ name: 'علي حسين', phone: '07701234567', password: pw }).ok, 'agrees with registration');
      assert.equal(a, parseResetInput({ phone: '07701234567', code: '123456', newPassword: pw }).ok, 'agrees with recovery');
    }
  });

  it('names the failing field precisely', () => {
    assert.deepEqual(errs(parseChangePasswordInput({ newPassword: good.newPassword })), [{ field: 'currentPassword', code: 'required' }]);
    assert.deepEqual(errs(parseChangePasswordInput({ currentPassword: good.currentPassword })), [{ field: 'newPassword', code: 'required' }]);
    assert.ok(has(errs(parseChangePasswordInput({ currentPassword: 5, newPassword: 6 })), 'currentPassword', 'invalid_type'));
    assert.ok(has(errs(parseChangePasswordInput({ currentPassword: 5, newPassword: 6 })), 'newPassword', 'invalid_type'));
  });

  it('is strict: no user id, role or any other field, and the body must be an object', () => {
    for (const extra of ['userId', 'user_id', 'id', 'phone', 'role', 'status', 'sessionId', 'refreshToken']) assert.ok(has(errs(parseChangePasswordInput({ ...good, [extra]: '1' })), extra, 'unknown_field'), extra);
    for (const body of [null, undefined, 'x', 5, [], [good]]) assert.deepEqual(errs(parseChangePasswordInput(body)), [{ field: 'body', code: 'invalid_type' }]);
  });

  it('never echoes a password in its errors', () => {
    const secret = 'Super-Secret-Value-123';
    const text = JSON.stringify(parseChangePasswordInput({ currentPassword: secret, newPassword: '1', [`k ${secret}`]: secret }));
    assert.ok(!text.includes(secret));
  });
});

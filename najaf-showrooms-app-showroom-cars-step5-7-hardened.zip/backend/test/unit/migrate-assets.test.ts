// The migration assets must stay consistent with the frozen, validated database/migrations:
// one wrapper and one rollback script per migration, byte-exact reading of the originals, and a DROP for every CREATE.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { DOWN_SQL_DIR, MIGRATIONS_DIR, UP_SQL_DIR, listMigrationNames } from '../../src/migrate/paths.ts';

const available = existsSync(UP_SQL_DIR);
const skip = available ? false : 'database/migrations not found next to backend/';
const databaseDir = join(UP_SQL_DIR, '..');
const upFiles = available ? readdirSync(UP_SQL_DIR).filter((f) => f.endsWith('.sql')).sort() : [];
const bases = upFiles.map((f) => f.slice(0, -4));
const stripComments = (sql: string): string => sql.replace(/--[^\n]*/g, '');
const read = (p: string): string => readFileSync(p, 'utf8');

function wrapperSource(base: string): string {
  return `'use strict';
// Phase 11.4.2 wrapper. Applies the validated, UNMODIFIED SQL of database/migrations/${base}.sql
// and rolls back with db/down/${base}.down.sql (both read verbatim; nothing is generated at runtime).
const fs = require('node:fs');
const path = require('node:path');

const UP = path.join(__dirname, '..', '..', '..', 'database', 'migrations', '${base}.sql');
const DOWN = path.join(__dirname, '..', 'down', '${base}.down.sql');

exports.up = (pgm) => {
  pgm.sql(fs.readFileSync(UP, 'utf8'));
};

exports.down = (pgm) => {
  pgm.sql(fs.readFileSync(DOWN, 'utf8'));
};
`;
}

describe('the original migrations are untouched', { skip }, () => {
  it('every database/migrations/*.sql still matches its SHA-256 in database/CHECKSUMS.sha256', () => {
    const lines = read(join(databaseDir, 'CHECKSUMS.sha256')).split('\n').filter((l) => l.includes('  migrations/'));
    assert.equal(lines.length, 13);
    for (const line of lines) {
      const [hash, rel] = line.split('  ') as [string, string];
      const actual = createHash('sha256').update(readFileSync(join(databaseDir, rel))).digest('hex');
      assert.equal(actual, hash, `${rel} was modified`);
    }
  });

  it('there are exactly 13 migrations numbered 0001-0013', () => {
    assert.deepEqual(upFiles.map((f) => f.slice(0, 4)), Array.from({ length: 13 }, (_, i) => String(i + 1).padStart(4, '0')));
  });
});

describe('wrappers and rollback scripts: one per migration, nothing else', { skip }, () => {
  it('the wrapper, down and up names match one-to-one', () => {
    assert.deepEqual(listMigrationNames(), bases);
    assert.deepEqual(readdirSync(DOWN_SQL_DIR).filter((f) => f.endsWith('.sql')).sort(), bases.map((b) => `${b}.down.sql`));
    // node-pg-migrate scans EVERY entry of this directory: nothing but the wrappers may be in it (a package.json here
    // made the tool fail with "Cannot determine numeric prefix").
    assert.deepEqual(readdirSync(MIGRATIONS_DIR).sort(), bases.map((b) => `${b}.js`));
  });

  it('the wrappers are CommonJS through db/package.json, ONE LEVEL ABOVE the scanned directory', () => {
    assert.equal(existsSync(join(MIGRATIONS_DIR, 'package.json')), false);
    assert.equal(JSON.parse(read(join(MIGRATIONS_DIR, '..', 'package.json'))).type, 'commonjs');
  });

  it('every wrapper has exactly the expected source (no drift)', () => {
    for (const b of bases) assert.equal(read(join(MIGRATIONS_DIR, `${b}.js`)), wrapperSource(b), b);
  });

  it('executing each wrapper passes the original SQL, byte for byte, to pgm.sql (up) and the rollback SQL (down)', () => {
    const require = createRequire(import.meta.url);
    for (const b of bases) {
      const mod = require(join(MIGRATIONS_DIR, `${b}.js`)) as { up: (p: { sql: (s: string) => void }) => void; down: (p: { sql: (s: string) => void }) => void };
      const up: string[] = [];
      const down: string[] = [];
      mod.up({ sql: (s) => up.push(s) });
      mod.down({ sql: (s) => down.push(s) });
      assert.deepEqual(up, [read(join(UP_SQL_DIR, `${b}.sql`))], `${b} up`);
      assert.deepEqual(down, [read(join(DOWN_SQL_DIR, `${b}.down.sql`))], `${b} down`);
    }
  });
});

describe('rollback scripts cover everything the migrations create', { skip }, () => {
  const patterns: Array<[string, RegExp, (name: string) => RegExp]> = [
    ['table', /^CREATE TABLE (\w+)/gm, (n) => new RegExp(`^DROP TABLE IF EXISTS ${n};`, 'm')],
    ['function', /^CREATE FUNCTION (\w+)\s*\(/gm, (n) => new RegExp(`^DROP FUNCTION IF EXISTS ${n}\\(`, 'm')],
    ['domain', /^CREATE DOMAIN (\w+)/gm, (n) => new RegExp(`^DROP DOMAIN IF EXISTS ${n};`, 'm')],
    ['view', /^CREATE VIEW (\w+)/gm, (n) => new RegExp(`^DROP VIEW IF EXISTS ${n};`, 'm')],
    ['extension', /^CREATE EXTENSION IF NOT EXISTS (\w+)/gm, (n) => new RegExp(`^DROP EXTENSION IF EXISTS ${n};`, 'm')],
    ['trigger', /^CREATE (?:CONSTRAINT )?TRIGGER (\w+)/gm, (n) => new RegExp(`^DROP TRIGGER IF EXISTS ${n} ON \\w+;`, 'm')],
    ['index', /^CREATE (?:UNIQUE )?INDEX (\w+)/gm, (n) => new RegExp(`^DROP INDEX IF EXISTS ${n};`, 'm')],
  ];

  it('every created object has a matching DROP in the same migration\'s rollback script (and the totals are the validated ones)', () => {
    const totals: Record<string, number> = {};
    for (const b of bases) {
      const up = stripComments(read(join(UP_SQL_DIR, `${b}.sql`)));
      const down = read(join(DOWN_SQL_DIR, `${b}.down.sql`));
      for (const [kind, re, drop] of patterns) {
        for (const m of up.matchAll(re)) {
          totals[kind] = (totals[kind] ?? 0) + 1;
          assert.ok(drop(m[1] as string).test(down), `${b}: no DROP for ${kind} ${m[1]}`);
        }
      }
    }
    assert.deepEqual(totals, { table: 16, function: 15, domain: 2, view: 2, extension: 2, trigger: 18, index: 42 });
  });

  it('GRANT and REVOKE statements are inverted one for one', () => {
    for (const b of bases) {
      const up = stripComments(read(join(UP_SQL_DIR, `${b}.sql`)));
      const down = stripComments(read(join(DOWN_SQL_DIR, `${b}.down.sql`)));
      const count = (s: string, w: string) => (s.match(new RegExp(`^${w}\\b`, 'gm')) ?? []).length;
      assert.equal(count(down, 'REVOKE'), count(up, 'GRANT'), `${b}: REVOKE vs GRANT`);
      assert.equal(count(down, 'GRANT'), count(up, 'REVOKE'), `${b}: GRANT vs REVOKE`);
    }
  });

  it('the seed rows inserted by 0011 are deleted by its rollback', () => {
    const b = bases.find((x) => x.startsWith('0011'))!;
    const down = read(join(DOWN_SQL_DIR, `${b}.down.sql`));
    assert.match(down, /DELETE FROM app_settings WHERE key IN \('limits\.text', 'images\.max_per_car', 'images\.upload', 'otp\.policy'\);/);
    assert.match(down, /DELETE FROM subscription_plans WHERE code = 'free';/);
  });

  it('rollback never drops cluster roles and never uses CASCADE, TRUNCATE or database-level commands', () => {
    for (const b of bases) {
      const down = stripComments(read(join(DOWN_SQL_DIR, `${b}.down.sql`)));
      for (const w of ['DROP ROLE', 'CASCADE', 'TRUNCATE', 'DROP DATABASE', 'DROP SCHEMA', 'ALTER ROLE']) assert.ok(!down.includes(w), `${b} contains ${w}`);
    }
  });

  it('0013 rollback restores the table-level UPDATE that migration 0013 revoked', () => {
    const b = bases.find((x) => x.startsWith('0013'))!;
    assert.match(read(join(DOWN_SQL_DIR, `${b}.down.sql`)), /GRANT UPDATE ON showrooms, cars, car_images, favorites TO najaf_app;/);
  });
});

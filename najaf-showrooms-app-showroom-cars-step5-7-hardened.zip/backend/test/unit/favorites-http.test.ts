// Phase 11.5, Step 5.6: the HTTP contract of the favorites routes, through the real routes, the real authentication service
// (fake auth store) and the real favorites service over the in-memory favorites store. Plus static guards on the SQL and the sources.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthzError } from '../../src/authz/index.ts';
import { FAVORITE_RATE_LIMITS, registerFavoriteRoutes, toFavoriteHttp } from '../../src/favorites/routes.ts';
import { FavoriteError, createFavoriteService } from '../../src/favorites/service.ts';
import { LOCK_ACTING_USER_SQL, LOCK_LIVE_CAR_SQL, buildFindPublic, buildInsertIfPublic, buildList, buildRemove, createPgFavoriteRepository } from '../../src/favorites/repository.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeFavoriteStore } from '../helpers/fake-favorites.ts';

type Hook = (request: unknown, reply: unknown) => Promise<unknown>;
type RouteOpts = { bodyLimit?: number; onRequest?: Hook[] };
type Handler = (request: unknown, reply: unknown) => Promise<unknown>;
type Sent = { status?: number; body?: unknown; headers: Record<string, string> };
type ErrBody = { error: { code: string; fields?: Array<{ field: string; code: string }>; requestId: string } };

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';
const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const JSON_HEADERS = { 'content-type': 'application/json' };
const COLLECTION = '/v1/me/favorites';
const ONE = '/v1/me/favorites/:carId';

function fakeReply() {
  const sent: Sent = { headers: {} };
  const reply = { code: (n: number) => ((sent.status = n), reply), header: (k: string, v: string) => ((sent.headers[k] = v), reply), send: (b?: unknown) => ((sent.body = b), reply) };
  return { reply, sent };
}

function setup(withLimiter = false) {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const favs = makeFakeFavoriteStore({
    userState: (id) => {
      const u = db.users().find((x) => x.id === id);
      return u ? { status: u.status, deleted: u.deletedAt !== null } : undefined;
    },
  });
  const favorites = createFavoriteService({ store: favs.store });
  const routes: Array<{ method: string; path: string; opts: RouteOpts | undefined; handler: Handler }> = [];
  const add = (method: string) => (path: string, a: unknown, b?: unknown) => {
    routes.push({ method, path, opts: typeof b === 'function' ? (a as RouteOpts) : undefined, handler: (typeof b === 'function' ? b : a) as Handler });
  };
  const limiter = createMemoryRateLimiter({ now: clock.now });
  registerFavoriteRoutes({ get: add('GET'), post: add('POST'), patch: add('PATCH'), put: add('PUT'), delete: add('DELETE') } as never, { auth, favorites, ...(withLimiter ? { rateLimiter: limiter } : {}) });

  let n = 0;
  const phone = () => `0771${String(1000000 + ++n).slice(-7)}`;
  async function call(method: string, path: string, request: Record<string, unknown> = {}): Promise<Sent> {
    const route = routes.find((r) => r.method === method && r.path === path);
    if (!route) throw new Error(`no route ${method} ${path}`);
    const { reply, sent } = fakeReply();
    const req = { id: 'req-abcdef01', ip: '10.0.0.1', headers: {}, body: undefined, query: {}, params: {}, log: { warn() {} }, ...request };
    for (const hook of route.opts?.onRequest ?? []) {
      await hook(req, reply);
      if (sent.status !== undefined) return sent;
    }
    await route.handler(req, reply);
    return sent;
  }
  const bearer = (token: string) => ({ authorization: `Bearer ${token}` });
  async function member() {
    const r = await auth.register({ name: 'عضو', phone: phone(), password: PW });
    const h = bearer(r.session.accessToken);
    return { id: r.user.id, headers: h, json: { ...h, ...JSON_HEADERS } };
  }
  async function pendingDealer() {
    const r = await auth.registerDealer({ name: 'تاجر', phone: phone(), password: PW });
    const h = bearer(r.session.accessToken);
    return { id: r.user.id, headers: h, json: { ...h, ...JSON_HEADERS } };
  }
  const post = (who: { json: Record<string, string> }, body: unknown) => call('POST', COLLECTION, { headers: who.json, body });
  return { routes, call, member, pendingDealer, post, favs };
}

describe('favorite routes: registration', () => {
  it('registers exactly the three routes; every one is rate limited when a limiter is supplied', () => {
    const { routes } = setup(true);
    assert.deepEqual(routes.map((r) => `${r.method} ${r.path}`).sort(), [`DELETE ${ONE}`, `GET ${COLLECTION}`, `POST ${COLLECTION}`]);
    for (const r of routes) assert.ok((r.opts?.onRequest ?? []).length >= 1);
    assert.equal(routes.find((r) => r.method === 'POST')!.opts?.bodyLimit, 1024);
  });
});

describe('favorite routes: authentication', () => {
  it('no token or a bad token is 401 with WWW-Authenticate on every route', async () => {
    const s = setup();
    for (const [method, path] of [['GET', COLLECTION], ['POST', COLLECTION], ['DELETE', ONE]] as const) {
      for (const headers of [{}, { authorization: 'Bearer forged.token.value' }]) {
        const sent = await s.call(method, path, { headers: { ...headers, ...JSON_HEADERS }, params: { carId: '7000' }, body: { carId: '7000' } });
        assert.equal(sent.status, 401, `${method} ${path}`);
        assert.equal(sent.headers['www-authenticate'], 'Bearer');
      }
    }
  });

  it('a pending dealer (authenticated, no actor) is 403 on add and list and 404 on delete', async () => {
    const s = setup();
    const car = s.favs.addCar();
    const d = await s.pendingDealer();
    assert.equal((await s.post(d, { carId: car.id })).status, 403);
    assert.equal((await s.call('GET', COLLECTION, { headers: d.headers })).status, 403);
    assert.equal((await s.call('DELETE', ONE, { headers: d.headers, params: { carId: car.id } })).status, 404);
    assert.deepEqual(s.favs.favorites(), []);
  });
});

describe('favorite routes: behavior', () => {
  it('POST is 201 {favorite} the first time and 200 for a duplicate; GET lists it; DELETE is 204 with no body, twice', async () => {
    const s = setup();
    const a = await s.member();
    const car = s.favs.addCar();
    const first = await s.post(a, { carId: car.id });
    assert.equal(first.status, 201);
    assert.deepEqual(Object.keys((first.body as { favorite: object }).favorite).sort(), ['carId', 'createdAt']);
    const again = await s.post(a, { carId: car.id });
    assert.equal(again.status, 200);
    assert.deepEqual(again.body, first.body);
    const list = await s.call('GET', COLLECTION, { headers: a.headers });
    assert.equal(list.status, 200);
    assert.deepEqual((list.body as { items: Array<{ car: { id: string } }> }).items.map((i) => i.car.id), [car.id]);
    assert.equal((list.body as { nextBefore: unknown }).nextBefore, null);
    for (let i = 0; i < 2; i++) {
      const del = await s.call('DELETE', ONE, { headers: a.headers, params: { carId: car.id } });
      assert.equal(del.status, 204);
      assert.equal(del.body, undefined);
    }
    assert.equal(s.favs.favorites().length, 0);
  });

  it('a car that is not public is 404 identical to an unknown car; nothing is stored', async () => {
    const s = setup();
    const a = await s.member();
    const hidden = [s.favs.addCar({ deleted: true }), s.favs.addCar({ showroomPublic: false }), s.favs.addCar({ sourceType: 'member', status: 'pending', ownerId: a.id })];
    const unknown = await s.post(a, { carId: '999999' });
    assert.equal(unknown.status, 404);
    for (const c of hidden) {
      const r = await s.post(a, { carId: c.id });
      assert.equal(r.status, 404);
      assert.deepEqual(r.body, unknown.body);
    }
    assert.deepEqual(s.favs.favorites(), []);
  });

  it('users are isolated: B never sees A\'s favorites, and B\'s delete does not remove A\'s favorite', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const car = s.favs.addCar();
    await s.post(a, { carId: car.id });
    assert.deepEqual(((await s.call('GET', COLLECTION, { headers: b.headers })).body as { items: unknown[] }).items, []);
    assert.equal((await s.call('DELETE', ONE, { headers: b.headers, params: { carId: car.id } })).status, 204);
    assert.equal(s.favs.favoritesOf(a.id).length, 1);
  });

  it('the user can never be named: a user id in the body or the query is a 400 and changes nothing', async () => {
    const s = setup();
    const a = await s.member();
    const b = await s.member();
    const car = s.favs.addCar();
    const bad = await s.post(a, { carId: car.id, userId: b.id, user_id: b.id });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as ErrBody).error.fields, [{ field: 'userId', code: 'unknown_field' }, { field: 'user_id', code: 'unknown_field' }]);
    const q = await s.call('GET', COLLECTION, { headers: a.headers, query: { userId: b.id } });
    assert.equal(q.status, 400);
    assert.deepEqual(s.favs.favorites(), []);
  });

  it('validation errors are 400 with field names and codes only, no submitted value', async () => {
    const s = setup();
    const a = await s.member();
    const bad = await s.post(a, { carId: 'SECRET-nope' });
    assert.equal(bad.status, 400);
    assert.deepEqual((bad.body as ErrBody).error.fields, [{ field: 'carId', code: 'invalid_format' }]);
    assert.ok(!JSON.stringify(bad.body).includes('SECRET'));
    const badQuery = await s.call('GET', COLLECTION, { headers: a.headers, query: { limit: '0', before: 'x' } });
    assert.equal(badQuery.status, 400);
    assert.deepEqual((badQuery.body as ErrBody).error.fields, [{ field: 'limit', code: 'invalid_format' }, { field: 'before', code: 'invalid_format' }]);
  });

  it('pagination over HTTP follows nextBefore to the end', async () => {
    const s = setup();
    const a = await s.member();
    const cars = Array.from({ length: 5 }, () => s.favs.addCar());
    for (const c of cars) await s.post(a, { carId: c.id });
    const seen: string[] = [];
    let before: string | undefined;
    for (let guard = 0; guard < 10; guard++) {
      const r = await s.call('GET', COLLECTION, { headers: a.headers, query: before === undefined ? { limit: '2' } : { limit: '2', before } });
      const body = r.body as { items: Array<{ car: { id: string } }>; nextBefore: string | null };
      seen.push(...body.items.map((i) => i.car.id));
      if (body.nextBefore === null) break;
      before = body.nextBefore;
    }
    assert.deepEqual(seen, [...cars].reverse().map((c) => c.id));
  });

  it('a malformed car id on DELETE is 404; a non-JSON POST is 415; a body on DELETE is refused', async () => {
    const s = setup();
    const a = await s.member();
    const car = s.favs.addCar();
    await s.post(a, { carId: car.id });
    assert.equal((await s.call('DELETE', ONE, { headers: a.headers, params: { carId: 'abc' } })).status, 404);
    assert.equal((await s.call('POST', COLLECTION, { headers: { ...a.headers, 'content-type': 'text/plain' }, body: 'x' })).status, 415);
    assert.equal((await s.call('DELETE', ONE, { headers: a.headers, params: { carId: car.id }, body: { force: true } })).status, 400);
    assert.equal(s.favs.favoritesOf(a.id).length, 1);
  });

  it('writes have their own budget per address; reads are not blocked by it', async () => {
    const s = setup(true);
    const a = await s.member();
    for (let i = 0; i < FAVORITE_RATE_LIMITS.write.limit; i++) assert.equal((await s.post(a, { carId: '999999' })).status, 404);
    const denied = await s.post(a, { carId: '999999' });
    assert.equal(denied.status, 429);
    assert.ok(Number(denied.headers['retry-after']) > 0);
    assert.equal((await s.call('GET', COLLECTION, { headers: a.headers })).status, 200);
  });

  it('maps its own errors; leaves unknown ones to the global handler', () => {
    assert.equal(toFavoriteHttp(new FavoriteError('validation_failed', [{ field: 'carId', code: 'required' }]))?.status, 400);
    assert.equal(toFavoriteHttp(new AuthzError('not_found'))?.status, 404);
    assert.equal(toFavoriteHttp(new AuthzError('forbidden'))?.status, 403);
    assert.equal(toFavoriteHttp(new Error('boom')), undefined);
  });
});

describe('favorites: SQL and source guards', () => {
  it('a favorite is created only from public_cars and duplicates are decided by the unique constraint', () => {
    const s = buildInsertIfPublic('1', '2');
    assert.deepEqual(s.values, ['1', '2']);
    assert.match(s.text, /INSERT INTO favorites \(user_id, car_id\)\s+SELECT \$1::bigint, pc\.id FROM public_cars pc WHERE pc\.id = \$2::bigint\s+ON CONFLICT \(user_id, car_id\) DO NOTHING\s+RETURNING car_id, created_at/);
  });

  it('every read and the delete are scoped by the user; the list and the existence check go through public_cars', () => {
    const find = buildFindPublic('1', '2');
    assert.match(find.text, /FROM favorites f JOIN public_cars pc ON pc\.id = f\.car_id\s+WHERE f\.user_id = \$1::bigint AND f\.car_id = \$2::bigint/);
    const del = buildRemove('1', '2');
    assert.equal(del.text, 'DELETE FROM favorites WHERE user_id = $1::bigint AND car_id = $2::bigint');
    assert.deepEqual(del.values, ['1', '2']);
    const first = buildList('1', { limit: 20, before: null });
    assert.match(first.text, /FROM favorites f JOIN public_cars pc ON pc\.id = f\.car_id\s+WHERE f\.user_id = \$1::bigint\s+ORDER BY f\.id DESC LIMIT \$2/);
    assert.deepEqual(first.values, ['1', 20]);
    const next = buildList('1', { limit: 5, before: '77' });
    assert.match(next.text, /WHERE f\.user_id = \$1::bigint AND f\.id < \$2::bigint\s+ORDER BY f\.id DESC LIMIT \$3/);
    assert.deepEqual(next.values, ['1', '77', 5]);
  });

  it('the car is locked FOR SHARE (not deleted) and the acting user is re-checked and share-locked', async () => {
    assert.equal(LOCK_LIVE_CAR_SQL, 'SELECT id FROM cars WHERE id = $1::bigint AND deleted_at IS NULL FOR SHARE');
    assert.equal(LOCK_ACTING_USER_SQL, "SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE");
    const seen: Array<{ text: string; values: readonly unknown[] | undefined }> = [];
    const repo = createPgFavoriteRepository({ query: async (text: string, values?: readonly unknown[]) => { seen.push({ text, values }); return { rows: [{ id: '1' }], rowCount: 1 } as never; } });
    assert.equal(await repo.lockActingUser('7'), true);
    assert.equal(await repo.lockLiveCar('9'), true);
    assert.deepEqual(seen.map((x) => x.values), [['7'], ['9']]);
  });

  it('the repository only reads public views and favorites, writes only favorites, never selects * or owner data', () => {
    const src = code('src/favorites/repository.ts');
    assert.ok(!/SELECT\s+\*/i.test(src));
    assert.ok(!/\b(owner_id|search_text|reviewed_by|rejection_reason|suspension_reason|password_hash)\b/.test(src));
    assert.ok(!/\b(INSERT INTO|UPDATE|DELETE FROM)\s+(?!favorites\b)\w+/i.test(src), 'only favorites is written');
    assert.ok(!/\bUPDATE\b/i.test(src.replace(/ON CONFLICT[^`]*DO NOTHING/g, '')), 'favorites has no UPDATE privilege');
    assert.ok(!/FROM\s+cars\b(?!\s+WHERE id = \$1::bigint AND deleted_at IS NULL FOR SHARE)/i.test(src), 'cars is read only for the lock');
  });

  it('the service and routes never take a user from the request, and the actor id is what reaches the store', () => {
    const svc = code('src/favorites/service.ts');
    const routes = code('src/favorites/routes.ts');
    assert.ok(!/request\.|headers|\.query\b/.test(svc), 'the service sees no HTTP object');
    assert.ok(!/userId|user_id/.test(routes + code('src/favorites/validation.ts')));
    assert.match(routes, /return toActor\(found\.user\);/);
    assert.match(svc, /insertIfPublic\(actor\.id, carId\)/);
    assert.match(svc, /favorites\.remove\(actor\.id, carId\)/);
    assert.match(svc, /store\.favorites\.list\(actor\.id, parsed\.value\)/);
  });

  it('the routes are wired only together with authentication, and the process supplies the Postgres-backed service', () => {
    assert.match(code('src/server.ts'), /if \(deps\.auth && deps\.favorites\) registerFavoriteRoutes\(/);
    const index = code('src/index.ts');
    assert.match(index, /createFavoriteService\(\{ store: createPgFavoriteStore\(db\) \}\)/);
    assert.match(index, /buildServer\(\{[^}]*\bfavorites\b/);
  });
});

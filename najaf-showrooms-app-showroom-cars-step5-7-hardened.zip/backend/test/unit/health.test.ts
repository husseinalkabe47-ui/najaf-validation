import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DbError } from '../../src/errors.ts';
import { livenessReport, readinessReport, withTimeout } from '../../src/health.ts';
import type { Logger } from '../../src/types.ts';

function recorder() {
  const warns: unknown[] = [];
  const logger: Logger = { debug() {}, info() {}, warn: (o) => warns.push(o), error() {} };
  return { logger, warns };
}
const okDb = { ping: async () => {}, checkSchema: async () => ({ missing: [] as string[] }) };

describe('health', () => {
  it('liveness needs no database', () => {
    assert.deepEqual(livenessReport(), { status: 'ok' });
  });

  it('ready when the database answers and the schema contract is satisfied', async () => {
    assert.deepEqual(await readinessReport({ db: okDb }), { ready: true, checks: { database: 'ok', schema: 'ok' } });
  });

  it('not ready when the database ping fails; the schema check is skipped and details go only to the log', async () => {
    const { logger, warns } = recorder();
    let schemaCalled = false;
    const db = {
      ping: async () => { throw new DbError('unavailable', { driverMessage: 'connect ECONNREFUSED 10.0.0.5:5432' }); },
      checkSchema: async () => { schemaCalled = true; return { missing: [] as string[] }; },
    };
    const r = await readinessReport({ db, logger });
    assert.deepEqual(r, { ready: false, checks: { database: 'fail', schema: 'skipped' } });
    assert.equal(schemaCalled, false);
    assert.ok(JSON.stringify(warns).includes('ECONNREFUSED'));
    assert.ok(!JSON.stringify(r).includes('ECONNREFUSED'));
  });

  it('not ready when a hung database exceeds the timeout', async () => {
    const db = { ping: () => new Promise<void>(() => {}), checkSchema: async () => ({ missing: [] as string[] }) };
    const r = await readinessReport({ db, timeoutMs: 20 });
    assert.equal(r.ready, false);
    assert.equal(r.checks.database, 'fail');
  });

  it('not ready when schema objects are missing; the names are logged, never returned', async () => {
    const { logger, warns } = recorder();
    const db = { ping: async () => {}, checkSchema: async () => ({ missing: ['payments', 'public_cars'] }) };
    const r = await readinessReport({ db, logger });
    assert.deepEqual(r, { ready: false, checks: { database: 'ok', schema: 'fail' } });
    assert.ok(JSON.stringify(warns).includes('public_cars'));
    assert.ok(!JSON.stringify(r).includes('public_cars'));
  });

  it('not ready when the schema check itself fails', async () => {
    const db = { ping: async () => {}, checkSchema: async () => { throw new DbError('forbidden'); } };
    assert.deepEqual(await readinessReport({ db }), { ready: false, checks: { database: 'ok', schema: 'fail' } });
  });

  it('withTimeout passes results through, rejects on timeout, and leaves no pending timer', async () => {
    assert.equal(await withTimeout(Promise.resolve(5), 1000, 'x'), 5);
    await assert.rejects(withTimeout(new Promise(() => {}), 10, 'slow op'), /slow op timed out after 10ms/);
    await assert.rejects(withTimeout(Promise.reject(new Error('inner')), 1000, 'x'), /inner/);
  });
});

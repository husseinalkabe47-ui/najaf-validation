import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { MIGRATIONS_DIR } from '../../src/migrate/paths.ts';

// Model of how node-pg-migrate reads the directory it is given (from its documented source): EVERY entry is a migration
// unless it matches ignorePattern (default: names starting with "."), and every migration needs a numeric prefix.
function discover(dir: string): string[] {
  const files = readdirSync(dir).filter((f) => !/^\..*$/.test(f));
  for (const f of files) if (!/^\d+_/.test(f)) throw new Error(`Cannot determine numeric prefix for "${f}"`);
  return files.sort();
}

describe('what node-pg-migrate would receive from the migrations directory', () => {
  it('the scanned directory holds only the 13 wrappers, in order 0001..0013 (nothing the tool would reject)', () => {
    const found = discover(MIGRATIONS_DIR);
    assert.equal(found.length, 13);
    assert.deepEqual(found.map((f) => f.slice(0, 4)), Array.from({ length: 13 }, (_, i) => String(i + 1).padStart(4, '0')));
  });

  it('the model reproduces the original failure when a package.json sits in the scanned directory', () => {
    const dir = mkdtempSync(join(tmpdir(), 'migdir-'));
    writeFileSync(join(dir, '0001_x.js'), '');
    writeFileSync(join(dir, 'package.json'), '{}');
    assert.throws(() => discover(dir), /Cannot determine numeric prefix for "package\.json"/);
  });
});

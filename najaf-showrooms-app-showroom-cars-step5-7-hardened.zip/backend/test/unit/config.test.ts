import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ConfigError, describeDbTarget, loadConfig, redactConfig } from '../../src/config.ts';

const URL_OK = 'postgres://najaf_app_login:S3cr3tPass@db.internal:5432/najaf';
const base = (extra: Record<string, string | undefined> = {}) => ({ DATABASE_URL: URL_OK, ...extra });

function problemsOf(env: Record<string, string | undefined>): string[] {
  try {
    loadConfig(env);
  } catch (e) {
    if (e instanceof ConfigError) return e.problems;
    throw e;
  }
  return [];
}

describe('config: defaults and parsing', () => {
  it('loads a minimal DATABASE_URL with safe development defaults', () => {
    const c = loadConfig(base());
    assert.equal(c.env, 'development');
    assert.deepEqual(c.server, { host: '127.0.0.1', port: 3000, logLevel: 'info' });
    assert.equal(c.db.host, 'db.internal');
    assert.equal(c.db.port, 5432);
    assert.equal(c.db.database, 'najaf');
    assert.equal(c.db.user, 'najaf_app_login');
    assert.equal(c.db.password, 'S3cr3tPass');
    assert.equal(c.db.ssl, 'disable');
    assert.equal(c.db.poolMax, 10);
    assert.equal(c.db.statementTimeoutMs, 15000);
    assert.equal(c.db.lockTimeoutMs, 5000);
    assert.equal(c.db.idleInTxTimeoutMs, 15000);
    assert.equal(c.db.connectTimeoutMs, 5000);
    assert.equal(c.db.applicationName, 'najaf-backend');
    assert.equal(c.db.requireAppRole, true);
  });

  it('accepts the PG* variables when DATABASE_URL is absent', () => {
    const c = loadConfig({ PGHOST: 'h', PGPORT: '6543', PGDATABASE: 'd', PGUSER: 'u', PGPASSWORD: 'p' });
    assert.deepEqual([c.db.host, c.db.port, c.db.database, c.db.user, c.db.password], ['h', 6543, 'd', 'u', 'p']);
  });

  it('DATABASE_URL wins over PG* variables', () => {
    const c = loadConfig(base({ PGHOST: 'ignored', PGUSER: 'ignored', PGPASSWORD: 'ignored', PGDATABASE: 'ignored' }));
    assert.equal(c.db.host, 'db.internal');
    assert.equal(c.db.user, 'najaf_app_login');
  });

  it('decodes percent-encoded credentials and database names', () => {
    const c = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:p%40ss%2Fw%3Ard@db.example.com:6432/na%20jaf' });
    assert.equal(c.db.password, 'p@ss/w:rd');
    assert.equal(c.db.database, 'na jaf');
    assert.equal(c.db.port, 6432);
  });

  it('supports IPv6 literal hosts', () => {
    assert.equal(loadConfig({ DATABASE_URL: 'postgres://u:p@[::1]:5432/d' }).db.host, '::1');
  });

  it('the resolved configuration is immutable', () => {
    const c = loadConfig(base());
    assert.equal(Object.isFrozen(c), true);
    assert.equal(Object.isFrozen(c.db), true);
    assert.equal(Object.isFrozen(c.server), true);
  });
});

describe('config: validation never leaks the password', () => {
  it('reports every missing database setting in one error', () => {
    const p = problemsOf({});
    assert.equal(p.length, 4);
    assert.ok(p.some((m) => m.includes('host')) && p.some((m) => m.includes('name')) && p.some((m) => m.includes('user')) && p.some((m) => m.includes('password')));
  });

  it('an unparseable DATABASE_URL does not echo its value', () => {
    const e = assert.throws(() => loadConfig({ DATABASE_URL: 'not a url S3cr3tPass' }), ConfigError);
    void e;
    const msg = problemsOf({ DATABASE_URL: 'not a url S3cr3tPass' }).join('\n');
    assert.ok(!msg.includes('S3cr3tPass'));
  });

  it('a wrong scheme does not echo its value', () => {
    const msg = problemsOf({ DATABASE_URL: 'mysql://u:S3cr3tPass@h/db' }).join('\n');
    assert.ok(msg.includes('postgres'));
    assert.ok(!msg.includes('S3cr3tPass'));
  });

  it('a bad percent-encoding does not echo its value', () => {
    const msg = problemsOf({ DATABASE_URL: 'postgres://u:%E0%A4%A@h/db' }).join('\n');
    assert.ok(!msg.includes('%E0%A4%A'));
  });

  it('redactConfig hides the password and CA material', () => {
    const c = loadConfig(base({ DB_SSL: 'verify-full', DB_SSL_CA: '-----BEGIN CERTIFICATE-----secret-----END CERTIFICATE-----' }));
    const text = JSON.stringify(redactConfig(c));
    assert.ok(!text.includes('S3cr3tPass'));
    assert.ok(!text.includes('BEGIN CERTIFICATE'));
    assert.ok(text.includes('"password":"***"'));
  });

  it('describeDbTarget has no password', () => {
    const t = describeDbTarget(loadConfig(base()).db);
    assert.equal(t, 'najaf_app_login@db.internal:5432/najaf');
    assert.ok(!t.includes('S3cr3tPass'));
  });
});

describe('config: least-privilege policy', () => {
  it("refuses the 'postgres' superuser by default", () => {
    const p = problemsOf({ DATABASE_URL: 'postgres://postgres:pw@h:5432/najaf' });
    assert.ok(p.some((m) => m.includes('superuser')));
  });

  it("allows 'postgres' only when the role policy is explicitly disabled (tests/tools)", () => {
    const c = loadConfig({ DATABASE_URL: 'postgres://postgres:pw@h:5432/najaf', DB_REQUIRE_APP_ROLE: 'false' });
    assert.equal(c.db.requireAppRole, false);
  });
});

describe('config: production rules', () => {
  const prod = (extra: Record<string, string | undefined> = {}) => base({ NODE_ENV: 'production', HOST: '0.0.0.0', ...extra });

  it('defaults TLS to verify-full', () => {
    assert.equal(loadConfig(prod()).db.ssl, 'verify-full');
  });

  it('requires an explicit HOST', () => {
    assert.ok(problemsOf(base({ NODE_ENV: 'production' })).some((m) => m.includes('HOST')));
  });

  it('rejects DB_SSL=disable', () => {
    assert.ok(problemsOf(prod({ DB_SSL: 'disable' })).some((m) => m.includes('not allowed in production')));
  });

  it('rejects a URL sslmode=disable', () => {
    assert.ok(problemsOf(prod({ DATABASE_URL: URL_OK + '?sslmode=disable' })).some((m) => m.includes('not allowed in production')));
  });

  it('rejects DB_REQUIRE_APP_ROLE=false', () => {
    assert.ok(problemsOf(prod({ DB_REQUIRE_APP_ROLE: 'false' })).some((m) => m.includes('DB_REQUIRE_APP_ROLE')));
  });

  it('accepts a fully specified production configuration', () => {
    const c = loadConfig(prod({ DB_SSL: 'verify-full', DB_SSL_CA: 'PEM', DB_POOL_MAX: '20' }));
    assert.equal(c.env, 'production');
    assert.equal(c.db.sslCa, 'PEM');
    assert.equal(c.server.host, '0.0.0.0');
  });
});

describe('config: TLS selection', () => {
  it('honours sslmode in the URL', () => {
    assert.equal(loadConfig({ DATABASE_URL: URL_OK + '?sslmode=require' }).db.ssl, 'require');
  });

  it('DB_SSL overrides the URL', () => {
    assert.equal(loadConfig({ DATABASE_URL: URL_OK + '?sslmode=require', DB_SSL: 'verify-full' }).db.ssl, 'verify-full');
  });

  it('rejects libpq modes that silently weaken security', () => {
    for (const mode of ['prefer', 'allow', 'verify-ca']) {
      assert.ok(problemsOf({ DATABASE_URL: URL_OK + '?sslmode=' + mode }).some((m) => m.includes('sslmode')), mode);
    }
  });
});

describe('config: numeric and enum validation', () => {
  it('rejects out-of-range, fractional and non-numeric values and aggregates all problems', () => {
    const p = problemsOf(
      base({ DB_POOL_MAX: '0', DB_STATEMENT_TIMEOUT_MS: '5', DB_LOCK_TIMEOUT_MS: 'abc', DB_CONNECT_TIMEOUT_MS: '5.5', PORT: '70000', DB_IDLE_TIMEOUT_MS: '999999999' }),
    );
    assert.equal(p.length, 6);
    for (const name of ['DB_POOL_MAX', 'DB_STATEMENT_TIMEOUT_MS', 'DB_LOCK_TIMEOUT_MS', 'DB_CONNECT_TIMEOUT_MS', 'PORT', 'DB_IDLE_TIMEOUT_MS']) {
      assert.ok(p.some((m) => m.startsWith(name)), name);
    }
  });

  it('accepts the documented bounds', () => {
    const c = loadConfig(base({ DB_POOL_MAX: '100', DB_STATEMENT_TIMEOUT_MS: '100', PORT: '65535' }));
    assert.equal(c.db.poolMax, 100);
    assert.equal(c.db.statementTimeoutMs, 100);
    assert.equal(c.server.port, 65535);
  });

  it('rejects an unknown NODE_ENV, LOG_LEVEL and application name', () => {
    const p = problemsOf(base({ NODE_ENV: 'staging', LOG_LEVEL: 'verbose', DB_APPLICATION_NAME: 'bad name!' }));
    assert.equal(p.length, 3);
  });

  it('parses booleans strictly', () => {
    assert.equal(loadConfig(base({ DB_REQUIRE_APP_ROLE: '1' })).db.requireAppRole, true);
    assert.ok(problemsOf(base({ DB_REQUIRE_APP_ROLE: 'maybe' })).some((m) => m.includes('DB_REQUIRE_APP_ROLE')));
  });
});

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAuthService } from '../../src/auth/service.ts';
import { createOtpService } from '../../src/auth/otp-service.ts';
import { OTP, LOGIN_MAX_FAILURES } from '../../src/auth/policy.ts';
import { AuthError } from '../../src/auth/types.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeProvider } from '../helpers/fake-messaging.ts';

const SECRET = 'otp-service-test-secret-0123456789abcdef-QWE';
const PASSWORD = 'Old-Passw0rd-123';
const NEW_PASSWORD = 'Brand-New-Passw0rd';
const reg = { name: 'علي حسين', phone: '07701234567', password: PASSWORD };
const PHONE = '+9647701234567';

function setup() {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher, calls } = makeFakeHasher();
  const log = recordingLogger();
  const msg = makeFakeProvider();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const otp = createOtpService({ store: db.store, hasher, provider: msg.provider, otpSecret: SECRET, logger: log.logger });
  return { clock, db, calls, log, msg, auth, otp };
}
type Env = ReturnType<typeof setup>;
const signUp = (env: Env, over: Partial<typeof reg> = {}) => env.auth.register({ ...reg, ...over });
const other = (code: string) => (code === '000000' ? '000001' : '000000');
async function failure(p: Promise<unknown>): Promise<AuthError> {
  try {
    await p;
  } catch (e) {
    assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
    return e;
  }
  throw new Error('expected a failure');
}
const shape = (e: AuthError) => JSON.stringify({ code: e.code, message: e.message, fields: e.fields, retry: e.retryAfterSeconds });
const nobodyLoggedIn = async (env: Env, token: string) => assert.equal(await env.auth.authenticate(token), null);

describe('phone verification: a registered number is NOT a verified number', () => {
  it('registration leaves the phone unverified and sends nothing', async () => {
    const env = setup();
    const r = await signUp(env);
    assert.equal(r.user.phoneVerified, false);
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);
    assert.equal(env.msg.sent.length, 0);
    assert.equal(env.db.codes().length, 0);
  });

  it('a code is sent to the user\'s OWN phone, for the right purpose, with the policy TTL', async () => {
    const env = setup();
    const r = await signUp(env);
    assert.deepEqual(await env.otp.requestPhoneVerification(r.user.id), { status: 'sent' });
    assert.equal(env.msg.sent.length, 1);
    const m = env.msg.sent[0]!;
    assert.equal(m.phone, PHONE);
    assert.equal(m.purpose, 'phone_verify');
    assert.equal(m.ttlSeconds, 600);
    assert.match(m.code, /^[0-9]{6}$/);
  });

  it('only a keyed hash is stored: never the code, bound to user, phone and purpose, with the policy expiry and attempt limit', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    const row = env.db.codes()[0]!;
    assert.equal(env.db.codes().length, 1);
    assert.equal(row.hash.length, 32);
    assert.equal(row.purpose, 'phone_verify');
    assert.equal(row.userId, r.user.id);
    assert.equal(row.phone, PHONE);
    assert.equal(row.maxAttempts, 5);
    assert.equal(row.attempts, 0);
    assert.equal(row.expiresAt.getTime() - row.createdAt.getTime(), 600_000);
    assert.ok(!env.db.dump().includes(code), 'the plain code must not be stored anywhere');
  });

  it('a valid code verifies the phone: the state changes and the code is consumed in the same step', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    const user = await env.otp.confirmPhoneVerification(r.user.id, { code });
    assert.equal(user.phoneVerified, true);
    assert.equal(user.id, r.user.id);
    assert.ok(env.db.users()[0]?.phoneVerifiedAt instanceof Date);
    assert.ok(env.db.codes()[0]?.consumedAt instanceof Date);
    assert.equal((await env.auth.authenticate(r.session.accessToken))?.user.phoneVerified, true, '/me sees it at once');
  });

  it('a wrong code is invalid_code: nothing changes except the attempt count, and the right code still works', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    const e = await failure(env.otp.confirmPhoneVerification(r.user.id, { code: other(code) }));
    assert.equal(e.code, 'invalid_code');
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);
    assert.equal(env.db.codes()[0]?.attempts, 1, 'the failed attempt was committed, not rolled back');
    assert.equal(env.db.codes()[0]?.consumedAt, null);
    assert.equal((await env.otp.confirmPhoneVerification(r.user.id, { code })).phoneVerified, true);
  });

  it('an expired code is rejected (valid until the last second, dead at 10 minutes)', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    env.clock.advanceSeconds(OTP.ttlSeconds + 1);
    assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);

    const env2 = setup();
    const r2 = await signUp(env2);
    await env2.otp.requestPhoneVerification(r2.user.id);
    const code2 = env2.msg.lastCode(PHONE, 'phone_verify')!;
    env2.clock.advanceSeconds(OTP.ttlSeconds - 1);
    assert.equal((await env2.otp.confirmPhoneVerification(r2.user.id, { code: code2 })).phoneVerified, true);
  });

  it('a used code cannot be used again (reuse)', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    await env.otp.confirmPhoneVerification(r.user.id, { code });
    env.db.users()[0]!.phoneVerifiedAt = null; // simulate a state where verification is needed again
    assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null, 'the consumed code verified nothing');
  });

  it('a code issued for ANOTHER purpose is never accepted, in either direction', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPasswordReset({ phone: reg.phone });
    const resetCode = env.msg.lastCode(PHONE, 'password_reset')!;
    assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code: resetCode }))).code, 'invalid_code', 'a recovery code cannot verify a phone');
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);

    await env.otp.requestPhoneVerification(r.user.id);
    const verifyCode = env.msg.lastCode(PHONE, 'phone_verify')!;
    assert.notEqual(verifyCode, resetCode);
    const e = await failure(env.otp.resetPassword({ phone: reg.phone, code: verifyCode, newPassword: NEW_PASSWORD }));
    assert.equal(e.code, 'invalid_code', 'a verification code cannot reset a password');
    assert.equal(env.db.users()[0]?.passwordHash.includes(NEW_PASSWORD), false);
    assert.equal((await env.auth.login({ phone: reg.phone, password: PASSWORD })).user.id, r.user.id, 'the old password still works');
  });

  it('a code belongs to its user: another user cannot use it, with or without a code of their own', async () => {
    const env = setup();
    const a = await signUp(env);
    const b = await signUp(env, { phone: '07709999999' });
    await env.otp.requestPhoneVerification(a.user.id);
    const codeA = env.msg.lastCode(PHONE, 'phone_verify')!;
    assert.equal((await failure(env.otp.confirmPhoneVerification(b.user.id, { code: codeA }))).code, 'invalid_code', 'B has no code at all');
    await env.otp.requestPhoneVerification(b.user.id);
    assert.equal((await failure(env.otp.confirmPhoneVerification(b.user.id, { code: codeA }))).code, 'invalid_code', 'B has a code, but not this one');
    assert.equal(env.db.users().find((u) => u.id === b.user.id)?.phoneVerifiedAt, null);
    assert.equal(env.db.users().find((u) => u.id === a.user.id)?.phoneVerifiedAt, null, 'A is not verified by B\'s attempts either');
  });

  it('allows at most 5 attempts per code: after that even the CORRECT code is refused', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    for (let i = 0; i < OTP.maxAttempts; i++) assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code: other(code) }))).code, 'invalid_code');
    assert.equal(env.db.codes()[0]?.attempts, OTP.maxAttempts);
    assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code', 'the 6th attempt is refused even with the right code');
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);
    assert.equal(env.db.codes()[0]?.attempts, OTP.maxAttempts, 'attempts never exceed the maximum');
    // recovery from exhaustion: a new code, after the cooldown
    env.clock.advanceSeconds(OTP.cooldownSeconds + 1);
    await env.otp.requestPhoneVerification(r.user.id);
    assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code', 'the old code is dead');
    assert.equal((await env.otp.confirmPhoneVerification(r.user.id, { code: env.msg.lastCode(PHONE, 'phone_verify')! })).phoneVerified, true);
  });

  it('a malformed code is a validation failure that touches nothing: no lookup, no attempt counted', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const before = env.db.counters.otpVerify;
    for (const body of [null, {}, { code: '' }, { code: '12345' }, { code: 123456 }, { code: 'abcdef' }, { code: '123456', userId: '9' }, { code: '123456', purpose: 'password_reset' }]) {
      assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, body))).code, 'validation_failed');
    }
    assert.equal(env.db.counters.otpVerify, before);
    assert.equal(env.db.codes()[0]?.attempts, 0);
  });

  it('a new request supersedes the old code: only one is ever active', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const first = env.msg.lastCode(PHONE, 'phone_verify')!;
    env.clock.advanceSeconds(OTP.cooldownSeconds + 1);
    await env.otp.requestPhoneVerification(r.user.id);
    const second = env.msg.lastCode(PHONE, 'phone_verify')!;
    assert.equal(env.db.codes().filter((c) => c.consumedAt === null && c.invalidatedAt === null).length, 1);
    assert.equal(env.db.codes().filter((c) => c.invalidatedAt !== null).length, 1);
    if (first !== second) assert.equal((await failure(env.otp.confirmPhoneVerification(r.user.id, { code: first }))).code, 'invalid_code');
    assert.equal((await env.otp.confirmPhoneVerification(r.user.id, { code: second })).phoneVerified, true);
  });

  it('an unknown or inactive account cannot request or confirm', async () => {
    const env = setup();
    const r = await signUp(env);
    assert.equal((await failure(env.otp.requestPhoneVerification('9999'))).code, 'unauthorized');
    assert.equal((await failure(env.otp.confirmPhoneVerification('9999', { code: '123456' }))).code, 'unauthorized');
    env.db.setStatus(r.user.id, 'suspended');
    assert.equal((await failure(env.otp.requestPhoneVerification(r.user.id))).code, 'unauthorized');
    assert.equal(env.msg.sent.length, 0);
  });
});

describe('phone verification: already-verified users', () => {
  async function verified() {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    await env.otp.confirmPhoneVerification(r.user.id, { code: env.msg.lastCode(PHONE, 'phone_verify')! });
    return { env, r, stamp: env.db.users()[0]!.phoneVerifiedAt as Date };
  }

  it('a request sends nothing and issues nothing', async () => {
    const { env, r } = await verified();
    const sentBefore = env.msg.sent.length;
    const codesBefore = env.db.codes().length;
    env.clock.advanceSeconds(3600);
    assert.deepEqual(await env.otp.requestPhoneVerification(r.user.id), { status: 'already_verified' });
    assert.equal(env.msg.sent.length, sentBefore);
    assert.equal(env.db.codes().length, codesBefore);
  });

  it('a confirmation is an idempotent success: it consumes nothing and never overwrites the verification time', async () => {
    const { env, r, stamp } = await verified();
    env.clock.advanceSeconds(7200);
    for (const code of ['000000', '123456']) {
      const user = await env.otp.confirmPhoneVerification(r.user.id, { code });
      assert.equal(user.phoneVerified, true);
    }
    assert.equal(env.db.users()[0]?.phoneVerifiedAt?.getTime(), stamp.getTime(), 'the original timestamp is kept');
    assert.equal(env.db.codes().length, 1);
  });

  it('two simultaneous confirmations with the right code both end verified, with ONE verification time and ONE consumed code', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    const results = await Promise.allSettled([env.otp.confirmPhoneVerification(r.user.id, { code }), env.otp.confirmPhoneVerification(r.user.id, { code })]);
    assert.deepEqual(results.map((x) => x.status), ['fulfilled', 'fulfilled']);
    assert.equal(env.db.codes().filter((c) => c.consumedAt !== null).length, 1);
    assert.ok(env.db.users()[0]?.phoneVerifiedAt instanceof Date);
  });
});

describe('phone verification: requesting codes is rate limited per user', () => {
  it('a second request within 60 seconds is refused with a Retry-After hint, and sends nothing', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    env.clock.advanceSeconds(10);
    const e = await failure(env.otp.requestPhoneVerification(r.user.id));
    assert.equal(e.code, 'rate_limited');
    assert.equal(e.retryAfterSeconds, 50);
    assert.equal(env.msg.sent.length, 1);
    assert.equal(env.db.codes().length, 1);
    env.clock.advanceSeconds(51);
    assert.deepEqual(await env.otp.requestPhoneVerification(r.user.id), { status: 'sent' });
  });

  it('at most 3 codes per hour', async () => {
    const env = setup();
    const r = await signUp(env);
    for (let i = 0; i < OTP.perHour; i++) {
      await env.otp.requestPhoneVerification(r.user.id);
      env.clock.advanceSeconds(OTP.cooldownSeconds + 1);
    }
    const e = await failure(env.otp.requestPhoneVerification(r.user.id));
    assert.equal(e.code, 'rate_limited');
    assert.equal(e.retryAfterSeconds, 3600);
    assert.equal(env.msg.sent.length, OTP.perHour);
    env.clock.advanceSeconds(3600);
    assert.deepEqual(await env.otp.requestPhoneVerification(r.user.id), { status: 'sent' });
  });

  it('at most 10 codes per day', async () => {
    const env = setup();
    const r = await signUp(env);
    let issued = 0;
    while (issued < OTP.perDay) {
      try {
        await env.otp.requestPhoneVerification(r.user.id);
        issued += 1;
        env.clock.advanceSeconds(OTP.cooldownSeconds + 1);
      } catch (e) {
        assert.ok(e instanceof AuthError && e.code === 'rate_limited');
        env.clock.advanceSeconds((e.retryAfterSeconds ?? 60) + 1);
      }
    }
    env.clock.advanceSeconds(3601); // clear the hourly window so only the daily limit can answer
    const e = await failure(env.otp.requestPhoneVerification(r.user.id));
    assert.equal(e.code, 'rate_limited');
    assert.equal(e.retryAfterSeconds, 86_400);
    assert.equal(env.msg.sent.length, OTP.perDay);
  });

  it('the limits are per user and per purpose', async () => {
    const env = setup();
    const a = await signUp(env);
    const b = await signUp(env, { phone: '07709999999' });
    await env.otp.requestPhoneVerification(a.user.id);
    assert.deepEqual(await env.otp.requestPhoneVerification(b.user.id), { status: 'sent' }, 'another user is unaffected');
    assert.deepEqual(await env.otp.requestPasswordReset({ phone: reg.phone }), { status: 'accepted' });
    assert.equal(env.msg.lastCode(PHONE, 'password_reset') !== undefined, true, 'another purpose has its own budget');
  });

  it('two simultaneous requests: the unique "one active code" index lets one win; the other is a clean throttle, not a crash', async () => {
    const env = setup();
    const r = await signUp(env);
    env.db.faults.otpUniqueViolation = true;
    const e = await failure(env.otp.requestPhoneVerification(r.user.id));
    assert.equal(e.code, 'rate_limited');
    assert.equal(env.msg.sent.length, 0);
    env.db.faults.otpUniqueViolation = true;
    assert.deepEqual(await env.otp.requestPasswordReset({ phone: reg.phone }), { status: 'accepted' }, 'password recovery answers the same');
  });
});

describe('delivery: after the commit, not awaited, failures are harmless and silent', () => {
  it('a provider that never answers cannot make the request wait', async () => {
    const env = setup();
    const r = await signUp(env);
    const hanging = createOtpService({ store: env.db.store, hasher: makeFakeHasher().hasher, provider: { send: () => new Promise<void>(() => {}) }, otpSecret: SECRET });
    assert.deepEqual(await hanging.requestPhoneVerification(r.user.id), { status: 'sent' });
    assert.equal(env.db.codes().length, 1);
  });

  it('a provider failure never changes the answer, is logged without any secret, and the code row still exists', async () => {
    const env = setup();
    const r = await signUp(env);
    env.msg.failNext();
    assert.deepEqual(await env.otp.requestPhoneVerification(r.user.id), { status: 'sent' });
    await new Promise((resolve) => setImmediate(resolve));
    const text = env.log.text();
    assert.ok(text.includes('auth.otp.delivery_failed') && text.includes('provider_error'));
    assert.ok(!text.includes('exploded') && !/\b[0-9]{6}\b/.test(text.replace(/"userId":"\d+"/g, '')) && !text.includes('9647701234567'), 'the provider\'s error text (which names the code and phone) is never logged');
    assert.equal(env.db.codes().length, 1);
  });

  it('a provider that throws synchronously is handled the same way', async () => {
    const env = setup();
    const r = await signUp(env);
    const throwing = createOtpService({ store: env.db.store, hasher: makeFakeHasher().hasher, provider: { send: () => { throw new Error('boom 123456'); } }, otpSecret: SECRET, logger: env.log.logger });
    assert.deepEqual(await throwing.requestPhoneVerification(r.user.id), { status: 'sent' });
    await new Promise((resolve) => setImmediate(resolve));
    assert.ok(!env.log.text().includes('boom'));
  });

  it('the code is delivered only after the database work is done (a failed transaction sends nothing)', async () => {
    const env = setup();
    const r = await signUp(env);
    const original = env.db.store.transaction;
    env.db.store.transaction = async () => { throw new Error('database down'); };
    await assert.rejects(env.otp.requestPhoneVerification(r.user.id), /database down/);
    env.db.store.transaction = original;
    assert.equal(env.msg.sent.length, 0);
  });
});

describe('password recovery: requesting a code never reveals whether an account exists', () => {
  it('a registered phone: the same answer, and a recovery code reaches that phone', async () => {
    const env = setup();
    await signUp(env);
    assert.deepEqual(await env.otp.requestPasswordReset({ phone: reg.phone }), { status: 'accepted' });
    assert.equal(env.msg.sent.length, 1);
    assert.equal(env.msg.sent[0]?.phone, PHONE);
    assert.equal(env.msg.sent[0]?.purpose, 'password_reset');
    assert.equal(env.db.codes().length, 1);
    assert.ok(!env.db.dump().includes(env.msg.sent[0]!.code));
  });

  it('an unknown phone gets the IDENTICAL answer, and nothing is stored or sent', async () => {
    const env = setup();
    await signUp(env);
    const known = await env.otp.requestPasswordReset({ phone: reg.phone });
    const unknown = await env.otp.requestPasswordReset({ phone: '07700000000' });
    assert.equal(JSON.stringify(known), JSON.stringify(unknown));
    assert.equal(env.msg.sent.length, 1, 'only the known phone received a message');
    assert.equal(env.db.codes().length, 1);
  });

  it('every non-delivering case is indistinguishable: unknown, suspended, throttled, mixed formats', async () => {
    const env = setup();
    const r = await signUp(env);
    const answers: string[] = [];
    answers.push(JSON.stringify(await env.otp.requestPasswordReset({ phone: reg.phone }))); // delivers
    answers.push(JSON.stringify(await env.otp.requestPasswordReset({ phone: reg.phone }))); // throttled (cooldown)
    answers.push(JSON.stringify(await env.otp.requestPasswordReset({ phone: '07700000000' }))); // unknown
    answers.push(JSON.stringify(await env.otp.requestPasswordReset({ phone: '+964 770 000 0000' }))); // unknown, other format
    env.db.setStatus(r.user.id, 'suspended');
    env.clock.advanceSeconds(OTP.cooldownSeconds + 1);
    answers.push(JSON.stringify(await env.otp.requestPasswordReset({ phone: reg.phone }))); // suspended
    assert.equal(new Set(answers).size, 1, answers.join(' | '));
    assert.equal(env.msg.sent.length, 1);
  });

  it('malformed input is a validation failure (it reveals nothing about any account)', async () => {
    const env = setup();
    await signUp(env);
    for (const body of [null, {}, { phone: 'abc' }, { phone: 5 }, { phone: reg.phone, extra: 1 }]) assert.equal((await failure(env.otp.requestPasswordReset(body))).code, 'validation_failed');
    assert.equal(env.msg.sent.length, 0);
  });

  it('requesting never changes anything about the account: password, sessions and phone state stay as they were', async () => {
    const env = setup();
    const r = await signUp(env);
    const before = env.db.users()[0]!.passwordHash;
    await env.otp.requestPasswordReset({ phone: reg.phone });
    assert.equal(env.db.users()[0]?.passwordHash, before);
    assert.ok(await env.auth.authenticate(r.session.accessToken), 'the user stays logged in');
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);
  });
});

describe('password recovery: resetting', () => {
  async function pending() {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPasswordReset({ phone: reg.phone });
    return { env, r, code: env.msg.lastCode(PHONE, 'password_reset')! };
  }

  it('a valid code sets the new password: the new one works, the old one does not', async () => {
    const { env, r, code } = await pending();
    assert.deepEqual(await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD }), { status: 'password_reset' });
    assert.equal((await env.auth.login({ phone: reg.phone, password: NEW_PASSWORD })).user.id, r.user.id);
    assert.equal((await failure(env.auth.login({ phone: reg.phone, password: PASSWORD }))).code, 'invalid_credentials');
    assert.ok(env.db.users()[0]!.passwordHash.startsWith('$argon2id$'), 'hashed with the existing password hasher');
    assert.ok(!env.db.dump().includes(NEW_PASSWORD) && !env.db.dump().includes(PASSWORD));
    assert.ok(env.db.codes()[0]?.consumedAt instanceof Date);
  });

  it('ends EVERY session: access tokens (immediately) and refresh tokens, across all of the user\'s logins', async () => {
    const { env, r, code } = await pending();
    const second = await env.auth.login({ phone: reg.phone, password: PASSWORD });
    assert.ok(await env.auth.authenticate(second.session.accessToken));
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD });
    for (const s of [r.session, second.session]) {
      await nobodyLoggedIn(env, s.accessToken);
      assert.equal((await failure(env.auth.refresh({ refreshToken: s.refreshToken }))).code, 'unauthorized');
    }
    assert.ok(env.db.sessions().every((s) => s.revokedAt !== null && s.revokedReason === 'password_changed'));
    const fresh = await env.auth.login({ phone: reg.phone, password: NEW_PASSWORD });
    assert.ok(await env.auth.authenticate(fresh.session.accessToken), 'a session created AFTER the reset works');
  });

  it('clears the login lockout, so a locked-out user can recover', async () => {
    const { env, code } = await pending();
    for (let i = 0; i < LOGIN_MAX_FAILURES; i++) await env.auth.login({ phone: reg.phone, password: 'wrong-' + i }).catch(() => undefined);
    assert.equal(env.db.users()[0]?.locked, true);
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD });
    assert.equal(env.db.users()[0]?.locked, false);
    assert.equal(env.db.users()[0]?.failedLogins, 0);
    assert.ok(await env.auth.login({ phone: reg.phone, password: NEW_PASSWORD }));
  });

  it('a wrong code changes nothing, counts an attempt, and does NOT run the (slow) password hash', async () => {
    const { env, code } = await pending();
    const hashesBefore = env.calls.hash;
    const e = await failure(env.otp.resetPassword({ phone: reg.phone, code: other(code), newPassword: NEW_PASSWORD }));
    assert.equal(e.code, 'invalid_code');
    assert.equal(env.calls.hash, hashesBefore, 'garbage cannot be used to burn CPU on argon2');
    assert.equal(env.db.counters.passwordResets, 0);
    assert.equal(env.db.codes()[0]?.attempts, 1);
    assert.ok(await env.auth.login({ phone: reg.phone, password: PASSWORD }), 'the old password still works');
  });

  it('an expired code is refused', async () => {
    const { env, code } = await pending();
    env.clock.advanceSeconds(OTP.ttlSeconds + 1);
    assert.equal((await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD }))).code, 'invalid_code');
    assert.equal(env.db.counters.passwordResets, 0);
  });

  it('a completed recovery cannot be replayed: the code is single use', async () => {
    const { env, code } = await pending();
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD });
    const mid = await env.auth.login({ phone: reg.phone, password: NEW_PASSWORD });
    const e = await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword: 'Attacker-Chosen-1' }));
    assert.equal(e.code, 'invalid_code');
    assert.equal(env.db.counters.passwordResets, 1);
    assert.ok(await env.auth.login({ phone: reg.phone, password: NEW_PASSWORD }), 'the password the owner chose is still the password');
    assert.equal((await failure(env.auth.login({ phone: reg.phone, password: 'Attacker-Chosen-1' }))).code, 'invalid_credentials');
    assert.ok(await env.auth.authenticate(mid.session.accessToken), 'the failed replay does not log anyone out');
  });

  it('a weak password is a validation failure BEFORE the code is examined: no attempt is burned and the code still works', async () => {
    const { env, code } = await pending();
    const verifiesBefore = env.db.counters.otpVerify;
    for (const newPassword of ['12345', '', 'x'.repeat(129), 'ab\u0000cd12', 12345]) {
      const e = await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword }));
      assert.equal(e.code, 'validation_failed');
      assert.ok(e.fields?.some((f) => f.field === 'newPassword'));
    }
    assert.equal(env.db.counters.otpVerify, verifiesBefore, 'the code was never looked at');
    assert.equal(env.db.codes()[0]?.attempts, 0);
    assert.deepEqual(await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD }), { status: 'password_reset' });
  });

  it('the minimum and maximum password lengths of the existing policy are accepted', async () => {
    for (const pw of ['123456', 'x'.repeat(128)]) {
      const { env, code } = await pending();
      assert.deepEqual(await env.otp.resetPassword({ phone: reg.phone, code, newPassword: pw }), { status: 'password_reset' });
    }
  });

  it('five wrong codes exhaust it: the correct code is then refused and the password is unchanged', async () => {
    const { env, code } = await pending();
    for (let i = 0; i < OTP.maxAttempts; i++) await failure(env.otp.resetPassword({ phone: reg.phone, code: other(code), newPassword: NEW_PASSWORD }));
    assert.equal((await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD }))).code, 'invalid_code');
    assert.equal(env.db.counters.passwordResets, 0);
    assert.ok(await env.auth.login({ phone: reg.phone, password: PASSWORD }));
  });

  it('every failure is the SAME error: unknown phone, wrong code, expired, used, wrong purpose, suspended', async () => {
    const shapes: Record<string, string> = {};
    const base = await pending();
    shapes['wrong code'] = shape(await failure(base.env.otp.resetPassword({ phone: reg.phone, code: other(base.code), newPassword: NEW_PASSWORD })));
    shapes['unknown phone'] = shape(await failure(base.env.otp.resetPassword({ phone: '07700000000', code: base.code, newPassword: NEW_PASSWORD })));
    const expired = await pending();
    expired.env.clock.advanceSeconds(OTP.ttlSeconds + 1);
    shapes['expired'] = shape(await failure(expired.env.otp.resetPassword({ phone: reg.phone, code: expired.code, newPassword: NEW_PASSWORD })));
    const used = await pending();
    await used.env.otp.resetPassword({ phone: reg.phone, code: used.code, newPassword: NEW_PASSWORD });
    shapes['used'] = shape(await failure(used.env.otp.resetPassword({ phone: reg.phone, code: used.code, newPassword: NEW_PASSWORD })));
    const purpose = await pending();
    await purpose.env.otp.requestPhoneVerification(purpose.r.user.id);
    shapes['wrong purpose'] = shape(await failure(purpose.env.otp.resetPassword({ phone: reg.phone, code: purpose.env.msg.lastCode(PHONE, 'phone_verify')!, newPassword: NEW_PASSWORD })));
    const susp = await pending();
    susp.env.db.setStatus(susp.r.user.id, 'suspended');
    shapes['suspended'] = shape(await failure(susp.env.otp.resetPassword({ phone: reg.phone, code: susp.code, newPassword: NEW_PASSWORD })));
    assert.equal(new Set(Object.values(shapes)).size, 1, JSON.stringify(shapes));
    assert.equal(JSON.parse(Object.values(shapes)[0] as string).code, 'invalid_code');
  });

  it('a suspended account cannot recover, even holding a code issued before the suspension', async () => {
    const { env, r, code } = await pending();
    env.db.setStatus(r.user.id, 'suspended');
    assert.equal((await failure(env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD }))).code, 'invalid_code');
    assert.equal(env.db.counters.passwordResets, 0);
  });

  it('two simultaneous resets with the same code: exactly one wins, and the password is the winner\'s', async () => {
    const { env, code } = await pending();
    const results = await Promise.allSettled([
      env.otp.resetPassword({ phone: reg.phone, code, newPassword: 'First-Candidate-1' }),
      env.otp.resetPassword({ phone: reg.phone, code, newPassword: 'Second-Candidate-2' }),
    ]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.equal(results.filter((x) => x.status === 'rejected' && (x.reason as AuthError).code === 'invalid_code').length, 1);
    assert.equal(env.db.counters.passwordResets, 1);
    const winner = results[0]?.status === 'fulfilled' ? 'First-Candidate-1' : 'Second-Candidate-2';
    const loser = winner === 'First-Candidate-1' ? 'Second-Candidate-2' : 'First-Candidate-1';
    assert.ok(await env.auth.login({ phone: reg.phone, password: winner }));
    assert.equal((await failure(env.auth.login({ phone: reg.phone, password: loser }))).code, 'invalid_credentials');
  });

  it('recovery does not mark the phone verified (the two states stay independent)', async () => {
    const { env, code } = await pending();
    await env.otp.resetPassword({ phone: reg.phone, code, newPassword: NEW_PASSWORD });
    assert.equal(env.db.users()[0]?.phoneVerifiedAt, null);
  });

  it('recovery works the same for a phone-verified user', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    await env.otp.confirmPhoneVerification(r.user.id, { code: env.msg.lastCode(PHONE, 'phone_verify')! });
    await env.otp.requestPasswordReset({ phone: reg.phone });
    await env.otp.resetPassword({ phone: reg.phone, code: env.msg.lastCode(PHONE, 'password_reset')!, newPassword: NEW_PASSWORD });
    assert.ok(await env.auth.login({ phone: reg.phone, password: NEW_PASSWORD }));
    assert.equal(env.db.users()[0]?.phoneVerifiedAt instanceof Date, true, 'verification state is untouched');
  });

  it('malformed input never touches the database', async () => {
    const { env } = await pending();
    const before = env.db.counters.otpVerify;
    for (const body of [null, {}, { phone: reg.phone, code: '123456' }, { phone: reg.phone, newPassword: NEW_PASSWORD }, { code: '123456', newPassword: NEW_PASSWORD }, { phone: reg.phone, code: '12', newPassword: NEW_PASSWORD }, { phone: reg.phone, code: '123456', newPassword: NEW_PASSWORD, userId: '1' }]) {
      assert.equal((await failure(env.otp.resetPassword(body))).code, 'validation_failed');
    }
    assert.equal(env.db.counters.otpVerify, before);
  });
});

describe('nothing secret is ever logged, stored or returned', () => {
  it('across the whole flow: no code, password, phone number, hash, token or secret in the logs', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const verifyCode = env.msg.lastCode(PHONE, 'phone_verify')!;
    await env.otp.confirmPhoneVerification(r.user.id, { code: other(verifyCode) }).catch(() => undefined);
    await env.otp.confirmPhoneVerification(r.user.id, { code: verifyCode });
    await env.otp.requestPasswordReset({ phone: reg.phone });
    await env.otp.requestPasswordReset({ phone: '07700000000' });
    const resetCode = env.msg.lastCode(PHONE, 'password_reset')!;
    await env.otp.resetPassword({ phone: reg.phone, code: other(resetCode), newPassword: NEW_PASSWORD }).catch(() => undefined);
    await env.otp.resetPassword({ phone: reg.phone, code: resetCode, newPassword: NEW_PASSWORD });
    await env.otp.resetPassword({ phone: reg.phone, code: resetCode, newPassword: NEW_PASSWORD }).catch(() => undefined); // replay
    env.msg.failNext();
    env.clock.advanceSeconds(3700);
    await env.otp.requestPasswordReset({ phone: reg.phone });
    await new Promise((resolve) => setImmediate(resolve));
    const text = env.log.text();
    for (const secret of [verifyCode, resetCode, other(verifyCode), PASSWORD, NEW_PASSWORD, '$argon2', 'nsj_', 'eyJ', SECRET, '9647701234567', '07701234567', '07700000000', 'علي']) {
      assert.ok(!text.includes(secret), `the log must not contain ${secret}`);
    }
    assert.ok(text.includes('auth.phone.verified') && text.includes('auth.password_reset.completed') && text.includes('auth.otp.rejected'));
  });

  it('no error carries a code, a password, a phone number or a hash', async () => {
    const { env, code } = await (async () => {
      const e = setup();
      await signUp(e);
      await e.otp.requestPasswordReset({ phone: reg.phone });
      return { env: e, code: e.msg.lastCode(PHONE, 'password_reset')! };
    })();
    const errors = [
      await failure(env.otp.resetPassword({ phone: reg.phone, code: other(code), newPassword: NEW_PASSWORD })),
      await failure(env.otp.resetPassword({ phone: '07700000000', code, newPassword: NEW_PASSWORD })),
      await failure(env.otp.resetPassword({ phone: reg.phone, code: 'abc', newPassword: 'x' })),
    ];
    for (const e of errors) {
      const text = JSON.stringify({ m: e.message, f: e.fields });
      for (const secret of [code, other(code), NEW_PASSWORD, '9647701234567', '07700000000', '$argon2', 'abc']) assert.ok(!text.includes(secret), secret);
    }
  });

  it('results never contain the code or the password, and only hashes are stored', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    const out = JSON.stringify(await env.otp.confirmPhoneVerification(r.user.id, { code }));
    assert.ok(!out.includes(code) && !out.includes(PASSWORD) && !out.includes('$argon2') && !/password|hash|code/i.test(out));
    assert.ok(!env.db.dump().includes(code));
  });
});

describe('construction', () => {
  it('refuses a weak secret', () => {
    const { db } = setup();
    for (const otpSecret of ['', 'short', 'x'.repeat(31)]) {
      assert.throws(() => createOtpService({ store: db.store, hasher: makeFakeHasher().hasher, provider: makeFakeProvider().provider, otpSecret }), /at least 32 characters/);
    }
  });

  it('codes are bound to the server secret: a service with another secret cannot verify them', async () => {
    const env = setup();
    const r = await signUp(env);
    await env.otp.requestPhoneVerification(r.user.id);
    const code = env.msg.lastCode(PHONE, 'phone_verify')!;
    const other = createOtpService({ store: env.db.store, hasher: makeFakeHasher().hasher, provider: makeFakeProvider().provider, otpSecret: 'a-different-otp-secret-0123456789-abcdefghijkl' });
    assert.equal((await failure(other.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
    assert.equal((await env.otp.confirmPhoneVerification(r.user.id, { code })).phoneVerified, true);
  });
});

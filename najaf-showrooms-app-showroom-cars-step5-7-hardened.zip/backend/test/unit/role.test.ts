import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ROLE_QUERY, RoleError, assertAppRole, parseRoleRow, roleViolations } from '../../src/role.ts';
import type { RoleReport } from '../../src/role.ts';

const good: RoleReport = {
  currentUser: 'najaf_app_login',
  sessionUser: 'najaf_app_login',
  database: 'najaf',
  isSuperuser: false,
  canCreateRole: false,
  canCreateDb: false,
  isReplication: false,
  bypassRls: false,
  isAppMember: true,
  serverVersionNum: 160013,
};

describe('role policy', () => {
  it('accepts a least-privilege member of najaf_app on PostgreSQL 16', () => {
    assert.deepEqual(roleViolations(good), []);
    assert.doesNotThrow(() => assertAppRole(good));
  });

  it('reports each privileged attribute separately', () => {
    const cases: Array<[Partial<RoleReport>, string]> = [
      [{ isSuperuser: true }, 'superuser'],
      [{ canCreateRole: true }, 'create roles'],
      [{ canCreateDb: true }, 'create databases'],
      [{ isReplication: true }, 'replication'],
      [{ bypassRls: true }, 'row-level security'],
      [{ isAppMember: false }, 'not a member of najaf_app'],
      [{ serverVersionNum: 150004 }, 'older than the supported 16'],
    ];
    for (const [patch, text] of cases) {
      const v = roleViolations({ ...good, ...patch });
      assert.equal(v.length, 1, text);
      assert.ok(v[0]?.includes(text), text);
    }
  });

  it('assertAppRole throws a RoleError listing every violation', () => {
    const bad = { ...good, currentUser: 'postgres', isSuperuser: true, canCreateRole: true, canCreateDb: true, isAppMember: true };
    assert.throws(
      () => assertAppRole(bad),
      (e: unknown) => e instanceof RoleError && e.violations.length === 3 && e.message.includes('postgres'),
    );
  });

  it('a superuser is rejected even though it is implicitly a member of every role', () => {
    const su = { ...good, currentUser: 'postgres', isSuperuser: true, isAppMember: true };
    assert.ok(roleViolations(su).some((m) => m.includes('superuser')));
  });
});

describe('role query parsing', () => {
  it('parses a catalog row', () => {
    const r = parseRoleRow({
      cur_user: 'najaf_app_login',
      sess_user: 'najaf_app_login',
      db_name: 'najaf',
      is_super: false,
      can_create_role: false,
      can_create_db: false,
      is_replication: false,
      bypass_rls: false,
      is_app_member: true,
      server_version_num: '160013',
    });
    assert.deepEqual(r, good);
  });

  it('treats anything but boolean true as false (fail closed on the privilege flags it reads)', () => {
    const r = parseRoleRow({ cur_user: 'x', sess_user: 'x', db_name: 'd', is_super: 't', server_version_num: 160000 });
    assert.equal(r.isSuperuser, false);
    assert.equal(r.isAppMember, false);
  });

  it('throws when the role row is missing', () => {
    assert.throws(() => parseRoleRow(undefined), /no row/);
  });

  it('the query is a single read-only statement that tolerates a missing najaf_app role', () => {
    assert.ok(!ROLE_QUERY.includes(';'));
    assert.ok(/^\s*SELECT/i.test(ROLE_QUERY));
    assert.ok(ROLE_QUERY.includes('FROM pg_roles'));
    assert.ok(ROLE_QUERY.includes("rolname = 'najaf_app'"));
    for (const word of ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER']) assert.ok(!new RegExp(`\\b${word}\\b`).test(ROLE_QUERY), word);
  });
});

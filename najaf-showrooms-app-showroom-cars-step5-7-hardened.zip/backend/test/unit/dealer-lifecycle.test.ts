// Phase 11.5, Step 5.2: dealer lifecycle, end to end through the REAL authentication service, the REAL policy layer (src/authz)
// and the REAL dealer service, over the in-memory store (which mirrors the SQL and the database triggers). The SQL itself is
// exercised against PostgreSQL 16 in test/integration/dealers.integration.test.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createAccountService } from '../../src/auth/account-service.ts';
import { createOtpService } from '../../src/auth/otp-service.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthError } from '../../src/auth/types.ts';
import { AuthzError, can, dealerDirectoryResource, isPublic, loadActor, showroomResource, toActor } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { DealerError, createDealerService, showroomNameFor } from '../../src/dealers/service.ts';
import { makeClock, makeFakeAuthStore, makeFakeHasher, recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeProvider } from '../helpers/fake-messaging.ts';

const SECRET = 'unit-test-access-secret-0123456789abcdef-XYZ';
const PW = 'Corr3ct-Horse-Battery';

function setup() {
  const clock = makeClock();
  const db = makeFakeAuthStore(clock);
  const { hasher } = makeFakeHasher();
  const log = recordingLogger();
  const auth = createAuthService({ store: db.store, hasher, accessTokenSecret: SECRET, logger: log.logger, now: clock.now });
  const dealers = createDealerService({ store: db.dealerStore, logger: log.logger });
  const adminId = db.addUser({ role: 'admin', status: 'active', name: 'مدير النظام' });
  const admin: Actor = { id: adminId, role: 'admin' };
  let n = 0;
  const phone = () => `0770${String(1000000 + ++n).slice(-7)}`;
  async function applyDealer(name = 'حسين التاجر') {
    const p = phone();
    const r = await auth.registerDealer({ name, phone: p, password: PW });
    return { id: r.user.id, phone: p, token: r.session.accessToken, refreshToken: r.session.refreshToken, result: r };
  }
  async function member() {
    const p = phone();
    const r = await auth.register({ name: 'عضو عادي', phone: p, password: PW });
    return { id: r.user.id, phone: p, token: r.session.accessToken };
  }
  async function activeDealer(name?: string) {
    const d = await applyDealer(name);
    await dealers.approve(admin, d.id);
    const login = await auth.login({ phone: d.phone, password: PW });
    return { ...d, token: login.session.accessToken, refreshToken: login.session.refreshToken };
  }
  const user = (id: string) => db.users().find((u) => u.id === id)!;
  const actorOf = (token: string) => loadActor(auth, token);
  return { clock, db, hasher, log, auth, dealers, admin, adminId, applyDealer, member, activeDealer, user, actorOf, phone };
}

async function failure(p: Promise<unknown>): Promise<Error> {
  try {
    await p;
  } catch (e) {
    return e as Error;
  }
  throw new Error('expected a failure');
}
const codeOf = async (p: Promise<unknown>) => {
  const e = await failure(p);
  if (e instanceof AuthzError || e instanceof DealerError || e instanceof AuthError) return e.code;
  throw e;
};

describe('dealer registration (application)', () => {
  it('creates a PENDING DEALER account, signs it in, and creates NO showroom', async () => {
    const s = setup();
    const d = await s.applyDealer('حسين التاجر');
    assert.equal(d.result.user.role, 'dealer');
    assert.equal(d.result.user.status, 'pending');
    assert.deepEqual(Object.keys(d.result.user).sort(), ['createdAt', 'id', 'name', 'phone', 'phoneVerified', 'role', 'status']);
    assert.equal(s.user(d.id).role, 'dealer');
    assert.equal(s.user(d.id).status, 'pending');
    assert.equal(s.db.showrooms().length, 0, 'the showroom is created by the approval, not by the application');
    assert.equal(s.db.sessions().filter((x) => x.userId === d.id).length, 1);
    assert.ok(s.log.text().includes('dealer.applied'));
    assert.ok(!s.log.text().includes(PW));
  });

  it('role, status, accountType or any other extra field cannot be submitted: rejected, nothing created', async () => {
    const s = setup();
    for (const extra of [{ role: 'admin' }, { role: 'dealer' }, { status: 'active' }, { accountType: 'admin' }, { showroomId: '1' }, { ownerId: '1' }]) {
      const before = s.db.users().length;
      const e = await failure(s.auth.registerDealer({ name: 'حسين التاجر', phone: s.phone(), password: PW, ...extra }));
      assert.ok(e instanceof AuthError && e.code === 'validation_failed', JSON.stringify(extra));
      assert.deepEqual(e.fields, [{ field: Object.keys(extra)[0], code: 'unknown_field' }]);
      assert.equal(s.db.users().length, before);
    }
  });

  it('the same validation and password policy as member registration', async () => {
    const s = setup();
    for (const body of [null, 'x', [], {}, { name: 'ab', phone: s.phone(), password: PW }, { name: 'اسم صحيح', phone: '123', password: PW }, { name: 'اسم صحيح', phone: s.phone(), password: '123' }]) {
      assert.equal(await codeOf(s.auth.registerDealer(body)), 'validation_failed', JSON.stringify(body));
    }
    assert.equal(s.db.users().length, 1, 'only the admin fixture');
  });

  it('a phone number already registered (as member or dealer) is the same generic conflict, and nothing is created', async () => {
    const s = setup();
    const m = await s.member();
    const d = await s.applyDealer();
    assert.equal(await codeOf(s.auth.registerDealer({ name: 'تاجر آخر', phone: m.phone, password: PW })), 'conflict');
    assert.equal(await codeOf(s.auth.registerDealer({ name: 'تاجر آخر', phone: d.phone, password: PW })), 'conflict');
    assert.equal(await codeOf(s.auth.register({ name: 'عضو آخر', phone: d.phone, password: PW })), 'conflict');
    assert.equal(s.db.users().length, 3);
  });

  it('member registration is unchanged: still an ACTIVE regular user', async () => {
    const s = setup();
    const r = await s.auth.register({ name: 'عضو عادي', phone: s.phone(), password: PW });
    assert.equal(r.user.role, 'user');
    assert.equal(r.user.status, 'active');
    assert.deepEqual(await s.actorOf(r.session.accessToken), { id: r.user.id, role: 'member' });
  });
});

describe('pending dealer: may authenticate, has NO dealer (or any other) powers', () => {
  it('account self-service: change password and sign out everywhere work; the one-time-code flows REFUSE a pending dealer (fail-closed, OTP files frozen)', async () => {
    const s = setup();
    const messaging = makeFakeProvider();
    const otp = createOtpService({ store: s.db.store, hasher: s.hasher, provider: messaging.provider, otpSecret: SECRET, logger: s.log.logger });
    const account = createAccountService({ store: s.db.store, hasher: s.hasher, logger: s.log.logger });
    const d = await s.applyDealer();
    assert.equal(await codeOf(otp.requestPhoneVerification(d.id)), 'unauthorized');
    assert.equal(await codeOf(otp.confirmPhoneVerification(d.id, { code: '123456' })), 'unauthorized');
    assert.deepEqual(await otp.requestPasswordReset({ phone: d.phone }), { status: 'accepted' }, 'recovery stays non-enumerating');
    assert.equal(messaging.sent.length, 0, 'no code is sent to a pending dealer');
    assert.deepEqual(await account.changePassword(d.id, { currentPassword: PW, newPassword: 'Another-Pass-2' }), { status: 'password_changed' });
    await s.auth.login({ phone: d.phone, password: 'Another-Pass-2' });
    assert.deepEqual(await account.logoutAll(d.id), { status: 'signed_out_everywhere' });
    assert.equal(s.user(d.id).status, 'pending', 'none of this changes the account state');
  });

  it('pending dealer: may authenticate (sign-in, refresh, session lookup) but has NO Actor and no dealer powers', async () => {
    const s = setup();
    const d = await s.applyDealer();
    const login = await s.auth.login({ phone: d.phone, password: PW });
    assert.equal(login.user.status, 'pending');
    const refreshed = await s.auth.refresh({ refreshToken: login.session.refreshToken });
    const found = await s.auth.authenticate(refreshed.session.accessToken);
    assert.equal(found?.user.role, 'dealer');
    assert.equal(found?.user.status, 'pending');
    assert.equal(toActor(found!.user), null, 'authentication is not authorization');
    assert.equal(await s.actorOf(refreshed.session.accessToken), null);
  });

  it('every dealer-only and admin-only decision denies it with 404, and no dealer row is touched', async () => {
    const s = setup();
    const d = await s.applyDealer();
    const other = await s.applyDealer('تاجر آخر');
    const actor = await s.actorOf(d.token);
    assert.equal(await codeOf(s.dealers.getOwnShowroom(actor)), 'not_found');
    assert.equal(await codeOf(s.dealers.listDealers(actor, {})), 'not_found');
    for (const target of [d.id, other.id]) for (const act of ['approve', 'reject', 'suspend', 'reactivate'] as const) assert.equal(await codeOf(s.dealers[act](actor, target)), 'not_found');
    // it cannot even forge its way in: an actor object CLAIMING dealer or admin is re-checked against the database
    assert.equal(await codeOf(s.dealers.approve({ id: d.id, role: 'admin' }, d.id)), 'not_found');
    assert.equal(s.user(d.id).status, 'pending');
    assert.equal(s.db.showrooms().length, 0);
    assert.equal(s.db.audits().length, 0);
  });

  it('a pending NON-dealer (impossible in the database) and suspended or deleted accounts still cannot authenticate', async () => {
    const s = setup();
    const m = await s.member();
    s.db.setStatus(m.id, 'pending');
    assert.equal(await s.auth.authenticate(m.token), null);
    assert.equal(await codeOf(s.auth.login({ phone: m.phone, password: PW })), 'invalid_credentials');
    const d = await s.applyDealer();
    s.db.users().find((u) => u.id === d.id)!.deletedAt = new Date();
    assert.equal(await s.auth.authenticate(d.token), null);
    assert.equal(await codeOf(s.auth.refresh({ refreshToken: d.refreshToken })), 'unauthorized');
  });
});

describe('approval', () => {
  it('pending -> active, creates ONE active showroom from the dealer row, audits it, and the SAME token now carries dealer powers', async () => {
    const s = setup();
    const d = await s.applyDealer('حسين التاجر');
    assert.equal(await s.actorOf(d.token), null);
    const out = await s.dealers.approve(s.admin, d.id, { requestId: 'approve-req-1' });
    assert.equal(out.status, 'active');
    assert.deepEqual(Object.keys(out).sort(), ['createdAt', 'id', 'name', 'phone', 'phoneVerified', 'showroom', 'status']);
    assert.equal(s.user(d.id).status, 'active');
    assert.equal(s.user(d.id).role, 'dealer', 'the role never changes');
    const rooms = s.db.showrooms();
    assert.equal(rooms.length, 1);
    assert.deepEqual({ owner: rooms[0]!.ownerId, name: rooms[0]!.name, status: rooms[0]!.status, phone: rooms[0]!.phone, wa: rooms[0]!.whatsapp, by: rooms[0]!.reviewedBy },
      { owner: d.id, name: 'معرض حسين التاجر', status: 'active', phone: s.user(d.id).phoneE164, wa: s.user(d.id).phoneE164, by: s.adminId });
    assert.deepEqual(out.showroom, { id: rooms[0]!.id, status: 'active' });
    const audits = s.db.audits();
    assert.equal(audits.length, 1);
    assert.deepEqual({ a: audits[0]!.action, actor: audits[0]!.actorUserId, role: audits[0]!.actorRole, type: audits[0]!.entityType, id: audits[0]!.entityId, data: audits[0]!.afterData, req: audits[0]!.requestId },
      { a: 'dealer.approve', actor: s.adminId, role: 'admin', type: 'user', id: d.id, data: { showroom_id: Number(rooms[0]!.id), showroom_created: 1 }, req: 'approve-req-1' });
    // the dealer did not have to sign in again: the role/status are re-read on every request
    const actor = await s.actorOf(d.token);
    assert.deepEqual(actor, { id: d.id, role: 'dealer' });
    const own = await s.dealers.getOwnShowroom(actor);
    assert.equal(own.id, rooms[0]!.id);
    assert.equal(own.status, 'active');
    assert.ok(isPublic(showroomResource({ ownerId: d.id, status: own.status, ownerActive: true })));
  });

  it('approving again, or approving an active/suspended dealer, is 409 and changes nothing', async () => {
    const s = setup();
    const d = await s.applyDealer();
    await s.dealers.approve(s.admin, d.id);
    const snapshot = JSON.stringify({ u: s.db.users(), r: s.db.showrooms(), a: s.db.audits() });
    assert.equal(await codeOf(s.dealers.approve(s.admin, d.id)), 'invalid_state');
    assert.equal(JSON.stringify({ u: s.db.users(), r: s.db.showrooms(), a: s.db.audits() }), snapshot, 'a refused transition writes nothing');
    await s.dealers.suspend(s.admin, d.id);
    const n = s.db.audits().length;
    assert.equal(await codeOf(s.dealers.approve(s.admin, d.id)), 'invalid_state');
    assert.equal(s.db.audits().length, n);
    assert.equal(s.user(d.id).status, 'suspended');
  });

  it('an operations-created PENDING showroom is approved, not duplicated; a showroom suspended by an admin stays suspended', async () => {
    const s = setup();
    const d = await s.applyDealer();
    const roomId = s.db.addShowroom({ ownerId: d.id, status: 'pending' });
    const out = await s.dealers.approve(s.admin, d.id);
    assert.deepEqual(out.showroom, { id: roomId, status: 'active' });
    assert.equal(s.db.showrooms().length, 1);
    assert.deepEqual(s.db.audits()[0]!.afterData, { showroom_id: Number(roomId), showroom_created: 0 });

    const d2 = await s.applyDealer('تاجر ثان');
    const room2 = s.db.addShowroom({ ownerId: d2.id, status: 'suspended' });
    const out2 = await s.dealers.approve(s.admin, d2.id);
    assert.deepEqual(out2.showroom, { id: room2, status: 'suspended' }, 'showroom moderation is a separate decision');
  });

  it('two approvals of the same application: exactly one succeeds, one showroom, one audit row', async () => {
    const s = setup();
    const d = await s.applyDealer();
    const results = await Promise.allSettled([s.dealers.approve(s.admin, d.id), s.dealers.approve(s.admin, d.id)]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    const rejected = results.find((r) => r.status === 'rejected') as PromiseRejectedResult;
    assert.ok(rejected.reason instanceof DealerError && rejected.reason.code === 'invalid_state');
    assert.equal(s.db.showrooms().length, 1);
    assert.equal(s.db.audits().length, 1);
  });

  it('losing the UNIQUE(owner_id) race to another insert uses the winning row instead of failing', async () => {
    const s = setup();
    const d = await s.applyDealer();
    s.db.dealerFaults.showroomConflictOnce = true;
    const out = await s.dealers.approve(s.admin, d.id);
    assert.equal(s.db.showrooms().length, 1);
    assert.equal(out.showroom?.id, s.db.showrooms()[0]!.id);
    assert.equal(s.db.audits()[0]!.afterData['showroom_created'], 0);
  });

  it('ALL OR NOTHING: if the showroom or the audit row cannot be written, the account stays pending and nothing remains', async () => {
    const s = setup();
    const d = await s.applyDealer();
    s.db.dealerFaults.failNextShowroomCreate = true;
    await failure(s.dealers.approve(s.admin, d.id));
    assert.equal(s.user(d.id).status, 'pending');
    assert.equal(s.db.showrooms().length, 0);
    s.db.faults.failNextAudit = true;
    await failure(s.dealers.approve(s.admin, d.id));
    assert.equal(s.user(d.id).status, 'pending');
    assert.equal(s.db.showrooms().length, 0);
    assert.equal(s.db.audits().length, 0);
    await s.dealers.approve(s.admin, d.id); // and it still works afterwards
    assert.equal(s.user(d.id).status, 'active');
  });

  it('the prototype showroom name', () => {
    assert.equal(showroomNameFor('حسين'), 'معرض حسين');
    assert.equal(showroomNameFor('  علي  '), 'معرض علي');
    assert.equal(showroomNameFor(''), 'معرض جديد');
  });
});

describe('rejection, suspension and reactivation', () => {
  it('reject: pending -> suspended, every session ends at once, no showroom, audited with the revocation count', async () => {
    const s = setup();
    const d = await s.applyDealer();
    await s.auth.login({ phone: d.phone, password: PW });
    const out = await s.dealers.reject(s.admin, d.id, { requestId: 'reject-req-1' });
    assert.equal(out.status, 'suspended');
    assert.equal(out.showroom, null);
    assert.equal(s.user(d.id).status, 'suspended');
    assert.equal(s.db.showrooms().length, 0);
    assert.ok(s.db.sessions().filter((x) => x.userId === d.id).every((x) => x.revokedAt !== null));
    assert.equal(await s.auth.authenticate(d.token), null);
    assert.equal(await codeOf(s.auth.refresh({ refreshToken: d.refreshToken })), 'unauthorized');
    assert.equal(await codeOf(s.auth.login({ phone: d.phone, password: PW })), 'invalid_credentials');
    const a = s.db.audits()[0]!;
    assert.deepEqual({ a: a.action, id: a.entityId, data: a.afterData, req: a.requestId }, { a: 'dealer.reject', id: d.id, data: { sessions_revoked: 2 }, req: 'reject-req-1' });
    assert.equal(await codeOf(s.dealers.reject(s.admin, d.id)), 'invalid_state', 'only a pending application can be rejected');
  });

  it('suspend: active -> suspended, sessions end, the showroom row is untouched but no longer public', async () => {
    const s = setup();
    const d = await s.activeDealer();
    const before = { ...s.db.showrooms()[0]! };
    const out = await s.dealers.suspend(s.admin, d.id);
    assert.equal(out.status, 'suspended');
    assert.equal(s.user(d.id).status, 'suspended');
    assert.equal(await s.auth.authenticate(d.token), null);
    assert.deepEqual(s.db.showrooms()[0], before, 'showroom moderation is a separate decision');
    assert.equal(isPublic(showroomResource({ ownerId: d.id, status: before.status, ownerActive: false })), false, 'the public view hides a suspended owner');
    assert.equal(s.db.audits().at(-1)!.action, 'dealer.suspend');
    assert.equal(await codeOf(s.dealers.suspend(s.admin, d.id)), 'invalid_state');
    assert.equal(await codeOf(s.dealers.suspend(s.admin, (await s.applyDealer('معلق')).id)), 'invalid_state', 'a pending application is rejected, not suspended');
  });

  it('reactivate: suspended -> active, the SAME showroom comes back, revoked sessions stay dead (no resurrection)', async () => {
    const s = setup();
    const d = await s.activeDealer();
    const room = s.db.showrooms()[0]!.id;
    await s.dealers.suspend(s.admin, d.id);
    const out = await s.dealers.reactivate(s.admin, d.id, { requestId: 'reactivate-1' });
    assert.equal(out.status, 'active');
    assert.deepEqual(out.showroom, { id: room, status: 'active' });
    assert.equal(s.db.showrooms().length, 1);
    assert.equal(await s.auth.authenticate(d.token), null, 'the token from before the suspension does not come back');
    assert.equal(await codeOf(s.auth.refresh({ refreshToken: d.refreshToken })), 'unauthorized');
    const login = await s.auth.login({ phone: d.phone, password: PW });
    assert.deepEqual(await s.actorOf(login.session.accessToken), { id: d.id, role: 'dealer' });
    assert.deepEqual(s.db.audits().at(-1)!.afterData, { showroom_id: Number(room), showroom_created: 0 });
    assert.equal(await codeOf(s.dealers.reactivate(s.admin, d.id)), 'invalid_state');
  });

  it('a REJECTED applicant can later be reactivated: they become an approved dealer and get their showroom', async () => {
    const s = setup();
    const d = await s.applyDealer('مرفوض سابقا');
    await s.dealers.reject(s.admin, d.id);
    const out = await s.dealers.reactivate(s.admin, d.id);
    assert.equal(out.status, 'active');
    assert.equal(s.db.showrooms().length, 1);
    assert.equal(s.db.showrooms()[0]!.name, 'معرض مرفوض سابقا');
    assert.deepEqual(s.db.audits().map((a) => a.action), ['dealer.reject', 'dealer.reactivate']);
  });

  it('a pending application cannot be "reactivated" (that would skip approval)', async () => {
    const s = setup();
    const d = await s.applyDealer();
    assert.equal(await codeOf(s.dealers.reactivate(s.admin, d.id)), 'invalid_state');
    assert.equal(s.user(d.id).status, 'pending');
  });
});

describe('only an acting administrator may decide', () => {
  const ACTIONS = ['approve', 'reject', 'suspend', 'reactivate'] as const;
  it('guest, member, dealer and pending dealer get 404 (403 only for their own account), BEFORE any database access', async () => {
    const s = setup();
    const target = await s.applyDealer('الهدف');
    const m = await s.member();
    const d = await s.activeDealer('تاجر نشط');
    const p = await s.applyDealer('تاجر معلق');
    const callers: Array<[string, Actor | null, string]> = [
      ['guest', null, 'not_found'],
      ['member', await s.actorOf(m.token), 'not_found'],
      ['active dealer', await s.actorOf(d.token), 'not_found'],
      ['pending dealer', await s.actorOf(p.token), 'not_found'],
    ];
    const lockBefore = s.db.dealerCounters.lockDealer;
    const adminLockBefore = s.db.dealerCounters.lockActingAdmin;
    const auditsBefore = s.db.audits().length;
    for (const [who, actor, expected] of callers) for (const act of ACTIONS) assert.equal(await codeOf(s.dealers[act](actor, target.id)), expected, `${who} ${act}`);
    for (const act of ACTIONS) assert.equal(await codeOf(s.dealers[act](await s.actorOf(d.token), d.id)), 'forbidden', `own account ${act}`);
    assert.equal(s.db.dealerCounters.lockDealer, lockBefore, 'denied before the database is touched');
    assert.equal(s.db.dealerCounters.lockActingAdmin, adminLockBefore);
    assert.equal(s.user(target.id).status, 'pending');
    assert.equal(s.db.audits().length, auditsBefore);
  });

  it('an administrator suspended (or deleted) after authenticating cannot finish the action', async () => {
    const s = setup();
    const d = await s.applyDealer();
    s.db.setStatus(s.adminId, 'suspended');
    assert.equal(await codeOf(s.dealers.approve(s.admin, d.id)), 'not_found');
    s.db.setStatus(s.adminId, 'active');
    s.db.users().find((u) => u.id === s.adminId)!.deletedAt = new Date();
    assert.equal(await codeOf(s.dealers.approve(s.admin, d.id)), 'not_found');
    assert.equal(s.user(d.id).status, 'pending');
    assert.equal(s.db.showrooms().length, 0);
    assert.equal(s.db.audits().length, 0);
  });

  it('only DEALER accounts are targets: a member, an admin, a deleted dealer or an unknown id are 404 for the admin too', async () => {
    const s = setup();
    const m = await s.member();
    const gone = await s.applyDealer();
    s.db.users().find((u) => u.id === gone.id)!.deletedAt = new Date();
    for (const id of [m.id, s.adminId, gone.id, '999999']) for (const act of ACTIONS) assert.equal(await codeOf(s.dealers[act](s.admin, id)), 'not_found', `${act} ${id}`);
    assert.equal(s.user(m.id).role, 'user', 'approval can never turn a member into a dealer');
    assert.equal(s.user(m.id).status, 'active');
    assert.equal(s.db.showrooms().length, 0);
  });

  it('malformed ids are 404 with no database access', async () => {
    const s = setup();
    for (const id of ['', '0', '-1', '01', '1 OR 1=1', "1'; UPDATE users SET role='admin' --", '1e3', ' 1', undefined, null, 1, {}, ['1']]) {
      assert.equal(await codeOf(s.dealers.approve(s.admin, id as never)), 'not_found', JSON.stringify(id));
    }
    assert.equal(s.db.dealerCounters.lockActingAdmin, 0);
  });
});

describe('privilege escalation', () => {
  it('a forged actor object does not grant admin: the acting admin is re-checked in the database', async () => {
    const s = setup();
    const m = await s.member();
    const d = await s.applyDealer();
    for (const forged of [{ id: m.id, role: 'admin' }, { id: d.id, role: 'admin' }] as Actor[]) {
      assert.equal(await codeOf(s.dealers.approve(forged, d.id)), 'not_found');
    }
    assert.equal(s.user(d.id).status, 'pending');
    assert.equal(s.db.audits().length, 0);
  });

  it('a pending dealer cannot approve itself by any route, and approval never changes a role', async () => {
    const s = setup();
    const d = await s.applyDealer();
    assert.equal(await codeOf(s.dealers.approve(await s.actorOf(d.token), d.id)), 'not_found');
    await s.dealers.approve(s.admin, d.id);
    await s.dealers.suspend(s.admin, d.id);
    await s.dealers.reactivate(s.admin, d.id);
    assert.equal(s.user(d.id).role, 'dealer');
    assert.equal(s.user(s.adminId).role, 'admin');
  });

  it('an active dealer gets dealer powers only over their OWN showroom (policy), never admin powers', async () => {
    const s = setup();
    const d = await s.activeDealer();
    const actor = (await s.actorOf(d.token))!;
    const own = s.db.showrooms().find((r) => r.ownerId === d.id)!;
    assert.equal(can(actor, 'update', showroomResource({ ownerId: own.ownerId, status: own.status, ownerActive: true })), true);
    assert.equal(can(actor, 'moderate', showroomResource({ ownerId: own.ownerId, status: own.status, ownerActive: true })), false);
    assert.equal(await codeOf(s.dealers.listDealers(actor, {})), 'not_found');
  });
});

describe('cross-dealer access', () => {
  it("each dealer sees ONLY their own showroom; the owner is the verified caller, never a parameter", async () => {
    const s = setup();
    const a = await s.activeDealer('تاجر أ');
    const b = await s.activeDealer('تاجر ب');
    const actorA = (await s.actorOf(a.token))!;
    const actorB = (await s.actorOf(b.token))!;
    const roomA = await s.dealers.getOwnShowroom(actorA);
    const roomB = await s.dealers.getOwnShowroom(actorB);
    assert.notEqual(roomA.id, roomB.id);
    assert.equal(roomA.name, 'معرض تاجر أ');
    assert.equal(roomB.name, 'معرض تاجر ب');
    assert.equal(s.dealers.getOwnShowroom.length, 1, 'the only input is the actor');
    const rowB = s.db.showrooms().find((r) => r.ownerId === b.id)!;
    for (const action of ['read', 'update', 'delete', 'moderate'] as const) assert.equal(can(actorA, action, showroomResource({ ownerId: rowB.ownerId, status: rowB.status, ownerActive: true })), false, action);
  });

  it('a dealer cannot act on another dealer account (404, nothing changes)', async () => {
    const s = setup();
    const a = await s.activeDealer('تاجر أ');
    const b = await s.activeDealer('تاجر ب');
    const actorA = await s.actorOf(a.token);
    for (const act of ['approve', 'reject', 'suspend', 'reactivate'] as const) assert.equal(await codeOf(s.dealers[act](actorA, b.id)), 'not_found');
    assert.equal(s.user(b.id).status, 'active');
  });

  it('defense in depth: even a showroom row owned by a non-dealer (impossible: showrooms_owner_guard) is no dealer area', async () => {
    const s = setup();
    const m = await s.member();
    s.db.addShowroom({ ownerId: s.adminId, status: 'active' });
    s.db.addShowroom({ ownerId: m.id, status: 'active' });
    assert.equal(await codeOf(s.dealers.getOwnShowroom(s.admin)), 'not_found');
    assert.equal(await codeOf(s.dealers.getOwnShowroom(await s.actorOf(m.token))), 'not_found');
  });

  it('the policy also covers the administrators\' dealer directory: read by an admin only, never public', () => {
    const dir = dealerDirectoryResource();
    assert.equal(can({ id: '1', role: 'admin' }, 'read', dir), true);
    for (const a of ['update', 'delete', 'moderate'] as const) assert.equal(can({ id: '1', role: 'admin' }, a, dir), false);
    for (const actor of [null, { id: '2', role: 'dealer' }, { id: '3', role: 'member' }] as Array<Actor | null>) assert.equal(can(actor, 'read', dir), false);
    assert.equal(isPublic(dir), false);
  });

  it('a member or an admin has no "own showroom" (404); a suspended dealer cannot reach theirs', async () => {
    const s = setup();
    const m = await s.member();
    assert.equal(await codeOf(s.dealers.getOwnShowroom(await s.actorOf(m.token))), 'not_found');
    assert.equal(await codeOf(s.dealers.getOwnShowroom(s.admin)), 'not_found');
    assert.equal(await codeOf(s.dealers.getOwnShowroom(null)), 'not_found');
    const d = await s.activeDealer();
    await s.dealers.suspend(s.admin, d.id);
    assert.equal(await s.actorOf(d.token), null);
  });
});

describe('administrator listing', () => {
  it('pending applications by default, in id order, with exactly the summary fields and no secret', async () => {
    const s = setup();
    const p1 = await s.applyDealer('أول');
    const p2 = await s.applyDealer('ثان');
    const a = await s.activeDealer('نشط');
    await s.member();
    const page = await s.dealers.listDealers(s.admin, {});
    assert.deepEqual(page.dealers.map((d) => d.id), [p1.id, p2.id]);
    assert.equal(page.nextAfter, null);
    assert.deepEqual(Object.keys(page.dealers[0]!).sort(), ['createdAt', 'id', 'name', 'phone', 'phoneVerified', 'showroom', 'status']);
    assert.ok(!JSON.stringify(page).includes('argon2'));
    const active = await s.dealers.listDealers(s.admin, { status: 'active' });
    assert.deepEqual(active.dealers.map((d) => [d.id, d.showroom?.status]), [[a.id, 'active']]);
  });

  it('keyset pagination with after/limit', async () => {
    const s = setup();
    const ids: string[] = [];
    for (let i = 0; i < 5; i++) ids.push((await s.applyDealer(`تاجر ${i}`)).id);
    const first = await s.dealers.listDealers(s.admin, { limit: '2' });
    assert.deepEqual(first.dealers.map((d) => d.id), ids.slice(0, 2));
    assert.equal(first.nextAfter, ids[1]);
    const second = await s.dealers.listDealers(s.admin, { limit: '2', after: first.nextAfter! });
    assert.deepEqual(second.dealers.map((d) => d.id), ids.slice(2, 4));
    const last = await s.dealers.listDealers(s.admin, { limit: '2', after: second.nextAfter! });
    assert.deepEqual(last.dealers.map((d) => d.id), ids.slice(4));
    assert.equal(last.nextAfter, null);
  });

  it('strict query validation: unknown keys, bad status, bad limit or cursor are 400 (for an admin only)', async () => {
    const s = setup();
    for (const q of [{ role: 'admin' }, { status: 'rejected' }, { status: 'ACTIVE' }, { limit: '0' }, { limit: '101' }, { limit: '5x' }, { after: '-1' }, { after: 'abc' }, { status: ['pending'] }, { ownerId: '1' }]) {
      const e = await failure(s.dealers.listDealers(s.admin, q));
      assert.ok(e instanceof DealerError && e.code === 'validation_failed', JSON.stringify(q));
    }
    assert.equal(await codeOf(s.dealers.listDealers(null, { role: 'admin' })), 'not_found', 'a non-admin learns nothing, not even about validation');
  });
});

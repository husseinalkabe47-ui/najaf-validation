import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { createDb, createPoolFactory, toPoolOptions } from '../../src/db.ts';
import type { PgModuleLike } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { ROLE_QUERY } from '../../src/role.ts';
import { REQUIRED_TABLES, REQUIRED_VIEWS } from '../../src/schema-contract.ts';
import type { Logger } from '../../src/types.ts';
import { makeFakePool, pgError } from '../helpers/fake-pool.ts';

const cfg = loadConfig({ DATABASE_URL: 'postgres://najaf_app_login:S3cr3tPass@db.internal:5432/najaf' }).db;

function recordingLogger() {
  const entries: Array<{ level: string; obj: unknown; msg: string | undefined }> = [];
  const logger: Logger = {
    debug: (obj, msg) => entries.push({ level: 'debug', obj, msg }),
    info: (obj, msg) => entries.push({ level: 'info', obj, msg }),
    warn: (obj, msg) => entries.push({ level: 'warn', obj, msg }),
    error: (obj, msg) => entries.push({ level: 'error', obj, msg }),
  };
  return { logger, entries };
}

describe('db: pool options', () => {
  it('maps the configuration to node-postgres options, with timeouts as startup parameters', () => {
    const o = toPoolOptions(loadConfig({ DATABASE_URL: 'postgres://u:p@h:6000/d', DB_POOL_MAX: '7', DB_APPLICATION_NAME: 'x-app' }).db);
    assert.equal(o['host'], 'h');
    assert.equal(o['port'], 6000);
    assert.equal(o['database'], 'd');
    assert.equal(o['max'], 7);
    assert.equal(o['statement_timeout'], 15000);
    assert.equal(o['lock_timeout'], 5000);
    assert.equal(o['idle_in_transaction_session_timeout'], 15000);
    assert.equal(o['idleTimeoutMillis'], 30000);
    assert.equal(o['connectionTimeoutMillis'], 5000);
    assert.equal(o['application_name'], 'x-app');
  });

  it('translates the three TLS modes', () => {
    const mk = (extra: Record<string, string>) => toPoolOptions(loadConfig({ DATABASE_URL: 'postgres://u:p@h/d', ...extra }).db)['ssl'];
    assert.equal(mk({ DB_SSL: 'disable' }), false);
    assert.deepEqual(mk({ DB_SSL: 'require' }), { rejectUnauthorized: false });
    assert.deepEqual(mk({ DB_SSL: 'verify-full' }), { rejectUnauthorized: true });
    assert.deepEqual(mk({ DB_SSL: 'verify-full', DB_SSL_CA: 'PEM' }), { rejectUnauthorized: true, ca: 'PEM' });
  });

  it('the pool factory builds a Pool from the default export or from a named export', async () => {
    const seen: Array<Record<string, unknown>> = [];
    class Pool {
      constructor(o: Record<string, unknown>) {
        seen.push(o);
      }
    }
    const viaDefault = createPoolFactory(async () => ({ default: { Pool } }) as unknown as PgModuleLike);
    const viaNamed = createPoolFactory(async () => ({ Pool }) as unknown as PgModuleLike);
    await viaDefault(cfg);
    await viaNamed(cfg);
    assert.equal(seen.length, 2);
    assert.equal(seen[0]?.['user'], 'najaf_app_login');
  });

  it('the pool factory fails clearly when pg exposes no Pool', async () => {
    await assert.rejects(createPoolFactory(async () => ({}))(cfg), /Pool/);
  });
});

describe('db: query', () => {
  it('forwards text and parameters separately and returns rows', async () => {
    const f = makeFakePool(() => ({ rows: [{ n: 1 }], rowCount: 1 }));
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    const r = await db.query('SELECT $1::int AS n', [1]);
    assert.deepEqual(r.rows, [{ n: 1 }]);
    assert.deepEqual(f.calls, [{ text: 'SELECT $1::int AS n', values: [1], via: 'pool' }]);
  });

  it('defaults to an empty parameter list', async () => {
    const f = makeFakePool();
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await db.query('SELECT 1');
    assert.deepEqual(f.calls[0]?.values, []);
  });

  it('classifies driver errors into DbError', async () => {
    const f = makeFakePool(() => pgError('23505', 'duplicate', { constraint: 'plans_code_uq' }));
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await assert.rejects(db.query('INSERT ...'), (e: unknown) => e instanceof DbError && e.kind === 'unique' && e.constraint === 'plans_code_uq');
  });

  it('lets programming errors through unchanged', async () => {
    const boom = new TypeError('x is not a function');
    const f = makeFakePool(() => boom);
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await assert.rejects(db.query('SELECT 1'), (e: unknown) => e === boom);
  });

  it('a closed handle rejects with DbError(unavailable) and close() is idempotent', async () => {
    const f = makeFakePool();
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await db.close();
    await db.close();
    assert.equal(f.state.ended, 1);
    await assert.rejects(db.query('SELECT 1'), (e: unknown) => e instanceof DbError && e.kind === 'unavailable');
    await assert.rejects(db.tx(async () => 1), (e: unknown) => e instanceof DbError && e.kind === 'unavailable');
  });

  it('an error on an idle pooled client is logged and does not throw', async () => {
    const f = makeFakePool();
    const { logger, entries } = recordingLogger();
    await createDb(cfg, { poolFactory: async () => f.pool, logger });
    const handler = f.listeners['error']?.[0];
    assert.ok(handler);
    assert.doesNotThrow(() => handler(pgError('57P01', 'terminating connection due to administrator command')));
    assert.equal(entries.at(-1)?.level, 'error');
  });
});

describe('db: transactions', () => {
  it('commits: BEGIN, statements, COMMIT on one client, released exactly once', async () => {
    const f = makeFakePool(() => ({ rows: [{ id: 7 }], rowCount: 1 }));
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    const out = await db.tx(async (t) => {
      const r = await t.query<{ id: number }>('INSERT INTO x VALUES ($1) RETURNING id', [1]);
      return r.rows[0]?.id;
    });
    assert.equal(out, 7);
    assert.deepEqual(f.calls.map((c) => c.text), ['BEGIN', 'INSERT INTO x VALUES ($1) RETURNING id', 'COMMIT']);
    assert.ok(f.calls.every((c) => c.via === 'client'));
    assert.deepEqual(f.releases, [undefined]);
  });

  it('rolls back and rethrows the original error when the callback throws', async () => {
    const f = makeFakePool();
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    const boom = new Error('domain failure');
    await assert.rejects(db.tx(async () => { throw boom; }), (e: unknown) => e === boom);
    assert.deepEqual(f.calls.map((c) => c.text), ['BEGIN', 'ROLLBACK']);
    assert.deepEqual(f.releases, [undefined]);
  });

  it('classifies a driver error raised inside the transaction and still rolls back', async () => {
    const f = makeFakePool((text) => (text.startsWith('INSERT') ? pgError('23503', 'fk') : { rows: [], rowCount: 0 }));
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await assert.rejects(db.tx((t) => t.query('INSERT INTO x VALUES (1)')), (e: unknown) => e instanceof DbError && e.kind === 'foreign_key');
    assert.deepEqual(f.calls.map((c) => c.text), ['BEGIN', 'INSERT INTO x VALUES (1)', 'ROLLBACK']);
    assert.equal(f.releases.length, 1);
  });

  it('a failing COMMIT is rolled back, mapped, and released once', async () => {
    const f = makeFakePool((text) => (text === 'COMMIT' ? pgError('40001', 'could not serialize') : { rows: [], rowCount: 0 }));
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await assert.rejects(db.tx(async () => 'ok'), (e: unknown) => e instanceof DbError && e.kind === 'serialization' && e.retryable);
    assert.deepEqual(f.calls.map((c) => c.text), ['BEGIN', 'COMMIT', 'ROLLBACK']);
    assert.equal(f.releases.length, 1);
  });

  it('a failing ROLLBACK destroys the connection (release with an error) and logs it', async () => {
    const f = makeFakePool((text) => (text === 'ROLLBACK' ? pgError('08006', 'connection failure') : { rows: [], rowCount: 0 }));
    const { logger, entries } = recordingLogger();
    const db = await createDb(cfg, { poolFactory: async () => f.pool, logger });
    const boom = new Error('domain failure');
    await assert.rejects(db.tx(async () => { throw boom; }), (e: unknown) => e === boom);
    assert.equal(f.releases.length, 1);
    assert.ok(f.releases[0] instanceof Error);
    assert.ok(entries.some((e) => e.level === 'error' && e.msg?.includes('rollback failed')));
  });

  it('a connection failure is mapped and nothing is released', async () => {
    const f = makeFakePool();
    f.state.connectError = new Error('timeout exceeded when trying to connect');
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    await assert.rejects(db.tx(async () => 1), (e: unknown) => e instanceof DbError && e.kind === 'unavailable');
    assert.equal(f.releases.length, 0);
  });

  it('the scoped query is unusable after the transaction ends (no leaked connection use)', async () => {
    const f = makeFakePool();
    const db = await createDb(cfg, { poolFactory: async () => f.pool });
    let leaked: { query: (t: string) => Promise<unknown> } | undefined;
    await db.tx(async (t) => {
      leaked = t;
    });
    await assert.rejects(leaked!.query('SELECT 1'), /no longer active/);
    assert.equal(f.calls.filter((c) => c.text === 'SELECT 1').length, 0);
  });
});

describe('db: health, role and schema checks', () => {
  it('ping runs SELECT 1 and fails on an unexpected result', async () => {
    const ok = makeFakePool(() => ({ rows: [{ ok: 1 }], rowCount: 1 }));
    await (await createDb(cfg, { poolFactory: async () => ok.pool })).ping();
    assert.equal(ok.calls[0]?.text, 'SELECT 1 AS ok');
    const bad = makeFakePool(() => ({ rows: [{ ok: 2 }], rowCount: 1 }));
    await assert.rejects((await createDb(cfg, { poolFactory: async () => bad.pool })).ping(), DbError);
  });

  it('verifyRole runs the catalog query and parses the row', async () => {
    const f = makeFakePool(() => ({
      rows: [{ cur_user: 'najaf_app_login', sess_user: 'najaf_app_login', db_name: 'najaf', is_super: false, can_create_role: false, can_create_db: false, is_replication: false, bypass_rls: false, is_app_member: true, server_version_num: 160013 }],
      rowCount: 1,
    }));
    const r = await (await createDb(cfg, { poolFactory: async () => f.pool })).verifyRole();
    assert.equal(f.calls[0]?.text, ROLE_QUERY);
    assert.equal(r.isAppMember, true);
    assert.equal(r.isSuperuser, false);
  });

  it('checkSchema passes the object names as ONE parameter (never interpolated) and reports the missing ones', async () => {
    const names = [...REQUIRED_TABLES, ...REQUIRED_VIEWS];
    const f = makeFakePool(() => ({ rows: names.map((name) => ({ name, present: name !== 'payments' && name !== 'public_cars' })), rowCount: names.length }));
    const r = await (await createDb(cfg, { poolFactory: async () => f.pool })).checkSchema();
    assert.deepEqual(r.missing, ['payments', 'public_cars']);
    assert.ok(f.calls[0]?.text.includes('$1::text[]'));
    assert.deepEqual(f.calls[0]?.values, [names]);
    for (const n of names) assert.ok(!f.calls[0]?.text.includes(n), n);
  });

  it('stats reflects the pool counters', async () => {
    const f = makeFakePool();
    assert.deepEqual((await createDb(cfg, { poolFactory: async () => f.pool })).stats(), { total: 3, idle: 1, waiting: 0 });
  });

  it('nothing sensitive from the configuration reaches the pool callbacks or logs', async () => {
    const f = makeFakePool(() => pgError('28P01', 'password authentication failed for user "najaf_app_login"'));
    const { logger, entries } = recordingLogger();
    const db = await createDb(cfg, { poolFactory: async () => f.pool, logger });
    await assert.rejects(db.query('SELECT 1'), (e: unknown) => e instanceof DbError && e.kind === 'auth_failed' && !JSON.stringify(e).includes('S3cr3tPass'));
    assert.ok(!JSON.stringify(entries).includes('S3cr3tPass'));
  });
});

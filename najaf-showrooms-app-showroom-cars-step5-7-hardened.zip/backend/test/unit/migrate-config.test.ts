import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { FORBIDDEN_MIGRATION_USERS, MigrationConfigError, describeMigrationTarget, loadMigrationConfig, redactMigrationConfig } from '../../src/migrate/config.ts';

const OK = 'postgres://najaf_migrator:S3cr3tMig@db.internal:5432/najaf';
const base = (extra: Record<string, string | undefined> = {}) => ({ MIGRATION_DATABASE_URL: OK, ...extra });

function problemsOf(env: Record<string, string | undefined>): string[] {
  try {
    loadMigrationConfig(env);
  } catch (e) {
    if (e instanceof MigrationConfigError) return e.problems;
    throw e;
  }
  return [];
}

describe('migration config: parsing and defaults', () => {
  it('loads a minimal MIGRATION_DATABASE_URL with safe development defaults', () => {
    const c = loadMigrationConfig(base());
    assert.equal(c.env, 'development');
    assert.deepEqual(
      [c.client.host, c.client.port, c.client.database, c.client.user, c.client.password, c.client.ssl, c.client.application_name],
      ['db.internal', 5432, 'najaf', 'najaf_migrator', 'S3cr3tMig', false, 'najaf-migrate'],
    );
    assert.equal(c.sslMode, 'disable');
    assert.equal(c.singleTransaction, false);
    assert.equal(c.allowRollback, false);
  });

  it('decodes percent-encoded credentials and supports IPv6 hosts', () => {
    const c = loadMigrationConfig({ MIGRATION_DATABASE_URL: 'postgres://najaf_migrator:p%40ss%2Fw%3Ard@[::1]:6432/na%20jaf' });
    assert.equal(c.client.password, 'p@ss/w:rd');
    assert.equal(c.client.host, '::1');
    assert.equal(c.client.port, 6432);
    assert.equal(c.client.database, 'na jaf');
  });

  it('the resolved configuration is immutable', () => {
    const c = loadMigrationConfig(base());
    assert.equal(Object.isFrozen(c), true);
    assert.equal(Object.isFrozen(c.client), true);
  });

  it('parses the two booleans strictly', () => {
    const c = loadMigrationConfig(base({ MIGRATION_SINGLE_TRANSACTION: 'true', MIGRATION_ALLOW_ROLLBACK: '1' }));
    assert.equal(c.singleTransaction, true);
    assert.equal(c.allowRollback, true);
    assert.ok(problemsOf(base({ MIGRATION_SINGLE_TRANSACTION: 'maybe' })).some((m) => m.includes('MIGRATION_SINGLE_TRANSACTION')));
  });
});

describe('migration config: the account must be separate from the application account', () => {
  it('requires MIGRATION_DATABASE_URL', () => {
    assert.ok(problemsOf({}).some((m) => m.includes('MIGRATION_DATABASE_URL is required')));
  });

  it('rejects every application/reporting identity, case-insensitively', () => {
    for (const u of FORBIDDEN_MIGRATION_USERS) {
      for (const name of [u, u.toUpperCase()]) {
        const p = problemsOf({ MIGRATION_DATABASE_URL: `postgres://${name}:pw@h:5432/najaf` });
        assert.ok(p.some((m) => m.includes('migration account must not be')), name);
      }
    }
    assert.deepEqual([...FORBIDDEN_MIGRATION_USERS].sort(), ['najaf_app', 'najaf_app_login', 'najaf_report']);
  });

  it('rejects the same user as DATABASE_URL, even if its name is not on the list', () => {
    const p = problemsOf({
      MIGRATION_DATABASE_URL: 'postgres://shared_account:pw1@h:5432/najaf',
      DATABASE_URL: 'postgres://shared_account:pw2@h:5432/najaf',
    });
    assert.ok(p.some((m) => m.includes('different account than DATABASE_URL')));
  });

  it('accepts a different account than DATABASE_URL', () => {
    assert.doesNotThrow(() => loadMigrationConfig(base({ DATABASE_URL: 'postgres://najaf_app_login:pw@h:5432/najaf' })));
  });

  it('an unparseable DATABASE_URL does not block (it is only compared) and is never echoed', () => {
    assert.doesNotThrow(() => loadMigrationConfig(base({ DATABASE_URL: 'not a url S3cr3tPass' })));
  });
});

describe('migration config: nothing secret in errors or logs', () => {
  it('an unparseable URL is not echoed', () => {
    const msg = problemsOf({ MIGRATION_DATABASE_URL: 'not a url S3cr3tMig' }).join('\n');
    assert.ok(!msg.includes('S3cr3tMig'));
  });

  it('a wrong scheme is not echoed', () => {
    const msg = problemsOf({ MIGRATION_DATABASE_URL: 'mysql://najaf_migrator:S3cr3tMig@h/db' }).join('\n');
    assert.ok(msg.includes('postgres') && !msg.includes('S3cr3tMig'));
  });

  it('a forbidden-user error does not echo the password', () => {
    const msg = problemsOf({ MIGRATION_DATABASE_URL: 'postgres://najaf_app_login:S3cr3tMig@h:5432/najaf' }).join('\n');
    assert.ok(!msg.includes('S3cr3tMig'));
  });

  it('missing parts are reported together', () => {
    // parses as a URL (host present) but has no database, no user and no password
    const p = problemsOf({ MIGRATION_DATABASE_URL: 'postgres://:@db.internal:5432/' });
    assert.equal(p.length, 3);
    assert.ok(p.some((m) => m.includes('no database')) && p.some((m) => m.includes('no user')) && p.some((m) => m.includes('no password')));
    // an unparseable URL is a single, non-echoing problem
    assert.equal(problemsOf({ MIGRATION_DATABASE_URL: 'postgres://@:5432/' }).length, 1);
  });

  it('redaction hides the password and CA, and describeMigrationTarget has none', () => {
    const c = loadMigrationConfig(base({ MIGRATION_DB_SSL: 'verify-full', MIGRATION_DB_SSL_CA: '-----BEGIN CERTIFICATE-----x' }));
    const text = JSON.stringify(redactMigrationConfig(c));
    assert.ok(!text.includes('S3cr3tMig') && !text.includes('BEGIN CERTIFICATE'));
    assert.ok(text.includes('"password":"***"'));
    assert.equal(describeMigrationTarget(c), 'najaf_migrator@db.internal:5432/najaf');
  });
});

describe('migration config: TLS and production rules', () => {
  it('translates the three TLS modes to pg options', () => {
    assert.equal(loadMigrationConfig(base({ MIGRATION_DB_SSL: 'disable' })).client.ssl, false);
    assert.deepEqual(loadMigrationConfig(base({ MIGRATION_DB_SSL: 'require' })).client.ssl, { rejectUnauthorized: false });
    assert.deepEqual(loadMigrationConfig(base({ MIGRATION_DB_SSL: 'verify-full' })).client.ssl, { rejectUnauthorized: true });
    assert.deepEqual(loadMigrationConfig(base({ MIGRATION_DB_SSL: 'verify-full', MIGRATION_DB_SSL_CA: 'PEM' })).client.ssl, { rejectUnauthorized: true, ca: 'PEM' });
  });

  it('honours sslmode in the URL; the variable overrides it; weakening libpq modes are rejected', () => {
    assert.equal(loadMigrationConfig({ MIGRATION_DATABASE_URL: OK + '?sslmode=require' }).sslMode, 'require');
    assert.equal(loadMigrationConfig({ MIGRATION_DATABASE_URL: OK + '?sslmode=require', MIGRATION_DB_SSL: 'verify-full' }).sslMode, 'verify-full');
    for (const m of ['prefer', 'allow', 'verify-ca']) {
      assert.ok(problemsOf({ MIGRATION_DATABASE_URL: OK + '?sslmode=' + m }).some((p) => p.includes('sslmode')), m);
    }
  });

  it('production defaults to verify-full and rejects disable (variable or URL)', () => {
    assert.equal(loadMigrationConfig(base({ NODE_ENV: 'production' })).sslMode, 'verify-full');
    assert.ok(problemsOf(base({ NODE_ENV: 'production', MIGRATION_DB_SSL: 'disable' })).some((m) => m.includes('not allowed in production')));
    assert.ok(problemsOf({ NODE_ENV: 'production', MIGRATION_DATABASE_URL: OK + '?sslmode=disable' }).some((m) => m.includes('not allowed in production')));
  });

  it('rejects an unknown NODE_ENV', () => {
    assert.ok(problemsOf(base({ NODE_ENV: 'staging' })).some((m) => m.includes('NODE_ENV')));
  });
});

// The validated database privileges (Phase 11.3), observed through the backend's own connection layer.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { Rollback, appConfig, seedLoaded, skip } from '../helpers/integration.ts';

const forbidden = (e: unknown) => e instanceof DbError && e.kind === 'forbidden' && e.sqlstate === '42501';

describe('application role privileges (real database)', { skip }, () => {
  let app: Db;
  before(async () => {
    app = await createDb(appConfig());
  });
  after(async () => {
    await app.close();
  });

  const denied: Array<[string, string]> = [
    ['CREATE TABLE', 'CREATE TABLE it_forbidden (a int)'],
    ['DROP TABLE', 'DROP TABLE users'],
    ['ALTER TABLE', 'ALTER TABLE cars ADD COLUMN it_x int'],
    ['DROP VIEW', 'DROP VIEW public_cars'],
    ['TRUNCATE cars', 'TRUNCATE cars'],
    ['TRUNCATE audit_logs', 'TRUNCATE audit_logs'],
    ['DELETE users', 'DELETE FROM users WHERE false'],
    ['DELETE showrooms', 'DELETE FROM showrooms WHERE false'],
    ['DELETE audit_logs', 'DELETE FROM audit_logs WHERE false'],
    ['DELETE exchange_rates', 'DELETE FROM exchange_rates WHERE false'],
    ['UPDATE audit_logs', "UPDATE audit_logs SET reason = 'x' WHERE false"],
    ['UPDATE exchange_rates', 'UPDATE exchange_rates SET usd_to_iqd = 1 WHERE false'],
    ['UPDATE users.role (column privilege)', "UPDATE users SET role = 'admin' WHERE false"],
    ['UPDATE users.id', 'UPDATE users SET id = id WHERE false'],
    ['UPDATE users.version', 'UPDATE users SET version = 5 WHERE false'],
    ['UPDATE cars.created_at (0013)', 'UPDATE cars SET created_at = created_at WHERE false'],
    ['UPDATE cars.owner_id (0013)', 'UPDATE cars SET owner_id = owner_id WHERE false'],
    ['UPDATE cars.source_type (0013)', 'UPDATE cars SET source_type = source_type WHERE false'],
    ['UPDATE cars.version (0013)', 'UPDATE cars SET version = 1 WHERE false'],
    ['UPDATE showrooms.owner_id (0013)', 'UPDATE showrooms SET owner_id = owner_id WHERE false'],
    ['UPDATE favorites (0013)', 'UPDATE favorites SET user_id = user_id WHERE false'],
    ['read pg_authid', 'SELECT * FROM pg_authid'],
    ['CREATE ROLE', 'CREATE ROLE it_forbidden_role'],
  ];
  for (const [label, sql] of denied) {
    it(`denied: ${label}`, async () => {
      await assert.rejects(app.query(sql), forbidden);
    });
  }

  const allowed: Array<[string, string]> = [
    ['read users (login needs the password hash)', 'SELECT count(*) FROM users'],
    ['read public_cars', 'SELECT count(*) FROM public_cars'],
    ['read public_showrooms', 'SELECT count(*) FROM public_showrooms'],
    ['read audit_logs', 'SELECT count(*) FROM audit_logs'],
    ['UPDATE users.name', 'UPDATE users SET name = name WHERE false'],
    ['UPDATE cars.price', 'UPDATE cars SET price = price WHERE false'],
    ['UPDATE cars.status', 'UPDATE cars SET status = status WHERE false'],
    ['UPDATE cars.deleted_at', 'UPDATE cars SET deleted_at = deleted_at WHERE false'],
    ['UPDATE showrooms.status', 'UPDATE showrooms SET status = status WHERE false'],
    ['UPDATE car_images.is_main', 'UPDATE car_images SET is_main = is_main WHERE false'],
    ['execute to_iqd', "SELECT to_iqd(1, 'IQD')"],
    ['execute current_usd_to_iqd', 'SELECT current_usd_to_iqd()'],
  ];
  for (const [label, sql] of allowed) {
    it(`allowed: ${label}`, async () => {
      await app.query(sql);
    });
  }

  it('may append to audit_logs (insert is allowed; nothing is persisted by this test)', async () => {
    await assert.rejects(
      app.tx(async (t) => {
        await t.query("INSERT INTO audit_logs (actor_role, action, entity_type) VALUES ('system', 'it.probe', 'test')");
        throw new Rollback();
      }),
      (e: unknown) => e instanceof Rollback,
    );
    assert.equal((await app.query("SELECT 1 FROM audit_logs WHERE action = 'it.probe'")).rows.length, 0);
  });

  it('cannot create an administrator account (database trigger)', async () => {
    const phone = '+9647' + String(Math.floor(Math.random() * 1e9)).padStart(9, '0');
    await assert.rejects(
      app.query("INSERT INTO users (name, phone_e164, role, password_hash) VALUES ('مدير اختبار', $1, 'admin', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA')", [phone]),
      (e: unknown) => forbidden(e) && String((e as DbError).driverMessage).includes('admin accounts can only be created'),
    );
  });

  it('the validated public visibility is readable: 3 showrooms and 115 cars (staging seed only)', { skip: seedLoaded ? false : 'set SEED_LOADED=1 when database/seed is loaded' }, async () => {
    const r = await app.query<{ s: number; c: number }>('SELECT (SELECT count(*) FROM public_showrooms)::int AS s, (SELECT count(*) FROM public_cars)::int AS c');
    assert.deepEqual(r.rows[0], { s: 3, c: 115 });
  });
});

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { RoleError, assertAppRole, roleViolations } from '../../src/role.ts';
import { APP_URL, adminConfig, appConfig, skip, withPassword } from '../helpers/integration.ts';

const isDbError = (kind: string) => (e: unknown) => e instanceof DbError && e.kind === kind;

describe('connection to PostgreSQL (real database)', { skip }, () => {
  let app: Db;
  let admin: Db;
  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    await app.close();
    await admin.close();
  });

  it('connects and answers a ping', async () => {
    await app.ping();
  });

  it('connects as a least-privilege member of najaf_app and passes the role policy', async () => {
    const r = await app.verifyRole();
    assert.equal(r.isSuperuser, false);
    assert.equal(r.canCreateRole, false);
    assert.equal(r.canCreateDb, false);
    assert.equal(r.isAppMember, true);
    assert.ok(r.serverVersionNum >= 160000, `PostgreSQL ${r.serverVersionNum}`);
    assert.deepEqual(roleViolations(r), []);
    assert.doesNotThrow(() => assertAppRole(r));
  });

  it('a superuser connection is rejected by the role policy', async () => {
    const r = await admin.verifyRole();
    assert.equal(r.isSuperuser, true);
    assert.throws(() => assertAppRole(r), (e: unknown) => e instanceof RoleError && e.violations.some((v) => v.includes('superuser')));
  });

  it('the validated schema contract is satisfied', async () => {
    assert.deepEqual((await app.checkSchema()).missing, []);
  });

  it('applies the configured timeouts and application name from the first statement', async () => {
    const db = await createDb(appConfig({ DB_STATEMENT_TIMEOUT_MS: '12345', DB_LOCK_TIMEOUT_MS: '2345', DB_IDLE_IN_TX_TIMEOUT_MS: '4567', DB_APPLICATION_NAME: 'najaf-it' }));
    try {
      const r = await db.query<{ st: string; lt: string; it: string; an: string }>(
        `SELECT current_setting('statement_timeout') AS st, current_setting('lock_timeout') AS lt,
                current_setting('idle_in_transaction_session_timeout') AS it, current_setting('application_name') AS an`,
      );
      assert.deepEqual(r.rows[0], { st: '12345ms', lt: '2345ms', it: '4567ms', an: 'najaf-it' });
    } finally {
      await db.close();
    }
  });

  it('enforces the statement timeout (SQLSTATE 57014 -> timeout)', async () => {
    const db = await createDb(appConfig({ DB_STATEMENT_TIMEOUT_MS: '300' }));
    try {
      await assert.rejects(db.query('SELECT pg_sleep(2)'), (e: unknown) => e instanceof DbError && e.kind === 'timeout' && e.sqlstate === '57014');
    } finally {
      await db.close();
    }
  });

  it('a wrong password is auth_failed and never appears in the error', async () => {
    const wrong = 'definitely-wrong-password-9X';
    const db = await createDb(appConfig({ DATABASE_URL: withPassword(APP_URL!, wrong) }));
    try {
      await assert.rejects(db.ping(), (e: unknown) => e instanceof DbError && e.kind === 'auth_failed' && !JSON.stringify(e).includes(wrong) && !e.message.includes(wrong) && !String(e.driverMessage).includes(wrong));
    } finally {
      await db.close();
    }
  });

  it('an unreachable server is unavailable (fails fast within the connect timeout)', async () => {
    const db = await createDb(appConfig({ DATABASE_URL: 'postgres://najaf_app_login:x@127.0.0.1:1/najaf', DB_CONNECT_TIMEOUT_MS: '1000' }));
    try {
      const started = Date.now();
      await assert.rejects(db.ping(), isDbError('unavailable'));
      assert.ok(Date.now() - started < 5000);
    } finally {
      await db.close();
    }
  });

  it('respects the pool maximum and queues excess work', async () => {
    const db = await createDb(appConfig({ DB_POOL_MAX: '3' }));
    try {
      await Promise.all(Array.from({ length: 12 }, () => db.query('SELECT pg_sleep(0.05)')));
      assert.ok(db.stats().total <= 3, `pool grew to ${db.stats().total}`);
    } finally {
      await db.close();
    }
  });

  it('a rolled-back transaction leaves no trace; a committed one persists', async () => {
    const key = `it_${randomUUID()}`;
    const insert = (t: { query: Db['query'] }) => t.query('INSERT INTO app_settings (key, value) VALUES ($1, $2::jsonb)', [key, JSON.stringify({ ok: true })]);
    try {
      await assert.rejects(
        app.tx(async (t) => {
          await insert(t);
          throw new Error('boom');
        }),
        /boom/,
      );
      assert.equal((await app.query('SELECT 1 FROM app_settings WHERE key = $1', [key])).rows.length, 0);
      await app.tx(insert);
      assert.equal((await app.query('SELECT 1 FROM app_settings WHERE key = $1', [key])).rows.length, 1);
    } finally {
      await admin.query('DELETE FROM app_settings WHERE key = $1', [key]);
    }
  });

  it('the pool stays healthy after failed transactions (connections are not leaked)', async () => {
    for (let i = 0; i < 25; i++) {
      await assert.rejects(app.tx(async (t) => { await t.query('SELECT $1::int', ['not-a-number']); }), isDbError('invalid_value'));
    }
    await app.ping();
    assert.ok(app.stats().total <= 10);
  });
});

describe('real constraint violations are classified without leaking SQL or values (real database)', { skip }, () => {
  let app: Db;
  before(async () => {
    app = await createDb(appConfig());
  });
  after(async () => {
    await app.close();
  });

  const cases: Array<[string, string, readonly unknown[], string, string | undefined]> = [
    ['unique', "INSERT INTO subscription_plans (code, name) VALUES ('free', 'duplicate')", [], 'unique', 'plans_code_uq'],
    ['check', "INSERT INTO exchange_rates (usd_to_iqd, kind) VALUES (0, 'manual')", [], 'check', 'fx_rate_pos'],
    ['foreign key', 'INSERT INTO favorites (user_id, car_id) VALUES (999999999, 999999999)', [], 'foreign_key', undefined],
    ['not null', 'INSERT INTO app_settings (key, value) VALUES ($1, NULL)', ['it_null_value'], 'not_null', undefined],
    ['invalid value', 'SELECT $1::int AS n', ['abc'], 'invalid_value', undefined],
    ['permission denied', 'DROP TABLE users', [], 'forbidden', undefined],
  ];
  for (const [label, sql, params, kind, constraint] of cases) {
    it(`${label} -> ${kind}`, async () => {
      await assert.rejects(app.query(sql, params), (e: unknown) => {
        if (!(e instanceof DbError) || e.kind !== kind) return false;
        if (constraint !== undefined && e.constraint !== constraint) return false;
        const json = JSON.stringify(e);
        return !json.includes('INSERT') && !json.includes('free') && !e.message.includes('Key (');
      });
    });
  }
});

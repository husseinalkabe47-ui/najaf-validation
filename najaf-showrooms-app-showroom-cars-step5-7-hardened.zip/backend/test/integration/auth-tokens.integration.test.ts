// Access tokens, refresh-token rotation, reuse detection, expiry, logout and rate limiting against a REAL PostgreSQL 16
// (migrations 0001-0013 applied) with REAL argon2id, through the application role. Needs DATABASE_URL (najaf_app_login)
// and ADMIN_DATABASE_URL (superuser: inspection, time travel and cleanup ONLY). Skipped visibly when they are missing,
// or when `argon2` / `fastify` are not installed.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { ACCESS_TOKEN_TTL_SECONDS, RATE_LIMITS, SESSION_TTL_SECONDS } from '../../src/auth/policy.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { hashSessionToken } from '../../src/auth/tokens.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AuthApi } from '../../src/auth/types.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { recordingLogger } from '../helpers/fake-auth.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Tokens-Passw0rd!';
const SECRET = 'integration-tokens-access-secret-0123456789-QWERTY';
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const DAY = 24 * 60 * 60;

describe('access and refresh tokens on PostgreSQL 16 with real argon2id', { skip: skip || argon2Missing }, () => {
  let app: Db;
  let admin: Db;
  let offsetSeconds = 0; // moves the APPLICATION clock (access-token expiry) without waiting; the database clock is untouched
  const log = recordingLogger();
  let auth: AuthApi;

  const rows = async (phone: string) =>
    (await admin.query(`SELECT s.id, s.family_id, encode(s.token_hash, 'hex') AS hash, s.revoked_at, s.revoked_reason, s.replaced_by, s.expires_at, s.user_agent
                          FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 ORDER BY s.created_at, s.id`, [phone])).rows as Array<{
      id: string; family_id: string; hash: string; revoked_at: Date | null; revoked_reason: string | null; replaced_by: string | null; expires_at: Date; user_agent: string | null;
    }>;
  const failure = async (p: Promise<unknown>): Promise<AuthError> => {
    try {
      await p;
    } catch (e) {
      assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
      return e;
    }
    throw new Error('expected a failure');
  };
  const signUp = async (extra: Record<string, unknown> = {}) => {
    const phone = newPhone();
    const r = await auth.register({ name: 'مستخدم الرموز', phone, password: PW, ...extra }, { userAgent: 'tokens-suite/1.0' });
    return { phone, r };
  };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET, logger: log.logger, now: () => Date.now() + offsetSeconds * 1000 });
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  it('registration issues a 15-minute access token and a 30-day refresh token; only the refresh hash is stored', async () => {
    const { phone, r } = await signUp();
    assert.equal(new Date(r.session.accessExpiresAt).getTime() - Date.now() < ACCESS_TOKEN_TTL_SECONDS * 1000 + 5000, true);
    assert.equal(new Date(r.session.accessExpiresAt).getTime() - Date.now() > (ACCESS_TOKEN_TTL_SECONDS - 5) * 1000, true);
    const [row] = await rows(phone);
    assert.equal(row?.hash, hashSessionToken(r.session.refreshToken).toString('hex'));
    assert.equal(row?.revoked_at, null);
    const lifetime = (await admin.query(`SELECT extract(epoch FROM (s.expires_at - s.created_at)) AS secs FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1`, [phone])).rows[0] as { secs: string };
    assert.ok(Math.abs(Number(lifetime.secs) - SESSION_TTL_SECONDS) < 5);
    const all = JSON.stringify((await admin.query('SELECT s::text AS t FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1', [phone])).rows);
    assert.ok(!all.includes(r.session.accessToken) && !all.includes(r.session.refreshToken));
  });

  it('refresh rotates in the database: one live row per login session, the old row revoked as "rotated" and linked to the new one, same absolute expiry', async () => {
    const { phone, r } = await signUp();
    const b = await auth.refresh({ refreshToken: r.session.refreshToken }, { userAgent: 'rotated-agent/2' });
    const [oldRow, newRow] = await rows(phone);
    assert.equal(oldRow?.family_id, newRow?.family_id);
    assert.equal(oldRow?.revoked_reason, 'rotated');
    assert.notEqual(oldRow?.revoked_at, null);
    assert.equal(oldRow?.replaced_by, newRow?.id);
    assert.equal(newRow?.revoked_at, null);
    assert.equal(newRow?.hash, hashSessionToken(b.session.refreshToken).toString('hex'));
    assert.equal(newRow?.user_agent, 'rotated-agent/2');
    assert.equal(newRow?.expires_at.getTime(), oldRow?.expires_at.getTime(), 'rotation does not extend the lifetime');
    assert.equal(b.session.refreshExpiresAt, r.session.refreshExpiresAt);
    assert.notEqual(b.session.refreshToken, r.session.refreshToken);
    assert.deepEqual((await auth.authenticate(b.session.accessToken))?.user, r.user);
  });

  it('a chain of rotations leaves exactly one live row', async () => {
    const { phone, r } = await signUp();
    let latest = r;
    for (let i = 0; i < 5; i++) latest = await auth.refresh({ refreshToken: latest.session.refreshToken });
    const all = await rows(phone);
    assert.equal(all.length, 6);
    assert.equal(all.filter((x) => x.revoked_at === null).length, 1);
    assert.equal(all.filter((x) => x.revoked_reason === 'rotated').length, 5);
    assert.equal(new Set(all.map((x) => x.family_id)).size, 1);
  });

  it('REUSE of an exchanged refresh token fails, revokes the whole login session (reuse_detected), and issues nothing', async () => {
    const { phone, r } = await signUp();
    const b = await auth.refresh({ refreshToken: r.session.refreshToken });
    assert.equal((await failure(auth.refresh({ refreshToken: r.session.refreshToken }))).code, 'unauthorized');
    const all = await rows(phone);
    assert.equal(all.length, 2, 'a detected reuse creates no new row');
    assert.ok(all.every((x) => x.revoked_at !== null));
    assert.deepEqual(all.map((x) => x.revoked_reason), ['rotated', 'reuse_detected']);
    assert.equal((await failure(auth.refresh({ refreshToken: b.session.refreshToken }))).code, 'unauthorized', 'the legitimate holder is cut off too');
    assert.equal(await auth.authenticate(b.session.accessToken), null, 'the access token dies at once, long before its 15 minutes');
    assert.equal(await auth.authenticate(r.session.accessToken), null);
  });

  it('reuse is contained to that login session: another session of the same user keeps working', async () => {
    const { phone, r } = await signUp();
    const other = await auth.login({ phone, password: PW });
    await auth.refresh({ refreshToken: r.session.refreshToken });
    await auth.refresh({ refreshToken: r.session.refreshToken }).catch(() => undefined);
    assert.ok(await auth.authenticate(other.session.accessToken));
    assert.ok(await auth.refresh({ refreshToken: other.session.refreshToken }));
  });

  it('concurrent refreshes of one token: the row lock lets exactly one rotation win; the loser is a reuse and the session ends', async () => {
    const { phone, r } = await signUp();
    const results = await Promise.allSettled(Array.from({ length: 4 }, () => auth.refresh({ refreshToken: r.session.refreshToken })));
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.equal(results.filter((x) => x.status === 'rejected' && (x.reason as AuthError).code === 'unauthorized').length, 3);
    const all = await rows(phone);
    assert.equal(all.filter((x) => x.revoked_at === null).length, 0, 'after the loser detected the reuse, nothing stays live');
    assert.equal(all.filter((x) => x.revoked_reason === 'rotated').length, 1, 'there was exactly one successful rotation');
    assert.ok(all.length <= 2);
  });

  it('the refresh lifetime is absolute: a session older than 30 days cannot be refreshed, however recently it rotated', async () => {
    const { phone, r } = await signUp();
    const b = await auth.refresh({ refreshToken: r.session.refreshToken });
    await admin.query(`UPDATE sessions SET created_at = created_at - interval '31 days', expires_at = expires_at - interval '31 days' WHERE user_id = (SELECT id FROM users WHERE phone_e164 = $1)`, [phone]);
    assert.equal((await failure(auth.refresh({ refreshToken: b.session.refreshToken }))).code, 'unauthorized');
    assert.equal(await auth.authenticate(b.session.accessToken), null);
    const all = await rows(phone);
    assert.equal(all.filter((x) => x.revoked_reason === 'reuse_detected').length, 0, 'an expired token is not a reuse');
  });

  it('the access token expires after 15 minutes while the session lives; a refresh then mints a new one', async () => {
    const { r } = await signUp();
    assert.ok(await auth.authenticate(r.session.accessToken));
    offsetSeconds = ACCESS_TOKEN_TTL_SECONDS + 1;
    try {
      assert.equal(await auth.authenticate(r.session.accessToken), null, 'expired');
      const renewed = await auth.refresh({ refreshToken: r.session.refreshToken });
      assert.ok(await auth.authenticate(renewed.session.accessToken), 'the new access token works');
    } finally {
      offsetSeconds = 0;
    }
  });

  it('logout ends the whole login session at once: the refresh token and the unexpired access token both stop working', async () => {
    const { phone, r } = await signUp();
    const b = await auth.refresh({ refreshToken: r.session.refreshToken });
    await auth.logout({ refreshToken: b.session.refreshToken });
    assert.equal(await auth.authenticate(b.session.accessToken), null);
    assert.equal((await failure(auth.refresh({ refreshToken: b.session.refreshToken }))).code, 'unauthorized');
    const all = await rows(phone);
    assert.ok(all.every((x) => x.revoked_at !== null));
    assert.equal(all.filter((x) => x.revoked_reason === 'logout').length, 1);
    assert.equal(all.filter((x) => x.revoked_reason === 'reuse_detected').length, 0, 'a refresh after logout is just invalid, not a reuse');
    await auth.logout({ refreshToken: b.session.refreshToken }); // idempotent
  });

  it('logging out one session leaves the user\'s other sessions alone', async () => {
    const { phone, r } = await signUp();
    const other = await auth.login({ phone, password: PW });
    await auth.logout({ refreshToken: r.session.refreshToken });
    assert.equal(await auth.authenticate(r.session.accessToken), null);
    assert.ok(await auth.authenticate(other.session.accessToken));
  });

  it('suspension revokes sessions in the database (trigger): access tokens and refresh both stop at once; a pending/suspended account cannot refresh', async () => {
    const { phone, r } = await signUp();
    const b = await auth.refresh({ refreshToken: r.session.refreshToken });
    await admin.query(`UPDATE users SET status = 'suspended' WHERE phone_e164 = $1`, [phone]);
    assert.equal(await auth.authenticate(b.session.accessToken), null);
    assert.equal((await failure(auth.refresh({ refreshToken: b.session.refreshToken }))).code, 'unauthorized');
    assert.ok((await rows(phone)).every((x) => x.revoked_at !== null));
  });

  it('a password change revokes every session (trigger), so old refresh tokens die', async () => {
    const { phone, r } = await signUp();
    await admin.query(`UPDATE users SET password_hash = '$argon2id$v=19$m=19456,t=2,p=1$c2FsdHNhbHRzYWx0c2FsdA$aGFzaGhhc2hoYXNoaGFzaGhhc2hoYXNoaGFzaGhhc2g', password_changed_at = now() WHERE phone_e164 = $1`, [phone]);
    assert.equal(await auth.authenticate(r.session.accessToken), null);
    assert.equal((await failure(auth.refresh({ refreshToken: r.session.refreshToken }))).code, 'unauthorized');
  });

  it('a soft-deleted user cannot authenticate or refresh', async () => {
    const { phone, r } = await signUp();
    await admin.query(`UPDATE users SET deleted_at = now() WHERE phone_e164 = $1`, [phone]);
    assert.equal(await auth.authenticate(r.session.accessToken), null);
    assert.equal((await failure(auth.refresh({ refreshToken: r.session.refreshToken }))).code, 'unauthorized');
  });

  it('every refresh failure is the same generic error: unknown, expired, logged out, reused, suspended', async () => {
    const shape = (e: AuthError) => JSON.stringify({ code: e.code, message: e.message, fields: e.fields });
    const shapes = new Set<string>();
    shapes.add(shape(await failure(auth.refresh({ refreshToken: 'nsj_' + 'K'.repeat(43) }))));
    const loggedOut = (await signUp()).r;
    await auth.logout({ refreshToken: loggedOut.session.refreshToken });
    shapes.add(shape(await failure(auth.refresh({ refreshToken: loggedOut.session.refreshToken }))));
    const reused = (await signUp()).r;
    await auth.refresh({ refreshToken: reused.session.refreshToken });
    shapes.add(shape(await failure(auth.refresh({ refreshToken: reused.session.refreshToken }))));
    const susp = await signUp();
    await admin.query(`UPDATE users SET status = 'suspended' WHERE phone_e164 = $1`, [susp.phone]);
    shapes.add(shape(await failure(auth.refresh({ refreshToken: susp.r.session.refreshToken }))));
    const expired = await signUp();
    await admin.query(`UPDATE sessions SET created_at = created_at - interval '40 days', expires_at = expires_at - interval '40 days' WHERE user_id = (SELECT id FROM users WHERE phone_e164 = $1)`, [expired.phone]);
    shapes.add(shape(await failure(auth.refresh({ refreshToken: expired.r.session.refreshToken }))));
    assert.equal(shapes.size, 1, [...shapes].join(' | '));
  });

  it('malformed refresh input is rejected before any database access', async () => {
    for (const body of [null, {}, { refreshToken: 'garbage' }, { refreshToken: 5 }, { refreshToken: 'nsj_' + 'A'.repeat(43), extra: 1 }]) {
      assert.equal((await failure(auth.refresh(body))).code, 'validation_failed');
    }
  });

  it('logs hold event names and ids only: no password, access token, refresh token or secret', async () => {
    const text = log.text();
    assert.ok(text.includes('auth.refresh.rotated') && text.includes('auth.refresh.reuse_detected'));
    for (const secret of [PW, SECRET, '$argon2', 'nsj_', 'eyJ', ...created]) assert.ok(!text.includes(secret), `the log must not contain ${secret}`);
  });
});

describe('rate limiting and trusted proxies over HTTP on PostgreSQL 16', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });
  const json = { 'content-type': 'application/json' };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  it('wrong-password logins are limited per client address, whatever the account; the right client from another address still logs in', async () => {
    const auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET });
    const server = await buildServer!({ config: config(), db: app, auth, rateLimiter: createMemoryRateLimiter() });
    const phone = newPhone();
    await auth.register({ name: 'مستخدم الحد', phone, password: PW });
    const login = (password: string, remoteAddress: string, p = phone) => server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: p, password }), remoteAddress });
    for (let i = 0; i < RATE_LIMITS.login.limit; i++) assert.equal((await login('wrong-password-' + i, '198.51.100.80', newPhone())).statusCode, 401);
    const blocked = await login(PW, '198.51.100.80');
    assert.equal(blocked.statusCode, 429);
    assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS.login.windowSeconds));
    assert.equal((await login(PW, '198.51.100.81')).statusCode, 200);
    await server.close();
  });

  it('registration is limited per client address and a blocked request creates no account', async () => {
    const server = await buildServer!({ config: config(), db: app, auth: createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET }), rateLimiter: createMemoryRateLimiter() });
    const register = (phone: string) => server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'مستخدم التسجيل', phone, password: PW }), remoteAddress: '198.51.100.90' });
    for (let i = 0; i < RATE_LIMITS.register.limit; i++) assert.equal((await register(newPhone())).statusCode, 201);
    const extra = newPhone();
    assert.equal((await register(extra)).statusCode, 429);
    assert.equal((await admin.query('SELECT 1 FROM users WHERE phone_e164 = $1', [extra])).rows.length, 0);
    await server.close();
  });

  it('refresh and logout are limited too, and a spoofed X-Forwarded-For cannot dodge it unless the proxy is trusted', async () => {
    const auth = createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET });
    const untrusted = await buildServer!({ config: config(), db: app, auth, rateLimiter: createMemoryRateLimiter() });
    for (let i = 0; i < RATE_LIMITS.logout.limit; i++) await untrusted.inject({ method: 'POST', url: '/v1/auth/logout', headers: { ...json, 'x-forwarded-for': `203.0.113.${(i % 250) + 1}` }, payload: JSON.stringify({ refreshToken: 'nsj_' + 'A'.repeat(43) }), remoteAddress: '198.51.100.100' });
    const spoofed = await untrusted.inject({ method: 'POST', url: '/v1/auth/logout', headers: { ...json, 'x-forwarded-for': '203.0.113.250' }, payload: JSON.stringify({ refreshToken: 'nsj_' + 'A'.repeat(43) }), remoteAddress: '198.51.100.100' });
    assert.equal(spoofed.statusCode, 429);
    await untrusted.close();

    const trusted = await buildServer!({ config: config(), db: app, auth, rateLimiter: createMemoryRateLimiter(), trustProxy: ['10.0.0.0/8'] });
    for (let i = 0; i < RATE_LIMITS.refresh.limit; i++) await trusted.inject({ method: 'POST', url: '/v1/auth/refresh', headers: { ...json, 'x-forwarded-for': '203.0.113.7' }, payload: JSON.stringify({ refreshToken: 'nsj_' + 'B'.repeat(43) }), remoteAddress: '10.0.0.9' });
    assert.equal((await trusted.inject({ method: 'POST', url: '/v1/auth/refresh', headers: { ...json, 'x-forwarded-for': '203.0.113.7' }, payload: JSON.stringify({ refreshToken: 'nsj_' + 'B'.repeat(43) }), remoteAddress: '10.0.0.9' })).statusCode, 429);
    assert.equal((await trusted.inject({ method: 'POST', url: '/v1/auth/refresh', headers: { ...json, 'x-forwarded-for': '203.0.113.8' }, payload: JSON.stringify({ refreshToken: 'nsj_' + 'B'.repeat(43) }), remoteAddress: '10.0.0.9' })).statusCode, 401, 'another client behind the same proxy is judged on its own');
    await trusted.close();
  });

  it('the full token lifecycle works through HTTP with real argon2: register, refresh (rotation), reuse is refused, logout', async () => {
    const server = await buildServer!({ config: config(), db: app, auth: createAuthService({ store: createPgAuthStore(app), hasher, accessTokenSecret: SECRET }), rateLimiter: createMemoryRateLimiter() });
    const phone = newPhone();
    const reg = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'دورة كاملة', phone, password: PW }) })).json() as { session: { refreshToken: string; accessToken: string } };
    const refreshed = await server.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: reg.session.refreshToken }) });
    assert.equal(refreshed.statusCode, 200);
    const next = (refreshed.json() as { session: { refreshToken: string; accessToken: string } }).session;
    const reuse = await server.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: reg.session.refreshToken }) });
    assert.equal(reuse.statusCode, 401);
    assert.equal(reuse.headers['www-authenticate'], 'Bearer');
    assert.equal((await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${next.accessToken}` } })).statusCode, 401, 'the reuse ended the session');
    for (const body of [refreshed.body, reuse.body]) assert.ok(!body.includes(PW) && !body.includes('$argon2'));
    await server.close();
  });
});

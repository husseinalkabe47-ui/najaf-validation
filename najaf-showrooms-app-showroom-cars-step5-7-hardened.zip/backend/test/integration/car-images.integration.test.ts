// Images of a member's own car (Phase 11.5, Step 5.5) against a real PostgreSQL 16 (migrations 0001-0013 applied), through the
// least-privilege application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: fixtures and cleanup
// ONLY). Skipped visibly when they are missing. Proves what the in-memory unit tests cannot: the column privileges allow exactly
// the statements of the repository, the car_images triggers (cap, asset ownership/readiness, one main at COMMIT) agree with the
// service, deleting a link keeps the asset, and concurrent adds on one car serialize under the car row lock.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, randomInt, randomUUID } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgCarImageStore } from '../../src/car-images/repository.ts';
import { CarImageError, createCarImageService } from '../../src/car-images/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

describe('car images on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  const carIds: string[] = [];
  let A: Actor;
  let B: Actor;
  let svc: ReturnType<typeof createCarImageService>;
  let svc2: ReturnType<typeof createCarImageService>;

  const newUser = async (): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('عضو اختبار', $1, 'user', 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const newCar = async (ownerId: string): Promise<string> => {
    const r = await admin.query<{ id: string }>(
      `INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status, search_text)
       VALUES ('member', $1::bigint, 'Toyota', 'Corolla', 2016, 14500, 'USD', '+9647701234567', 'النجف', 'pending', 'toyota corolla 2016')
       RETURNING id`,
      [ownerId],
    );
    const id = String(r.rows[0]!.id);
    carIds.push(id);
    return id;
  };
  const newAsset = async (ownerId: string, opts: { status?: string; kind?: string } = {}): Promise<string> => {
    const status = opts.status ?? 'ready';
    const id = randomUUID();
    const hex = randomBytes(32).toString('hex');
    if (status === 'ready') {
      await admin.query(
        `INSERT INTO assets (id, owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at)
         VALUES ($1::uuid, $2::bigint, $3, 'ready', $4, $5, 'image/webp', 1000, 800, 600, $6, now())`,
        [id, ownerId, opts.kind ?? 'car_image', `it/${hex}.webp`, `it/${hex}-t.webp`, hex],
      );
    } else {
      await admin.query(`INSERT INTO assets (id, owner_id, kind, status, reject_reason) VALUES ($1::uuid, $2::bigint, $3, $4, $5)`, [id, ownerId, opts.kind ?? 'car_image', status, status === 'rejected' ? 'test' : null]);
    }
    return id;
  };
  const links = async (carId: string) => (await admin.query<{ asset_id: string; sort_order: number; is_main: boolean }>('SELECT asset_id, sort_order, is_main FROM car_images WHERE car_id = $1::bigint ORDER BY sort_order', [carId])).rows.map((r) => ({ ...r }));
  const notFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    A = { id: await newUser(), role: 'member' };
    B = { id: await newUser(), role: 'member' };
    svc = createCarImageService({ store: createPgCarImageStore(app) });
    svc2 = createCarImageService({ store: createPgCarImageStore(app2) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM car_images WHERE car_id = ANY($1::bigint[])', [carIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('attaches the first own asset as main, the next at the end, with an audit row; the car version is untouched', async () => {
    const car = await newCar(A.id);
    const a1 = await newAsset(A.id);
    const a2 = await newAsset(A.id);
    const first = await svc.add(A, car, { assetId: a1 }, { requestId: 'it-img-1' });
    assert.equal(first.isMain, true);
    assert.equal(first.sortOrder, 0);
    assert.equal(first.width, 800);
    const second = await svc.add(A, car, { assetId: a2 });
    assert.equal(second.isMain, false);
    assert.equal(second.sortOrder, 1);
    assert.deepEqual((await links(car)).map((l) => [l.asset_id, l.sort_order, l.is_main]), [[a1, 0, true], [a2, 1, false]]);
    const listed = await svc.list(A, car);
    assert.equal(listed.images.length, 2);
    assert.equal(listed.maxImages, 4);
    const v = await admin.query<{ version: number }>('SELECT version FROM cars WHERE id = $1::bigint', [car]);
    assert.equal(Number(v.rows[0]!.version), 1);
    const audit = await admin.query<{ action: string }>(`SELECT action FROM audit_logs WHERE request_id = 'it-img-1'`);
    assert.deepEqual(audit.rows.map((r) => r.action), ['member_car.image_add']);
  });

  it("another member cannot list, add to or delete from the car (404), and cannot attach someone else's asset", async () => {
    const car = await newCar(A.id);
    const mine = await newAsset(A.id);
    const theirs = await newAsset(B.id);
    const img = await svc.add(A, car, { assetId: mine });
    await assert.rejects(svc.list(B, car), notFound);
    await assert.rejects(svc.add(B, car, { assetId: theirs }), notFound);
    await assert.rejects(svc.remove(B, car, img.id), notFound);
    await assert.rejects(svc.add(A, car, { assetId: theirs }), notFound);
    assert.equal((await links(car)).length, 1);
  });

  it('refuses a pending, rejected or showroom_cover asset and an asset that is already attached (409 invalid_state)', async () => {
    const car = await newCar(A.id);
    const car2 = await newCar(A.id);
    const bad = [await newAsset(A.id, { status: 'pending' }), await newAsset(A.id, { status: 'rejected' }), await newAsset(A.id, { kind: 'showroom_cover' })];
    for (const assetId of bad) await assert.rejects(svc.add(A, car, { assetId }), (e: unknown) => e instanceof CarImageError && e.code === 'invalid_state');
    const ok = await newAsset(A.id);
    await svc.add(A, car, { assetId: ok });
    await assert.rejects(svc.add(A, car2, { assetId: ok }), (e: unknown) => e instanceof CarImageError && e.code === 'invalid_state');
  });

  it('stops at the limit from app_settings (409 image_limit) and a freed slot can be used again', async () => {
    const car = await newCar(A.id);
    const ids: string[] = [];
    for (let i = 0; i < 4; i++) ids.push((await svc.add(A, car, { assetId: await newAsset(A.id) })).id);
    await assert.rejects(svc.add(A, car, { assetId: await newAsset(A.id) }), (e: unknown) => e instanceof CarImageError && e.code === 'image_limit');
    await svc.remove(A, car, ids[3]!);
    await svc.add(A, car, { assetId: await newAsset(A.id) });
    assert.equal((await links(car)).length, 4);
  });

  it('deleting the main image promotes the next one and keeps positions contiguous; the asset is kept and re-attachable', async () => {
    const car = await newCar(A.id);
    const assets = [await newAsset(A.id), await newAsset(A.id), await newAsset(A.id)];
    const imgs = [];
    for (const assetId of assets) imgs.push(await svc.add(A, car, { assetId }));
    await svc.remove(A, car, imgs[0]!.id, { requestId: 'it-img-del' });
    assert.deepEqual((await links(car)).map((l) => [l.asset_id, l.sort_order, l.is_main]), [[assets[1], 0, true], [assets[2], 1, false]]);
    const kept = await admin.query<{ status: string; owner_id: string }>('SELECT status, owner_id FROM assets WHERE id = $1::uuid', [assets[0]]);
    assert.equal(kept.rows[0]!.status, 'ready');
    assert.equal(String(kept.rows[0]!.owner_id), A.id);
    await svc.add(A, car, { assetId: assets[0]! });
    await svc.remove(A, car, (await svc.list(A, car)).images[0]!.id);
    await svc.remove(A, car, (await svc.list(A, car)).images[0]!.id);
    await svc.remove(A, car, (await svc.list(A, car)).images[0]!.id);
    assert.deepEqual(await links(car), []);
    const audit = await admin.query<{ action: string }>(`SELECT action FROM audit_logs WHERE request_id = 'it-img-del'`);
    assert.deepEqual(audit.rows.map((r) => r.action), ['member_car.image_delete']);
  });

  it("an image id of another car is 404 even for the owner of both cars; unknown and deleted cars are 404", async () => {
    const carA = await newCar(A.id);
    const carA2 = await newCar(A.id);
    const img = await svc.add(A, carA, { assetId: await newAsset(A.id) });
    await assert.rejects(svc.remove(A, carA2, img.id), notFound);
    assert.equal((await links(carA)).length, 1);
    await assert.rejects(svc.list(A, '999999999999'), notFound);
    await admin.query('UPDATE cars SET deleted_at = now() WHERE id = $1::bigint', [carA2]);
    await assert.rejects(svc.add(A, carA2, { assetId: await newAsset(A.id) }), notFound);
  });

  it('concurrent adds on one car from two connections never exceed the cap and leave exactly one main', async () => {
    const car = await newCar(A.id);
    const assets: string[] = [];
    for (let i = 0; i < 8; i++) assets.push(await newAsset(A.id));
    const results = await Promise.allSettled(assets.map((assetId, i) => (i % 2 ? svc : svc2).add(A, car, { assetId })));
    const ok = results.filter((r) => r.status === 'fulfilled').length;
    assert.equal(ok, 4);
    for (const r of results) if (r.status === 'rejected') assert.ok(r.reason instanceof CarImageError && r.reason.code === 'image_limit');
    const l = await links(car);
    assert.equal(l.length, 4);
    assert.equal(l.filter((x) => x.is_main).length, 1);
    assert.deepEqual(l.map((x) => x.sort_order), [0, 1, 2, 3]);
  });
});

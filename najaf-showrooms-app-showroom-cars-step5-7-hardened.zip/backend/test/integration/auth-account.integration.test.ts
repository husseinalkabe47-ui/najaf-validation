// Change password and sign out from all devices against a REAL PostgreSQL 16 (migrations 0001-0013 applied) with REAL argon2id,
// through the application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: inspection and cleanup
// ONLY). Skipped visibly when they are missing, or when `argon2` / `fastify` are not installed.
// The race tests are DETERMINISTIC: a transaction is held open on purpose (a "gate") while the competing operation starts, so
// the interleaving that a single-statement revocation would get wrong is exactly the one being exercised.
// audit_logs is append-only (even for the superuser), so the rows these tests create stay in the CI database.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createAccountService } from '../../src/auth/account-service.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { RATE_LIMITS } from '../../src/auth/policy.ts';
import { createPgAuthStore, createPgSessionsRepository } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { generateSessionToken, hashSessionToken } from '../../src/auth/tokens.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AccountApi, AuthApi, AuthResult } from '../../src/auth/types.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { recordingLogger } from '../helpers/fake-auth.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Account-Suite-Passw0rd!';
const NEW_PW = 'Changed-Passw0rd!';
const SECRET = 'integration-account-access-secret-0123456789-ASDFGH';
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);
const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));
const makeGate = () => {
  let release!: () => void;
  const open = new Promise<void>((resolve) => (release = resolve));
  return { open, release };
};

describe('account security on PostgreSQL 16 with real argon2id', { skip: skip || argon2Missing }, () => {
  let app: Db;
  let admin: Db;
  const log = recordingLogger();
  let auth: AuthApi;
  let account: AccountApi;

  type SessionRow = { id: string; family_id: string; revoked_at: Date | null; revoked_reason: string | null; expires_at: Date };
  const sessionRows = async (phone: string): Promise<SessionRow[]> =>
    (await admin.query(`SELECT s.id, s.family_id, s.revoked_at, s.revoked_reason, s.expires_at
                          FROM sessions s JOIN users u ON u.id = s.user_id
                         WHERE u.phone_e164 = $1 ORDER BY s.created_at, s.id`, [phone])).rows as SessionRow[];
  const liveCount = async (phone: string): Promise<number> =>
    ((await admin.query(`SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 AND s.revoked_at IS NULL`, [phone])).rows[0] as { n: number }).n;
  const reasons = async (phone: string): Promise<string[]> => (await sessionRows(phone)).map((r) => r.revoked_reason ?? 'LIVE').sort();
  type AuditRow = { action: string; actor_id: string; actor_role: string; entity_type: string; entity_id: string; after_data: Record<string, unknown>; request_id: string | null; recent: boolean };
  const auditRows = async (userId: string): Promise<AuditRow[]> =>
    (await admin.query(`SELECT a.action, a.actor_id::text AS actor_id, a.actor_role, a.entity_type, a.entity_id, a.after_data, a.request_id,
                               a.occurred_at > now() - interval '5 minutes' AS recent
                          FROM audit_logs a WHERE a.entity_id = $1 ORDER BY a.id`, [userId])).rows as AuditRow[];
  const userRow = async (phone: string) =>
    (await admin.query('SELECT id, password_hash, password_changed_at, failed_logins, locked_until, status FROM users WHERE phone_e164 = $1', [phone])).rows[0] as {
      id: string; password_hash: string; password_changed_at: Date | null; failed_logins: number; locked_until: Date | null; status: string;
    };
  const failure = async (p: Promise<unknown>): Promise<AuthError> => {
    try {
      await p;
    } catch (e) {
      assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
      return e;
    }
    throw new Error('expected a failure');
  };
  /** a user with `extra + 1` independent sign-ins */
  const signUp = async (extra = 0, password = PW) => {
    const phone = newPhone();
    const first = await auth.register({ name: 'مستخدم الحساب', phone: local(phone), password });
    const sessions: AuthResult[] = [first];
    for (let i = 0; i < extra; i++) sessions.push(await auth.login({ phone: local(phone), password }));
    return { phone, userId: first.user.id, sessions };
  };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const store = createPgAuthStore(app);
    auth = createAuthService({ store, hasher, accessTokenSecret: SECRET, logger: log.logger });
    account = createAccountService({ store, hasher, logger: log.logger });
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  // ------------------------------------------------------------------ change password
  it('change password: new password in the database, EVERY session ended (including a rotated chain), and one audit event', async () => {
    const { phone, userId, sessions } = await signUp(2);
    const rotated = await auth.refresh({ refreshToken: sessions[1]!.session.refreshToken });
    const before = await userRow(phone);
    assert.equal(await liveCount(phone), 3);
    assert.deepEqual(await account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW }, { requestId: 'change-req-0001' }), { status: 'password_changed' });
    const after = await userRow(phone);
    assert.notEqual(after.password_hash, before.password_hash);
    assert.match(after.password_hash, /^\$argon2id\$/);
    assert.notEqual(after.password_changed_at, null);
    assert.equal(await liveCount(phone), 0);
    assert.deepEqual(await reasons(phone), ['password_changed', 'password_changed', 'password_changed', 'rotated']);
    for (const s of [...sessions, rotated]) assert.equal(await auth.authenticate(s.session.accessToken), null, 'access tokens die at once');
    for (const s of [sessions[0]!, sessions[2]!, rotated]) assert.equal((await failure(auth.refresh({ refreshToken: s.session.refreshToken }))).code, 'unauthorized');
    assert.equal((await auth.login({ phone: local(phone), password: NEW_PW })).user.id, userId);
    assert.equal((await failure(auth.login({ phone: local(phone), password: PW }))).code, 'invalid_credentials');
    const audit = await auditRows(userId);
    assert.equal(audit.filter((a) => a.action === 'auth.password_changed').length, 1);
    const row = audit.find((a) => a.action === 'auth.password_changed')!;
    assert.deepEqual({ actor: row.actor_id, role: row.actor_role, type: row.entity_type, id: row.entity_id, data: row.after_data, req: row.request_id, recent: row.recent }, { actor: userId, role: 'user', type: 'user', id: userId, data: { sessions_revoked: 3 }, req: 'change-req-0001', recent: true });
  });

  it('a wrong current password changes nothing, counts one failed login, keeps every session and writes no audit event', async () => {
    const { phone, userId, sessions } = await signUp(1);
    const before = await userRow(phone);
    assert.equal((await failure(account.changePassword(userId, { currentPassword: 'definitely-wrong-1', newPassword: NEW_PW }))).code, 'invalid_current_password');
    const after = await userRow(phone);
    assert.equal(after.password_hash, before.password_hash);
    assert.equal(after.failed_logins, 1);
    assert.equal(await liveCount(phone), 2);
    assert.ok(await auth.authenticate(sessions[0]!.session.accessToken));
    assert.equal((await auditRows(userId)).length, 0);
  });

  it('wrong attempts lock the account like failed logins: after 5, even the correct current password is refused', async () => {
    const { phone, userId } = await signUp();
    const before = (await userRow(phone)).password_hash;
    for (let i = 0; i < 5; i++) assert.equal((await failure(account.changePassword(userId, { currentPassword: 'wrong-guess-' + i, newPassword: NEW_PW }))).code, 'invalid_current_password');
    assert.notEqual((await userRow(phone)).locked_until, null);
    assert.equal((await failure(account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW }))).code, 'invalid_current_password');
    assert.equal((await userRow(phone)).password_hash, before);
    assert.equal((await userRow(phone)).failed_logins, 5, 'attempts during the lock are not counted');
    assert.equal((await auditRows(userId)).length, 0);
    await admin.query(`UPDATE users SET locked_until = now() - interval '1 second' WHERE phone_e164 = $1`, [phone]);
    assert.deepEqual(await account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW }), { status: 'password_changed' });
    assert.equal((await userRow(phone)).failed_logins, 0);
  });

  it('a weak new password and the same password are refused without costing an attempt, and nothing changes', async () => {
    const { phone, userId } = await signUp(1);
    const before = await userRow(phone);
    for (const newPassword of ['12345', 'x'.repeat(129), '']) assert.equal((await failure(account.changePassword(userId, { currentPassword: PW, newPassword }))).code, 'validation_failed');
    const same = await failure(account.changePassword(userId, { currentPassword: PW, newPassword: PW }));
    assert.deepEqual(same.fields, [{ field: 'newPassword', code: 'same_as_current' }]);
    const after = await userRow(phone);
    assert.equal(after.password_hash, before.password_hash);
    assert.equal(after.failed_logins, 0);
    assert.equal(await liveCount(phone), 2);
    assert.equal((await auditRows(userId)).length, 0);
  });

  it('a suspended user cannot change the password even with the right current one, and a deleted one neither', async () => {
    const a = await signUp();
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [a.userId]);
    assert.equal((await failure(account.changePassword(a.userId, { currentPassword: PW, newPassword: NEW_PW }))).code, 'unauthorized');
    assert.equal((await failure(account.logoutAll(a.userId))).code, 'unauthorized');
    const b = await signUp();
    await admin.query(`UPDATE users SET deleted_at = now() WHERE id = $1`, [b.userId]);
    assert.equal((await failure(account.changePassword(b.userId, { currentPassword: PW, newPassword: NEW_PW }))).code, 'unauthorized');
    assert.equal((await failure(account.changePassword('987654321012', { currentPassword: PW, newPassword: NEW_PW }))).code, 'unauthorized');
    assert.equal((await auditRows(a.userId)).length + (await auditRows(b.userId)).length, 0);
  });

  it('ownership: changing one user\'s password touches no other user\'s password, sessions or audit trail', async () => {
    const a = await signUp(1);
    const b = await signUp(1);
    const bBefore = (await userRow(b.phone)).password_hash;
    await account.changePassword(a.userId, { currentPassword: PW, newPassword: NEW_PW });
    assert.equal((await userRow(b.phone)).password_hash, bBefore);
    assert.equal(await liveCount(b.phone), 2);
    for (const s of b.sessions) assert.ok(await auth.authenticate(s.session.accessToken));
    assert.equal((await auditRows(b.userId)).length, 0);
    assert.equal((await failure(account.changePassword(a.userId, { currentPassword: PW, newPassword: 'Other-Passw0rd-1', userId: b.userId }))).code, 'validation_failed', 'a user id in the input is refused');
  });

  it('simultaneous changes with the same current password: exactly ONE applies (compare-and-swap), the others are refused, exactly one audit event', async () => {
    const { phone, userId, sessions } = await signUp(2);
    const candidates = ['Candidate-One-Pass1', 'Candidate-Two-Pass2', 'Candidate-Three-Pass3', 'Candidate-Four-Pass4'];
    const results = await Promise.allSettled(candidates.map((newPassword) => account.changePassword(userId, { currentPassword: PW, newPassword })));
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.ok(results.filter((x) => x.status === 'rejected').every((x) => ((x as PromiseRejectedResult).reason as AuthError).code === 'invalid_current_password'));
    const winner = candidates[results.findIndex((x) => x.status === 'fulfilled')] as string;
    assert.ok(await auth.login({ phone: local(phone), password: winner }));
    for (const loser of candidates.filter((c) => c !== winner)) assert.equal((await failure(auth.login({ phone: local(phone), password: loser }))).code, 'invalid_credentials');
    assert.equal((await auditRows(userId)).filter((a) => a.action === 'auth.password_changed').length, 1, 'a losing change leaves no event');
    for (const s of sessions) assert.equal(await auth.authenticate(s.session.accessToken), null);
  });

  // ------------------------------------------------------------------ sign out everywhere
  it('sign out everywhere: every session ends, the requesting access token dies at once, other users are untouched, and one audit event counts them', async () => {
    const a = await signUp(2);
    const b = await signUp(1);
    const rotated = await auth.refresh({ refreshToken: a.sessions[1]!.session.refreshToken });
    const rowsBefore = (await sessionRows(a.phone)).length;
    const bRows = (await sessionRows(b.phone)).length;
    assert.deepEqual(await account.logoutAll(a.userId, { requestId: 'logout-all-req-1' }), { status: 'signed_out_everywhere' });
    assert.equal(await liveCount(a.phone), 0);
    assert.deepEqual(await reasons(a.phone), ['logout_all', 'logout_all', 'logout_all', 'rotated']);
    assert.equal((await sessionRows(a.phone)).length, rowsBefore, 'no session was created');
    for (const s of [...a.sessions, rotated]) assert.equal(await auth.authenticate(s.session.accessToken), null);
    for (const s of [a.sessions[0]!, a.sessions[2]!, rotated]) assert.equal((await failure(auth.refresh({ refreshToken: s.session.refreshToken }))).code, 'unauthorized');
    assert.ok(!(await reasons(a.phone)).includes('reuse_detected'), 'a refresh after sign-out is refused, not a reuse');
    assert.equal(await liveCount(b.phone), 2);
    assert.equal((await sessionRows(b.phone)).length, bRows);
    for (const s of b.sessions) assert.ok(await auth.authenticate(s.session.accessToken));
    const row = (await auditRows(a.userId)).find((x) => x.action === 'auth.logout_all')!;
    assert.deepEqual({ actor: row.actor_id, role: row.actor_role, id: row.entity_id, data: row.after_data, req: row.request_id }, { actor: a.userId, role: 'user', id: a.userId, data: { sessions_revoked: 3 }, req: 'logout-all-req-1' });
    assert.equal((await auditRows(b.userId)).length, 0);
    assert.ok(await auth.login({ phone: local(a.phone), password: PW }), 'signing in again works');
  });

  it('RACE: a refresh that is IN FLIGHT (its transaction open) cannot leave a live session behind a sign-out; its new token is swept up', async () => {
    const { phone, userId, sessions } = await signUp();
    const lockedIn = makeGate();
    const held = makeGate();
    const newToken = generateSessionToken();
    const rotating = app.tx(async (t) => {
      const out = await createPgSessionsRepository(t).rotate({ presentedHash: hashSessionToken(sessions[0]!.session.refreshToken), newHash: hashSessionToken(newToken), userAgent: null });
      lockedIn.release();
      await held.open; // the refresh has locked its row and inserted the new one, but has NOT committed
      return out;
    });
    await lockedIn.open;
    const revoking = account.logoutAll(userId); // must WAIT for the refresh instead of missing its new row
    await sleep(250);
    held.release();
    const [rotated] = await Promise.all([rotating, revoking]);
    assert.equal(rotated.kind, 'rotated', 'the refresh won the lock first');
    assert.equal(await liveCount(phone), 0, 'yet nothing is live afterwards: the sign-out saw the new row');
    assert.deepEqual(await reasons(phone), ['logout_all', 'rotated']);
    assert.equal((await failure(auth.refresh({ refreshToken: newToken }))).code, 'unauthorized', 'the token the in-flight refresh created is dead');
    assert.equal((await auditRows(userId)).find((a) => a.action === 'auth.logout_all')?.after_data['sessions_revoked'], 1);
  });

  it('RACE: a sign-out in flight makes a refresh that starts meanwhile fail, and issues no token', async () => {
    const { phone, userId, sessions } = await signUp();
    const rowsBefore = (await sessionRows(phone)).length;
    const lockedIn = makeGate();
    const held = makeGate();
    const revoking = app.tx(async (t) => {
      const n = await createPgSessionsRepository(t).revokeAllLive(userId, 'logout_all');
      lockedIn.release();
      await held.open;
      return n;
    });
    await lockedIn.open;
    const refreshing = Promise.allSettled([auth.refresh({ refreshToken: sessions[0]!.session.refreshToken })]);
    await sleep(250);
    held.release();
    assert.equal(await revoking, 1);
    const [settled] = await refreshing;
    assert.equal(settled.status, 'rejected');
    assert.equal(((settled as PromiseRejectedResult).reason as AuthError).code, 'unauthorized');
    assert.equal((await sessionRows(phone)).length, rowsBefore, 'the refused refresh created no row');
    assert.equal(await liveCount(phone), 0);
    assert.ok(!(await reasons(phone)).includes('reuse_detected'));
  });

  it('RACE: a password change racing with an in-flight refresh also leaves nothing live', async () => {
    const { phone, userId, sessions } = await signUp();
    const lockedIn = makeGate();
    const held = makeGate();
    const newToken = generateSessionToken();
    const rotating = app.tx(async (t) => {
      const out = await createPgSessionsRepository(t).rotate({ presentedHash: hashSessionToken(sessions[0]!.session.refreshToken), newHash: hashSessionToken(newToken), userAgent: null });
      lockedIn.release();
      await held.open;
      return out;
    });
    await lockedIn.open;
    const changing = account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW });
    await sleep(250);
    held.release();
    await Promise.all([rotating, changing]);
    assert.equal(await liveCount(phone), 0);
    assert.equal((await failure(auth.refresh({ refreshToken: newToken }))).code, 'unauthorized');
  });

  it('RACE: a storm of refreshes and sign-outs at once always ends with no live session and no unexpected error', async () => {
    const { phone, userId, sessions } = await signUp(5);
    const ops: Array<Promise<unknown>> = [
      ...sessions.map((s) => auth.refresh({ refreshToken: s.session.refreshToken })),
      account.logoutAll(userId),
      account.logoutAll(userId),
      account.logoutAll(userId),
    ];
    const results = await Promise.allSettled(ops);
    for (const r of results) {
      if (r.status === 'rejected') assert.ok((r.reason as AuthError).code === 'unauthorized', `unexpected failure: ${String(r.reason)}`);
    }
    assert.ok(results.slice(-3).every((r) => r.status === 'fulfilled'), 'every sign-out succeeded');
    assert.equal(await liveCount(phone), 0, 'whatever the interleaving, nothing is live afterwards');
    assert.ok(!(await reasons(phone)).includes('reuse_detected'));
  });

  it('simultaneous sign-outs are all fine, and the ended sessions are counted exactly once across the audit events', async () => {
    const { phone, userId } = await signUp(2);
    const results = await Promise.allSettled(Array.from({ length: 8 }, () => account.logoutAll(userId)));
    assert.ok(results.every((r) => r.status === 'fulfilled'));
    assert.equal(await liveCount(phone), 0);
    const events = (await auditRows(userId)).filter((a) => a.action === 'auth.logout_all');
    assert.equal(events.length, 8);
    assert.equal(events.reduce((n, e) => n + Number(e.after_data['sessions_revoked']), 0), 3);
  });

  // ------------------------------------------------------------------ audit trail
  it('audit_logs is append-only for EVERYONE: the application role cannot update or delete, and not even the superuser can', async () => {
    const { userId } = await signUp();
    await account.logoutAll(userId);
    const forbidden = (e: unknown) => (e as { kind?: string }).kind === 'forbidden';
    await assert.rejects(app.query(`UPDATE audit_logs SET action = 'tampered' WHERE entity_id = $1`, [userId]), forbidden);
    await assert.rejects(app.query(`DELETE FROM audit_logs WHERE entity_id = $1`, [userId]), forbidden);
    const trigger = (e: unknown) => forbidden(e) && String((e as { driverMessage?: string }).driverMessage).includes('append-only');
    await assert.rejects(admin.query(`UPDATE audit_logs SET action = 'tampered' WHERE entity_id = $1`, [userId]), trigger);
    await assert.rejects(admin.query(`DELETE FROM audit_logs WHERE entity_id = $1`, [userId]), trigger);
    assert.equal((await auditRows(userId))[0]?.action, 'auth.logout_all', 'the row is intact');
  });

  it('the audit trail contains no secret: no password, hash, token, code, phone number or name', async () => {
    const { phone, userId, sessions } = await signUp(1);
    await account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW }, { requestId: 'secret-check-req-1' });
    const fresh = await auth.login({ phone: local(phone), password: NEW_PW });
    await account.logoutAll(userId, { requestId: 'secret-check-req-2' });
    const everything = JSON.stringify((await admin.query(`SELECT a.* FROM audit_logs a WHERE a.entity_id = $1`, [userId])).rows);
    assert.ok(everything.includes('auth.password_changed') && everything.includes('auth.logout_all'));
    const secrets = [PW, NEW_PW, '$argon2', 'nsj_', 'eyJ', SECRET, phone, local(phone), 'مستخدم الحساب', sessions[0]!.session.refreshToken, sessions[0]!.session.accessToken, fresh.session.refreshToken, (await userRow(phone)).password_hash];
    for (const secret of secrets) assert.ok(!everything.includes(secret), `the audit trail must not contain ${secret.slice(0, 14)}`);
  });

  it('logs hold event names, ids and counts only: no password, hash, token or secret', async () => {
    const text = log.text();
    assert.ok(text.includes('auth.password_changed') && text.includes('auth.logout_all') && text.includes('auth.password_change.rejected'));
    const secrets = [PW, NEW_PW, 'wrong-guess', 'definitely-wrong', 'Candidate-', '$argon2', 'nsj_', 'eyJ', SECRET, ...created, ...created.map(local)];
    for (const secret of secrets) assert.ok(!text.includes(secret), `the log must not contain ${secret}`);
  });
});

describe('account security over HTTP on PostgreSQL 16', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });
  const json = { 'content-type': 'application/json' };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });
  const stack = async (withLimiter = false) => {
    const store = createPgAuthStore(app);
    const auth = createAuthService({ store, hasher, accessTokenSecret: SECRET });
    const account = createAccountService({ store, hasher });
    return buildServer!({ config: config(), db: app, auth, account, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter() } : {}) });
  };
  const register = async (server: Awaited<ReturnType<BuildServer>>, name: string) => {
    const phone = newPhone();
    const r = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name, phone: local(phone), password: PW }) })).json() as { user: { id: string }; session: { accessToken: string; refreshToken: string } };
    return { phone, userId: r.user.id, ...r.session };
  };

  it('change password end to end: refusals are generic, success ends every session, the request id reaches the audit row, and no body carries a secret', async () => {
    const server = await stack();
    const u = await register(server, 'تغيير HTTP');
    const second = (await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: local(u.phone), password: PW }) })).json() as { session: { accessToken: string; refreshToken: string } };
    const bearer = { authorization: `Bearer ${u.accessToken}` };
    const post = (payload: unknown, headers: Record<string, string> = bearer) => server.inject({ method: 'POST', url: '/v1/auth/password/change', headers: { ...json, ...headers }, payload: JSON.stringify(payload) });
    assert.equal((await post({ currentPassword: PW, newPassword: NEW_PW }, {})).statusCode, 401);
    const wrong = await post({ currentPassword: 'not-my-password', newPassword: NEW_PW });
    assert.equal(wrong.statusCode, 400);
    assert.equal((wrong.json() as { error: { code: string } }).error.code, 'invalid_current_password');
    const weak = await post({ currentPassword: PW, newPassword: '123' });
    assert.deepEqual((weak.json() as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'too_short' }]);
    const same = await post({ currentPassword: PW, newPassword: PW });
    assert.deepEqual((same.json() as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'same_as_current' }]);
    const stray = await post({ currentPassword: PW, newPassword: NEW_PW, userId: '1' });
    assert.deepEqual((stray.json() as { error: { fields: unknown } }).error.fields, [{ field: 'userId', code: 'unknown_field' }]);
    const ok = await post({ currentPassword: PW, newPassword: NEW_PW }, { ...bearer, 'x-request-id': 'http-change-req-0001' });
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { status: 'password_changed' });
    for (const r of [wrong, weak, same, stray, ok]) assert.ok(!r.body.includes(PW) && !r.body.includes(NEW_PW) && !r.body.includes('$argon2') && !r.body.includes('not-my-password'));
    for (const token of [u.accessToken, second.session.accessToken]) assert.equal((await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${token}` } })).statusCode, 401);
    for (const refreshToken of [u.refreshToken, second.session.refreshToken]) assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken }) })).statusCode, 401);
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: local(u.phone), password: NEW_PW }) })).statusCode, 200);
    const audit = (await admin.query(`SELECT a.request_id, a.after_data FROM audit_logs a WHERE a.entity_id = $1 AND a.action = 'auth.password_changed'`, [u.userId])).rows;
    assert.deepEqual(audit, [{ request_id: 'http-change-req-0001', after_data: { sessions_revoked: 2 } }]);
    await server.close();
  });

  it('sign out everywhere end to end: 204, every token of the user dies, another user is untouched, a user id in the request is ignored', async () => {
    const server = await stack();
    const a = await register(server, 'خروج أ');
    const b = await register(server, 'خروج ب');
    const aSecond = (await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: local(a.phone), password: PW }) })).json() as { session: { accessToken: string; refreshToken: string } };
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/logout/all' })).statusCode, 401);
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/logout/all', headers: { authorization: `Bearer ${a.refreshToken}` } })).statusCode, 401, 'a refresh token is not an access token');
    const out = await server.inject({ method: 'POST', url: `/v1/auth/logout/all?userId=${b.userId}`, headers: { ...json, authorization: `Bearer ${a.accessToken}`, 'x-request-id': 'http-logout-all-0001' }, payload: JSON.stringify({ userId: b.userId }) });
    assert.equal(out.statusCode, 204);
    assert.equal(out.body, '');
    for (const token of [a.accessToken, aSecond.session.accessToken]) assert.equal((await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${token}` } })).statusCode, 401);
    for (const refreshToken of [a.refreshToken, aSecond.session.refreshToken]) assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken }) })).statusCode, 401);
    assert.equal((await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${b.accessToken}` } })).statusCode, 200, 'user B is untouched');
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: b.refreshToken }) })).statusCode, 200);
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/logout/all', headers: { authorization: `Bearer ${a.accessToken}` } })).statusCode, 401, 'repeating it with the dead token is refused');
    const audit = (await admin.query(`SELECT a.request_id, a.after_data FROM audit_logs a WHERE a.entity_id = $1 AND a.action = 'auth.logout_all'`, [a.userId])).rows;
    assert.deepEqual(audit, [{ request_id: 'http-logout-all-0001', after_data: { sessions_revoked: 2 } }]);
    assert.equal((await admin.query(`SELECT 1 FROM audit_logs a WHERE a.entity_id = $1`, [b.userId])).rows.length, 0, 'nothing was recorded against B');
    await server.close();
  });

  it('a suspended account gets 401 on both routes, exactly like any dead token', async () => {
    const server = await stack();
    const u = await register(server, 'موقوف HTTP');
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [u.userId]);
    const bearer = { authorization: `Bearer ${u.accessToken}` };
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/logout/all', headers: bearer })).statusCode, 401);
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/password/change', headers: { ...json, ...bearer }, payload: JSON.stringify({ currentPassword: PW, newPassword: NEW_PW }) })).statusCode, 401);
    await server.close();
  });

  it('both routes are rate limited per client address (429 + Retry-After)', async () => {
    const server = await stack(true);
    const u = await register(server, 'حد المعدل');
    const bearer = { authorization: `Bearer ${u.accessToken}` };
    const change = () => server.inject({ method: 'POST', url: '/v1/auth/password/change', headers: { ...json, ...bearer }, payload: JSON.stringify({ currentPassword: 'not-the-password', newPassword: NEW_PW }), remoteAddress: '198.51.100.99' });
    for (let i = 0; i < RATE_LIMITS.passwordChange.limit; i++) assert.equal((await change()).statusCode, 400);
    const blocked = await change();
    assert.equal(blocked.statusCode, 429);
    assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS.passwordChange.windowSeconds));
    await server.close();
  });
});

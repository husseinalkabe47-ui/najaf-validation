// Showroom cars (Phase 11.5, Step 5.7) against a real PostgreSQL 16 (migrations 0001-0013 applied), through the least-privilege
// application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY). Skipped
// visibly when they are missing. Proves what the in-memory unit tests cannot: the 0013 privileges allow exactly these statements,
// the CHECKs accept what validation lets through, touch_versioned and the soft-delete trigger run, public_cars shows an available
// car of a public showroom (and hides it otherwise), and two writers on the SAME version cannot both win.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgShowroomCarStore } from '../../src/showroom-cars/repository.ts';
import { ShowroomCarError, createShowroomCarService } from '../../src/showroom-cars/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const VALID = { brand: 'Kia', model: 'Sportage', year: 2022, price: 31000000, currency: 'IQD', color: 'أبيض' };

describe('showroom cars on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  let D1: Actor;
  let D2: Actor;
  let A: Actor;
  let M: Actor;
  let s1: string;
  let svc: ReturnType<typeof createShowroomCarService>;
  let svc2: ReturnType<typeof createShowroomCarService>;

  const newUser = async (role: 'user' | 'dealer' | 'admin'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone, role],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const newShowroom = async (ownerId: string, status = 'active'): Promise<string> =>
    String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', $2) RETURNING id`, [ownerId, status])).rows[0]!.id);
  const row = async (id: string) => (await admin.query<Record<string, unknown>>('SELECT showroom_id, owner_id, source_type, status, version, deleted_at, price, phone FROM cars WHERE id = $1', [id])).rows[0]!;
  const isPublic = async (id: string) => (await app.query('SELECT 1 FROM public_cars WHERE id = $1::bigint', [id])).rows.length === 1;
  const notFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    D1 = { id: await newUser('dealer'), role: 'dealer' };
    D2 = { id: await newUser('dealer'), role: 'dealer' };
    A = { id: await newUser('admin'), role: 'admin' };
    M = { id: await newUser('user'), role: 'member' };
    s1 = await newShowroom(D1.id);
    await newShowroom(D2.id);
    svc = createShowroomCarService({ store: createPgShowroomCarStore(app) });
    svc2 = createShowroomCarService({ store: createPgShowroomCarStore(app2) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM cars WHERE showroom_id IN (SELECT id FROM showrooms WHERE owner_id = ANY($1::bigint[]))', [userIds]);
      await admin.query('DELETE FROM showrooms WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('creates an available showroom car in the dealer\'s showroom, public at once, with an audit row', async () => {
    const car = await svc.create(D1, VALID, { requestId: 'it-sc-1' });
    assert.equal(car.status, 'available');
    assert.equal(car.showroomId, s1);
    const r = await row(car.id);
    assert.equal(String(r['showroom_id']), s1);
    assert.equal(r['owner_id'], null);
    assert.equal(r['source_type'], 'showroom');
    assert.equal(r['phone'], null);
    assert.ok(await isPublic(car.id));
    const audit = await admin.query<{ action: string; actor_role: string }>(`SELECT action, actor_role FROM audit_logs WHERE request_id = 'it-sc-1'`);
    assert.deepEqual(audit.rows.map((a) => ({ ...a })), [{ action: 'showroom_car.create', actor_role: 'dealer' }]);
  });

  it('another dealer, a member and an administrator cannot read, update or delete it (404); the row is unchanged', async () => {
    const car = await svc.create(D1, VALID);
    for (const who of [D2, M, A]) {
      await assert.rejects(svc.getOwn(who, car.id), notFound);
      await assert.rejects(svc.update(who, car.id, { version: 1, price: 1 }), notFound);
      await assert.rejects(svc.remove(who, car.id, { version: '1' }), notFound);
    }
    const r = await row(car.id);
    assert.equal(Number(r['version']), 1);
    assert.equal(r['deleted_at'], null);
  });

  it('updates with the version (trigger bumps it), refuses a stale version, and soft-deletes (favorites removed)', async () => {
    const car = await svc.create(D1, VALID);
    const u = await svc.update(D1, car.id, { version: 1, price: 30000000, status: 'sold' });
    assert.equal(u.version, 2);
    assert.equal(u.status, 'sold');
    await assert.rejects(svc.update(D1, car.id, { version: 1, price: 2 }), (e: unknown) => e instanceof ShowroomCarError && e.code === 'version_conflict');
    await admin.query('INSERT INTO favorites (user_id, car_id) VALUES ($1::bigint, $2::bigint)', [M.id, car.id]);
    await svc.remove(D1, car.id, { version: '2' });
    assert.notEqual((await row(car.id))['deleted_at'], null);
    assert.equal((await admin.query('SELECT 1 FROM favorites WHERE car_id = $1::bigint', [car.id])).rows.length, 0);
    await assert.rejects(svc.getOwn(D1, car.id), notFound);
  });

  it('the administrator changes only the status; a dealer cannot use that route', async () => {
    const car = await svc.create(D1, VALID);
    await assert.rejects(svc.setStatusAsAdmin(D1, car.id, { version: 1, status: 'sold' }), notFound);
    const r = await svc.setStatusAsAdmin(A, car.id, { version: 1, status: 'sold' }, { requestId: 'it-sc-admin' });
    assert.equal(r.status, 'sold');
    assert.equal(r.price, VALID.price);
    const audit = await admin.query<{ action: string; actor_role: string }>(`SELECT action, actor_role FROM audit_logs WHERE request_id = 'it-sc-admin'`);
    assert.deepEqual(audit.rows.map((a) => ({ ...a })), [{ action: 'showroom_car.admin_mark_sold', actor_role: 'admin' }]);
  });

  it('a car of a suspended showroom is stored and managed but is not public', async () => {
    const d3: Actor = { id: await newUser('dealer'), role: 'dealer' };
    await newShowroom(d3.id, 'suspended');
    const car = await svc.create(d3, VALID);
    assert.equal(car.status, 'available');
    assert.equal(await isPublic(car.id), false);
  });

  it('concurrent writers on the same version over two connections: exactly one wins', async () => {
    const car = await svc.create(D1, VALID);
    const results = await Promise.allSettled([
      svc.update(D1, car.id, { version: 1, price: 1 }),
      svc2.update(D1, car.id, { version: 1, price: 2 }),
      svc2.setStatusAsAdmin(A, car.id, { version: 1, status: 'sold' }),
    ]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(Number((await row(car.id))['version']), 2);
  });

  it('the application role cannot move a car to another showroom', async () => {
    const car = await svc.create(D1, VALID);
    await assert.rejects(app.query('UPDATE cars SET showroom_id = showroom_id WHERE id = $1::bigint', [car.id]), /permission denied/);
  });
});

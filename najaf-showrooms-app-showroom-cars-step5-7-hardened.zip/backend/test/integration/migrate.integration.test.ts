// The migration runner against a real, EMPTY PostgreSQL 16 database (node-pg-migrate 9.0.0, real wrappers + rollback scripts).
//   MIGRATION_DATABASE_URL  the dedicated migration account (owner of the database, CREATEROLE, not superuser, not a najaf_app member)
//   ADMIN_DATABASE_URL      superuser, used ONLY to inspect the catalog
//   DATABASE_URL            (optional) the application login, used for the negative checks
// The suite is destructive (it rolls everything back), so it refuses a non-empty database or a name without test/mig/ci.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { loadMigrationConfig, MigrationConfigError } from '../../src/migrate/config.ts';
import { listMigrationNames } from '../../src/migrate/paths.ts';
import { MigrationRoleError, assertMigrationRole, migrationRoleViolations, preflightMigrationRole } from '../../src/migrate/preflight.ts';
import { migrationStatus, runMigrations } from '../../src/migrate/runner.ts';
import type { MigrationClientConfig } from '../../src/migrate/config.ts';

const MIGRATION_URL = process.env['MIGRATION_DATABASE_URL'];
const ADMIN_URL = process.env['ADMIN_DATABASE_URL'];
const APP_URL = process.env['DATABASE_URL'];
const skip: string | false = MIGRATION_URL && ADMIN_URL ? false : 'migration integration tests need MIGRATION_DATABASE_URL and ADMIN_DATABASE_URL';

interface AdminClient {
  connect(): Promise<void>;
  query(text: string, values?: unknown[]): Promise<{ rows: Array<Record<string, unknown>> }>;
  end(): Promise<void>;
}
async function adminClient(): Promise<AdminClient> {
  const mod = (await import('pg')) as unknown as { default?: { Client: new (o: Record<string, unknown>) => AdminClient }; Client?: new (o: Record<string, unknown>) => AdminClient };
  const Client = mod.default?.Client ?? mod.Client!;
  return new Client({ connectionString: ADMIN_URL });
}

function clientConfigFromUrl(url: string): MigrationClientConfig {
  const u = new URL(url);
  return { host: u.hostname, port: Number(u.port || 5432), database: decodeURIComponent(u.pathname.slice(1)), user: decodeURIComponent(u.username), password: decodeURIComponent(u.password), ssl: false, application_name: 'najaf-migrate-test' };
}

const cfg = () => loadMigrationConfig({ NODE_ENV: 'test', MIGRATION_DATABASE_URL: MIGRATION_URL, DATABASE_URL: APP_URL });

describe('migration runner on an empty PostgreSQL 16 database', { skip }, () => {
  let admin: AdminClient;
  const scalar = async (sql: string): Promise<string> => String((await admin.query(sql)).rows[0]?.['v']);
  const publicTables = () => scalar(`SELECT count(*) AS v FROM pg_tables WHERE schemaname = 'public'`);
  const tracked = () => scalar(`SELECT count(*) AS v FROM ops.pgmigrations`);
  const emptyCatalog = () =>
    scalar(`SELECT (SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'public' AND c.relkind IN ('r','v','S','m','p','f'))
                   || ' relations, ' || (SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'public'
                        AND NOT EXISTS (SELECT 1 FROM pg_depend d WHERE d.objid = p.oid AND d.deptype = 'e'))
                   || ' own functions, ' || (SELECT count(*) FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace WHERE n.nspname = 'public' AND t.typtype = 'd')
                   || ' domains, extensions=' || (SELECT string_agg(extname, ',' ORDER BY extname) FROM pg_extension) AS v`);

  before(async () => {
    admin = await adminClient();
    await admin.connect();
    const dbName = await scalar('SELECT current_database() AS v');
    assert.match(dbName, /test|mig|ci/i, `refusing to run a destructive suite on database "${dbName}" (its name must contain test, mig or ci)`);
    assert.equal(await emptyCatalog(), '0 relations, 0 own functions, 0 domains, extensions=plpgsql', 'the database must be empty before this suite');
  });
  after(async () => {
    await admin.end();
  });

  it('pre-flight: the migration account is accepted and is not an application identity', async () => {
    const r = await assertMigrationRole(cfg());
    assert.equal(r.canUseAppRole, false);
    assert.equal(r.canSetAppRole, false);
    assert.ok(r.serverVersionNum >= 160000);
  });

  it('up: applies the 13 unmodified migrations in order, tracked in ops.pgmigrations only', async () => {
    const result = await runMigrations(cfg(), { direction: 'up' });
    assert.equal(result.ran.length, 13);
    assert.deepEqual([...result.ran].sort(), result.ran);
    assert.equal(await tracked(), '13');
    assert.equal(await publicTables(), '16');
    assert.equal(await scalar(`SELECT to_regclass('ops.pgmigrations') IS NOT NULL AS v`), 'true');
    assert.equal(await scalar(`SELECT to_regclass('public.pgmigrations') IS NULL AS v`), 'true');
  });

  it('up again is a no-op and status shows nothing pending', async () => {
    assert.deepEqual((await runMigrations(cfg(), { direction: 'up' })).ran, []);
    const s = await migrationStatus(cfg());
    assert.deepEqual(s, { applied: listMigrationNames(), pending: [], unknown: [] });
  });

  it('after creating najaf_app the migration account STILL passes the pre-flight (PostgreSQL 16 gives the creator ADMIN OPTION only)', async () => {
    const r = await preflightMigrationRole(cfg().client);
    assert.equal(r.canUseAppRole, false, 'the migration account must not inherit najaf_app privileges');
    assert.equal(r.canSetAppRole, false, 'the migration account must not be able to SET ROLE najaf_app');
    assert.deepEqual(migrationRoleViolations(r), []);
    await assert.doesNotReject(assertMigrationRole(cfg()));
  });

  it('down 1 reverts exactly 0013 (the pre-hardening privileges return), and up restores it', async () => {
    const down = await runMigrations(cfg(), { direction: 'down', steps: 1 });
    assert.equal(down.ran.length, 1);
    assert.match(down.ran[0] as string, /0013/);
    assert.equal(await tracked(), '12');
    assert.equal(await scalar(`SELECT has_table_privilege('najaf_app', 'cars', 'UPDATE') AS v`), 'true');
    assert.equal(await scalar(`SELECT has_column_privilege('najaf_app', 'cars', 'created_at', 'UPDATE') AS v`), 'true');
    const up = await runMigrations(cfg(), { direction: 'up' });
    assert.equal(up.ran.length, 1);
    assert.equal(await scalar(`SELECT has_table_privilege('najaf_app', 'cars', 'UPDATE') AS v`), 'false');
    assert.equal(await scalar(`SELECT has_column_privilege('najaf_app', 'cars', 'created_at', 'UPDATE') AS v`), 'false');
    assert.equal(await tracked(), '13');
  });

  it('down --all leaves an empty database (cluster roles are kept), and up rebuilds it', async () => {
    const down = await runMigrations(cfg(), { direction: 'down', steps: 'all' });
    assert.equal(down.ran.length, 13);
    assert.equal(await emptyCatalog(), '0 relations, 0 own functions, 0 domains, extensions=plpgsql');
    assert.equal(await tracked(), '0');
    assert.equal(await scalar(`SELECT count(*) AS v FROM pg_roles WHERE rolname IN ('najaf_app','najaf_report')`), '2');
    const up = await runMigrations(cfg(), { direction: 'up' });
    assert.equal(up.ran.length, 13);
    assert.equal(await publicTables(), '16');
  });

  it('the application login is rejected as a migration account (config rule and role check)', { skip: APP_URL ? false : 'DATABASE_URL (application login) not provided' }, async () => {
    // najaf_app is created by migration 0012. If it is missing here, the earlier tests did not apply the migrations: fail with that cause.
    assert.equal(await scalar(`SELECT count(*) AS v FROM pg_roles WHERE rolname = 'najaf_app'`), '1', 'role najaf_app does not exist: the migrations were not applied by the previous tests in this suite');
    // The login role is created here (superuser, only if missing) from the credentials in DATABASE_URL: it needs najaf_app, which exists now.
    const app = clientConfigFromUrl(APP_URL as string);
    const create = await admin.query(
      `SELECT format('CREATE ROLE %I LOGIN PASSWORD %L IN ROLE najaf_app', $1::text, $2::text) AS v WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = $1::text)`,
      [app.user, app.password],
    );
    if (create.rows[0]) await admin.query(String(create.rows[0]['v']));
    assert.throws(() => loadMigrationConfig({ MIGRATION_DATABASE_URL: APP_URL }), MigrationConfigError);
    const report = await preflightMigrationRole(clientConfigFromUrl(APP_URL as string));
    assert.equal(report.canUseAppRole, true, 'the application login inherits najaf_app privileges');
    assert.ok(migrationRoleViolations(report).some((m) => m.includes('najaf_app')));
    await assert.rejects(
      assertMigrationRole({ ...cfg(), client: clientConfigFromUrl(APP_URL as string) }),
      (e: unknown) => e instanceof MigrationRoleError,
    );
  });

  it('the command-line tool reports status as JSON without secrets', () => {
    const r = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', 'scripts/migrate.ts', 'status'], {
      cwd: join(import.meta.dirname, '..', '..'),
      env: { PATH: process.env['PATH'] ?? '', NODE_ENV: 'test', MIGRATION_DATABASE_URL: MIGRATION_URL as string, ...(APP_URL ? { DATABASE_URL: APP_URL } : {}) },
      encoding: 'utf8',
    });
    assert.equal(r.status, 0, r.stderr);
    const out = JSON.parse(r.stdout) as { ok: boolean; applied: string[]; pending: string[] };
    assert.equal(out.ok, true);
    assert.equal(out.applied.length, 13);
    assert.deepEqual(out.pending, []);
    const password = decodeURIComponent(new URL(MIGRATION_URL as string).password);
    assert.ok(!r.stdout.includes(password) && !r.stderr.includes(password));
  });

  it('the command-line tool keeps stdout clean for down and up: exactly one JSON result document, migration logs go to stderr', () => {
    const cli = (args: string[]) =>
      spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', 'scripts/migrate.ts', ...args], {
        cwd: join(import.meta.dirname, '..', '..'),
        env: { PATH: process.env['PATH'] ?? '', NODE_ENV: 'test', MIGRATION_DATABASE_URL: MIGRATION_URL as string, ...(APP_URL ? { DATABASE_URL: APP_URL } : {}) },
        encoding: 'utf8',
      });
    const password = decodeURIComponent(new URL(MIGRATION_URL as string).password);
    for (const [args, direction] of [[['down', '--steps', '1'], 'down'], [['up'], 'up']] as const) {
      const r = cli([...args]);
      assert.equal(r.status, 0, `${args.join(' ')} failed: ${r.stderr}`);
      const out = JSON.parse(r.stdout) as { ok: boolean; direction: string; ran: string[] }; // the WHOLE stdout must be one document
      assert.equal(out.ok, true);
      assert.equal(out.direction, direction);
      assert.equal(out.ran.length, 1, `${args.join(' ')} should have run exactly one migration`);
      assert.ok(r.stdout.trimStart().startsWith('{') && r.stdout.trimEnd().endsWith('}'), 'stdout must be only the JSON document');
      assert.ok(!r.stdout.includes('"level"') && !r.stdout.includes('node-pg-migrate'), 'no log line may reach stdout');
      assert.ok(!r.stdout.includes(password) && !r.stderr.includes(password));
    }
    const status = JSON.parse(cli(['status']).stdout) as { applied: string[]; pending: string[] };
    assert.equal(status.applied.length, 13, 'the suite must leave all 13 migrations applied');
    assert.deepEqual(status.pending, []);
  });
});

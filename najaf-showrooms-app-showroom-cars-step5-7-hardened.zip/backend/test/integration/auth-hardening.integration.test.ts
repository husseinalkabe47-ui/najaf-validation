// Step 5.0 hardening against a REAL PostgreSQL 16 (migrations 0001-0013 applied) with REAL argon2id, through the application role.
// Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: inspection and cleanup ONLY). Skipped visibly otherwise.
// Every race is DETERMINISTIC and sleep-free: a transaction is stopped at an exact point (before it starts, or before it commits)
// while the competing operation runs; where the competitor must block on a row lock, the test waits until PostgreSQL reports a
// backend actually waiting for a lock. audit_logs is append-only, so the rows these tests create stay in the CI database.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { createAccountService } from '../../src/auth/account-service.ts';
import { createOtpService } from '../../src/auth/otp-service.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createPgAuthStore, createPgSessionsRepository } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { generateSessionToken, hashSessionToken } from '../../src/auth/tokens.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AuthApi, AuthResult, OtpApi, AccountApi } from '../../src/auth/types.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeProvider } from '../helpers/fake-messaging.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';
import { failAfterBody, failAudit, holdBeforeCommit, holdBeforeTransaction, makeGate, waitForLockWaiters } from '../helpers/pg-race.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Hardening-Suite-Passw0rd!';
const NEW_PW = 'Changed-By-Hardening-1!';
const SECRET = 'integration-hardening-access-secret-0123456789-ZXCVB';
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);

describe('hardening on PostgreSQL 16 with real argon2id', { skip: skip || argon2Missing }, () => {
  let app: Db;
  let admin: Db;
  const log = recordingLogger();
  const msg = makeFakeProvider();
  let store: ReturnType<typeof createPgAuthStore>;
  let auth: AuthApi;
  let account: AccountApi;
  let otp: OtpApi;

  type SessionRow = { id: string; revoked_at: Date | null; revoked_reason: string | null };
  const sessionRows = async (phone: string): Promise<SessionRow[]> =>
    (await admin.query(`SELECT s.id, s.revoked_at, s.revoked_reason FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 ORDER BY s.created_at, s.id`, [phone])).rows as SessionRow[];
  const liveCount = async (phone: string): Promise<number> =>
    ((await admin.query(`SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 AND s.revoked_at IS NULL`, [phone])).rows[0] as { n: number }).n;
  const userRow = async (phone: string) =>
    (await admin.query('SELECT id, password_hash, failed_logins, locked_until FROM users WHERE phone_e164 = $1', [phone])).rows[0] as { id: string; password_hash: string; failed_logins: number; locked_until: Date | null };
  type AuditRow = { action: string; actor_id: string; actor_role: string; entity_type: string; entity_id: string; after_data: Record<string, unknown>; request_id: string | null };
  const auditRows = async (userId: string): Promise<AuditRow[]> =>
    (await admin.query(`SELECT a.action, a.actor_id::text AS actor_id, a.actor_role, a.entity_type, a.entity_id, a.after_data, a.request_id FROM audit_logs a WHERE a.entity_id = $1 ORDER BY a.id`, [userId])).rows as AuditRow[];
  const codeRow = async (userId: string) =>
    (await admin.query(`SELECT c.consumed_at, c.attempts FROM verification_codes c WHERE c.user_id = $1 AND c.purpose = 'password_reset' ORDER BY c.id DESC LIMIT 1`, [userId])).rows[0] as { consumed_at: Date | null; attempts: number };
  const failure = async (p: Promise<unknown>): Promise<AuthError> => {
    try {
      await p;
    } catch (e) {
      assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
      return e;
    }
    throw new Error('expected a failure');
  };
  const signUp = async (extra = 0) => {
    const phone = newPhone();
    const first = await auth.register({ name: 'مستخدم التقوية', phone: local(phone), password: PW });
    const sessions: AuthResult[] = [first];
    for (let i = 0; i < extra; i++) sessions.push(await auth.login({ phone: local(phone), password: PW }));
    return { phone, userId: first.user.id, sessions };
  };
  const requestCode = async (phone: string): Promise<string> => {
    await otp.requestPasswordReset({ phone: local(phone) });
    return msg.lastCode(phone, 'password_reset')!;
  };
  const loginService = (s: ReturnType<typeof createPgAuthStore>): AuthApi => createAuthService({ store: s, hasher, accessTokenSecret: SECRET, logger: log.logger });

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    store = createPgAuthStore(app);
    auth = loginService(store);
    account = createAccountService({ store, hasher, logger: log.logger });
    otp = createOtpService({ store, hasher, provider: msg.provider, otpSecret: SECRET, logger: log.logger });
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  // ------------------------------------------------------------------ login vs change password
  it('A. LOGIN then CHANGE: a login that verified the OLD password and is frozen before its transaction cannot create a session after the change', async () => {
    const { phone, userId } = await signUp();
    const frozen = holdBeforeTransaction(store);
    const logging = Promise.allSettled([loginService(frozen.store).login({ phone: local(phone), password: PW })]);
    await frozen.reached; // the login has read the credentials and verified the old password
    await account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW }); // commits the new password, ends every session
    const rowsAfterChange = (await sessionRows(phone)).length;
    frozen.release();
    const [settled] = await logging;
    assert.equal(settled.status, 'rejected');
    assert.equal(((settled as PromiseRejectedResult).reason as AuthError).code, 'invalid_credentials');
    assert.equal((await sessionRows(phone)).length, rowsAfterChange, 'the stale login inserted no session row at all');
    assert.equal(await liveCount(phone), 0);
    assert.equal((await userRow(phone)).failed_logins, 0, 'it is not counted as a wrong password');
    assert.ok(await auth.login({ phone: local(phone), password: NEW_PW }), 'the new password works');
  });

  it('A2. the refusal is the same generic error as a wrong password: nothing reveals that the password changed', async () => {
    const { phone, userId } = await signUp();
    const wrong = await failure(auth.login({ phone: local(phone), password: 'not-the-password-1' }));
    const frozen = holdBeforeTransaction(store);
    const logging = Promise.allSettled([loginService(frozen.store).login({ phone: local(phone), password: PW })]);
    await frozen.reached;
    await account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW });
    frozen.release();
    const [settled] = await logging;
    const stale = (settled as PromiseRejectedResult).reason as AuthError;
    assert.equal(JSON.stringify({ c: stale.code, m: stale.message, f: stale.fields }), JSON.stringify({ c: wrong.code, m: wrong.message, f: wrong.fields }));
  });

  it('B. CHANGE then LOGIN: while a password change holds the user row (not yet committed), a login with the OLD password BLOCKS on that row and is refused once the change commits', async () => {
    const { phone, userId } = await signUp();
    const held = holdBeforeCommit(store);
    const changing = createAccountService({ store: held.store, hasher, logger: log.logger }).changePassword(userId, { currentPassword: PW, newPassword: NEW_PW });
    await held.reached; // the change ran every statement: sessions revoked, new hash written, audit inserted; NOT committed
    const logging = Promise.allSettled([auth.login({ phone: local(phone), password: PW })]); // reads the still-committed OLD hash, so it verifies
    await waitForLockWaiters(admin, 1); // the login is now blocked on the user's row lock, at its compare-and-swap
    held.release();
    await changing;
    const [settled] = await logging;
    assert.equal(settled.status, 'rejected');
    assert.equal(((settled as PromiseRejectedResult).reason as AuthError).code, 'invalid_credentials');
    assert.equal(await liveCount(phone), 0, 'no stale session survives');
    assert.ok(await auth.login({ phone: local(phone), password: NEW_PW }));
  });

  it('B2. a login that commits BEFORE the change\'s user update has its session swept by the change (the users_revoke_sessions trigger sees the committed row)', async () => {
    const { phone, userId } = await signUp();
    const held = holdBeforeCommit(store);
    const logging = loginService(held.store).login({ phone: local(phone), password: PW });
    await held.reached; // the login holds the user row lock and has inserted its session, uncommitted
    const changing = account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW });
    await waitForLockWaiters(admin, 1); // the change revoked what it could see, and is now blocked on the user row at its password update
    held.release();
    const early = await logging; // the login commits: the client holds a live session...
    await changing; // ...and the change, once it proceeds, ends it
    assert.equal(await liveCount(phone), 0);
    assert.equal(await auth.authenticate(early.session.accessToken), null, 'the session the login created is dead');
    assert.equal((await failure(auth.refresh({ refreshToken: early.session.refreshToken }))).code, 'unauthorized');
    assert.ok((await sessionRows(phone)).every((r) => r.revoked_reason === 'password_changed'));
  });

  it('C. SEVERAL logins that verified the old password while it is changed: every one is refused and no live session remains', async () => {
    const { phone, userId } = await signUp(1);
    const rowsBefore = (await sessionRows(phone)).length;
    const frozen = holdBeforeTransaction(store, 4);
    const frozenAuth = loginService(frozen.store);
    const logins = Promise.allSettled(Array.from({ length: 4 }, () => frozenAuth.login({ phone: local(phone), password: PW })));
    await frozen.reached;
    await account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW });
    frozen.release();
    const results = await logins;
    assert.ok(results.every((r) => r.status === 'rejected' && (r.reason as AuthError).code === 'invalid_credentials'));
    assert.equal((await sessionRows(phone)).length, rowsBefore, 'not one stale row');
    assert.equal(await liveCount(phone), 0);
  });

  it('C2. a storm of logins and one password change at the same instant always ends with no live session and only the generic error', async () => {
    const { phone, userId } = await signUp();
    const ops: Array<Promise<unknown>> = [...Array.from({ length: 6 }, () => auth.login({ phone: local(phone), password: PW })), account.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW })];
    const results = await Promise.allSettled(ops);
    for (const r of results.slice(0, 6)) {
      if (r.status === 'rejected') assert.equal((r.reason as AuthError).code, 'invalid_credentials', String(r.reason));
    }
    assert.equal(results[6]?.status, 'fulfilled', 'the change itself succeeded');
    const issued = results.slice(0, 6).flatMap((r) => (r.status === 'fulfilled' ? [(r.value as AuthResult).session] : []));
    for (const s of issued) {
      assert.equal(await auth.authenticate(s.accessToken), null, 'a session issued by a login that raced the change is dead');
      assert.equal((await failure(auth.refresh({ refreshToken: s.refreshToken }))).code, 'unauthorized');
    }
    assert.equal(await liveCount(phone), 0, 'whatever the interleaving');
  });

  it('D. a SUSPENSION that commits between the verification and the session creation also refuses the login', async () => {
    const { phone, userId } = await signUp();
    const frozen = holdBeforeTransaction(store);
    const logging = Promise.allSettled([loginService(frozen.store).login({ phone: local(phone), password: PW })]);
    await frozen.reached;
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [userId]);
    frozen.release();
    const [settled] = await logging;
    assert.equal(((settled as PromiseRejectedResult).reason as AuthError).code, 'invalid_credentials');
    assert.equal(await liveCount(phone), 0);
  });

  it('D2. with no competing change the login is unaffected (control): a live session, counters reset', async () => {
    const { phone } = await signUp();
    await failure(auth.login({ phone: local(phone), password: 'wrong-password-1' }));
    assert.equal((await userRow(phone)).failed_logins, 1);
    const r = await auth.login({ phone: local(phone), password: PW });
    assert.ok(await auth.authenticate(r.session.accessToken));
    assert.equal((await userRow(phone)).failed_logins, 0);
  });

  // ------------------------------------------------------------------ recovery: revocation
  it('E. RECOVERY vs an in-flight REFRESH: the recovery waits for it and then ends the session that refresh created', async () => {
    const { phone, userId, sessions } = await signUp();
    const code = await requestCode(phone);
    const lockedIn = makeGate();
    const held = makeGate();
    const newToken = generateSessionToken();
    const rotating = app.tx(async (t) => {
      const out = await createPgSessionsRepository(t).rotate({ presentedHash: hashSessionToken(sessions[0]!.session.refreshToken), newHash: hashSessionToken(newToken), userAgent: null });
      lockedIn.release();
      await held.open; // the refresh holds its row lock and has inserted the new row, uncommitted
      return out;
    });
    await lockedIn.open;
    const resetting = otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }, { requestId: 'recovery-race-0001' });
    await waitForLockWaiters(admin, 1); // the recovery reached revokeAllLive and is blocked on the refresh's row
    held.release();
    const [rotated] = await Promise.all([rotating, resetting]);
    assert.equal(rotated.kind, 'rotated');
    assert.equal(await liveCount(phone), 0, 'nothing is live: the recovery saw the row the refresh committed');
    assert.equal((await failure(auth.refresh({ refreshToken: newToken }))).code, 'unauthorized', 'the refreshed token is dead');
    assert.equal((await auditRows(userId)).find((a) => a.action === 'auth.password_reset')?.after_data['sessions_revoked'], 1);
  });

  it('E2. a LOGIN frozen after verifying the old password cannot create a session once a RECOVERY has committed', async () => {
    const { phone } = await signUp();
    const code = await requestCode(phone);
    const frozen = holdBeforeTransaction(store);
    const logging = Promise.allSettled([loginService(frozen.store).login({ phone: local(phone), password: PW })]);
    await frozen.reached;
    await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW });
    const rows = (await sessionRows(phone)).length;
    frozen.release();
    const [settled] = await logging;
    assert.equal(((settled as PromiseRejectedResult).reason as AuthError).code, 'invalid_credentials');
    assert.equal((await sessionRows(phone)).length, rows);
    assert.equal(await liveCount(phone), 0);
  });

  it('E3. recovery ends every session, and a revoked session can neither authenticate nor refresh', async () => {
    const { phone, sessions } = await signUp(2);
    const code = await requestCode(phone);
    await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW });
    assert.equal(await liveCount(phone), 0);
    assert.ok((await sessionRows(phone)).every((r) => r.revoked_reason === 'password_changed'));
    for (const s of sessions) {
      assert.equal(await auth.authenticate(s.session.accessToken), null);
      assert.equal((await failure(auth.refresh({ refreshToken: s.session.refreshToken }))).code, 'unauthorized');
    }
  });

  // ------------------------------------------------------------------ sign-out (ONE login session)
  it('K. SIGN-OUT vs an in-flight REFRESH of the same session: the sign-out waits for it and ends the session that refresh created; the user\'s other login is untouched', async () => {
    const { phone, sessions } = await signUp(1); // two independent logins = two session families
    const lockedIn = makeGate();
    const held = makeGate();
    const newToken = generateSessionToken();
    const rotating = app.tx(async (t) => {
      const out = await createPgSessionsRepository(t).rotate({ presentedHash: hashSessionToken(sessions[0]!.session.refreshToken), newHash: hashSessionToken(newToken), userAgent: null });
      lockedIn.release();
      await held.open; // the refresh holds its row lock and has inserted the new row, uncommitted
      return out;
    });
    await lockedIn.open;
    const signingOut = auth.logout({ refreshToken: sessions[0]!.session.refreshToken }); // must WAIT, not miss the new row
    await waitForLockWaiters(admin, 1); // the sign-out reached revokeFamilyLive and is blocked on the refresh's row
    held.release();
    const [rotated] = await Promise.all([rotating, signingOut]);
    assert.equal(rotated.kind, 'rotated', 'the refresh won the lock first');
    assert.equal((await failure(auth.refresh({ refreshToken: newToken }))).code, 'unauthorized', 'the token the in-flight refresh created is dead');
    assert.equal(await liveCount(phone), 1, 'only the OTHER login session is live');
    assert.ok(await auth.authenticate(sessions[1]!.session.accessToken), 'the other login keeps working');
    assert.deepEqual((await sessionRows(phone)).map((r) => r.revoked_reason ?? 'LIVE').sort(), ['LIVE', 'logout', 'rotated']);
  });

  it('K2. a SIGN-OUT in flight makes a refresh of that session that starts meanwhile fail, and issues no token', async () => {
    const { phone, sessions } = await signUp();
    const rowsBefore = (await sessionRows(phone)).length;
    const held = holdBeforeCommit(store);
    const signingOut = loginService(held.store).logout({ refreshToken: sessions[0]!.session.refreshToken });
    await held.reached; // it has locked and revoked its rows; NOT committed
    const refreshing = Promise.allSettled([auth.refresh({ refreshToken: sessions[0]!.session.refreshToken })]);
    await waitForLockWaiters(admin, 1); // the refresh is blocked on the row the sign-out holds
    held.release();
    await signingOut;
    const [settled] = await refreshing;
    assert.equal(settled.status, 'rejected');
    assert.equal(((settled as PromiseRejectedResult).reason as AuthError).code, 'unauthorized');
    assert.equal((await sessionRows(phone)).length, rowsBefore, 'the refused refresh created no row');
    assert.equal(await liveCount(phone), 0);
    assert.ok(!(await sessionRows(phone)).some((r) => r.revoked_reason === 'reuse_detected'), 'refused, not flagged as a reuse');
  });

  // ------------------------------------------------------------------ recovery: audit
  it('F. a successful recovery writes ONE auth.password_reset event with the actor, the entity, the request id and only a count', async () => {
    const { phone, userId } = await signUp(2);
    const code = await requestCode(phone);
    await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }, { requestId: 'recovery-audit-0001' });
    const events = (await auditRows(userId)).filter((a) => a.action === 'auth.password_reset');
    assert.equal(events.length, 1);
    const e = events[0]!;
    assert.deepEqual({ actor: e.actor_id, role: e.actor_role, type: e.entity_type, id: e.entity_id, data: e.after_data, req: e.request_id }, { actor: userId, role: 'user', type: 'user', id: userId, data: { sessions_revoked: 3 }, req: 'recovery-audit-0001' });
  });

  it('F2. the audit trail contains no secret: no code, password, hash, token, phone number or name', async () => {
    const { phone, userId, sessions } = await signUp(1);
    const code = await requestCode(phone);
    await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }, { requestId: 'recovery-audit-0002' });
    const everything = JSON.stringify((await admin.query(`SELECT a.* FROM audit_logs a WHERE a.entity_id = $1`, [userId])).rows);
    assert.ok(everything.includes('auth.password_reset'));
    // a 6-digit code is only searched as a whole digit run: it must not "match" part of an id or a timestamp in the JSON
    assert.ok(!new RegExp(`(^|[^0-9])${code}([^0-9]|$)`).test(everything), 'the one-time code must not appear');
    for (const secret of [PW, NEW_PW, '$argon2', 'nsj_', 'eyJ', SECRET, phone, local(phone), 'مستخدم التقوية', sessions[0]!.session.refreshToken, sessions[0]!.session.accessToken, (await userRow(phone)).password_hash]) {
      assert.ok(!everything.includes(secret), `the audit trail must not contain ${secret.slice(0, 12)}`);
    }
  });

  it('F3. refusals and the other recovery steps write NO event (wrong code, replay, weak password, asking for a code)', async () => {
    const { phone, userId } = await signUp();
    const code = await requestCode(phone);
    await failure(otp.resetPassword({ phone: local(phone), code: code === '000000' ? '000001' : '000000', newPassword: NEW_PW }));
    await failure(otp.resetPassword({ phone: local(phone), code, newPassword: '1' }));
    assert.equal((await auditRows(userId)).length, 0);
    await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW });
    await failure(otp.resetPassword({ phone: local(phone), code, newPassword: 'Another-Passw0rd-9!' }));
    assert.equal((await auditRows(userId)).length, 1, 'the replay added nothing');
  });

  it('G. ATOMICITY: if anything fails after the reset ran, PostgreSQL rolls back the password, the spent code, the revocation AND the audit row together; a retry then works', async () => {
    const { phone, userId } = await signUp(1);
    const code = await requestCode(phone);
    const hash = (await userRow(phone)).password_hash;
    const failing = createOtpService({ store: failAfterBody(store, 'forced failure after the reset ran'), hasher, provider: msg.provider, otpSecret: SECRET, logger: log.logger });
    await assert.rejects(failing.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }, { requestId: 'rollback-0001' }), /forced failure/);
    assert.equal((await userRow(phone)).password_hash, hash, 'password unchanged');
    assert.equal((await codeRow(userId)).consumed_at, null, 'the code was not spent');
    assert.equal(await liveCount(phone), 2, 'no session was revoked');
    assert.equal((await auditRows(userId)).length, 0, 'and no audit row remains');
    assert.deepEqual(await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }, { requestId: 'rollback-0002' }), { status: 'password_reset' });
    assert.equal((await auditRows(userId)).length, 1);
  });

  it('G2. ATOMICITY: if the audit insert itself fails, the reset does not happen', async () => {
    const { phone, userId } = await signUp(1);
    const code = await requestCode(phone);
    const hash = (await userRow(phone)).password_hash;
    const failing = createOtpService({ store: failAudit(store, 'audit insert failed'), hasher, provider: msg.provider, otpSecret: SECRET, logger: log.logger });
    await assert.rejects(failing.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }), /audit insert failed/);
    assert.equal((await userRow(phone)).password_hash, hash);
    assert.equal((await codeRow(userId)).consumed_at, null);
    assert.equal(await liveCount(phone), 2);
    assert.equal((await auditRows(userId)).length, 0);
  });

  it('G3. ATOMICITY of change password too: with the audit insert failing, nothing changes and the sessions stay', async () => {
    const { phone, userId, sessions } = await signUp(1);
    const hash = (await userRow(phone)).password_hash;
    const failing = createAccountService({ store: failAudit(store, 'audit insert failed'), hasher, logger: log.logger });
    await assert.rejects(failing.changePassword(userId, { currentPassword: PW, newPassword: NEW_PW }), /audit insert failed/);
    assert.equal((await userRow(phone)).password_hash, hash);
    assert.equal(await liveCount(phone), 2);
    assert.ok(await auth.authenticate(sessions[0]!.session.accessToken));
    assert.equal((await auditRows(userId)).length, 0);
  });

  it('H. two simultaneous recoveries with the same code: exactly ONE succeeds and exactly one audit event exists', async () => {
    const { phone, userId } = await signUp();
    const code = await requestCode(phone);
    const results = await Promise.allSettled([
      otp.resetPassword({ phone: local(phone), code, newPassword: 'First-Candidate-Pass1!' }),
      otp.resetPassword({ phone: local(phone), code, newPassword: 'Second-Candidate-Pass2!' }),
    ]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.ok(results.filter((r) => r.status === 'rejected').every((r) => ((r as PromiseRejectedResult).reason as AuthError).code === 'invalid_code'));
    assert.equal((await auditRows(userId)).filter((a) => a.action === 'auth.password_reset').length, 1);
    assert.equal(await liveCount(phone), 0);
  });

  it('I. simultaneous change password and recovery: both orders end with no live session and a consistent password', async () => {
    const { phone, userId } = await signUp(1);
    const code = await requestCode(phone);
    const results = await Promise.allSettled([
      account.changePassword(userId, { currentPassword: PW, newPassword: 'Changed-By-Change-1!' }),
      otp.resetPassword({ phone: local(phone), code, newPassword: 'Changed-By-Reset-2!' }),
    ]);
    for (const r of results) if (r.status === 'rejected') assert.ok((r.reason as AuthError).code === 'invalid_current_password', String(r.reason));
    assert.equal(await liveCount(phone), 0);
    const ok = await Promise.allSettled([auth.login({ phone: local(phone), password: 'Changed-By-Change-1!' }), auth.login({ phone: local(phone), password: 'Changed-By-Reset-2!' })]);
    assert.equal(ok.filter((r) => r.status === 'fulfilled').length, 1, 'exactly one of the two passwords is the current one');
  });

  it('J. logs hold event names and ids only: no password, hash, token, code or phone', async () => {
    const text = log.text();
    assert.ok(text.includes('stale_credentials'));
    const secrets = [PW, NEW_PW, '$argon2', 'nsj_', 'eyJ', SECRET, ...created, ...created.map(local)];
    for (const secret of secrets) assert.ok(!text.includes(secret), `the log must not contain ${secret.slice(0, 12)}`);
  });
});

describe('hardening over HTTP on PostgreSQL 16', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });
  const json = { 'content-type': 'application/json' };
  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  it('the recovery route passes its request id to the audit event, and the answers carry no secret', async () => {
    const msg = makeFakeProvider();
    const store = createPgAuthStore(app);
    const server = await buildServer!({
      config: config(),
      db: app,
      auth: createAuthService({ store, hasher, accessTokenSecret: SECRET }),
      otp: createOtpService({ store, hasher, provider: msg.provider, otpSecret: SECRET }),
    });
    const phone = newPhone();
    const reg = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'تعافي HTTP', phone: local(phone), password: PW }) })).json() as { user: { id: string }; session: { accessToken: string } };
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/password/forgot', headers: json, payload: JSON.stringify({ phone: local(phone) }) })).statusCode, 202);
    const code = msg.lastCode(phone, 'password_reset')!;
    const reset = await server.inject({ method: 'POST', url: '/v1/auth/password/reset', headers: { ...json, 'x-request-id': 'http-recovery-0001' }, payload: JSON.stringify({ phone: local(phone), code, newPassword: NEW_PW }) });
    assert.equal(reset.statusCode, 200);
    assert.deepEqual(reset.json(), { status: 'password_reset' });
    for (const secret of [code, PW, NEW_PW, '$argon2']) assert.ok(!reset.body.includes(secret));
    assert.equal((await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${reg.session.accessToken}` } })).statusCode, 401, 'the old session is dead');
    const audit = (await admin.query(`SELECT a.request_id, a.after_data FROM audit_logs a WHERE a.entity_id = $1 AND a.action = 'auth.password_reset'`, [reg.user.id])).rows;
    assert.deepEqual(audit, [{ request_id: 'http-recovery-0001', after_data: { sessions_revoked: 1 } }]);
    await server.close();
  });
});

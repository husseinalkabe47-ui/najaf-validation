// A member's own car ads (Phase 11.5, Step 5.4) against a real PostgreSQL 16 (migrations 0001-0013 applied), through the
// least-privilege application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: fixtures and cleanup
// ONLY). Skipped visibly when they are missing. Proves what the in-memory unit tests cannot: the column privileges of 0013 allow
// exactly these statements, the CHECKs accept what validation lets through, the triggers (version, soft-delete favorites) run,
// the public_cars view hides a pending ad, and two concurrent writers on the SAME version cannot both win.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgMemberCarStore } from '../../src/member-cars/repository.ts';
import { MemberCarError, createMemberCarService } from '../../src/member-cars/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const VALID = { brand: 'Toyota', model: 'Corolla', year: 2016, price: 14500, currency: 'USD', phone: '07701234567', location: 'النجف', latitude: 32.0, longitude: 44.33 };

describe('member cars on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  let A: Actor;
  let B: Actor;
  let svc: ReturnType<typeof createMemberCarService>;
  let svc2: ReturnType<typeof createMemberCarService>;

  const newUser = async (status = 'active'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('عضو اختبار', $1, 'user', $2, '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone, status],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const row = async (id: string) => (await admin.query<Record<string, unknown>>('SELECT owner_id, source_type, status, version, deleted_at, search_text, price FROM cars WHERE id = $1', [id])).rows[0]!;

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    A = { id: await newUser(), role: 'member' };
    B = { id: await newUser(), role: 'member' };
    svc = createMemberCarService({ store: createPgMemberCarStore(app) });
    svc2 = createMemberCarService({ store: createPgMemberCarStore(app2) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('creates a pending member ad owned by the actor, invisible in public_cars, with an audit row', async () => {
    const car = await svc.create(A, VALID, { requestId: 'it-create-1' });
    assert.equal(car.status, 'pending');
    assert.equal(car.version, 1);
    assert.equal(car.latitude, 32);
    const r = await row(car.id);
    assert.equal(String(r['owner_id']), A.id);
    assert.equal(r['source_type'], 'member');
    assert.match(String(r['search_text']), /toyota corolla 2016/);
    const pub = await app.query('SELECT 1 FROM public_cars WHERE id = $1', [car.id]);
    assert.equal(pub.rows.length, 0, 'D1: a new ad is not public');
    const audit = await admin.query<{ action: string; entity_type: string; actor_role: string }>(`SELECT action, entity_type, actor_role FROM audit_logs WHERE request_id = 'it-create-1'`);
    assert.deepEqual(audit.rows.map((a) => ({ ...a })), [{ action: 'member_car.create', entity_type: 'car', actor_role: 'user' }]);
  });

  it('another member cannot read, update or delete it (404); the row is unchanged', async () => {
    const car = await svc.create(A, VALID);
    await assert.rejects(svc.getOwn(B, car.id), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    await assert.rejects(svc.update(B, car.id, { version: 1, price: 1 }), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    await assert.rejects(svc.remove(B, car.id, { version: '1' }), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    const r = await row(car.id);
    assert.equal(Number(r['version']), 1);
    assert.equal(r['deleted_at'], null);
  });

  it('updates through the column privileges of 0013: the trigger bumps the version; a stale version is 409', async () => {
    const car = await svc.create(A, VALID);
    const updated = await svc.update(A, car.id, { version: 1, price: 13900, mileage: 120000, whatsapp: null });
    assert.equal(updated.version, 2);
    assert.equal(updated.price, 13900);
    await assert.rejects(svc.update(A, car.id, { version: 1, price: 1 }), (e: unknown) => e instanceof MemberCarError && e.code === 'version_conflict');
    assert.equal(String((await row(car.id))['price']), '13900');
  });

  it('two connections updating from the same version at once: exactly one wins, the other is 409', async () => {
    const car = await svc.create(A, VALID);
    const results = await Promise.allSettled([svc.update(A, car.id, { version: 1, price: 100 }), svc2.update(A, car.id, { version: 1, price: 200 })]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    const lost = results.find((r) => r.status === 'rejected') as PromiseRejectedResult;
    assert.ok(lost.reason instanceof MemberCarError && lost.reason.code === 'version_conflict');
    assert.equal(Number((await row(car.id))['version']), 2);
  });

  it('marks an active ad sold; the owner cannot publish', async () => {
    const car = await svc.create(A, VALID);
    await admin.query(`UPDATE cars SET status = 'active' WHERE id = $1`, [car.id]); // fixture: the publishing step (D1) does not exist yet
    const sold = await svc.update(A, car.id, { version: 2, status: 'sold' });
    assert.equal(sold.status, 'sold');
    await assert.rejects(svc.update(A, car.id, { version: 3, status: 'active' }), (e: unknown) => e instanceof MemberCarError && e.code === 'validation_failed');
  });

  it('soft-deletes: deleted_at is set, favorites are removed by the trigger, and the ad is 404 and out of the list', async () => {
    const car = await svc.create(A, VALID);
    await admin.query('INSERT INTO favorites (user_id, car_id) VALUES ($1, $2)', [B.id, car.id]);
    await svc.remove(A, car.id, { version: '1' });
    const r = await row(car.id);
    assert.ok(r['deleted_at'] instanceof Date);
    assert.equal((await admin.query('SELECT 1 FROM favorites WHERE car_id = $1', [car.id])).rows.length, 0);
    await assert.rejects(svc.getOwn(A, car.id), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    assert.ok(!(await svc.listOwn(A, {})).items.some((c) => c.id === car.id));
  });

  it('an owner suspended after authentication cannot change the ad', async () => {
    const owner: Actor = { id: await newUser(), role: 'member' };
    const car = await svc.create(owner, VALID);
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [owner.id]);
    await assert.rejects(svc.update(owner, car.id, { version: 1, price: 1 }), (e: unknown) => e instanceof AuthzError && e.code === 'not_found');
    assert.equal(Number((await row(car.id))['version']), 1);
  });
});

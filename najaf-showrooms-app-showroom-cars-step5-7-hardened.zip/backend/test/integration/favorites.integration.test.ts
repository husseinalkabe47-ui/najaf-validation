// A member's own favorites (Phase 11.5, Step 5.6) against a real PostgreSQL 16 (migrations 0001-0013 applied), through the
// least-privilege application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: fixtures and cleanup
// ONLY). Skipped visibly when they are missing. Proves what the in-memory unit tests cannot: the privileges of 0012/0013 allow
// exactly these statements, public_cars decides visibility, UNIQUE (user_id, car_id) absorbs duplicates under concurrency, and the
// soft-delete trigger and the FOR SHARE lock leave no favorite behind a car that is deleted while it is being favorited.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgFavoriteStore } from '../../src/favorites/repository.ts';
import { createFavoriteService } from '../../src/favorites/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

describe('favorites on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  const carIds: string[] = [];
  let A: Actor;
  let B: Actor;
  let owner: string;
  let svc: ReturnType<typeof createFavoriteService>;
  let svc2: ReturnType<typeof createFavoriteService>;

  const newUser = async (): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('عضو اختبار', $1, 'user', 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const newCar = async (status = 'active'): Promise<string> => {
    const r = await admin.query<{ id: string }>(
      `INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status, search_text)
       VALUES ('member', $1::bigint, 'Toyota', 'Corolla', 2016, 14500, 'USD', '+9647701234567', 'النجف', $2, 'toyota corolla 2016') RETURNING id`,
      [owner, status],
    );
    const id = String(r.rows[0]!.id);
    carIds.push(id);
    return id;
  };
  const rows = async (userId: string) => (await admin.query<{ car_id: string }>('SELECT car_id FROM favorites WHERE user_id = $1::bigint ORDER BY id', [userId])).rows.map((r) => String(r.car_id));
  const notFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    owner = await newUser();
    A = { id: await newUser(), role: 'member' };
    B = { id: await newUser(), role: 'member' };
    svc = createFavoriteService({ store: createPgFavoriteStore(app) });
    svc2 = createFavoriteService({ store: createPgFavoriteStore(app2) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM favorites WHERE user_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM cars WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('favorites a public car for the actor only, audits it, and a duplicate is absorbed (one row, one audit row)', async () => {
    const car = await newCar();
    const first = await svc.add(A, { carId: car }, { requestId: 'it-fav-1' });
    assert.equal(first.created, true);
    const second = await svc.add(A, { carId: car }, { requestId: 'it-fav-1b' });
    assert.equal(second.created, false);
    assert.deepEqual(second.favorite, first.favorite);
    assert.deepEqual(await rows(A.id), [car]);
    assert.deepEqual(await rows(B.id), []);
    const audit = await admin.query<{ action: string; actor_role: string; entity_type: string }>(`SELECT action, actor_role, entity_type FROM audit_logs WHERE request_id IN ('it-fav-1', 'it-fav-1b')`);
    assert.deepEqual(audit.rows.map((r) => ({ ...r })), [{ action: 'favorite.add', actor_role: 'user', entity_type: 'car' }]);
  });

  it('a pending, deleted or unknown car cannot be favorited (the same 404) and nothing is stored', async () => {
    const pending = await newCar('pending');
    const deleted = await newCar();
    await admin.query('UPDATE cars SET deleted_at = now() WHERE id = $1::bigint', [deleted]);
    for (const carId of [pending, deleted, '999999999999']) await assert.rejects(svc.add(B, { carId }), notFound, carId);
    assert.deepEqual(await rows(B.id), []);
  });

  it('lists only the actor\'s public favorites, newest first, with a stable keyset cursor; hidden cars disappear and come back', async () => {
    const cars = [await newCar(), await newCar(), await newCar(), await newCar(), await newCar()];
    for (const c of cars) await svc.add(B, { carId: c });
    await svc.add(A, { carId: cars[0]! });
    const seen: string[] = [];
    let before: string | undefined;
    for (let guard = 0; guard < 10; guard++) {
      const page = await svc.list(B, before === undefined ? { limit: '2' } : { limit: '2', before });
      seen.push(...page.items.map((i) => i.car.id));
      if (page.nextBefore === null) break;
      before = page.nextBefore;
    }
    assert.deepEqual(seen.filter((id) => cars.includes(id)), [...cars].reverse());
    await admin.query(`UPDATE cars SET status = 'suspended' WHERE id = $1::bigint`, [cars[2]]);
    assert.ok(!(await svc.list(B, {})).items.some((i) => i.car.id === cars[2]), 'a suspended car is not exposed');
    assert.deepEqual(await rows(B.id), cars, 'the row itself is kept');
    await admin.query(`UPDATE cars SET status = 'active' WHERE id = $1::bigint`, [cars[2]]);
    assert.ok((await svc.list(B, {})).items.some((i) => i.car.id === cars[2]));
    const item = (await svc.list(B, {})).items[0]! as unknown as { car: Record<string, unknown> };
    for (const k of ['owner_id', 'ownerId', 'search_text', 'reviewed_by']) assert.ok(!(k in item.car), k);
  });

  it('remove is idempotent, only touches the actor\'s row, and works for a car that is no longer public', async () => {
    const car = await newCar();
    await svc.add(A, { carId: car });
    await svc.add(B, { carId: car });
    await svc.remove(A, car, { requestId: 'it-fav-del' });
    await svc.remove(A, car, { requestId: 'it-fav-del2' });
    await svc.remove(A, '999999999999');
    assert.ok(!(await rows(A.id)).includes(car));
    assert.ok((await rows(B.id)).includes(car));
    await admin.query(`UPDATE cars SET status = 'suspended' WHERE id = $1::bigint`, [car]);
    await svc.remove(B, car);
    assert.ok(!(await rows(B.id)).includes(car));
    const audit = await admin.query<{ request_id: string }>(`SELECT request_id FROM audit_logs WHERE action = 'favorite.remove' AND request_id IN ('it-fav-del', 'it-fav-del2')`);
    assert.deepEqual(audit.rows.map((r) => r.request_id), ['it-fav-del']);
  });

  it('twelve concurrent adds of one car over two connections create exactly one favorite', async () => {
    const car = await newCar();
    const results = await Promise.all(Array.from({ length: 12 }, (_, i) => (i % 2 ? svc : svc2).add(A, { carId: car })));
    assert.equal(results.filter((r) => r.created).length, 1);
    assert.equal((await rows(A.id)).filter((c) => c === car).length, 1);
  });

  it('a car soft-deleted while it is being favorited never keeps a favorite (FOR SHARE lock + trigger), over repeated races', async () => {
    for (let i = 0; i < 8; i++) {
      const car = await newCar();
      const [add] = await Promise.allSettled([svc.add(A, { carId: car }), admin.query('UPDATE cars SET deleted_at = now() WHERE id = $1::bigint', [car])]);
      assert.ok(add.status === 'fulfilled' || notFound(add.reason));
      const left = await admin.query('SELECT 1 FROM favorites WHERE car_id = $1::bigint', [car]);
      assert.equal(left.rows.length, 0, `race ${i}`);
    }
  });

  it('the application role has no UPDATE on favorites', async () => {
    const car = await newCar();
    await svc.add(A, { carId: car });
    await assert.rejects(app.query('UPDATE favorites SET user_id = $1::bigint WHERE car_id = $2::bigint', [B.id, car]), /permission denied/);
    assert.ok((await rows(A.id)).includes(car));
  });
});

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../../src/config.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { APP_URL, appConfig, skip } from '../helpers/integration.ts';

// fastify is a dependency installed by "npm install" (CI); without it this suite is skipped visibly, never crashes.
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let missing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  missing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'}); run "npm install" in backend/`;
}

const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });

describe('HTTP health endpoints against a real database', { skip: skip || missing }, () => {
  let db: Db;
  before(async () => {
    db = await createDb(appConfig());
  });
  after(async () => {
    await db.close();
  });

  it('/healthz is 200', async () => {
    const app = await buildServer!({ config: config(), db });
    const r = await app.inject({ method: 'GET', url: '/healthz' });
    assert.equal(r.statusCode, 200);
    await app.close();
  });

  it('/readyz is 200 with the validated schema in place', async () => {
    const app = await buildServer!({ config: config(), db });
    const r = await app.inject({ method: 'GET', url: '/readyz' });
    assert.equal(r.statusCode, 200);
    assert.deepEqual(r.json(), { status: 'ready', checks: { database: 'ok', schema: 'ok' } });
    await app.close();
  });

  it('/readyz is 503 once the database handle is closed, with no error details', async () => {
    const closed = await createDb(appConfig());
    await closed.close();
    const app = await buildServer!({ config: config(), db: closed });
    const r = await app.inject({ method: 'GET', url: '/readyz' });
    assert.equal(r.statusCode, 503);
    assert.deepEqual(r.json(), { status: 'not_ready', checks: { database: 'fail', schema: 'skipped' } });
    await app.close();
  });
});

// One-time codes (phone verification, password recovery) against a REAL PostgreSQL 16 (migrations 0001-0013 applied) with REAL
// argon2id, through the application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: inspection,
// time travel and cleanup ONLY). Skipped visibly when they are missing, or when `argon2` / `fastify` are not installed.
// Time travel: verification_codes rows are shifted back in the database instead of waiting (created_at and expires_at move
// together, so the table's own CHECK expires_at > created_at keeps holding).
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import { loadConfig } from '../../src/config.ts';
import { OTP, RATE_LIMITS } from '../../src/auth/policy.ts';
import { createOtpService } from '../../src/auth/otp-service.ts';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createMemoryRateLimiter } from '../../src/auth/rate-limit.ts';
import { createPgAuthStore } from '../../src/auth/repository.ts';
import { createAuthService } from '../../src/auth/service.ts';
import { AuthError } from '../../src/auth/types.ts';
import type { AuthApi, OtpApi } from '../../src/auth/types.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { recordingLogger } from '../helpers/fake-auth.ts';
import { makeFakeProvider } from '../helpers/fake-messaging.ts';
import { APP_URL, adminConfig, appConfig, skip } from '../helpers/integration.ts';

const hasher = createArgon2idHasher();
let argon2Missing: string | false = false;
try {
  await hasher.ready();
} catch (e) {
  argon2Missing = `argon2 is not usable (${String((e as Error).message).slice(0, 80)}); run "npm install" in backend/`;
}
type BuildServer = typeof import('../../src/server.ts').buildServer;
let buildServer: BuildServer | undefined;
let fastifyMissing: string | false = false;
try {
  ({ buildServer } = await import('../../src/server.ts'));
} catch (e) {
  fastifyMissing = `fastify is not installed (${(e as { code?: string }).code ?? 'import failed'})`;
}

const PW = 'Otp-Suite-Passw0rd!';
const NEW_PW = 'Recovered-Passw0rd!';
const SECRET = 'integration-otp-access-secret-0123456789-ZXCVBN';
const created: string[] = [];
const newPhone = (): string => {
  const p = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
  created.push(p);
  return p;
};
const local = (e164: string): string => '0' + e164.slice(4);
const other = (code: string) => (code === '000000' ? '000001' : '000000');

describe('one-time codes on PostgreSQL 16 with real argon2id', { skip: skip || argon2Missing }, () => {
  let app: Db;
  let admin: Db;
  const log = recordingLogger();
  const msg = makeFakeProvider();
  let auth: AuthApi;
  let otp: OtpApi;

  type CodeRow = { id: string; purpose: string; target_phone: string; hash: string; len: number; attempts: number; max_attempts: number; ttl_secs: string; consumed_at: Date | null; invalidated_at: Date | null };
  const codes = async (phone: string): Promise<CodeRow[]> =>
    (await admin.query(`SELECT c.id, c.purpose, c.target_phone::text AS target_phone, encode(c.code_hash, 'hex') AS hash, octet_length(c.code_hash) AS len,
                               c.attempts, c.max_attempts, extract(epoch FROM (c.expires_at - c.created_at)) AS ttl_secs, c.consumed_at, c.invalidated_at
                          FROM verification_codes c JOIN users u ON u.id = c.user_id
                         WHERE u.phone_e164 = $1 ORDER BY c.created_at, c.id`, [phone])).rows as CodeRow[];
  const userRow = async (phone: string) =>
    (await admin.query('SELECT id, phone_verified_at, password_hash, password_changed_at, failed_logins, locked_until FROM users WHERE phone_e164 = $1', [phone])).rows[0] as {
      id: string; phone_verified_at: Date | null; password_hash: string; password_changed_at: Date | null; failed_logins: number; locked_until: Date | null;
    };
  const shiftCodes = (phone: string, interval: string) =>
    admin.query(`UPDATE verification_codes SET created_at = created_at - $2::interval, expires_at = expires_at - $2::interval WHERE user_id = (SELECT id FROM users WHERE phone_e164 = $1)`, [phone, interval]);
  const failure = async (p: Promise<unknown>): Promise<AuthError> => {
    try {
      await p;
    } catch (e) {
      assert.ok(e instanceof AuthError, `expected AuthError, got ${String(e)}`);
      return e;
    }
    throw new Error('expected a failure');
  };
  const signUp = async () => {
    const phone = newPhone();
    const r = await auth.register({ name: 'مستخدم الرموز', phone: local(phone), password: PW });
    return { phone, r };
  };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    const store = createPgAuthStore(app);
    auth = createAuthService({ store, hasher, accessTokenSecret: SECRET, logger: log.logger });
    otp = createOtpService({ store, hasher, provider: msg.provider, otpSecret: SECRET, logger: log.logger });
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });

  // ---------------------------------------------------------------- phone verification
  it('registering a phone number does not verify it, and creates no code', async () => {
    const { phone, r } = await signUp();
    assert.equal(r.user.phoneVerified, false);
    assert.equal((await userRow(phone)).phone_verified_at, null);
    assert.equal((await codes(phone)).length, 0);
  });

  it('a code is stored ONLY as a 32-byte hash, bound to purpose and phone, with a 10-minute life and 5 attempts; the plain code exists nowhere in the table', async () => {
    const { phone, r } = await signUp();
    assert.deepEqual(await otp.requestPhoneVerification(r.user.id), { status: 'sent' });
    const code = msg.lastCode(phone, 'phone_verify')!;
    assert.match(code, /^[0-9]{6}$/);
    const [row, ...rest] = await codes(phone);
    assert.equal(rest.length, 0);
    assert.equal(row?.purpose, 'phone_verify');
    assert.equal(row?.target_phone, phone);
    assert.equal(row?.len, 32);
    assert.equal(row?.attempts, 0);
    assert.equal(row?.max_attempts, OTP.maxAttempts);
    assert.equal(Number(row?.ttl_secs), OTP.ttlSeconds);
    assert.equal(row?.consumed_at, null);
    assert.equal(row?.invalidated_at, null);
    const everything = JSON.stringify((await admin.query('SELECT c::text AS t FROM verification_codes c JOIN users u ON u.id = c.user_id WHERE u.phone_e164 = $1', [phone])).rows);
    assert.ok(!everything.includes(code), 'the plain code must not be stored');
  });

  it('a valid code verifies the phone and consumes the code: both changes, together', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const user = await otp.confirmPhoneVerification(r.user.id, { code: msg.lastCode(phone, 'phone_verify')! });
    assert.equal(user.phoneVerified, true);
    assert.notEqual((await userRow(phone)).phone_verified_at, null);
    assert.notEqual((await codes(phone))[0]?.consumed_at, null);
    assert.equal((await auth.authenticate(r.session.accessToken))?.user.phoneVerified, true);
  });

  it('a wrong code is invalid_code, counts one attempt (committed), and the right code still works', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const code = msg.lastCode(phone, 'phone_verify')!;
    assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code: other(code) }))).code, 'invalid_code');
    assert.equal((await codes(phone))[0]?.attempts, 1);
    assert.equal((await userRow(phone)).phone_verified_at, null);
    assert.equal((await otp.confirmPhoneVerification(r.user.id, { code })).phoneVerified, true);
  });

  it('an expired code is refused', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const code = msg.lastCode(phone, 'phone_verify')!;
    await shiftCodes(phone, `${OTP.ttlSeconds + 1} seconds`);
    assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
    assert.equal((await userRow(phone)).phone_verified_at, null);
  });

  it('a used code cannot be used again', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const code = msg.lastCode(phone, 'phone_verify')!;
    await otp.confirmPhoneVerification(r.user.id, { code });
    await admin.query('UPDATE users SET phone_verified_at = NULL WHERE phone_e164 = $1', [phone]);
    assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
    assert.equal((await userRow(phone)).phone_verified_at, null);
  });

  it('a code for another purpose is never accepted, in either direction', async () => {
    const { phone, r } = await signUp();
    await otp.requestPasswordReset({ phone: local(phone) });
    const resetCode = msg.lastCode(phone, 'password_reset')!;
    assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code: resetCode }))).code, 'invalid_code');
    await otp.requestPhoneVerification(r.user.id);
    const verifyCode = msg.lastCode(phone, 'phone_verify')!;
    const before = (await userRow(phone)).password_hash;
    assert.equal((await failure(otp.resetPassword({ phone: local(phone), code: verifyCode, newPassword: NEW_PW }))).code, 'invalid_code');
    assert.equal((await userRow(phone)).password_hash, before, 'the password did not change');
    assert.equal((await userRow(phone)).phone_verified_at, null, 'the phone was not verified either');
  });

  it('a code belongs to its user: another user cannot use it', async () => {
    const a = await signUp();
    const b = await signUp();
    await otp.requestPhoneVerification(a.r.user.id);
    await otp.requestPhoneVerification(b.r.user.id);
    const codeA = msg.lastCode(a.phone, 'phone_verify')!;
    const codeB = msg.lastCode(b.phone, 'phone_verify')!;
    if (codeA !== codeB) assert.equal((await failure(otp.confirmPhoneVerification(b.r.user.id, { code: codeA }))).code, 'invalid_code');
    assert.equal((await userRow(a.phone)).phone_verified_at, null);
  });

  it('five wrong attempts exhaust a code: the correct one is then refused, attempts never exceed the maximum, and a new code recovers', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const code = msg.lastCode(phone, 'phone_verify')!;
    for (let i = 0; i < OTP.maxAttempts; i++) assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code: other(code) }))).code, 'invalid_code');
    assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
    assert.equal((await codes(phone))[0]?.attempts, OTP.maxAttempts);
    assert.equal((await userRow(phone)).phone_verified_at, null);
    await shiftCodes(phone, `${OTP.cooldownSeconds + 1} seconds`);
    await otp.requestPhoneVerification(r.user.id);
    assert.equal((await otp.confirmPhoneVerification(r.user.id, { code: msg.lastCode(phone, 'phone_verify')! })).phoneVerified, true);
  });

  it('sequential wrong guesses and parallel wrong guesses are both capped at 5 (the row lock serializes them)', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const code = msg.lastCode(phone, 'phone_verify')!;
    await Promise.allSettled(Array.from({ length: 12 }, () => otp.confirmPhoneVerification(r.user.id, { code: other(code) })));
    assert.equal((await codes(phone))[0]?.attempts, OTP.maxAttempts, 'twelve parallel guesses, five counted, none lost, none beyond the cap');
    assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code }))).code, 'invalid_code');
  });

  it('a new request supersedes the old code; the database keeps exactly one active code', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const first = msg.lastCode(phone, 'phone_verify')!;
    await shiftCodes(phone, `${OTP.cooldownSeconds + 1} seconds`);
    await otp.requestPhoneVerification(r.user.id);
    const second = msg.lastCode(phone, 'phone_verify')!;
    const rows = await codes(phone);
    assert.equal(rows.length, 2);
    assert.equal(rows.filter((x) => x.consumed_at === null && x.invalidated_at === null).length, 1);
    assert.notEqual(rows[0]?.invalidated_at, null);
    if (first !== second) assert.equal((await failure(otp.confirmPhoneVerification(r.user.id, { code: first }))).code, 'invalid_code');
    assert.equal((await otp.confirmPhoneVerification(r.user.id, { code: second })).phoneVerified, true);
  });

  it('requesting is throttled: 60 seconds between codes, 3 per hour, 10 per day, with a Retry-After hint and no extra row or message', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const sentAfterFirst = msg.sent.length;
    const cooldown = await failure(otp.requestPhoneVerification(r.user.id));
    assert.equal(cooldown.code, 'rate_limited');
    assert.ok((cooldown.retryAfterSeconds ?? 0) > 0 && (cooldown.retryAfterSeconds ?? 0) <= OTP.cooldownSeconds);
    assert.equal((await codes(phone)).length, 1);
    assert.equal(msg.sent.length, sentAfterFirst);

    for (let i = 1; i < OTP.perHour; i++) {
      await shiftCodes(phone, `${OTP.cooldownSeconds + 1} seconds`);
      await otp.requestPhoneVerification(r.user.id);
    }
    await shiftCodes(phone, `${OTP.cooldownSeconds + 1} seconds`);
    const hourly = await failure(otp.requestPhoneVerification(r.user.id));
    assert.equal(hourly.retryAfterSeconds, 3600);
    assert.equal((await codes(phone)).length, OTP.perHour);
    await shiftCodes(phone, '3601 seconds');
    assert.deepEqual(await otp.requestPhoneVerification(r.user.id), { status: 'sent' });
  });

  it('the daily limit: ten codes within 24 hours (spread over several hours) throttle the eleventh', async () => {
    const { phone, r } = await signUp();
    await admin.query(
      `INSERT INTO verification_codes (purpose, user_id, target_phone, code_hash, created_at, expires_at, invalidated_at)
       SELECT 'phone_verify', u.id, u.phone_e164, decode(repeat('ab', 32), 'hex'),
              now() - interval '2 hours' - g * interval '1 minute',
              now() - interval '2 hours' - g * interval '1 minute' + interval '10 minutes',
              now() - interval '2 hours' - g * interval '1 minute' + interval '1 minute'
         FROM users u, generate_series(1, 10) AS g
        WHERE u.phone_e164 = $1`,
      [phone],
    );
    const e = await failure(otp.requestPhoneVerification(r.user.id));
    assert.equal(e.code, 'rate_limited');
    assert.equal(e.retryAfterSeconds, 86_400);
    assert.equal((await codes(phone)).length, 10, 'nothing was added');
  });

  it('simultaneous requests cannot exceed the limits: the per-user lock lets exactly one issue a code (one message), the rest are clean throttles', async () => {
    const { phone, r } = await signUp();
    const sentBefore = msg.sent.length;
    const results = await Promise.allSettled(Array.from({ length: 8 }, () => otp.requestPhoneVerification(r.user.id)));
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.ok(results.filter((x) => x.status === 'rejected').every((x) => (x as PromiseRejectedResult).reason instanceof AuthError && ((x as PromiseRejectedResult).reason as AuthError).code === 'rate_limited'));
    const rows = await codes(phone);
    assert.equal(rows.length, 1);
    assert.equal(msg.sent.length - sentBefore, 1, 'exactly one message');
  });

  it('simultaneous forgot-password requests: ONE code and ONE message, and every answer is still the identical "accepted"', async () => {
    const { phone } = await signUp();
    const sentBefore = msg.sent.length;
    const answers = await Promise.all(Array.from({ length: 8 }, () => otp.requestPasswordReset({ phone: local(phone) })));
    assert.equal(new Set(answers.map((a) => JSON.stringify(a))).size, 1);
    assert.deepEqual(answers[0], { status: 'accepted' });
    assert.equal((await codes(phone)).length, 1);
    assert.equal(msg.sent.length - sentBefore, 1, 'eight simultaneous requests may not become eight messages');
  });

  it('an already-verified user: a request sends nothing, a confirmation is a harmless success that keeps the original time', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    await otp.confirmPhoneVerification(r.user.id, { code: msg.lastCode(phone, 'phone_verify')! });
    const stamp = (await userRow(phone)).phone_verified_at as Date;
    const sentBefore = msg.sent.length;
    const rowsBefore = (await codes(phone)).length;
    assert.deepEqual(await otp.requestPhoneVerification(r.user.id), { status: 'already_verified' });
    assert.equal((await otp.confirmPhoneVerification(r.user.id, { code: '123456' })).phoneVerified, true);
    assert.equal(msg.sent.length, sentBefore);
    assert.equal((await codes(phone)).length, rowsBefore);
    assert.equal(((await userRow(phone)).phone_verified_at as Date).getTime(), stamp.getTime());
  });

  it('simultaneous confirmations with the right code all end verified: one verification time, one consumed code', async () => {
    const { phone, r } = await signUp();
    await otp.requestPhoneVerification(r.user.id);
    const code = msg.lastCode(phone, 'phone_verify')!;
    const results = await Promise.allSettled(Array.from({ length: 5 }, () => otp.confirmPhoneVerification(r.user.id, { code })));
    assert.ok(results.every((x) => x.status === 'fulfilled'), JSON.stringify(results.filter((x) => x.status === 'rejected').map((x) => String((x as PromiseRejectedResult).reason))));
    assert.equal((await codes(phone)).filter((x) => x.consumed_at !== null).length, 1);
    assert.notEqual((await userRow(phone)).phone_verified_at, null);
  });

  it('the database itself refuses a code for an unknown purpose or a hash of the wrong length (defense in depth)', async () => {
    const { phone } = await signUp();
    const uid = (await userRow(phone)).id;
    await assert.rejects(app.query(`INSERT INTO verification_codes (purpose, user_id, target_phone, code_hash, expires_at) VALUES ('anything', $1, $2, decode(repeat('ab', 32), 'hex'), now() + interval '1 minute')`, [uid, phone]), (e: unknown) => (e as { kind?: string }).kind === 'check');
    await assert.rejects(app.query(`INSERT INTO verification_codes (purpose, user_id, target_phone, code_hash, expires_at) VALUES ('phone_verify', $1, $2, decode('abcd', 'hex'), now() + interval '1 minute')`, [uid, phone]), (e: unknown) => (e as { kind?: string }).kind === 'check');
  });

  // ---------------------------------------------------------------- password recovery
  it('forgot password: a registered phone gets a code; an unknown phone gets the IDENTICAL answer and nothing is stored or sent', async () => {
    const { phone } = await signUp();
    const stranger = newPhone();
    const sentBefore = msg.sent.length;
    const known = await otp.requestPasswordReset({ phone: local(phone) });
    const unknown = await otp.requestPasswordReset({ phone: local(stranger) });
    assert.equal(JSON.stringify(known), JSON.stringify(unknown));
    assert.deepEqual(known, { status: 'accepted' });
    assert.equal(msg.sent.length - sentBefore, 1);
    assert.equal(msg.sent.at(-1)?.phone, phone);
    assert.equal(msg.sent.at(-1)?.purpose, 'password_reset');
    assert.equal((await codes(phone)).length, 1);
    assert.equal((await admin.query('SELECT 1 FROM verification_codes c WHERE c.target_phone = $1', [stranger])).rows.length, 0);
  });

  it('every forgot-password answer is identical: delivered, throttled, unknown, suspended', async () => {
    const { phone, r } = await signUp();
    const answers = new Set<string>();
    answers.add(JSON.stringify(await otp.requestPasswordReset({ phone: local(phone) })));
    answers.add(JSON.stringify(await otp.requestPasswordReset({ phone: local(phone) }))); // cooldown
    answers.add(JSON.stringify(await otp.requestPasswordReset({ phone: local(newPhone()) })));
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [r.user.id]);
    await shiftCodes(phone, `${OTP.cooldownSeconds + 1} seconds`);
    const sentBefore = msg.sent.length;
    answers.add(JSON.stringify(await otp.requestPasswordReset({ phone: local(phone) })));
    assert.equal(answers.size, 1, [...answers].join(' | '));
    assert.equal(msg.sent.length, sentBefore, 'a suspended account gets no code');
  });

  it('a valid recovery sets the new password, ends EVERY session at once, clears the lockout and consumes the code', async () => {
    const { phone, r } = await signUp();
    const second = await auth.login({ phone: local(phone), password: PW });
    for (let i = 0; i < 5; i++) await auth.login({ phone: local(phone), password: 'wrong-password-' + i }).catch(() => undefined);
    assert.notEqual((await userRow(phone)).locked_until, null, 'precondition: the account is locked out');
    await otp.requestPasswordReset({ phone: local(phone) });
    const before = await userRow(phone);
    assert.deepEqual(await otp.resetPassword({ phone: local(phone), code: msg.lastCode(phone, 'password_reset')!, newPassword: NEW_PW }), { status: 'password_reset' });
    const after = await userRow(phone);
    assert.notEqual(after.password_hash, before.password_hash);
    assert.match(after.password_hash, /^\$argon2id\$/);
    assert.notEqual(after.password_changed_at, null);
    assert.equal(after.failed_logins, 0);
    assert.equal(after.locked_until, null);
    assert.notEqual((await codes(phone))[0]?.consumed_at, null);
    for (const s of [r.session, second.session]) {
      assert.equal(await auth.authenticate(s.accessToken), null, 'access tokens die at once, not after 15 minutes');
      assert.equal((await failure(auth.refresh({ refreshToken: s.refreshToken }))).code, 'unauthorized');
    }
    const live = await admin.query(`SELECT count(*)::int AS n FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1 AND s.revoked_at IS NULL`, [phone]);
    assert.equal((live.rows[0] as { n: number }).n, 0);
    const reasons = await admin.query(`SELECT DISTINCT s.revoked_reason FROM sessions s JOIN users u ON u.id = s.user_id WHERE u.phone_e164 = $1`, [phone]);
    assert.deepEqual(reasons.rows, [{ revoked_reason: 'password_changed' }]);
    assert.ok(await auth.login({ phone: local(phone), password: NEW_PW }));
    assert.equal((await failure(auth.login({ phone: local(phone), password: PW }))).code, 'invalid_credentials');
  });

  it('a wrong, expired or already-used recovery code changes nothing; a replay cannot override the owner\'s new password', async () => {
    const { phone } = await signUp();
    await otp.requestPasswordReset({ phone: local(phone) });
    const code = msg.lastCode(phone, 'password_reset')!;
    const original = (await userRow(phone)).password_hash;
    assert.equal((await failure(otp.resetPassword({ phone: local(phone), code: other(code), newPassword: NEW_PW }))).code, 'invalid_code');
    assert.equal((await userRow(phone)).password_hash, original);
    assert.equal((await codes(phone))[0]?.attempts, 1);

    await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW });
    const afterFirst = (await userRow(phone)).password_hash;
    assert.equal((await failure(otp.resetPassword({ phone: local(phone), code, newPassword: 'Attacker-Chosen-1' }))).code, 'invalid_code', 'replay');
    assert.equal((await userRow(phone)).password_hash, afterFirst);
    assert.ok(await auth.login({ phone: local(phone), password: NEW_PW }));

    await shiftCodes(phone, `${OTP.cooldownSeconds + 1} seconds`);
    await otp.requestPasswordReset({ phone: local(phone) });
    const fresh = msg.lastCode(phone, 'password_reset')!;
    await shiftCodes(phone, `${OTP.ttlSeconds + 1} seconds`);
    assert.equal((await failure(otp.resetPassword({ phone: local(phone), code: fresh, newPassword: 'Too-Late-Passw0rd' }))).code, 'invalid_code', 'expired');
    assert.equal((await userRow(phone)).password_hash, afterFirst);
  });

  it('five wrong recovery codes exhaust it: even the correct code is refused', async () => {
    const { phone } = await signUp();
    await otp.requestPasswordReset({ phone: local(phone) });
    const code = msg.lastCode(phone, 'password_reset')!;
    const original = (await userRow(phone)).password_hash;
    for (let i = 0; i < OTP.maxAttempts; i++) await failure(otp.resetPassword({ phone: local(phone), code: other(code), newPassword: NEW_PW }));
    assert.equal((await failure(otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }))).code, 'invalid_code');
    assert.equal((await userRow(phone)).password_hash, original);
  });

  it('the password policy is enforced BEFORE the code is examined: a weak password burns no attempt and the code still works', async () => {
    const { phone } = await signUp();
    await otp.requestPasswordReset({ phone: local(phone) });
    const code = msg.lastCode(phone, 'password_reset')!;
    for (const newPassword of ['12345', 'x'.repeat(129), '']) {
      const e = await failure(otp.resetPassword({ phone: local(phone), code, newPassword }));
      assert.equal(e.code, 'validation_failed');
    }
    assert.equal((await codes(phone))[0]?.attempts, 0);
    assert.deepEqual(await otp.resetPassword({ phone: local(phone), code, newPassword: NEW_PW }), { status: 'password_reset' });
  });

  it('simultaneous resets with one code: exactly one wins and its password is the one that works', async () => {
    const { phone } = await signUp();
    await otp.requestPasswordReset({ phone: local(phone) });
    const code = msg.lastCode(phone, 'password_reset')!;
    const candidates = ['Candidate-One-Pass1', 'Candidate-Two-Pass2', 'Candidate-Three-Pass3', 'Candidate-Four-Pass4'];
    const results = await Promise.allSettled(candidates.map((newPassword) => otp.resetPassword({ phone: local(phone), code, newPassword })));
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
    assert.ok(results.filter((x) => x.status === 'rejected').every((x) => ((x as PromiseRejectedResult).reason as AuthError).code === 'invalid_code'));
    const winner = candidates[results.findIndex((x) => x.status === 'fulfilled')] as string;
    assert.ok(await auth.login({ phone: local(phone), password: winner }));
    for (const loser of candidates.filter((c) => c !== winner)) assert.equal((await failure(auth.login({ phone: local(phone), password: loser }))).code, 'invalid_credentials');
  });

  it('every recovery failure is the same error: unknown phone, wrong code, used, wrong purpose, suspended', async () => {
    const shape = (e: AuthError) => JSON.stringify({ code: e.code, message: e.message, fields: e.fields });
    const shapes = new Set<string>();
    const a = await signUp();
    await otp.requestPasswordReset({ phone: local(a.phone) });
    const codeA = msg.lastCode(a.phone, 'password_reset')!;
    shapes.add(shape(await failure(otp.resetPassword({ phone: local(a.phone), code: other(codeA), newPassword: NEW_PW }))));
    shapes.add(shape(await failure(otp.resetPassword({ phone: local(newPhone()), code: codeA, newPassword: NEW_PW }))));
    await otp.resetPassword({ phone: local(a.phone), code: codeA, newPassword: NEW_PW });
    shapes.add(shape(await failure(otp.resetPassword({ phone: local(a.phone), code: codeA, newPassword: NEW_PW }))));
    const b = await signUp();
    await otp.requestPhoneVerification(b.r.user.id);
    shapes.add(shape(await failure(otp.resetPassword({ phone: local(b.phone), code: msg.lastCode(b.phone, 'phone_verify')!, newPassword: NEW_PW }))));
    const c = await signUp();
    await otp.requestPasswordReset({ phone: local(c.phone) });
    await admin.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [c.r.user.id]);
    shapes.add(shape(await failure(otp.resetPassword({ phone: local(c.phone), code: msg.lastCode(c.phone, 'password_reset')!, newPassword: NEW_PW }))));
    assert.equal(shapes.size, 1, [...shapes].join(' | '));
  });

  it('recovery proves nothing about the phone state: it neither verifies nor unverifies', async () => {
    const { phone } = await signUp();
    await otp.requestPasswordReset({ phone: local(phone) });
    await otp.resetPassword({ phone: local(phone), code: msg.lastCode(phone, 'password_reset')!, newPassword: NEW_PW });
    assert.equal((await userRow(phone)).phone_verified_at, null);
  });

  it('logs hold event names and ids only: no code, password, phone, hash, token or secret', async () => {
    const text = log.text();
    assert.ok(text.includes('auth.otp.rejected') && text.includes('auth.password_reset.completed') && text.includes('auth.phone.verified') && text.includes('auth.otp.sent'));
    const secrets = [PW, NEW_PW, 'Attacker-Chosen-1', SECRET, '$argon2', 'nsj_', 'eyJ', ...created, ...created.map(local), ...msg.sent.map((m) => m.code).filter((c, i, all) => all.indexOf(c) === i)];
    for (const secret of secrets) assert.ok(!text.includes(secret), `the log must not contain ${secret}`);
  });
});

describe('one-time codes over HTTP on PostgreSQL 16', { skip: skip || argon2Missing || fastifyMissing }, () => {
  let app: Db;
  let admin: Db;
  const msg = makeFakeProvider();
  const config = () => loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', DATABASE_URL: APP_URL });
  const json = { 'content-type': 'application/json' };

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
  });
  after(async () => {
    if (admin && created.length > 0) await admin.query('DELETE FROM users WHERE phone_e164::text = ANY($1::text[])', [created]);
    await app?.close();
    await admin?.close();
  });
  const stack = async (withLimiter = false) => {
    const store = createPgAuthStore(app);
    const auth = createAuthService({ store, hasher, accessTokenSecret: SECRET });
    const otp = createOtpService({ store, hasher, provider: msg.provider, otpSecret: SECRET });
    return buildServer!({ config: config(), db: app, auth, otp, ...(withLimiter ? { rateLimiter: createMemoryRateLimiter() } : {}) });
  };

  it('verification end to end: request, confirm, and /me shows the phone as verified; unauthenticated calls are 401', async () => {
    const server = await stack();
    const phone = newPhone();
    const reg = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'مستخدم HTTP', phone: local(phone), password: PW }) })).json() as { session: { accessToken: string }; user: { phoneVerified: boolean } };
    assert.equal(reg.user.phoneVerified, false);
    const bearer = { authorization: `Bearer ${reg.session.accessToken}` };
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/phone/verify/request' })).statusCode, 401);
    const requested = await server.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers: bearer });
    assert.equal(requested.statusCode, 202);
    assert.deepEqual(requested.json(), { status: 'sent' });
    const again = await server.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers: bearer });
    assert.equal(again.statusCode, 429);
    assert.ok(Number(again.headers['retry-after']) > 0);
    const code = msg.lastCode(phone, 'phone_verify')!;
    const wrong = await server.inject({ method: 'POST', url: '/v1/auth/phone/verify/confirm', headers: { ...json, ...bearer }, payload: JSON.stringify({ code: other(code) }) });
    assert.equal(wrong.statusCode, 400);
    assert.equal((wrong.json() as { error: { code: string } }).error.code, 'invalid_code');
    const ok = await server.inject({ method: 'POST', url: '/v1/auth/phone/verify/confirm', headers: { ...json, ...bearer }, payload: JSON.stringify({ code }) });
    assert.equal(ok.statusCode, 200);
    assert.equal((ok.json() as { user: { phoneVerified: boolean } }).user.phoneVerified, true);
    const me = await server.inject({ method: 'GET', url: '/v1/auth/me', headers: bearer });
    assert.equal((me.json() as { user: { phoneVerified: boolean } }).user.phoneVerified, true);
    const done = await server.inject({ method: 'POST', url: '/v1/auth/phone/verify/request', headers: bearer });
    assert.equal(done.statusCode, 200);
    assert.deepEqual(done.json(), { status: 'already_verified' });
    for (const r of [requested, wrong, ok, me]) assert.ok(!r.body.includes(code) && !r.body.includes(PW) && !r.body.includes('$argon2'));
    await server.close();
  });

  it('recovery end to end: the forgot answer is byte-identical for a known and an unknown phone; reset works once, and old sessions die', async () => {
    const server = await stack();
    const phone = newPhone();
    const reg = (await server.inject({ method: 'POST', url: '/v1/auth/register', headers: json, payload: JSON.stringify({ name: 'استرداد HTTP', phone: local(phone), password: PW }) })).json() as { session: { accessToken: string; refreshToken: string } };
    const forgot = (p: string) => server.inject({ method: 'POST', url: '/v1/auth/password/forgot', headers: json, payload: JSON.stringify({ phone: local(p) }) });
    const known = await forgot(phone);
    const unknown = await forgot(newPhone());
    assert.equal(known.statusCode, 202);
    assert.equal(unknown.statusCode, known.statusCode);
    assert.equal(unknown.body, known.body);
    assert.equal(unknown.headers['content-type'], known.headers['content-type']);
    assert.equal(unknown.headers['cache-control'], known.headers['cache-control']);
    const code = msg.lastCode(phone, 'password_reset')!;
    const reset = (c: string, pw: string) => server.inject({ method: 'POST', url: '/v1/auth/password/reset', headers: json, payload: JSON.stringify({ phone: local(phone), code: c, newPassword: pw }) });
    const weak = await reset(code, '12345');
    assert.equal(weak.statusCode, 400);
    assert.deepEqual((weak.json() as { error: { fields: unknown } }).error.fields, [{ field: 'newPassword', code: 'too_short' }]);
    const wrong = await reset(other(code), NEW_PW);
    assert.equal(wrong.statusCode, 400);
    assert.equal((wrong.json() as { error: { code: string } }).error.code, 'invalid_code');
    const ok = await reset(code, NEW_PW);
    assert.equal(ok.statusCode, 200);
    assert.deepEqual(ok.json(), { status: 'password_reset' });
    assert.equal((await reset(code, 'Attacker-Chosen-1')).statusCode, 400, 'replay');
    assert.equal((await server.inject({ method: 'GET', url: '/v1/auth/me', headers: { authorization: `Bearer ${reg.session.accessToken}` } })).statusCode, 401, 'the old session is dead');
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/refresh', headers: json, payload: JSON.stringify({ refreshToken: reg.session.refreshToken }) })).statusCode, 401);
    const login = await server.inject({ method: 'POST', url: '/v1/auth/login', headers: json, payload: JSON.stringify({ phone: local(phone), password: NEW_PW }) });
    assert.equal(login.statusCode, 200);
    for (const r of [known, ok, wrong, weak]) assert.ok(!r.body.includes(code) && !r.body.includes(NEW_PW) && !r.body.includes(PW));
    await server.close();
  });

  it('forgot-password and verification requests are rate limited per client address (429 + Retry-After)', async () => {
    const server = await stack(true);
    const hit = () => server.inject({ method: 'POST', url: '/v1/auth/password/forgot', headers: json, payload: JSON.stringify({ phone: local(newPhone()) }), remoteAddress: '198.51.100.77' });
    for (let i = 0; i < RATE_LIMITS.passwordForgot.limit; i++) assert.equal((await hit()).statusCode, 202);
    const blocked = await hit();
    assert.equal(blocked.statusCode, 429);
    assert.equal(blocked.headers['retry-after'], String(RATE_LIMITS.passwordForgot.windowSeconds));
    assert.equal((await server.inject({ method: 'POST', url: '/v1/auth/password/forgot', headers: json, payload: JSON.stringify({ phone: local(newPhone()) }), remoteAddress: '198.51.100.78' })).statusCode, 202, 'another client is unaffected');
    await server.close();
  });
});

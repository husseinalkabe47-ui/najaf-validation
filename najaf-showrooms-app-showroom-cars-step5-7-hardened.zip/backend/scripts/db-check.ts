// Operator tool: verifies the configured database connection against the backend policy.
//   npm run db:check          (reads the same environment variables as the server)
// Prints a JSON report without secrets. Exit code 0 only if connectivity, role policy and schema contract all pass.
import { ConfigError, describeDbTarget, loadConfig } from '../src/config.ts';
import { createDb } from '../src/db.ts';
import { describeError } from '../src/errors.ts';
import { roleViolations } from '../src/role.ts';

async function run(): Promise<number> {
  let config;
  try {
    config = loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      console.error(JSON.stringify({ ok: false, configProblems: e.problems }, null, 2));
      return 78;
    }
    throw e;
  }
  const db = await createDb(config.db);
  try {
    await db.ping();
    const role = await db.verifyRole();
    const violations = config.db.requireAppRole ? roleViolations(role) : [];
    const { missing } = await db.checkSchema();
    const ok = violations.length === 0 && missing.length === 0;
    console.log(JSON.stringify({ ok, target: describeDbTarget(config.db), role, roleViolations: violations, missingSchemaObjects: missing }, null, 2));
    return ok ? 0 : 1;
  } catch (e) {
    console.error(JSON.stringify({ ok: false, target: describeDbTarget(config.db), error: describeError(e) }, null, 2));
    return 1;
  } finally {
    await db.close();
  }
}

process.exitCode = await run();

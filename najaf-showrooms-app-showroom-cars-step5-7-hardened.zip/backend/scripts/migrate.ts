// Operator tool for the migration runner.
//   npm run db:migrate                         apply every pending migration (0001-0013)
//   npm run db:rollback -- --steps 1           roll back the last N migrations
//   npm run db:rollback -- --all               roll back everything (the tables are dropped; roles are kept)
//   npm run db:migrate:status                  applied / pending / unknown
// Uses MIGRATION_DATABASE_URL (a dedicated account), never the application account. Output is JSON without secrets:
// stdout carries exactly ONE JSON result document; node-pg-migrate's log lines go to stderr (scripts and CI parse stdout).
import { describeError } from '../src/errors.ts';
import { MigrationConfigError, describeMigrationTarget, loadMigrationConfig } from '../src/migrate/config.ts';
import { MigrationRoleError, assertMigrationRole } from '../src/migrate/preflight.ts';
import { MigrationError, migrationStatus, parseMigrateArgs, runMigrations } from '../src/migrate/runner.ts';
import { createConsoleLogger } from '../src/types.ts';

const EX_USAGE = 64;
const EX_CONFIG = 78;

async function run(): Promise<number> {
  let command;
  try {
    command = parseMigrateArgs(process.argv.slice(2));
  } catch (e) {
    if (e instanceof MigrationError) {
      console.error(JSON.stringify({ ok: false, error: e.message }));
      return EX_USAGE;
    }
    throw e;
  }

  let config;
  try {
    config = loadMigrationConfig();
  } catch (e) {
    if (e instanceof MigrationConfigError) {
      console.error(JSON.stringify({ ok: false, configProblems: e.problems }, null, 2));
      return EX_CONFIG;
    }
    throw e;
  }
  const target = describeMigrationTarget(config);

  try {
    const report = await assertMigrationRole(config);
    if (command.kind === 'status') {
      console.log(JSON.stringify({ ok: true, target, account: report.currentUser, ...(await migrationStatus(config)) }, null, 2));
      return 0;
    }
    const result = await runMigrations(config, command.kind === 'up' ? { direction: 'up' } : { direction: 'down', steps: command.steps }, { logger: createConsoleLogger((line) => console.error(line)) });
    console.log(JSON.stringify({ ok: true, target, account: report.currentUser, ...result }, null, 2));
    return 0;
  } catch (e) {
    if (e instanceof MigrationRoleError) {
      console.error(JSON.stringify({ ok: false, target, violations: e.violations }, null, 2));
      return EX_CONFIG;
    }
    if (e instanceof MigrationError) {
      console.error(JSON.stringify({ ok: false, target, code: e.code, error: e.message }, null, 2));
      return e.code === 'bad_request' ? EX_USAGE : 1;
    }
    console.error(JSON.stringify({ ok: false, target, error: describeError(e) }, null, 2));
    return 1;
  }
}

process.exitCode = await run();

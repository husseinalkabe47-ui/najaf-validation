// Input parsing for the PUBLIC catalog (Phase 11.5, Step 5.3). Read-only, no authentication.
//
// Rules (each one is covered by tests):
//  - Strict: unknown keys are rejected; repeated keys (arrays) are rejected; every value is type- and range-checked.
//  - Whitelist: filter values come from the schema vocabularies (currency, transmission, fuel type, source, status), never from
//    free text that reaches SQL. Free text (q) is length-bounded, normalized, and only ever used as a bound parameter.
//  - Pagination is keyset (`before` = the id of the last item the client has), with a fixed default and a hard maximum. No OFFSET.
//  - Error objects carry field names and machine codes only, never the submitted values.
import type { FieldError } from '../auth/validation.ts';

export const CATALOG_LIMIT_DEFAULT = 20;
export const CATALOG_LIMIT_MAX = 50;
export const SEARCH_MAX_LENGTH = 100;
export const SEARCH_MAX_TERMS = 5;
export const YEAR_MIN = 1980;
export const YEAR_MAX = 2100;
export const PRICE_MAX = 999_999_999_999; // numeric(14,0)
export const TEXT_FILTER_MAX = 40;

export const CURRENCIES = ['IQD', 'USD'] as const;
export const TRANSMISSIONS = ['أوتوماتيك', 'يدوي'] as const;
export const FUEL_TYPES = ['بنزين', 'ديزل', 'هايبرد', 'كهرباء'] as const;
export const SOURCE_TYPES = ['showroom', 'member'] as const;
/** Public statuses that the public views can return: showroom cars are available|sold; member cars are active only (the view). */
export const CAR_STATUSES = ['available', 'sold', 'active'] as const;

export type Parsed<T> = { ok: true; value: T } | { ok: false; errors: FieldError[] };
const MAX_ERRORS = 10;
const KEY = /^[A-Za-z0-9_]{1,40}$/;
const CONTROL = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
const ID = /^[1-9][0-9]{0,18}$/;
const BIGINT_MAX = '9223372036854775807';
/** A canonical positive id that PostgreSQL's bigint can hold. Larger values would fail inside the database (a 500), so they are refused here. */
export function isBigintId(v: string): boolean {
  return ID.test(v) && (v.length < BIGINT_MAX.length || (v.length === BIGINT_MAX.length && v <= BIGINT_MAX));
}

export interface Page {
  limit: number;
  /** Keyset cursor: return items with id strictly below this id. null = first page. */
  before: string | null;
}

/** Normalizes free text the same way the application's search does (NFKC, lowercase, collapsed spaces, no control characters). */
export function normalizeSearchText(raw: string): string {
  return raw.normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim();
}

/** Escapes LIKE metacharacters so that user text is always a literal (used with ESCAPE '\'). */
export function escapeLike(term: string): string {
  return term.replace(/[\\%_]/g, (c) => `\\${c}`);
}

class Collector {
  readonly errors: FieldError[] = [];
  add(field: string, code: FieldError['code']): void {
    this.errors.push({ field, code });
  }
  result<T>(value: T): Parsed<T> {
    if (this.errors.length > 0) return { ok: false, errors: this.errors.slice(0, MAX_ERRORS) };
    return { ok: true, value };
  }
}

/** A query value must be a single string. Arrays (repeated keys) and other types are invalid_type. */
function single(c: Collector, query: Record<string, unknown>, key: string): string | undefined {
  const v = query[key];
  if (v === undefined) return undefined;
  if (typeof v !== 'string') {
    c.add(key, 'invalid_type');
    return undefined;
  }
  return v;
}

function checkKeys(c: Collector, query: Record<string, unknown>, allowed: readonly string[]): void {
  for (const k of Object.keys(query)) if (!allowed.includes(k)) c.add(KEY.test(k) ? k : 'unknown', 'unknown_field');
}

function parsePage(c: Collector, query: Record<string, unknown>): Page {
  let limit = CATALOG_LIMIT_DEFAULT;
  const l = single(c, query, 'limit');
  if (l !== undefined) {
    if (!/^[1-9][0-9]{0,2}$/.test(l) || Number(l) > CATALOG_LIMIT_MAX) c.add('limit', 'invalid_format');
    else limit = Number(l);
  }
  let before: string | null = null;
  const b = single(c, query, 'before');
  if (b !== undefined) {
    if (!isBigintId(b)) c.add('before', 'invalid_format');
    else before = b;
  }
  return { limit, before };
}

/** q: free text. Normalized, length-bounded, split into at most SEARCH_MAX_TERMS terms (all must match). */
function parseSearch(c: Collector, query: Record<string, unknown>): string[] {
  const raw = single(c, query, 'q');
  if (raw === undefined) return [];
  if (CONTROL.test(raw) || raw.includes('\u0000')) {
    c.add('q', 'invalid_format');
    return [];
  }
  if (Array.from(raw).length > SEARCH_MAX_LENGTH) {
    c.add('q', 'too_long');
    return [];
  }
  const terms = normalizeSearchText(raw).split(' ').filter(Boolean);
  if (terms.length > SEARCH_MAX_TERMS) {
    c.add('q', 'too_long');
    return [];
  }
  return terms;
}

export interface ShowroomListQuery {
  page: Page;
  terms: string[];
}
export function parseShowroomListQuery(query: unknown): Parsed<ShowroomListQuery> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const c = new Collector();
  checkKeys(c, q, ['q', 'limit', 'before']);
  const page = parsePage(c, q);
  const terms = parseSearch(c, q);
  return c.result({ page, terms });
}

export interface CarListQuery {
  page: Page;
  terms: string[];
  source: (typeof SOURCE_TYPES)[number] | null;
  showroomId: string | null;
  brand: string | null;
  model: string | null;
  color: string | null;
  transmission: (typeof TRANSMISSIONS)[number] | null;
  fuelType: (typeof FUEL_TYPES)[number] | null;
  status: (typeof CAR_STATUSES)[number] | null;
  yearMin: number | null;
  yearMax: number | null;
  currency: (typeof CURRENCIES)[number] | null;
  priceMin: number | null;
  priceMax: number | null;
}

const TOP_LEVEL_CAR_KEYS = ['q', 'limit', 'before', 'source', 'showroomId', 'brand', 'model', 'color', 'transmission', 'fuelType', 'status', 'yearMin', 'yearMax', 'currency', 'priceMin', 'priceMax'];

function enumValue<T extends string>(c: Collector, query: Record<string, unknown>, key: string, allowed: readonly T[]): T | null {
  const v = single(c, query, key);
  if (v === undefined) return null;
  if (!(allowed as readonly string[]).includes(v)) {
    c.add(key, 'invalid_format');
    return null;
  }
  return v as T;
}

function textFilter(c: Collector, query: Record<string, unknown>, key: string): string | null {
  const v = single(c, query, key);
  if (v === undefined) return null;
  const t = v.normalize('NFKC').trim();
  if (t === '') return null;
  if (CONTROL.test(t) || Array.from(t).length > TEXT_FILTER_MAX) {
    c.add(key, Array.from(t).length > TEXT_FILTER_MAX ? 'too_long' : 'invalid_format');
    return null;
  }
  return t;
}

function integerFilter(c: Collector, query: Record<string, unknown>, key: string, min: number, max: number): number | null {
  const v = single(c, query, key);
  if (v === undefined) return null;
  if (!/^[0-9]{1,15}$/.test(v)) {
    c.add(key, 'invalid_format');
    return null;
  }
  const n = Number(v);
  if (n < min || n > max) {
    c.add(key, 'invalid_format');
    return null;
  }
  return n;
}

export function parseCarListQuery(query: unknown): Parsed<CarListQuery> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const c = new Collector();
  checkKeys(c, q, TOP_LEVEL_CAR_KEYS);
  const page = parsePage(c, q);
  const terms = parseSearch(c, q);
  const source = enumValue(c, q, 'source', SOURCE_TYPES);
  let showroomId: string | null = null;
  const sid = single(c, q, 'showroomId');
  if (sid !== undefined) {
    if (!isBigintId(sid)) c.add('showroomId', 'invalid_format');
    else showroomId = sid;
  }
  const brand = textFilter(c, q, 'brand');
  const model = textFilter(c, q, 'model');
  const color = textFilter(c, q, 'color');
  const transmission = enumValue(c, q, 'transmission', TRANSMISSIONS);
  const fuelType = enumValue(c, q, 'fuelType', FUEL_TYPES);
  const status = enumValue(c, q, 'status', CAR_STATUSES);
  const yearMin = integerFilter(c, q, 'yearMin', YEAR_MIN, YEAR_MAX);
  const yearMax = integerFilter(c, q, 'yearMax', YEAR_MIN, YEAR_MAX);
  if (yearMin !== null && yearMax !== null && yearMin > yearMax) c.add('yearMax', 'invalid_format');
  const currency = enumValue(c, q, 'currency', CURRENCIES);
  const priceMin = integerFilter(c, q, 'priceMin', 0, PRICE_MAX);
  const priceMax = integerFilter(c, q, 'priceMax', 0, PRICE_MAX);
  if (priceMin !== null && priceMax !== null && priceMin > priceMax) c.add('priceMax', 'invalid_format');
  // A price range is meaningless without the currency it is quoted in: prices are never compared across currencies.
  if ((priceMin !== null || priceMax !== null) && currency === null) c.add('currency', 'required');
  return c.result({ page, terms, source, showroomId, brand, model, color, transmission, fuelType, status, yearMin, yearMax, currency, priceMin, priceMax });
}

/** A detail route id: the path parameter, canonical positive bigint string. */
export function parseIdParam(id: unknown): string | null {
  return typeof id === 'string' && isBigintId(id) ? id : null;
}

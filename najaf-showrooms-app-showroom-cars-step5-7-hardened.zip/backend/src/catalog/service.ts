// Public catalog service (Phase 11.5, Step 5.3): read-only, no authentication, no actor.
//
// Decisions (each is covered by tests):
//  - Visibility is decided by the database views (see repository.ts). This service adds NO extra visibility rule and never reads
//    a base table; a record the views do not return is simply absent, and a detail request for it is 404.
//  - Output is a whitelist DTO built field by field. owner_id, reviewer data, reasons, search_text and asset keys never leave.
//  - A malformed id and an id that is not public are the SAME 404 (no existence oracle, no 400 that would distinguish them).
//  - Pagination is keyset: `nextBefore` is the id of the last item returned, and only when a full page came back.
//  - Member-car fields the views expose by design (contact, location, owner display name) are passed through as the views define them.
import { notFound } from '../authz/index.ts';
import { parseCarListQuery, parseIdParam, parseShowroomListQuery } from './params.ts';
import type { CarListQuery, ShowroomListQuery } from './params.ts';
import type { CatalogRepository, PublicCarRow, PublicShowroomRow } from './repository.ts';
import type { FieldError } from '../auth/validation.ts';

export class CatalogError extends Error {
  readonly code = 'validation_failed' as const;
  readonly fields: FieldError[];
  constructor(fields: FieldError[]) {
    super('The submitted data is not valid');
    this.name = 'CatalogError';
    this.fields = fields;
  }
}

export interface PublicShowroom {
  id: string;
  name: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  address: string;
  latitude: number | null;
  longitude: number | null;
  workingHours: string;
  services: string[];
  createdAt: string;
  updatedAt: string;
}
export interface PublicCar {
  id: string;
  sourceType: string;
  showroomId: string | null;
  brand: string;
  model: string;
  year: number;
  price: number;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  status: string;
  phone: string | null;
  whatsapp: string | null;
  location: string;
  latitude: number | null;
  longitude: number | null;
  ownerName: string | null;
  createdAt: string;
  updatedAt: string;
}
export interface Page<T> {
  items: T[];
  /** Pass as `before` to get the next page; null when this page was the last one. */
  nextBefore: string | null;
}

const num = (v: string | null): number | null => (v === null ? null : Number(v));

export function toPublicShowroom(r: PublicShowroomRow): PublicShowroom {
  return {
    id: r.id,
    name: r.name,
    description: r.description,
    phone: r.phone,
    whatsapp: r.whatsapp,
    address: r.address,
    latitude: num(r.latitude),
    longitude: num(r.longitude),
    workingHours: r.working_hours,
    services: [...r.services],
    createdAt: r.created_at.toISOString(),
    updatedAt: r.updated_at.toISOString(),
  };
}

export function toPublicCar(r: PublicCarRow): PublicCar {
  return {
    id: r.id,
    sourceType: r.source_type,
    showroomId: r.showroom_id,
    brand: r.brand,
    model: r.model,
    year: r.year,
    price: Number(r.price),
    currency: r.currency,
    mileage: r.mileage,
    transmission: r.transmission,
    fuelType: r.fuel_type,
    color: r.color,
    description: r.description,
    status: r.status,
    phone: r.phone,
    whatsapp: r.whatsapp,
    location: r.location,
    latitude: num(r.latitude),
    longitude: num(r.longitude),
    ownerName: r.owner_name,
    createdAt: r.created_at.toISOString(),
    updatedAt: r.updated_at.toISOString(),
  };
}

function pageOf<R, T>(rows: R[], limit: number, id: (r: R) => string, map: (r: R) => T): Page<T> {
  const last = rows.length === limit ? rows[rows.length - 1] : undefined;
  return { items: rows.map(map), nextBefore: last === undefined ? null : id(last) };
}

export interface CatalogApi {
  listShowrooms(query: unknown): Promise<Page<PublicShowroom>>;
  getShowroom(id: unknown): Promise<PublicShowroom>;
  listCars(query: unknown): Promise<Page<PublicCar>>;
  getCar(id: unknown): Promise<PublicCar>;
}

export function createCatalogService(deps: { repo: CatalogRepository }): CatalogApi {
  const { repo } = deps;

  const parsed = <T>(r: { ok: true; value: T } | { ok: false; errors: FieldError[] }): T => {
    if (!r.ok) throw new CatalogError(r.errors);
    return r.value;
  };

  return {
    async listShowrooms(query) {
      const q: ShowroomListQuery = parsed(parseShowroomListQuery(query));
      const rows = await repo.listShowrooms(q);
      return pageOf(rows, q.page.limit, (r) => r.id, toPublicShowroom);
    },

    async getShowroom(rawId) {
      const id = parseIdParam(rawId);
      if (id === null) throw notFound();
      const row = await repo.findShowroom(id);
      if (!row) throw notFound();
      return toPublicShowroom(row);
    },

    async listCars(query) {
      const q: CarListQuery = parsed(parseCarListQuery(query));
      const rows = await repo.listCars(q);
      return pageOf(rows, q.page.limit, (r) => r.id, toPublicCar);
    },

    async getCar(rawId) {
      const id = parseIdParam(rawId);
      if (id === null) throw notFound();
      const row = await repo.findCar(id);
      if (!row) throw notFound();
      return toPublicCar(row);
    },
  };
}

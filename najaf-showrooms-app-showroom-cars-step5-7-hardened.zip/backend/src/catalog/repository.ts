// SQL for the PUBLIC catalog (Phase 11.5, Step 5.3). The ONLY relations these queries read are the two public views:
//   public_showrooms  (active showroom AND active, not deleted owner)
//   public_cars       (showroom car in a public showroom, or active member car of an active owner; not deleted)
// Those views decide visibility; nothing here re-implements it, and nothing reads the base tables. Both views omit owner_id,
// reviewer data, rejection/suspension reasons and password material. A static test pins this.
//
// Every value is a bound parameter. Filters are added only from the whitelist in params.ts, so the SQL text is one of a fixed set of
// shapes. Ordering is keyset on id (unique, never changes), so pages are stable while rows are added or hidden.
import type { Db } from '../db.ts';
import { escapeLike } from './params.ts';
import type { CarListQuery, ShowroomListQuery } from './params.ts';

export interface PublicShowroomRow {
  id: string;
  name: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  address: string;
  latitude: string | null;
  longitude: string | null;
  working_hours: string;
  services: string[];
  created_at: Date;
  updated_at: Date;
}
export interface PublicCarRow {
  id: string;
  source_type: string;
  showroom_id: string | null;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuel_type: string;
  color: string;
  description: string;
  status: string;
  phone: string | null;
  whatsapp: string | null;
  location: string;
  latitude: string | null;
  longitude: string | null;
  owner_name: string | null;
  created_at: Date;
  updated_at: Date;
}

export interface CatalogRepository {
  listShowrooms(q: ShowroomListQuery): Promise<PublicShowroomRow[]>;
  findShowroom(id: string): Promise<PublicShowroomRow | null>;
  listCars(q: CarListQuery): Promise<PublicCarRow[]>;
  findCar(id: string): Promise<PublicCarRow | null>;
}

const SHOWROOM_COLUMNS = `ps.id, ps.name, ps.description, ps.phone, ps.whatsapp, ps.address, ps.latitude, ps.longitude,
       ps.working_hours, ps.services, ps.created_at, ps.updated_at`;
const CAR_COLUMNS = `pc.id, pc.source_type, pc.showroom_id, pc.brand, pc.model, pc.year, pc.price, pc.currency, pc.mileage,
       pc.transmission, pc.fuel_type, pc.color, pc.description, pc.status, pc.phone, pc.whatsapp, pc.location, pc.latitude,
       pc.longitude, pc.owner_name, pc.created_at, pc.updated_at`;

/** A builder collects clauses and their parameters; placeholders are numbered as the parameters are added. */
class Sql {
  readonly values: unknown[] = [];
  readonly clauses: string[] = [];
  bind(value: unknown): string {
    this.values.push(value);
    return `$${this.values.length}`;
  }
  where(clause: string): void {
    this.clauses.push(clause);
  }
  text(select: string, order: string, limit: number): { text: string; values: unknown[] } {
    const lim = this.bind(limit);
    const where = this.clauses.length > 0 ? `WHERE ${this.clauses.join(' AND ')}` : '';
    return { text: `${select} ${where} ${order} LIMIT ${lim}`, values: this.values };
  }
}

/** Each term must appear in at least one of the given text columns (AND across terms). Case-insensitive, literal. */
function addTerms(sql: Sql, terms: readonly string[], columns: readonly string[]): void {
  for (const term of terms) {
    const p = sql.bind(`%${escapeLike(term)}%`);
    sql.where(`(${columns.map((c) => `lower(${c}) LIKE ${p} ESCAPE '\\'`).join(' OR ')})`);
  }
}

export function buildShowroomList(q: ShowroomListQuery): { text: string; values: unknown[] } {
  const sql = new Sql();
  if (q.page.before !== null) sql.where(`ps.id < ${sql.bind(q.page.before)}::bigint`);
  addTerms(sql, q.terms, ['ps.name', 'ps.address', 'ps.search_text']);
  return sql.text(`SELECT ${SHOWROOM_COLUMNS} FROM public_showrooms ps`, 'ORDER BY ps.id DESC', q.page.limit);
}

export function buildShowroomDetail(id: string): { text: string; values: unknown[] } {
  return { text: `SELECT ${SHOWROOM_COLUMNS} FROM public_showrooms ps WHERE ps.id = $1::bigint`, values: [id] };
}

export function buildCarList(q: CarListQuery): { text: string; values: unknown[] } {
  const sql = new Sql();
  if (q.page.before !== null) sql.where(`pc.id < ${sql.bind(q.page.before)}::bigint`);
  addTerms(sql, q.terms, ['pc.brand', 'pc.model', 'pc.color', 'pc.search_text']);
  if (q.source !== null) sql.where(`pc.source_type = ${sql.bind(q.source)}`);
  if (q.showroomId !== null) sql.where(`pc.showroom_id = ${sql.bind(q.showroomId)}::bigint`);
  if (q.brand !== null) sql.where(`lower(pc.brand) = lower(${sql.bind(q.brand)})`);
  if (q.model !== null) sql.where(`lower(pc.model) = lower(${sql.bind(q.model)})`);
  if (q.color !== null) sql.where(`lower(pc.color) = lower(${sql.bind(q.color)})`);
  if (q.transmission !== null) sql.where(`pc.transmission = ${sql.bind(q.transmission)}`);
  if (q.fuelType !== null) sql.where(`pc.fuel_type = ${sql.bind(q.fuelType)}`);
  if (q.status !== null) sql.where(`pc.status = ${sql.bind(q.status)}`);
  if (q.yearMin !== null) sql.where(`pc.year >= ${sql.bind(q.yearMin)}`);
  if (q.yearMax !== null) sql.where(`pc.year <= ${sql.bind(q.yearMax)}`);
  // Prices are compared only within the one currency the caller named (never converted, never mixed).
  if (q.currency !== null) sql.where(`pc.currency = ${sql.bind(q.currency)}`);
  if (q.priceMin !== null) sql.where(`pc.price >= ${sql.bind(q.priceMin)}`);
  if (q.priceMax !== null) sql.where(`pc.price <= ${sql.bind(q.priceMax)}`);
  return sql.text(`SELECT ${CAR_COLUMNS} FROM public_cars pc`, 'ORDER BY pc.id DESC', q.page.limit);
}

export function buildCarDetail(id: string): { text: string; values: unknown[] } {
  return { text: `SELECT ${CAR_COLUMNS} FROM public_cars pc WHERE pc.id = $1::bigint`, values: [id] };
}

export function createPgCatalogRepository(db: Pick<Db, 'query'>): CatalogRepository {
  const run = async <R>(s: { text: string; values: unknown[] }): Promise<R[]> => (await db.query<R>(s.text, s.values)).rows;
  return {
    listShowrooms: async (q) => run<PublicShowroomRow>(buildShowroomList(q)),
    findShowroom: async (id) => (await run<PublicShowroomRow>(buildShowroomDetail(id)))[0] ?? null,
    listCars: async (q) => run<PublicCarRow>(buildCarList(q)),
    findCar: async (id) => (await run<PublicCarRow>(buildCarDetail(id)))[0] ?? null,
  };
}

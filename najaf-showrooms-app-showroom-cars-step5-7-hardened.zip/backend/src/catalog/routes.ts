// HTTP contract for the PUBLIC catalog (Phase 11.5, Step 5.3). Read-only, no authentication (an Authorization header, if sent,
// is ignored: nothing here is personalized). Imports Fastify TYPES only.
//
//   GET /v1/public/showrooms?q=&limit=&before=      -> 200 {items, nextBefore}
//   GET /v1/public/showrooms/:id                    -> 200 {showroom}          404 if not public
//   GET /v1/public/cars?q=&source=&showroomId=&brand=&model=&color=&transmission=&fuelType=&status=&yearMin=&yearMax=&currency=&priceMin=&priceMax=&limit=&before=
//                                                   -> 200 {items, nextBefore}
//   GET /v1/public/cars/:id                         -> 200 {car}               404 if not public
//
// Errors: 400 for invalid query input (field names and codes only); 404 for anything not public or not existing (identical).
// Rate limit: per client address and per instance (in-memory), like the other public routes.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { toAuthzHttp } from '../authz/index.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import type { FieldError } from '../auth/validation.ts';
import { CatalogError } from './service.ts';
import type { CatalogApi } from './service.ts';

/** PROPOSED, per client address and per instance. Reads are cheap but unauthenticated, so they are limited. */
export const CATALOG_RATE_LIMITS = {
  list: { limit: 240, windowSeconds: 10 * 60 },
  detail: { limit: 480, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type CatalogRateLimitedRoute = keyof typeof CATALOG_RATE_LIMITS;

export interface CatalogHttpError {
  status: number;
  code: string;
  message: string;
  fields?: FieldError[];
}

/** Maps catalog errors to the HTTP contract; undefined = not ours (the global handler maps it). */
export function toCatalogHttp(e: unknown): CatalogHttpError | undefined {
  if (e instanceof CatalogError) return { status: 400, code: e.code, message: e.message, fields: e.fields };
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  return undefined;
}

type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };
type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;

function catalogRateLimitHook(limiter: RateLimiter, route: CatalogRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`catalog.${route}:${request.ip}`, CATALOG_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'catalog.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

export function registerCatalogRoutes(app: FastifyInstance, deps: { catalog: CatalogApi; rateLimiter?: RateLimiter }): void {
  const { catalog, rateLimiter } = deps;
  const limited = (route: CatalogRateLimitedRoute): Hook[] => (rateLimiter ? [catalogRateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toCatalogHttp(e);
    if (!mapped) throw e;
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The path id is passed through as-is: the service decides (a malformed id is the same 404 as a missing one).
  const idParam = (request: FastifyRequest): unknown => (request.params as Record<string, unknown> | undefined)?.['id'];

  app.get('/v1/public/showrooms', { onRequest: limited('list') }, async (request, reply) => {
    try {
      return reply.code(200).send(await catalog.listShowrooms(request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/public/showrooms/:id', { onRequest: limited('detail') }, async (request, reply) => {
    try {
      const showroom = await catalog.getShowroom(idParam(request));
      return reply.code(200).send({ showroom });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/public/cars', { onRequest: limited('list') }, async (request, reply) => {
    try {
      return reply.code(200).send(await catalog.listCars(request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/public/cars/:id', { onRequest: limited('detail') }, async (request, reply) => {
    try {
      const car = await catalog.getCar(idParam(request));
      return reply.code(200).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

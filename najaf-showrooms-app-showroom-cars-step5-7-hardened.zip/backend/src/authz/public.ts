// Authorization core (Phase 11.5, Step 5.1): PUBLIC visibility, deliberately separate from private authorization.
//
// "May anyone see this?" depends only on the resource. It mirrors the database views public_showrooms / public_cars (which remain the
// authoritative source for LISTING public data). It never looks at who is asking and grants nothing beyond reading the public fields.

import type { Resource } from './resources.ts';

export function isPublic(resource: Resource): boolean {
  switch (resource.kind) {
    case 'showroom':
      return resource.status === 'active' && resource.ownerActive;
    case 'showroom_car':
      return !resource.deleted && resource.showroomStatus === 'active' && resource.ownerActive;
    case 'member_car':
      return !resource.deleted && resource.status === 'active' && resource.ownerActive;
    case 'user':
    case 'favorite':
    case 'dealer_directory':
      return false; // never public
  }
}

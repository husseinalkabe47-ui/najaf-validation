// Authorization core (Phase 11.5, Step 5.1): WHAT is being accessed.
//
// A Resource describes a row that the SERVER loaded from the database. Its owner and state fields must come from that row, never from
// the request body, query or headers. The factories below are the single place where a database row becomes a Resource; they refuse
// malformed ids so that a client-controlled value cannot sneak in as an owner.

import { isValidId } from './actor.ts';

export type Resource = UserResource | ShowroomResource | ShowroomCarResource | MemberCarResource | FavoriteResource | DealerDirectoryResource;

export interface UserResource {
  readonly kind: 'user';
  readonly id: string;
}
export interface ShowroomResource {
  readonly kind: 'showroom';
  readonly ownerId: string;
  readonly status: string;
  /** The owner account is active and not deleted (the same condition as the public_showrooms view). */
  readonly ownerActive: boolean;
}
/** A car that belongs to a showroom; ownership is the showroom's owner. */
export interface ShowroomCarResource {
  readonly kind: 'showroom_car';
  readonly showroomOwnerId: string;
  readonly showroomStatus: string;
  readonly ownerActive: boolean;
  readonly deleted: boolean;
}
export interface MemberCarResource {
  readonly kind: 'member_car';
  readonly ownerId: string;
  readonly status: string;
  readonly ownerActive: boolean;
  readonly deleted: boolean;
}
/** The administrators' list of dealer accounts and applications (Step 5.2): a collection, so it has no owner. */
export interface DealerDirectoryResource {
  readonly kind: 'dealer_directory';
}
/** A favorite belongs to ONE user and is never visible to anyone else. */
export interface FavoriteResource {
  readonly kind: 'favorite';
  readonly userId: string;
}

function id(value: unknown, what: string): string {
  if (!isValidId(value)) throw new TypeError(`invalid ${what}`);
  return value;
}
function str(value: unknown, what: string): string {
  if (typeof value !== 'string') throw new TypeError(`invalid ${what}`);
  return value;
}

export const userResource = (row: { id: string }): UserResource => Object.freeze({ kind: 'user', id: id(row.id, 'user id') });

export const showroomResource = (row: { ownerId: string; status: string; ownerActive: boolean }): ShowroomResource =>
  Object.freeze({ kind: 'showroom', ownerId: id(row.ownerId, 'owner id'), status: str(row.status, 'status'), ownerActive: row.ownerActive === true });

export const showroomCarResource = (row: { showroomOwnerId: string; showroomStatus: string; ownerActive: boolean; deleted: boolean }): ShowroomCarResource =>
  Object.freeze({
    kind: 'showroom_car',
    showroomOwnerId: id(row.showroomOwnerId, 'showroom owner id'),
    showroomStatus: str(row.showroomStatus, 'showroom status'),
    ownerActive: row.ownerActive === true,
    deleted: row.deleted === true,
  });

export const memberCarResource = (row: { ownerId: string; status: string; ownerActive: boolean; deleted: boolean }): MemberCarResource =>
  Object.freeze({ kind: 'member_car', ownerId: id(row.ownerId, 'owner id'), status: str(row.status, 'status'), ownerActive: row.ownerActive === true, deleted: row.deleted === true });

export const dealerDirectoryResource = (): DealerDirectoryResource => Object.freeze({ kind: 'dealer_directory' });

export const favoriteResource = (row: { userId: string }): FavoriteResource => Object.freeze({ kind: 'favorite', userId: id(row.userId, 'user id') });

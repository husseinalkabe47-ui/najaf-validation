// Authorization core (Phase 11.5, Step 5.1): WHO is calling.
//
// An Actor is built ONLY from the account row that the authentication service re-read from the database for a verified access token
// (role and status are never in the token and never in the request). It carries the minimum the policy needs: id and role.
// Every other state (suspended, pending, deleted, unknown role, malformed id) yields NO actor: the caller is then treated exactly like a
// guest, and the policy fails closed.

export type ActorRole = 'member' | 'dealer' | 'admin';

export interface Actor {
  readonly id: string;
  readonly role: ActorRole;
}

/** What is needed to decide whether an account may act. Shaped after PublicUser; `deletedAt`/`deleted` are optional extra signals. */
export interface ActorSource {
  id: string;
  role: string;
  status: string;
  deletedAt?: Date | string | null | undefined;
  deleted?: boolean | undefined;
}

// users.role uses 'user' for an ordinary member; the policy speaks 'member'. Anything else (including inherited keys) is unknown.
const ROLE_BY_DB_ROLE: Readonly<Record<string, ActorRole>> = Object.freeze({ user: 'member', dealer: 'dealer', admin: 'admin' });

/** bigint identity as a decimal string: no sign, no leading zero, no exponent, no whitespace. */
export const ID_PATTERN = /^[1-9][0-9]{0,18}$/;

export function isValidId(value: unknown): value is string {
  return typeof value === 'string' && ID_PATTERN.test(value);
}

/**
 * Only an ACTIVE, NOT-DELETED account with a known role and a well-formed id acts. suspended, pending and deleted accounts never do
 * (a pending dealer has no dealer powers until an administrator approves it).
 */
export function toActor(source: ActorSource | null | undefined): Actor | null {
  if (!source || typeof source !== 'object') return null;
  if (!isValidId(source.id)) return null;
  if (source.status !== 'active') return null;
  if (source.deleted === true) return null;
  if (source.deletedAt !== undefined && source.deletedAt !== null) return null;
  const role = typeof source.role === 'string' && Object.hasOwn(ROLE_BY_DB_ROLE, source.role) ? ROLE_BY_DB_ROLE[source.role] : undefined;
  if (!role) return null;
  return Object.freeze({ id: source.id, role });
}

/** The slice of the authentication service the actor loader needs. */
export interface ActorAuthenticator {
  authenticate(accessToken: string | undefined): Promise<{ user: ActorSource } | null>;
}

/**
 * The ONLY way a request becomes an Actor: verify the access token, re-read the session and the account from the database (role and
 * status as they are NOW), then apply the account-state rules. Returns null for a guest or for any account that may not act.
 */
export async function loadActor(auth: ActorAuthenticator, accessToken: string | undefined): Promise<Actor | null> {
  const found = await auth.authenticate(accessToken);
  return found ? toActor(found.user) : null;
}

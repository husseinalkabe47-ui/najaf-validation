// Authorization core (Phase 11.5, Step 5.1): turns a policy decision into the HTTP-safe outcome (non-disclosure).
//
// Rules (architecture §9):
//
//  - 403 `forbidden` is used only where the caller may already know the resource exists (they can READ it) but may not do this action;
//  - no actor on an action that needs one is 401 `unauthorized`, but only when the resource is not public.

import type { Actor } from './actor.ts';
import { can, type Action } from './policy.ts';
import { isPublic } from './public.ts';
import type { Resource } from './resources.ts';

export type AuthzErrorCode = 'not_found' | 'forbidden' | 'unauthorized';

const MESSAGES: Record<AuthzErrorCode, string> = {
  not_found: 'Not found',
  forbidden: 'Not allowed',
  unauthorized: 'Authentication required',
};
const STATUS: Record<AuthzErrorCode, number> = { not_found: 404, forbidden: 403, unauthorized: 401 };

export class AuthzError extends Error {
  readonly code: AuthzErrorCode;
  constructor(code: AuthzErrorCode) {
    super(MESSAGES[code]);
    this.name = 'AuthzError';
    this.code = code;
  }
}

export interface AuthzHttpError {
  status: number;
  code: AuthzErrorCode;
  message: string;
}

export function toAuthzHttp(e: unknown): AuthzHttpError | undefined {
  if (!(e instanceof AuthzError)) return undefined;
  return { status: STATUS[e.code], code: e.code, message: e.message };
}

/** Thrown for a resource that does not exist. Identical to the denial of a private resource, on purpose. */
export const notFound = (): AuthzError => new AuthzError('not_found');

/**
 * Use for any PRIVATE read/modify of a resource the server has loaded (public visibility is NOT considered here; see authorizeRead).
 *  - allowed                               → returns
 *  - denied, but the caller can read it    → forbidden (403): the resource is visible to them, the action is not allowed
 *  - denied, and the caller cannot read it → not_found (404): its existence is not disclosed (also for a guest or a non-acting account)
 */
export function authorize(actor: Actor | null, action: Action, resource: Resource | null | undefined): void {
  if (!resource) throw notFound();
  if (can(actor, action, resource)) return;
  throw new AuthzError(can(actor, 'read', resource) ? 'forbidden' : 'not_found');
}

/**
 * Use for reading a resource that has a PUBLIC face. A public resource is readable by anyone (guest included); a private one only by
 * whoever the policy allows, and a stranger gets 404. Reading the public fields grants nothing else.
 */
export function authorizeRead(actor: Actor | null, resource: Resource | null | undefined): void {
  if (!resource) throw notFound();
  if (isPublic(resource) || can(actor, 'read', resource)) return;
  throw notFound();
}

/** Narrow helper for routes that need an authenticated actor at all (no resource yet): guest → 401. */
export function requireActor(actor: Actor | null): Actor {
  if (!actor) throw new AuthzError('unauthorized');
  return actor;
}

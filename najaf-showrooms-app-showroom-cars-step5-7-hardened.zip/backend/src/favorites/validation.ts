// Input validation for a member's favorites (Phase 11.5, Step 5.6).
//
// Client input is only: the car to favorite ({carId}), the list paging (limit, before) and the car id in the DELETE path. The user is
// never an input. Strict whitelists: unknown fields are rejected, ids are canonical positive decimal strings that fit bigint. Error
// objects carry a field name and a machine code only, never the submitted value.
import type { FieldError, Parsed } from '../auth/validation.ts';
import { CATALOG_LIMIT_DEFAULT, CATALOG_LIMIT_MAX, isBigintId } from '../catalog/params.ts';

const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

function unknownFields(o: Record<string, unknown>, allowed: readonly string[]): FieldError[] {
  return Object.keys(o).filter((k) => !allowed.includes(k)).map((k) => ({ field: SAFE_FIELD.test(k) ? k : 'unknown', code: 'unknown_field' }));
}

/** A path/body id: a canonical positive id that fits bigint, else null. */
export function parseFavoriteCarId(raw: unknown): string | null {
  return typeof raw === 'string' && isBigintId(raw) ? raw : null;
}

export interface AddFavoriteInput {
  carId: string;
}
export function parseAddFavoriteInput(body: unknown): Parsed<AddFavoriteInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors = unknownFields(body, ['carId']);
  const raw = body['carId'];
  let carId: string | undefined;
  if (raw === undefined || raw === null) errors.push({ field: 'carId', code: 'required' });
  else if (typeof raw !== 'string') errors.push({ field: 'carId', code: 'invalid_type' });
  else if (!isBigintId(raw)) errors.push({ field: 'carId', code: 'invalid_format' });
  else carId = raw;
  if (errors.length > 0 || carId === undefined) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { carId } };
}

export interface ListFavoritesQuery {
  limit: number;
  /** Keyset cursor: return favorites strictly older than this cursor. null = first page. */
  before: string | null;
}
export function parseListFavoritesQuery(query: unknown): Parsed<ListFavoritesQuery> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const errors = unknownFields(q, ['limit', 'before']);
  let limit = CATALOG_LIMIT_DEFAULT;
  const l = q['limit'];
  if (l !== undefined) {
    if (typeof l !== 'string') errors.push({ field: 'limit', code: 'invalid_type' });
    else if (!/^[1-9][0-9]{0,2}$/.test(l) || Number(l) > CATALOG_LIMIT_MAX) errors.push({ field: 'limit', code: 'invalid_format' });
    else limit = Number(l);
  }
  let before: string | null = null;
  const b = q['before'];
  if (b !== undefined) {
    if (typeof b !== 'string') errors.push({ field: 'before', code: 'invalid_type' });
    else if (!isBigintId(b)) errors.push({ field: 'before', code: 'invalid_format' });
    else before = b;
  }
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { limit, before } };
}

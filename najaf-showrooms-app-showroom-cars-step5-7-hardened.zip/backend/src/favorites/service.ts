// A member's OWN favorites (Phase 11.5, Step 5.6): add, list, remove.
//
// Decisions (each is covered by tests):
//  - WHO acts is an Actor from src/authz. The user of a favorite is ALWAYS the actor's id; no input names a user. The existing
//    'favorite' policy (strictly the owner, not even an administrator) must allow the action. An authenticated account that may not
//    act (pending dealer) gets 403 on the collection and 404 on the item, as in Step 5.4.
//  - Only PUBLICLY VISIBLE cars can be favorited: visibility is the view public_cars (showroom car in a public showroom, or active
//    member car of an active owner, not deleted). An unknown, deleted, hidden, pending or malformed car is the same 404.
//  - The list returns only favorites whose car is public NOW. A car that was deleted, suspended or hidden disappears from the list
//    (soft delete also removes the favorite, by the existing database trigger); nothing about it is exposed.
//  - Duplicates are safe: adding a car that is already a favorite is not an error and not a second row (the UNIQUE constraint decides,
//    also under concurrency). It answers 200 with the existing favorite; a new favorite answers 201.
//  - Remove is IDEMPOTENT: 204 whether or not the favorite existed, and it works on a car that is no longer public (the user can
//    always clean up their own list). It only ever touches rows of the actor. A malformed car id is 404 (project convention).
//  - Audit rows (favorite.add / favorite.remove, numbers only) are written in the same transaction, and only when something changed.
//  - Paging: keyset on the favorites id, newest first; `nextBefore` is an opaque cursor, not a car id.
import { authorize, favoriteResource, notFound, AuthzError } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError } from '../auth/validation.ts';
import { toPublicCar } from '../catalog/service.ts';
import type { PublicCar } from '../catalog/service.ts';
import type { FavoriteRow, FavoriteStore } from './repository.ts';
import { parseAddFavoriteInput, parseFavoriteCarId, parseListFavoritesQuery } from './validation.ts';

export type FavoriteErrorCode = 'validation_failed';
export class FavoriteError extends Error {
  readonly code: FavoriteErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: FavoriteErrorCode, fields?: FieldError[]) {
    super('The submitted data is not valid');
    this.name = 'FavoriteError';
    this.code = code;
    this.fields = fields;
  }
}

export interface OwnFavorite {
  carId: string;
  createdAt: string;
}
export interface FavoriteListItem {
  car: PublicCar;
  favoritedAt: string;
}
export interface FavoritePage {
  items: FavoriteListItem[];
  /** Opaque cursor: pass as `before` for the next page; null when this page was the last one. */
  nextBefore: string | null;
}
export interface RequestContext {
  requestId?: string | undefined;
}

export interface FavoriteApi {
  add(actor: Actor | null, body: unknown, ctx?: RequestContext): Promise<{ favorite: OwnFavorite; created: boolean }>;
  list(actor: Actor | null, query: unknown): Promise<FavoritePage>;
  remove(actor: Actor | null, rawCarId: unknown, ctx?: RequestContext): Promise<void>;
}

const toOwnFavorite = (r: FavoriteRow): OwnFavorite => ({ carId: r.carId, createdAt: r.createdAt.toISOString() });

/** users.role vocabulary for the audit table (the policy says 'member', the table says 'user'). */
const auditRole = (a: Actor): string => (a.role === 'member' ? 'user' : a.role);

export function createFavoriteService(deps: { store: FavoriteStore }): FavoriteApi {
  const { store } = deps;

  return {
    async add(actor, body, ctx = {}) {
      // No item exists yet for a collection call: an account that may not act is 403.
      if (!actor) throw new AuthzError('forbidden');
      const parsed = parseAddFavoriteInput(body);
      if (!parsed.ok) throw new FavoriteError('validation_failed', parsed.errors);
      authorize(actor, 'update', favoriteResource({ userId: actor.id }));
      const { carId } = parsed.value;
      return store.transaction(async ({ favorites, audit }) => {
        if (!(await favorites.lockActingUser(actor.id))) throw notFound();
        if (!(await favorites.lockLiveCar(carId))) throw notFound();
        const inserted = await favorites.insertIfPublic(actor.id, carId);
        if (inserted) {
          await audit.record({ action: 'favorite.add', actorUserId: actor.id, actorRole: auditRole(actor), entityType: 'car', entityId: carId, afterData: { carId: Number(carId) }, requestId: ctx.requestId });
          return { favorite: toOwnFavorite(inserted), created: true };
        }
        // Not inserted: either it already exists (a duplicate: fine) or the car is not public (404, like an unknown car).
        const existing = await favorites.findPublic(actor.id, carId);
        if (!existing) throw notFound();
        return { favorite: toOwnFavorite(existing), created: false };
      });
    },

    async list(actor, query) {
      if (!actor) throw new AuthzError('forbidden');
      const parsed = parseListFavoritesQuery(query);
      if (!parsed.ok) throw new FavoriteError('validation_failed', parsed.errors);
      authorize(actor, 'read', favoriteResource({ userId: actor.id }));
      const rows = await store.favorites.list(actor.id, parsed.value);
      const last = rows.length === parsed.value.limit ? rows[rows.length - 1] : undefined;
      return { items: rows.map((r) => ({ car: toPublicCar(r.car), favoritedAt: r.favoritedAt.toISOString() })), nextBefore: last ? last.cursor : null };
    },

    async remove(actor, rawCarId, ctx = {}) {
      const carId = parseFavoriteCarId(rawCarId);
      if (!actor || carId === null) throw notFound();
      authorize(actor, 'delete', favoriteResource({ userId: actor.id }));
      await store.transaction(async ({ favorites, audit }) => {
        if (!(await favorites.lockActingUser(actor.id))) throw notFound();
        // Scoped by the actor: it can only ever remove the actor's own favorite. Absent = already removed = still 204.
        if (await favorites.remove(actor.id, carId)) {
          await audit.record({ action: 'favorite.remove', actorUserId: actor.id, actorRole: auditRole(actor), entityType: 'car', entityId: carId, afterData: { carId: Number(carId) }, requestId: ctx.requestId });
        }
      });
    },
  };
}

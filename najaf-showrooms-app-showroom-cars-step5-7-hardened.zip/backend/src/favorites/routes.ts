// HTTP contract for a member's OWN favorites (Phase 11.5, Step 5.6). Thin: decisions live in favorites/service.ts and src/authz.
// Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   POST   /v1/me/favorites            Bearer, JSON {carId}            -> 201 {favorite} new, 200 {favorite} already a favorite
//   GET    /v1/me/favorites?limit=&before=   Bearer                    -> 200 {items: [{car, favoritedAt}], nextBefore}
//   DELETE /v1/me/favorites/:carId     Bearer, no body                 -> 204 (idempotent: also when it was not a favorite)
//
// Errors: 401 no/invalid token; 403 add/list for an account that may not act; 404 for a car that is not public (unknown, deleted,
// hidden, pending: all identical) and for a malformed id; 400 invalid input (field names and codes only); 415 non-JSON body.
// The user is the verified token's account, never a request field.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { FavoriteError } from './service.ts';
import type { FavoriteApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same in-process limiter as the other routes). */
export const FAVORITE_RATE_LIMITS = {
  write: { limit: 120, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type FavoriteRateLimitedRoute = keyof typeof FAVORITE_RATE_LIMITS;

/** Maps every error this layer may see to the project's HTTP contract; undefined = not ours (the global handler maps it). */
export function toFavoriteHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof FavoriteError) return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function favoriteRateLimitHook(limiter: RateLimiter, route: FavoriteRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`favorites.${route}:${request.ip}`, FAVORITE_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'favorites.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** DELETE carries no body: the target is in the path. */
function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  throw new FavoriteError('validation_failed', [{ field: 'body', code: 'invalid_type' }]);
}

export function registerFavoriteRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; favorites: FavoriteApi; rateLimiter?: RateLimiter }): void {
  const { auth, favorites, rateLimiter } = deps;
  const limited = (route: FavoriteRateLimitedRoute): Hook[] => (rateLimiter ? [favoriteRateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toFavoriteHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling" (and so of whose favorites): the verified access token, re-read from the database, then the
  // account-state rules. No/invalid token -> 401. An authenticated account that may not act (pending dealer) -> null actor.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  app.post('/v1/me/favorites', { bodyLimit: 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const { favorite, created } = await favorites.add(actor, request.body, { requestId: request.id });
      return reply.code(created ? 201 : 200).send({ favorite });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/me/favorites', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await favorites.list(actor, request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.delete('/v1/me/favorites/:carId', { bodyLimit: 1024, onRequest: limited('write') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      assertNoBody(request.body);
      await favorites.remove(actor, (request.params as Record<string, unknown> | undefined)?.['carId'], { requestId: request.id });
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

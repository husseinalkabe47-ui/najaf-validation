// PostgreSQL access for a member's OWN favorites (Phase 11.5, Step 5.6). Rules, as in the other repositories:
//  - every statement is parameterized and scoped by `user_id = <the verified actor's id>`: another user's favorite is simply not found;
//  - PUBLIC VISIBILITY is decided by the existing view public_cars, never re-implemented here: a favorite is created only from a row
//    of public_cars, and listed only through a join to public_cars, so a deleted, suspended, pending or hidden car is never returned;
//  - duplicates are decided by the UNIQUE (user_id, car_id) constraint (`ON CONFLICT DO NOTHING`), not by a read-then-write;
//  - the car row is locked FOR SHARE while a favorite is added, so the soft-delete trigger (which removes a car's favorites) cannot
//    miss a favorite inserted at the same moment;
//  - only privileges of migrations 0012/0013 are used: SELECT/INSERT/DELETE on favorites (no UPDATE exists). Nothing here writes
//    cars, users or any other table;
//  - no SELECT *: owner_id, reviewer data and search_text are never read (the view does not expose them either).
// Audit rows reuse the single audit writer of auth/repository.ts (inside the same transaction).
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';
import type { PublicCarRow } from '../catalog/repository.ts';

export interface FavoriteRow {
  carId: string;
  createdAt: Date;
}
export interface FavoriteListRow {
  /** The favorites row id: the paging cursor only, never exposed as data. */
  cursor: string;
  favoritedAt: Date;
  car: PublicCarRow;
}

export interface FavoriteRepository {
  /** Re-checks INSIDE the transaction that the acting account is still active and not deleted, and SHARE-locks it to commit. */
  lockActingUser(userId: string): Promise<boolean>;
  /** Locks a car that is not deleted FOR SHARE (false for an unknown or deleted car). */
  lockLiveCar(carId: string): Promise<boolean>;
  /** Adds the favorite if the car is in public_cars. null = not inserted (not public, or it already exists). */
  insertIfPublic(userId: string, carId: string): Promise<FavoriteRow | null>;
  /** The user's existing favorite of a car that is still public; null otherwise. */
  findPublic(userId: string, carId: string): Promise<FavoriteRow | null>;
  /** Removes the user's favorite of that car (whatever the car's state now). false = there was none. */
  remove(userId: string, carId: string): Promise<boolean>;
  /** The user's favorites whose car is still public, newest first (keyset on the favorites id). */
  list(userId: string, q: { limit: number; before: string | null }): Promise<FavoriteListRow[]>;
}

export interface FavoriteStore {
  /** Autocommit reads. */
  favorites: FavoriteRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { favorites: FavoriteRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

const CAR_COLUMNS = `pc.id, pc.source_type, pc.showroom_id, pc.brand, pc.model, pc.year, pc.price, pc.currency, pc.mileage,
       pc.transmission, pc.fuel_type, pc.color, pc.description, pc.status, pc.phone, pc.whatsapp, pc.location, pc.latitude,
       pc.longitude, pc.owner_name, pc.created_at, pc.updated_at`;

/** SQL builders, exported so tests can pin their text (and run it on a real database). */
export const LOCK_ACTING_USER_SQL = `SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`;
export const LOCK_LIVE_CAR_SQL = `SELECT id FROM cars WHERE id = $1::bigint AND deleted_at IS NULL FOR SHARE`;

export function buildInsertIfPublic(userId: string, carId: string): { text: string; values: unknown[] } {
  return {
    text: `INSERT INTO favorites (user_id, car_id)
           SELECT $1::bigint, pc.id FROM public_cars pc WHERE pc.id = $2::bigint
           ON CONFLICT (user_id, car_id) DO NOTHING
           RETURNING car_id, created_at`,
    values: [userId, carId],
  };
}

export function buildFindPublic(userId: string, carId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT f.car_id, f.created_at FROM favorites f JOIN public_cars pc ON pc.id = f.car_id
            WHERE f.user_id = $1::bigint AND f.car_id = $2::bigint`,
    values: [userId, carId],
  };
}

export function buildRemove(userId: string, carId: string): { text: string; values: unknown[] } {
  return { text: `DELETE FROM favorites WHERE user_id = $1::bigint AND car_id = $2::bigint`, values: [userId, carId] };
}

export function buildList(userId: string, q: { limit: number; before: string | null }): { text: string; values: unknown[] } {
  const values: unknown[] = [userId];
  let before = '';
  if (q.before !== null) {
    values.push(q.before);
    before = ` AND f.id < $${values.length}::bigint`;
  }
  values.push(q.limit);
  return {
    text: `SELECT f.id AS favorite_cursor, f.created_at AS favorited_at, ${CAR_COLUMNS}
             FROM favorites f JOIN public_cars pc ON pc.id = f.car_id
            WHERE f.user_id = $1::bigint${before}
            ORDER BY f.id DESC LIMIT $${values.length}`,
    values,
  };
}

type ListSqlRow = PublicCarRow & { favorite_cursor: string; favorited_at: Date };

export function createPgFavoriteRepository(q: Tx): FavoriteRepository {
  const toFavorite = (r: { car_id: string; created_at: Date } | undefined): FavoriteRow | null => (r ? { carId: String(r.car_id), createdAt: r.created_at } : null);
  return {
    async lockActingUser(userId) {
      return (await q.query(LOCK_ACTING_USER_SQL, [userId])).rows.length === 1;
    },
    async lockLiveCar(carId) {
      return (await q.query(LOCK_LIVE_CAR_SQL, [carId])).rows.length === 1;
    },
    async insertIfPublic(userId, carId) {
      const s = buildInsertIfPublic(userId, carId);
      return toFavorite((await q.query<{ car_id: string; created_at: Date }>(s.text, s.values)).rows[0]);
    },
    async findPublic(userId, carId) {
      const s = buildFindPublic(userId, carId);
      return toFavorite((await q.query<{ car_id: string; created_at: Date }>(s.text, s.values)).rows[0]);
    },
    async remove(userId, carId) {
      const s = buildRemove(userId, carId);
      return ((await q.query(s.text, s.values)).rowCount ?? 0) > 0;
    },
    async list(userId, query) {
      const s = buildList(userId, query);
      const rows = (await q.query<ListSqlRow>(s.text, s.values)).rows;
      return rows.map((r) => ({ cursor: String(r.favorite_cursor), favoritedAt: r.favorited_at, car: r }));
    },
  };
}

export function createPgFavoriteStore(db: Db): FavoriteStore {
  return {
    favorites: createPgFavoriteRepository(db),
    transaction: (fn) => db.tx((t) => fn({ favorites: createPgFavoriteRepository(t), audit: createPgAuditRepository(t) })),
  };
}

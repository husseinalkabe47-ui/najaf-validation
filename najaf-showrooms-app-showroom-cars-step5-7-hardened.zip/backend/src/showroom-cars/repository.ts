// PostgreSQL access for showroom cars (Phase 11.5, Step 5.7). Rules, as in the other repositories:
//  - every statement is parameterized; source_type and every status a statement WRITES or requires are SQL literals or whitelisted;
//  - the dealer's showroom is found ONLY by `showrooms.owner_id = <the verified actor's id>` (one showroom per dealer, UNIQUE
//    owner_id; the application role cannot change owner_id, migration 0013). Its id is never taken from the request;
//  - EVERY dealer statement on cars is scoped by `showroom_id = <that showroom>` AND `source_type = 'showroom'` AND not deleted,
//    so a car of another showroom, a member ad or a deleted car is simply not found, whatever id is asked for;
//  - the administrator's statements read any showroom car that is not deleted, and WRITE ONLY `status` (plus nothing else);
//  - only columns the application role may write (migration 0013); the member-only columns (phone, WhatsApp, location,
//    coordinates, reasons, reviewer) are never written for a showroom car (cars_member_only_fields), version and updated_at are
//    owned by the touch_versioned trigger;
//  - the SET list of an update comes from a FIXED field -> column map below, never from request keys;
//  - optimistic concurrency: updates, status changes and the soft delete are compare-and-swap on `version`;
//  - no SELECT *: each query names its columns; search_text is never returned.
// Audit rows reuse the single audit writer of auth/repository.ts (inside the same transaction).
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';
import type { ShowroomCarField, ShowroomCarFields, ShowroomCarStatus } from './validation.ts';

export interface OwnShowroomRow {
  id: string;
  ownerId: string;
  status: string;
}

export interface ShowroomCarRow {
  id: string;
  showroomId: string;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  status: string;
  version: number;
  createdAt: Date;
  updatedAt: Date;
}

/** A showroom car as the administrator's moderation needs it: the car plus what the policy's resource is built from. */
export interface ModeratedCarRow extends ShowroomCarRow {
  showroomOwnerId: string;
  showroomStatus: string;
  ownerActive: boolean;
}

export interface ShowroomCarRepository {
  /** Re-checks INSIDE the transaction that the acting account is still active and not deleted, and SHARE-locks it to commit. */
  lockActingUser(userId: string): Promise<boolean>;
  /** The showroom owned by this account (at most one), whatever its status; null if none. */
  findShowroomOfOwner(ownerId: string): Promise<OwnShowroomRow | null>;
  /** Creates the car in this showroom, ALWAYS 'available' (the existing rule: no per-car approval, no rewarded ad). */
  insert(showroomId: string, fields: ShowroomCarFields, searchText: string): Promise<ShowroomCarRow>;
  /** This showroom's cars that are not deleted, newest id first (keyset on id). */
  listOwn(showroomId: string, q: { limit: number; before: string | null; status: ShowroomCarStatus | null }): Promise<ShowroomCarRow[]>;
  /** One car of this showroom that is not deleted; null for anything else. `lock` = FOR UPDATE until the end of the transaction. */
  findOwn(id: string, showroomId: string, lock: boolean): Promise<ShowroomCarRow | null>;
  /** Compare-and-swap update of the given fields (and status). null = not at `expectedVersion`: nothing was changed. */
  update(input: { id: string; showroomId: string; expectedVersion: number; changes: Partial<ShowroomCarFields>; status: ShowroomCarStatus | null; searchText: string }): Promise<ShowroomCarRow | null>;
  /** Compare-and-swap soft delete (deleted_at = now()). false = not at `expectedVersion` (or already deleted / not this showroom's). */
  softDelete(input: { id: string; showroomId: string; expectedVersion: number }): Promise<boolean>;
  /** ADMIN: any showroom car that is not deleted, locked FOR UPDATE, with its showroom's owner and state; null otherwise. */
  lockForModeration(id: string): Promise<ModeratedCarRow | null>;
  /** ADMIN: compare-and-swap of `status` only. null = not at `expectedVersion`. */
  setStatus(input: { id: string; expectedVersion: number; status: ShowroomCarStatus }): Promise<ShowroomCarRow | null>;
}

export interface ShowroomCarStore {
  /** Autocommit reads. */
  cars: ShowroomCarRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { cars: ShowroomCarRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

/** The ONLY mapping from an input field to a column. A key that is not here can never reach SQL. */
export const COLUMN_OF: Readonly<Record<ShowroomCarField, string>> = Object.freeze({
  brand: 'brand',
  model: 'model',
  year: 'year',
  price: 'price',
  currency: 'currency',
  mileage: 'mileage',
  transmission: 'transmission',
  fuelType: 'fuel_type',
  color: 'color',
  description: 'description',
});
const STATUS_SQL: Readonly<Record<ShowroomCarStatus, string>> = Object.freeze({ available: `'available'`, sold: `'sold'` });

const CAR_COLUMNS = `c.id, c.showroom_id, c.brand, c.model, c.year, c.price, c.currency, c.mileage, c.transmission, c.fuel_type, c.color,
       c.description, c.status, c.version, c.created_at, c.updated_at`;
const OWN = `c.showroom_id = $2::bigint AND c.source_type = 'showroom' AND c.deleted_at IS NULL`;

interface SqlRow {
  id: string;
  showroom_id: string;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuel_type: string;
  color: string;
  description: string;
  status: string;
  version: number;
  created_at: Date;
  updated_at: Date;
}

const toRow = (r: SqlRow): ShowroomCarRow => ({
  id: String(r.id),
  showroomId: String(r.showroom_id),
  brand: r.brand,
  model: r.model,
  year: Number(r.year),
  price: String(r.price),
  currency: r.currency,
  mileage: r.mileage === null ? null : Number(r.mileage),
  transmission: r.transmission,
  fuelType: r.fuel_type,
  color: r.color,
  description: r.description,
  status: r.status,
  version: Number(r.version),
  createdAt: r.created_at,
  updatedAt: r.updated_at,
});

/** SQL builders, exported so tests can pin their text (and run it on a real database). */
export const LOCK_ACTING_USER_SQL = `SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`;
export const FIND_SHOWROOM_OF_OWNER_SQL = `SELECT s.id, s.owner_id, s.status FROM showrooms s WHERE s.owner_id = $1::bigint`;

export function buildInsert(showroomId: string, f: ShowroomCarFields, searchText: string): { text: string; values: unknown[] } {
  return {
    text: `INSERT INTO cars (source_type, showroom_id, brand, model, year, price, currency, mileage, transmission, fuel_type, color, description,
                       status, search_text)
       VALUES ('showroom', $1::bigint, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'available', $12)
       RETURNING ${CAR_COLUMNS.replace(/c\./g, '')}`,
    values: [showroomId, f.brand, f.model, f.year, f.price, f.currency, f.mileage, f.transmission, f.fuelType, f.color, f.description, searchText],
  };
}

export function buildListOwn(showroomId: string, q: { limit: number; before: string | null; status: ShowroomCarStatus | null }): { text: string; values: unknown[] } {
  const values: unknown[] = [showroomId];
  const where = [`c.showroom_id = $1::bigint`, `c.source_type = 'showroom'`, `c.deleted_at IS NULL`];
  if (q.before !== null) {
    values.push(q.before);
    where.push(`c.id < $${values.length}::bigint`);
  }
  if (q.status !== null) {
    values.push(q.status);
    where.push(`c.status = $${values.length}`);
  }
  values.push(q.limit);
  return { text: `SELECT ${CAR_COLUMNS} FROM cars c WHERE ${where.join(' AND ')} ORDER BY c.id DESC LIMIT $${values.length}`, values };
}

export function buildFindOwn(id: string, showroomId: string, lock: boolean): { text: string; values: unknown[] } {
  return { text: `SELECT ${CAR_COLUMNS} FROM cars c WHERE c.id = $1::bigint AND ${OWN}${lock ? ' FOR UPDATE OF c' : ''}`, values: [id, showroomId] };
}

export function buildUpdate(input: { id: string; showroomId: string; expectedVersion: number; changes: Partial<ShowroomCarFields>; status: ShowroomCarStatus | null; searchText: string }): { text: string; values: unknown[] } {
  const values: unknown[] = [input.id, input.showroomId, input.expectedVersion];
  const set: string[] = [];
  for (const [field, value] of Object.entries(input.changes) as Array<[ShowroomCarField, unknown]>) {
    if (!Object.hasOwn(COLUMN_OF, field)) throw new Error('unknown showroom car field');
    values.push(value);
    set.push(`${COLUMN_OF[field]} = $${values.length}`);
  }
  if (input.status !== null) {
    if (!Object.hasOwn(STATUS_SQL, input.status)) throw new Error('unknown showroom car status');
    set.push(`status = ${STATUS_SQL[input.status]}`);
  }
  values.push(input.searchText);
  set.push(`search_text = $${values.length}`);
  return {
    text: `UPDATE cars c SET ${set.join(', ')}
            WHERE c.id = $1::bigint AND ${OWN} AND c.version = $3
        RETURNING ${CAR_COLUMNS}`,
    values,
  };
}

export function buildSoftDelete(input: { id: string; showroomId: string; expectedVersion: number }): { text: string; values: unknown[] } {
  return { text: `UPDATE cars c SET deleted_at = now() WHERE c.id = $1::bigint AND ${OWN} AND c.version = $3`, values: [input.id, input.showroomId, input.expectedVersion] };
}

export function buildLockForModeration(id: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT ${CAR_COLUMNS}, s.owner_id AS showroom_owner_id, s.status AS showroom_status,
                  (u.status = 'active' AND u.deleted_at IS NULL) AS owner_active
             FROM cars c JOIN showrooms s ON s.id = c.showroom_id JOIN users u ON u.id = s.owner_id
            WHERE c.id = $1::bigint AND c.source_type = 'showroom' AND c.deleted_at IS NULL
              FOR UPDATE OF c`,
    values: [id],
  };
}

export function buildSetStatus(input: { id: string; expectedVersion: number; status: ShowroomCarStatus }): { text: string; values: unknown[] } {
  if (!Object.hasOwn(STATUS_SQL, input.status)) throw new Error('unknown showroom car status');
  return {
    text: `UPDATE cars c SET status = ${STATUS_SQL[input.status]}
            WHERE c.id = $1::bigint AND c.source_type = 'showroom' AND c.deleted_at IS NULL AND c.version = $2
        RETURNING ${CAR_COLUMNS}`,
    values: [input.id, input.expectedVersion],
  };
}

type ModSqlRow = SqlRow & { showroom_owner_id: string; showroom_status: string; owner_active: boolean };

export function createPgShowroomCarRepository(q: Tx): ShowroomCarRepository {
  const run = async <R = SqlRow>(s: { text: string; values: unknown[] }) => q.query<R>(s.text, s.values);
  return {
    async lockActingUser(userId) {
      return (await q.query(LOCK_ACTING_USER_SQL, [userId])).rows.length === 1;
    },
    async findShowroomOfOwner(ownerId) {
      const r = (await q.query<{ id: string; owner_id: string; status: string }>(FIND_SHOWROOM_OF_OWNER_SQL, [ownerId])).rows[0];
      return r ? { id: String(r.id), ownerId: String(r.owner_id), status: r.status } : null;
    },
    async insert(showroomId, fields, searchText) {
      return toRow((await run(buildInsert(showroomId, fields, searchText))).rows[0]!);
    },
    async listOwn(showroomId, query) {
      return (await run(buildListOwn(showroomId, query))).rows.map(toRow);
    },
    async findOwn(id, showroomId, lock) {
      const r = (await run(buildFindOwn(id, showroomId, lock))).rows[0];
      return r ? toRow(r) : null;
    },
    async update(input) {
      const r = (await run(buildUpdate(input))).rows[0];
      return r ? toRow(r) : null;
    },
    async softDelete(input) {
      return ((await run(buildSoftDelete(input))).rowCount ?? 0) === 1;
    },
    async lockForModeration(id) {
      const r = (await run<ModSqlRow>(buildLockForModeration(id))).rows[0];
      return r ? { ...toRow(r), showroomOwnerId: String(r.showroom_owner_id), showroomStatus: r.showroom_status, ownerActive: r.owner_active === true } : null;
    },
    async setStatus(input) {
      const r = (await run(buildSetStatus(input))).rows[0];
      return r ? toRow(r) : null;
    },
  };
}

export function createPgShowroomCarStore(db: Db): ShowroomCarStore {
  return {
    cars: createPgShowroomCarRepository(db),
    transaction: (fn) => db.tx((t) => fn({ cars: createPgShowroomCarRepository(t), audit: createPgAuditRepository(t) })),
  };
}

// Showroom cars (Phase 11.5, Step 5.7): a dealer's own cars (create, list, read, update, soft delete) and the administrator's
// status change.
//
// Decisions (each is covered by tests):
//  - WHO acts is an Actor from src/authz. The dealer area is for an ACTIVE dealer only (a pending dealer has no actor; a suspended
//    one cannot authenticate). Anyone else, an administrator or a member included, gets 404 on every dealer route, as on
//    GET /v1/dealer/showroom (Step 5.2): the dealer area does not exist for them.
//  - The showroom is ALWAYS the one owned by the actor (showrooms.owner_id = actor id). No input carries a showroom, owner, source
//    type, reviewer or member-only field. A dealer without a showroom gets 404.
//  - Ownership is enforced three times: the SQL is scoped by that showroom (another showroom's car, a member ad or a deleted car is
//    not found), the service re-checks row.showroomId === showroom.id, and the existing policy (authorize on a showroomCarResource
//    built from the server-loaded showroom) must allow the action. Anything that is not the dealer's own car is 404.
//  - The existing rule for showroom cars stays: a new car is 'available' immediately (no per-car approval, no rewarded ad). Whether
//    it is PUBLIC is decided, as before, by the public_cars view (the showroom must be public). The existing policy lets the owner
//    manage the cars of a pending or suspended showroom (Step 5.1); this step does not change that.
//  - The dealer may switch a car between 'available' and 'sold' (the only two states of a showroom car).
//  - The administrator may change the STATUS of any showroom car that is not deleted, and nothing else: there is no administrator
//    create, edit or delete route. Non-administrators get 404 before the database is read.
//  - Optimistic concurrency: every write names the `version` the client last saw. Inside ONE transaction the acting account is
//    re-checked and share-locked, the car is locked FOR UPDATE, the version is compared (409 version_conflict), the write is a
//    compare-and-swap on that version, and the audit row is written. All or nothing.
//  - Soft delete only (deleted_at); the existing database trigger removes the car's favorites. A deleted car is 404 everywhere.
import { authorize, notFound, showroomCarResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { AuditEvent } from '../auth/repository.ts';
import type { FieldError } from '../auth/validation.ts';
import { searchTextOf } from '../member-cars/service.ts';
import { parseCarId, parseDeleteQuery } from '../member-cars/validation.ts';
import type { OwnShowroomRow, ShowroomCarRepository, ShowroomCarRow, ShowroomCarStore } from './repository.ts';
import { parseCreateInput, parseListQuery, parseStatusInput, parseUpdateInput } from './validation.ts';
import type { ShowroomCarStatus } from './validation.ts';

export type ShowroomCarErrorCode = 'validation_failed' | 'version_conflict';
const MESSAGES: Record<ShowroomCarErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  version_conflict: 'The car was changed by another request; reload it and try again',
};
export class ShowroomCarError extends Error {
  readonly code: ShowroomCarErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: ShowroomCarErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'ShowroomCarError';
    this.code = code;
    this.fields = fields;
  }
}

/** A showroom car as its dealer (or the moderating administrator) sees it: whitelist, field by field. No search text. */
export interface ShowroomCarView {
  id: string;
  showroomId: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  status: string;
  version: number;
  createdAt: string;
  updatedAt: string;
}
export interface ShowroomCarPage {
  items: ShowroomCarView[];
  nextBefore: string | null;
}
export interface RequestContext {
  requestId?: string | undefined;
}

export interface ShowroomCarApi {
  create(actor: Actor | null, body: unknown, ctx?: RequestContext): Promise<ShowroomCarView>;
  listOwn(actor: Actor | null, query: unknown): Promise<ShowroomCarPage>;
  getOwn(actor: Actor | null, rawId: unknown): Promise<ShowroomCarView>;
  update(actor: Actor | null, rawId: unknown, body: unknown, ctx?: RequestContext): Promise<ShowroomCarView>;
  remove(actor: Actor | null, rawId: unknown, query: unknown, ctx?: RequestContext): Promise<void>;
  /** Administrator only: the status of any showroom car, and nothing else. */
  setStatusAsAdmin(actor: Actor | null, rawId: unknown, body: unknown, ctx?: RequestContext): Promise<ShowroomCarView>;
}

export function toShowroomCarView(r: ShowroomCarRow): ShowroomCarView {
  return {
    id: r.id,
    showroomId: r.showroomId,
    brand: r.brand,
    model: r.model,
    year: r.year,
    price: Number(r.price),
    currency: r.currency,
    mileage: r.mileage,
    transmission: r.transmission,
    fuelType: r.fuelType,
    color: r.color,
    description: r.description,
    status: r.status,
    version: r.version,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

/** The text the public catalog searches, built exactly as for member ads (a showroom car has no location). */
const searchText = (f: { brand: string; model: string; year: number; color: string }): string => searchTextOf({ ...f, location: '' });

/** users.role vocabulary for the audit table. */
const auditRole = (a: Actor): string => (a.role === 'member' ? 'user' : a.role);

function parsed<T>(r: { ok: true; value: T } | { ok: false; errors: FieldError[] }): T {
  if (!r.ok) throw new ShowroomCarError('validation_failed', r.errors);
  return r.value;
}

/** Only an acting dealer has a dealer area. Everyone else: 404 (nothing to disclose, as GET /v1/dealer/showroom). */
function requireDealer(actor: Actor | null): Actor {
  if (!actor || actor.role !== 'dealer') throw notFound();
  return actor;
}

/** The actor's own showroom, found by owner id; 404 if the dealer has none. */
async function ownShowroom(cars: ShowroomCarRepository, actor: Actor): Promise<OwnShowroomRow> {
  const s = await cars.findShowroomOfOwner(actor.id);
  if (!s || s.ownerId !== actor.id) throw notFound();
  return s;
}

/** The single gate for the cars of a showroom: the policy must allow `action` on a car of the actor's (server-loaded) showroom. */
function allowOnShowroom(actor: Actor, showroom: OwnShowroomRow, action: 'read' | 'update' | 'delete'): void {
  authorize(actor, action, showroomCarResource({ showroomOwnerId: showroom.ownerId, showroomStatus: showroom.status, ownerActive: true, deleted: false }));
}

/** A loaded row must be a car of that showroom; anything else is 404. */
function ownCar(actor: Actor, showroom: OwnShowroomRow, row: ShowroomCarRow | null, action: 'read' | 'update' | 'delete'): ShowroomCarRow {
  if (!row || row.showroomId !== showroom.id) throw notFound();
  allowOnShowroom(actor, showroom, action);
  return row;
}

/** Inside a transaction: re-check the acting account, then load its showroom. */
async function lockedDealer(cars: ShowroomCarRepository, actor: Actor): Promise<OwnShowroomRow> {
  if (!(await cars.lockActingUser(actor.id))) throw notFound();
  return ownShowroom(cars, actor);
}

const statusAction = (s: ShowroomCarStatus, admin: boolean): AuditEvent['action'] =>
  admin ? (s === 'sold' ? 'showroom_car.admin_mark_sold' : 'showroom_car.admin_mark_available') : s === 'sold' ? 'showroom_car.mark_sold' : 'showroom_car.mark_available';

export function createShowroomCarService(deps: { store: ShowroomCarStore }): ShowroomCarApi {
  const { store } = deps;

  return {
    async create(actor, body, ctx = {}) {
      const dealer = requireDealer(actor);
      const { fields } = parsed(parseCreateInput(body));
      return store.transaction(async ({ cars, audit }) => {
        const showroom = await lockedDealer(cars, dealer);
        allowOnShowroom(dealer, showroom, 'update');
        const row = await cars.insert(showroom.id, fields, searchText(fields));
        await audit.record({ action: 'showroom_car.create', actorUserId: dealer.id, actorRole: auditRole(dealer), entityType: 'car', entityId: row.id, afterData: { version: row.version }, requestId: ctx.requestId });
        return toShowroomCarView(row);
      });
    },

    async listOwn(actor, query) {
      const dealer = requireDealer(actor);
      const q = parsed(parseListQuery(query));
      const showroom = await ownShowroom(store.cars, dealer);
      allowOnShowroom(dealer, showroom, 'read');
      const rows = await store.cars.listOwn(showroom.id, q);
      // Defense in depth: a row that is not this showroom's never leaves, whatever the query returned.
      const own = rows.filter((r) => r.showroomId === showroom.id);
      const last = rows.length === q.limit ? rows[rows.length - 1] : undefined;
      return { items: own.map(toShowroomCarView), nextBefore: last ? last.id : null };
    },

    async getOwn(actor, rawId) {
      const id = parseCarId(rawId);
      if (id === null) throw notFound();
      const dealer = requireDealer(actor);
      const showroom = await ownShowroom(store.cars, dealer);
      return toShowroomCarView(ownCar(dealer, showroom, await store.cars.findOwn(id, showroom.id, false), 'read'));
    },

    async update(actor, rawId, body, ctx = {}) {
      const id = parseCarId(rawId);
      if (id === null) throw notFound();
      const dealer = requireDealer(actor);
      const input = parsed(parseUpdateInput(body));
      return store.transaction(async ({ cars, audit }) => {
        const showroom = await lockedDealer(cars, dealer);
        const row = ownCar(dealer, showroom, await cars.findOwn(id, showroom.id, true), 'update');
        if (row.version !== input.version) throw new ShowroomCarError('version_conflict');
        const merged = { brand: input.changes.brand ?? row.brand, model: input.changes.model ?? row.model, year: input.changes.year ?? row.year, color: input.changes.color ?? row.color };
        const updated = await cars.update({ id, showroomId: showroom.id, expectedVersion: input.version, changes: input.changes, status: input.status, searchText: searchText(merged) });
        // Under the row lock this cannot happen; if it ever does, nothing was written and the client must reload.
        if (!updated) throw new ShowroomCarError('version_conflict');
        const statusChanged = input.status !== null && input.status !== row.status;
        await audit.record({
          action: statusChanged ? statusAction(input.status!, false) : 'showroom_car.update',
          actorUserId: dealer.id,
          actorRole: auditRole(dealer),
          entityType: 'car',
          entityId: id,
          afterData: { version: updated.version, fields: Object.keys(input.changes).length },
          requestId: ctx.requestId,
        });
        return toShowroomCarView(updated);
      });
    },

    async remove(actor, rawId, query, ctx = {}) {
      const id = parseCarId(rawId);
      if (id === null) throw notFound();
      const dealer = requireDealer(actor);
      const { version } = parsed(parseDeleteQuery(query));
      await store.transaction(async ({ cars, audit }) => {
        const showroom = await lockedDealer(cars, dealer);
        const row = ownCar(dealer, showroom, await cars.findOwn(id, showroom.id, true), 'delete');
        if (row.version !== version) throw new ShowroomCarError('version_conflict');
        if (!(await cars.softDelete({ id, showroomId: showroom.id, expectedVersion: version }))) throw new ShowroomCarError('version_conflict');
        await audit.record({ action: 'showroom_car.delete', actorUserId: dealer.id, actorRole: auditRole(dealer), entityType: 'car', entityId: id, afterData: { version }, requestId: ctx.requestId });
      });
    },

    async setStatusAsAdmin(actor, rawId, body, ctx = {}) {
      const id = parseCarId(rawId);
      // Non-administrators learn nothing (not even whether the id exists): 404 before any read.
      if (id === null || !actor || actor.role !== 'admin') throw notFound();
      const input = parsed(parseStatusInput(body));
      return store.transaction(async ({ cars, audit }) => {
        if (!(await cars.lockActingUser(actor.id))) throw notFound();
        const row = await cars.lockForModeration(id);
        if (!row) throw notFound();
        authorize(actor, 'moderate', showroomCarResource({ showroomOwnerId: row.showroomOwnerId, showroomStatus: row.showroomStatus, ownerActive: row.ownerActive, deleted: false }));
        if (row.version !== input.version) throw new ShowroomCarError('version_conflict');
        // Already in that status: nothing to write, nothing to audit (the version is not bumped).
        if (row.status === input.status) return toShowroomCarView(row);
        const updated = await cars.setStatus({ id, expectedVersion: input.version, status: input.status });
        if (!updated) throw new ShowroomCarError('version_conflict');
        await audit.record({ action: statusAction(input.status, true), actorUserId: actor.id, actorRole: auditRole(actor), entityType: 'car', entityId: id, afterData: { version: updated.version }, requestId: ctx.requestId });
        return toShowroomCarView(updated);
      });
    },
  };
}

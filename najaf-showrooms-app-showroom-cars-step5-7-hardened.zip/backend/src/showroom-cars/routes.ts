// HTTP contract for showroom cars (Phase 11.5, Step 5.7). Thin: decisions live in showroom-cars/service.ts and src/authz.
// Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   POST   /v1/dealer/cars                         Bearer, JSON {brand, model, year, price, currency, ...}  -> 201 {car} ('available')
//   GET    /v1/dealer/cars?limit=&before=&status=  Bearer                                                    -> 200 {items, nextBefore}
//   GET    /v1/dealer/cars/:id                     Bearer                                                    -> 200 {car}
//   PATCH  /v1/dealer/cars/:id                     Bearer, JSON {version, ...changed fields, status?}        -> 200 {car}
//   DELETE /v1/dealer/cars/:id?version=N           Bearer, no body                                           -> 204 (soft delete)
//   PATCH  /v1/admin/showroom-cars/:id/status      Bearer (administrator), JSON {version, status}            -> 200 {car}
//
// Errors: 401 no/invalid token; 404 for anyone who is not an acting dealer with a showroom (dealer routes) or not an administrator
// (admin route), for any car that is not the dealer's own, and for a malformed id (all identical to an unknown id); 400 invalid
// input (field names and codes only); 409 version_conflict; 415 non-JSON body. The showroom is the verified token's account's
// showroom, never a request field.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { ShowroomCarError } from './service.ts';
import type { ShowroomCarApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same in-process limiter as the other routes). */
export const SHOWROOM_CAR_RATE_LIMITS = {
  create: { limit: 60, windowSeconds: 60 * 60 },
  write: { limit: 120, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
  admin: { limit: 120, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type ShowroomCarRateLimitedRoute = keyof typeof SHOWROOM_CAR_RATE_LIMITS;

/** Maps every error this layer may see to the project's HTTP contract; undefined = not ours (the global handler maps it). */
export function toShowroomCarHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof ShowroomCarError) {
    if (e.code === 'validation_failed') return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    return { status: 409, code: e.code, message: e.message };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function rateLimitHook(limiter: RateLimiter, route: ShowroomCarRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`showroomCars.${route}:${request.ip}`, SHOWROOM_CAR_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'showroom_cars.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** DELETE carries no body (the version travels in the query string). */
function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  throw new ShowroomCarError('validation_failed', [{ field: 'body', code: 'invalid_type' }]);
}

export function registerShowroomCarRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; showroomCars: ShowroomCarApi; rateLimiter?: RateLimiter }): void {
  const { auth, showroomCars, rateLimiter } = deps;
  const limited = (route: ShowroomCarRateLimitedRoute): Hook[] => (rateLimiter ? [rateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toShowroomCarHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling" (and so of the showroom): the verified access token, re-read from the database, then the
  // account-state rules. No/invalid token -> 401. An authenticated account that may not act (pending dealer) -> null actor.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };
  const idParam = (request: FastifyRequest): unknown => (request.params as Record<string, unknown> | undefined)?.['id'];
  const ctxOf = (request: FastifyRequest) => ({ requestId: request.id });

  app.post('/v1/dealer/cars', { bodyLimit: 16 * 1024, onRequest: [...limited('create'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await showroomCars.create(actor, request.body, ctxOf(request));
      return reply.code(201).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/dealer/cars', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await showroomCars.listOwn(actor, request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/dealer/cars/:id', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await showroomCars.getOwn(actor, idParam(request));
      return reply.code(200).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.patch('/v1/dealer/cars/:id', { bodyLimit: 16 * 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await showroomCars.update(actor, idParam(request), request.body, ctxOf(request));
      return reply.code(200).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.delete('/v1/dealer/cars/:id', { bodyLimit: 1024, onRequest: limited('write') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      assertNoBody(request.body);
      await showroomCars.remove(actor, idParam(request), request.query, ctxOf(request));
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.patch('/v1/admin/showroom-cars/:id/status', { bodyLimit: 1024, onRequest: [...limited('admin'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await showroomCars.setStatusAsAdmin(actor, idParam(request), request.body, ctxOf(request));
      return reply.code(200).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

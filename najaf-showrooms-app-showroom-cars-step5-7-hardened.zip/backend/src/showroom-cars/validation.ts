// Input validation for showroom cars (Phase 11.5, Step 5.7): a dealer's own cars, and the administrator's status change.
//
// Strict whitelist: unknown fields are rejected; every value is type-, length- and range-checked against the cars table (0005)
// before it can reach SQL. There is no showroom, owner, source type, reviewer, member-only (phone, WhatsApp, location, coordinates,
// reasons), deletion or id field in any input: those are never client-controlled (the member-only columns must stay NULL for a
// showroom car, cars_member_only_fields). Error objects carry a field name and a machine code only, never the submitted value.
//
// Lengths, vocabularies and bounds are imported from the member-car and catalog modules so the three can never drift.
import type { FieldCode, FieldError, Parsed } from '../auth/validation.ts';
import { CURRENCIES, FUEL_TYPES, PRICE_MAX, TRANSMISSIONS, YEAR_MAX, YEAR_MIN, isBigintId } from '../catalog/params.ts';
import { BRAND_MAX, COLOR_MAX, DESCRIPTION_MAX, MILEAGE_MAX, MODEL_MAX } from '../member-cars/validation.ts';

export const SHOWROOM_CAR_LIMIT_DEFAULT = 20;
export const SHOWROOM_CAR_LIMIT_MAX = 50;
/** Every state a showroom car can be in (the table's cars_status_by_source). 'available' is public (while the showroom is). */
export const SHOWROOM_CAR_STATUSES = ['available', 'sold'] as const;
export type ShowroomCarStatus = (typeof SHOWROOM_CAR_STATUSES)[number];

const MAX_ERRORS = 10;
const VERSION_MAX = 2_147_483_647;
const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;
// eslint-disable-next-line no-control-regex
const CONTROL_EXCEPT_NEWLINE = /[\u0000-\u0009\u000b-\u001f\u007f-\u009f\u2028\u2029]/;
const HAS_LETTER_OR_DIGIT = /[\p{L}\p{N}]/u;

/** The fields of a showroom car a dealer writes. Everything else in the row is set by the server. */
export interface ShowroomCarFields {
  brand: string;
  model: string;
  year: number;
  price: number;
  currency: (typeof CURRENCIES)[number];
  mileage: number | null;
  transmission: (typeof TRANSMISSIONS)[number];
  fuelType: (typeof FUEL_TYPES)[number];
  color: string;
  description: string;
}
export type ShowroomCarField = keyof ShowroomCarFields;

export interface CreateInput {
  fields: ShowroomCarFields;
}
export interface UpdateInput {
  /** The version the client last saw (optimistic concurrency). Required. */
  version: number;
  /** Only the fields present in the request. */
  changes: Partial<ShowroomCarFields>;
  status: ShowroomCarStatus | null;
}
export interface ListQuery {
  limit: number;
  before: string | null;
  status: ShowroomCarStatus | null;
}
export interface StatusInput {
  version: number;
  status: ShowroomCarStatus;
}

const FIELD_KEYS: readonly ShowroomCarField[] = ['brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description'];
const UPDATE_KEYS: readonly string[] = [...FIELD_KEYS, 'version', 'status'];
const REQUIRED_ON_CREATE: readonly ShowroomCarField[] = ['brand', 'model', 'year', 'price', 'currency'];

class Errors {
  readonly list: FieldError[] = [];
  add(field: string, code: FieldCode): void {
    this.list.push({ field, code });
  }
  get any(): boolean {
    return this.list.length > 0;
  }
  fail<T>(): Parsed<T> {
    return { ok: false, errors: this.list.slice(0, MAX_ERRORS) };
  }
}

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
const has = (o: Record<string, unknown>, k: string): boolean => Object.hasOwn(o, k);
const chars = (s: string): number => Array.from(s).length;

function rejectUnknown(body: Record<string, unknown>, allowed: readonly string[], e: Errors): void {
  for (const k of Object.keys(body)) if (!allowed.includes(k)) e.add(SAFE_FIELD.test(k) ? k : 'unknown', 'unknown_field');
}

function shortText(e: Errors, field: string, v: unknown, max: number, opts: { min1: boolean; needsWord: boolean }): string | undefined {
  if (typeof v !== 'string') return void e.add(field, 'invalid_type');
  if (CONTROL.test(v)) return void e.add(field, 'invalid_format');
  const t = v.normalize('NFC').replace(/\s+/g, ' ').trim();
  if (opts.min1 && t === '') return void e.add(field, 'required');
  if (chars(t) > max) return void e.add(field, 'too_long');
  if (opts.needsWord && !HAS_LETTER_OR_DIGIT.test(t)) return void e.add(field, 'invalid_format');
  return t;
}

function description(e: Errors, v: unknown): string | undefined {
  if (typeof v !== 'string') return void e.add('description', 'invalid_type');
  const t = v.normalize('NFC').replace(/\r\n/g, '\n').trim();
  if (CONTROL_EXCEPT_NEWLINE.test(t)) return void e.add('description', 'invalid_format');
  if (chars(t) > DESCRIPTION_MAX) return void e.add('description', 'too_long');
  return t;
}

function integer(e: Errors, field: string, v: unknown, min: number, max: number): number | undefined {
  if (typeof v !== 'number') return void e.add(field, 'invalid_type');
  if (!Number.isSafeInteger(v) || v < min || v > max) return void e.add(field, 'invalid_format');
  return v;
}

function oneOf<T extends string>(e: Errors, field: string, v: unknown, allowed: readonly T[]): T | undefined {
  if (typeof v !== 'string') return void e.add(field, 'invalid_type');
  if (!(allowed as readonly string[]).includes(v)) return void e.add(field, 'invalid_format');
  return v as T;
}

function version(e: Errors, body: Record<string, unknown>): number | undefined {
  if (!has(body, 'version') || body['version'] === null) return void e.add('version', 'required');
  return integer(e, 'version', body['version'], 1, VERSION_MAX);
}

function parseFields(body: Record<string, unknown>, e: Errors): Partial<ShowroomCarFields> {
  const out: Partial<ShowroomCarFields> = {};
  if (has(body, 'brand')) {
    const v = shortText(e, 'brand', body['brand'], BRAND_MAX, { min1: true, needsWord: true });
    if (v !== undefined) out.brand = v;
  }
  if (has(body, 'model')) {
    const v = shortText(e, 'model', body['model'], MODEL_MAX, { min1: true, needsWord: true });
    if (v !== undefined) out.model = v;
  }
  if (has(body, 'year')) {
    const v = integer(e, 'year', body['year'], YEAR_MIN, YEAR_MAX);
    if (v !== undefined) out.year = v;
  }
  if (has(body, 'price')) {
    const v = integer(e, 'price', body['price'], 1, PRICE_MAX);
    if (v !== undefined) out.price = v;
  }
  if (has(body, 'currency')) {
    const v = oneOf(e, 'currency', body['currency'], CURRENCIES);
    if (v !== undefined) out.currency = v;
  }
  if (has(body, 'mileage')) {
    if (body['mileage'] === null) out.mileage = null; // unknown (not 0)
    else {
      const v = integer(e, 'mileage', body['mileage'], 0, MILEAGE_MAX);
      if (v !== undefined) out.mileage = v;
    }
  }
  if (has(body, 'transmission')) {
    const v = oneOf(e, 'transmission', body['transmission'], TRANSMISSIONS);
    if (v !== undefined) out.transmission = v;
  }
  if (has(body, 'fuelType')) {
    const v = oneOf(e, 'fuelType', body['fuelType'], FUEL_TYPES);
    if (v !== undefined) out.fuelType = v;
  }
  if (has(body, 'color')) {
    const v = shortText(e, 'color', body['color'], COLOR_MAX, { min1: false, needsWord: false });
    if (v !== undefined) out.color = v;
  }
  if (has(body, 'description')) {
    const v = description(e, body['description']);
    if (v !== undefined) out.description = v;
  }
  return out;
}

export function parseCreateInput(body: unknown): Parsed<CreateInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(body, FIELD_KEYS, e);
  for (const k of REQUIRED_ON_CREATE) if (!has(body, k) || body[k] === null || body[k] === undefined) e.add(k, 'required');
  const p = parseFields(
    Object.fromEntries(Object.entries(body).filter(([k, v]) => (FIELD_KEYS as readonly string[]).includes(k) && !(REQUIRED_ON_CREATE.includes(k as ShowroomCarField) && (v === null || v === undefined)))),
    e,
  );
  if (e.any) return e.fail();
  return {
    ok: true,
    value: {
      fields: {
        brand: p.brand!,
        model: p.model!,
        year: p.year!,
        price: p.price!,
        currency: p.currency!,
        mileage: p.mileage ?? null,
        transmission: p.transmission ?? 'أوتوماتيك',
        fuelType: p.fuelType ?? 'بنزين',
        color: p.color ?? '',
        description: p.description ?? '',
      },
    },
  };
}

export function parseUpdateInput(body: unknown): Parsed<UpdateInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(body, UPDATE_KEYS, e);
  const v = version(e, body);
  for (const k of REQUIRED_ON_CREATE) if (has(body, k) && body[k] === null) e.add(k, 'invalid_type');
  const changes = parseFields(Object.fromEntries(Object.entries(body).filter(([k, val]) => (FIELD_KEYS as readonly string[]).includes(k) && !(REQUIRED_ON_CREATE.includes(k as ShowroomCarField) && val === null))), e);
  let status: ShowroomCarStatus | null = null;
  if (has(body, 'status')) {
    const s = oneOf(e, 'status', body['status'], SHOWROOM_CAR_STATUSES);
    if (s !== undefined) status = s;
  }
  if (!e.any && Object.keys(changes).length === 0 && status === null) e.add('body', 'required');
  if (e.any) return e.fail();
  return { ok: true, value: { version: v!, changes, status } };
}

/** The administrator's ONLY input: the version last seen and the new status. Nothing else about the car can be sent. */
export function parseStatusInput(body: unknown): Parsed<StatusInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(body, ['version', 'status'], e);
  const v = version(e, body);
  let status: ShowroomCarStatus | undefined;
  if (!has(body, 'status') || body['status'] === null) e.add('status', 'required');
  else status = oneOf(e, 'status', body['status'], SHOWROOM_CAR_STATUSES);
  if (e.any) return e.fail();
  return { ok: true, value: { version: v!, status: status! } };
}

export function parseListQuery(query: unknown): Parsed<ListQuery> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(q, ['limit', 'before', 'status'], e);
  let limit = SHOWROOM_CAR_LIMIT_DEFAULT;
  const l = q['limit'];
  if (l !== undefined) {
    if (typeof l !== 'string') e.add('limit', 'invalid_type');
    else if (!/^[1-9][0-9]{0,2}$/.test(l) || Number(l) > SHOWROOM_CAR_LIMIT_MAX) e.add('limit', 'invalid_format');
    else limit = Number(l);
  }
  let before: string | null = null;
  const b = q['before'];
  if (b !== undefined) {
    if (typeof b !== 'string') e.add('before', 'invalid_type');
    else if (!isBigintId(b)) e.add('before', 'invalid_format');
    else before = b;
  }
  let status: ShowroomCarStatus | null = null;
  if (q['status'] !== undefined) {
    const s = oneOf(e, 'status', q['status'], SHOWROOM_CAR_STATUSES);
    if (s !== undefined) status = s;
  }
  if (e.any) return e.fail();
  return { ok: true, value: { limit, before, status } };
}

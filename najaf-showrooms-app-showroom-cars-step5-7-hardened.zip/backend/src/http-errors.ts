// Maps internal errors to HTTP responses. Client-facing messages are generic by design:
// no SQL, constraint names, row values, stack traces, or driver messages ever leave the process.
import { DbError } from './errors.ts';

export interface HttpErrorBody {
  status: number;
  code: string;
  message: string;
}

export function toHttpError(err: unknown): HttpErrorBody {
  if (err instanceof DbError) {
    switch (err.kind) {
      case 'unique':
      case 'foreign_key':
        return { status: 409, code: 'conflict', message: 'The request conflicts with the current state' };
      case 'check':
      case 'not_null':
      case 'invalid_value':
        return { status: 422, code: 'unprocessable', message: 'The request could not be processed' };
      case 'forbidden':
        return { status: 403, code: 'forbidden', message: 'Forbidden' };
      case 'timeout':
      case 'serialization':
      case 'deadlock':
        return { status: 503, code: 'retry_later', message: 'The service is busy, please retry' };
      case 'unavailable':
      case 'auth_failed':
        return { status: 503, code: 'service_unavailable', message: 'Service temporarily unavailable' };
      default:
        return { status: 500, code: 'internal_error', message: 'Internal server error' };
    }
  }
  const status = typeof err === 'object' && err !== null ? (err as { statusCode?: unknown }).statusCode : undefined;
  if (typeof status === 'number' && status >= 400 && status < 500) {
    if (status === 404) return { status, code: 'not_found', message: 'Not found' };
    if (status === 413) return { status, code: 'payload_too_large', message: 'Payload too large' };
    return { status, code: 'bad_request', message: 'Bad request' };
  }
  return { status: 500, code: 'internal_error', message: 'Internal server error' };
}

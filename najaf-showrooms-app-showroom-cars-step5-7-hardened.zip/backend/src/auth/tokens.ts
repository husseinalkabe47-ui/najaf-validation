// Opaque session tokens: 256 random bits, shown to the client once, stored only as SHA-256 (sessions.token_hash, 32 bytes).
import { createHash, randomBytes } from 'node:crypto';
import { SESSION_TOKEN_BYTES } from './policy.ts';

export const TOKEN_PREFIX = 'nsj_';
// 32 bytes -> 43 base64url characters (no padding)
const TOKEN_FORMAT = /^nsj_[A-Za-z0-9_-]{43}$/;

export function generateSessionToken(rand: (bytes: number) => Buffer = randomBytes): string {
  return TOKEN_PREFIX + rand(SESSION_TOKEN_BYTES).toString('base64url');
}

export function isWellFormedToken(value: unknown): value is string {
  return typeof value === 'string' && TOKEN_FORMAT.test(value);
}

export function hashSessionToken(token: string): Buffer {
  return createHash('sha256').update(token, 'utf8').digest();
}

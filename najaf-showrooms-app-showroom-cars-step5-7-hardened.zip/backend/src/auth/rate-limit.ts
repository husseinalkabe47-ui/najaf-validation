// In-process fixed-window rate limiter. No database table (no schema change): limits are per application instance, which
// is stated in the README. Memory is bounded: expired windows are pruned, and past RATE_LIMIT_MAX_KEYS the oldest key is
// evicted (fail-open for the evicted key rather than fail-closed for everyone).
import { RATE_LIMIT_MAX_KEYS } from './policy.ts';

export interface RateRule {
  limit: number;
  windowSeconds: number;
}
export interface RateDecision {
  allowed: boolean;
  remaining: number;
  /** Seconds until the window resets (0 when allowed). */
  retryAfterSeconds: number;
}
export interface RateLimiter {
  /** Counts one request against `key` and says whether it may proceed. */
  consume(key: string, rule: RateRule): RateDecision;
}

export function createMemoryRateLimiter(opts: { now?: () => number; maxKeys?: number } = {}): RateLimiter & { size(): number } {
  const now = opts.now ?? Date.now;
  const maxKeys = opts.maxKeys ?? RATE_LIMIT_MAX_KEYS;
  const windows = new Map<string, { count: number; resetAt: number }>();

  const prune = (t: number): void => {
    for (const [k, w] of windows) if (w.resetAt <= t) windows.delete(k);
  };

  return {
    consume(key, rule) {
      const t = now();
      const current = windows.get(key);
      if (current && current.resetAt > t) {
        current.count += 1;
        if (current.count <= rule.limit) return { allowed: true, remaining: rule.limit - current.count, retryAfterSeconds: 0 };
        return { allowed: false, remaining: 0, retryAfterSeconds: Math.max(1, Math.ceil((current.resetAt - t) / 1000)) };
      }
      windows.delete(key); // an expired window is replaced, and re-inserted last
      if (windows.size >= maxKeys) {
        prune(t);
        while (windows.size >= maxKeys) {
          const oldest = windows.keys().next();
          if (oldest.done) break;
          windows.delete(oldest.value);
        }
      }
      windows.set(key, { count: 1, resetAt: t + rule.windowSeconds * 1000 });
      return { allowed: rule.limit >= 1, remaining: Math.max(0, rule.limit - 1), retryAfterSeconds: rule.limit >= 1 ? 0 : rule.windowSeconds };
    },
    size: () => windows.size,
  };
}

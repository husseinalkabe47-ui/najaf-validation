// Password hashing behind an interface. The only implementation is argon2id (the database CHECK users_hash_argon2id
// requires the PHC prefix "$argon2id$"). The `argon2` package is loaded lazily and can be injected, so the rest of the
// authentication code is testable without the native module.
import { ARGON2, ARGON2_PHC_PREFIX } from './policy.ts';

export interface PasswordHasher {
  /** Loads the native module and proves a hash/verify round trip works; call it at startup to fail fast. */
  ready(): Promise<void>;
  /** Returns a PHC string ($argon2id$...). The plain password is never stored or logged. */
  hash(plain: string): Promise<string>;
  /** true only for a matching password; malformed hashes and any verification error are a plain `false`. */
  verify(hash: string, plain: string): Promise<boolean>;
}

export interface Argon2ModuleLike {
  argon2id: number;
  hash(plain: string, options: { type: number; memoryCost: number; timeCost: number; parallelism: number }): Promise<string>;
  verify(hash: string, plain: string): Promise<boolean>;
}
interface Argon2Import {
  default?: Argon2ModuleLike;
  argon2id?: number;
  hash?: Argon2ModuleLike['hash'];
  verify?: Argon2ModuleLike['verify'];
}

async function importArgon2(): Promise<Argon2ModuleLike> {
  const mod = (await import('argon2')) as unknown as Argon2Import;
  const m = (mod.default ?? mod) as Argon2ModuleLike;
  if (typeof m.hash !== 'function' || typeof m.verify !== 'function' || typeof m.argon2id !== 'number') {
    throw new Error('the "argon2" package does not expose hash/verify/argon2id');
  }
  return m;
}

export function createArgon2idHasher(deps: { importArgon2?: () => Promise<Argon2ModuleLike>; params?: typeof ARGON2 } = {}): PasswordHasher {
  const load = deps.importArgon2 ?? importArgon2;
  const params = deps.params ?? ARGON2;
  let loaded: Promise<Argon2ModuleLike> | undefined;
  const mod = (): Promise<Argon2ModuleLike> => (loaded ??= load());

  const hash = async (plain: string): Promise<string> => {
    const m = await mod();
    const out = await m.hash(plain, { type: m.argon2id, memoryCost: params.memoryCost, timeCost: params.timeCost, parallelism: params.parallelism });
    if (typeof out !== 'string' || !out.startsWith(ARGON2_PHC_PREFIX)) throw new Error('unexpected password hash format');
    return out;
  };
  const verify = async (stored: string, plain: string): Promise<boolean> => {
    const m = await mod();
    try {
      return (await m.verify(stored, plain)) === true;
    } catch {
      return false;
    }
  };
  return {
    hash,
    verify,
    async ready() {
      const probe = await hash('startup-self-test');
      if (!(await verify(probe, 'startup-self-test')) || (await verify(probe, 'startup-self-test-x'))) {
        throw new Error('argon2 self-test failed: the hasher does not verify correctly');
      }
    },
  };
}

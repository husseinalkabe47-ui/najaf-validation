// One-time codes: generation, keyed hashing and comparison. Pure functions; no I/O.
//
//  - Generated with crypto.randomInt (CSPRNG, uniform: no modulo bias).
//  - Stored ONLY as HMAC-SHA256 (verification_codes.code_hash, 32 bytes). A plain hash would be useless: a 6-digit code has
//    only 10^6 possibilities, so anyone who read the table could invert it instantly; the HMAC key is a secret that is not
//    in the database.
//  - The HMAC input binds the code to its purpose, user and phone: a code can never be accepted for another purpose, another
//    user or another number, even if the database row is copied.
import { createHmac, randomInt, timingSafeEqual } from 'node:crypto';
import { OTP } from './policy.ts';

export type OtpPurpose = 'phone_verify' | 'password_reset';

const KEY_LABEL = 'najaf:otp:v1';
const CODE_FORMAT = new RegExp(`^[0-9]{${OTP.codeLength}}$`);

/** A key derived (with a distinct label) from the server secret: an access-token signature can never be a code hash. */
export function deriveOtpKey(secret: string): Buffer {
  return createHmac('sha256', secret).update(KEY_LABEL).digest();
}

export function generateOtp(rng: (maxExclusive: number) => number = (n) => randomInt(n)): string {
  return String(rng(10 ** OTP.codeLength)).padStart(OTP.codeLength, '0');
}

export function isWellFormedOtp(value: unknown): value is string {
  return typeof value === 'string' && CODE_FORMAT.test(value);
}

export function hashOtp(key: Buffer, binding: { purpose: OtpPurpose; userId: string; phone: string; code: string }): Buffer {
  return createHmac('sha256', key).update(`${binding.purpose}\u0000${binding.userId}\u0000${binding.phone}\u0000${binding.code}`).digest();
}

export function hashesEqual(a: Buffer, b: Buffer): boolean {
  return a.length === b.length && timingSafeEqual(a, b);
}

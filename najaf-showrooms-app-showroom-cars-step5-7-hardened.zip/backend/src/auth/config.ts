// Authentication configuration: the access-token signing secret and the trusted reverse proxies. Kept in its own module
// (like the migration configuration) so the application configuration and its tests are untouched.
// The secret is never echoed: not in errors, not in redactAuthConfig, not in logs.
import { isIPv4, isIPv6 } from 'node:net';

export const AUTH_ENV_VARS = ['AUTH_ACCESS_TOKEN_SECRET', 'AUTH_TRUSTED_PROXIES'] as const;

export interface AuthConfig {
  accessTokenSecret: string;
  /** Addresses/CIDRs whose X-Forwarded-For is trusted (Fastify trustProxy). Empty = trust nobody (the default). */
  trustedProxies: string[];
}

export class AuthConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`Invalid authentication configuration:\n- ${problems.join('\n- ')}`);
    this.name = 'AuthConfigError';
    this.problems = problems;
  }
}

export const MIN_SECRET_LENGTH = 32;
const PLACEHOLDERS = ['change-me', 'changeme', 'secret', 'password', 'example', 'placeholder', 'your-', 'xxxxx'];
const KEYWORDS = ['loopback', 'linklocal', 'uniquelocal'];
const MAX_PROXIES = 20;

// Node's own parsers decide what is an address (a hand-written regex accepted "10.0.0.1:8080" as IPv6).
const isIpv4 = (s: string): boolean => isIPv4(s);
const isIpv6 = (s: string): boolean => isIPv6(s);

function proxyProblem(entry: string): string | undefined {
  if (KEYWORDS.includes(entry)) return undefined;
  const [addr, prefix, ...rest] = entry.split('/');
  if (rest.length > 0 || addr === undefined || addr === '') return 'is not an address, a CIDR or a keyword (loopback, linklocal, uniquelocal)';
  const v4 = isIpv4(addr);
  const v6 = !v4 && isIpv6(addr);
  if (!v4 && !v6) return 'is not an address, a CIDR or a keyword (loopback, linklocal, uniquelocal)';
  if (prefix !== undefined) {
    if (!/^\d{1,3}$/.test(prefix) || Number(prefix) > (v4 ? 32 : 128)) return 'has an invalid prefix length';
    if (Number(prefix) === 0) return 'would trust every address (prefix /0)';
  }
  return undefined;
}

export function loadAuthConfig(env: Record<string, string | undefined> = process.env): AuthConfig {
  const problems: string[] = [];

  const secret = env['AUTH_ACCESS_TOKEN_SECRET'] ?? '';
  if (secret === '') problems.push('AUTH_ACCESS_TOKEN_SECRET is required (at least 32 characters, e.g. the output of: openssl rand -base64 48)');
  else {
    if (secret.length < MIN_SECRET_LENGTH) problems.push(`AUTH_ACCESS_TOKEN_SECRET must be at least ${MIN_SECRET_LENGTH} characters`);
    if (/\s/.test(secret)) problems.push('AUTH_ACCESS_TOKEN_SECRET must not contain whitespace');
    if (new Set(secret).size < 10) problems.push('AUTH_ACCESS_TOKEN_SECRET has too little variety to be a random secret');
    if (PLACEHOLDERS.some((p) => secret.toLowerCase().includes(p))) problems.push('AUTH_ACCESS_TOKEN_SECRET looks like a placeholder; generate a random value');
  }

  const raw = env['AUTH_TRUSTED_PROXIES'] ?? '';
  const trustedProxies = raw
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s !== '');
  if (trustedProxies.length > MAX_PROXIES) problems.push(`AUTH_TRUSTED_PROXIES lists more than ${MAX_PROXIES} entries`);
  trustedProxies.forEach((entry, i) => {
    const p = proxyProblem(entry);
    if (p) problems.push(`AUTH_TRUSTED_PROXIES entry #${i + 1} ${p}`);
  });

  if (problems.length > 0) throw new AuthConfigError(problems);
  return Object.freeze({ accessTokenSecret: secret, trustedProxies: Object.freeze(trustedProxies) as string[] });
}

export function redactAuthConfig(cfg: AuthConfig): Record<string, unknown> {
  return { accessTokenSecret: '***', trustedProxies: [...cfg.trustedProxies] };
}

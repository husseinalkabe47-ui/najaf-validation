// One-time codes: phone verification and password recovery.
//
// Security properties (each one is covered by tests):
//  - Codes come from a CSPRNG and exist only as an HMAC bound to purpose + user + phone (see otp.ts). The plain code is
//    handed to the messaging provider and is never stored, logged, or put in an error or a response.
//  - ONE active code per (user, purpose) (a unique index). A new code supersedes the old one. Short expiry (10 minutes),
//    at most 5 attempts per code, cooldown 60 s, 3 per hour, 10 per day per user and purpose.
//  - A code is single use: it is consumed in the same transaction that performs its effect, under a row lock, so two
//    concurrent submissions cannot both succeed and a replay finds nothing.
//  - A failed attempt is COMMITTED (the outcome is returned from the transaction, never thrown out of it), so the attempt
//    counter cannot be dodged by making the request fail.
//  - EVERY code failure is the same 'invalid_code' error: wrong, expired, used, exhausted, other purpose, other user,
//    unknown account. Password recovery never says whether a phone belongs to an account.
//  - The password policy is checked BEFORE the code is looked at, so a weak password never burns an attempt, and the
//    (slow) password hash is computed only AFTER the code has been verified, so garbage cannot be used to burn CPU.
//  - A successful reset changes the password, clears the login lockout and ends EVERY session of the user.
//  - Delivery happens after the commit and is not awaited, so response time does not depend on the provider; a provider
//    failure is logged (without any secret) and never changes the response.
import { DbError } from '../errors.ts';
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import type { MessagingProvider, OtpMessage } from '../messaging/provider.ts';
import { MIN_SECRET_LENGTH } from './config.ts';
import { deriveOtpKey, generateOtp, hashOtp } from './otp.ts';
import type { OtpPurpose } from './otp.ts';
import type { PasswordHasher } from './password.ts';
import { OTP } from './policy.ts';
import type { AuthStore, UserRow } from './repository.ts';
import { toPublicUser } from './service.ts';
import { AuthError } from './types.ts';
import type { AccountContext, OtpApi, PublicUser } from './types.ts';
import { parseForgotInput, parseOtpConfirmInput, parseResetInput } from './validation.ts';

type IssueResult = { kind: 'issued' } | { kind: 'throttled'; retryAfterSeconds: number };
const NO_HASH = Buffer.alloc(32);

export function createOtpService(deps: {
  store: AuthStore;
  hasher: PasswordHasher;
  provider: MessagingProvider;
  /** The server secret from which the code-hashing key is derived (never used directly, never logged). */
  otpSecret: string;
  logger?: Logger;
  /** Uniform integer in [0, max). Injectable for tests only. */
  randomInt?: (maxExclusive: number) => number;
}): OtpApi {
  const { store, hasher, provider } = deps;
  if (typeof deps.otpSecret !== 'string' || deps.otpSecret.length < MIN_SECRET_LENGTH) {
    throw new Error(`the OTP secret must be at least ${MIN_SECRET_LENGTH} characters`);
  }
  const key = deriveOtpKey(deps.otpSecret);
  const logger = deps.logger ?? nullLogger;
  const rng = deps.randomInt;
  const bind = (purpose: OtpPurpose, user: { id: string; phoneE164: string }, code: string) => hashOtp(key, { purpose, userId: user.id, phone: user.phoneE164, code });

  // Hands the code to the provider AFTER the transaction committed. Not awaited; failures are logged without any secret.
  function dispatch(message: OtpMessage, userId: string): void {
    let sending: Promise<void>;
    try {
      sending = provider.send(message);
    } catch {
      sending = Promise.reject(new Error('provider_error'));
    }
    sending.then(
      () => logger.info({ event: 'auth.otp.sent', purpose: message.purpose, userId }),
      () => logger.warn({ event: 'auth.otp.delivery_failed', purpose: message.purpose, userId, reason: 'provider_error' }),
    );
  }

  async function issueFor(user: UserRow, purpose: OtpPurpose): Promise<IssueResult> {
    const code = generateOtp(rng);
    try {
      const outcome = await store.transaction(({ otp }) => otp.issue({ userId: user.id, phoneE164: user.phoneE164, purpose, codeHash: bind(purpose, user, code) }));
      if (outcome.kind === 'throttled') return outcome;
      dispatch({ phone: user.phoneE164, purpose, code, ttlSeconds: OTP.ttlSeconds }, user.id);
      return { kind: 'issued' };
    } catch (e) {
      // Two simultaneous requests: the unique index let only one code exist. The other request just made one: not an error.
      if (e instanceof DbError && e.kind === 'unique' && e.constraint === 'vcodes_one_active_uq') return { kind: 'throttled', retryAfterSeconds: OTP.cooldownSeconds };
      throw e;
    }
  }

  async function requestPhoneVerification(userId: string): Promise<{ status: 'sent' | 'already_verified' }> {
    const user = await store.users.findById(userId);
    if (!user || user.status !== 'active') throw new AuthError('unauthorized');
    if (user.phoneVerifiedAt !== null) return { status: 'already_verified' }; // nothing is sent, nothing changes
    const result = await issueFor(user, 'phone_verify');
    if (result.kind === 'throttled') {
      logger.info({ event: 'auth.otp.throttled', purpose: 'phone_verify', userId });
      throw new AuthError('rate_limited', undefined, result.retryAfterSeconds);
    }
    return { status: 'sent' };
  }

  async function confirmPhoneVerification(userId: string, input: unknown): Promise<PublicUser> {
    const parsed = parseOtpConfirmInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);

    type Outcome = { kind: 'unauthorized' } | { kind: 'already'; user: UserRow } | { kind: 'verified'; user: UserRow } | { kind: 'rejected'; reason: string };
    const outcome: Outcome = await store.transaction(async ({ users, otp }) => {
      const user = await users.findById(userId);
      if (!user || user.status !== 'active') return { kind: 'unauthorized' };
      if (user.phoneVerifiedAt !== null) return { kind: 'already', user };
      const v = await otp.verify({ userId, phoneE164: user.phoneE164, purpose: 'phone_verify', expectedHash: bind('phone_verify', user, parsed.value.code) });
      if (v.kind === 'rejected') {
        // A concurrent confirmation may have just consumed the code and verified the phone: that is a success, not a failure.
        const again = v.reason === 'no_active_code' ? await users.findById(userId) : null;
        return again && again.phoneVerifiedAt !== null ? { kind: 'already', user: again } : { kind: 'rejected', reason: v.reason };
      }
      await users.markPhoneVerified(userId); // same transaction as the consumption of the code
      return { kind: 'verified', user: (await users.findById(userId)) ?? user };
    });

    if (outcome.kind === 'unauthorized') throw new AuthError('unauthorized');
    if (outcome.kind === 'rejected') {
      logger.info({ event: 'auth.otp.rejected', purpose: 'phone_verify', reason: outcome.reason, userId });
      throw new AuthError('invalid_code');
    }
    if (outcome.kind === 'verified') logger.info({ event: 'auth.phone.verified', userId });
    return toPublicUser(outcome.user);
  }

  async function requestPasswordReset(input: unknown): Promise<{ status: 'accepted' }> {
    const parsed = parseForgotInput(input);
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);

    const user = await store.users.findByPhone(parsed.value.phone);
    if (user && user.status === 'active') {
      const result = await issueFor(user, 'password_reset');
      logger.info({ event: result.kind === 'issued' ? 'auth.password_reset.requested' : 'auth.otp.throttled', purpose: 'password_reset', userId: user.id });
    } else {
      // Same CPU work as the real path (one random code and one HMAC), no row, no message. The answer below is identical.
      hashOtp(key, { purpose: 'password_reset', userId: '0', phone: parsed.value.phone, code: generateOtp(rng) });
      logger.info({ event: 'auth.password_reset.requested_unknown' });
    }
    return { status: 'accepted' }; // always: nothing says whether the phone is registered, throttled, or inactive
  }

  async function resetPassword(input: unknown, ctx: AccountContext = {}): Promise<{ status: 'password_reset' }> {
    const parsed = parseResetInput(input); // includes the password policy: a violation never reaches the code
    if (!parsed.ok) throw new AuthError('validation_failed', parsed.errors);
    const { phone, code, newPassword } = parsed.value;

    type Outcome = { kind: 'reset'; userId: string } | { kind: 'rejected'; reason: string; userId?: string };
    const outcome: Outcome = await store.transaction(async ({ users, sessions, otp, audit }) => {
      const user = await users.findByPhone(phone);
      if (!user || user.status !== 'active') {
        // Unknown or inactive account: the same lookup shape as a real one, and it can never succeed.
        await otp.verify({ userId: '0', phoneE164: phone, purpose: 'password_reset', expectedHash: NO_HASH });
        return { kind: 'rejected', reason: 'unknown_account' };
      }
      const v = await otp.verify({ userId: user.id, phoneE164: user.phoneE164, purpose: 'password_reset', expectedHash: bind('password_reset', user, code) });
      if (v.kind === 'rejected') return { kind: 'rejected', reason: v.reason, userId: user.id };
      // Only now, with a verified code, is the (slow) password hash computed, and BEFORE any session row is locked.
      const newHash = await hasher.hash(newPassword);
      // The one concurrency-safe revocation (it waits for a refresh in flight and sees what that refresh committed), run
      // before the password changes so the audit count is exact; the users_revoke_sessions trigger then sweeps anything that
      // a concurrent sign-in committed in between (a sign-in that began earlier is refused by its own compare-and-swap).
      const ended = await sessions.revokeAllLive(user.id, 'password_changed');
      await users.resetPassword(user.id, newHash);
      // Same transaction: no password reset without its event, and no event for a reset that rolled back. Numbers only.
      await audit.record({ action: 'auth.password_reset', actorUserId: user.id, actorRole: user.role, entityType: 'user', entityId: user.id, afterData: { sessions_revoked: ended }, requestId: ctx.requestId });
      return { kind: 'reset', userId: user.id };
    });

    if (outcome.kind === 'rejected') {
      logger.info({ event: 'auth.otp.rejected', purpose: 'password_reset', reason: outcome.reason, ...(outcome.userId ? { userId: outcome.userId } : {}) });
      throw new AuthError('invalid_code');
    }
    logger.info({ event: 'auth.password_reset.completed', userId: outcome.userId });
    return { status: 'password_reset' };
  }

  return { requestPhoneVerification, confirmPhoneVerification, requestPasswordReset, resetPassword };
}

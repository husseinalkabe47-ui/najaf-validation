// Iraqi mobile numbers. Accepts exactly the formats the prototype accepts (07XXXXXXXXX, +964…, 00964…, 964…, Arabic-Indic
// and Persian digits, spaces, dashes, parentheses) and returns the canonical E.164 form stored by the database (e164_iq).
import { PHONE_INPUT_MAX } from './policy.ts';

const ARABIC_INDIC = '٠١٢٣٤٥٦٧٨٩';
const EXTENDED = '۰۱۲۳۴۵۶۷۸۹';

export function normalizeIraqiPhone(input: string): string | null {
  if (input.length === 0 || input.length > PHONE_INPUT_MAX) return null;
  let s = input.trim();
  s = s.replace(/[٠-٩]/g, (d) => String(ARABIC_INDIC.indexOf(d))).replace(/[۰-۹]/g, (d) => String(EXTENDED.indexOf(d)));
  s = s.replace(/[\s\-()]/g, '');
  let national: string;
  if (s.startsWith('+964')) national = s.slice(4);
  else if (s.startsWith('00964')) national = s.slice(5);
  else if (s.startsWith('964') && s.length === 13) national = s.slice(3);
  else if (s.startsWith('07') && s.length === 11) national = s.slice(1);
  else return null;
  return /^7[0-9]{9}$/.test(national) ? `+964${national}` : null;
}

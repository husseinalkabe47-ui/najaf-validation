// Access tokens: compact JWT, HS256 only, implemented on node:crypto (no dependency). Claims are exactly
// { sub: user id, sid: session family id, iat, exp }: the role and the account status are NEVER taken from the token;
// they are re-read from the database on every request. Verification is strict and fails closed.
import { createHmac, timingSafeEqual } from 'node:crypto';
import { ACCESS_TOKEN_CLOCK_SKEW_SECONDS, ACCESS_TOKEN_MAX_LENGTH, ACCESS_TOKEN_TTL_SECONDS } from './policy.ts';

export interface AccessClaims {
  /** users.id (decimal bigint). */
  sub: string;
  /** sessions.family_id (uuid): the login session this token belongs to. */
  sid: string;
}

// The header is a constant: any other header (alg none, RS256, extra fields...) is rejected by exact comparison.
const HEADER = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
const SEGMENT = /^[A-Za-z0-9_-]+$/;
const SUB = /^[1-9][0-9]{0,18}$/;
const SID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const CLAIM_KEYS = ['exp', 'iat', 'sid', 'sub'];

const mac = (secret: string, signingInput: string): Buffer => createHmac('sha256', secret).update(signingInput).digest();

export function signAccessToken(claims: AccessClaims, secret: string, nowMs: number): { token: string; expiresAt: Date } {
  const iat = Math.floor(nowMs / 1000);
  const exp = iat + ACCESS_TOKEN_TTL_SECONDS;
  const payload = Buffer.from(JSON.stringify({ sub: claims.sub, sid: claims.sid, iat, exp })).toString('base64url');
  const signature = mac(secret, `${HEADER}.${payload}`).toString('base64url');
  return { token: `${HEADER}.${payload}.${signature}`, expiresAt: new Date(exp * 1000) };
}

/** The claims of a valid, unexpired token signed with `secret`; null for anything else (never throws). */
export function verifyAccessToken(token: unknown, secret: string, nowMs: number): AccessClaims | null {
  if (typeof token !== 'string' || token.length > ACCESS_TOKEN_MAX_LENGTH) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, payload, signature] = parts as [string, string, string];
  if (!SEGMENT.test(header) || !SEGMENT.test(payload) || !SEGMENT.test(signature)) return null;
  if (header !== HEADER) return null;

  // 1) signature first (constant time, canonical encoding), 2) only then parse the payload
  const expected = mac(secret, `${header}.${payload}`);
  const provided = Buffer.from(signature, 'base64url');
  if (provided.length !== expected.length || provided.toString('base64url') !== signature) return null;
  if (!timingSafeEqual(provided, expected)) return null;

  let claims: unknown;
  try {
    claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (typeof claims !== 'object' || claims === null || Array.isArray(claims)) return null;
  const c = claims as Record<string, unknown>;
  if (Object.keys(c).sort().join(',') !== CLAIM_KEYS.join(',')) return null;
  const { sub, sid, iat, exp } = c;
  if (typeof sub !== 'string' || !SUB.test(sub) || typeof sid !== 'string' || !SID.test(sid)) return null;
  if (!Number.isSafeInteger(iat) || !Number.isSafeInteger(exp)) return null;
  const now = Math.floor(nowMs / 1000);
  if ((exp as number) <= now) return null; // expired
  if ((iat as number) > now + ACCESS_TOKEN_CLOCK_SKEW_SECONDS) return null; // issued in the future
  const lifetime = (exp as number) - (iat as number);
  if (lifetime <= 0 || lifetime > ACCESS_TOKEN_TTL_SECONDS) return null; // never longer than the policy allows
  return { sub, sid };
}

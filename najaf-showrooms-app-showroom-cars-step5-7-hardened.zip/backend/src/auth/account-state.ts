// Which accounts may AUTHENTICATE (Phase 11.5, Step 5.2). ONE rule, used by every authentication path:
//   sign-in, the per-request session lookup, refresh-token rotation, phone verification, password recovery, change password and
//   sign-out everywhere.
//
//   - active                    -> yes
//   - pending AND role = dealer -> yes: a dealer who applied and waits for an administrator can sign in, see their own account,
//                                  verify their phone, recover their password. Authentication is NOT authorization: the policy layer
//                                  (src/authz, toActor) gives a pending account NO actor, so it has no dealer (or any other) powers.
//   - pending, any other role   -> no (the database forbids that state: users_pending_dealer; refusing it is fail-closed)
//   - suspended                 -> no (also covers a rejected dealer application: the schema has no 'rejected' account state)
//   - deleted (deleted_at set)  -> no (callers only pass rows that are not deleted; the SQL forms check deleted_at themselves)
//
// The SQL forms of this rule live next to the queries that need them (repository.ts); a unit test keeps them identical to this one.

export interface AccountState {
  status: string;
  role: string;
}

export function mayAuthenticate(account: AccountState | null | undefined): boolean {
  if (!account) return false;
  return account.status === 'active' || (account.status === 'pending' && account.role === 'dealer');
}

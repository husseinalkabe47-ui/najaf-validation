// Verifies that the connection the backend uses is the least-privilege application role, not an administrator.
import { APP_ROLE } from './schema-contract.ts';

export interface RoleReport {
  currentUser: string;
  sessionUser: string;
  database: string;
  isSuperuser: boolean;
  canCreateRole: boolean;
  canCreateDb: boolean;
  isReplication: boolean;
  bypassRls: boolean;
  isAppMember: boolean;
  serverVersionNum: number;
}

// Read-only catalog query. The CASE keeps it valid even when najaf_app does not exist yet (reported as a violation).
export const ROLE_QUERY = `
SELECT current_user::text AS cur_user,
       session_user::text AS sess_user,
       current_database()::text AS db_name,
       r.rolsuper AS is_super,
       r.rolcreaterole AS can_create_role,
       r.rolcreatedb AS can_create_db,
       r.rolreplication AS is_replication,
       r.rolbypassrls AS bypass_rls,
       CASE WHEN EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${APP_ROLE}')
            THEN pg_has_role(current_user, '${APP_ROLE}', 'member') ELSE false END AS is_app_member,
       current_setting('server_version_num')::int AS server_version_num
  FROM pg_roles r
 WHERE r.rolname = current_user`;

export class RoleError extends Error {
  readonly violations: string[];
  constructor(violations: string[]) {
    super(`Database role policy violated:\n- ${violations.join('\n- ')}`);
    this.name = 'RoleError';
    this.violations = violations;
  }
}

export function parseRoleRow(row: Record<string, unknown> | undefined): RoleReport {
  if (!row) throw new Error('role query returned no row');
  return {
    currentUser: String(row['cur_user']),
    sessionUser: String(row['sess_user']),
    database: String(row['db_name']),
    isSuperuser: row['is_super'] === true,
    canCreateRole: row['can_create_role'] === true,
    canCreateDb: row['can_create_db'] === true,
    isReplication: row['is_replication'] === true,
    bypassRls: row['bypass_rls'] === true,
    isAppMember: row['is_app_member'] === true,
    serverVersionNum: Number(row['server_version_num']),
  };
}

export function roleViolations(r: RoleReport, minServerVersionNum = 160000): string[] {
  const v: string[] = [];
  if (r.isSuperuser) v.push(`role "${r.currentUser}" is a superuser`);
  if (r.canCreateRole) v.push(`role "${r.currentUser}" can create roles`);
  if (r.canCreateDb) v.push(`role "${r.currentUser}" can create databases`);
  if (r.isReplication) v.push(`role "${r.currentUser}" has the replication attribute`);
  if (r.bypassRls) v.push(`role "${r.currentUser}" bypasses row-level security`);
  if (!r.isAppMember) v.push(`role "${r.currentUser}" is not a member of ${APP_ROLE}`);
  if (r.serverVersionNum < minServerVersionNum) v.push(`PostgreSQL ${r.serverVersionNum} is older than the supported 16`);
  return v;
}

export function assertAppRole(r: RoleReport): void {
  const v = roleViolations(r);
  if (v.length > 0) throw new RoleError(v);
}

// Environment-driven configuration. Dependency-free, fully validated, and secret-safe:
// error messages and redactConfig() never contain the database password.

export type NodeEnv = 'development' | 'test' | 'production';
export type SslMode = 'disable' | 'require' | 'verify-full';
export type LogLevel = 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace' | 'silent';

export interface DbConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
  ssl: SslMode;
  sslCa: string | undefined;
  poolMax: number;
  idleTimeoutMs: number;
  connectTimeoutMs: number;
  statementTimeoutMs: number;
  lockTimeoutMs: number;
  idleInTxTimeoutMs: number;
  applicationName: string;
  requireAppRole: boolean;
}

export interface ServerConfig {
  host: string;
  port: number;
  logLevel: LogLevel;
}

export interface AppConfig {
  env: NodeEnv;
  server: ServerConfig;
  db: DbConfig;
}

// Every environment variable this module reads. backend/.env.example must document each one (unit-tested).
export const ENV_VARS = [
  'NODE_ENV',
  'HOST',
  'PORT',
  'LOG_LEVEL',
  'DATABASE_URL',
  'PGHOST',
  'PGPORT',
  'PGDATABASE',
  'PGUSER',
  'PGPASSWORD',
  'DB_SSL',
  'DB_SSL_CA',
  'DB_POOL_MAX',
  'DB_IDLE_TIMEOUT_MS',
  'DB_CONNECT_TIMEOUT_MS',
  'DB_STATEMENT_TIMEOUT_MS',
  'DB_LOCK_TIMEOUT_MS',
  'DB_IDLE_IN_TX_TIMEOUT_MS',
  'DB_APPLICATION_NAME',
  'DB_REQUIRE_APP_ROLE',
] as const;

export class ConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`Invalid configuration:\n- ${problems.join('\n- ')}`);
    this.name = 'ConfigError';
    this.problems = problems;
  }
}

type Env = Record<string, string | undefined>;

const NODE_ENVS: readonly NodeEnv[] = ['development', 'test', 'production'];
const SSL_MODES: readonly SslMode[] = ['disable', 'require', 'verify-full'];
const LOG_LEVELS: readonly LogLevel[] = ['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent'];

interface ParsedUrl {
  host: string;
  port: number | undefined;
  database: string;
  user: string;
  password: string;
  sslmode: string | undefined;
}

function parseDatabaseUrl(raw: string, problems: string[]): ParsedUrl | undefined {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    // Never echo the raw value: it contains the password.
    problems.push('DATABASE_URL is not a valid URL (expected postgres://user:password@host:port/database)');
    return undefined;
  }
  if (u.protocol !== 'postgres:' && u.protocol !== 'postgresql:') {
    problems.push('DATABASE_URL must use the postgres:// or postgresql:// scheme');
    return undefined;
  }
  const hostname = u.hostname.startsWith('[') && u.hostname.endsWith(']') ? u.hostname.slice(1, -1) : u.hostname;
  try {
    return {
      host: hostname,
      port: u.port === '' ? undefined : Number(u.port),
      database: decodeURIComponent(u.pathname.replace(/^\//, '')),
      user: decodeURIComponent(u.username),
      password: decodeURIComponent(u.password),
      sslmode: u.searchParams.get('sslmode') ?? undefined,
    };
  } catch {
    problems.push('DATABASE_URL contains an invalid percent-encoded sequence');
    return undefined;
  }
}

function intVar(env: Env, name: string, fallback: number, min: number, max: number, problems: string[]): number {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  if (!/^\d+$/.test(raw)) {
    problems.push(`${name} must be an integer between ${min} and ${max}`);
    return fallback;
  }
  const n = Number(raw);
  if (n < min || n > max) {
    problems.push(`${name} must be between ${min} and ${max}`);
    return fallback;
  }
  return n;
}

function boolVar(env: Env, name: string, fallback: boolean, problems: string[]): boolean {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const v = raw.toLowerCase();
  if (v === 'true' || v === '1') return true;
  if (v === 'false' || v === '0') return false;
  problems.push(`${name} must be true or false`);
  return fallback;
}

export function loadConfig(env: Env = process.env): AppConfig {
  const problems: string[] = [];

  const rawEnv = env['NODE_ENV'] ?? 'development';
  let nodeEnv: NodeEnv = 'development';
  if ((NODE_ENVS as readonly string[]).includes(rawEnv)) nodeEnv = rawEnv as NodeEnv;
  else problems.push(`NODE_ENV must be one of: ${NODE_ENVS.join(', ')}`);
  const production = nodeEnv === 'production';

  // ---- HTTP server ----
  const hostRaw = env['HOST'];
  if (production && (hostRaw === undefined || hostRaw === '')) {
    problems.push('HOST must be set explicitly in production (use 0.0.0.0 inside a container, 127.0.0.1 behind a local proxy)');
  }
  const port = intVar(env, 'PORT', 3000, 1, 65535, problems);
  const rawLevel = env['LOG_LEVEL'] ?? 'info';
  let logLevel: LogLevel = 'info';
  if ((LOG_LEVELS as readonly string[]).includes(rawLevel)) logLevel = rawLevel as LogLevel;
  else problems.push(`LOG_LEVEL must be one of: ${LOG_LEVELS.join(', ')}`);

  // ---- Database connection: DATABASE_URL wins over PG* variables ----
  let host: string | undefined;
  let dbPort: number | undefined;
  let database: string | undefined;
  let user: string | undefined;
  let password: string | undefined;
  let urlSslMode: string | undefined;
  const url = env['DATABASE_URL'];
  if (url !== undefined && url !== '') {
    const p = parseDatabaseUrl(url, problems);
    if (p) {
      host = p.host;
      dbPort = p.port;
      database = p.database;
      user = p.user;
      password = p.password;
      urlSslMode = p.sslmode;
    }
  } else {
    host = env['PGHOST'];
    database = env['PGDATABASE'];
    user = env['PGUSER'];
    password = env['PGPASSWORD'];
    if (env['PGPORT'] !== undefined && env['PGPORT'] !== '') dbPort = intVar(env, 'PGPORT', 5432, 1, 65535, problems);
  }
  if (!host) problems.push('database host is required (DATABASE_URL or PGHOST)');
  if (!database) problems.push('database name is required (DATABASE_URL or PGDATABASE)');
  if (!user) problems.push('database user is required (DATABASE_URL or PGUSER)');
  if (!password) problems.push('database password is required (DATABASE_URL or PGPASSWORD)');
  if (dbPort !== undefined && (!Number.isInteger(dbPort) || dbPort < 1 || dbPort > 65535)) {
    problems.push('database port must be between 1 and 65535');
    dbPort = undefined;
  }

  // ---- TLS: DB_SSL > ?sslmode= in the URL > default (verify-full in production, otherwise disable) ----
  let ssl: SslMode = production ? 'verify-full' : 'disable';
  const sslRaw = env['DB_SSL'] !== undefined && env['DB_SSL'] !== '' ? env['DB_SSL'] : urlSslMode;
  if (sslRaw !== undefined) {
    if ((SSL_MODES as readonly string[]).includes(sslRaw)) ssl = sslRaw as SslMode;
    else problems.push(`DB_SSL / sslmode must be one of: ${SSL_MODES.join(', ')} (other libpq modes are intentionally unsupported)`);
  }
  if (production && ssl === 'disable') problems.push('DB_SSL=disable is not allowed in production');
  const sslCaRaw = env['DB_SSL_CA'];
  const sslCa = sslCaRaw !== undefined && sslCaRaw !== '' ? sslCaRaw : undefined;

  // ---- Pool, timeouts, role policy ----
  const requireAppRole = boolVar(env, 'DB_REQUIRE_APP_ROLE', true, problems);
  if (production && !requireAppRole) problems.push('DB_REQUIRE_APP_ROLE=false is not allowed in production');
  if (requireAppRole && user !== undefined && user.toLowerCase() === 'postgres') {
    problems.push("the application must not connect as the 'postgres' superuser; use the least-privilege login role (see backend/ops/create_app_login.sql)");
  }
  const appName = env['DB_APPLICATION_NAME'] !== undefined && env['DB_APPLICATION_NAME'] !== '' ? env['DB_APPLICATION_NAME'] : 'najaf-backend';
  if (!/^[A-Za-z0-9_.-]{1,63}$/.test(appName)) problems.push('DB_APPLICATION_NAME must match [A-Za-z0-9_.-] and be at most 63 characters');

  const db: DbConfig = {
    host: host ?? '',
    port: dbPort ?? 5432,
    database: database ?? '',
    user: user ?? '',
    password: password ?? '',
    ssl,
    sslCa,
    poolMax: intVar(env, 'DB_POOL_MAX', 10, 1, 100, problems),
    idleTimeoutMs: intVar(env, 'DB_IDLE_TIMEOUT_MS', 30_000, 1_000, 600_000, problems),
    connectTimeoutMs: intVar(env, 'DB_CONNECT_TIMEOUT_MS', 5_000, 500, 60_000, problems),
    statementTimeoutMs: intVar(env, 'DB_STATEMENT_TIMEOUT_MS', 15_000, 100, 300_000, problems),
    lockTimeoutMs: intVar(env, 'DB_LOCK_TIMEOUT_MS', 5_000, 100, 60_000, problems),
    idleInTxTimeoutMs: intVar(env, 'DB_IDLE_IN_TX_TIMEOUT_MS', 15_000, 100, 300_000, problems),
    applicationName: appName,
    requireAppRole,
  };

  if (problems.length > 0) throw new ConfigError(problems);
  return Object.freeze({
    env: nodeEnv,
    server: Object.freeze({ host: hostRaw !== undefined && hostRaw !== '' ? hostRaw : '127.0.0.1', port, logLevel }),
    db: Object.freeze(db),
  });
}

// Safe to log: the password and CA material are never included.
export function redactConfig(cfg: AppConfig): Record<string, unknown> {
  return {
    env: cfg.env,
    server: { ...cfg.server },
    db: { ...cfg.db, password: '***', sslCa: cfg.db.sslCa ? '[set]' : undefined },
  };
}

export function describeDbTarget(db: DbConfig): string {
  return `${db.user}@${db.host}:${db.port}/${db.database}`;
}

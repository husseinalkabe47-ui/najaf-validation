// Liveness never touches the database. Readiness checks connectivity and that the schema contract is present.
// Details go to the server log; the response contains only coarse statuses.
import type { Db } from './db.ts';
import { describeError } from './errors.ts';
import { nullLogger } from './types.ts';
import type { Logger } from './types.ts';

export interface Readiness {
  ready: boolean;
  checks: { database: 'ok' | 'fail'; schema: 'ok' | 'fail' | 'skipped' };
}

export function livenessReport(): { status: 'ok' } {
  return { status: 'ok' };
}

export async function withTimeout<T>(work: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
  });
  try {
    return await Promise.race([work, timeout]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

export async function readinessReport(deps: {
  db: Pick<Db, 'ping' | 'checkSchema'>;
  timeoutMs?: number;
  logger?: Logger;
}): Promise<Readiness> {
  const timeoutMs = deps.timeoutMs ?? 2000;
  const logger = deps.logger ?? nullLogger;
  try {
    await withTimeout(deps.db.ping(), timeoutMs, 'database ping');
  } catch (e) {
    logger.warn({ err: describeError(e) }, 'readiness: database check failed');
    return { ready: false, checks: { database: 'fail', schema: 'skipped' } };
  }
  try {
    const { missing } = await withTimeout(deps.db.checkSchema(), timeoutMs, 'schema check');
    if (missing.length > 0) {
      logger.warn({ missing }, 'readiness: schema contract not satisfied');
      return { ready: false, checks: { database: 'ok', schema: 'fail' } };
    }
  } catch (e) {
    logger.warn({ err: describeError(e) }, 'readiness: schema check failed');
    return { ready: false, checks: { database: 'ok', schema: 'fail' } };
  }
  return { ready: true, checks: { database: 'ok', schema: 'ok' } };
}

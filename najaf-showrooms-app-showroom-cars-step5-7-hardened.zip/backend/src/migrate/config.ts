// Configuration of the migration account. It is intentionally separate from the application configuration:
// the backend runtime connects as a least-privilege member of najaf_app; migrations need an owner-level account.
import type { NodeEnv, SslMode } from '../config.ts';

export interface MigrationClientConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
  ssl: false | { rejectUnauthorized: boolean; ca?: string };
  application_name: string;
}

export interface MigrationConfig {
  env: NodeEnv;
  client: MigrationClientConfig;
  sslMode: SslMode;
  /** false (default, as validated): each migration in its own transaction; true: all-or-nothing. */
  singleTransaction: boolean;
  /** `down` is always allowed outside production; in production only with MIGRATION_ALLOW_ROLLBACK=true. */
  allowRollback: boolean;
}

// Every variable this module reads; backend/.env.migrations.example must document each one (unit-tested).
export const MIGRATION_ENV_VARS = [
  'NODE_ENV',
  'DATABASE_URL',
  'MIGRATION_DATABASE_URL',
  'MIGRATION_DB_SSL',
  'MIGRATION_DB_SSL_CA',
  'MIGRATION_SINGLE_TRANSACTION',
  'MIGRATION_ALLOW_ROLLBACK',
] as const;

/** Account names that must never run migrations: they are the application/reporting identities. */
export const FORBIDDEN_MIGRATION_USERS: readonly string[] = ['najaf_app', 'najaf_app_login', 'najaf_report'];

export class MigrationConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`Invalid migration configuration:\n- ${problems.join('\n- ')}`);
    this.name = 'MigrationConfigError';
    this.problems = problems;
  }
}

type Env = Record<string, string | undefined>;
const SSL_MODES: readonly SslMode[] = ['disable', 'require', 'verify-full'];

function userOf(raw: string | undefined): string | undefined {
  if (raw === undefined || raw === '') return undefined;
  try {
    return decodeURIComponent(new URL(raw).username);
  } catch {
    return undefined;
  }
}

export function loadMigrationConfig(env: Env = process.env): MigrationConfig {
  const problems: string[] = [];

  const rawEnv = env['NODE_ENV'] ?? 'development';
  let nodeEnv: NodeEnv = 'development';
  if (rawEnv === 'development' || rawEnv === 'test' || rawEnv === 'production') nodeEnv = rawEnv;
  else problems.push('NODE_ENV must be one of: development, test, production');
  const production = nodeEnv === 'production';

  let host = '';
  let port = 5432;
  let database = '';
  let user = '';
  let password = '';
  let urlSslMode: string | undefined;
  const raw = env['MIGRATION_DATABASE_URL'];
  if (raw === undefined || raw === '') {
    problems.push('MIGRATION_DATABASE_URL is required (postgres://user:password@host:port/database)');
  } else {
    let u: URL | undefined;
    try {
      u = new URL(raw);
    } catch {
      // Never echo the raw value: it contains the password.
      problems.push('MIGRATION_DATABASE_URL is not a valid URL');
    }
    if (u) {
      if (u.protocol !== 'postgres:' && u.protocol !== 'postgresql:') {
        problems.push('MIGRATION_DATABASE_URL must use the postgres:// or postgresql:// scheme');
      } else {
        try {
          host = u.hostname.startsWith('[') && u.hostname.endsWith(']') ? u.hostname.slice(1, -1) : u.hostname;
          port = u.port === '' ? 5432 : Number(u.port);
          database = decodeURIComponent(u.pathname.replace(/^\//, ''));
          user = decodeURIComponent(u.username);
          password = decodeURIComponent(u.password);
          urlSslMode = u.searchParams.get('sslmode') ?? undefined;
        } catch {
          problems.push('MIGRATION_DATABASE_URL contains an invalid percent-encoded sequence');
        }
        if (!host) problems.push('MIGRATION_DATABASE_URL has no host');
        if (!database) problems.push('MIGRATION_DATABASE_URL has no database name');
        if (!user) problems.push('MIGRATION_DATABASE_URL has no user');
        if (!password) problems.push('MIGRATION_DATABASE_URL has no password');
        if (!Number.isInteger(port) || port < 1 || port > 65535) problems.push('MIGRATION_DATABASE_URL port must be between 1 and 65535');
      }
    }
  }

  // The migration account must be a different identity from the application account.
  if (user !== '') {
    if (FORBIDDEN_MIGRATION_USERS.includes(user.toLowerCase())) {
      problems.push(`the migration account must not be '${user}': it is the application/reporting identity; use a dedicated owner-level account (see backend/ops/create_migration_role.sql)`);
    }
    const appUser = userOf(env['DATABASE_URL']);
    if (appUser !== undefined && appUser === user) {
      problems.push('MIGRATION_DATABASE_URL must use a different account than DATABASE_URL (the application account)');
    }
  }

  let sslMode: SslMode = production ? 'verify-full' : 'disable';
  const sslRaw = env['MIGRATION_DB_SSL'] !== undefined && env['MIGRATION_DB_SSL'] !== '' ? env['MIGRATION_DB_SSL'] : urlSslMode;
  if (sslRaw !== undefined) {
    if ((SSL_MODES as readonly string[]).includes(sslRaw)) sslMode = sslRaw as SslMode;
    else problems.push(`MIGRATION_DB_SSL / sslmode must be one of: ${SSL_MODES.join(', ')}`);
  }
  if (production && sslMode === 'disable') problems.push('MIGRATION_DB_SSL=disable is not allowed in production');
  const ca = env['MIGRATION_DB_SSL_CA'] !== undefined && env['MIGRATION_DB_SSL_CA'] !== '' ? env['MIGRATION_DB_SSL_CA'] : undefined;

  const boolVar = (name: string, fallback: boolean): boolean => {
    const v = env[name];
    if (v === undefined || v === '') return fallback;
    const l = v.toLowerCase();
    if (l === 'true' || l === '1') return true;
    if (l === 'false' || l === '0') return false;
    problems.push(`${name} must be true or false`);
    return fallback;
  };
  const singleTransaction = boolVar('MIGRATION_SINGLE_TRANSACTION', false);
  const allowRollback = boolVar('MIGRATION_ALLOW_ROLLBACK', false);

  if (problems.length > 0) throw new MigrationConfigError(problems);

  let ssl: MigrationClientConfig['ssl'];
  if (sslMode === 'disable') ssl = false;
  else if (sslMode === 'require') ssl = { rejectUnauthorized: false };
  else ssl = { rejectUnauthorized: true, ...(ca ? { ca } : {}) };

  return Object.freeze({
    env: nodeEnv,
    client: Object.freeze({ host, port, database, user, password, ssl, application_name: 'najaf-migrate' }),
    sslMode,
    singleTransaction,
    allowRollback,
  });
}

// Safe to log: no password, no CA material.
export function redactMigrationConfig(cfg: MigrationConfig): Record<string, unknown> {
  return {
    env: cfg.env,
    client: { ...cfg.client, password: '***', ssl: cfg.sslMode },
    singleTransaction: cfg.singleTransaction,
    allowRollback: cfg.allowRollback,
  };
}

export function describeMigrationTarget(cfg: MigrationConfig): string {
  return `${cfg.client.user}@${cfg.client.host}:${cfg.client.port}/${cfg.client.database}`;
}

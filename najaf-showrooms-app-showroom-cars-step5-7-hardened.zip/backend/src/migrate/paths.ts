// Fixed locations for the migration runner (Phase 11.4.2). Nothing here is configurable on purpose:
// the SQL source of truth stays in database/migrations (frozen, checksummed); this package only wraps it.
import { readdirSync } from 'node:fs';
import { join } from 'node:path';

export const BACKEND_ROOT = join(import.meta.dirname, '..', '..');
/** CommonJS wrappers (one per migration) that node-pg-migrate loads. */
export const MIGRATIONS_DIR = join(BACKEND_ROOT, 'db', 'migrations');
/** Rollback scripts, one per migration. */
export const DOWN_SQL_DIR = join(BACKEND_ROOT, 'db', 'down');
/** The validated, unmodified migrations (never written by this code). */
export const UP_SQL_DIR = join(BACKEND_ROOT, '..', 'database', 'migrations');

/**
 * node-pg-migrate treats EVERY entry of the directory it is given as a migration (it only skips names matching
 * ignorePattern, by default those starting with "."), and each one needs a numeric prefix. So MIGRATIONS_DIR must hold
 * nothing but the wrappers; the CommonJS marker lives one level up, in db/package.json.
 */
export const WRAPPER_FILE = /^\d{4}_[a-z0-9_]+\.js$/;

/** Tracking table, outside `public` (the 11.3 structure suite forbids extra tables in public). */
export const TRACKING_SCHEMA = 'ops';
export const TRACKING_TABLE = 'pgmigrations';

/** The version validated by the migrations-evaluation run (29 PASS / 0 FAIL on PostgreSQL 16). */
export const PINNED_TOOL_VERSION = '9.0.0';

/** Migration names (file name without extension), ascending. */
export function listMigrationNames(dir: string = MIGRATIONS_DIR): string[] {
  return readdirSync(dir)
    .filter((f) => f.endsWith('.js'))
    .map((f) => f.slice(0, -'.js'.length))
    .sort();
}

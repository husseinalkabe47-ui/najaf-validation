// The objects the backend requires. This is the contract with the PostgreSQL schema that passed Phase 11.3
// (database/migrations 0001-0013). A unit test compares these lists with the migration files, so they cannot drift.
export const SCHEMA_CONTRACT_VERSION = '0013';

export const REQUIRED_TABLES: readonly string[] = [
  'users',
  'assets',
  'showrooms',
  'cars',
  'car_images',
  'favorites',
  'sessions',
  'verification_codes',
  'message_deliveries',
  'reward_grants',
  'subscription_plans',
  'subscriptions',
  'payments',
  'audit_logs',
  'exchange_rates',
  'app_settings',
];

export const REQUIRED_VIEWS: readonly string[] = ['public_showrooms', 'public_cars'];

// The least-privilege role every application login must be a member of (created by migration 0012).
export const APP_ROLE = 'najaf_app';

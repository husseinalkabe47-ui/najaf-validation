// HTTP contract for a member's OWN car ads (Phase 11.5, Step 5.4). Thin: decisions live in member-cars/service.ts and src/authz.
// Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   POST   /v1/me/cars                    Bearer, JSON {brand, model, year, price, currency, phone, ...}  -> 201 {car}  (status 'pending')
//   GET    /v1/me/cars?limit=&before=&status=   Bearer                                                   -> 200 {items, nextBefore}
//   GET    /v1/me/cars/:id                Bearer                                                          -> 200 {car}
//   PATCH  /v1/me/cars/:id                Bearer, JSON {version, ...changed fields, status?: 'sold'}      -> 200 {car}
//   DELETE /v1/me/cars/:id?version=N      Bearer, no body                                                 -> 204
//
// Errors: 401 no/invalid token; 403 create/list for an account that may not act; 404 for any ad that is not the caller's (or a
// malformed id), identical to an unknown id; 400 invalid input (field names and codes only); 409 version_conflict / invalid_state;
// 415 non-JSON body. The owner is the verified token's account, never a request field.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { MemberCarError } from './service.ts';
import type { MemberCarApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same in-process limiter as the other routes). */
export const MEMBER_CAR_RATE_LIMITS = {
  create: { limit: 20, windowSeconds: 60 * 60 },
  write: { limit: 120, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type MemberCarRateLimitedRoute = keyof typeof MEMBER_CAR_RATE_LIMITS;

/** Maps every error this layer may see to the project's HTTP contract; undefined = not ours (the global handler maps it). */
export function toMemberCarHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof MemberCarError) {
    if (e.code === 'validation_failed') return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    return { status: 409, code: e.code, message: e.message };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function memberCarRateLimitHook(limiter: RateLimiter, route: MemberCarRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`memberCars.${route}:${request.ip}`, MEMBER_CAR_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'member_cars.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** DELETE carries no body (the version travels in the query string). */
function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  throw new MemberCarError('validation_failed', [{ field: 'body', code: 'invalid_type' }]);
}

export function registerMemberCarRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; memberCars: MemberCarApi; rateLimiter?: RateLimiter }): void {
  const { auth, memberCars, rateLimiter } = deps;
  const limited = (route: MemberCarRateLimitedRoute): Hook[] => (rateLimiter ? [memberCarRateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toMemberCarHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling" (and so of the owner): the verified access token, re-read from the database, then the
  // account-state rules. No/invalid token -> 401. An authenticated account that may not act (pending dealer) -> null actor.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };
  const idParam = (request: FastifyRequest): unknown => (request.params as Record<string, unknown> | undefined)?.['id'];
  const ctxOf = (request: FastifyRequest) => ({ requestId: request.id });

  app.post('/v1/me/cars', { bodyLimit: 16 * 1024, onRequest: [...limited('create'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await memberCars.create(actor, request.body, ctxOf(request));
      return reply.code(201).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/me/cars', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await memberCars.listOwn(actor, request.query));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.get('/v1/me/cars/:id', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await memberCars.getOwn(actor, idParam(request));
      return reply.code(200).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.patch('/v1/me/cars/:id', { bodyLimit: 16 * 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const car = await memberCars.update(actor, idParam(request), request.body, ctxOf(request));
      return reply.code(200).send({ car });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.delete('/v1/me/cars/:id', { bodyLimit: 1024, onRequest: limited('write') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      assertNoBody(request.body);
      await memberCars.remove(actor, idParam(request), request.query, ctxOf(request));
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

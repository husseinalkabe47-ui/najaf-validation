// A member's OWN car ads (Phase 11.5, Step 5.4): create, list own, get own, update own, soft-delete own.
//
// Decisions (each is covered by tests):
//  - WHO acts is an Actor from src/authz (the account re-read from the database for a verified access token). An authenticated
//    account without an actor (pending dealer) can do nothing here: 403 on the collection (create/list: there is no resource to
//    hide), 404 on an item (same as an unknown id).
//  - The owner is ALWAYS the actor's id. No input carries an owner, showroom, source type, status to publish, or reviewer field.
//  - Ownership is enforced three times: the SQL is scoped by owner_id (another user's row is not found), the service re-checks
//    row.ownerId === actor.id, and the existing policy (authorize on a memberCarResource) must allow the action. Any non-owner,
//    an administrator included, gets 404: these are "/me" routes, and administrator car management is not part of this step.
//  - Publishing is DISABLED (decision D1, rewarded-ad verification not implemented): every new ad is stored 'pending' (not in the
//    public_cars view) and no route can move an ad to 'active'. The only status an owner sets here is active -> sold.
//  - Optimistic concurrency: update and delete must name the `version` the client last saw. Inside ONE transaction the acting
//    account is re-checked and share-locked, the ad is locked FOR UPDATE, the version is compared (409 version_conflict), the
//    write is a compare-and-swap on that version, and the audit row is written. All or nothing.
//  - Soft delete only (deleted_at); the database trigger removes favorites of the deleted ad. A deleted ad is 404 everywhere.
//  - Order of checks for an item: malformed id -> 404 without touching the database; invalid input -> 400 (independent of any
//    row, so it discloses nothing); then the row.
import { AuthzError, authorize, memberCarResource, notFound } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError } from '../auth/validation.ts';
import { normalizeSearchText } from '../catalog/params.ts';
import type { MemberCarRepository, MemberCarRow, MemberCarStore } from './repository.ts';
import { parseCarId, parseCreateInput, parseDeleteQuery, parseListQuery, parseUpdateInput } from './validation.ts';
import type { MemberCarFields } from './validation.ts';

export type MemberCarErrorCode = 'validation_failed' | 'version_conflict' | 'invalid_state';
const MESSAGES: Record<MemberCarErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  version_conflict: 'The ad was changed by another request; reload it and try again',
  invalid_state: 'The ad is not in a state that allows this action',
};
export class MemberCarError extends Error {
  readonly code: MemberCarErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: MemberCarErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'MemberCarError';
    this.code = code;
    this.fields = fields;
  }
}

/** The owner's view of their ad (whitelist, field by field). No owner id, reviewer id or search text. */
export interface OwnMemberCar {
  id: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  location: string;
  latitude: number | null;
  longitude: number | null;
  status: string;
  /** Why an administrator rejected or suspended the ad: the owner's own information. */
  rejectionReason: string | null;
  suspensionReason: string | null;
  version: number;
  createdAt: string;
  updatedAt: string;
}
export interface OwnPage {
  items: OwnMemberCar[];
  nextBefore: string | null;
}
export interface RequestContext {
  requestId?: string | undefined;
}

export interface MemberCarApi {
  create(actor: Actor | null, body: unknown, ctx?: RequestContext): Promise<OwnMemberCar>;
  listOwn(actor: Actor | null, query: unknown): Promise<OwnPage>;
  getOwn(actor: Actor | null, rawId: unknown): Promise<OwnMemberCar>;
  update(actor: Actor | null, rawId: unknown, body: unknown, ctx?: RequestContext): Promise<OwnMemberCar>;
  remove(actor: Actor | null, rawId: unknown, query: unknown, ctx?: RequestContext): Promise<void>;
}

const num = (v: string | null): number | null => (v === null ? null : Number(v));

export function toOwnMemberCar(r: MemberCarRow): OwnMemberCar {
  return {
    id: r.id,
    brand: r.brand,
    model: r.model,
    year: r.year,
    price: Number(r.price),
    currency: r.currency,
    mileage: r.mileage,
    transmission: r.transmission,
    fuelType: r.fuelType,
    color: r.color,
    description: r.description,
    phone: r.phone,
    whatsapp: r.whatsapp,
    location: r.location ?? '',
    latitude: num(r.latitude),
    longitude: num(r.longitude),
    status: r.status,
    rejectionReason: r.rejectionReason,
    suspensionReason: r.suspensionReason,
    version: r.version,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

/** The text the public catalog searches (same normalization as its queries): brand, model, year, colour, location. */
export function searchTextOf(f: Pick<MemberCarFields, 'brand' | 'model' | 'year' | 'color' | 'location'>): string {
  return normalizeSearchText([f.brand, f.model, String(f.year), f.color, f.location].join(' '));
}

/** users.role vocabulary for the audit table (the policy says 'member', the table says 'user'). */
const auditRole = (a: Actor): string => (a.role === 'member' ? 'user' : a.role);

function parsed<T>(r: { ok: true; value: T } | { ok: false; errors: FieldError[] }): T {
  if (!r.ok) throw new MemberCarError('validation_failed', r.errors);
  return r.value;
}

/** The single ownership gate for a loaded row: the actor's own, AND allowed by the policy. Anything else is 404. */
function assertOwnAndAllowed(actor: Actor, row: MemberCarRow | null, action: 'read' | 'update' | 'delete'): MemberCarRow {
  if (!row || row.ownerId !== actor.id) throw notFound();
  const resource = memberCarResource({ ownerId: row.ownerId, status: row.status, ownerActive: row.ownerActive, deleted: false });
  authorize(actor, action, resource);
  return row;
}

/** Loads and locks the actor's own ad inside a transaction, after re-checking the actor. 404 for anything that is not theirs. */
async function lockOwned(cars: MemberCarRepository, actor: Actor, id: string, action: 'update' | 'delete'): Promise<MemberCarRow> {
  if (!(await cars.lockActingUser(actor.id))) throw notFound();
  return assertOwnAndAllowed(actor, await cars.lockOwn(id, actor.id), action);
}

export function createMemberCarService(deps: { store: MemberCarStore }): MemberCarApi {
  const { store } = deps;

  return {
    async create(actor, body, ctx = {}) {
      // Any account that may act (member, dealer, admin), as in the prototype. No resource exists yet, so no 404 to protect: 403.
      if (!actor) throw new AuthzError('forbidden');
      const { fields } = parsed(parseCreateInput(body));
      return store.transaction(async ({ cars, audit }) => {
        if (!(await cars.lockActingUser(actor.id))) throw new AuthzError('forbidden');
        const row = await cars.insert(actor.id, fields, searchTextOf(fields));
        await audit.record({ action: 'member_car.create', actorUserId: actor.id, actorRole: auditRole(actor), entityType: 'car', entityId: row.id, afterData: { version: row.version }, requestId: ctx.requestId });
        return toOwnMemberCar(row);
      });
    },

    async listOwn(actor, query) {
      if (!actor) throw new AuthzError('forbidden');
      const q = parsed(parseListQuery(query));
      const rows = await store.cars.listOwn(actor.id, q);
      // Defense in depth: a row that is not the actor's never leaves, whatever the query returned.
      const own = rows.filter((r) => r.ownerId === actor.id);
      const last = rows.length === q.limit ? rows[rows.length - 1] : undefined;
      return { items: own.map(toOwnMemberCar), nextBefore: last ? last.id : null };
    },

    async getOwn(actor, rawId) {
      const id = parseCarId(rawId);
      if (!actor || id === null) throw notFound();
      return toOwnMemberCar(assertOwnAndAllowed(actor, await store.cars.findOwn(id, actor.id), 'read'));
    },

    async update(actor, rawId, body, ctx = {}) {
      const id = parseCarId(rawId);
      if (!actor || id === null) throw notFound();
      const input = parsed(parseUpdateInput(body));
      return store.transaction(async ({ cars, audit }) => {
        const row = await lockOwned(cars, actor, id, 'update');
        if (row.version !== input.version) throw new MemberCarError('version_conflict');
        if (input.status === 'sold' && row.status !== 'active') throw new MemberCarError('invalid_state');
        const merged = {
          brand: input.changes.brand ?? row.brand,
          model: input.changes.model ?? row.model,
          year: input.changes.year ?? row.year,
          color: input.changes.color ?? row.color,
          location: input.changes.location ?? row.location ?? '',
        };
        const updated = await cars.update({ id, ownerId: actor.id, expectedVersion: input.version, changes: input.changes, markSold: input.status === 'sold', searchText: searchTextOf(merged) });
        // Under the row lock this cannot happen; if it ever does, nothing was written and the client must reload.
        if (!updated) throw new MemberCarError('version_conflict');
        await audit.record({
          action: input.status === 'sold' ? 'member_car.mark_sold' : 'member_car.update',
          actorUserId: actor.id,
          actorRole: auditRole(actor),
          entityType: 'car',
          entityId: id,
          afterData: { version: updated.version, fields: Object.keys(input.changes).length },
          requestId: ctx.requestId,
        });
        return toOwnMemberCar(updated);
      });
    },

    async remove(actor, rawId, query, ctx = {}) {
      const id = parseCarId(rawId);
      if (!actor || id === null) throw notFound();
      const { version } = parsed(parseDeleteQuery(query));
      await store.transaction(async ({ cars, audit }) => {
        const row = await lockOwned(cars, actor, id, 'delete');
        if (row.version !== version) throw new MemberCarError('version_conflict');
        if (!(await cars.softDelete({ id, ownerId: actor.id, expectedVersion: version }))) throw new MemberCarError('version_conflict');
        await audit.record({ action: 'member_car.delete', actorUserId: actor.id, actorRole: auditRole(actor), entityType: 'car', entityId: id, afterData: { version }, requestId: ctx.requestId });
      });
    },
  };
}

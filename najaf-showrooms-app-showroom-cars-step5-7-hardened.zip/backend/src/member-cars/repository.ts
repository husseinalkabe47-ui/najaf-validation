// PostgreSQL access for a member's OWN car ads (Phase 11.5, Step 5.4). Rules, as in the other repositories:
//  - every statement is parameterized; source_type and every status a statement WRITES or requires are SQL literals;
//  - EVERY statement is scoped by owner: `owner_id = <the verified actor's id>` AND `source_type = 'member'`, so another user's
//    row (or a showroom car) is simply not found, whatever id is asked for. The owner id is never taken from the request;
//  - only columns the application role may write (migration 0013): never id, owner_id, showroom_id, source_type, version,
//    created_at or updated_at (the touch_versioned trigger owns version and updated_at), and never the reviewer columns;
//  - the SET list of an update comes from a FIXED field -> column map below, never from request keys;
//  - optimistic concurrency: updates and the soft delete are compare-and-swap on `version`;
//  - no SELECT *: each query names its columns; reviewed_by (an administrator's id) and search_text are never returned.
// Audit rows reuse the single audit writer of auth/repository.ts (inside the same transaction).
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';
import type { MemberCarField, MemberCarFields, MemberCarStatus } from './validation.ts';

export interface MemberCarRow {
  id: string;
  ownerId: string;
  /** The owner account is active and not deleted (needed by the policy's resource, never exposed). */
  ownerActive: boolean;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuelType: string;
  color: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  location: string | null;
  latitude: string | null;
  longitude: string | null;
  status: string;
  rejectionReason: string | null;
  suspensionReason: string | null;
  version: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface MemberCarRepository {
  /** Re-checks INSIDE the transaction that the acting account is still active and not deleted, and SHARE-locks it to commit. */
  lockActingUser(userId: string): Promise<boolean>;
  /** Creates the ad for this owner, ALWAYS as an unpublished 'pending' member car (decision D1: no publishing yet). */
  insert(ownerId: string, fields: MemberCarFields, searchText: string): Promise<MemberCarRow>;
  /** The owner's ads that are not deleted, newest id first (keyset on id). */
  listOwn(ownerId: string, q: { limit: number; before: string | null; status: MemberCarStatus | null }): Promise<MemberCarRow[]>;
  /** One of the owner's ads that is not deleted; null for anything else (another owner's, a showroom car, deleted, unknown). */
  findOwn(id: string, ownerId: string): Promise<MemberCarRow | null>;
  /** findOwn, locked FOR UPDATE until the end of the transaction. */
  lockOwn(id: string, ownerId: string): Promise<MemberCarRow | null>;
  /**
   * Compare-and-swap update of the given fields (and status 'sold' when `markSold`, which also requires status = 'active').
   * null = the row is no longer at `expectedVersion` (or not in 'active' for markSold): nothing was changed.
   */
  update(input: { id: string; ownerId: string; expectedVersion: number; changes: Partial<MemberCarFields>; markSold: boolean; searchText: string }): Promise<MemberCarRow | null>;
  /** Compare-and-swap soft delete (deleted_at = now()). false = not at `expectedVersion` (or already deleted / not the owner's). */
  softDelete(input: { id: string; ownerId: string; expectedVersion: number }): Promise<boolean>;
}

export interface MemberCarStore {
  /** Autocommit reads. */
  cars: MemberCarRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { cars: MemberCarRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

/** The ONLY mapping from an input field to a column. A key that is not here can never reach SQL. */
export const COLUMN_OF: Readonly<Record<MemberCarField, string>> = Object.freeze({
  brand: 'brand',
  model: 'model',
  year: 'year',
  price: 'price',
  currency: 'currency',
  mileage: 'mileage',
  transmission: 'transmission',
  fuelType: 'fuel_type',
  color: 'color',
  description: 'description',
  phone: 'phone',
  whatsapp: 'whatsapp',
  location: 'location',
  latitude: 'latitude',
  longitude: 'longitude',
});

const CAR_COLUMNS = `c.id, c.owner_id, c.brand, c.model, c.year, c.price, c.currency, c.mileage, c.transmission, c.fuel_type, c.color,
       c.description, c.phone, c.whatsapp, c.location, c.latitude, c.longitude, c.status, c.rejection_reason, c.suspension_reason,
       c.version, c.created_at, c.updated_at`;
const OWN = `c.owner_id = $2::bigint AND c.source_type = 'member' AND c.deleted_at IS NULL`;

interface SqlRow {
  id: string;
  owner_id: string;
  owner_active?: boolean;
  brand: string;
  model: string;
  year: number;
  price: string;
  currency: string;
  mileage: number | null;
  transmission: string;
  fuel_type: string;
  color: string;
  description: string;
  phone: string | null;
  whatsapp: string | null;
  location: string | null;
  latitude: string | null;
  longitude: string | null;
  status: string;
  rejection_reason: string | null;
  suspension_reason: string | null;
  version: number;
  created_at: Date;
  updated_at: Date;
}

const toRow = (r: SqlRow, ownerActive: boolean): MemberCarRow => ({
  id: String(r.id),
  ownerId: String(r.owner_id),
  ownerActive,
  brand: r.brand,
  model: r.model,
  year: Number(r.year),
  price: String(r.price),
  currency: r.currency,
  mileage: r.mileage === null ? null : Number(r.mileage),
  transmission: r.transmission,
  fuelType: r.fuel_type,
  color: r.color,
  description: r.description,
  phone: r.phone,
  whatsapp: r.whatsapp,
  location: r.location,
  latitude: r.latitude === null ? null : String(r.latitude),
  longitude: r.longitude === null ? null : String(r.longitude),
  status: r.status,
  rejectionReason: r.rejection_reason,
  suspensionReason: r.suspension_reason,
  version: Number(r.version),
  createdAt: r.created_at,
  updatedAt: r.updated_at,
});

/** SQL builders, exported so tests can pin their text (and run it on a real database). */
export function buildInsert(ownerId: string, f: MemberCarFields, searchText: string): { text: string; values: unknown[] } {
  return {
    text: `INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, mileage, transmission, fuel_type, color, description,
                       phone, whatsapp, location, latitude, longitude, status, search_text)
       VALUES ('member', $1::bigint, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, 'pending', $17)
       RETURNING ${CAR_COLUMNS.replace(/c\./g, '')}`,
    values: [ownerId, f.brand, f.model, f.year, f.price, f.currency, f.mileage, f.transmission, f.fuelType, f.color, f.description, f.phone, f.whatsapp, f.location, f.latitude, f.longitude, searchText],
  };
}

export function buildListOwn(ownerId: string, q: { limit: number; before: string | null; status: MemberCarStatus | null }): { text: string; values: unknown[] } {
  const values: unknown[] = [ownerId];
  const where = [`c.owner_id = $1::bigint`, `c.source_type = 'member'`, `c.deleted_at IS NULL`];
  if (q.before !== null) {
    values.push(q.before);
    where.push(`c.id < $${values.length}::bigint`);
  }
  if (q.status !== null) {
    values.push(q.status);
    where.push(`c.status = $${values.length}`);
  }
  values.push(q.limit);
  return { text: `SELECT ${CAR_COLUMNS} FROM cars c WHERE ${where.join(' AND ')} ORDER BY c.id DESC LIMIT $${values.length}`, values };
}

export function buildFindOwn(id: string, ownerId: string, lock: boolean): { text: string; values: unknown[] } {
  return {
    text: `SELECT ${CAR_COLUMNS}, (u.status = 'active' AND u.deleted_at IS NULL) AS owner_active
             FROM cars c JOIN users u ON u.id = c.owner_id
            WHERE c.id = $1::bigint AND ${OWN}${lock ? '\n              FOR UPDATE OF c' : ''}`,
    values: [id, ownerId],
  };
}

export function buildUpdate(input: { id: string; ownerId: string; expectedVersion: number; changes: Partial<MemberCarFields>; markSold: boolean; searchText: string }): { text: string; values: unknown[] } {
  const values: unknown[] = [input.id, input.ownerId, input.expectedVersion];
  const set: string[] = [];
  for (const [field, value] of Object.entries(input.changes) as Array<[MemberCarField, unknown]>) {
    if (!Object.hasOwn(COLUMN_OF, field)) throw new Error('unknown member car field');
    values.push(value);
    set.push(`${COLUMN_OF[field]} = $${values.length}`);
  }
  if (input.markSold) set.push(`status = 'sold'`);
  values.push(input.searchText);
  set.push(`search_text = $${values.length}`);
  return {
    text: `UPDATE cars c SET ${set.join(', ')}
            WHERE c.id = $1::bigint AND ${OWN} AND c.version = $3${input.markSold ? ` AND c.status = 'active'` : ''}
        RETURNING ${CAR_COLUMNS}`,
    values,
  };
}

export function buildSoftDelete(input: { id: string; ownerId: string; expectedVersion: number }): { text: string; values: unknown[] } {
  return {
    text: `UPDATE cars c SET deleted_at = now() WHERE c.id = $1::bigint AND ${OWN} AND c.version = $3`,
    values: [input.id, input.ownerId, input.expectedVersion],
  };
}

export function createPgMemberCarRepository(q: Tx): MemberCarRepository {
  const run = async (s: { text: string; values: unknown[] }) => q.query<SqlRow>(s.text, s.values);
  return {
    async lockActingUser(userId) {
      const r = await q.query(`SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`, [userId]);
      return r.rows.length === 1;
    },
    async insert(ownerId, fields, searchText) {
      const r = await run(buildInsert(ownerId, fields, searchText));
      // The acting account was re-checked and share-locked in this transaction, so the owner is active.
      return toRow(r.rows[0]!, true);
    },
    async listOwn(ownerId, query) {
      // Listing one's own ads as the (active) actor: the owner is active by construction.
      return (await run(buildListOwn(ownerId, query))).rows.map((r) => toRow(r, true));
    },
    async findOwn(id, ownerId) {
      const r = (await run(buildFindOwn(id, ownerId, false))).rows[0];
      return r ? toRow(r, r.owner_active === true) : null;
    },
    async lockOwn(id, ownerId) {
      const r = (await run(buildFindOwn(id, ownerId, true))).rows[0];
      return r ? toRow(r, r.owner_active === true) : null;
    },
    async update(input) {
      const r = (await run(buildUpdate(input))).rows[0];
      return r ? toRow(r, true) : null;
    },
    async softDelete(input) {
      const r = await run(buildSoftDelete(input));
      return (r.rowCount ?? 0) === 1;
    },
  };
}

export function createPgMemberCarStore(db: Db): MemberCarStore {
  return {
    cars: createPgMemberCarRepository(db),
    transaction: (fn) => db.tx((t) => fn({ cars: createPgMemberCarRepository(t), audit: createPgAuditRepository(t) })),
  };
}

// Input validation for a member's OWN car ads (Phase 11.5, Step 5.4).
//
// Strict whitelist: unknown fields are rejected; every value is type-, length- and range-checked against the cars table (0005)
// before it can reach SQL. There is no owner, showroom, source type, reviewer, reason, deletion or id field in any input: those are
// never client-controlled. Error objects carry a field name and a machine code only, never the submitted value.
//
// Vocabularies (currency, transmission, fuel type, year and price bounds) are shared with the public catalog so the two can never
// drift; this module only imports them.
import { normalizeIraqiPhone } from '../auth/phone.ts';
import type { FieldCode, FieldError, Parsed } from '../auth/validation.ts';
import { CURRENCIES, FUEL_TYPES, PRICE_MAX, TRANSMISSIONS, YEAR_MAX, YEAR_MIN, isBigintId } from '../catalog/params.ts';

/** Lengths in characters, exactly the varchar sizes of the cars table. */
export const BRAND_MAX = 50;
export const MODEL_MAX = 80;
export const COLOR_MAX = 40;
export const DESCRIPTION_MAX = 2000;
export const LOCATION_MAX = 200;
/** PROPOSED: an upper bound that rejects obvious typos (the column only forbids negatives). */
export const MILEAGE_MAX = 10_000_000;
export const MEMBER_CAR_LIMIT_DEFAULT = 20;
export const MEMBER_CAR_LIMIT_MAX = 50;
/** Every state a member car can be in (the table's CHECK). Used only to FILTER the owner's own list. */
export const MEMBER_CAR_STATUSES = ['pending', 'active', 'sold', 'rejected', 'suspended'] as const;
export type MemberCarStatus = (typeof MEMBER_CAR_STATUSES)[number];

const MAX_ERRORS = 10;
const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;
// The description may contain line breaks (\n); every other control character is refused.
// eslint-disable-next-line no-control-regex
const CONTROL_EXCEPT_NEWLINE = /[\u0000-\u0009\u000b-\u001f\u007f-\u009f\u2028\u2029]/;
const HAS_LETTER_OR_DIGIT = /[\p{L}\p{N}]/u;
const COORD_DECIMALS = 6; // numeric(9,6)

/** The fields of a car ad a member writes. Everything else in the row is set by the server. */
export interface MemberCarFields {
  brand: string;
  model: string;
  year: number;
  price: number;
  currency: (typeof CURRENCIES)[number];
  mileage: number | null;
  transmission: (typeof TRANSMISSIONS)[number];
  fuelType: (typeof FUEL_TYPES)[number];
  color: string;
  description: string;
  /** Canonical E.164 (+9647XXXXXXXXX). */
  phone: string;
  whatsapp: string | null;
  location: string;
  /** Decimal strings with at most 6 decimals (numeric(9,6)), or both null. */
  latitude: string | null;
  longitude: string | null;
}
export type MemberCarField = keyof MemberCarFields;

export interface CreateInput {
  fields: MemberCarFields;
}
export interface UpdateInput {
  /** The version the client last saw (optimistic concurrency). Required. */
  version: number;
  /** Only the fields present in the request. */
  changes: Partial<MemberCarFields>;
  /** The only status an owner may set here: 'sold' (from 'active'). Anything that would publish is NOT accepted (decision D1). */
  status: 'sold' | null;
}
export interface ListQuery {
  limit: number;
  before: string | null;
  status: MemberCarStatus | null;
}

const FIELD_KEYS: readonly MemberCarField[] = [
  'brand', 'model', 'year', 'price', 'currency', 'mileage', 'transmission', 'fuelType', 'color', 'description', 'phone', 'whatsapp',
  'location', 'latitude', 'longitude',
];
const CREATE_KEYS: readonly string[] = FIELD_KEYS;
const UPDATE_KEYS: readonly string[] = [...FIELD_KEYS, 'version', 'status'];
const REQUIRED_ON_CREATE: readonly MemberCarField[] = ['brand', 'model', 'year', 'price', 'currency', 'phone'];

class Errors {
  readonly list: FieldError[] = [];
  add(field: string, code: FieldCode): void {
    this.list.push({ field, code });
  }
  get any(): boolean {
    return this.list.length > 0;
  }
  fail<T>(): Parsed<T> {
    return { ok: false, errors: this.list.slice(0, MAX_ERRORS) };
  }
}

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
const has = (o: Record<string, unknown>, k: string): boolean => Object.hasOwn(o, k);
const chars = (s: string): number => Array.from(s).length;

function rejectUnknown(body: Record<string, unknown>, allowed: readonly string[], e: Errors): void {
  for (const k of Object.keys(body)) if (!allowed.includes(k)) e.add(SAFE_FIELD.test(k) ? k : 'unknown', 'unknown_field');
}

/** A short single-line text: NFC, trimmed, inner whitespace collapsed, no control characters, at most `max` characters. */
function shortText(e: Errors, field: string, v: unknown, max: number, opts: { min1: boolean; needsWord: boolean }): string | undefined {
  if (typeof v !== 'string') return void e.add(field, 'invalid_type');
  if (CONTROL.test(v)) return void e.add(field, 'invalid_format');
  const t = v.normalize('NFC').replace(/\s+/g, ' ').trim();
  if (opts.min1 && t === '') return void e.add(field, 'required');
  if (chars(t) > max) return void e.add(field, 'too_long');
  if (opts.needsWord && !HAS_LETTER_OR_DIGIT.test(t)) return void e.add(field, 'invalid_format');
  return t;
}

function description(e: Errors, v: unknown): string | undefined {
  if (typeof v !== 'string') return void e.add('description', 'invalid_type');
  const t = v.normalize('NFC').replace(/\r\n/g, '\n').trim();
  if (CONTROL_EXCEPT_NEWLINE.test(t)) return void e.add('description', 'invalid_format');
  if (chars(t) > DESCRIPTION_MAX) return void e.add('description', 'too_long');
  return t;
}

function integer(e: Errors, field: string, v: unknown, min: number, max: number): number | undefined {
  if (typeof v !== 'number') return void e.add(field, 'invalid_type');
  if (!Number.isSafeInteger(v) || v < min || v > max) return void e.add(field, 'invalid_format');
  return v;
}

function oneOf<T extends string>(e: Errors, field: string, v: unknown, allowed: readonly T[]): T | undefined {
  if (typeof v !== 'string') return void e.add(field, 'invalid_type');
  if (!(allowed as readonly string[]).includes(v)) return void e.add(field, 'invalid_format');
  return v as T;
}

function phone(e: Errors, field: string, v: unknown): string | undefined {
  if (typeof v !== 'string') return void e.add(field, 'invalid_type');
  const p = normalizeIraqiPhone(v);
  if (!p) return void e.add(field, 'invalid_format');
  return p;
}

function coordinate(e: Errors, field: string, v: unknown, limit: number): string | undefined {
  if (typeof v !== 'number') return void e.add(field, 'invalid_type');
  if (!Number.isFinite(v) || v < -limit || v > limit) return void e.add(field, 'invalid_format');
  // Fixed 6 decimals, as numeric(9,6) stores it: what is returned is exactly what was stored.
  return v.toFixed(COORD_DECIMALS);
}

/**
 * Parses the member-writable fields present in `body`. `nullable` lists the optional fields a client may clear with null.
 * Returns only the fields that were present (absent fields are left to the caller: defaults on create, unchanged on update).
 */
function parseFields(body: Record<string, unknown>, e: Errors): Partial<MemberCarFields> {
  const out: Partial<MemberCarFields> = {};
  if (has(body, 'brand')) {
    const v = shortText(e, 'brand', body['brand'], BRAND_MAX, { min1: true, needsWord: true });
    if (v !== undefined) out.brand = v;
  }
  if (has(body, 'model')) {
    const v = shortText(e, 'model', body['model'], MODEL_MAX, { min1: true, needsWord: true });
    if (v !== undefined) out.model = v;
  }
  if (has(body, 'year')) {
    const v = integer(e, 'year', body['year'], YEAR_MIN, YEAR_MAX);
    if (v !== undefined) out.year = v;
  }
  if (has(body, 'price')) {
    const v = integer(e, 'price', body['price'], 1, PRICE_MAX);
    if (v !== undefined) out.price = v;
  }
  if (has(body, 'currency')) {
    const v = oneOf(e, 'currency', body['currency'], CURRENCIES);
    if (v !== undefined) out.currency = v;
  }
  if (has(body, 'mileage')) {
    if (body['mileage'] === null) out.mileage = null; // unknown (not 0)
    else {
      const v = integer(e, 'mileage', body['mileage'], 0, MILEAGE_MAX);
      if (v !== undefined) out.mileage = v;
    }
  }
  if (has(body, 'transmission')) {
    const v = oneOf(e, 'transmission', body['transmission'], TRANSMISSIONS);
    if (v !== undefined) out.transmission = v;
  }
  if (has(body, 'fuelType')) {
    const v = oneOf(e, 'fuelType', body['fuelType'], FUEL_TYPES);
    if (v !== undefined) out.fuelType = v;
  }
  if (has(body, 'color')) {
    const v = shortText(e, 'color', body['color'], COLOR_MAX, { min1: false, needsWord: false });
    if (v !== undefined) out.color = v;
  }
  if (has(body, 'description')) {
    const v = description(e, body['description']);
    if (v !== undefined) out.description = v;
  }
  if (has(body, 'phone')) {
    const v = phone(e, 'phone', body['phone']);
    if (v !== undefined) out.phone = v;
  }
  if (has(body, 'whatsapp')) {
    if (body['whatsapp'] === null) out.whatsapp = null;
    else {
      const v = phone(e, 'whatsapp', body['whatsapp']);
      if (v !== undefined) out.whatsapp = v;
    }
  }
  if (has(body, 'location')) {
    const v = shortText(e, 'location', body['location'], LOCATION_MAX, { min1: false, needsWord: false });
    if (v !== undefined) out.location = v;
  }
  // Coordinates travel as a pair (the table's cars_geo_pair): both numbers, or both null to clear.
  const hasLat = has(body, 'latitude');
  const hasLng = has(body, 'longitude');
  if (hasLat || hasLng) {
    if (hasLat !== hasLng) e.add(hasLat ? 'longitude' : 'latitude', 'required');
    else if (body['latitude'] === null && body['longitude'] === null) {
      out.latitude = null;
      out.longitude = null;
    } else if (body['latitude'] === null || body['longitude'] === null) {
      e.add(body['latitude'] === null ? 'latitude' : 'longitude', 'invalid_type');
    } else {
      const lat = coordinate(e, 'latitude', body['latitude'], 90);
      const lng = coordinate(e, 'longitude', body['longitude'], 180);
      if (lat !== undefined && lng !== undefined) {
        out.latitude = lat;
        out.longitude = lng;
      }
    }
  }
  return out;
}

export function parseCreateInput(body: unknown): Parsed<CreateInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(body, CREATE_KEYS, e);
  for (const k of REQUIRED_ON_CREATE) if (!has(body, k) || body[k] === null || body[k] === undefined) e.add(k, 'required');
  const p = parseFields(
    Object.fromEntries(Object.entries(body).filter(([k, v]) => CREATE_KEYS.includes(k) && !(REQUIRED_ON_CREATE.includes(k as MemberCarField) && (v === null || v === undefined)))),
    e,
  );
  if (e.any) return e.fail();
  const phoneE164 = p.phone!;
  return {
    ok: true,
    value: {
      fields: {
        brand: p.brand!,
        model: p.model!,
        year: p.year!,
        price: p.price!,
        currency: p.currency!,
        mileage: p.mileage ?? null,
        transmission: p.transmission ?? 'أوتوماتيك',
        fuelType: p.fuelType ?? 'بنزين',
        color: p.color ?? '',
        description: p.description ?? '',
        phone: phoneE164,
        // As the prototype: no WhatsApp given = the phone number (an explicit null keeps it empty).
        whatsapp: has(body, 'whatsapp') ? (p.whatsapp ?? null) : phoneE164,
        location: p.location ?? '',
        latitude: p.latitude ?? null,
        longitude: p.longitude ?? null,
      },
    },
  };
}

export function parseUpdateInput(body: unknown): Parsed<UpdateInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(body, UPDATE_KEYS, e);
  let version: number | undefined;
  if (!has(body, 'version') || body['version'] === null) e.add('version', 'required');
  else version = integer(e, 'version', body['version'], 1, 2_147_483_647);
  // Required fields cannot be cleared; optional ones are cleared with null (handled in parseFields).
  for (const k of REQUIRED_ON_CREATE) if (has(body, k) && body[k] === null) e.add(k, 'invalid_type');
  const changes = parseFields(Object.fromEntries(Object.entries(body).filter(([k, v]) => FIELD_KEYS.includes(k as MemberCarField) && !(REQUIRED_ON_CREATE.includes(k as MemberCarField) && v === null))), e);
  let status: 'sold' | null = null;
  if (has(body, 'status')) {
    // Only marking an ad as sold is an owner action in this step. Publishing (-> active) waits for verified rewarded ads (D1).
    const v = oneOf(e, 'status', body['status'], ['sold'] as const);
    if (v !== undefined) status = v;
  }
  if (!e.any && Object.keys(changes).length === 0 && status === null) e.add('body', 'required');
  if (e.any) return e.fail();
  return { ok: true, value: { version: version!, changes, status } };
}

/** The `version` a DELETE must name (query string), so a stale client cannot delete an ad it has not seen the latest of. */
export function parseDeleteQuery(query: unknown): Parsed<{ version: number }> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(q, ['version'], e);
  const raw = q['version'];
  let version: number | undefined;
  if (raw === undefined) e.add('version', 'required');
  else if (typeof raw !== 'string') e.add('version', 'invalid_type');
  else if (!/^[1-9][0-9]{0,9}$/.test(raw) || Number(raw) > 2_147_483_647) e.add('version', 'invalid_format');
  else version = Number(raw);
  if (e.any) return e.fail();
  return { ok: true, value: { version: version! } };
}

export function parseListQuery(query: unknown): Parsed<ListQuery> {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const e = new Errors();
  rejectUnknown(q, ['limit', 'before', 'status'], e);
  let limit = MEMBER_CAR_LIMIT_DEFAULT;
  const l = q['limit'];
  if (l !== undefined) {
    if (typeof l !== 'string') e.add('limit', 'invalid_type');
    else if (!/^[1-9][0-9]{0,2}$/.test(l) || Number(l) > MEMBER_CAR_LIMIT_MAX) e.add('limit', 'invalid_format');
    else limit = Number(l);
  }
  let before: string | null = null;
  const b = q['before'];
  if (b !== undefined) {
    if (typeof b !== 'string') e.add('before', 'invalid_type');
    else if (!isBigintId(b)) e.add('before', 'invalid_format');
    else before = b;
  }
  let status: MemberCarStatus | null = null;
  if (q['status'] !== undefined) {
    const v = oneOf(e, 'status', q['status'], MEMBER_CAR_STATUSES);
    if (v !== undefined) status = v;
  }
  if (e.any) return e.fail();
  return { ok: true, value: { limit, before, status } };
}

/** A path id: a canonical positive id that fits bigint, else null (the caller answers 404, never 400: no existence oracle). */
export function parseCarId(raw: unknown): string | null {
  return typeof raw === 'string' && isBigintId(raw) ? raw : null;
}

// PostgreSQL access layer. The driver (`pg`) is loaded lazily and injected through a factory, so everything
// here is unit-testable without a database. Rules:
//   - parameterized queries only (values are never interpolated into SQL),
//   - errors are classified into DbError (no SQL/parameters/row values),
//   - every connection gets statement/lock/idle-in-transaction timeouts as startup parameters,
//   - transactions always release their client exactly once.
import type { DbConfig } from './config.ts';
import { DbError, describeError, isDriverError, mapDriverError } from './errors.ts';
import { ROLE_QUERY, parseRoleRow } from './role.ts';
import type { RoleReport } from './role.ts';
import { REQUIRED_TABLES, REQUIRED_VIEWS } from './schema-contract.ts';
import { nullLogger } from './types.ts';
import type { Logger } from './types.ts';

export interface QueryResultLike<R> {
  rows: R[];
  rowCount: number | null;
}

export interface PoolClientLike {
  query<R = Record<string, unknown>>(text: string, values?: readonly unknown[]): Promise<QueryResultLike<R>>;
  release(err?: Error | boolean): void;
}

export interface PoolLike {
  query<R = Record<string, unknown>>(text: string, values?: readonly unknown[]): Promise<QueryResultLike<R>>;
  connect(): Promise<PoolClientLike>;
  end(): Promise<void>;
  on(event: 'error', listener: (err: Error) => void): unknown;
  readonly totalCount: number;
  readonly idleCount: number;
  readonly waitingCount: number;
}

export type PoolFactory = (cfg: DbConfig) => Promise<PoolLike>;

type PoolCtor = new (options: Record<string, unknown>) => PoolLike;
export interface PgModuleLike {
  default?: { Pool: PoolCtor };
  Pool?: PoolCtor;
}

export interface Tx {
  query<R = Record<string, unknown>>(text: string, values?: readonly unknown[]): Promise<QueryResultLike<R>>;
}

export interface Db extends Tx {
  tx<T>(fn: (t: Tx) => Promise<T>): Promise<T>;
  ping(): Promise<void>;
  verifyRole(): Promise<RoleReport>;
  checkSchema(): Promise<{ missing: string[] }>;
  stats(): { total: number; idle: number; waiting: number };
  close(): Promise<void>;
}

// DbConfig -> node-postgres Pool options. The timeouts are startup parameters, so they apply from the first statement.
export function toPoolOptions(cfg: DbConfig): Record<string, unknown> {
  let ssl: false | { rejectUnauthorized: boolean; ca?: string };
  if (cfg.ssl === 'disable') ssl = false;
  else if (cfg.ssl === 'require') ssl = { rejectUnauthorized: false };
  else ssl = { rejectUnauthorized: true, ...(cfg.sslCa ? { ca: cfg.sslCa } : {}) };
  return {
    host: cfg.host,
    port: cfg.port,
    database: cfg.database,
    user: cfg.user,
    password: cfg.password,
    ssl,
    max: cfg.poolMax,
    idleTimeoutMillis: cfg.idleTimeoutMs,
    connectionTimeoutMillis: cfg.connectTimeoutMs,
    statement_timeout: cfg.statementTimeoutMs,
    lock_timeout: cfg.lockTimeoutMs,
    idle_in_transaction_session_timeout: cfg.idleInTxTimeoutMs,
    application_name: cfg.applicationName,
  };
}

export function createPoolFactory(
  importPg: () => Promise<PgModuleLike> = () => import('pg') as unknown as Promise<PgModuleLike>,
): PoolFactory {
  return async (cfg) => {
    const mod = await importPg();
    const Pool = mod.default?.Pool ?? mod.Pool;
    if (!Pool) throw new Error('the "pg" package does not expose a Pool class');
    return new Pool(toPoolOptions(cfg));
  };
}

export const defaultPoolFactory: PoolFactory = createPoolFactory();

export async function createDb(cfg: DbConfig, deps: { poolFactory?: PoolFactory; logger?: Logger } = {}): Promise<Db> {
  const logger = deps.logger ?? nullLogger;
  const pool = await (deps.poolFactory ?? defaultPoolFactory)(cfg);
  let closed = false;

  // An error on an idle pooled client must never crash the process.
  pool.on('error', (err) => logger.error({ err: describeError(err) }, 'idle database client error'));

  const assertOpen = (): void => {
    if (closed) throw new DbError('unavailable', { driverMessage: 'database handle is closed' });
  };
  // Driver/network errors become DbError; programming errors (TypeError, ...) pass through unchanged.
  const wrap = (e: unknown): unknown => (isDriverError(e) ? mapDriverError(e) : e);

  async function query<R = Record<string, unknown>>(text: string, values: readonly unknown[] = []): Promise<QueryResultLike<R>> {
    assertOpen();
    try {
      return await pool.query<R>(text, values);
    } catch (e) {
      throw wrap(e);
    }
  }

  async function tx<T>(fn: (t: Tx) => Promise<T>): Promise<T> {
    assertOpen();
    let client: PoolClientLike;
    try {
      client = await pool.connect();
    } catch (e) {
      throw wrap(e);
    }
    let active = true;
    let released = false;
    const release = (err?: Error): void => {
      if (released) return;
      released = true;
      client.release(err);
    };
    const scoped: Tx = {
      query: async <R = Record<string, unknown>>(text: string, values: readonly unknown[] = []): Promise<QueryResultLike<R>> => {
        if (!active) throw new Error('transaction is no longer active');
        try {
          return await client.query<R>(text, values);
        } catch (e) {
          throw wrap(e);
        }
      },
    };
    try {
      await client.query('BEGIN');
      const result = await fn(scoped);
      await client.query('COMMIT');
      active = false;
      release();
      return result;
    } catch (e) {
      active = false;
      let rollbackFailed: Error | undefined;
      try {
        await client.query('ROLLBACK');
      } catch (re) {
        rollbackFailed = new Error('rollback failed');
        logger.error({ err: describeError(re) }, 'rollback failed; discarding the connection');
      }
      // Passing an error to release() makes node-postgres destroy the connection instead of reusing it.
      release(rollbackFailed);
      throw wrap(e);
    }
  }

  async function ping(): Promise<void> {
    const r = await query<{ ok: number }>('SELECT 1 AS ok');
    if (r.rows[0]?.ok !== 1) throw new DbError('unknown', { driverMessage: 'unexpected ping result' });
  }

  async function verifyRole(): Promise<RoleReport> {
    const r = await query(ROLE_QUERY);
    return parseRoleRow(r.rows[0]);
  }

  async function checkSchema(): Promise<{ missing: string[] }> {
    const names = [...REQUIRED_TABLES, ...REQUIRED_VIEWS];
    const r = await query<{ name: string; present: boolean }>(
      `SELECT n AS name, to_regclass('public.' || quote_ident(n)) IS NOT NULL AS present FROM unnest($1::text[]) AS n`,
      [names],
    );
    return { missing: r.rows.filter((row) => row.present !== true).map((row) => row.name) };
  }

  return {
    query,
    tx,
    ping,
    verifyRole,
    checkSchema,
    stats: () => ({ total: pool.totalCount, idle: pool.idleCount, waiting: pool.waitingCount }),
    async close() {
      if (closed) return;
      closed = true;
      await pool.end();
    },
  };
}

// The delivery channel for one-time codes. Only the interface and a "not configured" implementation live here: production
// SMS/WhatsApp integration is a later step. The code is passed to `send` because it must be delivered; it is never logged,
// stored in clear, or included in any error by this codebase. Implementations must not log it either.
import type { OtpPurpose } from '../auth/otp.ts';

export interface OtpMessage {
  /** Canonical E.164. */
  phone: string;
  purpose: OtpPurpose;
  code: string;
  ttlSeconds: number;
}

export interface MessagingProvider {
  send(message: OtpMessage): Promise<void>;
}

export class ProviderNotConfiguredError extends Error {
  constructor() {
    super('no messaging provider is configured');
    this.name = 'ProviderNotConfiguredError';
  }
}

/** Fails every send. The OTP flows still work end to end; nothing is delivered until a real provider is wired in. */
export function createUnconfiguredMessagingProvider(): MessagingProvider {
  return {
    async send() {
      throw new ProviderNotConfiguredError();
    },
  };
}

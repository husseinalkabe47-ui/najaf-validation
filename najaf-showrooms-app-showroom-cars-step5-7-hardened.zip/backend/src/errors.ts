// Driver error classification. A DbError carries only safe metadata: never SQL text, parameters, or row values.

export type DbErrorKind =
  | 'unique'
  | 'foreign_key'
  | 'check'
  | 'not_null'
  | 'invalid_value'
  | 'forbidden'
  | 'timeout'
  | 'serialization'
  | 'deadlock'
  | 'unavailable'
  | 'auth_failed'
  | 'unknown';

const GENERIC_MESSAGE: Record<DbErrorKind, string> = {
  unique: 'database operation failed: unique violation',
  foreign_key: 'database operation failed: foreign key violation',
  check: 'database operation failed: constraint violation',
  not_null: 'database operation failed: missing required value',
  invalid_value: 'database operation failed: invalid value',
  forbidden: 'database operation failed: permission denied',
  timeout: 'database operation failed: timeout',
  serialization: 'database operation failed: serialization failure',
  deadlock: 'database operation failed: deadlock detected',
  unavailable: 'database is unavailable',
  auth_failed: 'database authentication failed',
  unknown: 'database operation failed',
};

const SQLSTATE_KIND: Record<string, DbErrorKind> = {
  '23505': 'unique',
  '23503': 'foreign_key',
  '23001': 'foreign_key',
  '23514': 'check',
  '23502': 'not_null',
  '42501': 'forbidden',
  '57014': 'timeout',
  '55P03': 'timeout',
  '40001': 'serialization',
  '40P01': 'deadlock',
  '28P01': 'auth_failed',
  '28000': 'auth_failed',
  '57P01': 'unavailable',
  '57P02': 'unavailable',
  '57P03': 'unavailable',
  '53300': 'unavailable',
  '3D000': 'unavailable',
};

const NETWORK_CODES = new Set([
  'ECONNREFUSED',
  'ECONNRESET',
  'ECONNABORTED',
  'ENOTFOUND',
  'EAI_AGAIN',
  'ETIMEDOUT',
  'EPIPE',
  'EHOSTUNREACH',
  'ENETUNREACH',
]);

// Messages node-postgres raises without an SQLSTATE when the connection itself fails.
const UNAVAILABLE_MESSAGES = [
  'timeout exceeded when trying to connect',
  'Connection terminated',
  'Client has encountered a connection error',
  'Cannot use a pool after calling end on the pool',
  'Client was closed',
  'connect ECONNREFUSED',
];

export class DbError extends Error {
  readonly kind: DbErrorKind;
  readonly sqlstate: string | undefined;
  readonly constraint: string | undefined;
  // Original driver message: for server-side logs only; it never reaches HTTP responses or toJSON().
  readonly driverMessage: string | undefined;

  constructor(kind: DbErrorKind, init: { sqlstate?: string; constraint?: string; driverMessage?: string } = {}) {
    super(GENERIC_MESSAGE[kind]);
    this.name = 'DbError';
    this.kind = kind;
    this.sqlstate = init.sqlstate;
    this.constraint = init.constraint;
    this.driverMessage = init.driverMessage;
  }

  get retryable(): boolean {
    return this.kind === 'serialization' || this.kind === 'deadlock';
  }

  toJSON(): { name: string; kind: DbErrorKind; sqlstate: string | undefined; constraint: string | undefined } {
    return { name: this.name, kind: this.kind, sqlstate: this.sqlstate, constraint: this.constraint };
  }
}

function field(e: object, name: string): unknown {
  return (e as Record<string, unknown>)[name];
}

// True only for errors that come from the PostgreSQL driver or the network, never for programming errors.
export function isDriverError(e: unknown): boolean {
  if (typeof e !== 'object' || e === null) return false;
  const code = field(e, 'code');
  if (typeof code === 'string') {
    if (NETWORK_CODES.has(code)) return true;
    // pg DatabaseError instances always carry severity/routine next to the SQLSTATE in `code`.
    if (typeof field(e, 'severity') === 'string' || typeof field(e, 'routine') === 'string') return true;
  }
  const msg = field(e, 'message');
  return typeof msg === 'string' && UNAVAILABLE_MESSAGES.some((m) => msg.startsWith(m));
}

export function mapDriverError(e: unknown): DbError {
  const obj = (typeof e === 'object' && e !== null ? e : {}) as object;
  const code = field(obj, 'code');
  const constraint = field(obj, 'constraint');
  const message = field(obj, 'message');
  const init = {
    ...(typeof code === 'string' ? { sqlstate: code } : {}),
    ...(typeof constraint === 'string' ? { constraint } : {}),
    ...(typeof message === 'string' ? { driverMessage: message } : {}),
  };
  if (typeof code === 'string') {
    if (NETWORK_CODES.has(code)) return new DbError('unavailable', init);
    const direct = SQLSTATE_KIND[code];
    if (direct) return new DbError(direct, init);
    if (code.startsWith('08')) return new DbError('unavailable', init);
    if (code.startsWith('22')) return new DbError('invalid_value', init);
    if (code.startsWith('23')) return new DbError('check', init);
    if (code.startsWith('28')) return new DbError('auth_failed', init);
  }
  if (typeof message === 'string' && UNAVAILABLE_MESSAGES.some((m) => message.startsWith(m))) return new DbError('unavailable', init);
  return new DbError('unknown', init);
}

// Log-safe description of any error.
export function describeError(e: unknown): Record<string, unknown> {
  if (e instanceof DbError) return { ...e.toJSON(), driverMessage: e.driverMessage };
  if (e instanceof Error) return { name: e.name, message: e.message };
  return { message: String(e) };
}

// Input validation for the images of a member's OWN car (Phase 11.5, Step 5.5).
//
// The only client input is the id of an asset to attach. Strict whitelist: unknown fields are rejected, the id must be a canonical
// UUID. There is no car id, owner id, sort order, main flag, storage key or URL in any input: the car comes from the path (and is
// then checked against the actor), the position and the main image are decided by the server. Error objects carry a field name and
// a machine code only, never the submitted value.
import type { FieldError, Parsed } from '../auth/validation.ts';
import { isBigintId } from '../catalog/params.ts';

const SAFE_FIELD = /^[A-Za-z0-9_]{1,40}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

export interface AddImageInput {
  /** Lower-case canonical UUID of a READY car_image asset owned by the caller. */
  assetId: string;
}

export function parseAddImageInput(body: unknown): Parsed<AddImageInput> {
  if (!isPlainObject(body)) return { ok: false, errors: [{ field: 'body', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  for (const k of Object.keys(body)) if (k !== 'assetId') errors.push({ field: SAFE_FIELD.test(k) ? k : 'unknown', code: 'unknown_field' });
  const raw = body['assetId'];
  let assetId: string | undefined;
  if (raw === undefined || raw === null) errors.push({ field: 'assetId', code: 'required' });
  else if (typeof raw !== 'string') errors.push({ field: 'assetId', code: 'invalid_type' });
  else if (!UUID.test(raw)) errors.push({ field: 'assetId', code: 'invalid_format' });
  else assetId = raw.toLowerCase();
  if (errors.length > 0 || assetId === undefined) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { assetId } };
}

/** A path id (image): a canonical positive id that fits bigint, else null (the caller answers 404, never 400). */
export function parseImageId(raw: unknown): string | null {
  return typeof raw === 'string' && isBigintId(raw) ? raw : null;
}

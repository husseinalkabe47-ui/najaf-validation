// Images of a member's OWN car (Phase 11.5, Step 5.5): add, list, delete.
//
// Decisions (each is covered by tests):
//  - WHO acts is an Actor from src/authz. The car is addressed by the path, but it is only ever FOUND as the actor's own member car
//    (owner_id = actor, not deleted), then re-checked (row.ownerId === actor.id) and authorized with the existing policy (update
//    for add/delete, read for list). Anyone else (another member, a dealer, an administrator, no actor) and any unknown, deleted or
//    malformed car id get the same 404. The owner is never an input.
//  - car -> car_images -> assets: an image is found only through the authorized car (an image id of ANOTHER car is 404, even if the
//    caller owns that car too), and an asset is found only if the CALLER owns it (another user's asset is 404, same as unknown).
//  - What "add" means: it attaches an existing, READY, car_image asset of the caller to the car. Creating assets (upload, image
//    processing, object storage) is a later step; this service never touches file bytes or storage keys, and no response carries
//    them. An asset that is not ready, not a car image, or already attached is 409 invalid_state.
//  - Limits: the per-car cap is read from app_settings 'images.max_per_car' (member: 4), the very value the database trigger
//    enforces; reaching it is 409 image_limit. The check runs under the car's row lock, so concurrent adds cannot exceed it.
//  - Layout is decided by the server: a new image goes last and is main if it is the first; deleting the main image promotes the
//    first remaining one; positions stay contiguous. Everything in ONE transaction with the acting account re-checked and the audit row.
//  - Delete removes the LINK only. The asset stays (ready, unattached, owned by the caller) for the cleanup job that also deletes the
//    stored files; deleting the row here would orphan files in a storage that is not integrated yet.
//  - Car rows are never written here (their version is untouched): this step does not change the Step 5.4 behavior.
import { authorize, memberCarResource, notFound } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import type { FieldError } from '../auth/validation.ts';
import { parseCarId } from '../member-cars/validation.ts';
import type { CarImageRepository, CarImageRow, CarImageStore, OwnCarRow } from './repository.ts';
import { parseAddImageInput, parseImageId } from './validation.ts';
import { DbError } from '../errors.ts';

export type CarImageErrorCode = 'validation_failed' | 'image_limit' | 'invalid_state';
const MESSAGES: Record<CarImageErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  image_limit: 'The ad already has the maximum number of images',
  invalid_state: 'The image cannot be attached in its current state',
};
export class CarImageError extends Error {
  readonly code: CarImageErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: CarImageErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'CarImageError';
    this.code = code;
    this.fields = fields;
  }
}

/** What the owner sees of an image: ids and layout only. No storage key, thumbnail key, checksum or owner. */
export interface OwnCarImage {
  id: string;
  assetId: string;
  sortOrder: number;
  isMain: boolean;
  width: number | null;
  height: number | null;
  createdAt: string;
}
export interface OwnCarImages {
  images: OwnCarImage[];
  maxImages: number;
}
export interface RequestContext {
  requestId?: string | undefined;
}

export interface CarImageApi {
  add(actor: Actor | null, rawCarId: unknown, body: unknown, ctx?: RequestContext): Promise<OwnCarImage>;
  list(actor: Actor | null, rawCarId: unknown): Promise<OwnCarImages>;
  remove(actor: Actor | null, rawCarId: unknown, rawImageId: unknown, ctx?: RequestContext): Promise<void>;
}

export const toOwnCarImage = (r: CarImageRow): OwnCarImage => ({
  id: r.id,
  assetId: r.assetId,
  sortOrder: r.sortOrder,
  isMain: r.isMain,
  width: r.width,
  height: r.height,
  createdAt: r.createdAt.toISOString(),
});

/** users.role vocabulary for the audit table (the policy says 'member', the table says 'user'). */
const auditRole = (a: Actor): string => (a.role === 'member' ? 'user' : a.role);

/** The single ownership gate for a loaded car: the actor's own, AND allowed by the policy. Anything else is 404. */
function assertOwnCar(actor: Actor, car: OwnCarRow | null, action: 'read' | 'update'): OwnCarRow {
  if (!car || car.ownerId !== actor.id) throw notFound();
  authorize(actor, action, memberCarResource({ ownerId: car.ownerId, status: car.status, ownerActive: car.ownerActive, deleted: false }));
  return car;
}

async function lockOwnCar(images: CarImageRepository, actor: Actor, carId: string): Promise<OwnCarRow> {
  if (!(await images.lockActingUser(actor.id))) throw notFound();
  return assertOwnCar(actor, await images.lockOwnCar(carId, actor.id), 'update');
}

export function createCarImageService(deps: { store: CarImageStore }): CarImageApi {
  const { store } = deps;

  return {
    async add(actor, rawCarId, body, ctx = {}) {
      const carId = parseCarId(rawCarId);
      if (!actor || carId === null) throw notFound();
      const parsed = parseAddImageInput(body);
      if (!parsed.ok) throw new CarImageError('validation_failed', parsed.errors);
      const { assetId } = parsed.value;
      try {
        return await store.transaction(async ({ images, audit }) => {
          const car = await lockOwnCar(images, actor, carId);
          // The caller's OWN asset only: another user's asset is indistinguishable from an unknown one.
          const asset = await images.findOwnAsset(assetId, actor.id);
          if (!asset) throw notFound();
          if (asset.kind !== 'car_image' || asset.status !== 'ready' || asset.attachedCarId !== null) throw new CarImageError('invalid_state');
          const [count, cap] = [await images.countImages(car.id), await images.memberImageCap()];
          if (count >= cap) throw new CarImageError('image_limit');
          const row = await images.insertImage(car.id, assetId);
          await audit.record({
            action: 'member_car.image_add',
            actorUserId: actor.id,
            actorRole: auditRole(actor),
            entityType: 'car',
            entityId: car.id,
            afterData: { imageId: Number(row.id), images: count + 1 },
            requestId: ctx.requestId,
          });
          return toOwnCarImage(row);
        });
      } catch (e) {
        // A concurrent attach of the same asset (the UNIQUE asset_id decides): the asset is no longer free.
        if (e instanceof DbError && e.kind === 'unique') throw new CarImageError('invalid_state');
        throw e;
      }
    },

    async list(actor, rawCarId) {
      const carId = parseCarId(rawCarId);
      if (!actor || carId === null) throw notFound();
      const car = assertOwnCar(actor, await store.images.findOwnCar(carId, actor.id), 'read');
      const [rows, cap] = [await store.images.listImages(car.id), await store.images.memberImageCap()];
      return { images: rows.map(toOwnCarImage), maxImages: cap };
    },

    async remove(actor, rawCarId, rawImageId, ctx = {}) {
      const carId = parseCarId(rawCarId);
      const imageId = parseImageId(rawImageId);
      if (!actor || carId === null || imageId === null) throw notFound();
      await store.transaction(async ({ images, audit }) => {
        const car = await lockOwnCar(images, actor, carId);
        // Scoped by the authorized car: an image of any other car (even the caller's own) is simply not found.
        const removed = await images.deleteImage(imageId, car.id);
        if (!removed) throw notFound();
        await images.repairLayout(car.id);
        await audit.record({
          action: 'member_car.image_delete',
          actorUserId: actor.id,
          actorRole: auditRole(actor),
          entityType: 'car',
          entityId: car.id,
          afterData: { imageId: Number(imageId), images: await images.countImages(car.id) },
          requestId: ctx.requestId,
        });
      });
    },
  };
}

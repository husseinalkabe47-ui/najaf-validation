// PostgreSQL access for the images of a member's OWN car (Phase 11.5, Step 5.5). Rules, as in the other repositories:
//  - every statement is parameterized; kinds and statuses a statement requires are SQL literals;
//  - the CAR is always found by `owner_id = <the verified actor's id>` AND `source_type = 'member'` AND not deleted, and is locked
//    FOR UPDATE for every write (this also serializes with the database trigger car_images_guard, which locks the same row);
//  - the ASSET is always found by `owner_id = <the actor's id>`: another user's asset is simply not found;
//  - an image is always found by (image id AND the car id of the already-authorized car): an image of another car is not found;
//  - only privileges of migrations 0012/0013 are used: INSERT/DELETE on car_images, UPDATE of sort_order and is_main only. Nothing
//    here writes car_id, asset_id, assets, or the cars table;
//  - no SELECT *; storage_key, thumb_key and sha256 of an asset are never read.
// Audit rows reuse the single audit writer of auth/repository.ts (inside the same transaction).
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository } from '../auth/repository.ts';
import type { AuditRepository } from '../auth/repository.ts';

export const MEMBER_IMAGE_CAP_DEFAULT = 4;

export interface OwnCarRow {
  id: string;
  ownerId: string;
  status: string;
  ownerActive: boolean;
}
export interface CarImageRow {
  id: string;
  assetId: string;
  sortOrder: number;
  isMain: boolean;
  createdAt: Date;
  width: number | null;
  height: number | null;
}
export interface OwnAssetRow {
  id: string;
  kind: string;
  status: string;
  /** The car this asset is already attached to, if any. */
  attachedCarId: string | null;
}

export interface CarImageRepository {
  /** Re-checks INSIDE the transaction that the acting account is still active and not deleted, and SHARE-locks it to commit. */
  lockActingUser(userId: string): Promise<boolean>;
  /** The owner's member car (not deleted); null for anything else. */
  findOwnCar(carId: string, ownerId: string): Promise<OwnCarRow | null>;
  /** findOwnCar, locked FOR UPDATE until the end of the transaction. */
  lockOwnCar(carId: string, ownerId: string): Promise<OwnCarRow | null>;
  /** The per-car image limit for member cars (app_settings 'images.max_per_car', the same value the database trigger enforces). */
  memberImageCap(): Promise<number>;
  listImages(carId: string): Promise<CarImageRow[]>;
  /** The caller's own asset (by owner), with the car it is attached to; null for another user's or an unknown asset. */
  findOwnAsset(assetId: string, ownerId: string): Promise<OwnAssetRow | null>;
  countImages(carId: string): Promise<number>;
  /** Appends the image at the next position; it is the main image when it is the car's first. */
  insertImage(carId: string, assetId: string): Promise<CarImageRow>;
  /** Deletes the link (not the asset). Scoped by the car: returns the removed row's flag, or null if the car has no such image. */
  deleteImage(imageId: string, carId: string): Promise<{ wasMain: boolean } | null>;
  /** After a deletion: the first remaining image becomes main if none is, and positions are contiguous again (0..n-1). */
  repairLayout(carId: string): Promise<void>;
}

export interface CarImageStore {
  /** Autocommit reads. */
  images: CarImageRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { images: CarImageRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

const IMAGE_COLUMNS = `ci.id, ci.asset_id, ci.sort_order, ci.is_main, ci.created_at, a.width, a.height`;

interface ImageSqlRow {
  id: string;
  asset_id: string;
  sort_order: number;
  is_main: boolean;
  created_at: Date;
  width: number | null;
  height: number | null;
}
const toImage = (r: ImageSqlRow): CarImageRow => ({
  id: String(r.id),
  assetId: r.asset_id,
  sortOrder: Number(r.sort_order),
  isMain: r.is_main === true,
  createdAt: r.created_at,
  width: r.width === null ? null : Number(r.width),
  height: r.height === null ? null : Number(r.height),
});

/** SQL builders, exported so tests can pin their text (and run it on a real database). */
export function buildFindOwnCar(carId: string, ownerId: string, lock: boolean): { text: string; values: unknown[] } {
  return {
    text: `SELECT c.id, c.owner_id, c.status, (u.status = 'active' AND u.deleted_at IS NULL) AS owner_active
             FROM cars c JOIN users u ON u.id = c.owner_id
            WHERE c.id = $1::bigint AND c.owner_id = $2::bigint AND c.source_type = 'member' AND c.deleted_at IS NULL${lock ? '\n              FOR UPDATE OF c' : ''}`,
    values: [carId, ownerId],
  };
}
export function buildListImages(carId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT ${IMAGE_COLUMNS} FROM car_images ci JOIN assets a ON a.id = ci.asset_id WHERE ci.car_id = $1::bigint ORDER BY ci.sort_order, ci.id`,
    values: [carId],
  };
}
export function buildFindOwnAsset(assetId: string, ownerId: string): { text: string; values: unknown[] } {
  return {
    text: `SELECT a.id, a.kind, a.status, ci.car_id AS attached_car_id
             FROM assets a LEFT JOIN car_images ci ON ci.asset_id = a.id
            WHERE a.id = $1::uuid AND a.owner_id = $2::bigint`,
    values: [assetId, ownerId],
  };
}
export function buildInsertImage(carId: string, assetId: string): { text: string; values: unknown[] } {
  return {
    text: `WITH ins AS (
             INSERT INTO car_images (car_id, asset_id, sort_order, is_main)
             SELECT $1::bigint, $2::uuid, COALESCE(MAX(sort_order) + 1, 0), COUNT(*) = 0 FROM car_images WHERE car_id = $1::bigint
             RETURNING id, asset_id, sort_order, is_main, created_at)
           SELECT ins.id, ins.asset_id, ins.sort_order, ins.is_main, ins.created_at, a.width, a.height FROM ins JOIN assets a ON a.id = ins.asset_id`,
    values: [carId, assetId],
  };
}
export function buildDeleteImage(imageId: string, carId: string): { text: string; values: unknown[] } {
  return { text: `DELETE FROM car_images WHERE id = $1::bigint AND car_id = $2::bigint RETURNING is_main`, values: [imageId, carId] };
}
export const PROMOTE_MAIN_SQL = `UPDATE car_images SET is_main = true
   WHERE id = (SELECT id FROM car_images WHERE car_id = $1::bigint ORDER BY sort_order, id LIMIT 1)
     AND NOT EXISTS (SELECT 1 FROM car_images WHERE car_id = $1::bigint AND is_main)`;
export const RENUMBER_SQL = `UPDATE car_images ci SET sort_order = r.n
    FROM (SELECT id, (row_number() OVER (ORDER BY sort_order, id) - 1)::smallint AS n FROM car_images WHERE car_id = $1::bigint) r
   WHERE ci.id = r.id AND ci.car_id = $1::bigint AND ci.sort_order <> r.n`;

export function createPgCarImageRepository(q: Tx): CarImageRepository {
  return {
    async lockActingUser(userId) {
      const r = await q.query(`SELECT id FROM users WHERE id = $1::bigint AND status = 'active' AND deleted_at IS NULL FOR SHARE`, [userId]);
      return r.rows.length === 1;
    },
    async findOwnCar(carId, ownerId) {
      return toCar((await run(buildFindOwnCar(carId, ownerId, false))).rows[0]);
    },
    async lockOwnCar(carId, ownerId) {
      return toCar((await run(buildFindOwnCar(carId, ownerId, true))).rows[0]);
    },
    async memberImageCap() {
      const r = await q.query<{ cap: number | null }>(`SELECT (value ->> 'member')::integer AS cap FROM app_settings WHERE key = 'images.max_per_car'`);
      const cap = r.rows[0]?.cap;
      return typeof cap === 'number' && cap >= 0 ? cap : MEMBER_IMAGE_CAP_DEFAULT;
    },
    async listImages(carId) {
      return (await q.query<ImageSqlRow>(...args(buildListImages(carId)))).rows.map(toImage);
    },
    async findOwnAsset(assetId, ownerId) {
      const r = (await q.query<{ id: string; kind: string; status: string; attached_car_id: string | null }>(...args(buildFindOwnAsset(assetId, ownerId)))).rows[0];
      return r ? { id: r.id, kind: r.kind, status: r.status, attachedCarId: r.attached_car_id === null ? null : String(r.attached_car_id) } : null;
    },
    async countImages(carId) {
      const r = await q.query<{ n: number }>(`SELECT count(*)::int AS n FROM car_images WHERE car_id = $1::bigint`, [carId]);
      return Number(r.rows[0]?.n ?? 0);
    },
    async insertImage(carId, assetId) {
      return toImage((await q.query<ImageSqlRow>(...args(buildInsertImage(carId, assetId)))).rows[0]!);
    },
    async deleteImage(imageId, carId) {
      const r = (await q.query<{ is_main: boolean }>(...args(buildDeleteImage(imageId, carId)))).rows[0];
      return r ? { wasMain: r.is_main === true } : null;
    },
    async repairLayout(carId) {
      await q.query(PROMOTE_MAIN_SQL, [carId]);
      await q.query(RENUMBER_SQL, [carId]);
    },
  };

  function run(s: { text: string; values: unknown[] }) {
    return q.query<{ id: string; owner_id: string; status: string; owner_active: boolean }>(s.text, s.values);
  }
  function args(s: { text: string; values: unknown[] }): [string, unknown[]] {
    return [s.text, s.values];
  }
  function toCar(r: { id: string; owner_id: string; status: string; owner_active: boolean } | undefined): OwnCarRow | null {
    return r ? { id: String(r.id), ownerId: String(r.owner_id), status: r.status, ownerActive: r.owner_active === true } : null;
  }
}

export function createPgCarImageStore(db: Db): CarImageStore {
  return {
    images: createPgCarImageRepository(db),
    transaction: (fn) => db.tx((t) => fn({ images: createPgCarImageRepository(t), audit: createPgAuditRepository(t) })),
  };
}

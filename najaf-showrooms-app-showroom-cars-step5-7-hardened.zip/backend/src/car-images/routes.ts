// HTTP contract for the images of a member's OWN car (Phase 11.5, Step 5.5). Thin: decisions live in car-images/service.ts and
// src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   GET    /v1/me/cars/:id/images              Bearer                         -> 200 {images, maxImages}
//   POST   /v1/me/cars/:id/images              Bearer, JSON {assetId}         -> 201 {image}   attaches the caller's own READY asset
//   DELETE /v1/me/cars/:id/images/:imageId     Bearer, no body                -> 204           removes the link (the asset is kept)
//
// Errors: 401 no/invalid token; 404 for any car that is not the caller's, any image that is not on that car, any asset that is not
// the caller's, and malformed ids (all identical to an unknown id); 400 invalid input (field names and codes only); 409 image_limit /
// invalid_state; 415 non-JSON body. The owner is the verified token's account, never a request field.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { CarImageError } from './service.ts';
import type { CarImageApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same in-process limiter as the other routes). */
export const CAR_IMAGE_RATE_LIMITS = {
  write: { limit: 60, windowSeconds: 10 * 60 },
  read: { limit: 240, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type CarImageRateLimitedRoute = keyof typeof CAR_IMAGE_RATE_LIMITS;

/** Maps every error this layer may see to the project's HTTP contract; undefined = not ours (the global handler maps it). */
export function toCarImageHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof CarImageError) {
    if (e.code === 'validation_failed') return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
    return { status: 409, code: e.code, message: e.message };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function carImageRateLimitHook(limiter: RateLimiter, route: CarImageRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`carImages.${route}:${request.ip}`, CAR_IMAGE_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'car_images.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** DELETE carries no body: the targets are in the path. */
function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  throw new CarImageError('validation_failed', [{ field: 'body', code: 'invalid_type' }]);
}

export function registerCarImageRoutes(app: FastifyInstance, deps: { auth: Pick<AuthApi, 'authenticate'>; carImages: CarImageApi; rateLimiter?: RateLimiter }): void {
  const { auth, carImages, rateLimiter } = deps;
  const limited = (route: CarImageRateLimitedRoute): Hook[] => (rateLimiter ? [carImageRateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toCarImageHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling" (and so of the owner): the verified access token, re-read from the database, then the
  // account-state rules. No/invalid token -> 401. An authenticated account that may not act (pending dealer) -> null actor.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };
  const param = (request: FastifyRequest, name: string): unknown => (request.params as Record<string, unknown> | undefined)?.[name];

  app.get('/v1/me/cars/:id/images', { onRequest: limited('read') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      return reply.code(200).send(await carImages.list(actor, param(request, 'id')));
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.post('/v1/me/cars/:id/images', { bodyLimit: 1024, onRequest: [...limited('write'), requireJsonBody] }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const image = await carImages.add(actor, param(request, 'id'), request.body, { requestId: request.id });
      return reply.code(201).send({ image });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  app.delete('/v1/me/cars/:id/images/:imageId', { bodyLimit: 1024, onRequest: limited('write') }, async (request, reply) => {
    try {
      const actor = await identify(request);
      assertNoBody(request.body);
      await carImages.remove(actor, param(request, 'id'), param(request, 'imageId'), { requestId: request.id });
      return reply.code(204).send();
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });
}

// PostgreSQL access for the dealer lifecycle (Phase 11.5, Step 5.2). Rules, as in auth/repository.ts:
//  - every statement is parameterized; statuses and roles that a statement WRITES are SQL literals, never parameters;
//  - only columns the application role may touch (migrations 0012/0013): users.status; showrooms INSERT and
//    showrooms.status/reviewed_by/reviewed_at. Nothing here can write users.role, showrooms.owner_id or any id;
//  - ownership is read from the database (showrooms.owner_id), never accepted from a caller;
//  - no SELECT *: each query names the columns it returns, and password_hash is never selected.
// Audit rows and session revocation are NOT written here: they reuse the single audit writer and the single lock-then-update
// revocation of auth/repository.ts.
import type { Db, Tx } from '../db.ts';
import { createPgAuditRepository, createPgSessionsRepository } from '../auth/repository.ts';
import type { AuditRepository, SessionsRepository } from '../auth/repository.ts';

export type DealerStatus = 'pending' | 'active' | 'suspended';

/**
 * The dealer ACCOUNT state machine, and nothing else. The schema has no 'rejected' account state (users.status is
 * active/pending/suspended), so a rejected application is 'suspended', exactly as the prototype does (adminService.rejectDealer);
 * the audit action (dealer.reject vs dealer.suspend) records which one it was.
 */
export const TRANSITIONS = {
  approve: { from: 'pending', to: 'active' },
  reject: { from: 'pending', to: 'suspended' },
  suspend: { from: 'active', to: 'suspended' },
  reactivate: { from: 'suspended', to: 'active' },
} as const satisfies Record<string, { from: DealerStatus; to: DealerStatus }>;
export type DealerTransition = keyof typeof TRANSITIONS;

// One fixed statement per transition: both states are SQL literals, so no value from anywhere can choose a status.
const TRANSITION_SQL: Record<DealerTransition, string> = {
  approve: `UPDATE users SET status = 'active' WHERE id = $1 AND role = 'dealer' AND status = 'pending' AND deleted_at IS NULL`,
  reject: `UPDATE users SET status = 'suspended' WHERE id = $1 AND role = 'dealer' AND status = 'pending' AND deleted_at IS NULL`,
  suspend: `UPDATE users SET status = 'suspended' WHERE id = $1 AND role = 'dealer' AND status = 'active' AND deleted_at IS NULL`,
  reactivate: `UPDATE users SET status = 'active' WHERE id = $1 AND role = 'dealer' AND status = 'suspended' AND deleted_at IS NULL`,
};

export interface DealerRow {
  id: string;
  name: string;
  phoneE164: string;
  status: string;
  phoneVerified: boolean;
  createdAt: Date;
}
export interface ShowroomRow {
  id: string;
  ownerId: string;
  name: string;
  status: string;
}
export interface DealerListRow extends DealerRow {
  showroom: { id: string; status: string } | null;
}
export interface OwnShowroomRow extends ShowroomRow {
  phone: string | null;
  whatsapp: string | null;
  address: string;
  createdAt: Date;
}

export interface DealerRepository {
  /**
   * Re-checks, INSIDE the transaction, that the acting administrator is still an active, not deleted admin, and holds a SHARE lock
   * on that row until the end of the transaction: an admin suspended while this request runs cannot complete it.
   */
  lockActingAdmin(adminId: string): Promise<boolean>;
  /** The dealer account (role = dealer, not deleted), locked FOR UPDATE; null for anything else (unknown id, member, admin, deleted). */
  lockDealer(userId: string): Promise<DealerRow | null>;
  /** Compare-and-swap of the account status along ONE transition of TRANSITIONS, for a dealer that is not deleted. false = not in `from`. */
  transition(userId: string, t: DealerTransition): Promise<boolean>;
  /** The showroom owned by this user (showrooms.owner_id is UNIQUE), locked FOR UPDATE; null if none. */
  lockShowroomOfOwner(ownerId: string): Promise<ShowroomRow | null>;
  /**
   * Creates the dealer's showroom, ACTIVE and reviewed (prototype: "معرض <name>", the dealer's phone as phone and WhatsApp). null if a
   * showroom for this owner already exists (UNIQUE owner_id decides, never a prior SELECT).
   */
  createApprovedShowroom(input: { ownerId: string; name: string; phoneE164: string; reviewerId: string }): Promise<ShowroomRow | null>;
  /** pending -> active (an operations-created showroom awaiting review). Compare-and-swap on the status. */
  approvePendingShowroom(showroomId: string, reviewerId: string): Promise<boolean>;
  /** Administrator listing: dealers in one account status, by ascending id (keyset pagination). */
  listDealers(input: { status: DealerStatus; afterId: string | null; limit: number }): Promise<DealerListRow[]>;
  /** The caller's OWN showroom, by owner id (the id comes from the verified token, never from the request). */
  findOwnShowroom(ownerId: string): Promise<OwnShowroomRow | null>;
}

export interface DealerStore {
  /** Autocommit reads (listing, own showroom). */
  dealers: DealerRepository;
  /** One database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { dealers: DealerRepository; sessions: SessionsRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

interface DealerSqlRow {
  id: string;
  name: string;
  phone_e164: string;
  status: string;
  phone_verified: boolean;
  created_at: Date;
}
const toDealer = (r: DealerSqlRow): DealerRow => ({ id: r.id, name: r.name, phoneE164: r.phone_e164, status: r.status, phoneVerified: r.phone_verified === true, createdAt: r.created_at });
interface ShowroomSqlRow {
  id: string;
  owner_id: string;
  name: string;
  status: string;
}
const toShowroom = (r: ShowroomSqlRow): ShowroomRow => ({ id: r.id, ownerId: r.owner_id, name: r.name, status: r.status });

export function createPgDealerRepository(q: Tx): DealerRepository {
  return {
    async lockActingAdmin(adminId) {
      const r = await q.query(`SELECT id FROM users WHERE id = $1 AND role = 'admin' AND status = 'active' AND deleted_at IS NULL FOR SHARE`, [adminId]);
      return r.rows.length === 1;
    },

    async lockDealer(userId) {
      const r = await q.query<DealerSqlRow>(
        `SELECT id, name, phone_e164, status, phone_verified_at IS NOT NULL AS phone_verified, created_at
           FROM users
          WHERE id = $1 AND role = 'dealer' AND deleted_at IS NULL
            FOR UPDATE`,
        [userId],
      );
      return r.rows[0] ? toDealer(r.rows[0]) : null;
    },

    async transition(userId, t) {
      const sql = Object.hasOwn(TRANSITION_SQL, t) ? TRANSITION_SQL[t] : undefined;
      if (!sql) throw new Error('unknown dealer transition');
      const r = await q.query(sql, [userId]);
      return (r.rowCount ?? 0) === 1;
    },

    async lockShowroomOfOwner(ownerId) {
      const r = await q.query<ShowroomSqlRow>(`SELECT id, owner_id, name, status FROM showrooms WHERE owner_id = $1 FOR UPDATE`, [ownerId]);
      return r.rows[0] ? toShowroom(r.rows[0]) : null;
    },

    async createApprovedShowroom({ ownerId, name, phoneE164, reviewerId }) {
      const r = await q.query<ShowroomSqlRow>(
        `INSERT INTO showrooms (owner_id, name, phone, whatsapp, status, reviewed_by, reviewed_at)
         VALUES ($1, $2, $3, $3, 'active', $4, now())
         ON CONFLICT (owner_id) DO NOTHING
         RETURNING id, owner_id, name, status`,
        [ownerId, name, phoneE164, reviewerId],
      );
      return r.rows[0] ? toShowroom(r.rows[0]) : null;
    },

    async approvePendingShowroom(showroomId, reviewerId) {
      const r = await q.query(`UPDATE showrooms SET status = 'active', reviewed_by = $2, reviewed_at = now() WHERE id = $1 AND status = 'pending'`, [showroomId, reviewerId]);
      return (r.rowCount ?? 0) === 1;
    },

    async listDealers({ status, afterId, limit }) {
      const r = await q.query<DealerSqlRow & { showroom_id: string | null; showroom_status: string | null }>(
        `SELECT u.id, u.name, u.phone_e164, u.status, u.phone_verified_at IS NOT NULL AS phone_verified, u.created_at,
                s.id AS showroom_id, s.status AS showroom_status
           FROM users u
           LEFT JOIN showrooms s ON s.owner_id = u.id
          WHERE u.role = 'dealer' AND u.deleted_at IS NULL AND u.status = $1
            AND ($2::bigint IS NULL OR u.id > $2::bigint)
          ORDER BY u.id
          LIMIT $3`,
        [status, afterId, limit],
      );
      return r.rows.map((row) => ({ ...toDealer(row), showroom: row.showroom_id !== null && row.showroom_status !== null ? { id: row.showroom_id, status: row.showroom_status } : null }));
    },

    async findOwnShowroom(ownerId) {
      const r = await q.query<ShowroomSqlRow & { phone: string | null; whatsapp: string | null; address: string; created_at: Date }>(
        `SELECT id, owner_id, name, status, phone, whatsapp, address, created_at FROM showrooms WHERE owner_id = $1`,
        [ownerId],
      );
      const row = r.rows[0];
      return row ? { ...toShowroom(row), phone: row.phone, whatsapp: row.whatsapp, address: row.address, createdAt: row.created_at } : null;
    },
  };
}

export function createPgDealerStore(db: Db): DealerStore {
  return {
    dealers: createPgDealerRepository(db),
    transaction: (fn) => db.tx((t) => fn({ dealers: createPgDealerRepository(t), sessions: createPgSessionsRepository(t), audit: createPgAuditRepository(t) })),
  };
}

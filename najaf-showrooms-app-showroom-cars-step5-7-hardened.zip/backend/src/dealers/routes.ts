// HTTP contract for the dealer lifecycle (Phase 11.5, Step 5.2). Thin by design: decisions live in dealers/service.ts and
// src/authz. Imports Fastify TYPES only, so the handlers are unit-testable without Fastify installed.
//
//   POST /v1/dealers/register                  {name, phone, password}  -> 201 {user, session}   user.role='dealer', status='pending'
//   GET  /v1/dealer/showroom                   Bearer (active dealer)   -> 200 {showroom}        the caller's OWN showroom
//   GET  /v1/admin/dealers?status=&after=&limit=  Bearer (admin)         -> 200 {dealers, nextAfter}
//   POST /v1/admin/dealers/:id/approve         Bearer (admin), no body  -> 200 {dealer}   pending   -> active (+ showroom)
//   POST /v1/admin/dealers/:id/reject          Bearer (admin), no body  -> 200 {dealer}   pending   -> suspended
//   POST /v1/admin/dealers/:id/suspend         Bearer (admin), no body  -> 200 {dealer}   active    -> suspended (sessions end)
//   POST /v1/admin/dealers/:id/reactivate      Bearer (admin), no body  -> 200 {dealer}   suspended -> active (+ showroom)
//
// Pipeline per request: rate limit -> (JSON-only) -> authentication (token + database re-read) -> strict input validation ->
// policy -> service in a transaction -> whitelisted DTO -> audit. Errors: 401 no/invalid token; 404 for anything the caller may
// not see (identical to an unknown id); 403 only for the caller's own account; 400 invalid input; 409 wrong state.
// No role, owner, showroom id or status is ever read from the request: the only id in a URL names the TARGET of an admin action.
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { bearerToken, isJsonContentType, rateLimitHook, toAuthHttp } from '../auth/routes.ts';
import type { AuthHttpError } from '../auth/routes.ts';
import type { RateLimiter, RateRule } from '../auth/rate-limit.ts';
import { AuthError } from '../auth/types.ts';
import type { AuthApi, AuthContext, DealerRegistrationApi } from '../auth/types.ts';
import { toActor, toAuthzHttp } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { DealerError } from './service.ts';
import type { DealerApi } from './service.ts';

/** PROPOSED, per client address and per instance (the same in-process limiter as authentication). */
export const DEALER_RATE_LIMITS = {
  dealerShowroom: { limit: 120, windowSeconds: 10 * 60 },
  adminDealersList: { limit: 120, windowSeconds: 10 * 60 },
  adminDealerAction: { limit: 60, windowSeconds: 10 * 60 },
} as const satisfies Record<string, RateRule>;
export type DealerRateLimitedRoute = keyof typeof DEALER_RATE_LIMITS;

export const ADMIN_DEALER_ACTIONS = ['approve', 'reject', 'suspend', 'reactivate'] as const;
export type AdminDealerAction = (typeof ADMIN_DEALER_ACTIONS)[number];

/** Maps every error this layer may see to the project's HTTP contract; undefined = not ours (the global handler maps it). */
export function toDealerHttp(e: unknown): AuthHttpError | undefined {
  const auth = toAuthHttp(e);
  if (auth) return auth;
  const authz = toAuthzHttp(e);
  if (authz) return authz;
  if (e instanceof DealerError) {
    if (e.code === 'invalid_state') return { status: 409, code: e.code, message: e.message };
    return { status: 400, code: e.code, message: e.message, ...(e.fields ? { fields: e.fields } : {}) };
  }
  return undefined;
}

type Hook = (request: FastifyRequest, reply: FastifyReply) => Promise<FastifyReply | undefined>;
type Reply = { code(n: number): Reply; header(k: string, v: string): Reply; send(b?: unknown): Reply };

function dealerRateLimitHook(limiter: RateLimiter, route: DealerRateLimitedRoute): Hook {
  return async (request, reply) => {
    const decision = limiter.consume(`dealers.${route}:${request.ip}`, DEALER_RATE_LIMITS[route]);
    if (decision.allowed) return undefined;
    request.log.warn({ event: 'dealers.rate_limited', route });
    reply.header('retry-after', String(decision.retryAfterSeconds));
    return reply.code(429).send({ error: { code: 'rate_limited', message: 'Too many requests', requestId: request.id } });
  };
}

async function requireJsonBody(request: FastifyRequest, reply: FastifyReply): Promise<FastifyReply | undefined> {
  const contentType = request.headers['content-type'];
  if (contentType === undefined || isJsonContentType(contentType)) return undefined;
  return reply.code(415).send({ error: { code: 'unsupported_media_type', message: 'Content-Type must be application/json', requestId: request.id } });
}

/** An admin action takes NO input besides the target id: no body at all, or an empty JSON object. */
export function assertNoBody(body: unknown): void {
  if (body === undefined || body === null) return;
  if (typeof body === 'object' && !Array.isArray(body) && Object.keys(body as object).length === 0) return;
  if (typeof body === 'object' && body !== null && !Array.isArray(body)) {
    const fields = Object.keys(body as object).slice(0, 10).map((k) => ({ field: /^[A-Za-z0-9_]{1,40}$/.test(k) ? k : 'unknown', code: 'unknown_field' as const }));
    throw new DealerError('validation_failed', fields);
  }
  throw new DealerError('validation_failed', [{ field: 'body', code: 'invalid_type' }]);
}

export function registerDealerRoutes(
  app: FastifyInstance,
  deps: { auth: Pick<AuthApi, 'authenticate'>; registration: DealerRegistrationApi; dealers: DealerApi; rateLimiter?: RateLimiter },
): void {
  const { auth, registration, dealers, rateLimiter } = deps;
  const limited = (route: DealerRateLimitedRoute): Hook[] => (rateLimiter ? [dealerRateLimitHook(rateLimiter, route)] : []);

  const fail = (request: FastifyRequest, reply: Reply, e: unknown): Reply => {
    const mapped = toDealerHttp(e);
    if (!mapped) throw e;
    if (mapped.status === 401) reply.header('www-authenticate', 'Bearer');
    if (mapped.retryAfterSeconds !== undefined) reply.header('retry-after', String(mapped.retryAfterSeconds));
    return reply.code(mapped.status).send({ error: { code: mapped.code, message: mapped.message, ...(mapped.fields ? { fields: mapped.fields } : {}), requestId: request.id } });
  };

  // The ONLY source of "who is calling": the verified access token, re-read from the database (authenticate), then the
  // account-state rules (toActor). No token / invalid token -> 401. A valid token of a pending dealer -> an authenticated
  // caller with NO actor (null): every decision below then denies it.
  const identify = async (request: FastifyRequest): Promise<Actor | null> => {
    const found = await auth.authenticate(bearerToken(request.headers['authorization']));
    if (!found) throw new AuthError('unauthorized');
    return toActor(found.user);
  };

  // ---- the dealer application (public, shares the registration rate limit: one budget for both kinds of sign-up) ----
  app.post(
    '/v1/dealers/register',
    { bodyLimit: 4096, onRequest: [...(rateLimiter ? [rateLimitHook(rateLimiter, 'register')] : []), requireJsonBody] },
    async (request, reply) => {
      try {
        const ua = request.headers['user-agent'];
        const ctx: AuthContext = { userAgent: typeof ua === 'string' ? ua : undefined };
        const result = await registration.registerDealer(request.body, ctx);
        return reply.code(201).send(result);
      } catch (e) {
        return fail(request, reply as unknown as Reply, e);
      }
    },
  );

  // ---- the dealer's own area ----
  app.get('/v1/dealer/showroom', { ...(rateLimiter ? { onRequest: limited('dealerShowroom') } : {}) }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const showroom = await dealers.getOwnShowroom(actor);
      return reply.code(200).send({ showroom });
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  // ---- administration ----
  app.get('/v1/admin/dealers', { ...(rateLimiter ? { onRequest: limited('adminDealersList') } : {}) }, async (request, reply) => {
    try {
      const actor = await identify(request);
      const result = await dealers.listDealers(actor, request.query);
      return reply.code(200).send(result);
    } catch (e) {
      return fail(request, reply as unknown as Reply, e);
    }
  });

  for (const action of ADMIN_DEALER_ACTIONS) {
    app.post(
      `/v1/admin/dealers/:id/${action}`,
      { bodyLimit: 1024, onRequest: [...limited('adminDealerAction'), requireJsonBody] },
      async (request, reply) => {
        try {
          const actor = await identify(request);
          assertNoBody(request.body);
          const id = (request.params as Record<string, unknown> | undefined)?.['id'];
          const dealer = await dealers[action](actor, id, { requestId: request.id });
          return reply.code(200).send({ dealer });
        } catch (e) {
          return fail(request, reply as unknown as Reply, e);
        }
      },
    );
  }
}

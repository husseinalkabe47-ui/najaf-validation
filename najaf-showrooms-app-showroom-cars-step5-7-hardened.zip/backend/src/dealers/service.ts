// Dealer lifecycle (Phase 11.5, Step 5.2): the administrator's decisions on dealer accounts, and the dealer's view of their own
// showroom. The dealer APPLICATION itself (a pending dealer account + a session) lives in the authentication service
// (registerDealer), because it is a sign-up.
//
// Decisions (each is covered by tests):
//  - WHO acts is an Actor from src/authz (loadActor/toActor): the account re-read from the database for a verified access token.
//    A pending or suspended account has NO actor, so it can do nothing here; a member or a dealer is not an admin.
//  - Every decision goes through the policy (authorize/can) BEFORE any database access, so a non-administrator learns nothing
//    (404, identical to an unknown id; 403 only for their own account, which they already know exists).
//  - Inside ONE transaction: the acting admin is re-checked and SHARE-locked (an admin suspended meanwhile cannot finish), the
//    dealer row is locked FOR UPDATE, the transition is a compare-and-swap whose states are SQL literals, sessions are ended with
//    the single lock-then-update revocation, the showroom is created/approved, and the audit row is written. All or nothing.
//  - The transitions (no others exist): approve pending->active, reject pending->suspended, suspend active->suspended,
//    reactivate suspended->active. Anything else is 409 invalid_state and changes nothing.
//  - The schema has no 'rejected' account state; a rejected application is 'suspended' (the prototype's own choice), and the
//    audit action says which it was. Reactivating a rejected applicant therefore makes them an approved dealer.
//  - Approval and reactivation make sure the dealer has exactly ONE showroom: created active (UNIQUE owner_id decides, so two
//    concurrent approvals cannot create two), or an operations-created pending showroom is approved. A showroom an
//    administrator suspended separately stays suspended.
//  - Suspension (and rejection) does not touch the showroom row: the public views already hide a showroom whose owner is not
//    active, and reactivation brings it back as it was.
//  - Ownership is never an input: the showroom is found by owner_id = the dealer's id (from the locked row) or = the actor's id.
import { nullLogger } from '../types.ts';
import type { Logger } from '../types.ts';
import { authorize, isValidId, notFound, showroomResource, userResource, dealerDirectoryResource } from '../authz/index.ts';
import type { Actor } from '../authz/index.ts';
import { TRANSITIONS } from './repository.ts';
import type { DealerListRow, DealerRepository, DealerRow, DealerStatus, DealerStore, DealerTransition, ShowroomRow } from './repository.ts';
import type { FieldError } from '../auth/validation.ts';

export type DealerErrorCode = 'validation_failed' | 'invalid_state';
const MESSAGES: Record<DealerErrorCode, string> = {
  validation_failed: 'The submitted data is not valid',
  invalid_state: 'The dealer account is not in a state that allows this action',
};
export class DealerError extends Error {
  readonly code: DealerErrorCode;
  readonly fields: FieldError[] | undefined;
  constructor(code: DealerErrorCode, fields?: FieldError[]) {
    super(MESSAGES[code]);
    this.name = 'DealerError';
    this.code = code;
    this.fields = fields;
  }
}

/** What an administrator sees of a dealer account. Built field by field (no password hash, counters or internal columns). */
export interface DealerSummary {
  id: string;
  name: string;
  phone: string;
  status: string;
  phoneVerified: boolean;
  createdAt: string;
  showroom: { id: string; status: string } | null;
}
/** The dealer's own showroom, as the dealer sees it (its status included, even when it is not public). */
export interface OwnShowroom {
  id: string;
  name: string;
  status: string;
  phone: string | null;
  whatsapp: string | null;
  address: string;
  createdAt: string;
}
export interface DealerContext {
  /** The HTTP request id, recorded in the audit row. Not a secret. */
  requestId?: string | undefined;
}

export interface DealerApi {
  listDealers(actor: Actor | null, query: unknown): Promise<{ dealers: DealerSummary[]; nextAfter: string | null }>;
  approve(actor: Actor | null, dealerId: unknown, ctx?: DealerContext): Promise<DealerSummary>;
  reject(actor: Actor | null, dealerId: unknown, ctx?: DealerContext): Promise<DealerSummary>;
  suspend(actor: Actor | null, dealerId: unknown, ctx?: DealerContext): Promise<DealerSummary>;
  reactivate(actor: Actor | null, dealerId: unknown, ctx?: DealerContext): Promise<DealerSummary>;
  /** An ACTIVE dealer's own showroom; 404 for everyone else (guest, pending/suspended dealer, member, admin). */
  getOwnShowroom(actor: Actor | null): Promise<OwnShowroom>;
}

export const LIST_LIMIT_DEFAULT = 50;
export const LIST_LIMIT_MAX = 100;
const STATUSES: readonly DealerStatus[] = ['pending', 'active', 'suspended'];
const LIMIT_PATTERN = /^[1-9][0-9]{0,2}$/;

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);

/** ?status=pending|active|suspended (default pending) &after=<id> &limit=1..100 (default 50). Unknown keys are rejected. */
export function parseListQuery(query: unknown): { ok: true; value: { status: DealerStatus; afterId: string | null; limit: number } } | { ok: false; errors: FieldError[] } {
  const q = query === undefined || query === null ? {} : query;
  if (!isPlainObject(q)) return { ok: false, errors: [{ field: 'query', code: 'invalid_type' }] };
  const errors: FieldError[] = [];
  for (const key of Object.keys(q)) if (!['status', 'after', 'limit'].includes(key)) errors.push({ field: /^[A-Za-z0-9_]{1,40}$/.test(key) ? key : 'unknown', code: 'unknown_field' });
  let status: DealerStatus = 'pending';
  const s = q['status'];
  if (s !== undefined) {
    if (typeof s !== 'string') errors.push({ field: 'status', code: 'invalid_type' });
    else if (!(STATUSES as readonly string[]).includes(s)) errors.push({ field: 'status', code: 'invalid_format' });
    else status = s as DealerStatus;
  }
  let afterId: string | null = null;
  const a = q['after'];
  if (a !== undefined) {
    if (typeof a !== 'string') errors.push({ field: 'after', code: 'invalid_type' });
    else if (!isValidId(a)) errors.push({ field: 'after', code: 'invalid_format' });
    else afterId = a;
  }
  let limit = LIST_LIMIT_DEFAULT;
  const l = q['limit'];
  if (l !== undefined) {
    if (typeof l !== 'string') errors.push({ field: 'limit', code: 'invalid_type' });
    else if (!LIMIT_PATTERN.test(l) || Number(l) > LIST_LIMIT_MAX) errors.push({ field: 'limit', code: 'invalid_format' });
    else limit = Number(l);
  }
  if (errors.length > 0) return { ok: false, errors: errors.slice(0, 10) };
  return { ok: true, value: { status, afterId, limit } };
}

/** The prototype's showroom name for a newly approved dealer (ShowroomService.ensureDealerShowroom). */
export function showroomNameFor(dealerName: string): string {
  const n = String(dealerName ?? '').trim();
  return `معرض ${n === '' ? 'جديد' : n}`;
}

function summary(d: DealerRow, status: string, showroom: { id: string; status: string } | null): DealerSummary {
  return { id: d.id, name: d.name, phone: d.phoneE164, status, phoneVerified: d.phoneVerified, createdAt: d.createdAt.toISOString(), showroom };
}
const listSummary = (r: DealerListRow): DealerSummary => summary(r, r.status, r.showroom ? { id: r.showroom.id, status: r.showroom.status } : null);

/** Audit data must be numbers; a bigint id is recorded only when it is exactly representable. */
const idNumber = (id: string): Record<string, number> => (Number.isSafeInteger(Number(id)) ? { showroom_id: Number(id) } : {});

export function createDealerService(deps: { store: DealerStore; logger?: Logger }): DealerApi {
  const { store } = deps;
  const logger = deps.logger ?? nullLogger;

  async function ensureShowroom(dealers: DealerRepository, dealer: DealerRow, reviewerId: string): Promise<{ showroom: ShowroomRow; created: boolean }> {
    const existing = await dealers.lockShowroomOfOwner(dealer.id);
    if (existing) {
      if (existing.status === 'pending' && (await dealers.approvePendingShowroom(existing.id, reviewerId))) return { showroom: { ...existing, status: 'active' }, created: false };
      return { showroom: existing, created: false };
    }
    const created = await dealers.createApprovedShowroom({ ownerId: dealer.id, name: showroomNameFor(dealer.name), phoneE164: dealer.phoneE164, reviewerId });
    if (created) return { showroom: created, created: true };
    // Lost a race to another insert for the same owner (UNIQUE owner_id): use the row that won.
    const winner = await dealers.lockShowroomOfOwner(dealer.id);
    if (!winner) throw new Error('showroom neither created nor found');
    return { showroom: winner, created: false };
  }

  async function act(t: DealerTransition, actor: Actor | null, rawId: unknown, ctx: DealerContext = {}): Promise<DealerSummary> {
    // 1) Policy BEFORE any database access. A malformed id is simply "not found" (no 400 that would distinguish it).
    if (!isValidId(rawId)) throw notFound();
    authorize(actor, 'moderate', userResource({ id: rawId })); // only an acting administrator passes
    const admin = actor as Actor;
    const { from, to } = TRANSITIONS[t];

    type Outcome =
      | { kind: 'not_found' }
      | { kind: 'invalid_state' }
      | { kind: 'done'; dealer: DealerSummary; sessionsRevoked: number; showroomCreated: boolean };
    const outcome: Outcome = await store.transaction(async ({ dealers, sessions, audit }) => {
      // 2) The actor is re-checked under a lock: an administrator suspended after authenticating cannot finish this.
      if (!(await dealers.lockActingAdmin(admin.id))) return { kind: 'not_found' };
      // 3) The target, locked. Only a dealer account (role from the database, never from the request) qualifies.
      const dealer = await dealers.lockDealer(rawId);
      if (!dealer) return { kind: 'not_found' };
      if (dealer.status !== from) return { kind: 'invalid_state' };

      // 4) Ending access: lock-then-update over every live session (waits for a refresh in flight), BEFORE the status changes;
      //    the users_revoke_sessions trigger then sweeps anything else in the same transaction.
      const sessionsRevoked = to === 'suspended' ? await sessions.revokeAllLive(dealer.id, 'user_suspended') : 0;
      if (!(await dealers.transition(dealer.id, t))) return { kind: 'invalid_state' }; // unreachable under the row lock; fail closed
      let showroom: ShowroomRow | null = null;
      let showroomCreated = false;
      if (to === 'active') ({ showroom, created: showroomCreated } = await ensureShowroom(dealers, dealer, admin.id));
      else showroom = await dealers.lockShowroomOfOwner(dealer.id);

      const afterData: Record<string, number> = to === 'suspended' ? { sessions_revoked: sessionsRevoked } : { ...(showroom ? idNumber(showroom.id) : {}), showroom_created: showroomCreated ? 1 : 0 };
      await audit.record({ action: `dealer.${t}`, actorUserId: admin.id, actorRole: 'admin', entityType: 'user', entityId: dealer.id, afterData, requestId: ctx.requestId });
      return { kind: 'done', dealer: summary(dealer, to, showroom ? { id: showroom.id, status: showroom.status } : null), sessionsRevoked, showroomCreated };
    });

    if (outcome.kind === 'not_found') throw notFound();
    if (outcome.kind === 'invalid_state') {
      logger.info({ event: 'dealer.transition_refused', transition: t, dealerId: rawId, adminId: admin.id });
      throw new DealerError('invalid_state');
    }
    logger.info({ event: `dealer.${t}`, dealerId: outcome.dealer.id, adminId: admin.id, sessionsRevoked: outcome.sessionsRevoked, showroomCreated: outcome.showroomCreated });
    return outcome.dealer;
  }

  async function listDealers(actor: Actor | null, query: unknown): Promise<{ dealers: DealerSummary[]; nextAfter: string | null }> {
    authorize(actor, 'read', dealerDirectoryResource()); // non-admins: 404 before the query is even parsed
    const parsed = parseListQuery(query);
    if (!parsed.ok) throw new DealerError('validation_failed', parsed.errors);
    const rows = await store.dealers.listDealers(parsed.value);
    const last = rows.length === parsed.value.limit ? rows[rows.length - 1] : undefined;
    return { dealers: rows.map(listSummary), nextAfter: last ? last.id : null };
  }

  async function getOwnShowroom(actor: Actor | null): Promise<OwnShowroom> {
    // No actor (guest, pending or suspended dealer) or not a dealer: there is no dealer area to show.
    if (!actor || actor.role !== 'dealer') throw notFound();
    const row = await store.dealers.findOwnShowroom(actor.id); // owner = the verified caller, never a request value
    if (!row) throw notFound();
    authorize(actor, 'read', showroomResource({ ownerId: row.ownerId, status: row.status, ownerActive: true })); // defense in depth
    return { id: row.id, name: row.name, status: row.status, phone: row.phone, whatsapp: row.whatsapp, address: row.address, createdAt: row.createdAt.toISOString() };
  }

  return {
    listDealers,
    approve: (actor, id, ctx) => act('approve', actor, id, ctx),
    reject: (actor, id, ctx) => act('reject', actor, id, ctx),
    suspend: (actor, id, ctx) => act('suspend', actor, id, ctx),
    reactivate: (actor, id, ctx) => act('reactivate', actor, id, ctx),
    getOwnShowroom,
  };
}

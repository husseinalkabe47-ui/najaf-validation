-- Creates (or refreshes) the least-privilege LOGIN role the backend connects with.
-- It is a plain member of najaf_app (created by database/migrations/0012), so it inherits exactly the validated
-- privileges: no DDL, no TRUNCATE, no DELETE on users/showrooms/audit_logs/exchange_rates, no UPDATE on audit_logs,
-- no UPDATE on users.role, and (after 0013) no UPDATE on ownership/timestamp/version columns of cars/showrooms/...
--
-- Run it as an administrator, once per database. The password never appears in this file:
--   psql -v ON_ERROR_STOP=1 -d najaf -v login=najaf_app_login -v pw="$NAJAF_APP_PASSWORD" -f backend/ops/create_app_login.sql
--
-- NOTE: do not give this role SUPERUSER / CREATEROLE / CREATEDB / REPLICATION / BYPASSRLS. The backend refuses to start if it has any.
\set ON_ERROR_STOP on

SELECT format('CREATE ROLE %I LOGIN PASSWORD %L IN ROLE najaf_app NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 50', :'login', :'pw')
 WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'login') \gexec

-- Already exists: rotate the password and re-assert the restrictions.
SELECT format('ALTER ROLE %I LOGIN PASSWORD %L NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS', :'login', :'pw')
 WHERE EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'login') \gexec

-- Membership is idempotent (no error if already a member).
SELECT format('GRANT najaf_app TO %I', :'login') \gexec

-- Needed only if CONNECT was revoked from PUBLIC on this database.
SELECT format('GRANT CONNECT ON DATABASE %I TO %I', current_database(), :'login') \gexec

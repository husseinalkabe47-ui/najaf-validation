'use strict';
// Phase 11.4.2 wrapper. Applies the validated, UNMODIFIED SQL of database/migrations/0012_views_grants.sql
// and rolls back with db/down/0012_views_grants.down.sql (both read verbatim; nothing is generated at runtime).
const fs = require('node:fs');
const path = require('node:path');

const UP = path.join(__dirname, '..', '..', '..', 'database', 'migrations', '0012_views_grants.sql');
const DOWN = path.join(__dirname, '..', 'down', '0012_views_grants.down.sql');

exports.up = (pgm) => {
  pgm.sql(fs.readFileSync(UP, 'utf8'));
};

exports.down = (pgm) => {
  pgm.sql(fs.readFileSync(DOWN, 'utf8'));
};

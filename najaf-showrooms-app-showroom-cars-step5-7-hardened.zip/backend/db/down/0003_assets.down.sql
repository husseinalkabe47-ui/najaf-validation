DROP INDEX IF EXISTS assets_cleanup_idx;
DROP INDEX IF EXISTS assets_owner_idx;
DROP INDEX IF EXISTS assets_legacy_ref_uq;
DROP INDEX IF EXISTS assets_storage_key_uq;
DROP TABLE IF EXISTS assets;

DROP TRIGGER IF EXISTS showrooms_cover_guard_biu ON showrooms;
DROP FUNCTION IF EXISTS showrooms_cover_guard();
DROP TRIGGER IF EXISTS showrooms_owner_guard_biu ON showrooms;
DROP FUNCTION IF EXISTS showrooms_owner_guard();
DROP TRIGGER IF EXISTS showrooms_touch_bu ON showrooms;
DROP INDEX IF EXISTS showrooms_search_trgm_idx;
DROP INDEX IF EXISTS showrooms_status_idx;
DROP TABLE IF EXISTS showrooms;

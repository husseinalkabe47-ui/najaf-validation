DROP TRIGGER IF EXISTS users_guard_biud ON users;
DROP FUNCTION IF EXISTS users_guard();
DROP TRIGGER IF EXISTS users_touch_bu ON users;
DROP INDEX IF EXISTS users_pending_dealers_idx;
DROP INDEX IF EXISTS users_role_status_idx;
DROP INDEX IF EXISTS users_email_active_uq;
DROP INDEX IF EXISTS users_phone_active_uq;
DROP TABLE IF EXISTS users;

REVOKE SELECT ON audit_logs FROM najaf_report;
REVOKE SELECT ON public_showrooms, public_cars FROM najaf_app, najaf_report;
REVOKE EXECUTE ON FUNCTION current_usd_to_iqd(), to_iqd(numeric, text), entitlements_for_showroom(bigint) FROM najaf_app;
GRANT EXECUTE ON FUNCTION current_usd_to_iqd(), to_iqd(numeric, text), entitlements_for_showroom(bigint) TO PUBLIC;
REVOKE USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public FROM najaf_app;
REVOKE SELECT, INSERT ON audit_logs, exchange_rates FROM najaf_app;
REVOKE SELECT, INSERT, UPDATE ON message_deliveries, subscription_plans, subscriptions, payments, app_settings FROM najaf_app;
REVOKE SELECT, INSERT, UPDATE, DELETE ON cars, car_images, favorites, assets, sessions, verification_codes, reward_grants FROM najaf_app;
REVOKE SELECT, INSERT, UPDATE ON showrooms FROM najaf_app;
REVOKE UPDATE (name, phone_e164, phone_verified_at, email, status, password_hash, password_changed_at, failed_logins, locked_until, last_login_at, deleted_at) ON users FROM najaf_app;
REVOKE SELECT, INSERT ON users FROM najaf_app;
REVOKE USAGE ON SCHEMA public FROM najaf_app, najaf_report;
-- roles are cluster-level objects: intentionally NOT dropped by the rollback
DROP VIEW IF EXISTS public_cars;
DROP VIEW IF EXISTS public_showrooms;

DROP TRIGGER IF EXISTS users_revoke_sessions_au ON users;
DROP FUNCTION IF EXISTS users_revoke_sessions();
DROP INDEX IF EXISTS sessions_expiry_idx;
DROP INDEX IF EXISTS sessions_family_idx;
DROP INDEX IF EXISTS sessions_user_live_idx;
DROP INDEX IF EXISTS sessions_token_hash_uq;
DROP TABLE IF EXISTS sessions;

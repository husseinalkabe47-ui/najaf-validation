DROP INDEX IF EXISTS reward_user_idx;
DROP INDEX IF EXISTS reward_ssv_uq;
DROP TABLE IF EXISTS reward_grants;

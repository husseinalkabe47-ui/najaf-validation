REVOKE UPDATE (sort_order, is_main) ON car_images FROM najaf_app;
REVOKE UPDATE (brand, model, year, price, currency, mileage, transmission, fuel_type, color, description, status, phone, whatsapp, location, latitude, longitude, rejection_reason, suspension_reason, reviewed_at, reviewed_by, search_text, deleted_at) ON cars FROM najaf_app;
REVOKE UPDATE (name, description, phone, whatsapp, address, latitude, longitude, cover_asset_id, working_hours, services, status, reviewed_by, reviewed_at, search_text) ON showrooms FROM najaf_app;
GRANT UPDATE ON showrooms, cars, car_images, favorites TO najaf_app;

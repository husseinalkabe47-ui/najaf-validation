DROP TRIGGER IF EXISTS msgdel_touch_bu ON message_deliveries;
DROP INDEX IF EXISTS msgdel_phone_idx;
DROP INDEX IF EXISTS msgdel_budget_idx;
DROP INDEX IF EXISTS msgdel_provider_msg_uq;
DROP TABLE IF EXISTS message_deliveries;
DROP INDEX IF EXISTS vcodes_expiry_idx;
DROP INDEX IF EXISTS vcodes_rate_idx;
DROP INDEX IF EXISTS vcodes_one_active_uq;
DROP TABLE IF EXISTS verification_codes;

/* ==========================================================================
   ROUTER
   كل مسار قد يملك guard: يعيد true (مسموح) أو اسم مسار للتحويل إليه
   أو false (عرض «غير مصرّح»). الحارس يُفحص داخل render() نفسه، فلا يمكن
   عرض شاشة محمية بمجرد استدعاء go('adminHome') أو تغيير currentRoute يدويًا.
   ========================================================================== */
/** حارس موحّد لكل شاشات لوحة الإدارة: admin فقط، وإلا تسجيل دخول أو «غير مصرّح». */
const _adminGuard = () => AuthorizationService.canAccessAdmin() || (SessionService.isLoggedIn() ? false : 'login');

const ROUTES = {
  home: { render: HomeScreen, nav: 'home' },
  showrooms: { render: ShowroomsScreen, nav: 'showrooms' },
  cars: { render: CarsScreen, nav: 'cars' },
  map: { render: MapScreen, nav: 'map' },
  favorites: { render: FavoritesScreen, nav: 'favorites' },
  showroomDetails: { render: ShowroomDetailsScreen, nav: 'showrooms' },
  carDetails: { render: CarDetailsScreen, nav: 'cars' },
  recentCars: { render: RecentCarsScreen, nav: 'home' }, // عام: السيارات المضافة حديثًا (ميزة جديدة ج1)
  search: { render: SearchScreen, nav: null }, // نتائج البحث الموحّد (المرحلة 8)

  // --- المرحلة 3: الحسابات والصلاحيات ---
  login:    { render: LoginScreen,    nav: null, guard: () => !SessionService.isLoggedIn() || 'account' },
  register: { render: RegisterScreen, nav: null, guard: () => !SessionService.isLoggedIn() || 'account' },
  account:  { render: AccountScreen,  nav: null, guard: () => SessionService.isLoggedIn() || 'login' },
  dealerHome: { render: DealerHomeScreen, nav: null,
    guard: () => AuthorizationService.canAccessDealerArea() || (SessionService.isLoggedIn() ? false : 'login') },
  adminHome:  { render: AdminDashboardScreen,  nav: null, guard: _adminGuard }, // لوحة الإدارة الفعلية (المرحلة 5)
  accessDenied: { render: AccessDeniedScreen, nav: null },

  // --- المرحلة 5: لوحة الإدارة ---
  adminDashboard:      { render: AdminDashboardScreen,      nav: null, guard: _adminGuard },
  adminMemberCars:     { render: AdminMemberCarsScreen,     nav: null, guard: _adminGuard },
  adminMemberCarDetails: { render: AdminMemberCarDetailsScreen, nav: null, guard: _adminGuard },
  adminShowrooms:      { render: AdminShowroomsScreen,      nav: null, guard: _adminGuard },
  adminShowroomCars:   { render: AdminShowroomCarsScreen,   nav: null, guard: _adminGuard },
  adminUsers:          { render: AdminUsersScreen,          nav: null, guard: _adminGuard },
  adminUserDetails:    { render: AdminUserDetailsScreen,    nav: null, guard: _adminGuard },
  adminDealerRequests: { render: AdminDealerRequestsScreen, nav: null, guard: _adminGuard },

  // --- المرحلة 4: سيارات الأعضاء ---
  memberCars: { render: MemberCarsScreen, nav: null }, // عام: يعرض فقط النشطة (عبر searchCars/getActiveMemberCars)
  memberCarDetails: { render: MemberCarDetailsScreen, nav: null,
    guard: (id) => {
      // غير موجود أو ظاهر لهذا المشاهد (active، أو لمالكه/المدير): تُعرض الشاشة (والغائب يظهر «غير موجود» داخلها).
      // إعلان غير نشط (pending/rejected/suspended/sold) لغير مالكه/المدير: رفض أو دخول، حتى لو مرَّر أحدهم الـID مباشرة.
      if (getMemberCarAccess(id).status !== 'hidden') return true;
      return SessionService.isLoggedIn() ? false : 'login';
    } },
  addMemberCar: { render: AddMemberCarScreen, nav: null, guard: () => SessionService.isLoggedIn() || 'login' },
  editMemberCar: { render: EditMemberCarScreen, nav: null,
    guard: (id) => {
      if (!SessionService.isLoggedIn()) return 'login';
      const car = getMemberCarById(id);
      return (!!car && AuthorizationService.canEditMemberCar(undefined, car)) || false;
    } },
  myMemberCars: { render: MyMemberCarsScreen, nav: null, guard: () => SessionService.isLoggedIn() || 'login' },

  // --- المرحلة 7: إدارة سيارات المعرض للتاجر ---
  myShowroomCars: { render: MyShowroomCarsScreen, nav: null,
    guard: () => AuthorizationService.canAccessDealerArea() || (SessionService.isLoggedIn() ? false : 'login') },
  addShowroomCar: { render: AddShowroomCarScreen, nav: null,
    guard: () => AuthorizationService.canAccessDealerArea() || (SessionService.isLoggedIn() ? false : 'login') },
  editShowroomCar: { render: EditShowroomCarScreen, nav: null,
    guard: (id) => (SessionService.isLoggedIn() ? (AuthorizationService.canManageCar(id) || false) : 'login') },
};
const NAV_ITEMS = [
  { key: 'home', icon: '🏠', label: 'الرئيسية' },
  { key: 'showrooms', icon: '🏢', label: 'المعارض' },
  { key: 'cars', icon: '🚘', label: 'السيارات' },
  { key: 'map', icon: '📍', label: 'الخريطة' },
  { key: 'favorites', icon: '❤️', label: 'المفضلة' },
];

let currentRoute = 'home';
let currentParam = null;

/* ---- نقطة ربط مستقبلية لإعلانات Interstitial (AdMob) ---- */
function maybeShowInterstitial(fromRoute, toRoute) {
  // لا شيء الآن — محجوزة للمرحلة القادمة فقط.
}

/* ---- سجل التنقل (المرحلة 8): زر الرجوع يعود للشاشة التي جاء منها المستخدم فعلًا ---- */
let _navStack = [];
// شاشات الدخول/الرفض وكل النماذج لا تدخل سجل الرجوع: بعد الحفظ لا يعود المستخدم إلى نموذج قديم
const _NO_HISTORY = ['login', 'register', 'accessDenied', 'addMemberCar', 'editMemberCar', 'addShowroomCar', 'editShowroomCar'];
// سجل يشير إلى عنصر حُذف لاحقًا يُتجاوز بدل عرض «غير موجود»
const _STILL_EXISTS = {
  carDetails: id => getCarAccess(id).status === 'ok', memberCarDetails: id => getMemberCarAccess(id).status === 'ok', showroomDetails: id => getShowroomAccess(id).status === 'ok',
  adminMemberCarDetails: id => !!getMemberCarById(id), adminUserDetails: id => !!UserService.getPublicById(id),
};
function _entryUsable(e) { const f = _STILL_EXISTS[e.route]; return !!ROUTES[e.route] && (!f || f(e.param)); }
function _samePage(aRoute, aParam, bRoute, bParam) { return aRoute === bRoute && JSON.stringify(aParam) === JSON.stringify(bParam); }

/* (الجزء 6.2-A) نقرة ثانية سريعة (double-tap) كانت تقع على زر الشاشة الجديدة في الموضع نفسه (مثلًا: «دخول» ثم تضغط «استكشف المعارض على الخريطة» فتنتقل لشاشة خاطئة).
   بعد كل انتقال تُقفل نقرات #screen 350ms فقط (CSS pointer-events)؛ شريط التنقل السفلي غير مقفول، والنداءات البرمجية لا تتأثر. */
let _navLockTimer = null;
function _lockScreenTaps() {
  if (typeof document === 'undefined' || typeof document.getElementById !== 'function') return;
  const app = document.getElementById('app'); if (!app || !app.classList) return;
  app.classList.add('nav-lock');
  if (_navLockTimer) clearTimeout(_navLockTimer);
  _navLockTimer = setTimeout(() => { _navLockTimer = null; app.classList.remove('nav-lock'); }, 350);
}

/* (الجزء 6.2-B) بعد كل انتقال: تُغلق أي نافذة حوار مفتوحة (بلا تنفيذ معالجها)، ويُنقل التركيز إلى محتوى الشاشة (قارئ الشاشة/لوحة المفاتيح يعرفان أن الشاشة تغيّرت)،
   ويتبع عنوان الصفحة عنوان الشاشة. لا يُستدعى من render() (إعادة الرسم بعد فلتر/بحث لا تسرق التركيز من الحقل). */
function _afterNavigate() {
  try {
    if (typeof AppDialog !== 'undefined') AppDialog.dismiss();
    if (typeof ModalFocus !== 'undefined') ModalFocus.reset();
    if (typeof document === 'undefined') return;
    const h = typeof document.querySelector === 'function' ? document.querySelector('#screen h1, #screen [role="heading"][aria-level="1"]') : null;
    const t = h && String(h.textContent || '').replace(/\s+/g, ' ').trim();
    document.title = t ? `${t} — معارض النجف` : 'معارض النجف';
    const main = typeof document.getElementById === 'function' ? document.getElementById('screen') : null;
    if (main && typeof main.focus === 'function') main.focus({ preventScroll: true });
  } catch (e) { /* التركيز/العنوان تحسين: لا يُسقط التنقل */ }
}

function go(route, param) {
  maybeShowInterstitial(currentRoute, route);
  if (!_samePage(currentRoute, currentParam, route, param) && !_NO_HISTORY.includes(currentRoute)) {
    _navStack.push({ route: currentRoute, param: currentParam });
    if (_navStack.length > 30) _navStack.shift();
  }
  currentRoute = route;
  currentParam = param;
  window.scrollTo(0, 0);
  render();
  _lockScreenTaps();
  _afterNavigate();
}

/** رجوع: للشاشة السابقة في السجل، وإلا إلى fallback (الافتراضي الرئيسية) */
function goBack(fallback) {
  let prev;
  while ((prev = _navStack.pop())) {
    if (_samePage(prev.route, prev.param, currentRoute, currentParam)) continue;   // لا «رجوع» إلى الشاشة نفسها
    if (_entryUsable(prev)) break;
  }
  if (prev) {
    currentRoute = prev.route;
    currentParam = prev.param;
    window.scrollTo(0, 0);
    render();
    _lockScreenTaps();
    _afterNavigate();
  } else {
    // (الجزء 6.2-A) بلا سجل: ننتقل للشاشة البديلة «بلا» دفع الشاشة الحالية في السجل. كان go(fallback) يدفعها، فيعود الرجوع التالي إليها (حلقة: تفاصيل ← رئيسية ← تفاصيل).
    currentRoute = fallback || 'home';
    currentParam = undefined;
    window.scrollTo(0, 0);
    render();
    _lockScreenTaps();
    _afterNavigate();
  }
}

/* ---- (الجزء 6.2-A) زر الرجوع في المتصفح/الهاتف ----
   التطبيق صفحة واحدة بلا history: زر الرجوع في المتصفح (أو زر الرجوع في أندرويد) كان يُخرج المستخدم من التطبيق مباشرة من أي شاشة.
   الآن: مدخل حارس واحد يُعاد دفعه بعد كل «رجوع»، فيُترجم الرجوع إلى goBack() نفسها (سجل التنقل الداخلي)، فلا يتكرر سجل المتصفح ولا تنشأ حلقات.
   من الرئيسية وبسجل فارغ يخرج المستخدم فعلًا. أزرار الرجوع داخل التطبيق لا تلمس history إطلاقًا. */
const _BACK_GUARD = { najafGuard: true };
function initBrowserBack(win, hist) {
  win = win || (typeof window !== 'undefined' ? window : null);
  hist = hist || (typeof history !== 'undefined' ? history : null);
  if (!win || !hist || typeof hist.pushState !== 'function' || typeof win.addEventListener !== 'function') return false;
  try { hist.replaceState({ najafBase: true }, ''); hist.pushState(_BACK_GUARD, ''); } catch (e) { return false; }
  win.addEventListener('popstate', () => {
    const atRoot = currentRoute === 'home' && _navStack.length === 0;
    if (atRoot) { try { hist.back(); } catch (e) { /* لا شيء */ } return; }   // نحن على المدخل الأساسي: الخروج الفعلي
    try { hist.pushState(_BACK_GUARD, ''); } catch (e) { /* لا شيء */ }
    goBack();
  });
  return true;
}

function renderNav() {
  const active = (ROUTES[currentRoute] || {}).nav;
  document.getElementById('bottomnav').innerHTML = NAV_ITEMS.map(item => `
    <button class="navbtn ${item.key === active ? 'active' : ''}" onclick="go('${item.key}')"${item.key === active ? ' aria-current="page"' : ''}>
      <span class="ic" aria-hidden="true">${item.icon}</span>${item.label}
    </button>`).join('');
}

function render() {
  try {
    // تطبيق الحراسة (حتى 3 تحويلات لتفادي الحلقات)
    for (let i = 0; i < 3; i++) {
      const r = ROUTES[currentRoute] || (currentRoute = 'home', ROUTES.home);
      const g = r.guard ? r.guard(currentParam) : true;
      if (g === true) break;
      if (typeof g === 'string') {
        const from = currentRoute, fromParam = currentParam;
        currentRoute = g;
        currentParam = (g === 'login') ? { returnTo: from, returnParam: fromParam } : undefined;
      } else {
        currentRoute = 'accessDenied';
        currentParam = undefined;
      }
    }
    document.getElementById('screen').innerHTML = ROUTES[currentRoute].render(currentParam);
  } catch (e) {
    // لا يرى المستخدم أي خطأ تقني: رسالة عربية + أزرار، والتفاصيل في Console للمطوّر
    console.error('[render error]', currentRoute, e);
    document.getElementById('screen').innerHTML = ErrorState();
  }
  renderNav();
}

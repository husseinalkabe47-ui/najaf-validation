/* ==========================================================================
   UI ACTIONS
   حلقة الوصل بين الشاشات والخدمات: تقرأ حقول النماذج، تستدعي AuthService/
   FavoritesService، ثم تتنقل. الشاشات لا تحتوي أي منطق دخول أو صلاحيات.
   ========================================================================== */
function _val(id) { const el = document.getElementById(id); return el ? el.value : ''; }
function _setMsg(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg || '';
  el.style.display = msg ? 'block' : 'none';
  if (msg) _focusMessage(el);
}
/** (الجزء 6.2-B) رسالة خطأ/ملاحظة ظاهرة: يُنقل إليها التركيز ويُمرَّر إليها (قارئ الشاشة يقرؤها، ومستخدم لوحة المفاتيح لا يضيع)؛ role=alert في الـmarkup */
function _focusMessage(el) {
  try {
    if (typeof el.setAttribute === 'function') el.setAttribute('tabindex', '-1');
    if (typeof el.scrollIntoView === 'function') el.scrollIntoView({ block: 'center' });
    if (typeof el.focus === 'function') el.focus({ preventScroll: true });
  } catch (e) { /* لا استثناء من التركيز */ }
}

function handleLoginSubmit() {
  const r = AuthService.login(_val('loginIdentifier'), _val('loginPassword'));
  if (!r.ok) { _setMsg('loginError', r.error); return; }
  const back = (currentParam && currentParam.returnTo) || 'home';
  go(back, currentParam && currentParam.returnParam);
}

function handleRegisterSubmit() {
  const typeEl = document.querySelector('input[name=accountType]:checked');
  const r = AuthService.register({
    name: _val('regName'), phone: _val('regPhone'), email: _val('regEmail'),
    password: _val('regPassword'), confirmPassword: _val('regConfirm'),
    accountType: typeEl ? typeEl.value : ''
  });
  if (!r.ok) { _setMsg('registerError', r.error); return; }
  go('account');
  warnIfNotSaved(r);   // تدقيق ما قبل الباكند: لا يبقى نجاح التسجيل صامتًا إن تعذّر الحفظ على الجهاز
}

function onAccountTypeChange() {
  const typeEl = document.querySelector('input[name=accountType]:checked');
  const note = document.getElementById('dealerNote');
  if (note) note.style.display = (typeEl && typeEl.value === 'dealer') ? 'block' : 'none';
}

function handleForgotPassword() {
  _setMsg('loginNote', 'استعادة كلمة المرور تحتاج خادمًا (Backend) وستُضاف في مرحلة لاحقة.');
}

function fillDemoAccount(i) {
  const a = DEMO_ACCOUNTS[i];
  if (!a) return;
  const idEl = document.getElementById('loginIdentifier'), pwEl = document.getElementById('loginPassword');
  if (idEl) idEl.value = a.identifier;
  if (pwEl) pwEl.value = a.password;
}

function handleLogout() {
  AuthService.logout();
  go('home');
}

/** المفضلة: الزائر يُحوَّل لتسجيل الدخول ثم يعود لنفس الشاشة */
function handleFavoriteToggle(carId) {
  const r = toggleFavorite(carId);
  if (!r.ok && r.reason === 'login_required') {
    go('login', { returnTo: currentRoute, returnParam: currentParam });
    return;
  }
  warnIfNotSaved(r);
  render();
}

/* ---- المرحلة 4/6: سيارات الأعضاء ---- */
let _currentDraftId = null;
let _rewardCountdownTimer = null;
const REWARD_AD_SECONDS = 8; // ضمن المدى المطلوب (5-10 ثوانٍ)

function _collectMemberCarFormData() {
  return {
    brand: _val('mcBrand'), model: _val('mcModel'), year: _val('mcYear'), price: _val('mcPrice'), currency: _val('mcCurrency') || undefined,   // القائمة لا تحوي خيارًا فارغًا: القيمة المختارة دائمًا (فارغ = العنصر غير موجود)
    mileage: _val('mcMileage'), transmission: _val('mcTransmission'), fuelType: _val('mcFuelType'),
    color: _val('mcColor'), location: _val('mcLocation'), phone: _val('mcPhone'),
    whatsapp: _val('mcWhatsapp'), description: _val('mcDescription'), mainImage: _val('mcImage'),
  };
}

/** الضغط على «نشر السيارة»: يبني مسودة عبر الخدمة، وهي من تقرر إن كان يحتاج إعلانًا (حسب الدور). */
let _memberSubmitBusy = false;
function handleAddMemberCarSubmit() {
  if (_memberSubmitBusy || _currentDraftId) return;   // يمنع التكرار أثناء الحفظ أو أثناء نافذة الإعلان
  const r = createDraftMemberCar(_collectMemberCarFormData());
  if (!r.ok) { _setMsg('addMemberCarError', userMsg(r.error)); return; }
  _setMsg('addMemberCarError', '');   // (تدقيق ما قبل الباكند) لا يبقى خطأ سابق ظاهرًا بعد نجاح التحقق (خلف نافذة الإعلان/بعد إلغائها)

  const imgDraft = (_imageCtx && _imageCtx.mode === 'draft') ? _imageCtx.draft : null;
  if (r.published) {
    // dealer/admin: نشر فوري بلا إعلان (قاعدة المرحلة 6)
    const finish = () => { notifySaved('تم نشر سيارتك بنجاح', r); go('myMemberCars'); };
    if (imgDraft && imgDraft.count()) {
      _memberSubmitBusy = true; setBusy('addMemberCarBtn', true);   // حفظ الصور غير فوري: نقفل الزر حتى لا تتكرر السيارة
      commitImageDraft(r.car.id, imgDraft).then(res => { _memberSubmitBusy = false; setBusy('addMemberCarBtn', false); finish(); warnImagesNotSaved(res); });
    } else finish();
    return;
  }
  // user: يحتاج مشاهدة إعلان قبل النشر
  _currentDraftId = r.draftId;
  const overlay = document.getElementById('rewardAdOverlay');
  if (overlay) {
    overlay.style.display = 'flex';
    _rewardStepLabel('Intro');
    // (الجزء 6.2-B) التركيز يدخل النافذة (زر «مشاهدة الإعلان»)، Tab محبوس داخلها، وEscape = إلغاء (قبل اكتمال الإعلان فقط)
    ModalFocus.activate(overlay, { onEscape: _rewardEscape, initial: '#rewardAdStepIntro .btn-primary' });
  }
}
/** عنوان النافذة (aria-labelledby) يتبع الخطوة الظاهرة: Intro | Playing | Done */
function _rewardStepLabel(step) {
  const box = document.getElementById('rewardAdBox');
  if (box && typeof box.setAttribute === 'function') box.setAttribute('aria-labelledby', 'rewardAdTitle' + step);
}
/** Escape داخل نافذة المكافأة: يلغي إن لم يكتمل الإعلان؛ بعد الاكتمال (النشر جارٍ) لا شيء */
function _rewardEscape() {
  const done = document.getElementById('rewardAdStepDone');
  if (done && done.style && done.style.display === 'block') return;
  handleCancelRewardAd();
}

/** الضغط على «مشاهدة الإعلان»: يطلب الإعلان من rewardService (Mock الآن، AdMob لاحقًا بنفس الواجهة) ثم يبدأ عدّادًا فعليًا. */
function handleWatchRewardAd() {
  if (!_currentDraftId || _rewardCountdownTimer) return;   // نقرة ثانية أثناء العدّ لا تبدأ عدّادًا ثانيًا
  const load = requestPublishReward(_currentDraftId);
  if (!load.ok) { _setMsg('rewardAdError', load.error || 'تعذر تحميل الإعلان، حاول مرة أخرى.'); return; }

  document.getElementById('rewardAdStepIntro').style.display = 'none';
  document.getElementById('rewardAdStepPlaying').style.display = 'block';
  _rewardStepLabel('Playing'); ModalFocus.refocus({ box: true });   // الزر المضغوط اختفى: التركيز على النافذة (لا على «إلغاء»): نقرة Enter/Space ثانية سريعة لا تلغي الإعلان بالخطأ
  let remaining = REWARD_AD_SECONDS;
  const el = document.getElementById('rewardAdCountdown');
  const tick = () => { if (el) el.textContent = '00:' + String(remaining).padStart(2, '0'); };
  tick();
  _rewardCountdownTimer = setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(_rewardCountdownTimer);
      _rewardCountdownTimer = null;
      _completeRewardAndPublish();
      return;
    }
    tick();
  }, 1000);
}

/** ينفَّذ فقط عند وصول العدّاد إلى الصفر فعليًا — لا طريقة أخرى لتعليم الإعلان كمكتمل من الواجهة. */
function _completeRewardAndPublish() {
  const draftId = _currentDraftId;
  if (!draftId) return;   // اكتمل/أُلغي مسبقًا: لا رسالة خطأ متأخرة
  const completed = onRewardCompleted(draftId); // rewardService: يسجّل الاكتمال لنفس draftId تحديدًا
  if (!completed.ok) { _setMsg('rewardAdError', 'تعذر إكمال الإعلان، حاول مرة أخرى.'); return; }

  const r = publishMemberCarAfterReward(draftId);
  if (!r.ok) { _setMsg('rewardAdError', r.error); return; }
  warnIfNotSaved(r);

  document.getElementById('rewardAdStepPlaying').style.display = 'none';
  document.getElementById('rewardAdStepDone').style.display = 'block';
  _rewardStepLabel('Done'); ModalFocus.refocus({ box: true });     // خطوة «اكتمل» بلا أزرار: التركيز على النافذة نفسها فيُقرأ العنوان
  _currentDraftId = null;
  // صور الإعلان المضغوطة تُخزَّن بعد النشر (المرحلة 7)، ثم ننتقل لإعلاناتي
  const imgDraft = (_imageCtx && _imageCtx.mode === 'draft') ? _imageCtx.draft : null;
  const saved = (imgDraft && imgDraft.count()) ? commitImageDraft(r.car.id, imgDraft) : Promise.resolve();
  saved.then(res => { warnImagesNotSaved(res); setTimeout(() => { go('myMemberCars'); }, 1200); });
}

/** إغلاق/إلغاء الإعلان قبل اكتماله: لا نشر إطلاقًا، والمسودة تُهمَل (يمكن المحاولة من جديد بالضغط على نشر ثانية). */
function handleCancelRewardAd() {
  if (_rewardCountdownTimer) { clearInterval(_rewardCountdownTimer); _rewardCountdownTimer = null; }
  if (_currentDraftId) {
    onRewardCancelled(_currentDraftId);
    discardMemberCarDraft(_currentDraftId);
    _currentDraftId = null;
  }
  const overlay = document.getElementById('rewardAdOverlay');
  if (overlay) overlay.style.display = 'none';
  _rewardStepLabel('Intro'); ModalFocus.deactivate();     // يعود التركيز إلى زر «نشر السيارة» الذي فتحها
  const intro = document.getElementById('rewardAdStepIntro'), playing = document.getElementById('rewardAdStepPlaying'), done = document.getElementById('rewardAdStepDone');
  if (intro) intro.style.display = 'block';
  if (playing) playing.style.display = 'none';
  if (done) done.style.display = 'none';
}

function handleEditMemberCarSubmit(id) {
  const r = updateMemberCar(id, {
    brand: _val('mcBrand'), model: _val('mcModel'), year: _val('mcYear'),
    price: _val('mcPrice'), currency: _val('mcCurrency') || undefined, mileage: _val('mcMileage'), transmission: _val('mcTransmission'), fuelType: _val('mcFuelType'),
    color: _val('mcColor'), location: _val('mcLocation'), phone: _val('mcPhone'), whatsapp: _val('mcWhatsapp'),
    description: _val('mcDescription'),
  });
  if (!r.ok) { _setMsg('editMemberCarError', userMsg(r.error)); return; }
  notifySaved('تم حفظ التعديلات', r);
  go('memberCarDetails', id);
}

function handleDeleteMemberCar(id) {
  const car = getMemberCarById(id);
  const name = car ? `${car.brand} ${car.model}` : 'هذا الإعلان';
  askConfirm({ title: 'حذف الإعلان', message: `هل أنت متأكد من حذف «${name}»؟ لا يمكن التراجع عن هذا الإجراء.`, confirmLabel: 'حذف', danger: true }, () => {
    const r = deleteMemberCar(id);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    go('myMemberCars');
  });
}

/** المالك: active/sold فقط. المدير: أي من الحالات الخمس (يتحقق منها changeMemberCarStatus نفسها). */
function handleMemberCarStatusChange(id) {
  const car = getMemberCarById(id);
  if (!car) return;
  const isAdmin = AuthorizationService.canAccessAdmin();
  const options = isAdmin
    ? Object.values(MEMBER_CAR_STATUS)
    : [MEMBER_CAR_STATUS.ACTIVE, MEMBER_CAR_STATUS.SOLD];
  const labels = options.map(s => `${s} = ${MEMBER_CAR_STATUS_LABEL[s]}`).join('\n');
  // (الجزء 6.2-B) اختيار بالأزرار بدل كتابة الرمز؛ الصلاحية والتحقق في changeMemberCarStatus كما كانا
  askChoice({ title: 'تغيير حالة الإعلان', options: options.map(s => ({ value: s, label: MEMBER_CAR_STATUS_LABEL[s] })), current: car.status,
              nativeMessage: `أدخل الحالة الجديدة:\n${labels}`, nativeDefault: car.status }, status => {
    const r = changeMemberCarStatus(id, status);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}

function handleShareMemberCar(id) {
  const car = getMemberCarById(id);
  if (!car) return;
  const text = `${car.brand} ${car.model} ${car.year} — ${carPriceOrDash(car)} — معارض النجف`;
  if (navigator.share) {
    navigator.share({ title: 'معارض النجف', text, url: location.href }).catch(() => {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(text + ' ' + location.href).then(() => notify('تم نسخ رابط الإعلان')).catch(() => notify(text));
  } else {
    notify(text);
  }
}

/* ---- المرحلة 5: لوحة الإدارة ---- */
function handleApproveMemberCar(id) {
  const r = approveMemberCar(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  notifySaved('تمت الموافقة على الإعلان ونشره', r);
  render();
}
function handleRejectMemberCar(id) {
  askText({ title: 'رفض الإعلان', label: 'سبب الرفض', confirmLabel: 'رفض الإعلان', nativeMessage: 'سبب الرفض:' }, reason => {
    const r = rejectMemberCar(id, reason);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}
function handleSuspendMemberCarAdmin(id) {
  askText({ title: 'إيقاف الإعلان', label: 'سبب الإيقاف (اختياري)', confirmLabel: 'إيقاف الإعلان', nativeMessage: 'سبب الإيقاف (اختياري):', nativeDefault: '' }, reason => {
    const r = suspendMemberCarAdmin(id, reason);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}
function handleRestoreMemberCarAdmin(id) {
  const r = restoreMemberCar(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleAdminSuspendShowroom(id) {
  const r = suspendShowroom(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleAdminActivateShowroom(id) {
  const r = activateShowroom(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleAdminShowroomCarStatusChange(id) {
  const car = getCarById(id);
  askChoice({ title: 'تغيير حالة السيارة', options: SHOWROOM_CAR_STATUSES.map(s => ({ value: s, label: CAR_STATUS_LABEL[s] })), current: car ? car.status : undefined,
              nativeMessage: 'أدخل الحالة الجديدة:\navailable = متاحة للبيع\nsold = مباعة', nativeDefault: 'available' }, status => {
    const r = setShowroomCarStatus(id, status);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}
function handleApproveDealer(id) {
  const r = approveDealer(id);
  if (!r.ok) { notify(r.error); return; }
  warnIfNotSaved(r);
  render();
}
function handleRejectDealer(id) {
  askConfirm({ title: 'رفض طلب صاحب المعرض', message: 'هل أنت متأكد من رفض هذا الطلب؟ سيبقى الحساب موجودًا بلا صلاحية إدارة معرض.', confirmLabel: 'رفض الطلب', danger: true }, () => {
    const r = rejectDealer(id);
    if (!r.ok) { notify(r.error); return; }
    warnIfNotSaved(r);
    render();
  });
}

/* أكشنز المرحلة 7: إدارة سيارات المعرض + منتقي الصور. الشاشات تستدعي الخدمات فقط،
   والخدمات هي التي تتحقق من الصلاحية والحد الأقصى والضغط. */
function _collectShowroomCarForm() {
  return {
    brand: _val('scBrand'), model: _val('scModel'), year: _val('scYear'), price: _val('scPrice'), currency: _val('scCurrency') || undefined,   // قائمة بلا خيار فارغ: القيمة المختارة دائمًا
    mileage: _val('scMileage'), transmission: _val('scTransmission'), fuelType: _val('scFuelType'),
    color: _val('scColor'), description: _val('scDescription'),
  };
}

/* قفل ضد الضغط المتكرر: السيارة تُنشأ فورًا ثم تُحفظ الصور (غير فوري)، فبدون قفل تتكرر السيارة */
let _showroomSubmitBusy = false;
async function handleAddShowroomCarSubmit() {
  if (_showroomSubmitBusy) return;
  _showroomSubmitBusy = true; setBusy('addShowroomCarBtn', true);
  try {
    const draft = _imageCtx && _imageCtx.mode === 'draft' ? _imageCtx.draft : null;
    const r = await createShowroomCar(_collectShowroomCarForm(), draft);
    if (!r.ok) { _setMsg('showroomCarError', userMsg(r.error)); return; }
    notifySaved('تمت إضافة السيارة ونشرها', r);
    warnImagesNotSaved(r);
    go('myShowroomCars');
  } finally { _showroomSubmitBusy = false; setBusy('addShowroomCarBtn', false); }
}

function handleEditShowroomCarSubmit(id) {
  const r = updateShowroomCar(id, _collectShowroomCarForm());
  if (!r.ok) { _setMsg('showroomCarError', userMsg(r.error)); return; }
  notifySaved('تم حفظ التعديلات', r);
  go('myShowroomCars');
}

const _deleting = {};
async function handleDeleteShowroomCar(id) {
  if (_deleting[id]) return;
  const car = getCarById(id);
  const name = car ? `${car.brand} ${car.model}` : 'هذه السيارة';
  _deleting[id] = true;                                   // نقرة ثانية أثناء نافذة التأكيد أو الحذف لا تعيد المحاولة
  const yes = await askConfirmAsync({ title: 'حذف السيارة', message: `هل أنت متأكد من حذف «${name}»؟ ستُحذف صورها أيضًا ولا يمكن التراجع.`, confirmLabel: 'حذف', danger: true });
  if (!yes) { delete _deleting[id]; return; }
  try {
    const r = await deleteShowroomCar(id);
    if (!r.ok) { notify(r.error); return; }
    notifySaved('تم حذف السيارة', r);
    render();
  } finally { delete _deleting[id]; }
}

function handleShowroomCarStatusChange(id, status) {
  if (!status) return;
  const r = changeShowroomCarStatus(id, status);
  if (!r.ok) { notify(r.error); return; }
  notifySaved('تم تغيير الحالة', r);
  render();
}

/* ---- منتقي الصور ---- */
async function handlePickImages(input) {
  const ctx = _imageCtx;
  if (!ctx) return;
  const files = Array.from(input.files || []);
  input.value = '';                 // لا يبقى الملف الأصلي مرتبطًا بعنصر الإدخال
  if (ctx.busy) return;             // معالجة صور جارية: لا تبدأ معالجة متداخلة
  ctx.busy = true; ctx.message = ''; refreshImagePicker();
  for (const f of files) {
    const r = ctx.mode === 'draft' ? await ctx.draft.add(f) : await addCarImage(ctx.carId, f);
    if (!r.ok) { ctx.message = r.error; break; }
  }
  ctx.busy = false; refreshImagePicker();
}

async function handleRemoveImage(ref) {
  const ctx = _imageCtx; if (!ctx) return;
  const r = ctx.mode === 'draft' ? ctx.draft.remove(ref) : await removeCarImage(ref);
  ctx.message = r.ok ? '' : (r.error || '');
  refreshImagePicker();
}

function handleSetMainImage(ref) {
  const ctx = _imageCtx; if (!ctx) return;
  const r = ctx.mode === 'draft' ? ctx.draft.setMain(ref) : setMainImage(ref);
  ctx.message = r.ok ? '' : (r.error || '');
  refreshImagePicker();
}

/** حالة «جارٍ الحفظ…» على زر أثناء عملية غير فورية (تمنع الضغط المتكرر بتعطيل الزر) */
function setBusy(btnId, busy) {
  const el = btnId ? document.getElementById(btnId) : null;
  if (!el) return;
  el.disabled = !!busy;
  if (busy) { el._label = el.textContent; el.textContent = 'جارٍ الحفظ…'; }
  else if (el._label) { el.textContent = el._label; }
}

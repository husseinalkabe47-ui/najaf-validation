/* بيانات تجريبية للمستخدمين — تستخدم UserModel.
   كلمات المرور هنا تجريبية وواضحة للاختبار فقط، وتُخزَّن كتجزئة (passwordHash)
   وليس كنص صريح. يجب حذف هذه الحسابات وصندوق الحسابات التجريبية قبل الإطلاق الفعلي.
     مستخدم عادي : 07700000001 / user123
     صاحب معرض   : 07701234567 / dealer123   (يملك «معرض النجف للسيارات» ownerId=1)
     صاحب معرض 2 : 07709876543 / dealer123   (يملك «معرض الفرات الذهبي» ownerId=2)
     مدير النظام : 07700000000 / admin123 */
const H_USER   = "mock$1a16938610cb15";   // user123
const H_DEALER = "mock$587d435e3c04b";    // dealer123
const H_ADMIN  = "mock$1f97b7d82a82";     // admin123

const USERS = [
  UserModel({ id: 1, name: "حيدر عبد الكاظم",   phone: "07701234567", email: "haidar.showroom@example.com", role: "dealer", status: "active", passwordHash: H_DEALER, createdAt: "2024-01-10T06:00:00.000Z" }),
  UserModel({ id: 2, name: "علي جبار الفتلاوي", phone: "07709876543", email: "ali.motors@example.com",      role: "dealer", status: "active", passwordHash: H_DEALER, createdAt: "2024-02-14T06:00:00.000Z" }),
  UserModel({ id: 3, name: "مرتضى صادق",         phone: "07711223344", email: "murtadha.cars@example.com",   role: "dealer", status: "active", passwordHash: H_DEALER, createdAt: "2024-03-02T06:00:00.000Z" }),
  UserModel({ id: 4, name: "زين العابدين كريم", phone: "07705566778", email: "zain.elite@example.com",      role: "dealer", status: "active", passwordHash: H_DEALER, createdAt: "2024-03-20T06:00:00.000Z" }),
  UserModel({ id: 5, name: "أحمد ستار",          phone: "07715558899", email: "ahmed.gulf@example.com",      role: "dealer", status: "active", passwordHash: H_DEALER, createdAt: "2024-04-05T06:00:00.000Z" }),
  UserModel({ id: 6, name: "مدير المنصة",        phone: "07700000000", email: "admin@najaf-showrooms.example", role: "admin", status: "active", passwordHash: H_ADMIN,  createdAt: "2024-01-01T06:00:00.000Z" }),
  UserModel({ id: 7, name: "مستخدم تجريبي",      phone: "07700000001", email: "user@example.com",             role: "user",   status: "active", passwordHash: H_USER,   createdAt: "2024-05-01T06:00:00.000Z" }),
  UserModel({ id: 8, name: "سجاد كامل",          phone: "07733445566", email: "sajjad.newshowroom@example.com", role: "dealer", status: "pending", passwordHash: H_DEALER, createdAt: "2026-07-01T06:00:00.000Z" }),
];

/* حسابات الاختبار المعروضة في شاشة تسجيل الدخول (للتجربة فقط — تُحذف قبل الإطلاق) */
const DEMO_ACCOUNTS = [
  { label: "مستخدم عادي",         identifier: "07700000001", password: "user123" },
  { label: "صاحب معرض (النجف)",   identifier: "07701234567", password: "dealer123" },
  { label: "صاحب معرض (الفرات)",  identifier: "07709876543", password: "dealer123" },
  { label: "صاحب معرض (قيد الموافقة)", identifier: "07733445566", password: "dealer123" },
  { label: "مدير النظام",          identifier: "07700000000", password: "admin123" },
];

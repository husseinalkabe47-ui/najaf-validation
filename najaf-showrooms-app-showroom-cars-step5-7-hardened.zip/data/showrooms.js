/* بيانات تجريبية لمعارض السيارات — تستخدم ShowroomModel.
   الإحداثيات تقريبية ضمن مدينة النجف الأشرف، جاهزة للربط بخريطة حقيقية لاحقًا. */
const SHOWROOMS = [
  ShowroomModel({
    id: 1, name: "معرض النجف للسيارات",
    description: "معرض متخصص بالسيارات الوارد الوكالة وشبه الجديدة.",
    phone: "07701234567", whatsapp: "9647701234567",
    address: "شارع الكوفة، النجف الأشرف",
    latitude: 31.9986, longitude: 44.3134,
    image: null, workingHours: "9 صباحًا - 9 مساءً",
    services: ["فحص فني", "تسهيلات دفع", "ضمان محدود"],
    status: "active", ownerId: 1,
    createdAt: "2024-01-15T06:00:00.000Z", updatedAt: "2026-08-01T09:00:00"
  }),
  ShowroomModel({
    id: 2, name: "معرض الفرات الذهبي",
    description: "تشكيلة متنوعة من السيارات الاقتصادية والعائلية.",
    phone: "07709876543", whatsapp: "9647709876543",
    address: "حي السلام، النجف الأشرف",
    latitude: 32.0045, longitude: 44.3251,
    image: null, workingHours: "10 صباحًا - 10 مساءً",
    services: ["تسهيلات دفع"],
    status: "active", ownerId: 2,
    createdAt: "2024-02-20T06:00:00.000Z", updatedAt: "2026-08-01T09:00:00"
  }),
  ShowroomModel({
    id: 3, name: "معرض العباس موتورز",
    description: "معرض كبير يضم سيارات مستعملة بحالات متفاوتة.",
    phone: "07711223344", whatsapp: "9647711223344",
    address: "طريق كربلاء، النجف الأشرف",
    latitude: 31.9822, longitude: 44.3009,
    image: null, workingHours: "9 صباحًا - 8 مساءً",
    services: ["فحص فني"],
    status: "pending", ownerId: 3,
    createdAt: "2024-03-05T06:00:00.000Z", updatedAt: "2026-08-01T09:00:00"
  }),
  ShowroomModel({
    id: 4, name: "معرض النخبة للسيارات",
    description: "سيارات فئة فاخرة ومختارة بعناية.",
    phone: "07705566778", whatsapp: "9647705566778",
    address: "حي الأمير، النجف الأشرف",
    latitude: 32.0102, longitude: 44.3387,
    image: null, workingHours: "9 صباحًا - 9 مساءً",
    services: ["ضمان محدود", "توصيل السيارة"],
    status: "active", ownerId: 4,
    createdAt: "2024-03-25T06:00:00.000Z", updatedAt: "2026-08-01T09:00:00"
  }),
  ShowroomModel({
    id: 5, name: "معرض الخليج للسيارات",
    description: "معرض متوسط يقدم خيارات اقتصادية بأسعار منافسة.",
    phone: "07715558899", whatsapp: "9647715558899",
    address: "شارع المدينة الصناعية، النجف الأشرف",
    latitude: 31.9755, longitude: 44.3288,
    image: null, workingHours: "10 صباحًا - 9 مساءً",
    services: ["تسهيلات دفع"],
    status: "suspended", ownerId: 5,
    createdAt: "2024-04-10T06:00:00.000Z", updatedAt: "2026-08-01T09:00:00"
  }),
];

/* بيانات تجريبية لصور السيارات — كل سيارة ترتبط بأكثر من صورة عبر carId.
   imageUrl حاليًا مسار Placeholder فقط (لا توجد ملفات صور حقيقية بعد)،
   وستُستبدل لاحقًا بروابط حقيقية عند رفع صور فعلية للسيارات. */
let CAR_IMAGES = [];
let _imgId = 1;
CARS.forEach((car) => {
  // صورة رئيسية + صورة إضافية لكل سيارة (يمكن إضافة المزيد لاحقًا بسهولة)
  CAR_IMAGES.push(CarImageModel({ id: _imgId++, carId: car.id, imageUrl: `assets/cars/${car.id}_1.jpg`, sortOrder: 0, isMain: true }));
  CAR_IMAGES.push(CarImageModel({ id: _imgId++, carId: car.id, imageUrl: `assets/cars/${car.id}_2.jpg`, sortOrder: 1 }));
});

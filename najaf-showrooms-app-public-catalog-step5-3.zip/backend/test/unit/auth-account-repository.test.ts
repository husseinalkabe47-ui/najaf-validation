import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { assertAuditSafe, createPgAuditRepository, createPgSessionsRepository, createPgUsersRepository } from '../../src/auth/repository.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import type { Tx } from '../../src/db.ts';

interface Call {
  text: string;
  values: readonly unknown[];
}
type Reply = { rows: unknown[]; rowCount: number };
function script(respond: (text: string, values: readonly unknown[]) => Reply = () => ({ rows: [], rowCount: 0 })) {
  const calls: Call[] = [];
  const tx: Tx = {
    query: async <R>(text: string, values: readonly unknown[] = []) => {
      calls.push({ text, values });
      return respond(text, values) as never as { rows: R[]; rowCount: number };
    },
  };
  return { tx, calls };
}
const HASH_A = '$argon2id$v=19$m=19456,p=1,t=2$c2FsdHNhbHRzYWx0c2FsdA$aGFzaGhhc2hoYXNoaGFzaGhhc2hoYXNoaGFzaGhhc2g';
const HASH_B = '$argon2id$v=19$m=19456,p=1,t=2$b3RoZXJzYWx0b3RoZXJzYQ$b3RoZXJoYXNob3RoZXJoYXNob3RoZXJoYXNob3RoZXI';
const userRow = { id: '7', name: 'علي حسين', phone_e164: '+9647701234567', role: 'user', status: 'active', phone_verified_at: null, created_at: new Date('2026-01-01T00:00:00Z'), password_hash: HASH_A, locked: false };

describe('users repository: credentials by id and the compare-and-swap password change', () => {
  it('findCredentialsById reads the credentials of ONE non-deleted user by id, and maps the hash and the lock flag', async () => {
    const { tx, calls } = script(() => ({ rows: [{ ...userRow, locked: true }], rowCount: 1 }));
    const cred = await createPgUsersRepository(tx).findCredentialsById('7');
    assert.match(calls[0]!.text, /FROM users\s+WHERE id = \$1 AND deleted_at IS NULL/);
    assert.match(calls[0]!.text, /locked_until > now\(\)/);
    assert.deepEqual(calls[0]!.values, ['7']);
    assert.equal(cred?.passwordHash, HASH_A);
    assert.equal(cred?.locked, true);
    assert.equal(cred?.id, '7');
    assert.equal(await createPgUsersRepository(script().tx).findCredentialsById('1'), null);
  });

  it('changePasswordIf swaps ONLY while the stored hash is still the one the caller proved (compare-and-swap), in one statement', async () => {
    const { tx, calls } = script(() => ({ rows: [], rowCount: 1 }));
    assert.equal(await createPgUsersRepository(tx).changePasswordIf('7', HASH_A, HASH_B), true);
    assert.equal(calls.length, 1);
    assert.match(calls[0]!.text, /SET password_hash = \$3, password_changed_at = now\(\), failed_logins = 0, locked_until = NULL\s+WHERE id = \$1 AND password_hash = \$2 AND deleted_at IS NULL/);
    assert.deepEqual(calls[0]!.values, ['7', HASH_A, HASH_B], 'the expected (old) hash is a bound parameter, and so is the new one');
  });

  it('changePasswordIf reports false when nothing matched (a concurrent change won, or the user is gone)', async () => {
    assert.equal(await createPgUsersRepository(script(() => ({ rows: [], rowCount: 0 })).tx).changePasswordIf('7', HASH_A, HASH_B), false);
  });

  it('every column it updates is one the application role may update', async () => {
    const { tx, calls } = script();
    await createPgUsersRepository(tx).changePasswordIf('7', HASH_A, HASH_B);
    const allowed = new Set(['password_hash', 'password_changed_at', 'failed_logins', 'locked_until']);
    const set = /SET\s+([\s\S]*?)\s+WHERE/.exec(calls[0]!.text)?.[1] ?? '';
    for (const col of set.match(/\b([a-z_]+)\s*=/g) ?? []) assert.ok(allowed.has(col.replace(/\s*=/, '')), col);
  });

  it('password_hash is touched by exactly five statements in the whole users repository: 3 reads/writes of credentials and the two password updates', async () => {
    const { tx, calls } = script(() => ({ rows: [userRow], rowCount: 1 }));
    const users = createPgUsersRepository(tx);
    await users.insert({ name: 'abc', phoneE164: '+9647701234567', passwordHash: HASH_A });
    await users.findCredentialsByPhone('+9647701234567');
    await users.findCredentialsById('7');
    await users.findById('7');
    await users.findByPhone('+9647701234567');
    await users.recordFailedLogin('7');
    await users.recordSuccessfulLogin('7');
    await users.markPhoneVerified('7');
    await users.resetPassword('7', HASH_A);
    await users.changePasswordIf('7', HASH_A, HASH_B);
    const first = (c: Call) => c.text.trim().split(/\s+/).slice(0, 3).join(' ');
    assert.deepEqual(calls.filter((c) => c.text.includes('password_hash')).map(first), ['INSERT INTO users', 'SELECT id, name,', 'SELECT id, name,', 'UPDATE users SET', 'UPDATE users SET']);
    assert.ok(!calls.filter((c) => /^\s*SELECT/.test(c.text) && c.text.includes('password_hash')).some((c) => !/WHERE (phone_e164|id) = \$1 AND deleted_at IS NULL/.test(c.text)), 'the hash is only ever read for ONE user, found by phone (login) or by id (change password)');
  });
});

describe('sessions repository: revokeAllLive (lock, then a fresh-snapshot update)', () => {
  const revoke = (reason: 'logout_all' | 'password_changed', updated = 3) => {
    const s = script((text) => (text.startsWith('UPDATE') ? { rows: [], rowCount: updated } : { rows: [{ id: 'a' }, { id: 'b' }], rowCount: 2 }));
    return { ...s, run: () => createPgSessionsRepository(s.tx).revokeAllLive('7', reason) };
  };

  it('runs exactly two statements, in order: first LOCK every live row of the user, then UPDATE', async () => {
    const { calls, run } = revoke('logout_all');
    await run();
    assert.equal(calls.length, 2);
    assert.match(calls[0]!.text, /^SELECT id FROM sessions WHERE user_id = \$1 AND revoked_at IS NULL ORDER BY id FOR UPDATE$/);
    assert.deepEqual(calls[0]!.values, ['7']);
    assert.match(calls[1]!.text, /^UPDATE sessions SET revoked_at = now\(\), revoked_reason = \$2 WHERE user_id = \$1 AND revoked_at IS NULL$/);
    assert.deepEqual(calls[1]!.values, ['7', 'logout_all']);
  });

  it('returns what the UPDATE changed, never what the lock returned', async () => {
    assert.equal(await revoke('logout_all', 5).run(), 5);
    assert.equal(await revoke('logout_all', 0).run(), 0);
  });

  it('locks in a FIXED order (id), so two simultaneous revocations of one user can never deadlock', async () => {
    const { calls, run } = revoke('password_changed');
    await run();
    assert.match(calls[0]!.text, /ORDER BY id FOR UPDATE/);
  });

  it('the lock covers exactly the rows the update touches: both are filtered by the user and by "still live"', async () => {
    const { calls, run } = revoke('logout_all');
    await run();
    for (const c of calls) assert.ok(c.text.includes('user_id = $1') && c.text.includes('revoked_at IS NULL'), c.text);
  });

  it('only ever REVOKES: it never inserts, never clears a revocation, and the reason is a bound parameter', async () => {
    for (const reason of ['logout_all', 'password_changed'] as const) {
      const { calls, run } = revoke(reason);
      await run();
      assert.ok(!calls.some((c) => /INSERT|DELETE/.test(c.text)));
      assert.ok(!calls.some((c) => /revoked_at\s*=\s*NULL/.test(c.text)));
      assert.ok(!calls.some((c) => c.text.includes(`'${reason}'`)), 'the reason is not part of the SQL text');
      assert.equal(calls[1]!.values[1], reason);
    }
  });

  it('is scoped to ONE user: the user id is a bound parameter in both statements', async () => {
    const evil = "7'; UPDATE sessions SET revoked_at = NULL; --";
    const { tx, calls } = script((text) => (text.startsWith('UPDATE') ? { rows: [], rowCount: 1 } : { rows: [], rowCount: 0 }));
    await createPgSessionsRepository(tx).revokeAllLive(evil, 'logout_all');
    for (const c of calls) {
      assert.ok(!c.text.includes(evil) && !c.text.includes('revoked_at = NULL'));
      assert.equal(c.values[0], evil);
    }
  });

  it('leaves the Step 3 method as it was: a single UPDATE', async () => {
    const { tx, calls } = script(() => ({ rows: [], rowCount: 2 }));
    assert.equal(await createPgSessionsRepository(tx).revokeAllForUser('7', 'password_changed'), 2);
    assert.equal(calls.length, 1);
    assert.match(calls[0]!.text, /SET revoked_at = now\(\), revoked_reason = \$2 WHERE user_id = \$1 AND revoked_at IS NULL/);
  });
});

describe('audit repository', () => {
  const event: AuditEvent = { action: 'auth.password_changed', actorUserId: '7', actorRole: 'user', entityType: 'user', entityId: '7', afterData: { sessions_revoked: 3 }, requestId: 'req-1' };

  it('inserts ONE row, with every value a bound parameter and the data as JSON', async () => {
    const { tx, calls } = script();
    await createPgAuditRepository(tx).record(event);
    assert.equal(calls.length, 1);
    assert.match(calls[0]!.text, /INSERT INTO audit_logs \(actor_id, actor_role, action, entity_type, entity_id, after_data, request_id\)\s+VALUES \(\$1, \$2, \$3, \$4, \$5, \$6::jsonb, \$7\)/);
    assert.deepEqual(calls[0]!.values, ['7', 'user', 'auth.password_changed', 'user', '7', '{"sessions_revoked":3}', 'req-1']);
  });

  it('a missing request id is stored as NULL', async () => {
    const { tx, calls } = script();
    const { requestId: _omit, ...withoutRequest } = event;
    await createPgAuditRepository(tx).record(withoutRequest);
    assert.equal(calls[0]!.values[6], null);
  });

  it('uses only INSERT: no UPDATE, DELETE or TRUNCATE (the table is append-only, enforced by triggers and by the grants)', async () => {
    const { tx, calls } = script();
    await createPgAuditRepository(tx).record(event);
    assert.ok(calls.every((c) => /^\s*INSERT INTO audit_logs/.test(c.text)));
  });

  it('hostile values never reach the SQL text', async () => {
    const evil = "x'); DROP TABLE audit_logs; --";
    const { tx, calls } = script();
    await createPgAuditRepository(tx).record({ ...event, actorRole: evil, entityId: evil, requestId: evil });
    assert.ok(!calls[0]!.text.includes('DROP TABLE'));
    assert.ok(calls[0]!.values.includes(evil));
  });

  it('refuses any data key that names a secret, and any value that is not a finite number: nothing is written', async () => {
    const bad: Array<Record<string, number>> = [{ password: 1 }, { new_password: 1 }, { password_hash: 1 }, { hash: 1 }, { token: 1 }, { access_token: 1 }, { refresh_token: 1 }, { otp: 1 }, { code: 1 }, { phone: 1 }, { api_key: 1 }, { secret: 1 }, { credentials: 1 }, { sessions_revoked: 'three' as unknown as number }, { sessions_revoked: Number.NaN }, { sessions_revoked: Number.POSITIVE_INFINITY }, { sessions_revoked: null as unknown as number }];
    for (const afterData of bad) {
      const { tx, calls } = script();
      await assert.rejects(createPgAuditRepository(tx).record({ ...event, afterData }), /audit data/, JSON.stringify(afterData));
      assert.equal(calls.length, 0);
    }
    assert.doesNotThrow(() => assertAuditSafe({ ...event, afterData: { sessions_revoked: 0 } }));
    assert.doesNotThrow(() => assertAuditSafe({ ...event, afterData: {} }));
  });
});

describe('static guards over the whole source tree', () => {
  const walk = (dir: string): string[] => readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? walk(join(dir, f)) : f.endsWith('.ts') ? [join(dir, f)] : []));
  const srcDir = join(import.meta.dirname, '..', '..', 'src');
  const sources = walk(srcDir).map((f) => ({ f: f.slice(srcDir.length + 1), text: readFileSync(f, 'utf8') }));

  it('no code anywhere can UPDATE, DELETE or TRUNCATE audit_logs', () => {
    for (const { f, text } of sources) assert.ok(!/(UPDATE|DELETE\s+FROM|TRUNCATE(\s+TABLE)?)\s+audit_logs/i.test(text), f);
  });

  it('audit_logs is written in exactly ONE place: the audit repository', () => {
    const writers = sources.filter(({ text }) => /INSERT\s+INTO\s+audit_logs/i.test(text)).map((s) => s.f);
    assert.deepEqual(writers, ['auth/repository.ts']);
  });

  it('the audit event vocabulary is exactly the three security events plus the four dealer decisions of Step 5.2', () => {
    const repo = sources.find((s) => s.f === 'auth/repository.ts')!.text;
    assert.match(repo, /action: 'auth\.password_changed' \| 'auth\.logout_all' \| 'auth\.password_reset' \| 'dealer\.approve' \| 'dealer\.reject' \| 'dealer\.suspend' \| 'dealer\.reactivate';/);
  });

  it('the account service never reads a user id from the request: its only inputs are the userId parameter and the parsed body', () => {
    const svc = sources.find((s) => s.f === 'auth/account-service.ts')!.text;
    assert.ok(!/request\.|req\.|headers|params|query/.test(svc.replace(/\/\/.*$/gm, '')), 'no HTTP object is touched');
    assert.match(svc, /async function changePassword\(userId: string, input: unknown/);
    assert.match(svc, /async function logoutAll\(userId: string/);
  });

  it('the new routes take the user id from the verified token only', () => {
    const routes = sources.find((s) => s.f === 'auth/routes.ts')!.text;
    const changeBlock = routes.slice(routes.indexOf("'/v1/auth/password/change'"), routes.indexOf("'/v1/auth/logout/all'"));
    const logoutBlock = routes.slice(routes.indexOf("'/v1/auth/logout/all'"), routes.indexOf('// ---- one-time codes ----'));
    for (const block of [changeBlock, logoutBlock]) {
      assert.match(block, /const \{ user \} = await requireAccess\(request\);/);
      assert.match(block, /\(user\.id/);
      assert.ok(!/request\.(body|params|query)\??\.(userId|id|user_id)/.test(block));
    }
  });
});

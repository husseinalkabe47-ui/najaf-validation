// Thin HTTP layer (Fastify). All decisions live in dependency-free modules (health.ts, http-errors.ts);
// this file only wires them. Routes: health always; authentication (Phase 11.4) when an AuthApi is supplied.
import { randomUUID } from 'node:crypto';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import type { AppConfig } from './config.ts';
import type { Db } from './db.ts';
import { livenessReport, readinessReport } from './health.ts';
import { toHttpError } from './http-errors.ts';
import { registerAuthRoutes } from './auth/routes.ts';
import type { RateLimiter } from './auth/rate-limit.ts';
import type { AccountApi, AuthApi, DealerRegistrationApi, OtpApi } from './auth/types.ts';
import { registerDealerRoutes } from './dealers/routes.ts';
import type { DealerApi } from './dealers/service.ts';
import { registerCatalogRoutes } from './catalog/routes.ts';
import type { CatalogApi } from './catalog/service.ts';

const REQUEST_ID = /^[A-Za-z0-9._-]{8,64}$/;

export async function buildServer(deps: {
  config: AppConfig;
  db: Pick<Db, 'ping' | 'checkSchema'>;
  auth?: AuthApi;
  /** One-time codes (phone verification, password recovery). Registered only together with `auth`. */
  otp?: OtpApi;
  /** Change password and sign out everywhere. Registered only together with `auth`. */
  account?: AccountApi;
  /** Dealer application and the administrators' dealer lifecycle (Step 5.2). Registered only together with `auth`. */
  dealers?: { registration: DealerRegistrationApi; lifecycle: DealerApi };
  /** Public, read-only catalog (Step 5.3). No authentication; registered whenever supplied. */
  catalog?: CatalogApi;
  /** Limits the authentication routes per client address (omit = no limiting, as before). */
  rateLimiter?: RateLimiter;
  /** Addresses/CIDRs of reverse proxies whose X-Forwarded-For is trusted. Omit or empty = trust nobody. */
  trustProxy?: string[];
}): Promise<FastifyInstance> {
  const { config, db } = deps;
  const app = Fastify({
    ...(deps.trustProxy && deps.trustProxy.length > 0 ? { trustProxy: deps.trustProxy } : {}),
    logger: {
      level: config.server.logLevel,
      redact: { paths: ['req.headers.authorization', 'req.headers.cookie', 'res.headers["set-cookie"]'], censor: '[redacted]' },
    },
    // Accept a well-formed incoming id for tracing, otherwise generate one (never trust arbitrary header content).
    genReqId: (req) => {
      const h = req.headers['x-request-id'];
      return typeof h === 'string' && REQUEST_ID.test(h) ? h : randomUUID();
    },
  });

  app.addHook('onSend', async (request, reply, payload) => {
    reply.header('x-request-id', request.id);
    reply.header('cache-control', 'no-store');
    reply.header('x-content-type-options', 'nosniff');
    return payload;
  });

  app.get('/healthz', async () => livenessReport());

  app.get('/readyz', async (request, reply) => {
    const r = await readinessReport({ db, logger: request.log });
    return reply.code(r.ready ? 200 : 503).send({ status: r.ready ? 'ready' : 'not_ready', checks: r.checks });
  });

  // Authentication routes exist only when an AuthApi is supplied (existing callers and tests are unaffected).
  if (deps.auth) registerAuthRoutes(app, { auth: deps.auth, ...(deps.otp ? { otp: deps.otp } : {}), ...(deps.account ? { account: deps.account } : {}), ...(deps.rateLimiter ? { rateLimiter: deps.rateLimiter } : {}) });

  if (deps.auth && deps.dealers) registerDealerRoutes(app, { auth: deps.auth, registration: deps.dealers.registration, dealers: deps.dealers.lifecycle, ...(deps.rateLimiter ? { rateLimiter: deps.rateLimiter } : {}) });

  if (deps.catalog) registerCatalogRoutes(app, { catalog: deps.catalog, ...(deps.rateLimiter ? { rateLimiter: deps.rateLimiter } : {}) });

  app.setNotFoundHandler((request, reply) => {
    const e = toHttpError({ statusCode: 404 });
    return reply.code(e.status).send({ error: { code: e.code, message: e.message, requestId: request.id } });
  });

  app.setErrorHandler((error, request, reply) => {
    const e = toHttpError(error);
    // Full detail (including the stack) stays in the server log; the client gets the generic mapped body only.
    if (e.status >= 500) request.log.error({ err: error }, 'request failed');
    else request.log.warn({ code: e.code }, 'request rejected');
    return reply.code(e.status).send({ error: { code: e.code, message: e.message, requestId: request.id } });
  });

  return app;
}

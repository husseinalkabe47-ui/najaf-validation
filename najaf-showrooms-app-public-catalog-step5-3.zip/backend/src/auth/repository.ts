// PostgreSQL access for authentication. Every statement is parameterized (values are never interpolated into SQL), uses
// only columns/privileges the application role has (migrations 0012/0013), and never selects password_hash except in the
// single credentials lookup used by login. Time is the database clock (now()), so there is no clock skew.
import type { Db, Tx } from '../db.ts';
import { mayAuthenticate } from './account-state.ts';
import { hashesEqual } from './otp.ts';
import type { OtpPurpose } from './otp.ts';
import { LOGIN_LOCK_SECONDS, LOGIN_MAX_FAILURES, OTP, SESSION_TOUCH_INTERVAL_SECONDS, SESSION_TTL_SECONDS } from './policy.ts';

export interface UserRow {
  id: string;
  name: string;
  phoneE164: string;
  role: string;
  status: string;
  /** users.phone_verified_at: null until a one-time code has proven the phone. */
  phoneVerifiedAt: Date | null;
  createdAt: Date;
}
export interface CredentialRow extends UserRow {
  passwordHash: string;
  /** true while users.locked_until is in the future (decided by the database clock). */
  locked: boolean;
}
export interface NewSession {
  /** sessions.id of the NEW row (this refresh token). */
  sessionId: string;
  /** sessions.family_id: the login session; stable across rotations. */
  familyId: string;
  expiresAt: Date;
}
export interface ActiveSession {
  /** sessions.id of the live row (the current refresh token's row). */
  sessionId: string;
  familyId: string;
  lastUsedAt: Date;
  user: UserRow;
}
export type RotateOutcome =
  | { kind: 'rotated'; user: UserRow; session: NewSession }
  /** The presented refresh token was already rotated: the whole family has been revoked ('reuse_detected'). */
  | { kind: 'reuse'; userId: string }
  /** Unknown, revoked (other reasons), expired, or the account may not authenticate (see account-state.ts). Nothing changed. */
  | { kind: 'rejected' };

export interface UsersRepository {
  /** Inserts an ACTIVE regular user. role and status are NOT parameters: the database defaults ('user', 'active') apply. */
  insert(input: { name: string; phoneE164: string; passwordHash: string }): Promise<UserRow>;
  /**
   * Inserts a dealer APPLICATION: role 'dealer', status 'pending' (Step 5.2). Both are literals in the SQL, never parameters, so no
   * input can choose another role or status. A pending dealer can sign in but has no dealer powers until an administrator approves.
   */
  insertPendingDealer(input: { name: string; phoneE164: string; passwordHash: string }): Promise<UserRow>;
  findCredentialsByPhone(phoneE164: string): Promise<CredentialRow | null>;
  recordFailedLogin(userId: string): Promise<void>;
  /**
   * NOT what a sign-in uses any more (see recordSuccessfulLoginIf): this one is unconditional, so a login that verified a password
   * which has since been changed would still "succeed". Kept only because its behavior is covered by tests; the login service
   * never calls it (a static test enforces that).
   */
  recordSuccessfulLogin(userId: string): Promise<void>;
  /**
   * The FIRST statement of a successful sign-in's transaction (MUST run inside AuthStore.transaction). A compare-and-swap on the
   * state the password was verified against: it succeeds only while the stored hash is STILL `expectedHash` and the account is
   * still allowed to sign in (account-state.ts) and not deleted. It resets the failure counters and takes the user's row lock, so it serializes with a password
   * change, a recovery, a suspension and a deletion: a login that began before one of them cannot create a live session after it.
   * false = the credentials it verified are stale; the caller must create NO session and answer like any failed login.
   */
  recordSuccessfulLoginIf(userId: string, expectedHash: string): Promise<boolean>;
  /** By id / by phone, WITHOUT the password hash (account recovery and phone verification never need it). Not deleted users only. */
  findById(userId: string): Promise<UserRow | null>;
  findByPhone(phoneE164: string): Promise<UserRow | null>;
  /** Sets phone_verified_at once; false when it was already set (the timestamp is never overwritten). */
  markPhoneVerified(userId: string): Promise<boolean>;
  /** New password hash + password_changed_at, and clears the login lockout (the user just proved they own the phone). */
  resetPassword(userId: string, passwordHash: string): Promise<void>;
  /** Credentials by id, for the authenticated change-password flow. With findCredentialsByPhone, the only reads of password_hash. */
  findCredentialsById(userId: string): Promise<CredentialRow | null>;
  /**
   * Compare-and-swap: sets the new hash ONLY while the stored hash is still `expectedHash`. false means a concurrent change got
   * there first, so the password the caller proved is no longer the current one. Also clears the login lockout.
   */
  changePasswordIf(userId: string, expectedHash: string, newHash: string): Promise<boolean>;
}
export interface SessionsRepository {
  /** Starts a NEW login session (new family) for a user. */
  create(input: { userId: string; tokenHash: Buffer; userAgent: string | null }): Promise<NewSession>;
  /** The live session of a family belonging to this user, with the user (may authenticate: active or pending dealer; not deleted); otherwise null. */
  findActiveByFamily(familyId: string, userId: string): Promise<ActiveSession | null>;
  /**
   * Rotates a refresh token. MUST run inside AuthStore.transaction: it locks the presented row, so two concurrent
   * refreshes of the same token cannot both succeed (the loser sees it as already rotated, i.e. reuse).
   */
  rotate(input: { presentedHash: Buffer; newHash: Buffer; userAgent: string | null }): Promise<RotateOutcome>;
  /** Revokes the live session of the family that this refresh token belongs to, whether or not the token is current. */
  revokeFamilyByTokenHash(tokenHash: Buffer): Promise<boolean>;
  /**
   * @deprecated A single UPDATE: it misses a session that a refresh IN FLIGHT inserted (its snapshot predates that commit), so a
   * session can survive. No production code calls it any more (a static test enforces that); use revokeAllLive. Kept unchanged
   * because its behavior is covered by tests.
   */
  revokeAllForUser(userId: string, reason: 'password_changed'): Promise<number>;
  /**
   * The concurrency-safe way to end EVERY live login session of a user (all families); returns how many rows changed. Used by
   * sign-out everywhere, change password and password recovery. MUST run inside AuthStore.transaction. A refresh locks its live
   * row and inserts a new one; a single UPDATE would not see that row (its snapshot predates the commit) and a session would
   * survive. So: first lock every live row (this WAITS for any in-flight refresh to finish), then UPDATE with a fresh snapshot
   * that sees everything committed. A refresh that starts later finds its row revoked and is refused.
   */
  revokeAllLive(userId: string, reason: 'logout_all' | 'password_changed' | 'user_suspended'): Promise<number>;
  /**
   * The same lock-then-update, scoped to the ONE login session (family) that `tokenHash` belongs to: this is sign-out. Without
   * it a sign-out that races a refresh of the same session would end the old row and miss the new one. MUST run inside
   * AuthStore.transaction. Returns how many rows changed (0 for an unknown token or an already ended session).
   */
  revokeFamilyLive(tokenHash: Buffer): Promise<number>;
  touch(sessionId: string): Promise<void>;
}

export type IssueOutcome =
  | { kind: 'issued'; codeId: string; expiresAt: Date }
  /** Nothing was written. retryAfterSeconds is a hint (cooldown remaining, or the length of the exhausted window). */
  | { kind: 'throttled'; retryAfterSeconds: number };
export type VerifyOutcome =
  | { kind: 'verified' }
  /** The reason is for INTERNAL logs only; callers must answer every rejection the same way. */
  | { kind: 'rejected'; reason: 'no_active_code' | 'expired' | 'attempts_exhausted' | 'mismatch' };
/** One-time codes (verification_codes). Both methods MUST run inside AuthStore.transaction. */
export interface OtpRepository {
  /** Throttles, supersedes the user's previous active code for this purpose, and stores the new code's HMAC. */
  issue(input: { userId: string; phoneE164: string; purpose: OtpPurpose; codeHash: Buffer }): Promise<IssueOutcome>;
  /**
   * Locks the ONE active code of (user, purpose, phone) and compares. A match consumes the code; a mismatch increments
   * attempts (and the caller must COMMIT, so the attempt is recorded). Anything else writes nothing.
   */
  verify(input: { userId: string; phoneE164: string; purpose: OtpPurpose; expectedHash: Buffer }): Promise<VerifyOutcome>;
}
/** One security event for audit_logs (append-only: the table's triggers refuse UPDATE, DELETE and TRUNCATE). */
export interface AuditEvent {
  /** Naming follows the table's own convention: <domain>.<event>, e.g. auth.login_failed. */
  action: 'auth.password_changed' | 'auth.logout_all' | 'auth.password_reset' | 'dealer.approve' | 'dealer.reject' | 'dealer.suspend' | 'dealer.reactivate';
  actorUserId: string;
  /** users.role of the actor: 'user' | 'dealer' | 'admin' (the table's vocabulary also has 'system'). */
  actorRole: string;
  entityType: 'user';
  entityId: string;
  /**
   * NUMBERS ONLY (e.g. how many sessions were ended, the id of the showroom an approval created): never a password, a hash, a
   * token, a code or a phone number. The dealer.* actions name their state transition, so no status strings are needed here.
   */
  afterData: Record<string, number>;
  requestId?: string | undefined;
}
export interface AuditRepository {
  /** Inserts one row. Runs inside the same transaction as the action it records, so the two succeed or fail together. */
  record(event: AuditEvent): Promise<void>;
}
export interface AuthStore {
  users: UsersRepository;
  sessions: SessionsRepository;
  /** Runs fn in one database transaction (rolled back if fn throws). */
  transaction<T>(fn: (repos: { users: UsersRepository; sessions: SessionsRepository; otp: OtpRepository; audit: AuditRepository }) => Promise<T>): Promise<T>;
}

interface UserSqlRow {
  id: string;
  name: string;
  phone_e164: string;
  role: string;
  status: string;
  phone_verified_at?: Date | null;
  created_at: Date;
}
const toUserRow = (r: UserSqlRow): UserRow => ({ id: r.id, name: r.name, phoneE164: r.phone_e164, role: r.role, status: r.status, phoneVerifiedAt: r.phone_verified_at ?? null, createdAt: r.created_at });

export function createPgUsersRepository(q: Tx): UsersRepository {
  return {
    async insert({ name, phoneE164, passwordHash }) {
      const r = await q.query<UserSqlRow>(
        `INSERT INTO users (name, phone_e164, password_hash)
         VALUES ($1, $2, $3)
         RETURNING id, name, phone_e164, role, status, phone_verified_at, created_at`,
        [name, phoneE164, passwordHash],
      );
      return toUserRow(r.rows[0] as UserSqlRow);
    },

    async insertPendingDealer({ name, phoneE164, passwordHash }) {
      const r = await q.query<UserSqlRow>(
        `INSERT INTO users (name, phone_e164, password_hash, role, status)
         VALUES ($1, $2, $3, 'dealer', 'pending')
         RETURNING id, name, phone_e164, role, status, phone_verified_at, created_at`,
        [name, phoneE164, passwordHash],
      );
      return toUserRow(r.rows[0] as UserSqlRow);
    },

    async findCredentialsByPhone(phoneE164) {
      const r = await q.query<UserSqlRow & { password_hash: string; locked: boolean }>(
        `SELECT id, name, phone_e164, role, status, phone_verified_at, created_at, password_hash,
                (locked_until IS NOT NULL AND locked_until > now()) AS locked
           FROM users
          WHERE phone_e164 = $1 AND deleted_at IS NULL`,
        [phoneE164],
      );
      const row = r.rows[0];
      return row ? { ...toUserRow(row), passwordHash: row.password_hash, locked: row.locked === true } : null;
    },

    async recordFailedLogin(userId) {
      // Atomic: concurrent failures cannot lose a count; the lock starts exactly when the threshold is reached.
      await q.query(
        `UPDATE users
            SET failed_logins = LEAST(failed_logins + 1, 100),
                locked_until = CASE WHEN failed_logins + 1 >= $2 THEN now() + make_interval(secs => $3) ELSE locked_until END
          WHERE id = $1`,
        [userId, LOGIN_MAX_FAILURES, LOGIN_LOCK_SECONDS],
      );
    },

    async recordSuccessfulLogin(userId) {
      await q.query(`UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now() WHERE id = $1`, [userId]);
    },

    async recordSuccessfulLoginIf(userId, expectedHash) {
      const r = await q.query(
        `UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now()
          WHERE id = $1 AND password_hash = $2 AND (status = 'active' OR (status = 'pending' AND role = 'dealer')) AND deleted_at IS NULL`,
        [userId, expectedHash],
      );
      return (r.rowCount ?? 0) > 0;
    },

    async findById(userId) {
      const r = await q.query<UserSqlRow>(`SELECT id, name, phone_e164, role, status, phone_verified_at, created_at FROM users WHERE id = $1 AND deleted_at IS NULL`, [userId]);
      return r.rows[0] ? toUserRow(r.rows[0]) : null;
    },

    async findByPhone(phoneE164) {
      const r = await q.query<UserSqlRow>(`SELECT id, name, phone_e164, role, status, phone_verified_at, created_at FROM users WHERE phone_e164 = $1 AND deleted_at IS NULL`, [phoneE164]);
      return r.rows[0] ? toUserRow(r.rows[0]) : null;
    },

    async markPhoneVerified(userId) {
      const r = await q.query(`UPDATE users SET phone_verified_at = now() WHERE id = $1 AND phone_verified_at IS NULL`, [userId]);
      return (r.rowCount ?? 0) > 0;
    },

    async resetPassword(userId, passwordHash) {
      await q.query(`UPDATE users SET password_hash = $2, password_changed_at = now(), failed_logins = 0, locked_until = NULL WHERE id = $1`, [userId, passwordHash]);
    },

    async findCredentialsById(userId) {
      const r = await q.query<UserSqlRow & { password_hash: string; locked: boolean }>(
        `SELECT id, name, phone_e164, role, status, phone_verified_at, created_at, password_hash,
                (locked_until IS NOT NULL AND locked_until > now()) AS locked
           FROM users
          WHERE id = $1 AND deleted_at IS NULL`,
        [userId],
      );
      const row = r.rows[0];
      return row ? { ...toUserRow(row), passwordHash: row.password_hash, locked: row.locked === true } : null;
    },

    async changePasswordIf(userId, expectedHash, newHash) {
      const r = await q.query(
        `UPDATE users SET password_hash = $3, password_changed_at = now(), failed_logins = 0, locked_until = NULL
          WHERE id = $1 AND password_hash = $2 AND deleted_at IS NULL`,
        [userId, expectedHash, newHash],
      );
      return (r.rowCount ?? 0) > 0;
    },
  };
}

interface RotateSqlRow {
  id: string;
  family_id: string;
  user_id: string;
  revoked: boolean;
  revoked_reason: string | null;
  expired: boolean;
  status: string;
  deleted: boolean;
  name: string;
  phone_e164: string;
  role: string;
  phone_verified_at: Date | null;
  created_at: Date;
}

// The two scopes of the ONE lock-then-update that ends live sessions. Constants (never built from input): the key is always $1.
const LIVE_SCOPE = {
  user: 'user_id = $1',
  family: 'family_id = (SELECT family_id FROM sessions WHERE token_hash = $1)',
} as const;

/**
 * The single concurrency-safe session revocation (the SQL behind revokeAllLive and revokeFamilyLive). It MUST run inside a
 * transaction, because its first statement takes row locks that only a transaction keeps.
 *  1) Lock every live row of the scope, in a fixed order (two concurrent revocations cannot deadlock). A refresh in flight holds
 *     the lock of the row it is rotating until it commits, so this statement WAITS for it. Its own result is not used.
 *  2) A NEW statement, hence a new snapshot: it sees the row that refresh inserted. Revoke everything still live.
 */
async function revokeLive(q: Tx, scope: string, key: unknown, reason: string): Promise<number> {
  await q.query(`SELECT id FROM sessions WHERE ${scope} AND revoked_at IS NULL ORDER BY id FOR UPDATE`, [key]);
  const r = await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = $2 WHERE ${scope} AND revoked_at IS NULL`, [key, reason]);
  return r.rowCount ?? 0;
}

export function createPgSessionsRepository(q: Tx): SessionsRepository {
  return {
    async create({ userId, tokenHash, userAgent }) {
      // A new family per login; expires_at is absolute and comes from the database clock.
      const r = await q.query<{ id: string; family_id: string; expires_at: Date }>(
        `INSERT INTO sessions (user_id, family_id, token_hash, expires_at, user_agent)
         VALUES ($1, gen_random_uuid(), $2, now() + make_interval(secs => $3), $4)
         RETURNING id, family_id, expires_at`,
        [userId, tokenHash, SESSION_TTL_SECONDS, userAgent],
      );
      const row = r.rows[0] as { id: string; family_id: string; expires_at: Date };
      return { sessionId: row.id, familyId: row.family_id, expiresAt: row.expires_at };
    },

    async findActiveByFamily(familyId, userId) {
      const r = await q.query<UserSqlRow & { session_id: string; family_id: string; last_used_at: Date }>(
        `SELECT s.id AS session_id, s.family_id, s.last_used_at,
                u.id, u.name, u.phone_e164, u.role, u.status, u.phone_verified_at, u.created_at
           FROM sessions s
           JOIN users u ON u.id = s.user_id
          WHERE s.family_id = $1
            AND s.user_id = $2
            AND s.revoked_at IS NULL
            AND s.expires_at > now()
            AND u.deleted_at IS NULL
            AND (u.status = 'active' OR (u.status = 'pending' AND u.role = 'dealer'))`,
        [familyId, userId],
      );
      const row = r.rows[0];
      return row ? { sessionId: row.session_id, familyId: row.family_id, lastUsedAt: row.last_used_at, user: toUserRow(row) } : null;
    },

    async rotate({ presentedHash, newHash, userAgent }) {
      const found = await q.query<RotateSqlRow>(
        `SELECT s.id, s.family_id, s.user_id,
                s.revoked_at IS NOT NULL AS revoked, s.revoked_reason, s.expires_at <= now() AS expired,
                u.status, u.deleted_at IS NOT NULL AS deleted, u.name, u.phone_e164, u.role, u.phone_verified_at, u.created_at
           FROM sessions s
           JOIN users u ON u.id = s.user_id
          WHERE s.token_hash = $1
            FOR UPDATE OF s`,
        [presentedHash],
      );
      const row = found.rows[0];
      if (!row) return { kind: 'rejected' };

      if (row.revoked) {
        if (row.revoked_reason !== 'rotated') return { kind: 'rejected' };
        // A token that was already exchanged is being presented again: it was copied. End the whole login session.
        await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'reuse_detected' WHERE family_id = $1 AND revoked_at IS NULL`, [row.family_id]);
        return { kind: 'reuse', userId: row.user_id };
      }
      if (row.expired || row.deleted || !mayAuthenticate(row)) return { kind: 'rejected' };

      // Same family and the SAME absolute expiry (copied inside SQL, so microseconds are preserved).
      const inserted = await q.query<{ id: string; expires_at: Date }>(
        `INSERT INTO sessions (user_id, family_id, token_hash, expires_at, user_agent)
         SELECT user_id, family_id, $2::bytea, expires_at, $3::text FROM sessions WHERE id = $1
         RETURNING id, expires_at`,
        [row.id, newHash, userAgent],
      );
      const created = inserted.rows[0] as { id: string; expires_at: Date };
      await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'rotated', replaced_by = $2 WHERE id = $1`, [row.id, created.id]);
      return {
        kind: 'rotated',
        user: toUserRow({ id: row.user_id, name: row.name, phone_e164: row.phone_e164, role: row.role, status: row.status, phone_verified_at: row.phone_verified_at, created_at: row.created_at }),
        session: { sessionId: created.id, familyId: row.family_id, expiresAt: created.expires_at },
      };
    },

    async revokeFamilyByTokenHash(tokenHash) {
      const r = await q.query(
        `UPDATE sessions SET revoked_at = now(), revoked_reason = 'logout'
          WHERE revoked_at IS NULL AND family_id = (SELECT family_id FROM sessions WHERE token_hash = $1)`,
        [tokenHash],
      );
      return (r.rowCount ?? 0) > 0;
    },

    async revokeAllForUser(userId, reason) {
      // The users_revoke_sessions trigger already does this when password_hash changes; doing it explicitly keeps the
      // guarantee even if that trigger is ever altered. Parameterized: the reason is checked by the vocabulary CHECK.
      const r = await q.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = $2 WHERE user_id = $1 AND revoked_at IS NULL`, [userId, reason]);
      return r.rowCount ?? 0;
    },

    async revokeAllLive(userId, reason) {
      return revokeLive(q, LIVE_SCOPE.user, userId, reason);
    },

    async revokeFamilyLive(tokenHash) {
      return revokeLive(q, LIVE_SCOPE.family, tokenHash, 'logout');
    },


    async touch(sessionId) {
      await q.query(`UPDATE sessions SET last_used_at = now() WHERE id = $1 AND last_used_at < now() - make_interval(secs => $2)`, [sessionId, SESSION_TOUCH_INTERVAL_SECONDS]);
    },
  };
}

interface CodeSqlRow {
  id: string;
  code_hash: Buffer;
  attempts: number;
  max_attempts: number;
  expired: boolean;
}

export function createPgOtpRepository(q: Tx): OtpRepository {
  return {
    async issue({ userId, phoneE164, purpose, codeHash }) {
      // 0) Serialize issuance per (user, purpose): without this, N simultaneous requests all read "0 codes so far", all pass the
      //    limits below, and N messages go out. The lock lives until this transaction ends, so the next request counts the
      //    code the previous one just committed. (The unique index vcodes_one_active_uq stays as a second line of defense.)
      await q.query(`SELECT pg_advisory_xact_lock(hashtextextended($1, 0))`, [`najaf.otp:${purpose}:${userId}`]);

      // 1) How many codes were requested recently? (every row counts, superseded ones included.)
      const counts = await q.query<{ last_hour: number; last_day: number; cooldown_left: number }>(
        `SELECT count(*) FILTER (WHERE created_at > now() - interval '1 hour')::int AS last_hour,
                count(*) FILTER (WHERE created_at > now() - interval '1 day')::int AS last_day,
                COALESCE(ceil(extract(epoch FROM (max(created_at) + make_interval(secs => $3) - now()))), 0)::int AS cooldown_left
           FROM verification_codes
          WHERE user_id = $1 AND purpose = $2`,
        [userId, purpose, OTP.cooldownSeconds],
      );
      const c = counts.rows[0] as { last_hour: number; last_day: number; cooldown_left: number };
      if (c.cooldown_left > 0) return { kind: 'throttled', retryAfterSeconds: c.cooldown_left };
      if (c.last_hour >= OTP.perHour) return { kind: 'throttled', retryAfterSeconds: 60 * 60 };
      if (c.last_day >= OTP.perDay) return { kind: 'throttled', retryAfterSeconds: 24 * 60 * 60 };

      // 2) The previous active code stops working (the unique index vcodes_one_active_uq allows only one per user+purpose).
      await q.query(
        `UPDATE verification_codes SET invalidated_at = now()
          WHERE user_id = $1 AND purpose = $2 AND consumed_at IS NULL AND invalidated_at IS NULL`,
        [userId, purpose],
      );
      // 3) The new code: only its HMAC is stored. Expiry is the database clock.
      const inserted = await q.query<{ id: string; expires_at: Date }>(
        `INSERT INTO verification_codes (purpose, user_id, target_phone, code_hash, max_attempts, expires_at)
         VALUES ($1, $2, $3, $4, $5, now() + make_interval(secs => $6))
         RETURNING id, expires_at`,
        [purpose, userId, phoneE164, codeHash, OTP.maxAttempts, OTP.ttlSeconds],
      );
      const row = inserted.rows[0] as { id: string; expires_at: Date };
      return { kind: 'issued', codeId: row.id, expiresAt: row.expires_at };
    },

    async verify({ userId, phoneE164, purpose, expectedHash }) {
      // The purpose, the user AND the phone are part of the lookup: a code is only ever found by its own owner and purpose.
      const found = await q.query<CodeSqlRow>(
        `SELECT id, code_hash, attempts, max_attempts, expires_at <= now() AS expired
           FROM verification_codes
          WHERE user_id = $1 AND purpose = $2 AND target_phone = $3
            AND consumed_at IS NULL AND invalidated_at IS NULL
            FOR UPDATE`,
        [userId, purpose, phoneE164],
      );
      const row = found.rows[0];
      if (!row) return { kind: 'rejected', reason: 'no_active_code' };
      if (row.expired) return { kind: 'rejected', reason: 'expired' };
      if (row.attempts >= row.max_attempts) return { kind: 'rejected', reason: 'attempts_exhausted' };

      if (hashesEqual(row.code_hash, expectedHash)) {
        await q.query(`UPDATE verification_codes SET consumed_at = now() WHERE id = $1`, [row.id]);
        return { kind: 'verified' };
      }
      await q.query(`UPDATE verification_codes SET attempts = attempts + 1 WHERE id = $1 AND attempts < max_attempts`, [row.id]);
      return { kind: 'rejected', reason: 'mismatch' };
    },
  };
}

// Defense in depth for the audit trail: even if a caller tried, nothing that looks like a secret can be written.
const FORBIDDEN_AUDIT_KEY = /pass|hash|token|secret|code|otp|phone|key|cred/i;
export function assertAuditSafe(event: AuditEvent): void {
  for (const [k, v] of Object.entries(event.afterData)) {
    if (FORBIDDEN_AUDIT_KEY.test(k)) throw new Error(`audit data key "${k}" is not allowed`);
    if (typeof v !== 'number' || !Number.isFinite(v)) throw new Error(`audit data "${k}" must be a number`);
  }
}

export function createPgAuditRepository(q: Tx): AuditRepository {
  return {
    async record(event) {
      assertAuditSafe(event);
      await q.query(
        `INSERT INTO audit_logs (actor_id, actor_role, action, entity_type, entity_id, after_data, request_id)
         VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7)`,
        [event.actorUserId, event.actorRole, event.action, event.entityType, event.entityId, JSON.stringify(event.afterData), event.requestId ?? null],
      );
    },
  };
}

export function createPgAuthStore(db: Db): AuthStore {
  return {
    users: createPgUsersRepository(db),
    sessions: createPgSessionsRepository(db),
    transaction: (fn) => db.tx((t) => fn({ users: createPgUsersRepository(t), sessions: createPgSessionsRepository(t), otp: createPgOtpRepository(t), audit: createPgAuditRepository(t) })),
  };
}

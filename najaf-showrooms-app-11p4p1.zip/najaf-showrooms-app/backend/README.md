# Backend — أساس المرحلة 11.4.1

**الحالة بصراحة:** هذا الأساس **غير متصل بالواجهة** ولا يضيف أي ميزة للمستخدم. يحوي فقط: إعدادات البيئة، طبقة اتصال آمنة بـPostgreSQL 16، فحص الدور والمخطط عند الإقلاع، ونقطتَي صحة (`/healthz` و`/readyz`). الواجهة (التطبيق الحالي) ما زالت تعمل على `localStorage` كما كانت، ولم يُعدَّل فيها ملف.

## البنية
```
backend/
├── src/
│   ├── config.ts          إعدادات البيئة: تحقق كامل، لا كلمة مرور في الأخطاء أو السجلات
│   ├── errors.ts          تصنيف أخطاء المشغّل (SQLSTATE/شبكة) إلى DbError آمن (بلا SQL ولا قيم)
│   ├── http-errors.ts     تحويل الأخطاء إلى ردود HTTP عامة (409/422/403/503/500)
│   ├── role.ts            فحص أن الاتصال بدور أدنى امتيازًا (ليس superuser، عضو في najaf_app)
│   ├── schema-contract.ts العقد مع المخطط المُختبَر: 16 جدولًا + viewان (يُقارَن آليًا بالترحيلات)
│   ├── db.ts              Pool + query + tx (BEGIN/COMMIT/ROLLBACK مضمونة) + ping/verifyRole/checkSchema
│   ├── health.ts          liveness بلا قاعدة، readiness (اتصال + عقد المخطط) بلا تفاصيل للعميل
│   ├── server.ts          Fastify رفيع: /healthz و/readyz و404/خطأ عامّان، request-id، no-store
│   ├── index.ts           نقطة الدخول: config → db → سياسة الدور → خادم → إيقاف نظيف
│   └── types.ts           واجهة Logger (متوافقة مع pino)
├── scripts/db-check.ts    أداة تشغيل: تفحص الاتصال والدور والمخطط وتطبع JSON بلا أسرار
├── ops/create_app_login.sql  ينشئ دور الدخول الأدنى امتيازًا (كلمة المرور تُمرَّر -v ولا تُكتب في الملف)
├── test/unit/             اختبارات بلا قاعدة بيانات (تعمل في أي بيئة)
├── test/integration/      اختبارات على PostgreSQL حقيقي (تُتخطّى بوضوح بلا DATABASE_URL)
└── .env.example           كل متغيرات البيئة موثَّقة (اختبار آلي يمنع اختلافها عن الكود)
```
**القاعدة الحاكمة:** كل المنطق في وحدات **بلا اعتماديات** (تُختبر محليًا بالكامل)؛ و`pg` وFastify لا يظهران إلا في `db.ts` (استيراد كسول عبر factory) و`server.ts`.

## نموذج الأمان (ما اعتُمد)
- **لا اتصال بمشرف.** يتصل الـBackend بدور دخول (`najaf_app_login`) **عضو** في `najaf_app` (من الترحيل 0012) فيرث الامتيازات المُختبَرة فقط: بلا DDL ولا TRUNCATE، بلا DELETE على `users` و`showrooms` و`audit_logs` و`exchange_rates`، بلا تعديل `users.role`، وبعد 0013 بلا تعديل أعمدة الملكية والأوقات و`version`.
- **سياسة تُفرض عند الإقلاع** (`DB_REQUIRE_APP_ROLE=true`، ولا يُسمح بتعطيلها في الإنتاج): ترفض العملية الدور إن كان superuser أو يستطيع إنشاء أدوار/قواعد أو له replication/bypassrls أو ليس عضوًا في `najaf_app`، وترفض كذلك اسم المستخدم `postgres` في الإعداد. رمز الخروج 78.
- **TLS:** الافتراضي `verify-full` في الإنتاج، و`disable` مرفوض فيه؛ أنماط libpq التي تُضعف الأمان بصمت (`prefer`/`allow`/`verify-ca`) مرفوضة.
- **استعلامات مُعلَّمة فقط** (القيم لا تُدمج في SQL أبدًا)، و`checkSchema` يمرّر أسماء الكائنات معلَّمة كذلك.
- **مهلات من أول جملة:** `statement_timeout` و`lock_timeout` و`idle_in_transaction_session_timeout` كمعاملات بدء الاتصال (يتحقق منها اختبار التكامل بقراءة `current_setting`).
- **أخطاء بلا تسريب:** `DbError` يحمل النوع والـSQLSTATE واسم القيد فقط؛ رسالة المشغّل الأصلية للسجل الداخلي وحده؛ ردود HTTP عامة (لا SQL ولا أسماء قيود ولا تتبّع مكدّس).
- **المعاملات:** الاتصال يُحرَّر مرة واحدة دائمًا؛ فشل `ROLLBACK` يُتلف الاتصال بدل إعادة استعماله؛ استعلام المعاملة بعد انتهائها مرفوض.
- **readiness** لا يكشف شيئًا للعميل سوى حالات خشنة (`ok/fail/skipped`)؛ التفاصيل في السجل.

## البيئة (`.env.example`)
`DATABASE_URL` (أو `PGHOST`/`PGPORT`/`PGDATABASE`/`PGUSER`/`PGPASSWORD`)، `DB_SSL` و`DB_SSL_CA`، `DB_POOL_MAX` (10)، `DB_STATEMENT_TIMEOUT_MS` (15000)، `DB_LOCK_TIMEOUT_MS` (5000)، `DB_IDLE_IN_TX_TIMEOUT_MS` (15000)، `DB_CONNECT_TIMEOUT_MS` (5000)، `DB_IDLE_TIMEOUT_MS` (30000)، `DB_APPLICATION_NAME`، `DB_REQUIRE_APP_ROLE`، و`NODE_ENV` و`HOST` و`PORT` و`LOG_LEVEL`. القيم الخاطئة تُجمَع في خطأ واحد واضح، ولا يظهر فيه كلمة المرور أبدًا. لا ملف `.env` في المستودع (`.gitignore`).

## التشغيل
```bash
# 1) قاعدة PostgreSQL 16 بالترحيلات المُختبَرة
for f in ../database/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -1 -d najaf -f "$f"; done
# 2) دور الاتصال (مرة واحدة)
psql -v ON_ERROR_STOP=1 -d najaf -v login=najaf_app_login -v pw="$NAJAF_APP_PASSWORD" -f ops/create_app_login.sql
# 3) الاعتماديات والإعداد
npm install && cp .env.example .env     # عدّل DATABASE_URL
npm run db:check                         # يفحص الاتصال والدور والمخطط
npm run dev                              # خادم Node ≥ 22.18 يشغّل TypeScript مباشرة (بلا خطوة بناء)
```
`GET /healthz` ← `{"status":"ok"}`؛ `GET /readyz` ← 200 `{"status":"ready",...}` أو 503 `not_ready`.

## الاختبارات
| الأمر | ماذا يشغّل | يحتاج |
| --- | --- | --- |
| `npm test` | **117 اختبار وحدة** تعمل بلا أي اعتمادية: الإعدادات (27)، تصنيف الأخطاء وردود HTTP (44)، طبقة الاتصال بـpool مزيّف: خيارات `pg`، معاملات، تنظيف الاتصال، أخطاء (22)، سياسة الدور (8)، الصحة (7)، العقد مع الترحيلات (5)، توافق `.env.example` (4). ثم **7 اختبارات خادم HTTP** (Fastify `inject`) | Node ≥ 22.18. اختبارات الخادم تحتاج `npm install` وإلا تُتخطّى بوضوح كمجموعة |
| `npm run test:integration` | **58 اختبار تكامل** على PostgreSQL حقيقي: اتصال ودور ومهلات فعلية وكلمة مرور خاطئة وخادم غير متاح وحدّ الـpool وcommit/rollback وعدم تسريب الاتصالات (17)، **امتيازات الدور** (23 عملية ممنوعة و12 مسموحة + إضافة التدقيق + منع إنشاء مدير + 3 معارض/115 سيارة) (38)، وردود الصحة عبر HTTP (3) | `DATABASE_URL` (دور التطبيق) و`ADMIN_DATABASE_URL` (superuser للتجهيز فقط) |
| `npm run typecheck` | `tsc --noEmit` صارم (`erasableSyntaxOnly`) | `npm install` |

CI: `.github/workflows/backend.yml` (تشغيل يدوي) يطبّق الترحيلات المُختبَرة ويشغّل الثلاثة معًا + انحدار الواجهة (33 ملفًا) على PostgreSQL 16.

## التراجع (المرحلة قابلة للإزالة بالكامل)
هذه المرحلة **إضافية بحتة**: احذف `backend/` و`.github/workflows/backend.yml` وفقرة 11.4.1 من `README.md` الجذر، فيعود المشروع كما كان في 11p3 بلا أي أثر. لا ملف في الواجهة أو الخدمات أو المستودعات أو `database/` تغيّر.

## قرارات معمارية معلَّقة (لم تُنفَّذ عمدًا؛ تحتاج موافقتك قبل 11.4.2)
1. **TypeScript بلا بناء:** يُنفَّذ مباشرة بـNode ≥ 22.18 (type stripping) وتُفحَص أنواعه بـ`tsc` في CI. بديله: خطوة بناء (esbuild/tsc) — أُبقي المشروع بلا بناء اتساقًا مع قاعدته.
2. **Drizzle ORM** (المذكور في وثيقة 11.1) **مؤجَّل**: المخطط يعتمد مشغّلات وviews وصلاحيات أعمدة ومهاجرات SQL مكتوبة يدويًا واجتازت التحقق؛ فالمقترح SQL مُعلَّم مباشرة بـ`pg`، مع إعادة النظر عند نقل أول مستودع.
3. **Zod** مؤجَّل لحين وجود أول مسار يستقبل مدخلات.
4. **لا مشغّل ترحيلات في الباكند:** الترحيلات SQL تُطبَّق بـ`psql`؛ جدول تتبّع داخل المخطط سيغيّر ما اجتاز التحقق. خيارات 11.4.2: أداة خارجية (dbmate/graphile-migrate) أو مشغّل بمخطط `ops` منفصل.
5. **ملف قفل الحزم غير موجود:** بيئتي لا تثبّت حزم npm؛ يُنشأ `package-lock.json` من أول تشغيل ناجح في CI ويُلتزم به.

## خريطة الخدمات الحالية → وحدات الباكند القادمة (تصميم، غير منفَّذ)
| الواجهة الآن | وحدة الباكند | الجداول |
| --- | --- | --- |
| AuthService/SessionService/UserService | auth | users, sessions, verification_codes, message_deliveries |
| SearchService/VisibilityService/CarFilterService | catalog (قراءة عامة) | views: public_cars, public_showrooms |
| MemberCarsService/ShowroomCarsService/ShowroomService/FavoritesService | owners | cars, showrooms, favorites |
| CarImagesService/ImageService/ImageStore (IndexedDB) | uploads | assets, car_images + تخزين كائنات |
| AdminService | moderation | users, showrooms, cars, audit_logs |
| RewardService | rewards | reward_grants |
| FormatService (TEXT_LIMITS) وسعر الصرف | settings | app_settings, exchange_rates |
| AuthorizationService | سياسة `can(actor, action, resource)` واحدة | — |
| MigrationService (مخطط localStorage) | لا مقابل (تحلّ محلّه ترحيلات SQL) | — |

ربط الواجهة بالباكند (علم `DATA_SOURCE=local|api` ومستودعات بعيدة بالواجهة نفسها) في مرحلة لاحقة؛ الواجهة هنا لم تُلمَس.

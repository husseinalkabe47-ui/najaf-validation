-- ===== MIGRATION 0015 — حد السيارات المعروضة للخطة المجانية (المرحلة 11.9-F) =================
-- للأمام فقط؛ لا يعدّل أي ترحيل سابق ولا أي صف بيانات.
-- القاعدة نفسها التي تعتمدها entitlements_for_showroom (الترحيل 0011): اشتراك حيّ ساري (trialing/active/past_due مع
-- current_period_end > now()) = الخطة المدفوعة؛ وإلا فالمعرض على الخطة المجانية.
--   * الخطة المدفوعة السارية: عدد غير محدود من السيارات المتاحة (available) المعروضة للعامة.
--   * الخطة المجانية: 3 سيارات متاحة معروضة كحد أقصى لكل معرض. عند تجاوز الحد (مثلًا بعد انتهاء اشتراك) تبقى الأقدم
--     (created_at ثم id تصاعديًا: اختيار حتمي) ظاهرة، ويُخفى الزائد من العرض العام فقط: لا حذف، ولا تغيير لحالة السيارة،
--     ولا مساس بقرارات المالك أو الإشراف. عند تجديد الاشتراك يعود الزائد للظهور تلقائيًا لأن الحالة لم تتغيّر أصلًا.
--   * السيارات المباعة (sold) وإعلانات الأعضاء لا تدخل في الحد، وظهورها كما كان.
-- 1) دالة الحد التي يستعملها التطبيق داخل معاملة النشر (NULL = بلا حد).
CREATE FUNCTION showroom_active_car_limit(p_showroom bigint) RETURNS integer LANGUAGE sql STABLE AS $$
  SELECT CASE WHEN EXISTS (
           SELECT 1 FROM subscriptions s
            WHERE s.showroom_id = p_showroom AND s.status IN ('trialing', 'active', 'past_due') AND s.current_period_end > now())
         THEN NULL ELSE 3 END
$$;
REVOKE EXECUTE ON FUNCTION showroom_active_car_limit(bigint) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION showroom_active_car_limit(bigint) TO najaf_app;

-- 2) العرض العام: نفس الأعمدة ونفس الشروط، مع شرط الحد لسيارات المعارض المتاحة. الشرط مكتوب داخل الـview (لا عبر الدالة)
--    لأن صلاحيات الجداول داخل الـview تُفحص بصلاحيات مالكها، بينما تُفحص صلاحية تنفيذ الدوال بصلاحيات القارئ.
CREATE OR REPLACE VIEW public_cars WITH (security_barrier = true) AS
SELECT c.id, c.source_type, c.showroom_id, c.brand, c.model, c.year, c.price, c.currency, c.mileage,
       c.transmission, c.fuel_type, c.color, c.description, c.status,
       c.phone, c.whatsapp, c.location, c.latitude, c.longitude,
       CASE WHEN c.source_type = 'member' THEN uo.name END AS owner_name,
       c.search_text, c.created_at, c.updated_at
  FROM cars c
  LEFT JOIN public_showrooms ps ON ps.id = c.showroom_id
  LEFT JOIN users uo ON uo.id = c.owner_id
 WHERE c.deleted_at IS NULL
   AND ( (c.source_type = 'showroom' AND ps.id IS NOT NULL
          AND ( c.status <> 'available'
             OR EXISTS (SELECT 1 FROM subscriptions s
                         WHERE s.showroom_id = c.showroom_id AND s.status IN ('trialing', 'active', 'past_due') AND s.current_period_end > now())
             OR (SELECT count(*) FROM cars e
                  WHERE e.showroom_id = c.showroom_id AND e.source_type = 'showroom' AND e.status = 'available' AND e.deleted_at IS NULL
                    AND (e.created_at, e.id) < (c.created_at, c.id)) < 3 ))
      OR (c.source_type = 'member' AND c.status = 'active' AND uo.status = 'active' AND uo.deleted_at IS NULL) );

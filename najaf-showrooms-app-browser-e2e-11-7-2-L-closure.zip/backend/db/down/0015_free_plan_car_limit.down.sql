-- Rollback of 0015 (Phase 11.9-F), written by hand: the public_cars view of 0012 exactly as it was, then the limit function.
-- No row is touched by 0015, so nothing else needs restoring.
CREATE OR REPLACE VIEW public_cars WITH (security_barrier = true) AS
SELECT c.id, c.source_type, c.showroom_id, c.brand, c.model, c.year, c.price, c.currency, c.mileage,
       c.transmission, c.fuel_type, c.color, c.description, c.status,
       c.phone, c.whatsapp, c.location, c.latitude, c.longitude,
       CASE WHEN c.source_type = 'member' THEN uo.name END AS owner_name,
       c.search_text, c.created_at, c.updated_at
  FROM cars c
  LEFT JOIN public_showrooms ps ON ps.id = c.showroom_id
  LEFT JOIN users uo ON uo.id = c.owner_id
 WHERE c.deleted_at IS NULL
   AND ( (c.source_type = 'showroom' AND ps.id IS NOT NULL)
      OR (c.source_type = 'member' AND c.status = 'active' AND uo.status = 'active' AND uo.deleted_at IS NULL) );
REVOKE EXECUTE ON FUNCTION showroom_active_car_limit(bigint) FROM najaf_app;
GRANT EXECUTE ON FUNCTION showroom_active_car_limit(bigint) TO PUBLIC;
DROP FUNCTION IF EXISTS showroom_active_car_limit(bigint);

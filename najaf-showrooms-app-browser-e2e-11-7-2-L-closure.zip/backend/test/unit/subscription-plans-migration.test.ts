// Phase 11.9-B: migration 0014 (subscription plan durations). Static checks of the forward-only SQL and its rollback: the three plans
// (3, 6, 12 months), IQD, initial price 0, the duration column and its constraints, the free plan and entitlements untouched, no
// earlier migration rewritten, and nothing beyond plans (no subscriptions, payments, grants or functions). Behaviour on a real
// PostgreSQL 16 is in test/integration/subscription-plans.integration.test.ts (CI).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const root = join(import.meta.dirname, '..', '..', '..');
const up = readFileSync(join(root, 'database', 'migrations', '0014_subscription_plan_durations.sql'), 'utf8');
const down = readFileSync(join(root, 'backend', 'db', 'down', '0014_subscription_plan_durations.down.sql'), 'utf8');
const code = (sql: string) => sql.replace(/--[^\n]*/g, '');
const upCode = code(up);

describe('migration 0014: the three plans', () => {
  const rows = [...upCode.matchAll(/\('(plan_\d+m)',\s*'([^']+)',\s*(NULL|'\w+'),\s*(\d+),\s*(\d+),\s*'(\w+)',\s*'(\{[^']*\})'::jsonb\)/g)].map((m) => ({
    code: m[1]!, name: m[2]!, interval: m[3]!, months: Number(m[4]), price: Number(m[5]), currency: m[6]!, entitlements: m[7]!,
  }));
  it('seeds exactly plan_3m, plan_6m and plan_12m with durations 3, 6 and 12', () => {
    assert.deepEqual(rows.map((r) => [r.code, r.months]), [['plan_3m', 3], ['plan_6m', 6], ['plan_12m', 12]]);
  });
  it('every plan is in IQD with an initial price of 0 and no entitlements yet', () => {
    for (const r of rows) assert.deepEqual([r.currency, r.price, r.entitlements], ['IQD', 0, '{}'], r.code);
  });
  it('the duration lives in duration_months; billing_interval stays NULL (month/year cannot express 3 or 6)', () => {
    for (const r of rows) assert.equal(r.interval, 'NULL', r.code);
  });
  it('the seed is idempotent on the unique plan code', () => {
    assert.match(upCode, /ON CONFLICT \(code\) DO NOTHING;/);
  });
});

describe('migration 0014: column and constraints', () => {
  it('adds a nullable smallint duration_months restricted to 3, 6, 12', () => {
    assert.match(upCode, /ALTER TABLE subscription_plans ADD COLUMN duration_months smallint;/);
    assert.match(upCode, /ADD CONSTRAINT plans_duration_vocab CHECK \(duration_months IS NULL OR duration_months IN \(3, 6, 12\)\);/);
  });
  it('allows one plan per duration', () => {
    assert.match(upCode, /CREATE UNIQUE INDEX plans_duration_uq ON subscription_plans \(duration_months\) WHERE duration_months IS NOT NULL;/);
  });
  it('widens (never narrows) the priced-plan rule: a duration also satisfies it', () => {
    assert.match(upCode, /plans_priced_needs_interval CHECK \(price = 0 OR billing_interval IS NOT NULL OR duration_months IS NOT NULL\);/);
  });
  it('is forward-only SQL: no destructive statement on existing data', () => {
    for (const w of ['DROP TABLE', 'TRUNCATE', 'DELETE FROM', 'UPDATE ', 'CASCADE', 'DROP COLUMN']) assert.ok(!upCode.includes(w), w);
  });
  it('touches nothing but subscription_plans: the free plan, subscriptions, payments, functions and grants stay as they are', () => {
    const tables = new Set([...upCode.matchAll(/(?:ALTER TABLE|INSERT INTO|CREATE UNIQUE INDEX \w+ ON)\s+(\w+)/g)].map((m) => m[1]));
    assert.deepEqual([...tables], ['subscription_plans']);
    for (const w of ['CREATE FUNCTION', 'CREATE OR REPLACE', 'GRANT', 'REVOKE', "'free'", 'entitlements_for_showroom']) assert.ok(!upCode.includes(w), w);
  });
  it('declares no new table (the schema contract table list is unchanged)', () => {
    assert.doesNotMatch(upCode, /CREATE TABLE/);
  });
});

describe('migration 0014: rollback', () => {
  it('removes only what 0014 added, in a safe order (rows, constraint, index, column)', () => {
    const lines = code(down).split('\n').map((l) => l.trim()).filter(Boolean);
    assert.deepEqual(lines, [
      "DELETE FROM subscription_plans WHERE code IN ('plan_3m', 'plan_6m', 'plan_12m');",
      'ALTER TABLE subscription_plans DROP CONSTRAINT plans_priced_needs_interval;',
      'ALTER TABLE subscription_plans ADD CONSTRAINT plans_priced_needs_interval CHECK (price = 0 OR billing_interval IS NOT NULL);',
      'DROP INDEX IF EXISTS plans_duration_uq;',
      'ALTER TABLE subscription_plans DROP CONSTRAINT plans_duration_vocab;',
      'ALTER TABLE subscription_plans DROP COLUMN duration_months;',
    ]);
  });
  it('restores exactly the constraint migration 0010 defined', () => {
    const original = readFileSync(join(root, 'database', 'migrations', '0010_subscriptions.sql'), 'utf8');
    assert.match(original, /CONSTRAINT plans_priced_needs_interval CHECK \(price = 0 OR billing_interval IS NOT NULL\),/);
  });
});

describe('migration 0014: earlier migrations are untouched and the new one is registered', () => {
  const db = join(root, 'database');
  const sums = new Map(readFileSync(join(db, 'CHECKSUMS.sha256'), 'utf8').split('\n').filter((l) => l.includes('  migrations/')).map((l) => [l.split('  ')[1]!, l.split('  ')[0]!]));
  it('0001-0013 still match the recorded SHA-256 and 0014 is recorded', () => {
    for (const f of readdirSync(join(db, 'migrations')).filter((x) => x.endsWith('.sql'))) {
      assert.equal(createHash('sha256').update(readFileSync(join(db, 'migrations', f))).digest('hex'), sums.get(`migrations/${f}`), f);
    }
    assert.equal(sums.size, 15); // 0015 (Phase 11.9-F) is the next forward-only migration
    assert.ok(sums.has('migrations/0014_subscription_plan_durations.sql'));
  });
  it('the original 0010 and 0011 mention neither duration_months nor the new plans', () => {
    for (const f of ['0010_subscriptions.sql', '0011_audit_settings_functions.sql']) {
      assert.doesNotMatch(readFileSync(join(db, 'migrations', f), 'utf8'), /duration_months|plan_3m|plan_6m|plan_12m/, f);
    }
  });
});

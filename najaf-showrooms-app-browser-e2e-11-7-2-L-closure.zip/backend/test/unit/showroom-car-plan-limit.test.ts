// Phase 11.9-F: the free plan's active-car limit on every path that makes a showroom car 'available' (create, the dealer's
// sold -> available, the administrator's sold -> available), over the in-memory store whose quota stands in for the database function
// showroom_active_car_limit; plus static checks of migration 0015 (the public_cars cap, the function, the hand-written rollback) and
// of the repository's lock. The SQL itself runs in test/integration/plan-car-limit.integration.test.ts.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Actor } from '../../src/authz/index.ts';
import { LOCK_SHOWROOM_QUOTA_SQL, PUBLISHING_QUOTA_SQL } from '../../src/showroom-cars/repository.ts';
import { toShowroomCarHttp } from '../../src/showroom-cars/routes.ts';
import { FREE_ACTIVE_CAR_LIMIT, ShowroomCarError, createShowroomCarService } from '../../src/showroom-cars/service.ts';
import type { ShowroomCarView } from '../../src/showroom-cars/service.ts';
import { makeFakeShowroomCarStore } from '../helpers/fake-showroom-cars.ts';

const D1: Actor = Object.freeze({ id: '10', role: 'dealer' });
const D2: Actor = Object.freeze({ id: '11', role: 'dealer' });
const ADMIN: Actor = Object.freeze({ id: '30', role: 'admin' });
const VALID = { brand: 'Toyota', model: 'Camry', year: 2022, price: 30000000, currency: 'IQD', color: 'أبيض' };
const ROOT = join(import.meta.dirname, '..', '..', '..');
const read = (rel: string): string => readFileSync(join(ROOT, rel), 'utf8');
const isLimit = (e: unknown) => e instanceof ShowroomCarError && e.code === 'plan_limit_reached';

function setup(limit: number | null = FREE_ACTIVE_CAR_LIMIT) {
  const f = makeFakeShowroomCarStore();
  for (const a of [D1, D2, ADMIN]) f.addUser(a.id);
  const s1 = f.addShowroom({ ownerId: D1.id });
  const s2 = f.addShowroom({ ownerId: D2.id });
  f.setActiveCarLimit(s1.id, limit);
  f.setActiveCarLimit(s2.id, FREE_ACTIVE_CAR_LIMIT);
  const svc = createShowroomCarService({ store: f.store });
  return { f, svc, s1, s2 };
}
const available = (f: ReturnType<typeof setup>['f'], showroomId: string) => f.cars().filter((c) => c.showroomId === showroomId && c.status === 'available' && !c.deleted).length;

describe('free plan: at most 3 available cars per showroom', () => {
  it('the limit is 3', () => assert.equal(FREE_ACTIVE_CAR_LIMIT, 3));

  it('creates 3 cars, refuses the 4th with 409 plan_limit_reached, and writes nothing for it (no row, no audit)', async () => {
    const { f, svc, s1 } = setup();
    for (let i = 0; i < 3; i++) await svc.create(D1, VALID);
    const before = JSON.stringify([f.cars(), f.audits()]);
    await assert.rejects(() => svc.create(D1, VALID), isLimit);
    assert.equal(JSON.stringify([f.cars(), f.audits()]), before);
    assert.equal(available(f, s1.id), 3);
  });

  it('the limit is per showroom: another free showroom has its own 3', async () => {
    const { f, svc, s2 } = setup();
    for (let i = 0; i < 3; i++) await svc.create(D1, VALID);
    for (let i = 0; i < 3; i++) await svc.create(D2, VALID);
    await assert.rejects(() => svc.create(D2, VALID), isLimit);
    assert.equal(available(f, s2.id), 3);
  });

  it('sold and deleted cars do not count: marking one sold or deleting one frees a place', async () => {
    const { f, svc, s1 } = setup();
    const cars: ShowroomCarView[] = [];
    for (let i = 0; i < 3; i++) cars.push(await svc.create(D1, VALID));
    await svc.update(D1, cars[0]!.id, { version: 1, status: 'sold' });
    await svc.create(D1, VALID);
    await svc.remove(D1, cars[1]!.id, { version: '1' });
    await svc.create(D1, VALID);
    assert.equal(available(f, s1.id), 3);
    await assert.rejects(() => svc.create(D1, VALID), isLimit);
  });

  it('the dealer cannot bring a sold car back to available at the limit (409, unchanged), but can once a place is free', async () => {
    const { f, svc } = setup();
    const a = await svc.create(D1, VALID);
    await svc.update(D1, a.id, { version: 1, status: 'sold' });
    const others = [await svc.create(D1, VALID), await svc.create(D1, VALID), await svc.create(D1, VALID)];
    await assert.rejects(() => svc.update(D1, a.id, { version: 2, status: 'available' }), isLimit);
    await assert.rejects(() => svc.update(D1, a.id, { version: 2, status: 'available', price: 1 }), isLimit); // with other fields too
    assert.deepEqual([f.car(a.id).status, f.car(a.id).version, f.car(a.id).price], ['sold', 2, '30000000']);
    await svc.update(D1, others[0]!.id, { version: 1, status: 'sold' });
    const back = await svc.update(D1, a.id, { version: 2, status: 'available' });
    assert.equal(back.status, 'available');
  });

  it('never limits editing, marking sold or deleting, even above the limit (cars kept from a paid period)', async () => {
    const { f, svc, s1 } = setup(null);
    const cars: ShowroomCarView[] = [];
    for (let i = 0; i < 5; i++) cars.push(await svc.create(D1, VALID)); // published while unlimited
    f.setActiveCarLimit(s1.id, FREE_ACTIVE_CAR_LIMIT); // the subscription ended
    const edited = await svc.update(D1, cars[4]!.id, { version: 1, price: 29000000 });
    assert.equal(edited.price, 29000000);
    const same = await svc.update(D1, cars[3]!.id, { version: 1, status: 'available', color: 'أسود' }); // already available: not a publication
    assert.equal(same.status, 'available');
    await svc.update(D1, cars[2]!.id, { version: 1, status: 'sold' });
    await svc.remove(D1, cars[1]!.id, { version: '1' });
    assert.equal(available(f, s1.id), 3);
    await assert.rejects(() => svc.create(D1, VALID), isLimit);
  });

  it('the administrator\'s sold -> available is limited the same way; marking sold and a no-op are not', async () => {
    const { f, svc } = setup();
    const a = await svc.create(D1, VALID);
    await svc.setStatusAsAdmin(ADMIN, a.id, { version: 1, status: 'sold' });
    for (let i = 0; i < 3; i++) await svc.create(D1, VALID);
    await assert.rejects(() => svc.setStatusAsAdmin(ADMIN, a.id, { version: 2, status: 'available' }), isLimit);
    assert.equal(f.car(a.id).status, 'sold');
    const noop = await svc.setStatusAsAdmin(ADMIN, a.id, { version: 2, status: 'sold' });
    assert.equal(noop.version, 2);
  });

  it('checks the quota only on a publication (create, sold -> available), never on other writes', async () => {
    const { f, svc } = setup();
    const a = await svc.create(D1, VALID);
    assert.equal(f.calls.filter((c) => c === 'lockPublishingQuota').length, 1);
    f.calls.length = 0;
    await svc.update(D1, a.id, { version: 1, price: 5 });
    await svc.update(D1, a.id, { version: 2, status: 'sold' });
    await svc.setStatusAsAdmin(ADMIN, a.id, { version: 3, status: 'sold' });
    await svc.remove(D1, a.id, { version: '3' });
    assert.ok(!f.calls.includes('lockPublishingQuota'));
  });

  it('concurrent creates cannot exceed the limit: exactly 3 of 8 succeed, the rest are 409', async () => {
    const { f, svc, s1 } = setup();
    const results = await Promise.allSettled(Array.from({ length: 8 }, () => svc.create(D1, VALID)));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 3);
    assert.ok(results.filter((r) => r.status === 'rejected').every((r) => isLimit((r as PromiseRejectedResult).reason)));
    assert.equal(available(f, s1.id), 3);
    assert.equal(f.audits().filter((a) => a.action === 'showroom_car.create').length, 3);
  });

  it('an unknown showroom behind the quota is 404, not a publication', async () => {
    const f = makeFakeShowroomCarStore();
    f.addUser(D1.id);
    f.addShowroom({ ownerId: D1.id });
    const svc = createShowroomCarService({ store: { ...f.store, transaction: (fn) => f.store.transaction(({ cars, audit }) => fn({ cars: { ...cars, lockPublishingQuota: async () => null }, audit })) } });
    await assert.rejects(() => svc.create(D1, VALID), (e: unknown) => (e as { code?: string }).code === 'not_found');
  });

  it('answers 409 plan_limit_reached over HTTP (no fields, no internal detail)', () => {
    assert.deepEqual(toShowroomCarHttp(new ShowroomCarError('plan_limit_reached')), { status: 409, code: 'plan_limit_reached', message: 'The showroom already has the maximum number of available cars for its plan' });
  });
});

describe('paid plan in force: no limit', () => {
  it('publishes any number of cars', async () => {
    const { f, svc, s1 } = setup(null);
    for (let i = 0; i < 12; i++) await svc.create(D1, VALID);
    assert.equal(available(f, s1.id), 12);
  });
});

describe('the lock and the quota statement', () => {
  it('locks the showroom row first (FOR NO KEY UPDATE), then reads limit and count in a separate statement', () => {
    assert.equal(LOCK_SHOWROOM_QUOTA_SQL, 'SELECT id FROM showrooms WHERE id = $1::bigint FOR NO KEY UPDATE');
    assert.match(PUBLISHING_QUOTA_SQL, /showroom_active_car_limit\(\$1::bigint\)/);
    assert.match(PUBLISHING_QUOTA_SQL, /c\.showroom_id = \$1::bigint AND c\.source_type = 'showroom' AND c\.status = 'available' AND c\.deleted_at IS NULL/);
    assert.doesNotMatch(PUBLISHING_QUOTA_SQL, /FOR (NO KEY )?UPDATE/);
  });
});

describe('migration 0015', () => {
  const up = read('database/migrations/0015_free_plan_car_limit.sql');
  const down = read('backend/db/down/0015_free_plan_car_limit.down.sql');
  const code = (s: string) => s.split('\n').filter((l) => !l.trimStart().startsWith('--')).join('\n');
  const IN_FORCE = /s\.status IN \('trialing', 'active', 'past_due'\) AND s\.current_period_end > now\(\)/;

  it('uses the entitlement rule of 0011 (a live subscription in force = paid) in both the function and the view', () => {
    assert.match(read('database/migrations/0011_audit_settings_functions.sql'), /s\.status IN \('trialing', 'active', 'past_due'\) AND s\.current_period_end > now\(\)/);
    const fn = code(up).slice(code(up).indexOf('CREATE FUNCTION'), code(up).indexOf('$$;') + 3);
    assert.match(fn, IN_FORCE);
    assert.match(fn, /THEN NULL ELSE 3 END/);
    assert.match(code(up).slice(code(up).indexOf('CREATE OR REPLACE VIEW')), IN_FORCE);
  });

  it('caps only AVAILABLE showroom cars, keeps the oldest 3 (created_at, then id) and leaves sold cars and member ads as they were', () => {
    const view = code(up).slice(code(up).indexOf('CREATE OR REPLACE VIEW'));
    assert.match(view, /c\.status <> 'available'/);
    assert.match(view, /e\.showroom_id = c\.showroom_id AND e\.source_type = 'showroom' AND e\.status = 'available' AND e\.deleted_at IS NULL\s+AND \(e\.created_at, e\.id\) < \(c\.created_at, c\.id\)\) < 3/);
    assert.match(view, /OR \(c\.source_type = 'member' AND c\.status = 'active' AND uo\.status = 'active' AND uo\.deleted_at IS NULL\) \);/);
  });

  it('keeps every column of the 0012 view (same SELECT list), and the rollback restores the 0012 view verbatim', () => {
    const v12 = read('database/migrations/0012_views_grants.sql');
    const block12 = v12.slice(v12.indexOf('CREATE VIEW public_cars'), v12.indexOf(';', v12.indexOf('CREATE VIEW public_cars')) + 1);
    const select = (s: string) => s.slice(s.indexOf('SELECT'), s.indexOf(' WHERE'));
    const upView = code(up).slice(code(up).indexOf('CREATE OR REPLACE VIEW'));
    assert.equal(select(upView), select(block12));
    assert.ok(code(down).includes(block12.replace('CREATE VIEW', 'CREATE OR REPLACE VIEW')), 'the rollback is the 0012 definition');
  });

  it('changes no row and drops nothing but its own function; the function is executable by the app role only', () => {
    assert.doesNotMatch(code(up), /\b(INSERT|UPDATE|DELETE|TRUNCATE|DROP|ALTER TABLE)\b/);
    assert.match(code(up), /REVOKE EXECUTE ON FUNCTION showroom_active_car_limit\(bigint\) FROM PUBLIC;/);
    assert.match(code(up), /GRANT EXECUTE ON FUNCTION showroom_active_car_limit\(bigint\) TO najaf_app;/);
    assert.match(code(down), /DROP FUNCTION IF EXISTS showroom_active_car_limit\(bigint\);/);
    assert.doesNotMatch(code(down), /\b(INSERT|UPDATE|DELETE|TRUNCATE)\b/);
  });

  it('the service limit and the database limit are the same number', () => {
    assert.match(code(up), new RegExp(`ELSE ${FREE_ACTIVE_CAR_LIMIT} END`));
    assert.match(code(up), new RegExp(`\\) < ${FREE_ACTIVE_CAR_LIMIT} \\)\\)`));
  });
});

describe('owner visibility vs public visibility (11.9-F correction)', () => {
  it('after a downgrade the owner\'s private list and detail still return every own car; another dealer gets 404', async () => {
    const { f, svc, s1 } = setup(null);
    const created: ShowroomCarView[] = [];
    for (let i = 0; i < 6; i++) created.push(await svc.create(D1, VALID));
    f.setActiveCarLimit(s1.id, FREE_ACTIVE_CAR_LIMIT); // the paid period ended
    const page = await svc.listOwn(D1, { limit: '50' });
    assert.deepEqual(page.items.map((x) => x.id).sort(), created.map((x) => x.id).sort());
    for (const car of created) assert.equal((await svc.getOwn(D1, car.id)).status, 'available');
    await assert.rejects(() => svc.getOwn(D2, created[5]!.id), (e: unknown) => (e as { code?: string }).code === 'not_found');
    assert.ok(!(await svc.listOwn(D2, { limit: '50' })).items.some((x) => x.id === created[5]!.id));
  });

  it('private owner reads never go through the public view; every public read does', () => {
    const src = (rel: string) => read(`backend/${rel}`).split('\n').filter((l) => !l.trimStart().startsWith('//') && !l.trimStart().startsWith('*')).join('\n');
    for (const f of ['src/showroom-cars/repository.ts', 'src/showroom-car-images/repository.ts']) assert.doesNotMatch(src(f), /public_cars/, f);
    const delivery = src('src/assets/delivery-repository.ts');
    const ownReady = delivery.slice(delivery.indexOf('export function buildFindOwnReady'), delivery.indexOf('\n}', delivery.indexOf('export function buildFindOwnReady')));
    assert.match(ownReady, /a\.owner_id = \$2::bigint/);
    assert.doesNotMatch(ownReady, /public_cars/);
    assert.match(src('src/catalog/repository.ts'), /FROM public_cars pc/);
    assert.match(src('src/favorites/repository.ts'), /FROM public_cars pc/);
    assert.match(delivery, /JOIN public_cars pc/);
  });
});

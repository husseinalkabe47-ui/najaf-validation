// Images of a showroom owner's own showroom cars (Phase 11.7.2-I) against a real PostgreSQL 16 (migrations 0001-0013 applied),
// through the least-privilege application role. Needs DATABASE_URL (najaf_app_login) and ADMIN_DATABASE_URL (superuser: fixtures and
// cleanup ONLY). Skipped visibly when they are missing. Proves what the in-memory unit tests cannot: the showroom scoping of the SQL,
// the car_images triggers (showroom cap 5 from app_settings, asset owner = showroom owner, one main at COMMIT), that deleting a link
// keeps the asset, that concurrent adds serialize under the car row lock, and that the existing PUBLIC images query serves the images.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, randomInt, randomUUID } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createPgDeliveryRepository } from '../../src/assets/delivery-repository.ts';
import { CarImageError } from '../../src/car-images/service.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { DbError } from '../../src/errors.ts';
import { createPgShowroomImageStore } from '../../src/showroom-car-images/repository.ts';
import { createShowroomCarImageService } from '../../src/showroom-car-images/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

describe('showroom car images on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  const userIds: string[] = [];
  let D1: Actor;
  let D2: Actor;
  let M: Actor;
  let s1: string;
  let s2: string;
  let svc: ReturnType<typeof createShowroomCarImageService>;
  let svc2: ReturnType<typeof createShowroomCarImageService>;

  const newUser = async (role: 'user' | 'dealer'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(
      `INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA') RETURNING id`,
      [phone, role],
    );
    const id = String(r.rows[0]!.id);
    userIds.push(id);
    return id;
  };
  const newShowroom = async (ownerId: string, status = 'active'): Promise<string> =>
    String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض اختبار', $2) RETURNING id`, [ownerId, status])).rows[0]!.id);
  const newCar = async (showroomId: string): Promise<string> =>
    String((await admin.query<{ id: string }>(
      `INSERT INTO cars (source_type, showroom_id, brand, model, year, price, currency, status, search_text) VALUES ('showroom', $1::bigint, 'Kia', 'Sportage', 2022, 31000000, 'IQD', 'available', 'kia sportage 2022') RETURNING id`,
      [showroomId],
    )).rows[0]!.id);
  const newMemberCar = async (ownerId: string): Promise<string> =>
    String((await admin.query<{ id: string }>(
      `INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status, search_text) VALUES ('member', $1::bigint, 'Toyota', 'Corolla', 2016, 14500, 'USD', '+9647701234567', 'النجف', 'active', 'toyota corolla 2016') RETURNING id`,
      [ownerId],
    )).rows[0]!.id);
  const newAsset = async (ownerId: string, opts: { status?: string; kind?: string } = {}): Promise<string> => {
    const status = opts.status ?? 'ready';
    const id = randomUUID();
    const hex = randomBytes(32).toString('hex');
    if (status === 'ready') {
      await admin.query(
        `INSERT INTO assets (id, owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at)
         VALUES ($1::uuid, $2::bigint, $3, 'ready', $4, $5, 'image/webp', 1000, 800, 600, $6, now())`,
        [id, ownerId, opts.kind ?? 'car_image', `it/${hex}.webp`, `it/${hex}-t.webp`, hex],
      );
    } else {
      await admin.query(`INSERT INTO assets (id, owner_id, kind, status, reject_reason) VALUES ($1::uuid, $2::bigint, $3, $4, $5)`, [id, ownerId, opts.kind ?? 'car_image', status, status === 'rejected' ? 'test' : null]);
    }
    return id;
  };
  const links = async (carId: string) => (await admin.query<{ asset_id: string; sort_order: number; is_main: boolean }>('SELECT asset_id, sort_order, is_main FROM car_images WHERE car_id = $1::bigint ORDER BY sort_order', [carId])).rows.map((r) => ({ ...r }));
  const notFound = (e: unknown) => e instanceof AuthzError && e.code === 'not_found';
  const imgErr = (code: string) => (e: unknown) => e instanceof CarImageError && e.code === code;

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    D1 = { id: await newUser('dealer'), role: 'dealer' };
    D2 = { id: await newUser('dealer'), role: 'dealer' };
    M = { id: await newUser('user'), role: 'member' };
    s1 = await newShowroom(D1.id);
    // Phase 11.9-F: these suites publish more than the free plan's 3 cars in one showroom; a paid subscription in force keeps their
    // meaning (unlimited). It is removed with the showroom (subscriptions.showroom_id ON DELETE CASCADE).
    await admin.query(`INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end)
                       VALUES ($1::bigint, (SELECT id FROM subscription_plans WHERE code = 'plan_12m'), 'active', now() - interval '1 day', now() + interval '365 days')`, [s1]);
    s2 = await newShowroom(D2.id);
    svc = createShowroomCarImageService({ store: createPgShowroomImageStore(app) });
    svc2 = createShowroomCarImageService({ store: createPgShowroomImageStore(app2) });
  });
  after(async () => {
    if (admin && userIds.length > 0) {
      await admin.query('DELETE FROM car_images WHERE car_id IN (SELECT id FROM cars WHERE showroom_id IN (SELECT id FROM showrooms WHERE owner_id = ANY($1::bigint[])) OR owner_id = ANY($1::bigint[]))', [userIds]);
      await admin.query('DELETE FROM cars WHERE showroom_id IN (SELECT id FROM showrooms WHERE owner_id = ANY($1::bigint[])) OR owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM showrooms WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM assets WHERE owner_id = ANY($1::bigint[])', [userIds]);
      await admin.query('DELETE FROM users WHERE id = ANY($1::bigint[])', [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('attaches the first own asset as main, the next at the end, with a dealer audit row; the car version is untouched', async () => {
    const car = await newCar(s1);
    const a1 = await newAsset(D1.id);
    const a2 = await newAsset(D1.id);
    const first = await svc.add(D1, car, { assetId: a1 }, { requestId: 'it-simg-1' });
    assert.deepEqual([first.isMain, first.sortOrder, first.width], [true, 0, 800]);
    const second = await svc.add(D1, car, { assetId: a2 });
    assert.deepEqual([second.isMain, second.sortOrder], [false, 1]);
    assert.deepEqual((await links(car)).map((l) => [l.asset_id, l.sort_order, l.is_main]), [[a1, 0, true], [a2, 1, false]]);
    const listed = await svc.list(D1, car);
    assert.deepEqual([listed.images.length, listed.maxImages], [2, 5]);
    assert.equal(Number((await admin.query<{ version: number }>('SELECT version FROM cars WHERE id = $1::bigint', [car])).rows[0]!.version), 1);
    const audit = await admin.query<{ action: string; actor_role: string }>(`SELECT action, actor_role FROM audit_logs WHERE request_id = 'it-simg-1'`);
    assert.deepEqual(audit.rows.map((r) => ({ ...r })), [{ action: 'showroom_car.image_add', actor_role: 'dealer' }]);
  });

  it("another dealer, a member and no actor cannot list, add to or delete from the car (404); another user's asset is 404", async () => {
    const car = await newCar(s1);
    const mine = await newAsset(D1.id);
    const theirs = await newAsset(D2.id);
    const img = await svc.add(D1, car, { assetId: mine });
    for (const other of [D2, M, null]) {
      await assert.rejects(svc.list(other, car), notFound);
      await assert.rejects(svc.add(other, car, { assetId: theirs }), notFound);
      await assert.rejects(svc.remove(other, car, img.id), notFound);
    }
    await assert.rejects(svc.add(D1, car, { assetId: theirs }), notFound);
    assert.equal((await links(car)).length, 1);
  });

  it("a member ad and another showroom's car are not reachable through the dealer routes", async () => {
    const member = await newMemberCar(M.id);
    const theirs = await newCar(s2);
    const asset = await newAsset(D1.id);
    for (const id of [member, theirs]) {
      await assert.rejects(svc.list(D1, id), notFound);
      await assert.rejects(svc.add(D1, id, { assetId: asset }), notFound);
    }
    assert.equal((await links(member)).length + (await links(theirs)).length, 0);
  });

  it("an image of another showroom's car (or of another car) cannot be deleted through this car", async () => {
    const mine = await newCar(s1);
    const mine2 = await newCar(s1);
    const theirs = await newCar(s2);
    const onMine = await svc.add(D1, mine, { assetId: await newAsset(D1.id) });
    const onTheirs = await svc.add(D2, theirs, { assetId: await newAsset(D2.id) });
    await assert.rejects(svc.remove(D1, mine, onTheirs.id), notFound);
    await assert.rejects(svc.remove(D1, theirs, onTheirs.id), notFound);
    await assert.rejects(svc.remove(D1, mine2, onMine.id), notFound);
    assert.equal((await links(mine)).length + (await links(theirs)).length, 2);
  });

  it('refuses a pending, rejected or showroom_cover asset and an asset already attached (409 invalid_state)', async () => {
    const car = await newCar(s1);
    const car2 = await newCar(s1);
    for (const assetId of [await newAsset(D1.id, { status: 'pending' }), await newAsset(D1.id, { status: 'rejected' }), await newAsset(D1.id, { kind: 'showroom_cover' })]) {
      await assert.rejects(svc.add(D1, car, { assetId }), imgErr('invalid_state'));
    }
    const ok = await newAsset(D1.id);
    await svc.add(D1, car, { assetId: ok });
    await assert.rejects(svc.add(D1, car2, { assetId: ok }), imgErr('invalid_state'));
  });

  it('stops at the showroom limit 5 from app_settings (409 image_limit); a freed slot can be used again', async () => {
    const car = await newCar(s1);
    const ids: string[] = [];
    for (let i = 0; i < 5; i++) ids.push((await svc.add(D1, car, { assetId: await newAsset(D1.id) })).id);
    await assert.rejects(svc.add(D1, car, { assetId: await newAsset(D1.id) }), imgErr('image_limit'));
    await svc.remove(D1, car, ids[4]!);
    await svc.add(D1, car, { assetId: await newAsset(D1.id) });
    assert.equal((await links(car)).length, 5);
  });

  it('the database trigger is the backstop: an asset of another owner and a sixth link are refused even when the service is bypassed', async () => {
    const car = await newCar(s1);
    const foreign = await newAsset(D2.id);
    await assert.rejects(app.query(`INSERT INTO car_images (car_id, asset_id, sort_order, is_main) VALUES ($1::bigint, $2::uuid, 0, true)`, [car, foreign]), (e: unknown) => e instanceof DbError);
    assert.equal((await links(car)).length, 0);
  });

  it('delete keeps the asset (ready, owned, unattached), promotes the next image to main and renumbers', async () => {
    const car = await newCar(s1);
    const a1 = await newAsset(D1.id);
    const first = await svc.add(D1, car, { assetId: a1 });
    const a2 = await newAsset(D1.id);
    await svc.add(D1, car, { assetId: a2 });
    await svc.remove(D1, car, first.id);
    assert.deepEqual((await links(car)).map((l) => [l.asset_id, l.sort_order, l.is_main]), [[a2, 0, true]]);
    const kept = await admin.query<{ status: string; owner_id: string }>('SELECT status, owner_id FROM assets WHERE id = $1::uuid', [a1]);
    assert.deepEqual([kept.rows[0]!.status, String(kept.rows[0]!.owner_id)], ['ready', D1.id]);
  });

  it('eight concurrent adds on one car from two connections: exactly 5 succeed and there is one main image', async () => {
    const car = await newCar(s1);
    const assets = await Promise.all(Array.from({ length: 8 }, () => newAsset(D1.id)));
    const results = await Promise.allSettled(assets.map((assetId, i) => (i % 2 === 0 ? svc : svc2).add(D1, car, { assetId })));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 5);
    for (const r of results) if (r.status === 'rejected') assert.ok(imgErr('image_limit')(r.reason), String(r.reason));
    const rows = await links(car);
    assert.equal(rows.length, 5);
    assert.equal(rows.filter((r) => r.is_main).length, 1);
  });

  it('PUBLIC DISPLAY: the existing public images query lists the attached images of a showroom car of a public showroom, in order, and nothing for a hidden one', async () => {
    const delivery = createPgDeliveryRepository(app);
    const car = await newCar(s1);
    const a1 = await newAsset(D1.id);
    const a2 = await newAsset(D1.id);
    await svc.add(D1, car, { assetId: a1 });
    await svc.add(D1, car, { assetId: a2 });
    const publicImages = await delivery.listPublicCarImages(car);
    assert.deepEqual(publicImages?.map((i) => [i.assetId, i.isMain, i.sortOrder, i.width, i.height]), [[a1, true, 0, 800, 600], [a2, false, 1, 800, 600]]);
    assert.notEqual(await delivery.findPublic(a1), null, 'the image bytes route accepts an image of a public showroom car');
    // A suspended showroom is not public: its cars' images are unknown to everyone but the owner's own routes.
    await admin.query(`UPDATE showrooms SET status = 'suspended' WHERE id = $1::bigint`, [s1]);
    try {
      assert.equal(await delivery.listPublicCarImages(car), null);
      assert.equal(await delivery.findPublic(a1), null);
      assert.equal((await svc.list(D1, car)).images.length, 2, 'the owner still manages it');
    } finally {
      await admin.query(`UPDATE showrooms SET status = 'active' WHERE id = $1::bigint`, [s1]);
    }
  });
});

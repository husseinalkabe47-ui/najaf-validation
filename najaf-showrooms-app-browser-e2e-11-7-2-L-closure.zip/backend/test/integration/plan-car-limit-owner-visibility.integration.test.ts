// Phase 11.9-F correction: after a paid subscription ends, the PUBLIC sees at most the 3 eligible available cars of a showroom, while
// the authenticated OWNER still sees and manages ALL of their own cars (the private dealer routes read the cars table scoped to the
// owner's showroom, never public_cars), including the hidden ones and their images. Nobody else sees a hidden car. Real PostgreSQL 16
// through the least-privilege application role; needs DATABASE_URL and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY).
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, randomInt, randomUUID } from 'node:crypto';
import { AuthzError } from '../../src/authz/index.ts';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgDeliveryRepository } from '../../src/assets/delivery-repository.ts';
import { createPgCatalogRepository } from '../../src/catalog/repository.ts';
import { CatalogError, createCatalogService } from '../../src/catalog/service.ts';
import { createPgShowroomImageStore } from '../../src/showroom-car-images/repository.ts';
import { createShowroomCarImageService } from '../../src/showroom-car-images/service.ts';
import { createPgShowroomCarStore } from '../../src/showroom-cars/repository.ts';
import { createShowroomCarService } from '../../src/showroom-cars/service.ts';
import type { ShowroomCarView } from '../../src/showroom-cars/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const VALID = { brand: 'Toyota', model: 'Camry', year: 2022, price: 30000000, currency: 'IQD', color: 'أبيض' };
const notFound = (e: unknown) => (e instanceof AuthzError && e.code === 'not_found') || (e instanceof CatalogError) || (e as { code?: string })?.code === 'not_found';

describe('owner sees every own car, the public only the eligible 3 (PostgreSQL 16, application role)', { skip }, () => {
  let app: Db;
  let admin: Db;
  let cars: ReturnType<typeof createShowroomCarService>;
  let images: ReturnType<typeof createShowroomCarImageService>;
  let catalog: ReturnType<typeof createCatalogService>;
  const userIds: string[] = [];
  const showroomIds: string[] = [];
  let D: Actor;
  let OTHER: Actor;
  let A: Actor;
  let showroomId: string;
  let sub: string;
  let c: ShowroomCarView[] = [];
  let hiddenAsset: string;

  const newUser = async (role: 'dealer' | 'admin'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    userIds.push(String(r.rows[0]!.id));
    return String(r.rows[0]!.id);
  };
  const newShowroom = async (ownerId: string): Promise<string> => {
    const s = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض المالك', 'active') RETURNING id`, [ownerId])).rows[0]!.id);
    showroomIds.push(s);
    return s;
  };
  const readyAsset = async (ownerId: string): Promise<string> => {
    const id = randomUUID();
    const hex = randomBytes(32).toString('hex');
    await admin.query(`INSERT INTO assets (id, owner_id, kind, status, storage_key, thumb_key, mime, bytes, width, height, sha256, ready_at)
                       VALUES ($1::uuid, $2::bigint, 'car_image', 'ready', $3, $4, 'image/webp', 1000, 800, 600, $5, now())`, [id, ownerId, `it/${hex}.webp`, `it/${hex}-t.webp`, hex]);
    return id;
  };
  const publicIds = async (): Promise<string[]> =>
    (await app.query<{ id: string }>(`SELECT id FROM public_cars WHERE showroom_id = $1::bigint ORDER BY created_at, id`, [showroomId])).rows.map((r) => String(r.id));

  before(async () => {
    app = await createDb(appConfig());
    admin = await createDb(adminConfig());
    cars = createShowroomCarService({ store: createPgShowroomCarStore(app) });
    images = createShowroomCarImageService({ store: createPgShowroomImageStore(app) });
    catalog = createCatalogService({ repo: createPgCatalogRepository(app) });
    D = { id: await newUser('dealer'), role: 'dealer' };
    OTHER = { id: await newUser('dealer'), role: 'dealer' };
    A = { id: await newUser('admin'), role: 'admin' };
    showroomId = await newShowroom(D.id);
    await newShowroom(OTHER.id);
    sub = String((await admin.query<{ id: string }>(`INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end)
      VALUES ($1::bigint, (SELECT id FROM subscription_plans WHERE code = 'plan_3m'), 'active', now() - interval '30 days', now() + interval '60 days') RETURNING id`, [showroomId])).rows[0]!.id);
    c = [];
    for (let i = 0; i < 6; i++) c.push(await cars.create(D, VALID));
    await cars.update(D, c[1]!.id, { version: 1, status: 'sold' });
    hiddenAsset = await readyAsset(D.id);
    await images.add(D, c[5]!.id, { assetId: hiddenAsset }); // an image of a car that will be hidden
    await admin.query(`UPDATE subscriptions SET current_period_end = now() - interval '1 second' WHERE id = $1::bigint`, [sub]); // the paid period ended
  });
  after(async () => {
    if (admin) {
      if (showroomIds.length > 0) {
        await admin.query(`DELETE FROM car_images WHERE car_id IN (SELECT id FROM cars WHERE showroom_id = ANY($1::bigint[]))`, [showroomIds]);
        await admin.query(`DELETE FROM subscriptions WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM cars WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM showrooms WHERE id = ANY($1::bigint[])`, [showroomIds]);
      }
      if (userIds.length > 0) {
        await admin.query(`DELETE FROM assets WHERE owner_id = ANY($1::bigint[])`, [userIds]);
        await admin.query(`DELETE FROM users WHERE id = ANY($1::bigint[])`, [userIds]);
      }
    }
    await app?.close();
    await admin?.close();
  });

  it('public: at most 3 eligible available cars (the oldest), plus the sold one; the 2 newest available are hidden', async () => {
    assert.deepEqual(await publicIds(), [c[0]!.id, c[1]!.id, c[2]!.id, c[3]!.id]); // c1 is sold (always public), c0/c2/c3 the eligible 3
    const page = await catalog.listCars({ showroomId, limit: '50' });
    assert.deepEqual(page.items.map((x) => x.id).sort(), [c[0]!.id, c[1]!.id, c[2]!.id, c[3]!.id].sort());
    assert.equal(page.items.filter((x) => x.status === 'available').length, 3);
    for (const hidden of [c[4]!.id, c[5]!.id]) await assert.rejects(() => catalog.getCar(hidden), notFound);
  });

  it('owner: the private dealer list and detail return ALL own cars, hidden ones included, with their real status', async () => {
    const page = await cars.listOwn(D, { limit: '50' });
    assert.deepEqual(page.items.map((x) => x.id).sort(), c.map((x) => x.id).sort());
    assert.deepEqual(page.items.find((x) => x.id === c[5]!.id)!.status, 'available');
    for (const car of c) assert.equal((await cars.getOwn(D, car.id)).id, car.id);
    const onlyAvailable = await cars.listOwn(D, { limit: '50', status: 'available' });
    assert.equal(onlyAvailable.items.length, 5);
  });

  it('owner: manages a hidden car (edit, image list and add, mark sold) and still reaches its own image bytes', async () => {
    const edited = await cars.update(D, c[4]!.id, { version: 1, price: 29000000 });
    assert.equal(edited.price, 29000000);
    const listed = await images.list(D, c[5]!.id);
    assert.deepEqual(listed.images.map((i) => i.assetId), [hiddenAsset]);
    const more = await readyAsset(D.id);
    await images.add(D, c[5]!.id, { assetId: more });
    const delivery = createPgDeliveryRepository(app);
    assert.notEqual(await delivery.findOwnReady(hiddenAsset, D.id), null, 'the owner reaches their own image');
    assert.equal(await delivery.findPublic(hiddenAsset), null, 'the public does not');
    assert.equal(await delivery.listPublicCarImages(c[5]!.id), null);
    const sold = await cars.update(D, c[4]!.id, { version: edited.version, status: 'sold' });
    assert.equal(sold.status, 'sold');
    assert.ok((await publicIds()).includes(c[4]!.id), 'a sold car is public again, as before 11.9-F');
  });

  it('nobody else sees a hidden car: another dealer gets 404 everywhere, an administrator only through moderation', async () => {
    for (const fn of [() => cars.getOwn(OTHER, c[5]!.id), () => images.list(OTHER, c[5]!.id), () => cars.update(OTHER, c[5]!.id, { version: 1, price: 1 })]) await assert.rejects(fn, notFound);
    assert.ok(!(await cars.listOwn(OTHER, { limit: '50' })).items.some((x) => x.id === c[5]!.id));
    assert.equal(await createPgDeliveryRepository(app).findOwnReady(hiddenAsset, OTHER.id), null);
    const fav = await app.query(`INSERT INTO favorites (user_id, car_id) SELECT $1::bigint, pc.id FROM public_cars pc WHERE pc.id = $2::bigint RETURNING car_id`, [OTHER.id, c[5]!.id]);
    assert.equal(fav.rows.length, 0);
    // moderation keeps working on any non-deleted showroom car, hidden or not (unchanged rule)
    const v = (await cars.getOwn(D, c[5]!.id)).version;
    const mod = await cars.setStatusAsAdmin(A, c[5]!.id, { version: v, status: 'sold' });
    assert.equal(mod.status, 'sold');
  });

  it('renewal restores public visibility automatically; nothing was deleted', async () => {
    await admin.query(`UPDATE subscriptions SET status = 'expired' WHERE id = $1::bigint`, [sub]);
    await admin.query(`INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end)
      VALUES ($1::bigint, (SELECT id FROM subscription_plans WHERE code = 'plan_6m'), 'active', now(), now() + interval '180 days')`, [showroomId]);
    assert.deepEqual(await publicIds(), c.map((x) => x.id)); // every non-deleted car (available or sold) is public again
    assert.equal(Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM cars WHERE showroom_id = $1::bigint AND deleted_at IS NULL`, [showroomId])).rows[0]!.n), 6);
    assert.equal((await createPgDeliveryRepository(app).listPublicCarImages(c[5]!.id))?.length, 2);
  });
});

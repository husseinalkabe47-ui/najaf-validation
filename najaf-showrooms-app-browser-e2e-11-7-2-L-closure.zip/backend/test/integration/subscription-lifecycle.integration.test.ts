// Phase 11.9-G: end-to-end edge cases of the subscription features (11.9-D manual grants, 11.9-E expiry, 11.9-F entitlements) against a
// real PostgreSQL 16 through the least-privilege application role. Each case covers what the per-phase suites do not combine: the
// full lifecycle with payment history and audit consistency, the exact boundary inside one transaction, rollback of the lapsed-renewal
// path, isolation between showrooms, and concurrency across features. Needs DATABASE_URL and ADMIN_DATABASE_URL (superuser:
// fixtures, clock simulation and cleanup ONLY); skipped visibly without them.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import type { Actor } from '../../src/authz/index.ts';
import type { AuditEvent } from '../../src/auth/repository.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgShowroomCarStore } from '../../src/showroom-cars/repository.ts';
import { ShowroomCarError, createShowroomCarService } from '../../src/showroom-cars/service.ts';
import type { ShowroomCarView } from '../../src/showroom-cars/service.ts';
import { createPgSubscriptionsRepository } from '../../src/subscriptions/repository.ts';
import type { SubscriptionsRepository } from '../../src/subscriptions/repository.ts';
import { createSubscriptionsService, SubscriptionsError } from '../../src/subscriptions/service.ts';
import { createPgSubscriptionExpiryRepository } from '../../src/subscriptions/expiry-repository.ts';
import { runSubscriptionExpiry } from '../../src/subscriptions/expiry.ts';
import { createPgSubscriptionPlansRepository } from '../../src/subscription-plans/repository.ts';
import { createSubscriptionPlansService } from '../../src/subscription-plans/service.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const VALID = { brand: 'Hyundai', model: 'Tucson', year: 2023, price: 35000000, currency: 'IQD', color: 'رمادي' };
const isLimit = (e: unknown) => e instanceof ShowroomCarError && e.code === 'plan_limit_reached';

describe('subscription lifecycle edge cases on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  let A: Actor;
  let cars: ReturnType<typeof createShowroomCarService>;
  let cars2: ReturnType<typeof createShowroomCarService>;
  let repo: SubscriptionsRepository;
  const userIds: string[] = [];
  const showroomIds: string[] = [];
  const run = String(randomInt(100000, 999999));
  let seq = 0;
  const ref = () => `LC${run}-${++seq}`;

  const newUser = async (role: 'dealer' | 'admin'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    userIds.push(String(r.rows[0]!.id));
    return String(r.rows[0]!.id);
  };
  const newDealer = async (): Promise<{ D: Actor; showroomId: string }> => {
    const id = await newUser('dealer');
    const s = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض دورة الاشتراك', 'active') RETURNING id`, [id])).rows[0]!.id);
    showroomIds.push(s);
    return { D: { id, role: 'dealer' }, showroomId: s };
  };
  /** The manual-grant service with a clock fixed to the database's now() (so dates and visibility use the same instant). */
  const grantNow = async (showroomId: string, planCode = 'plan_3m', over: Record<string, unknown> = {}, r: SubscriptionsRepository = repo) => {
    const now = (await admin.query<{ t: Date }>(`SELECT now() AS t`)).rows[0]!.t;
    return createSubscriptionsService({ repo: r, now: () => now }).grant(A, { showroomId, planCode, method: 'cash', reference: ref(), amount: 75000, paidAt: now.toISOString().slice(0, 10), ...over });
  };
  /** Simulates the passage of time for one showroom: its live subscription ended a second ago (superuser fixture). */
  const lapse = (showroomId: string) => admin.query(`UPDATE subscriptions SET current_period_end = now() - interval '1 second', current_period_start = now() - interval '100 days'
                                                     WHERE showroom_id = $1::bigint AND status IN ('trialing', 'active', 'past_due')`, [showroomId]);
  const expireAll = async () => { for (let i = 0; i < 50; i++) if ((await runSubscriptionExpiry({ repo: createPgSubscriptionExpiryRepository(app) }, { dryRun: false, batchSize: 200 })).complete) return; };
  const publicAvailable = async (showroomId: string) => (await app.query<{ id: string }>(`SELECT id FROM public_cars WHERE showroom_id = $1::bigint AND status = 'available' ORDER BY created_at, id`, [showroomId])).rows.map((r) => String(r.id));
  const subsOf = async (showroomId: string) => (await admin.query<{ id: string; status: string; plan: string }>(`SELECT s.id, s.status, p.code AS plan FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id WHERE s.showroom_id = $1::bigint ORDER BY s.id`, [showroomId])).rows.map((r) => ({ ...r, id: String(r.id) }));
  const auditsOf = async (subIds: string[]) => (await admin.query<{ action: string; entity_id: string; actor_role: string; after_data: Record<string, number> }>(
    `SELECT action, entity_id, actor_role, after_data FROM audit_logs WHERE entity_type = 'subscription' AND entity_id = ANY($1::text[]) ORDER BY id`, [subIds])).rows;
  const paymentsOf = async (showroomId: string) => (await admin.query<{ id: string; subscription_id: string; amount: string; status: string }>(
    `SELECT p.id, p.subscription_id, p.amount, p.status FROM payments p JOIN subscriptions s ON s.id = p.subscription_id WHERE s.showroom_id = $1::bigint ORDER BY p.id`, [showroomId])).rows.map((r) => ({ ...r, id: String(r.id), subscription_id: String(r.subscription_id) }));

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    A = { id: await newUser('admin'), role: 'admin' };
    cars = createShowroomCarService({ store: createPgShowroomCarStore(app) });
    cars2 = createShowroomCarService({ store: createPgShowroomCarStore(app2) });
    repo = createPgSubscriptionsRepository(app);
  });
  after(async () => {
    if (admin) {
      await admin.query(`UPDATE subscription_plans SET price = 0 WHERE code IN ('plan_3m', 'plan_6m', 'plan_12m')`);
      if (showroomIds.length > 0) {
        await admin.query(`DELETE FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = ANY($1::bigint[]))`, [showroomIds]);
        await admin.query(`DELETE FROM subscriptions WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM cars WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM showrooms WHERE id = ANY($1::bigint[])`, [showroomIds]);
      }
      if (userIds.length > 0) await admin.query(`DELETE FROM users WHERE id = ANY($1::bigint[])`, [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('full lifecycle: activate, renew before expiry, lapse, expiry job, renew after expiry; visibility, payments and audit stay consistent', async () => {
    const { D, showroomId } = await newDealer();
    const g1 = await grantNow(showroomId, 'plan_3m');
    assert.equal(g1.outcome, 'activated');
    const created: ShowroomCarView[] = [];
    for (let i = 0; i < 5; i++) created.push(await cars.create(D, VALID));
    assert.equal((await publicAvailable(showroomId)).length, 5);

    const g2 = await grantNow(showroomId, 'plan_3m', { amount: 80000 }); // before expiry: same row, end extended
    assert.deepEqual([g2.outcome, g2.subscription.id], ['renewed', g1.subscription.id]);
    assert.ok(new Date(g2.subscription.periodEnd) > new Date(g1.subscription.periodEnd));
    assert.equal((await publicAvailable(showroomId)).length, 5);

    await lapse(showroomId); // the paid period is over (expiry job not yet run): the public sees the oldest 3 at once
    assert.deepEqual(await publicAvailable(showroomId), created.slice(0, 3).map((c) => c.id));
    await expireAll();
    await expireAll(); // repeated run: nothing more happens
    assert.deepEqual((await subsOf(showroomId)).map((s) => s.status), ['expired']);
    await assert.rejects(() => cars.create(D, VALID), isLimit);

    const g3 = await grantNow(showroomId, 'plan_6m', { amount: 120000 }); // after expiry (the job already closed the old row)
    assert.equal(g3.outcome, 'renewed_after_expiry');
    assert.notEqual(g3.subscription.id, g1.subscription.id);
    assert.equal(g3.subscription.periodStart, (await admin.query<{ t: Date }>(`SELECT current_period_start AS t FROM subscriptions WHERE id = $1::bigint`, [g3.subscription.id])).rows[0]!.t.toISOString());
    assert.equal((await publicAvailable(showroomId)).length, 5); // restored
    await cars.create(D, VALID);
    assert.equal((await publicAvailable(showroomId)).length, 6);

    // payment history: three paid IQD payments, never changed, each on the subscription it paid for
    const pays = await paymentsOf(showroomId);
    assert.deepEqual(pays.map((p) => [p.subscription_id, p.amount, p.status]), [[g1.subscription.id, '75000', 'paid'], [g1.subscription.id, '80000', 'paid'], [g3.subscription.id, '120000', 'paid']]);
    const hist = await createSubscriptionsService({ repo }).history(A, showroomId);
    assert.deepEqual(hist.subscriptions.map((s) => [s.id, s.status, s.payments.length]), [[g3.subscription.id, 'active', 1], [g1.subscription.id, 'expired', 2]]);

    // audit: one row per business event, consistent with the payments, the old/new details chained
    const audits = await auditsOf([g1.subscription.id, g3.subscription.id]);
    assert.deepEqual(audits.map((a) => [a.action, a.entity_id, a.actor_role]), [
      ['subscription.activate', g1.subscription.id, 'admin'],
      ['subscription.renew', g1.subscription.id, 'admin'],
      ['subscription.expire', g1.subscription.id, 'system'],
      ['subscription.renew', g3.subscription.id, 'admin'],
    ]);
    assert.deepEqual(audits.filter((a) => a.actor_role === 'admin').map((a) => a.after_data['paymentId']), pays.map((p) => Number(p.id)));
    const renewAfter = audits[3]!.after_data;
    assert.equal(renewAfter['oldSubscriptionId'], Number(g1.subscription.id));
    assert.equal(renewAfter['oldPeriodEnd'], audits[2]!.after_data['periodEnd']); // the period the job closed
  });

  it('renewal after expiry is recorded the same way whether or not the expiry job ran first', async () => {
    const a = await newDealer();
    const b = await newDealer();
    for (const s of [a, b]) { await grantNow(s.showroomId); await lapse(s.showroomId); }
    await expireAll(); // closes both lapsed rows
    const ga = await grantNow(a.showroomId); // job already ran
    await grantNow(b.showroomId); // b: also already closed; create a third showroom whose lapsed row the GRANT closes
    const c = await newDealer();
    await grantNow(c.showroomId);
    await lapse(c.showroomId);
    const gc = await grantNow(c.showroomId); // job not run: the grant closes the lapsed row itself
    assert.equal(ga.outcome, 'renewed_after_expiry');
    assert.equal(gc.outcome, 'renewed_after_expiry');
    for (const g of [ga, gc]) {
      const row = (await auditsOf([g.subscription.id])).at(-1)!;
      assert.equal(row.action, 'subscription.renew');
      for (const k of ['oldSubscriptionId', 'oldPlanId', 'oldPeriodEnd', 'newPeriodEnd', 'paymentId']) assert.equal(typeof row.after_data[k], 'number', k);
    }
  });

  it('the exact boundary inside one transaction: a subscription ending at now() is not in force for the limit, the public view or a renewal', async () => {
    const { D, showroomId } = await newDealer();
    await grantNow(showroomId);
    for (let i = 0; i < 4; i++) await cars.create(D, VALID);
    // first, committed: the end set to the transaction's own now() is in the past for every later statement
    await admin.query(`UPDATE subscriptions SET current_period_end = now() WHERE showroom_id = $1::bigint AND status = 'active'`, [showroomId]);
    const r = await admin.query<{ lim: number | null; vis: number; due: number; ent_free: boolean }>(`
      SELECT showroom_active_car_limit($1::bigint) AS lim,
             (SELECT count(*)::int FROM public_cars WHERE showroom_id = $1::bigint AND status = 'available') AS vis,
             (SELECT count(*)::int FROM subscriptions WHERE showroom_id = $1::bigint AND status IN ('trialing','active','past_due') AND current_period_end <= now()) AS due,
             entitlements_for_showroom($1::bigint) = (SELECT entitlements FROM subscription_plans WHERE code = 'free') AS ent_free`, [showroomId]);
    // then the boundary proper: within ONE transaction now() is constant, so "ends exactly now" is observed by every rule at once
    await admin.query('BEGIN');
    try {
      await admin.query(`UPDATE subscriptions SET current_period_end = now() WHERE showroom_id = $1::bigint AND status = 'active'`, [showroomId]);
      const b = (await admin.query<{ lim: number | null; vis: number; due: number }>(`
        SELECT showroom_active_car_limit($1::bigint) AS lim,
               (SELECT count(*)::int FROM public_cars WHERE showroom_id = $1::bigint AND status = 'available') AS vis,
               (SELECT count(*)::int FROM subscriptions WHERE showroom_id = $1::bigint AND status IN ('trialing','active','past_due') AND current_period_end <= now()) AS due`, [showroomId])).rows[0]!;
      assert.deepEqual([b.lim, b.vis, b.due], [3, 3, 1]); // limit = free, view capped, expiry job would pick it
      await admin.query(`UPDATE subscriptions SET current_period_end = now() + interval '1 microsecond' WHERE showroom_id = $1::bigint AND status = 'active'`, [showroomId]);
      const c = (await admin.query<{ lim: number | null; vis: number; due: number }>(`
        SELECT showroom_active_car_limit($1::bigint) AS lim,
               (SELECT count(*)::int FROM public_cars WHERE showroom_id = $1::bigint AND status = 'available') AS vis,
               (SELECT count(*)::int FROM subscriptions WHERE showroom_id = $1::bigint AND status IN ('trialing','active','past_due') AND current_period_end <= now()) AS due`, [showroomId])).rows[0]!;
      assert.deepEqual([c.lim, c.vis, c.due], [null, 4, 0]); // one microsecond later it is still in force everywhere
    } finally {
      await admin.query('ROLLBACK');
    }
    assert.deepEqual([r.rows[0]!.lim, r.rows[0]!.vis, r.rows[0]!.due, r.rows[0]!.ent_free], [3, 3, 1, true]);
  });

  it('rollback of the lapsed-renewal path: when the payment fails, the old row is NOT closed and no new row, payment or audit remains', async () => {
    const { showroomId } = await newDealer();
    const g1 = await grantNow(showroomId);
    await lapse(showroomId);
    const before = { subs: await subsOf(showroomId), pays: await paymentsOf(showroomId), audits: (await auditsOf([g1.subscription.id])).length };
    const failing: SubscriptionsRepository = { ...repo, transaction: (fn) => repo.transaction((t) => fn({ ...t, insertPayment: async () => { throw new Error('payment insert failed'); } })) };
    await assert.rejects(() => grantNow(showroomId, 'plan_6m', {}, failing), /payment insert failed/);
    assert.deepEqual(await subsOf(showroomId), before.subs); // still one row, still 'active' (lapsed), not 'expired'
    assert.deepEqual(await paymentsOf(showroomId), before.pays);
    assert.equal((await auditsOf([g1.subscription.id])).length, before.audits);
    const failingAudit: SubscriptionsRepository = { ...repo, transaction: (fn) => repo.transaction((t) => fn({ ...t, audit: { record: async (e: AuditEvent) => { if (e.action === 'subscription.renew') throw new Error('audit write failed'); await t.audit.record(e); } } })) };
    await assert.rejects(() => grantNow(showroomId, 'plan_6m', {}, failingAudit), /audit write failed/);
    assert.deepEqual(await subsOf(showroomId), before.subs);
    const ok = await grantNow(showroomId, 'plan_6m');
    assert.equal(ok.outcome, 'renewed_after_expiry');
    assert.deepEqual((await subsOf(showroomId)).map((s) => s.status), ['expired', 'active']);
  });

  it('isolation between showrooms: one showroom\'s plan, expiry, renewal, limit and history never affect another\'s', async () => {
    const paidS = await newDealer();
    const freeS = await newDealer();
    await grantNow(paidS.showroomId);
    for (let i = 0; i < 5; i++) await cars.create(paidS.D, VALID);
    for (let i = 0; i < 3; i++) await cars.create(freeS.D, VALID);
    await assert.rejects(() => cars.create(freeS.D, VALID), isLimit); // the other showroom's subscription grants nothing here
    assert.deepEqual([(await publicAvailable(paidS.showroomId)).length, (await publicAvailable(freeS.showroomId)).length], [5, 3]);
    // the free showroom's cars are not counted against the paid one and vice versa, even when published concurrently
    const both = await Promise.allSettled([...Array.from({ length: 3 }, () => cars.create(paidS.D, VALID)), ...Array.from({ length: 3 }, () => cars2.create(freeS.D, VALID))]);
    assert.deepEqual(both.map((r) => r.status), ['fulfilled', 'fulfilled', 'fulfilled', 'rejected', 'rejected', 'rejected']);
    // lapsing the paid showroom changes only its own visibility; renewing it restores only its own cars
    await lapse(paidS.showroomId);
    assert.deepEqual([(await publicAvailable(paidS.showroomId)).length, (await publicAvailable(freeS.showroomId)).length], [3, 3]);
    await grantNow(paidS.showroomId);
    assert.deepEqual([(await publicAvailable(paidS.showroomId)).length, (await publicAvailable(freeS.showroomId)).length], [8, 3]);
    // histories are per showroom; a duplicate reference is refused across showrooms (one payment, one place)
    const svc = createSubscriptionsService({ repo });
    assert.equal((await svc.history(A, freeS.showroomId)).subscriptions.length, 0);
    assert.equal((await svc.history(A, paidS.showroomId)).subscriptions.length, 2);
    const dupRef = ref();
    await grantNow(paidS.showroomId, 'plan_3m', { reference: dupRef });
    await assert.rejects(() => grantNow(freeS.showroomId, 'plan_3m', { reference: dupRef }), (e: unknown) => e instanceof SubscriptionsError && e.code === 'duplicate_payment');
    assert.equal((await svc.history(A, freeS.showroomId)).subscriptions.length, 0);
    // the other owner cannot see or manage the paid showroom's cars
    const someCar = (await cars.listOwn(paidS.D, { limit: '1' })).items[0]!;
    await assert.rejects(() => cars.getOwn(freeS.D, someCar.id), (e: unknown) => (e as { code?: string }).code === 'not_found');
  });

  it('concurrency across features: publishing at the limit, an expiry run and a renewal at once never leave more than the plan allows', async () => {
    const { D, showroomId } = await newDealer();
    await grantNow(showroomId);
    for (let i = 0; i < 2; i++) await cars.create(D, VALID);
    await lapse(showroomId); // free again: 2 available, 1 place left
    const ops = await Promise.allSettled([
      cars.create(D, VALID), cars2.create(D, VALID), cars.create(D, VALID), cars2.create(D, VALID),
      expireAll(), expireAll(),
    ]);
    const created = ops.slice(0, 4).filter((r) => r.status === 'fulfilled').length;
    for (const r of ops.slice(0, 4)) if (r.status === 'rejected') assert.ok(isLimit(r.reason), String(r.reason));
    assert.equal(created, 1);
    assert.equal(ops[4]!.status, 'fulfilled'); assert.equal(ops[5]!.status, 'fulfilled');
    const subs = await subsOf(showroomId);
    assert.deepEqual(subs.map((s) => s.status), ['expired']);
    assert.equal((await auditsOf(subs.map((s) => s.id))).filter((a) => a.action === 'subscription.expire').length, 1); // two runs, one transition
    // renewal and publishing at once: the renewal commits, publications serialize on the showroom row and stay consistent
    const mixed = await Promise.allSettled([grantNow(showroomId, 'plan_12m'), cars.create(D, VALID), cars2.create(D, VALID)]);
    assert.equal(mixed[0]!.status, 'fulfilled');
    for (const r of mixed.slice(1)) if (r.status === 'rejected') assert.ok(isLimit(r.reason));
    const avail = Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM cars WHERE showroom_id = $1::bigint AND status = 'available' AND deleted_at IS NULL`, [showroomId])).rows[0]!.n);
    assert.equal(avail, 3 + mixed.slice(1).filter((r) => r.status === 'fulfilled').length);
    assert.equal((await publicAvailable(showroomId)).length, avail); // paid again: everything available is public
  });

  it('a later plan price change never rewrites recorded payments or audit rows', async () => {
    const { showroomId } = await newDealer();
    const plans = createSubscriptionPlansService({ repo: createPgSubscriptionPlansRepository(app) });
    await plans.setPrice(A, 'plan_3m', { price: 50000 });
    const g = await grantNow(showroomId, 'plan_3m', { amount: 50000 });
    const auditBefore = await auditsOf([g.subscription.id]);
    await plans.setPrice(A, 'plan_3m', { price: 90000 });
    assert.deepEqual((await paymentsOf(showroomId)).map((p) => p.amount), ['50000']);
    assert.deepEqual(await auditsOf([g.subscription.id]), auditBefore);
    assert.equal(auditBefore[0]!.after_data['planPrice'], 50000); // the price in force when it was recorded
    await plans.setPrice(A, 'plan_3m', { price: 0 });
  });
});

// Phase 11.9-F against a real PostgreSQL 16 (migrations 0001-0015), through the least-privilege application role: the free plan's
// limit of 3 available showroom cars, unlimited cars under a paid subscription in force, the public_cars cap after a subscription ends
// (oldest 3 stay visible, nothing deleted or changed), restoration when a paid subscription is in force again, direct bypass attempts,
// and concurrency over two connection pools. Needs DATABASE_URL and ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY).
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomInt } from 'node:crypto';
import type { Actor } from '../../src/authz/index.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { createPgShowroomCarStore } from '../../src/showroom-cars/repository.ts';
import { ShowroomCarError, createShowroomCarService } from '../../src/showroom-cars/service.ts';
import type { ShowroomCarView } from '../../src/showroom-cars/service.ts';
import { createPgSubscriptionsRepository } from '../../src/subscriptions/repository.ts';
import { createSubscriptionsService } from '../../src/subscriptions/service.ts';
import { createPgSubscriptionExpiryRepository } from '../../src/subscriptions/expiry-repository.ts';
import { runSubscriptionExpiry } from '../../src/subscriptions/expiry.ts';
import { adminConfig, appConfig, skip } from '../helpers/integration.ts';

const HASH = '$argon2id$v=19$m=19456,t=2,p=1$dGVzdA$dGVzdA';
const VALID = { brand: 'Toyota', model: 'Camry', year: 2022, price: 30000000, currency: 'IQD', color: 'أبيض' };
const isLimit = (e: unknown) => e instanceof ShowroomCarError && e.code === 'plan_limit_reached';

describe('free-plan car limit and paid entitlements on PostgreSQL 16 (application role)', { skip }, () => {
  let app: Db;
  let app2: Db;
  let admin: Db;
  let svc: ReturnType<typeof createShowroomCarService>;
  let svc2: ReturnType<typeof createShowroomCarService>;
  let A: Actor;
  const userIds: string[] = [];
  const showroomIds: string[] = [];

  const newUser = async (role: 'dealer' | 'admin'): Promise<string> => {
    const phone = '+9647' + String(randomInt(0, 1_000_000_000)).padStart(9, '0');
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ('حساب اختبار', $1, $2, 'active', $3) RETURNING id`, [phone, role, HASH]);
    userIds.push(String(r.rows[0]!.id));
    return String(r.rows[0]!.id);
  };
  /** A dealer with an active (public) showroom. */
  const newDealer = async (): Promise<{ D: Actor; showroomId: string }> => {
    const id = await newUser('dealer');
    const s = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, 'معرض الحد', 'active') RETURNING id`, [id])).rows[0]!.id);
    showroomIds.push(s);
    return { D: { id, role: 'dealer' }, showroomId: s };
  };
  /** A paid subscription in force (as an administrator's manual grant would leave it). */
  const paid = async (showroomId: string, endSql = `now() + interval '90 days'`): Promise<string> =>
    String((await admin.query<{ id: string }>(`INSERT INTO subscriptions (showroom_id, plan_id, status, current_period_start, current_period_end)
      VALUES ($1::bigint, (SELECT id FROM subscription_plans WHERE code = 'plan_3m'), 'active', now() - interval '30 days', ${endSql}) RETURNING id`, [showroomId])).rows[0]!.id);
  const endNow = (subId: string) => admin.query(`UPDATE subscriptions SET current_period_end = now() - interval '1 second' WHERE id = $1::bigint`, [subId]);
  const visible = async (showroomId: string): Promise<string[]> =>
    (await app.query<{ id: string }>(`SELECT id FROM public_cars WHERE showroom_id = $1::bigint AND status = 'available' ORDER BY created_at, id`, [showroomId])).rows.map((r) => String(r.id));
  const rows = async (showroomId: string) =>
    (await admin.query<{ id: string; status: string; deleted_at: Date | null; version: number }>(`SELECT id, status, deleted_at, version FROM cars WHERE showroom_id = $1::bigint ORDER BY created_at, id`, [showroomId])).rows.map((r) => ({ ...r, id: String(r.id) }));

  before(async () => {
    app = await createDb(appConfig());
    app2 = await createDb(appConfig());
    admin = await createDb(adminConfig());
    svc = createShowroomCarService({ store: createPgShowroomCarStore(app) });
    svc2 = createShowroomCarService({ store: createPgShowroomCarStore(app2) });
    A = { id: await newUser('admin'), role: 'admin' };
  });
  after(async () => {
    if (admin) {
      if (showroomIds.length > 0) {
        await admin.query(`DELETE FROM payments WHERE subscription_id IN (SELECT id FROM subscriptions WHERE showroom_id = ANY($1::bigint[]))`, [showroomIds]);
        await admin.query(`DELETE FROM subscriptions WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM cars WHERE showroom_id = ANY($1::bigint[])`, [showroomIds]);
        await admin.query(`DELETE FROM showrooms WHERE id = ANY($1::bigint[])`, [showroomIds]);
      }
      if (userIds.length > 0) await admin.query(`DELETE FROM users WHERE id = ANY($1::bigint[])`, [userIds]);
    }
    await app?.close();
    await app2?.close();
    await admin?.close();
  });

  it('the database function: 3 for a showroom without a subscription in force, NULL (unlimited) with one; the report role cannot call it', async () => {
    const free = await newDealer();
    const pay = await newDealer();
    await paid(pay.showroomId);
    const lim = async (id: string) => (await app.query<{ l: number | null }>(`SELECT showroom_active_car_limit($1::bigint) AS l`, [id])).rows[0]!.l;
    assert.equal(await lim(free.showroomId), 3);
    assert.equal(await lim(pay.showroomId), null);
    await assert.rejects(admin.query(`SET ROLE najaf_report; SELECT showroom_active_car_limit(1)`).finally(() => admin.query('RESET ROLE')));
    await admin.query('RESET ROLE');
  });

  it('free plan: 3 cars are published, the 4th is refused (409) and nothing is written', async () => {
    const { D, showroomId } = await newDealer();
    for (let i = 0; i < 3; i++) await svc.create(D, VALID);
    const audits = async () => Number((await admin.query<{ n: string }>(`SELECT count(*) AS n FROM audit_logs WHERE actor_id = $1::bigint AND action = 'showroom_car.create'`, [D.id])).rows[0]!.n);
    const n = await audits();
    await assert.rejects(() => svc.create(D, VALID), isLimit);
    assert.equal((await rows(showroomId)).length, 3);
    assert.equal(await audits(), n);
    assert.equal((await visible(showroomId)).length, 3);
  });

  it('paid plan in force: unlimited, every available car is public', async () => {
    const { D, showroomId } = await newDealer();
    await paid(showroomId);
    for (let i = 0; i < 7; i++) await svc.create(D, VALID);
    assert.equal((await visible(showroomId)).length, 7);
  });

  it('expiry downgrade: the oldest 3 stay public, the excess is hidden only (status, version, deletion untouched); sold cars stay public', async () => {
    const { D, showroomId } = await newDealer();
    const sub = await paid(showroomId);
    const created: ShowroomCarView[] = [];
    for (let i = 0; i < 6; i++) created.push(await svc.create(D, VALID));
    await svc.update(D, created[1]!.id, { version: 1, status: 'sold' });
    const before = await rows(showroomId);
    await endNow(sub);
    const vis = await visible(showroomId);
    assert.deepEqual(vis, [created[0]!.id, created[2]!.id, created[3]!.id]); // deterministic: oldest available first
    assert.deepEqual(await rows(showroomId), before); // nothing deleted or changed
    assert.equal((await app.query(`SELECT 1 FROM public_cars WHERE id = $1::bigint`, [created[1]!.id])).rows.length, 1, 'a sold car stays public');
    for (const hidden of [created[4]!.id, created[5]!.id]) assert.equal((await app.query(`SELECT 1 FROM public_cars WHERE id = $1::bigint`, [hidden])).rows.length, 0);
    // the operator's expiry job (11.9-E) only records the status; visibility is already right and does not change
    for (let i = 0; i < 20; i++) if ((await runSubscriptionExpiry({ repo: createPgSubscriptionExpiryRepository(app) }, { dryRun: false })).complete) break;
    assert.equal((await admin.query<{ s: string }>(`SELECT status AS s FROM subscriptions WHERE id = $1::bigint`, [sub])).rows[0]!.s, 'expired');
    assert.deepEqual(await visible(showroomId), vis);
    // after the downgrade the free limit applies to new publications, but the owner still edits a hidden car
    await assert.rejects(() => svc.create(D, VALID), isLimit);
    await assert.rejects(() => svc.update(D, created[1]!.id, { version: 2, status: 'available' }), isLimit);
    const edited = await svc.update(D, created[5]!.id, { version: 1, price: 29000000 });
    assert.equal(edited.status, 'available');
  });

  it('renewal restores visibility from the entitlements, without overriding owner or moderation decisions', async () => {
    const { D, showroomId } = await newDealer();
    const sub = await paid(showroomId);
    const c: ShowroomCarView[] = [];
    for (let i = 0; i < 6; i++) c.push(await svc.create(D, VALID));
    await svc.update(D, c[2]!.id, { version: 1, status: 'sold' }); // owner decision
    await svc.setStatusAsAdmin(A, c[3]!.id, { version: 1, status: 'sold' }); // moderation decision
    await svc.remove(D, c[4]!.id, { version: '1' }); // owner deletion
    await endNow(sub);
    assert.deepEqual(await visible(showroomId), [c[0]!.id, c[1]!.id, c[5]!.id]);
    // an administrator records a renewal after expiry (11.9-D): a new subscription in force
    const grant = await createSubscriptionsService({ repo: createPgSubscriptionsRepository(app) }).grant(A, { showroomId, planCode: 'plan_6m', method: 'cash', reference: `PL${randomInt(100000, 999999)}`, amount: 1000, paidAt: new Date().toISOString().slice(0, 10) });
    assert.equal(grant.outcome, 'renewed_after_expiry');
    assert.deepEqual(await visible(showroomId), [c[0]!.id, c[1]!.id, c[5]!.id]); // every available car is public again (here 3 remain available)
    const st = await rows(showroomId);
    assert.deepEqual(st.map((r) => [r.id, r.status, r.deleted_at === null]), [[c[0]!.id, 'available', true], [c[1]!.id, 'available', true], [c[2]!.id, 'sold', true], [c[3]!.id, 'sold', true], [c[4]!.id, 'available', false], [c[5]!.id, 'available', true]]);
    // with the paid plan in force again, more cars can be published and are public
    for (let i = 0; i < 3; i++) await svc.create(D, VALID);
    assert.equal((await visible(showroomId)).length, 6);
  });

  it('a paid showroom that lapses with 8 cars and renews shows all 8 again', async () => {
    const { D, showroomId } = await newDealer();
    const sub = await paid(showroomId);
    for (let i = 0; i < 8; i++) await svc.create(D, VALID);
    await endNow(sub);
    assert.equal((await visible(showroomId)).length, 3);
    await admin.query(`UPDATE subscriptions SET status = 'expired' WHERE id = $1::bigint`, [sub]); // closed (history kept)
    await paid(showroomId); // a new one in force (as a manual grant)
    assert.equal((await visible(showroomId)).length, 8);
  });

  it('direct bypass attempts: the admin route, a raw insert by the app role and the catalog/favorite reads all respect the cap', async () => {
    const { D, showroomId } = await newDealer();
    const first = await svc.create(D, VALID);
    await svc.update(D, first.id, { version: 1, status: 'sold' });
    for (let i = 0; i < 3; i++) await svc.create(D, VALID);
    await assert.rejects(() => svc.setStatusAsAdmin(A, first.id, { version: 2, status: 'available' }), isLimit);
    // rows written around the service (here: the app role's own INSERTs) are stored but never shown beyond the cap
    for (let i = 0; i < 3; i++) await app.query(`INSERT INTO cars (source_type, showroom_id, brand, model, year, price, currency, status, search_text) VALUES ('showroom', $1::bigint, 'Kia', 'Rio', 2020, 9000000, 'IQD', 'available', 'kia rio')`, [showroomId]);
    assert.equal((await rows(showroomId)).filter((r) => r.status === 'available').length, 6);
    const vis = await visible(showroomId);
    assert.equal(vis.length, 3);
    const hidden = (await rows(showroomId)).filter((r) => r.status === 'available' && !vis.includes(r.id)).map((r) => r.id);
    for (const id of hidden) {
      assert.equal((await app.query(`SELECT 1 FROM public_cars WHERE id = $1::bigint`, [id])).rows.length, 0);
      // a favorite is created only from a public_cars row (favorites/repository.ts): nothing is inserted for a hidden car
      assert.equal((await app.query(`INSERT INTO favorites (user_id, car_id) SELECT $1::bigint, pc.id FROM public_cars pc WHERE pc.id = $2::bigint RETURNING car_id`, [A.id, id])).rows.length, 0);
    }
  });

  it('concurrent creates over two connection pools cannot exceed the free limit', async () => {
    const { D, showroomId } = await newDealer();
    const results = await Promise.allSettled(Array.from({ length: 8 }, (_, i) => (i % 2 ? svc2 : svc).create(D, VALID)));
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 3);
    assert.ok(results.filter((r) => r.status === 'rejected').every((r) => isLimit((r as PromiseRejectedResult).reason)));
    assert.equal((await rows(showroomId)).length, 3);
  });

  it('concurrent sold -> available on two connections at the limit minus one: exactly one wins', async () => {
    const { D, showroomId } = await newDealer();
    const a = await svc.create(D, VALID);
    const b = await svc.create(D, VALID);
    await svc.create(D, VALID);
    await svc.update(D, a.id, { version: 1, status: 'sold' });
    await svc.create(D, VALID);
    await svc.update(D, b.id, { version: 1, status: 'sold' }); // 2 available, 2 sold: one place left
    const results = await Promise.allSettled([svc.update(D, a.id, { version: 2, status: 'available' }), svc2.update(D, b.id, { version: 2, status: 'available' })]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal((await rows(showroomId)).filter((r) => r.status === 'available').length, 3);
  });

  it('publishing while the subscription ends: whatever the order, at most 3 available cars stay public and no error but the limit occurs', async () => {
    const { D, showroomId } = await newDealer();
    const sub = await paid(showroomId);
    for (let i = 0; i < 2; i++) await svc.create(D, VALID);
    const results = await Promise.allSettled([endNow(sub), ...Array.from({ length: 4 }, (_, i) => (i % 2 ? svc2 : svc).create(D, VALID))]);
    for (const r of results.slice(1)) if (r.status === 'rejected') assert.ok(isLimit(r.reason), String(r.reason));
    assert.ok((await visible(showroomId)).length <= 3);
    assert.equal((await rows(showroomId)).filter((r) => r.status === 'available').length, 2 + results.slice(1).filter((r) => r.status === 'fulfilled').length);
  });

  it('member ads are not affected by the showroom limit', async () => {
    const m = await newUser('dealer'); // any owner account; member ads are keyed by owner_id
    for (let i = 0; i < 5; i++) await admin.query(`INSERT INTO cars (source_type, owner_id, brand, model, year, price, currency, phone, location, status, search_text) VALUES ('member', $1::bigint, 'Kia', 'Rio', 2018, 9000, 'USD', '+9647701234567', 'النجف', 'active', 'kia rio')`, [m]);
    assert.equal((await app.query<{ n: number }>(`SELECT count(*)::int AS n FROM public_cars WHERE source_type = 'member' AND id IN (SELECT id FROM cars WHERE owner_id = $1::bigint)`, [m])).rows[0]!.n, 5);
    await admin.query(`DELETE FROM cars WHERE owner_id = $1::bigint`, [m]);
  });
});

// Phase 11.7.2-L, Step 2: a REAL browser (Chromium, Playwright) against the REAL application server (src/index.ts, started as a child
// process exactly like `npm start`) on the CI PostgreSQL 16 (migrations + staging seed + the least-privilege login role). No mock API.
//
// Deployment shape under test: the backend has no CORS, so the frontend must share the API's origin (api/README.md). This test plays
// the reverse proxy: one origin (FRONT) serves the frontend files and forwards /v1/* and /healthz to the backend untouched, and the
// page is configured through <meta name="najaf-api-base-url"> = FRONT (injected into index.html as it is served; no file is changed).
// Cookie transport is on (AUTH_COOKIE_ORIGINS = FRONT, AUTH_COOKIE_SECURE=false: allowed only for loopback http outside production).
//
// Covered: public browsing; a dealer's session (HttpOnly cookie, restore after reload, logout) and car creation through the UI; an
// administrator's dashboard and lists; the dealer kept out of the admin area; CORS (another origin cannot read or call the API, and the
// cookie routes refuse foreign or missing origins); Arabic RTL. Fixtures (one dealer with an active showroom, one administrator) are
// created with the superuser handle, with real argon2id hashes of throwaway passwords, and removed afterwards.
//
// Needs DATABASE_URL (app login role), ADMIN_DATABASE_URL (superuser: fixtures and cleanup ONLY) and the `playwright` package (1.56.0,
// installed in CI with --no-save, not a project dependency) with its Chromium (`npx playwright install --with-deps chromium`). Skipped
// visibly when any of them is missing, except with E2E_REQUIRED=1 (CI), where that is a failure.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { randomBytes, randomInt } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createServer, request as httpRequest } from 'node:http';
import type { IncomingMessage, Server, ServerResponse } from 'node:http';
import { createServer as createNetServer } from 'node:net';
import type { AddressInfo } from 'node:net';
import { extname, join, normalize, sep } from 'node:path';
import { createArgon2idHasher } from '../../src/auth/password.ts';
import { createDb } from '../../src/db.ts';
import type { Db } from '../../src/db.ts';
import { ADMIN_URL, APP_URL, adminConfig } from '../helpers/integration.ts';

// The few Playwright calls this test makes, typed locally: the package is installed in CI only (pinned, `npm install --no-save
// playwright@1.56.0`), so neither `npm run typecheck` nor any other test depends on it.
interface PwRequest { method(): string; headers(): Record<string, string>; postDataJSON(): unknown }
interface PwResponse { url(): string; status(): number; json(): Promise<unknown>; text(): Promise<string>; headerValue(name: string): Promise<string | null>; request(): PwRequest }
interface PwLocator { first(): PwLocator; waitFor(): Promise<void>; count(): Promise<number>; click(): Promise<void> }
interface PwPage {
  on(event: 'pageerror', f: (e: Error) => void): void;
  on(event: 'request', f: (r: { url(): string }) => void): void;
  on(event: 'response', f: (r: PwResponse) => void): void;
  goto(url: string, o?: { waitUntil?: 'load' | 'domcontentloaded' }): Promise<unknown>;
  waitForFunction(f: string | (() => unknown)): Promise<unknown>;
  evaluate<R, A = undefined>(f: string | ((a: A) => R | Promise<R>), arg?: A): Promise<R>;
  waitForResponse(p: (r: PwResponse) => boolean): Promise<PwResponse>;
  fill(selector: string, value: string): Promise<void>;
  click(selector: string): Promise<void>;
  selectOption(selector: string, value: string): Promise<unknown>;
  locator(selector: string, o?: { hasText?: string }): PwLocator;
  reload(o?: { waitUntil?: 'load' }): Promise<unknown>;
  waitForTimeout(ms: number): Promise<void>;
}
interface PwContext { newPage(): Promise<PwPage>; cookies(): Promise<Array<{ name: string; httpOnly: boolean; sameSite: string; path: string }>>; close(): Promise<void> }
interface PwBrowser { newContext(o?: { viewport?: { width: number; height: number }; locale?: string }): Promise<PwContext>; close(): Promise<void> }
interface PwModule { chromium: { launch(): Promise<PwBrowser> } }

const PW_MODULE = 'playwright';
let pw: PwModule | null = null;
let pwProblem = '';
try {
  pw = (await import(PW_MODULE)) as PwModule;
} catch (e) {
  pwProblem = `playwright is not installed (${(e as { code?: string }).code ?? 'error'}); in backend/ run "npm install --no-save playwright@1.56.0" and "npx playwright install chromium"`;
}
const missing = !APP_URL || !ADMIN_URL ? 'browser e2e needs DATABASE_URL (app login role) and ADMIN_DATABASE_URL (superuser)' : pw ? '' : pwProblem;
// In CI (E2E_REQUIRED=1) a missing prerequisite is a FAILURE, never a silent skip.
const required = process.env['E2E_REQUIRED'] === '1';
const skip: string | false = missing && !required ? missing : false;
if (missing && required) {
  describe('browser e2e prerequisites (E2E_REQUIRED=1)', () => {
    it('has a database and Playwright with Chromium', () => assert.fail(missing));
  });
}

const BACKEND_DIR = join(import.meta.dirname, '..', '..');
const ROOT = join(BACKEND_DIR, '..'); // the frontend lives at the repository root (index.html)
const TYPES: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp', '.ico': 'image/x-icon' };

const freePort = (): Promise<number> => new Promise((resolve, reject) => {
  const s = createNetServer();
  s.once('error', reject);
  s.listen(0, '127.0.0.1', () => { const p = (s.address() as AddressInfo).port; s.close(() => resolve(p)); });
});
const listen = (srv: Server, port: number, host: string) => new Promise<void>((resolve, reject) => { srv.once('error', reject); srv.listen(port, host, () => resolve()); });
const closeServer = (srv: Server | undefined) => new Promise<void>((resolve) => (srv ? srv.close(() => resolve()) : resolve()));

describe('real server + real browser (Chromium): public browsing, dealer, administrator, session cookie, CORS, RTL', { skip: missing ? (skip || 'prerequisites missing') : false }, () => {
  let admin: Db;
  let backend: ChildProcess | undefined;
  let backendLog = '';
  let front: Server | undefined;
  let evil: Server | undefined;
  let browser: PwBrowser;
  let API = '';
  let FRONT = '';
  let EVIL = '';
  const run = String(randomInt(100000, 999999));
  const userIds: string[] = [];
  let showroomId = '';
  const dealer = { phoneLocal: '', password: `E2e-dealer-${randomBytes(6).toString('hex')}`, name: `تاجر تجربة ${run}`, id: '' };
  const adminUser = { phoneLocal: '', password: `E2e-admin-${randomBytes(6).toString('hex')}`, name: `مدير تجربة ${run}`, id: '' };

  const newUser = async (u: typeof dealer, role: 'dealer' | 'admin', hash: string) => {
    const digits = `70${String(randomInt(0, 10_000_000)).padStart(7, '0')}`; // 0770XXXXXXX, a valid Iraqi mobile number
    u.phoneLocal = `07${digits}`;
    const r = await admin.query<{ id: string }>(`INSERT INTO users (name, phone_e164, role, status, password_hash) VALUES ($1, $2, $3, 'active', $4) RETURNING id`, [u.name, `+9647${digits}`, role, hash]);
    u.id = String(r.rows[0]!.id);
    userIds.push(u.id);
  };

  /** FRONT: the frontend files (index.html gets the API base URL meta) and a pass-through proxy for the API paths. */
  const frontHandler = (req: IncomingMessage, res: ServerResponse) => {
    const url = new URL(req.url ?? '/', FRONT);
    if (url.pathname.startsWith('/v1/') || url.pathname === '/healthz' || url.pathname === '/readyz') {
      const up = httpRequest(`${API}${url.pathname}${url.search}`, { method: req.method, headers: req.headers }, (r: IncomingMessage) => { res.writeHead(r.statusCode ?? 502, r.headers); r.pipe(res); });
      up.on('error', () => { if (!res.headersSent) res.writeHead(502); res.end(); });
      req.pipe(up);
      return;
    }
    const rel = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
    const file = normalize(join(ROOT, rel));
    if (!file.startsWith(ROOT + sep) || file.includes(`${sep}node_modules${sep}`) || file.includes(`${sep}backend${sep}`)) { res.writeHead(404); res.end(); return; }
    readFile(file).then((buf: Buffer) => {
      let body: Buffer | string = buf;
      if (rel === 'index.html') {
        const html = buf.toString('utf8');
        const tag = '<meta name="najaf-api-base-url" content="">';
        if (!html.includes(tag)) throw new Error('index.html no longer has the empty najaf-api-base-url meta this test configures');
        body = html.replace(tag, `<meta name="najaf-api-base-url" content="${FRONT}">`);
      }
      res.writeHead(200, { 'content-type': TYPES[extname(file)] ?? 'application/octet-stream', 'cache-control': 'no-store' });
      res.end(body);
    }).catch(() => { if (!res.headersSent) res.writeHead(404); res.end(); });
  };

  before(async () => {
    admin = await createDb(adminConfig());
    const hasher = createArgon2idHasher();
    await newUser(dealer, 'dealer', await hasher.hash(dealer.password));
    await newUser(adminUser, 'admin', await hasher.hash(adminUser.password));
    showroomId = String((await admin.query<{ id: string }>(`INSERT INTO showrooms (owner_id, name, status) VALUES ($1::bigint, $2, 'active') RETURNING id`, [dealer.id, `معرض تجربة ${run}`])).rows[0]!.id);

    const [apiPort, frontPort, evilPort] = [await freePort(), await freePort(), await freePort()];
    API = `http://127.0.0.1:${apiPort}`;
    FRONT = `http://127.0.0.1:${frontPort}`;
    EVIL = `http://localhost:${evilPort}`; // another SITE as well as another origin
    const env: Record<string, string> = {};
    for (const k of ['PATH', 'HOME', 'TMPDIR', 'LANG', 'SystemRoot']) if (process.env[k] !== undefined) env[k] = process.env[k]!;
    Object.assign(env, {
      NODE_ENV: 'test', HOST: '127.0.0.1', PORT: String(apiPort), LOG_LEVEL: 'warn', DATABASE_URL: APP_URL!,
      AUTH_ACCESS_TOKEN_SECRET: `e2e${randomBytes(36).toString('base64url')}`, AUTH_COOKIE_ORIGINS: FRONT, AUTH_COOKIE_SECURE: 'false',
    }); // nothing else: no storage, no reward provider, never the superuser URL
    backend = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/index.ts'], { cwd: BACKEND_DIR, env, stdio: ['ignore', 'pipe', 'pipe'] });
    backend.stdout!.on('data', (d: Buffer) => { backendLog += d.toString(); });
    backend.stderr!.on('data', (d: Buffer) => { backendLog += d.toString(); });
    let up = false;
    for (let i = 0; i < 120 && !up; i++) {
      if (backend.exitCode !== null) break;
      try { up = (await fetch(`${API}/healthz`)).ok; } catch { await new Promise((r) => setTimeout(r, 250)); }
    }
    if (!up) throw new Error(`the application server did not start:\n${backendLog.slice(-4000)}`);

    front = createServer(frontHandler);
    await listen(front, frontPort, '127.0.0.1');
    evil = createServer((_req: IncomingMessage, res: ServerResponse) => { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end('<!doctype html><html lang="en"><body>another origin</body></html>'); });
    await listen(evil, evilPort, '127.0.0.1');
    browser = await pw!.chromium.launch();
  });

  after(async () => {
    await browser?.close().catch(() => undefined);
    await closeServer(front);
    await closeServer(evil);
    if (backend && backend.exitCode === null) {
      backend.kill('SIGTERM');
      await new Promise((r) => { const t = setTimeout(r, 5000); backend!.once('exit', () => { clearTimeout(t); r(undefined); }); });
    }
    if (admin) {
      if (showroomId) {
        await admin.query(`DELETE FROM cars WHERE showroom_id = $1::bigint`, [showroomId]);
        await admin.query(`DELETE FROM showrooms WHERE id = $1::bigint`, [showroomId]);
      }
      if (userIds.length > 0) {
        await admin.query(`DELETE FROM sessions WHERE user_id = ANY($1::bigint[])`, [userIds]);
        await admin.query(`DELETE FROM users WHERE id = ANY($1::bigint[])`, [userIds]);
      }
      await admin.close();
    }
  });

  /** A fresh browser profile on FRONT; every page error fails the test; every API call must stay on FRONT (never the backend's port). */
  const openApp = async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar-IQ' });
    const page = await context.newPage();
    const pageErrors: string[] = [];
    const offOrigin: string[] = [];
    const apiCalls: string[] = [];
    page.on('pageerror', (e) => pageErrors.push(e.message));
    page.on('response', (r) => { const u = new URL(r.url()); if (u.pathname.startsWith('/v1/')) apiCalls.push(`${r.request().method()} ${u.pathname} ${r.status()}`); });
    page.on('request', (r) => { if (r.url().startsWith(API)) offOrigin.push(r.url()); });
    await page.goto(`${FRONT}/`, { waitUntil: 'load' });
    await page.waitForFunction(() => typeof (window as unknown as { go?: unknown }).go === 'function');
    return { context, page, pageErrors, offOrigin, apiCalls };
  };
  const go = (page: PwPage, route: string, param?: string) => page.evaluate(([r, p]) => { (window as unknown as { go: (a: string, b?: string) => void }).go(r!, p); }, [route, param] as const);
  const isApi = (path: string, method = 'GET') => (r: PwResponse) => new URL(r.url()).pathname === path && r.request().method() === method;
  const login = async (page: PwPage, u: typeof dealer) => {
    await go(page, 'login');
    await page.fill('#loginIdentifier', u.phoneLocal);
    await page.fill('#loginPassword', u.password);
    const [res] = await Promise.all([page.waitForResponse(isApi('/v1/auth/login', 'POST')), page.click('button.btn-primary:has-text("تسجيل الدخول")')]);
    return res;
  };

  it('public browsing: Arabic RTL, the catalog comes from the real server through the configured base URL', async () => {
    const { context, page, pageErrors, offOrigin } = await openApp();
    try {
      const doc = await page.evaluate(() => ({ dir: document.documentElement.dir, lang: document.documentElement.lang, title: document.title, base: document.querySelector('meta[name="najaf-api-base-url"]')!.getAttribute('content') }));
      assert.deepEqual([doc.dir, doc.lang, doc.title, doc.base], ['rtl', 'ar', 'معارض النجف', FRONT]);
      const [res] = await Promise.all([page.waitForResponse((r) => new URL(r.url()).pathname === '/v1/public/cars' && r.request().method() === 'GET'), go(page, 'cars')]);
      assert.equal(res.status(), 200);
      const items = ((await res.json()) as { items: Array<{ id: string; sourceType: string }> }).items;
      assert.ok(items.length > 0, 'the staging seed has public showroom cars');
      const first = items[0]!;
      await page.locator(`.car-card .card-body[onclick="go('carDetails','${first.id}')"]`).first().waitFor();
      assert.equal(await page.locator('.car-card').count() > 0, true);
      const [detail] = await Promise.all([page.waitForResponse(isApi(`/v1/public/cars/${first.id}`)), page.locator(`.card-body[onclick="go('carDetails','${first.id}')"]`).first().click()]);
      assert.equal(detail.status(), 200);
      assert.equal(await page.evaluate(() => getComputedStyle(document.body).direction), 'rtl');
      assert.deepEqual(pageErrors, []);
      assert.deepEqual(offOrigin, [], 'every API call goes to the configured (same) origin');
    } finally {
      await context.close();
    }
  });

  it('dealer: logs in (refresh token only in an HttpOnly SameSite=Strict cookie), adds a car through the UI, keeps the session across a reload, logs out', async () => {
    const { context, page, pageErrors, offOrigin } = await openApp();
    try {
      const res = await login(page, dealer);
      assert.equal(res.status(), 200);
      assert.equal(res.request().headers()['x-session-transport'], 'cookie');
      const body = (await res.json()) as Record<string, unknown> & { session?: Record<string, unknown> };
      assert.ok(!JSON.stringify(body).includes('refreshToken'), 'the refresh token never reaches page JavaScript');
      const setCookie = (await res.headerValue('set-cookie')) ?? '';
      assert.match(setCookie, /^najaf_rt=/);
      for (const attr of [/HttpOnly/i, /SameSite=Strict/i, /Path=\/v1\/auth/i]) assert.match(setCookie, attr);
      const cookie = (await context.cookies()).find((c) => c.name === 'najaf_rt'); // (cookies(url) would filter by path: this one is /v1/auth only)
      assert.ok(cookie && cookie.httpOnly && cookie.sameSite === 'Strict' && cookie.path === '/v1/auth');
      assert.ok(!(await page.evaluate(() => document.cookie)).includes('najaf_rt'));

      // the dealer area, then a new car through the real form
      await go(page, 'addShowroomCar');
      await page.fill('#scBrand', 'Kia');
      await page.fill('#scModel', 'Sportage');
      await page.fill('#scYear', '2022');
      await page.fill('#scPrice', '31000000');
      await page.selectOption('#scCurrency', 'IQD');
      await page.fill('#scColor', 'أبيض');
      await page.fill('#scDescription', `سيارة تجربة ${run}`);
      const [created] = await Promise.all([page.waitForResponse(isApi('/v1/dealer/cars', 'POST')), page.click('#addShowroomCarBtn')]);
      assert.equal(created.status(), 201, await created.text());
      const sent = created.request().postDataJSON() as Record<string, unknown>;
      const car = ((await created.json()) as { car: { id: string; brand: string; model: string; status: string } }).car;
      const row = (await admin.query<{ showroom_id: string; brand: string; model: string; status: string; description: string }>(`SELECT showroom_id, brand, model, status, description FROM cars WHERE id = $1::bigint`, [car.id])).rows[0]!;
      assert.deepEqual([String(row.showroom_id), row.brand, row.model, row.status, row.description], [showroomId, sent['brand'], sent['model'], 'available', `سيارة تجربة ${run}`]);
      assert.equal(await page.evaluate(async (id) => (await fetch(`/v1/public/cars/${id}`)).status, car.id), 200, 'a free showroom\'s first car is public at once');

      await go(page, 'myShowroomCars');
      await page.locator('.ad-row .card-title', { hasText: `${car.brand} ${car.model}` }).first().waitFor();

      // the dealer is kept out of the administration area (UI guard; the API answers 404 to a non-administrator)
      await go(page, 'adminDashboard');
      assert.equal(await page.evaluate('currentRoute'), 'accessDenied');

      // reload: the page restores the session from the HttpOnly cookie alone
      const [refreshed] = await Promise.all([page.waitForResponse(isApi('/v1/auth/refresh', 'POST')), page.reload({ waitUntil: 'load' })]);
      assert.equal(refreshed.status(), 200);
      assert.ok(!JSON.stringify(await refreshed.json()).includes('refreshToken'));
      await page.waitForFunction('SessionService.isLoggedIn()'); // a top-level const of the app scripts, not a window property
      const [list] = await Promise.all([page.waitForResponse(isApi('/v1/dealer/cars')), go(page, 'myShowroomCars')]);
      assert.equal(list.status(), 200);
      assert.ok(((await list.json()) as { items: Array<{ id: string }> }).items.some((c) => c.id === car.id));

      // logout ends the server session and clears the cookie; a later reload cannot restore it
      const [out] = await Promise.all([page.waitForResponse(isApi('/v1/auth/logout', 'POST')), page.evaluate(() => { (window as unknown as { handleLogout: () => void }).handleLogout(); })]);
      assert.ok(out.status() >= 200 && out.status() < 300, String(out.status()));
      assert.equal((await context.cookies()).some((c) => c.name === 'najaf_rt'), false);
      await page.reload({ waitUntil: 'load' });
      await page.waitForFunction(() => typeof (window as unknown as { go?: unknown }).go === 'function');
      await page.waitForTimeout(500);
      assert.equal(await page.evaluate('SessionService.isLoggedIn()'), false);
      const live = await admin.query<{ n: string }>(`SELECT count(*) AS n FROM sessions WHERE user_id = $1::bigint AND revoked_at IS NULL`, [dealer.id]);
      assert.equal(Number(live.rows[0]!.n), 0, 'no live server session remains');
      assert.deepEqual(pageErrors, []);
      assert.deepEqual(offOrigin, []);
    } finally {
      await context.close();
    }
  });

  it('administrator: logs in, sees the dashboard statistics and the user and dealer lists from the real server', async () => {
    const { context, page, pageErrors, offOrigin, apiCalls } = await openApp();
    try {
      assert.equal((await login(page, adminUser)).status(), 200);
      const [stats] = await Promise.all([page.waitForResponse(isApi('/v1/admin/stats')), go(page, 'adminDashboard')]);
      assert.equal(stats.status(), 200);
      const s = ((await stats.json()) as { stats: { totalUsers: number; totalShowrooms: number } }).stats;
      assert.ok(s.totalUsers >= 2 && s.totalShowrooms >= 1);
      await page.locator('.stat-card .num', { hasText: String(s.totalUsers) }).first().waitFor();
      const [users] = await Promise.all([page.waitForResponse(isApi('/v1/admin/users')), go(page, 'adminUsers')]);
      assert.equal(users.status(), 200);
      assert.ok(((await users.json()) as { users: unknown[] }).users.length > 0);
      await go(page, 'adminDealerRequests'); // its list (GET /v1/admin/dealers) is shared with the dashboard's pending badge
      await page.waitForFunction("currentRoute === 'adminDealerRequests'");
      await page.waitForTimeout(300);
      assert.ok(apiCalls.some((c) => /^GET \/v1\/admin\/dealers 200$/.test(c)), apiCalls.join(', '));
      assert.ok(!apiCalls.some((c) => / (401|403|5\d\d)$/.test(c)), apiCalls.join(', '));
      assert.deepEqual(pageErrors, []);
      assert.deepEqual(offOrigin, []);
    } finally {
      await context.close();
    }
  });

  it('CORS: another origin can neither read the API nor call it, and the cookie routes refuse a foreign or missing Origin', async () => {
    const context = await browser.newContext();
    const page = await context.newPage();
    try {
      await page.goto(`${EVIL}/`);
      const outcome = await page.evaluate(async ([front, phone, password]) => {
        const attempt = async (f: () => Promise<Response>) => { try { const r = await f(); return `read:${r.status}`; } catch { return 'blocked'; } };
        return {
          get: await attempt(() => fetch(`${front}/v1/public/cars?limit=1`)),
          login: await attempt(() => fetch(`${front}/v1/auth/login`, { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json', 'x-session-transport': 'cookie' }, body: JSON.stringify({ phone, password }) })),
        };
      }, [FRONT, `+964${dealer.phoneLocal.slice(1)}`, dealer.password] as const);
      assert.deepEqual(outcome, { get: 'blocked', login: 'blocked' });
    } finally {
      await context.close();
    }
    // the server itself grants no cross-origin access (no CORS headers at all), on a simple request and on a preflight
    const simple = await fetch(`${FRONT}/v1/public/cars?limit=1`, { headers: { origin: EVIL } });
    assert.equal(simple.headers.get('access-control-allow-origin'), null);
    const preflight = await fetch(`${FRONT}/v1/auth/login`, { method: 'OPTIONS', headers: { origin: EVIL, 'access-control-request-method': 'POST', 'access-control-request-headers': 'content-type,x-session-transport' } });
    assert.equal(preflight.headers.get('access-control-allow-origin'), null);
    assert.equal(preflight.headers.get('access-control-allow-credentials'), null);
    // cookie transport from a foreign origin or with no Origin: 403, and no cookie is set
    for (const headers of [{ origin: EVIL }, {}] as Array<Record<string, string>>) {
      const r = await fetch(`${API}/v1/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-session-transport': 'cookie', ...headers }, body: JSON.stringify({ phone: `+964${dealer.phoneLocal.slice(1)}`, password: dealer.password }) });
      assert.equal(r.status, 403, JSON.stringify(headers));
      assert.equal(r.headers.get('set-cookie'), null);
    }
  });
});

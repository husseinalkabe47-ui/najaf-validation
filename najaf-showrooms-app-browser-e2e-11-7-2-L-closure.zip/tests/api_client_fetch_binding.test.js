/* Phase 11.7.2-L — a real browser refuses `fetch` called as a method of another object ("Illegal invocation": WindowOrGlobalScope
   methods need the global as `this`). The client used to call `env.fetch(url, init)`, so EVERY server-mode request failed as a
   "network error" in Chrome/Edge/Firefox while the injected-fetch tests passed. Found by the real-browser e2e test
   (backend/test/e2e/browser.e2e.test.ts). These checks model the browser rule: fetch must be called without a foreign receiver. */
const test = require('node:test');
const assert = require('node:assert/strict');
const ApiClient = require('../api/apiClient.js');

/** A fetch that behaves like the browser's: it throws when invoked with a receiver other than undefined or the global object. */
function browserLikeFetch(calls) {
  return function (url, init) {
    'use strict';
    if (this !== undefined && this !== globalThis) return Promise.reject(new TypeError("Failed to execute 'fetch' on 'Window': Illegal invocation"));
    calls.push({ url, init });
    return Promise.resolve(new Response(JSON.stringify({ items: [], nextBefore: null }), { status: 200, headers: { 'content-type': 'application/json' } }));
  };
}

test('an injected fetch is called without a foreign receiver', async () => {
  const calls = [];
  const api = ApiClient.create({ baseUrl: 'https://api.example.test', fetch: browserLikeFetch(calls) });
  const data = await api.get('/v1/public/cars', { auth: 'none' });
  assert.deepEqual(data, { items: [], nextBefore: null });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://api.example.test/v1/public/cars');
});

test('the global fetch (the browser default, nothing injected) is called without a foreign receiver', async () => {
  const calls = [];
  const original = globalThis.fetch;
  globalThis.fetch = browserLikeFetch(calls);
  try {
    const api = ApiClient.create({ baseUrl: 'https://api.example.test' });
    const data = await api.get('/v1/public/cars', { auth: 'none' });
    assert.deepEqual(data, { items: [], nextBefore: null });
    assert.equal(calls.length, 1);
  } finally {
    globalThis.fetch = original;
  }
});

// Object storage entry point (Phase 11.6.1). Nothing in the running server uses storage yet: upload and processing are later steps.
export { StorageError, assertContentType } from './provider.ts';
export type { PutOptions, StorageErrorCode, StorageProvider, StoredObject } from './provider.ts';
export { assertSafeKey, isSafeKey, KEY_MAX_LENGTH, KEY_MAX_SEGMENTS } from './keys.ts';
export { STORAGE_ENV_VARS, StorageConfigError, loadStorageConfig, redactStorageConfig } from './config.ts';
export type { S3Settings, StorageConfig } from './config.ts';
export { createS3Storage } from './s3.ts';
export type { S3Deps } from './s3.ts';
export { createMemoryStorage } from './memory.ts';
export type { MemoryStorage } from './memory.ts';

import { loadStorageConfig } from './config.ts';
import type { StorageConfig } from './config.ts';
import { createMemoryStorage } from './memory.ts';
import type { StorageProvider } from './provider.ts';
import { createS3Storage } from './s3.ts';
import type { S3Deps } from './s3.ts';

/** The provider a validated configuration describes. */
export function createStorage(config: StorageConfig, deps: S3Deps = {}): StorageProvider {
  if (config.provider === 'memory') return createMemoryStorage({ keyPrefix: config.keyPrefix, maxObjectBytes: config.maxObjectBytes });
  if (!config.s3) throw new Error('r2 storage needs S3 settings');
  return createS3Storage({ s3: config.s3, keyPrefix: config.keyPrefix, timeoutMs: config.timeoutMs, maxObjectBytes: config.maxObjectBytes }, deps);
}

/** Validates the environment (StorageConfigError lists every problem, never a secret) and returns the provider. */
export function createStorageFromEnv(env: Record<string, string | undefined> = process.env, deps: S3Deps = {}): StorageProvider {
  return createStorage(loadStorageConfig(env), deps);
}

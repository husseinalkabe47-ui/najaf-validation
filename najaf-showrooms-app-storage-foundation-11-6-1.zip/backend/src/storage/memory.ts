// In-memory storage provider (Phase 11.6.1): the replaceable fake for tests and local development (refused in production by
// loadStorageConfig). It enforces EXACTLY the same contract as the R2 provider (safe keys, content types, size limit, copies in and
// out, idempotent delete), so code written against it behaves the same against R2. Nothing persists across process restarts.
import { assertSafeKey } from './keys.ts';
import { assertBody, assertContentType } from './provider.ts';
import type { StorageProvider, StoredObject } from './provider.ts';
import { MAX_OBJECT_BYTES_DEFAULT } from './config.ts';

export interface MemoryStorage extends StorageProvider {
  /** Test helper: the number of stored objects. */
  size(): number;
  /** Test helper: the stored keys (prefix included), sorted. Never exposed through any route. */
  keys(): string[];
}

export function createMemoryStorage(opts: { keyPrefix?: string; maxObjectBytes?: number } = {}): MemoryStorage {
  const keyPrefix = opts.keyPrefix ?? '';
  if (keyPrefix !== '') assertSafeKey(keyPrefix);
  const maxObjectBytes = opts.maxObjectBytes ?? MAX_OBJECT_BYTES_DEFAULT;
  const objects = new Map<string, { body: Uint8Array; contentType: string }>();
  const full = (key: string): string => (keyPrefix === '' ? assertSafeKey(key) : `${keyPrefix}/${assertSafeKey(key)}`);

  return {
    kind: 'memory',
    async put(key, body, opts) {
      const k = full(key);
      const type = assertContentType(opts?.contentType);
      const bytes = assertBody(body, maxObjectBytes);
      objects.set(k, { body: new Uint8Array(bytes), contentType: type });
    },
    async get(key): Promise<StoredObject | null> {
      const o = objects.get(full(key));
      return o ? { body: new Uint8Array(o.body), contentType: o.contentType, size: o.body.byteLength } : null;
    },
    async delete(key) {
      objects.delete(full(key));
    },
    async exists(key) {
      return objects.has(full(key));
    },
    size: () => objects.size,
    keys: () => [...objects.keys()].sort(),
  };
}

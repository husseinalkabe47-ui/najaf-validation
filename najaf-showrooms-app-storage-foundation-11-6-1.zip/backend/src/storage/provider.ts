// Object storage abstraction (Phase 11.6.1). The rest of the backend talks to THIS interface only, never to a vendor SDK or URL,
// so the provider is replaceable (Cloudflare R2 or any S3-compatible service, or the in-memory provider in tests and development).
//
// Contract (enforced by every provider and pinned by a shared contract test):
//  - every key is checked with assertSafeKey() BEFORE any I/O; an unsafe key never reaches the network or the map;
//  - put() stores the bytes as given (a copy), with a validated content type, and refuses a body above the configured size;
//  - get() returns a copy of the bytes and the stored content type, or null when the object does not exist;
//  - delete() is idempotent (deleting a missing object succeeds);
//  - exists() is true/false; any other answer of the backend (forbidden, server error, timeout) is an error, never "false";
//  - errors are StorageError with a machine code and a fixed message: never a key, bucket, endpoint, credential or backend body.
// Keys are INTERNAL: they are never accepted from a client and never returned to one (assets.storage_key stays server-side).

export type StorageErrorCode = 'invalid_key' | 'invalid_content_type' | 'too_large' | 'unavailable' | 'integrity';

const MESSAGES: Record<StorageErrorCode, string> = {
  invalid_key: 'The object key is not allowed',
  invalid_content_type: 'The content type is not allowed',
  too_large: 'The object is larger than allowed',
  unavailable: 'The storage service could not complete the request',
  integrity: 'The storage service returned an unexpected response',
};

export class StorageError extends Error {
  readonly code: StorageErrorCode;
  /** The backend's HTTP status when there was one (a number only: no body, no headers). */
  readonly status: number | undefined;
  constructor(code: StorageErrorCode, status?: number) {
    super(MESSAGES[code]);
    this.name = 'StorageError';
    this.code = code;
    this.status = status;
  }
}

export interface StoredObject {
  body: Uint8Array;
  contentType: string | null;
  size: number;
}

export interface PutOptions {
  /** A plain MIME type such as image/webp (no parameters). */
  contentType: string;
}

export interface StorageProvider {
  /** The provider kind, for logs and health output (never a secret). */
  readonly kind: 'r2' | 'memory';
  put(key: string, body: Uint8Array, opts: PutOptions): Promise<void>;
  get(key: string): Promise<StoredObject | null>;
  delete(key: string): Promise<void>;
  exists(key: string): Promise<boolean>;
}

/** A plain `type/subtype` MIME type: lower case token characters only, no parameters, no whitespace, at most 100 characters. */
const CONTENT_TYPE = /^[a-z0-9][a-z0-9!#$&^_.+-]{0,47}\/[a-z0-9][a-z0-9!#$&^_.+-]{0,47}$/;
export function assertContentType(contentType: unknown): string {
  if (typeof contentType !== 'string' || !CONTENT_TYPE.test(contentType)) throw new StorageError('invalid_content_type');
  return contentType;
}

export function assertBody(body: unknown, maxBytes: number): Uint8Array {
  if (!(body instanceof Uint8Array)) throw new StorageError('integrity');
  if (body.byteLength > maxBytes) throw new StorageError('too_large');
  return body;
}

// Cloudflare R2 (or any S3-compatible service) provider (Phase 11.6.1), over the S3 REST API with node's fetch and the SigV4 signer
// in sigv4.ts. No SDK dependency. Everything (endpoint, region, bucket, credentials, prefix, limits) comes from StorageConfig.
//
//  - path-style addressing: <endpoint>/<bucket>/<prefix>/<key>, every segment URI-encoded (keys are already restricted to safe
//    characters by assertSafeKey, which runs before any I/O);
//  - every request is signed with the payload hash (x-amz-content-sha256 = SHA-256 of the body), sent with a timeout, and
//    redirects are refused (signed headers are never replayed to another host);
//  - status mapping: GET/HEAD 404 -> missing (null/false); DELETE 404 -> success (idempotent); any other non-2xx, a network failure,
//    a timeout or a redirect -> StorageError('unavailable', status). The backend's body, the URL, the key and the credentials never
//    appear in an error;
//  - size limits on both directions: a body above maxObjectBytes is refused before sending, and a download is refused (and the
//    stream cancelled) as soon as it is announced or seen to exceed the limit.
import type { S3Settings, StorageConfig } from './config.ts';
import { assertSafeKey } from './keys.ts';
import { StorageError, assertBody, assertContentType } from './provider.ts';
import type { StorageProvider, StoredObject } from './provider.ts';
import { EMPTY_SHA256, sha256Hex, signV4, uriEncode } from './sigv4.ts';

export interface S3Deps {
  fetch?: typeof fetch;
  now?: () => Date;
}

type Method = 'PUT' | 'GET' | 'HEAD' | 'DELETE';

export function createS3Storage(config: Pick<StorageConfig, 'keyPrefix' | 'timeoutMs' | 'maxObjectBytes'> & { s3: S3Settings }, deps: S3Deps = {}): StorageProvider {
  const doFetch = deps.fetch ?? globalThis.fetch;
  const now = deps.now ?? (() => new Date());
  const { s3, keyPrefix, timeoutMs, maxObjectBytes } = config;
  const origin = new URL(s3.endpoint);
  if (origin.protocol !== 'https:' && origin.protocol !== 'http:') throw new StorageError('unavailable');
  const host = origin.host;
  if (keyPrefix !== '') assertSafeKey(keyPrefix);

  function pathOf(key: string): string {
    const full = keyPrefix === '' ? assertSafeKey(key) : `${keyPrefix}/${assertSafeKey(key)}`;
    return '/' + [s3.bucket, ...full.split('/')].map(uriEncode).join('/');
  }

  async function send(method: Method, key: string, body?: Uint8Array<ArrayBuffer>, contentType?: string): Promise<Response> {
    const canonicalPath = pathOf(key);
    const payloadHash = body ? sha256Hex(body) : EMPTY_SHA256;
    const signed = signV4({
      method, host, canonicalPath, headers: contentType ? { 'content-type': contentType } : {}, payloadHash,
      accessKeyId: s3.accessKeyId, secretAccessKey: s3.secretAccessKey, region: s3.region, service: 's3', now: now(),
    });
    try {
      return await doFetch(`${origin.origin}${canonicalPath}`, {
        method,
        headers: signed.headers,
        ...(body ? { body } : {}),
        redirect: 'error',
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch {
      // Network failure, timeout or a redirect. The underlying error may contain the URL: it is deliberately dropped.
      throw new StorageError('unavailable');
    }
  }

  const discard = async (res: Response): Promise<void> => {
    try {
      await res.body?.cancel();
    } catch {
      /* nothing to release */
    }
  };
  const fail = async (res: Response): Promise<never> => {
    await discard(res);
    throw new StorageError('unavailable', res.status);
  };

  async function readLimited(res: Response): Promise<Uint8Array> {
    const declared = res.headers.get('content-length');
    if (declared !== null && (!/^\d{1,15}$/.test(declared) || Number(declared) > maxObjectBytes)) {
      await discard(res);
      throw new StorageError(/^\d{1,15}$/.test(declared) ? 'too_large' : 'integrity');
    }
    if (!res.body) return new Uint8Array(0);
    const reader = res.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    for (;;) {
      let step: ReadableStreamReadResult<Uint8Array>;
      try {
        step = await reader.read();
      } catch {
        throw new StorageError('unavailable');
      }
      if (step.done) break;
      total += step.value.byteLength;
      if (total > maxObjectBytes) {
        try {
          await reader.cancel();
        } catch {
          /* already closed */
        }
        throw new StorageError('too_large');
      }
      chunks.push(step.value);
    }
    if (declared !== null && Number(declared) !== total) throw new StorageError('integrity');
    const out = new Uint8Array(total);
    let at = 0;
    for (const c of chunks) {
      out.set(c, at);
      at += c.byteLength;
    }
    return out;
  }

  return {
    kind: 'r2',
    async put(key, body, opts) {
      pathOf(key);
      const type = assertContentType(opts?.contentType);
      // A private copy: the caller cannot change the bytes between hashing and sending.
      const bytes = new Uint8Array(assertBody(body, maxObjectBytes));
      const res = await send('PUT', key, bytes, type);
      if (res.status !== 200) return fail(res);
      await discard(res);
    },
    async get(key): Promise<StoredObject | null> {
      pathOf(key);
      const res = await send('GET', key);
      if (res.status === 404) {
        await discard(res);
        return null;
      }
      if (res.status !== 200) return fail(res);
      const body = await readLimited(res);
      return { body, contentType: res.headers.get('content-type'), size: body.byteLength };
    },
    async delete(key) {
      pathOf(key);
      const res = await send('DELETE', key);
      if (res.status === 204 || res.status === 200 || res.status === 404) return void (await discard(res));
      return fail(res);
    },
    async exists(key) {
      pathOf(key);
      const res = await send('HEAD', key);
      await discard(res);
      if (res.status === 200) return true;
      if (res.status === 404) return false;
      throw new StorageError('unavailable', res.status);
    },
  };
}

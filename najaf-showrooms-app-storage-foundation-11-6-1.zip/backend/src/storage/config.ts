// Object storage configuration (Phase 11.6.1). Kept in its own module, like the authentication and migration configuration, so the
// application configuration and its tests are untouched. Every value comes from the environment: there is no built-in endpoint,
// bucket, region or credential. Errors and redactStorageConfig() never contain the secret, the access key id or the endpoint.
//
// STORAGE_PROVIDER selects the provider:
//  - r2:     Cloudflare R2 (or any S3-compatible service) through the S3 API. Endpoint, region, bucket and the two credentials are
//            all REQUIRED. The endpoint must be https (plain http is accepted only for a loopback host outside production, for a
//            local S3-compatible test server).
//  - memory: the in-memory provider (tests and local development only; refused when NODE_ENV=production). No S3 variable may be set.
// NODE_ENV is read here too (documented in .env.example).
import { isSafeKey } from './keys.ts';

export const STORAGE_ENV_VARS = [
  'STORAGE_PROVIDER',
  'STORAGE_S3_ENDPOINT',
  'STORAGE_S3_REGION',
  'STORAGE_S3_BUCKET',
  'STORAGE_S3_ACCESS_KEY_ID',
  'STORAGE_S3_SECRET_ACCESS_KEY',
  'STORAGE_KEY_PREFIX',
  'STORAGE_TIMEOUT_MS',
  'STORAGE_MAX_OBJECT_BYTES',
] as const;

const S3_VARS = ['STORAGE_S3_ENDPOINT', 'STORAGE_S3_REGION', 'STORAGE_S3_BUCKET', 'STORAGE_S3_ACCESS_KEY_ID', 'STORAGE_S3_SECRET_ACCESS_KEY'] as const;

export interface S3Settings {
  /** Origin only (scheme, host, optional port), e.g. https://<account>.r2.cloudflarestorage.com — from the environment. */
  endpoint: string;
  region: string;
  bucket: string;
  accessKeyId: string;
  secretAccessKey: string;
}

export interface StorageConfig {
  provider: 'r2' | 'memory';
  s3: S3Settings | null;
  /** Optional key prefix (e.g. "staging"), applied by the provider; '' = none. */
  keyPrefix: string;
  timeoutMs: number;
  maxObjectBytes: number;
}

export class StorageConfigError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`Invalid storage configuration:\n- ${problems.join('\n- ')}`);
    this.name = 'StorageConfigError';
    this.problems = problems;
  }
}

export const TIMEOUT_DEFAULT_MS = 10_000;
export const TIMEOUT_MIN_MS = 1_000;
export const TIMEOUT_MAX_MS = 60_000;
export const MAX_OBJECT_BYTES_DEFAULT = 10 * 1024 * 1024;
export const MAX_OBJECT_BYTES_LIMIT = 100 * 1024 * 1024;
export const MIN_SECRET_LENGTH = 32;

const PLACEHOLDERS = ['change-me', 'changeme', 'secret', 'password', 'example', 'placeholder', 'your-', 'xxxxx'];
const ACCESS_KEY_ID = /^[A-Za-z0-9]{16,128}$/;
const REGION = /^[a-z0-9][a-z0-9-]{0,31}$/;
// S3/R2 bucket names: 3..63 lower-case letters, digits and hyphens, starting and ending with a letter or digit. No dots (path-style
// addressing is used, and dotted names break TLS for virtual-hosted access).
const BUCKET = /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/;
const LOOPBACK = new Set(['localhost', '127.0.0.1', '[::1]']);

function endpointProblem(raw: string, production: boolean): string | undefined {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return 'STORAGE_S3_ENDPOINT is not a valid URL';
  }
  if (url.username !== '' || url.password !== '') return 'STORAGE_S3_ENDPOINT must not contain credentials';
  if (url.protocol === 'http:') {
    if (production || !LOOPBACK.has(url.hostname)) return 'STORAGE_S3_ENDPOINT must use https (plain http only for a loopback test server outside production)';
  } else if (url.protocol !== 'https:') return 'STORAGE_S3_ENDPOINT must use https';
  if (url.hostname === '') return 'STORAGE_S3_ENDPOINT has no host';
  if (url.pathname !== '/' || url.search !== '' || url.hash !== '' || raw.includes('?') || raw.includes('#')) return 'STORAGE_S3_ENDPOINT must be an origin only (no path, query or fragment)';
  return undefined;
}

function intVar(env: Record<string, string | undefined>, name: string, def: number, min: number, max: number, problems: string[]): number {
  const raw = env[name];
  if (raw === undefined || raw === '') return def;
  if (!/^[0-9]{1,10}$/.test(raw) || Number(raw) < min || Number(raw) > max) {
    problems.push(`${name} must be a whole number between ${min} and ${max}`);
    return def;
  }
  return Number(raw);
}

export function loadStorageConfig(env: Record<string, string | undefined> = process.env): StorageConfig {
  const problems: string[] = [];
  const production = env['NODE_ENV'] === 'production';
  const provider = env['STORAGE_PROVIDER'] ?? '';
  if (provider !== 'r2' && provider !== 'memory') problems.push('STORAGE_PROVIDER is required and must be "r2" or "memory"');
  if (provider === 'memory' && production) problems.push('STORAGE_PROVIDER=memory is not allowed in production');

  let s3: S3Settings | null = null;
  if (provider === 'memory') {
    for (const v of S3_VARS) if ((env[v] ?? '') !== '') problems.push(`${v} must not be set when STORAGE_PROVIDER=memory`);
  }
  if (provider === 'r2') {
    const endpoint = env['STORAGE_S3_ENDPOINT'] ?? '';
    const region = env['STORAGE_S3_REGION'] ?? '';
    const bucket = env['STORAGE_S3_BUCKET'] ?? '';
    const accessKeyId = env['STORAGE_S3_ACCESS_KEY_ID'] ?? '';
    const secretAccessKey = env['STORAGE_S3_SECRET_ACCESS_KEY'] ?? '';
    for (const v of S3_VARS) if ((env[v] ?? '') === '') problems.push(`${v} is required when STORAGE_PROVIDER=r2`);
    if (endpoint !== '') {
      const p = endpointProblem(endpoint, production);
      if (p) problems.push(p);
    }
    if (region !== '' && !REGION.test(region)) problems.push('STORAGE_S3_REGION must be lower-case letters, digits and hyphens (for R2: auto)');
    if (bucket !== '' && !BUCKET.test(bucket)) problems.push('STORAGE_S3_BUCKET must be 3-63 lower-case letters, digits and hyphens, starting and ending with a letter or digit');
    if (accessKeyId !== '' && !ACCESS_KEY_ID.test(accessKeyId)) problems.push('STORAGE_S3_ACCESS_KEY_ID must be 16-128 letters and digits');
    if (secretAccessKey !== '') {
      if (secretAccessKey.length < MIN_SECRET_LENGTH || secretAccessKey.length > 256) problems.push(`STORAGE_S3_SECRET_ACCESS_KEY must be ${MIN_SECRET_LENGTH}-256 characters`);
      if (!/^[\x21-\x7e]+$/.test(secretAccessKey)) problems.push('STORAGE_S3_SECRET_ACCESS_KEY must be printable ASCII without whitespace');
      if (PLACEHOLDERS.some((p) => secretAccessKey.toLowerCase().includes(p))) problems.push('STORAGE_S3_SECRET_ACCESS_KEY looks like a placeholder');
      if (secretAccessKey === accessKeyId) problems.push('STORAGE_S3_SECRET_ACCESS_KEY must differ from the access key id');
    }
    if (problems.length === 0) s3 = Object.freeze({ endpoint: new URL(endpoint).origin, region, bucket, accessKeyId, secretAccessKey });
  }

  const keyPrefix = env['STORAGE_KEY_PREFIX'] ?? '';
  if (keyPrefix !== '' && !isSafeKey(keyPrefix)) problems.push('STORAGE_KEY_PREFIX must be a safe key (letters, digits, ".", "_", "-" segments joined by "/")');
  const timeoutMs = intVar(env, 'STORAGE_TIMEOUT_MS', TIMEOUT_DEFAULT_MS, TIMEOUT_MIN_MS, TIMEOUT_MAX_MS, problems);
  const maxObjectBytes = intVar(env, 'STORAGE_MAX_OBJECT_BYTES', MAX_OBJECT_BYTES_DEFAULT, 1, MAX_OBJECT_BYTES_LIMIT, problems);

  if (problems.length > 0) throw new StorageConfigError(problems);
  return Object.freeze({ provider: provider as 'r2' | 'memory', s3, keyPrefix, timeoutMs, maxObjectBytes });
}

/** For logs and health output: no secret, no access key id, no endpoint (it names the account), no bucket. */
export function redactStorageConfig(cfg: StorageConfig): Record<string, unknown> {
  return {
    provider: cfg.provider,
    s3: cfg.s3 ? { endpoint: '***', region: cfg.s3.region, bucket: '***', accessKeyId: '***', secretAccessKey: '***' } : null,
    keyPrefix: cfg.keyPrefix,
    timeoutMs: cfg.timeoutMs,
    maxObjectBytes: cfg.maxObjectBytes,
  };
}

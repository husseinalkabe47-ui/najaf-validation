// AWS Signature Version 4 for the S3 API (Phase 11.6.1), with node:crypto only (no SDK dependency). R2 accepts exactly this
// signature with region "auto" and service "s3". Pure and deterministic for a given clock, so it is tested against an independent
// reference implementation (botocore) and AWS's published examples.
//
// The payload is always signed (x-amz-content-sha256 = SHA-256 of the body); UNSIGNED-PAYLOAD is never used.
import { createHash, createHmac } from 'node:crypto';

export const EMPTY_SHA256 = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

export const sha256Hex = (data: Uint8Array | string): string => createHash('sha256').update(data).digest('hex');
const hmac = (key: Uint8Array | string, data: string): Buffer => createHmac('sha256', key).update(data, 'utf8').digest();

/** RFC 3986 percent-encoding as S3 expects it (unreserved characters A-Z a-z 0-9 - . _ ~ are kept). */
export function uriEncode(s: string): string {
  return encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

/** 20150830T123600Z */
export function amzDate(d: Date): string {
  return d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

export interface SignInput {
  method: string;
  /** host[:port] exactly as it is sent in the Host header. */
  host: string;
  /** The canonical (already URI-encoded) path, starting with "/". */
  canonicalPath: string;
  /** Query parameters (decoded); [] for none. */
  query?: ReadonlyArray<[string, string]>;
  /** Extra headers to sign, e.g. content-type. Names are lower-cased here. */
  headers: Record<string, string>;
  payloadHash: string;
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
  service: string;
  now: Date;
}

export interface Signed {
  /** Every header that must be sent (the signed ones, x-amz-date, x-amz-content-sha256 and authorization), host excluded. */
  headers: Record<string, string>;
  /** Exposed for tests only. */
  canonicalRequest: string;
  stringToSign: string;
  signature: string;
}

export function signV4(input: SignInput): Signed {
  const date = amzDate(input.now);
  const day = date.slice(0, 8);
  const all: Record<string, string> = { host: input.host, 'x-amz-content-sha256': input.payloadHash, 'x-amz-date': date };
  for (const [k, v] of Object.entries(input.headers)) all[k.toLowerCase()] = v;
  const names = Object.keys(all).sort();
  const canonicalHeaders = names.map((n) => `${n}:${all[n]!.trim().replace(/\s+/g, ' ')}\n`).join('');
  const signedHeaders = names.join(';');
  const canonicalQuery = [...(input.query ?? [])]
    .map(([k, v]) => [uriEncode(k), uriEncode(v)] as const)
    .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join('&');
  const canonicalRequest = [input.method, input.canonicalPath, canonicalQuery, canonicalHeaders, signedHeaders, input.payloadHash].join('\n');
  const scope = `${day}/${input.region}/${input.service}/aws4_request`;
  const stringToSign = ['AWS4-HMAC-SHA256', date, scope, sha256Hex(canonicalRequest)].join('\n');
  const kDate = hmac(`AWS4${input.secretAccessKey}`, day);
  const kRegion = hmac(kDate, input.region);
  const kService = hmac(kRegion, input.service);
  const kSigning = hmac(kService, 'aws4_request');
  const signature = createHmac('sha256', kSigning).update(stringToSign, 'utf8').digest('hex');
  const headers: Record<string, string> = {};
  for (const n of names) if (n !== 'host') headers[n] = all[n]!;
  headers['authorization'] = `AWS4-HMAC-SHA256 Credential=${input.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  return { headers, canonicalRequest, stringToSign, signature };
}

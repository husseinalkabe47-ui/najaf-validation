// A fake S3-compatible endpoint (Phase 11.6.1) exposed as a `fetch` function, for the R2 provider's unit tests. Like R2 it:
//  - REJECTS (403) any request whose SigV4 signature, payload hash, date, credential scope or host does not verify;
//  - implements PUT (200), GET (200/404), HEAD (200/404) and DELETE (204, also for a missing object) on path-style URLs;
// and it records every request (method, path, headers) so tests can assert what went over the wire.
// Fault injection: a forced status, a network error, a hang (to exercise the timeout), a lying or huge Content-Length, a
// streamed body larger than allowed, and a redirect.
import { sha256Hex, signV4 } from '../../src/storage/sigv4.ts';

export interface FakeS3Options {
  host: string;
  bucket: string;
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
}
export interface SeenRequest {
  method: string;
  url: string;
  path: string;
  headers: Record<string, string>;
  bodyLength: number;
  redirect: string | undefined;
  hasSignal: boolean;
}

export function makeFakeS3(opts: FakeS3Options) {
  const objects = new Map<string, { body: Uint8Array; contentType: string }>();
  const seen: SeenRequest[] = [];
  const faults: {
    status: number | null;
    statusBody: string;
    network: boolean;
    hang: boolean;
    contentLength: string | null;
    streamExtra: number;
    redirect: boolean;
  } = { status: null, statusBody: '', network: false, hang: false, contentLength: null, streamExtra: 0, redirect: false };

  const verify = (method: string, url: URL, headers: Record<string, string>, body: Uint8Array): boolean => {
    const auth = headers['authorization'] ?? '';
    const m = /^AWS4-HMAC-SHA256 Credential=([^/]+)\/(\d{8})\/([^/]+)\/s3\/aws4_request, SignedHeaders=([a-z0-9;-]+), Signature=([0-9a-f]{64})$/.exec(auth);
    if (!m) return false;
    const [, akid, day, region, signedHeaders, signature] = m;
    if (akid !== opts.accessKeyId || region !== opts.region || url.host !== opts.host) return false;
    const date = headers['x-amz-date'] ?? '';
    if (!date.startsWith(day!)) return false;
    if (headers['x-amz-content-sha256'] !== sha256Hex(body)) return false;
    const names = signedHeaders!.split(';');
    if (!names.includes('host') || !names.includes('x-amz-date') || !names.includes('x-amz-content-sha256')) return false;
    const extra: Record<string, string> = {};
    for (const n of names) if (!['host', 'x-amz-date', 'x-amz-content-sha256'].includes(n)) extra[n] = headers[n] ?? '';
    const now = new Date(`${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}T${date.slice(9, 11)}:${date.slice(11, 13)}:${date.slice(13, 15)}Z`);
    const expected = signV4({ method, host: url.host, canonicalPath: url.pathname, headers: extra, payloadHash: sha256Hex(body), accessKeyId: opts.accessKeyId, secretAccessKey: opts.secretAccessKey, region: opts.region, service: 's3', now });
    return expected.signature === signature;
  };

  const fetchFn = async (input: string | URL | Request, init: RequestInit = {}): Promise<Response> => {
    const url = new URL(String(input));
    // Like a real fetch, the body is read AFTER the call returns (so a caller that mutates its buffer mid-flight is caught).
    await new Promise((r) => setTimeout(r, 0));
    const headers: Record<string, string> = {};
    for (const [k, v] of Object.entries((init.headers ?? {}) as Record<string, string>)) headers[k.toLowerCase()] = v;
    const body = init.body ? new Uint8Array(init.body as Uint8Array) : new Uint8Array(0);
    const method = init.method ?? 'GET';
    seen.push({ method, url: url.toString(), path: url.pathname, headers, bodyLength: body.byteLength, redirect: init.redirect, hasSignal: init.signal instanceof AbortSignal });
    if (faults.network) throw new TypeError(`fetch failed for ${url.toString()} (simulated)`);
    if (faults.hang) {
      return new Promise<Response>((_resolve, reject) => {
        // A real hung socket keeps the process alive; AbortSignal.timeout's own timer does not, so hold the loop open here.
        const keepAlive = setInterval(() => undefined, 1000);
        init.signal?.addEventListener('abort', () => {
          clearInterval(keepAlive);
          reject(new DOMException(`The operation to ${url.toString()} was aborted`, 'TimeoutError'));
        });
      });
    }
    if (faults.redirect) {
      if (init.redirect === 'error') throw new TypeError(`redirect to https://elsewhere.test${url.pathname} refused (simulated)`);
      return new Response(null, { status: 307, headers: { location: 'https://elsewhere.test/' } });
    }
    if (faults.status !== null) return new Response(faults.statusBody, { status: faults.status });
    if (!verify(method, url, headers, body)) return new Response('<Error><Code>SignatureDoesNotMatch</Code></Error>', { status: 403 });
    const parts = url.pathname.split('/').slice(1).map(decodeURIComponent);
    if (parts[0] !== opts.bucket) return new Response('<Error><Code>NoSuchBucket</Code></Error>', { status: 404 });
    const key = parts.slice(1).join('/');
    const obj = objects.get(key);
    switch (method) {
      case 'PUT':
        objects.set(key, { body, contentType: headers['content-type'] ?? 'application/octet-stream' });
        return new Response(null, { status: 200, headers: { etag: `"${sha256Hex(body).slice(0, 32)}"` } });
      case 'GET': {
        if (!obj) return new Response('<Error><Code>NoSuchKey</Code></Error>', { status: 404 });
        const extra = faults.streamExtra;
        const stream = new ReadableStream<Uint8Array>({
          start(c) {
            c.enqueue(obj.body);
            if (extra > 0) c.enqueue(new Uint8Array(extra));
            c.close();
          },
        });
        const h: Record<string, string> = { 'content-type': obj.contentType };
        if (faults.contentLength !== null) h['content-length'] = faults.contentLength;
        else if (extra === 0) h['content-length'] = String(obj.body.byteLength);
        return new Response(stream, { status: 200, headers: h });
      }
      case 'HEAD':
        return new Response(null, { status: obj ? 200 : 404 });
      case 'DELETE':
        objects.delete(key);
        return new Response(null, { status: 204 });
      default:
        return new Response(null, { status: 405 });
    }
  };

  return { fetch: fetchFn as typeof fetch, objects, seen, faults };
}

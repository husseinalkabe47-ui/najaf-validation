// Object storage against a REAL S3-compatible bucket (Phase 11.6.1), e.g. a dedicated Cloudflare R2 test bucket. Opt-in: runs only
// when STORAGE_IT=1 and the STORAGE_* variables describe an r2 provider (see .env.storage.example). It writes, reads and deletes a
// few small objects under a random "ci-it/<id>/" prefix and removes them again. Skipped visibly otherwise.
import { after, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createStorageFromEnv, loadStorageConfig } from '../../src/storage/index.ts';
import type { StorageProvider } from '../../src/storage/index.ts';

const enabled = process.env['STORAGE_IT'] === '1' && process.env['STORAGE_PROVIDER'] === 'r2';
const skip: string | false = enabled ? false : 'storage integration needs STORAGE_IT=1 and an r2 STORAGE_* configuration (a dedicated test bucket)';

describe('object storage on a real S3-compatible bucket', { skip }, () => {
  const run = `ci-it/${randomUUID()}`;
  const keys: string[] = [];
  let s: StorageProvider;
  const key = (name: string) => {
    const k = `${run}/${name}`;
    keys.push(k);
    return k;
  };
  after(async () => {
    if (s) for (const k of keys) await s.delete(k).catch(() => undefined);
  });

  it('validates the configuration and round-trips an object (put, exists, get, delete, idempotent delete)', async () => {
    loadStorageConfig(process.env);
    s = createStorageFromEnv(process.env);
    const k = key('a.bin');
    const body = new Uint8Array(4096).map((_, i) => i & 255);
    await s.put(k, body, { contentType: 'application/octet-stream' });
    assert.equal(await s.exists(k), true);
    const o = await s.get(k);
    assert.deepEqual(Buffer.from(o!.body), Buffer.from(body));
    await s.delete(k);
    await s.delete(k);
    assert.equal(await s.exists(k), false);
    assert.equal(await s.get(k), null);
  });

  it('a wrong secret is refused by the service (unavailable with a 4xx status), never reported as missing', async () => {
    const bad = createStorageFromEnv({ ...process.env, STORAGE_S3_SECRET_ACCESS_KEY: `${process.env['STORAGE_S3_SECRET_ACCESS_KEY']}x` });
    await assert.rejects(bad.exists(key('b.bin')), (e: unknown) => (e as { code?: string; status?: number }).code === 'unavailable' && ((e as { status?: number }).status ?? 0) >= 400);
  });
});

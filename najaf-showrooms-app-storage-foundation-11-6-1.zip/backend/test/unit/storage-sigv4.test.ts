// Phase 11.6.1: the SigV4 signer against AWS's published S3 examples and 40 requests signed by an independent implementation
// (botocore 1.34.22, S3SigV4Auth, signed payload; generated once into test/fixtures/sigv4-botocore-vectors.json).
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { EMPTY_SHA256, amzDate, sha256Hex, signV4, uriEncode } from '../../src/storage/sigv4.ts';

const AWS = { accessKeyId: 'AKIAIOSFODNN7EXAMPLE', secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', region: 'us-east-1', service: 's3', now: new Date(Date.UTC(2013, 4, 24)) };

describe('SigV4 signer', () => {
  it('reproduces the AWS documentation example "GET Object" (examplebucket/test.txt, Range bytes=0-9)', () => {
    const s = signV4({ ...AWS, method: 'GET', host: 'examplebucket.s3.amazonaws.com', canonicalPath: '/test.txt', headers: { range: 'bytes=0-9' }, payloadHash: EMPTY_SHA256 });
    assert.equal(s.signature, 'f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41');
    assert.equal(s.headers['authorization'], 'AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/s3/aws4_request, SignedHeaders=host;range;x-amz-content-sha256;x-amz-date, Signature=f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41');
  });

  it('reproduces the AWS documentation example "PUT Object" (test$file.text, signed payload)', () => {
    const s = signV4({ ...AWS, method: 'PUT', host: 'examplebucket.s3.amazonaws.com', canonicalPath: `/${uriEncode('test$file.text')}`, headers: { date: 'Fri, 24 May 2013 00:00:00 GMT', 'x-amz-storage-class': 'REDUCED_REDUNDANCY' }, payloadHash: sha256Hex('Welcome to Amazon S3.') });
    assert.equal(s.signature, '98ad721746da40c64f1a55b78f14c238d841ea1380cd77a1b5971af0ece108bd');
  });

  it('matches botocore on 40 generated PUT/GET/HEAD/DELETE requests (hosts, regions, keys, bodies, dates)', () => {
    const d = JSON.parse(readFileSync(join(import.meta.dirname, '..', 'fixtures', 'sigv4-botocore-vectors.json'), 'utf8')) as { cases: Array<Record<string, string> & { expected: Record<string, string> }> };
    assert.equal(d.cases.length, 40);
    for (const c of d.cases) {
      const s = signV4({
        method: c['method']!, host: c['host']!, canonicalPath: '/' + [c['bucket']!, ...c['key']!.split('/')].map(uriEncode).join('/'),
        headers: c['contentType'] ? { 'content-type': c['contentType'] } : {}, payloadHash: sha256Hex(Buffer.from(c['bodyHex']!, 'hex')),
        accessKeyId: c['accessKeyId']!, secretAccessKey: c['secretAccessKey']!, region: c['region']!, service: 's3', now: new Date(c['now']!),
      });
      assert.equal(s.headers['authorization'], c.expected['authorization'], `${c['method']} ${c['key']}`);
      assert.equal(s.headers['x-amz-date'], c.expected['x-amz-date']);
      assert.equal(s.headers['x-amz-content-sha256'], c.expected['x-amz-content-sha256']);
    }
  });

  it('encodes per RFC 3986, sorts the query, formats dates, and never puts host in the returned headers', () => {
    assert.equal(uriEncode("a b/c!*'()~._-"), 'a%20b%2Fc%21%2A%27%28%29~._-');
    assert.equal(amzDate(new Date(Date.UTC(2026, 9, 9, 2, 51, 7, 123))), '20261009T025107Z');
    const s = signV4({ ...AWS, method: 'GET', host: 'h.test', canonicalPath: '/b', query: [['b', '2'], ['a', 'x y'], ['a', '1']], headers: {}, payloadHash: EMPTY_SHA256 });
    assert.equal(s.canonicalRequest.split('\n')[2], 'a=1&a=x%20y&b=2');
    assert.ok(!('host' in s.headers));
    const t = signV4({ ...AWS, method: 'PUT', host: 'h.test', canonicalPath: '/b', headers: { 'X-Test': '  a   b\tc  ' }, payloadHash: EMPTY_SHA256 });
    assert.ok(t.canonicalRequest.includes('\nx-test:a b c\n'), 'header names are lower-cased and values trimmed with inner whitespace collapsed');
    assert.equal(t.headers['x-test'], '  a   b\tc  ', 'the value sent is the value given');
    assert.equal(EMPTY_SHA256, sha256Hex(''));
  });
});

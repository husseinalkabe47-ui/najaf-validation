// Phase 11.6.1: object keys. Path traversal and every other unsafe shape are refused before any I/O, without echoing the key.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { KEY_MAX_LENGTH, KEY_MAX_SEGMENTS, StorageError, assertSafeKey, isSafeKey } from '../../src/storage/index.ts';

const GOOD = ['a', 'car-images/2026/10/0f8fad5b-d9cb-469f-a165-70867728950e.webp', 'thumbs/x_1.webp', 'A9', 'a.b.c', 'v1/a-b_c.d', 'x'.repeat(128), Array.from({ length: KEY_MAX_SEGMENTS }, () => 'a').join('/')];
const BAD: unknown[] = [
  '', '/', '/a', 'a/', 'a//b', '.', '..', '../a', 'a/..', 'a/../b', './a', 'a/./b', '.hidden', 'a/.git/config', '-a', '_a',
  '..%2fetc', '%2e%2e/x', 'a%2Fb', 'a\\b', '..\\a', 'C:/x', 'c:', '~/x', 'a b', ' a', 'a\t', 'a\nb', 'a\u0000b', 'a\u202eb', 'ä', 'a/é', 'ﬁle',
  'a?b', 'a#b', 'a*b', 'a:b', 'a;b', 'a&b', 'a"b', "a'b", 'a<b', 'a|b', 'x'.repeat(129), Array.from({ length: KEY_MAX_SEGMENTS + 1 }, () => 'a').join('/'),
  `${'abcdefghij/'.repeat(46)}x`, undefined, null, 1, {}, ['a'], new String('a'),
];

describe('storage keys', () => {
  it('accepts server-generated keys of letters, digits, ".", "_", "-" in at most 8 segments', () => {
    for (const k of GOOD) assert.equal(isSafeKey(k), true, k);
    for (const k of GOOD) assert.equal(assertSafeKey(k), k);
  });

  it('refuses traversal, absolute paths, empty segments, hidden names, encodings, separators, control and non-ASCII characters', () => {
    for (const k of BAD) assert.equal(isSafeKey(k), false, JSON.stringify(k));
  });

  it('refuses keys over the total length limit even when every segment is valid', () => {
    const k = Array.from({ length: KEY_MAX_SEGMENTS }, () => 'y'.repeat(64)).join('/') + 'zz';
    assert.ok(k.length > KEY_MAX_LENGTH);
    assert.equal(isSafeKey(k), false);
    assert.equal(isSafeKey(k.slice(0, KEY_MAX_LENGTH).replace(/\/$/, 'y')), true);
  });

  it('assertSafeKey throws StorageError invalid_key with a fixed message that never contains the key', () => {
    for (const k of ['../../etc/passwd', 'SECRET-KEY-VALUE/..', 'a//SECRET']) {
      try {
        assertSafeKey(k);
        assert.fail('expected a rejection');
      } catch (e) {
        assert.ok(e instanceof StorageError);
        assert.equal(e.code, 'invalid_key');
        assert.equal(e.message, 'The object key is not allowed');
        assert.ok(!String(e.stack).includes('SECRET') && !e.message.includes('passwd'));
      }
    }
  });
});

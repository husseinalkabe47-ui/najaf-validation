// Phase 11.6.1: the R2 (S3-compatible) provider over a fake S3 endpoint that verifies every signature, plus a contract suite that
// runs unchanged against the R2 provider and the in-memory provider.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { StorageError, createMemoryStorage, createS3Storage } from '../../src/storage/index.ts';
import type { StorageProvider } from '../../src/storage/index.ts';
import { sha256Hex } from '../../src/storage/sigv4.ts';
import { makeFakeS3 } from '../helpers/fake-s3.ts';

const SECRET = 'q7Rk2vN9xT4bL8mZ3cW6yH1jP5sF0dGaE9uK2rQ7vX4nB8tM';
const AKID = 'f3a9c27d41b8e6a05c9d2e7b1a4f8c63';
const S3 = { endpoint: 'https://acct0123.r2.cloudflarestorage.test', region: 'auto', bucket: 'najaf-media', accessKeyId: AKID, secretAccessKey: SECRET };
const NOW = new Date(Date.UTC(2026, 9, 9, 0, 0, 0));
const bytes = (s: string) => new TextEncoder().encode(s);

function r2(opts: { keyPrefix?: string; maxObjectBytes?: number; timeoutMs?: number; secret?: string } = {}) {
  const fake = makeFakeS3({ host: 'acct0123.r2.cloudflarestorage.test', bucket: S3.bucket, region: S3.region, accessKeyId: AKID, secretAccessKey: SECRET });
  const storage = createS3Storage(
    { s3: { ...S3, secretAccessKey: opts.secret ?? SECRET }, keyPrefix: opts.keyPrefix ?? '', timeoutMs: opts.timeoutMs ?? 1000, maxObjectBytes: opts.maxObjectBytes ?? 1024 },
    { fetch: fake.fetch, now: () => NOW },
  );
  return { fake, storage };
}
const isErr = (code: string) => (e: unknown) => e instanceof StorageError && e.code === code;
const LEAKS = [SECRET, AKID, 'acct0123', 'najaf-media', 'cloudflarestorage', 'cars/SECRET-KEY', 'SignatureDoesNotMatch', 'InternalError', 'elsewhere'];
async function noLeak(p: Promise<unknown>, code: string) {
  try {
    await p;
    assert.fail('expected a StorageError');
  } catch (e) {
    assert.ok(e instanceof StorageError, String(e));
    assert.equal(e.code, code);
    const text = `${e.message} ${e.stack} ${JSON.stringify(e)} ${String((e as { cause?: unknown }).cause ?? '')}`;
    for (const s of LEAKS) assert.ok(!text.includes(s), `error leaks ${s}`);
  }
}

// ---- the same contract for every provider ----
const providers: Array<[string, (o?: { keyPrefix?: string; maxObjectBytes?: number }) => StorageProvider]> = [
  ['r2', (o) => r2(o).storage],
  ['memory', (o) => createMemoryStorage({ maxObjectBytes: 1024, ...o })],
];
for (const [name, make] of providers) {
  describe(`storage contract: ${name}`, () => {
    it('put -> exists -> get (same bytes, content type) -> delete -> missing; delete is idempotent', async () => {
      const s = make();
      assert.equal(await s.exists('cars/1/a.webp'), false);
      assert.equal(await s.get('cars/1/a.webp'), null);
      await s.put('cars/1/a.webp', bytes('hello'), { contentType: 'image/webp' });
      assert.equal(await s.exists('cars/1/a.webp'), true);
      const o = await s.get('cars/1/a.webp');
      assert.deepEqual([...o!.body], [...bytes('hello')]);
      assert.equal(o!.contentType, 'image/webp');
      assert.equal(o!.size, 5);
      await s.put('cars/1/a.webp', bytes('replaced'), { contentType: 'image/webp' });
      assert.equal(new TextDecoder().decode((await s.get('cars/1/a.webp'))!.body), 'replaced');
      await s.delete('cars/1/a.webp');
      await s.delete('cars/1/a.webp');
      assert.equal(await s.exists('cars/1/a.webp'), false);
      assert.equal(await s.get('cars/1/a.webp'), null);
    });

    it('stores a copy and returns a copy: later changes to either buffer do not change the object', async () => {
      const s = make();
      const b = bytes('abc');
      await s.put('k', b, { contentType: 'application/octet-stream' });
      b[0] = 0x7a;
      const first = (await s.get('k'))!.body;
      first[1] = 0x7a;
      assert.equal(new TextDecoder().decode((await s.get('k'))!.body), 'abc');
    });

    it('refuses every unsafe key on every operation, before any I/O', async () => {
      const s = make();
      for (const key of ['../x', '/x', 'a//b', 'a/../b', '.env', 'a\\b', '%2e%2e', '', 'a b', 'é']) {
        await assert.rejects(s.put(key, bytes('x'), { contentType: 'text/plain' }), isErr('invalid_key'), key);
        await assert.rejects(s.get(key), isErr('invalid_key'), key);
        await assert.rejects(s.exists(key), isErr('invalid_key'), key);
        await assert.rejects(s.delete(key), isErr('invalid_key'), key);
      }
    });

    it('refuses a bad content type, a non-byte body and a body above the size limit', async () => {
      const s = make({ maxObjectBytes: 8 });
      for (const t of ['', 'image', 'image/webp; charset=x', 'IMAGE/WEBP', 'image/web p', 'text/html\r\nx: y', ' image/webp', 'Ximage/webp', 'image/webp ', undefined]) {
        await assert.rejects(s.put('k', bytes('x'), { contentType: t as string }), isErr('invalid_content_type'), String(t));
      }
      await assert.rejects(s.put('k', 'text' as never, { contentType: 'text/plain' }), isErr('integrity'));
      await assert.rejects(s.put('k', new Uint8Array(9), { contentType: 'text/plain' }), isErr('too_large'));
      await s.put('k', new Uint8Array(8), { contentType: 'text/plain' });
      assert.equal(await s.exists('k'), true);
    });

    it('applies the configured key prefix and keeps keys apart from another prefix', async () => {
      const a = make({ keyPrefix: 'staging' });
      await a.put('x/y', bytes('1'), { contentType: 'text/plain' });
      assert.equal(await a.exists('x/y'), true);
      assert.throws(() => make({ keyPrefix: '../prod' }), isErr('invalid_key'));
    });
  });
}

// ---- R2 specifics ----
describe('r2 provider: what goes over the wire', () => {
  it('path-style URL <endpoint>/<bucket>/<prefix>/<key>, signed with the payload hash, redirects refused, with a timeout', async () => {
    const { fake, storage } = r2({ keyPrefix: 'staging' });
    await storage.put('cars/7/main.webp', bytes('img'), { contentType: 'image/webp' });
    const put = fake.seen[0]!;
    assert.equal(put.method, 'PUT');
    assert.equal(put.url, 'https://acct0123.r2.cloudflarestorage.test/najaf-media/staging/cars/7/main.webp');
    assert.equal(put.headers['x-amz-content-sha256'], sha256Hex(bytes('img')));
    assert.equal(put.headers['content-type'], 'image/webp');
    assert.equal(put.headers['x-amz-date'], '20261009T000000Z');
    assert.match(put.headers['authorization']!, /^AWS4-HMAC-SHA256 Credential=f3a9c27d41b8e6a05c9d2e7b1a4f8c63\/20261009\/auto\/s3\/aws4_request, SignedHeaders=content-type;host;x-amz-content-sha256;x-amz-date, Signature=[0-9a-f]{64}$/);
    assert.ok(!JSON.stringify(put.headers).includes(SECRET), 'the secret is never sent');
    assert.equal(put.redirect, 'error');
    assert.equal(put.hasSignal, true);
    assert.equal(put.bodyLength, 3);
    for (const r of fake.seen) assert.notEqual(r.headers['x-amz-content-sha256'], 'UNSIGNED-PAYLOAD');
  });

  it('a wrong secret is refused by the backend (403) and surfaces as unavailable, never as "missing"', async () => {
    const { storage } = r2({ secret: `${SECRET}x` });
    await noLeak(storage.put('k', bytes('x'), { contentType: 'text/plain' }), 'unavailable');
    await noLeak(storage.exists('k'), 'unavailable');
    await noLeak(storage.get('k'), 'unavailable');
    await noLeak(storage.delete('k'), 'unavailable');
  });

  it('maps backend failures to unavailable with the status only; no body, URL, key, bucket or credential leaks', async () => {
    const { fake, storage } = r2();
    fake.faults.status = 500;
    fake.faults.statusBody = '<Error><Code>InternalError</Code><Key>cars/SECRET-KEY</Key></Error>';
    for (const op of [() => storage.put('cars/SECRET-KEY', bytes('x'), { contentType: 'text/plain' }), () => storage.get('cars/SECRET-KEY'), () => storage.exists('cars/SECRET-KEY'), () => storage.delete('cars/SECRET-KEY')]) {
      await noLeak(op(), 'unavailable');
    }
    try {
      await storage.get('cars/SECRET-KEY');
    } catch (e) {
      assert.equal((e as StorageError).status, 500);
    }
    fake.faults.status = 403;
    await noLeak(storage.exists('k'), 'unavailable');
    fake.faults.status = 301;
    await noLeak(storage.get('k'), 'unavailable');
  });

  it('a network failure, a redirect and a timeout are unavailable, without the URL from the underlying error', async () => {
    const net = r2();
    net.fake.faults.network = true;
    await noLeak(net.storage.get('cars/SECRET-KEY'), 'unavailable');
    const red = r2();
    red.fake.faults.redirect = true;
    await noLeak(red.storage.get('cars/SECRET-KEY'), 'unavailable');
    const slow = r2({ timeoutMs: 50 });
    slow.fake.faults.hang = true;
    const t0 = Date.now();
    await noLeak(slow.storage.exists('cars/SECRET-KEY'), 'unavailable');
    assert.ok(Date.now() - t0 < 2000);
  });

  it('downloads are bounded: an announced or streamed size above the limit is refused; a lying length is an integrity error', async () => {
    const { fake, storage } = r2({ maxObjectBytes: 16 });
    await storage.put('k', new Uint8Array(10), { contentType: 'application/octet-stream' });
    fake.faults.contentLength = '999999';
    await noLeak(storage.get('k'), 'too_large');
    fake.faults.contentLength = 'abc';
    await noLeak(storage.get('k'), 'integrity');
    fake.faults.contentLength = '11';
    await noLeak(storage.get('k'), 'integrity');
    fake.faults.contentLength = null;
    fake.faults.streamExtra = 7; // 10 + 7 > 16, with no Content-Length
    await noLeak(storage.get('k'), 'too_large');
    fake.faults.streamExtra = 0;
    assert.equal((await storage.get('k'))!.size, 10);
  });

  it('an oversized or invalid upload never reaches the network', async () => {
    const { fake, storage } = r2({ maxObjectBytes: 4 });
    await assert.rejects(storage.put('k', new Uint8Array(5), { contentType: 'text/plain' }), isErr('too_large'));
    await assert.rejects(storage.put('../k', new Uint8Array(1), { contentType: 'text/plain' }), isErr('invalid_key'));
    await assert.rejects(storage.put('k', new Uint8Array(1), { contentType: 'text/plain\n' }), isErr('invalid_content_type'));
    assert.equal(fake.seen.length, 0);
  });

  it('a PUT is stored only on 200: any other answer (201, 204, 304, 400) is unavailable', async () => {
    const { fake, storage } = r2();
    for (const status of [201, 204, 304, 400]) {
      fake.faults.status = status;
      await noLeak(storage.put('k', bytes('x'), { contentType: 'text/plain' }), 'unavailable');
    }
  });

  it('DELETE of a missing object succeeds (204 and 404 both mean gone)', async () => {
    const { fake, storage } = r2();
    await storage.delete('never/existed');
    fake.faults.status = 404;
    await storage.delete('never/existed');
    fake.faults.status = 200;
    await storage.delete('x');
  });

  it('the bytes sent are a private copy taken before hashing', async () => {
    const { fake, storage } = r2();
    const b = bytes('stable');
    const p = storage.put('k', b, { contentType: 'text/plain' });
    b.fill(0);
    await p;
    assert.equal(new TextDecoder().decode(fake.objects.get('k')!.body), 'stable');
  });
});

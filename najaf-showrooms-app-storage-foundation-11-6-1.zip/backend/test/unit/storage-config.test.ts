// Phase 11.6.1: storage configuration. Strict validation, no built-in values, nothing secret in errors or redacted output.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { STORAGE_ENV_VARS, StorageConfigError, createStorage, createStorageFromEnv, loadStorageConfig, redactStorageConfig } from '../../src/storage/index.ts';

const SECRET = 'q7Rk2vN9xT4bL8mZ3cW6yH1jP5sF0dGaE9uK2rQ7vX4nB8tM';
const AKID = 'f3a9c27d41b8e6a05c9d2e7b1a4f8c63';
const R2 = {
  STORAGE_PROVIDER: 'r2',
  STORAGE_S3_ENDPOINT: 'https://0123456789abcdef0123456789abcdef.r2.cloudflarestorage.test',
  STORAGE_S3_REGION: 'auto',
  STORAGE_S3_BUCKET: 'najaf-media',
  STORAGE_S3_ACCESS_KEY_ID: AKID,
  STORAGE_S3_SECRET_ACCESS_KEY: SECRET,
};
function problemsOf(env: Record<string, string | undefined>): string[] {
  try {
    loadStorageConfig(env);
  } catch (e) {
    if (e instanceof StorageConfigError) return e.problems;
    throw e;
  }
  return [];
}
const has = (env: Record<string, string | undefined>, re: RegExp) => problemsOf(env).some((p) => re.test(p));

describe('storage configuration: r2', () => {
  it('accepts a complete r2 configuration, with defaults for the optional settings, and freezes it', () => {
    const c = loadStorageConfig(R2);
    assert.equal(c.provider, 'r2');
    assert.deepEqual({ ...c.s3 }, { endpoint: R2.STORAGE_S3_ENDPOINT, region: 'auto', bucket: 'najaf-media', accessKeyId: AKID, secretAccessKey: SECRET });
    assert.equal(c.keyPrefix, '');
    assert.equal(c.timeoutMs, 10_000);
    assert.equal(c.maxObjectBytes, 10 * 1024 * 1024);
    assert.ok(Object.isFrozen(c) && Object.isFrozen(c.s3));
    assert.equal(loadStorageConfig({ ...R2, STORAGE_S3_ENDPOINT: `${R2.STORAGE_S3_ENDPOINT}/` }).s3!.endpoint, R2.STORAGE_S3_ENDPOINT, 'a trailing slash is normalized away');
  });

  it('has NO built-in endpoint, region, bucket or credential: each one is required', () => {
    for (const v of ['STORAGE_S3_ENDPOINT', 'STORAGE_S3_REGION', 'STORAGE_S3_BUCKET', 'STORAGE_S3_ACCESS_KEY_ID', 'STORAGE_S3_SECRET_ACCESS_KEY']) {
      assert.ok(has({ ...R2, [v]: undefined }, new RegExp(`^${v} is required`)), v);
      assert.ok(has({ ...R2, [v]: '' }, new RegExp(`^${v} is required`)), v);
    }
    assert.ok(has({}, /STORAGE_PROVIDER is required/));
    assert.ok(has({ ...R2, STORAGE_PROVIDER: 's3' }, /STORAGE_PROVIDER is required and must be/));
    assert.ok(has({ ...R2, STORAGE_PROVIDER: 'R2' }, /STORAGE_PROVIDER is required and must be/));
  });

  it('the endpoint must be an https origin: no credentials, path, query or fragment; http only for loopback outside production', () => {
    const bad: Array<[string, RegExp]> = [
      ['http://abc.r2.cloudflarestorage.test', /must use https/],
      ['ftp://abc.test', /must use https/],
      ['https://user:pass@abc.test', /must not contain credentials/],
      ['https://abc.test/najaf-media', /origin only/],
      ['https://abc.test/?x=1', /origin only/],
      ['https://abc.test/#x', /origin only/],
      ['abc.test', /not a valid URL/],
      ['https://', /not a valid URL|no host/],
    ];
    for (const [endpoint, re] of bad) assert.ok(has({ ...R2, STORAGE_S3_ENDPOINT: endpoint }, re), endpoint);
    for (const local of ['http://localhost:9000', 'http://127.0.0.1:9000', 'http://[::1]:9000']) {
      assert.deepEqual(problemsOf({ ...R2, STORAGE_S3_ENDPOINT: local }), [], local);
      assert.ok(has({ ...R2, STORAGE_S3_ENDPOINT: local, NODE_ENV: 'production' }, /must use https/), `${local} in production`);
    }
    assert.ok(has({ ...R2, STORAGE_S3_ENDPOINT: 'http://localhost.evil.test:9000' }, /must use https/));
  });

  it('validates region, bucket, access key id and secret', () => {
    for (const region of ['Auto', 'us east', 'a'.repeat(33), '-x']) assert.ok(has({ ...R2, STORAGE_S3_REGION: region }, /STORAGE_S3_REGION/), region);
    for (const bucket of ['ab', 'Najaf', 'najaf.media', '-najaf', 'najaf-', 'a'.repeat(64), 'najaf_media', 'najaf/media', '../x']) assert.ok(has({ ...R2, STORAGE_S3_BUCKET: bucket }, /STORAGE_S3_BUCKET/), bucket);
    for (const akid of ['short', 'has space 1234567890', 'x'.repeat(129), 'abc-def-ghi-jkl-mno']) assert.ok(has({ ...R2, STORAGE_S3_ACCESS_KEY_ID: akid }, /STORAGE_S3_ACCESS_KEY_ID/), akid);
    assert.ok(has({ ...R2, STORAGE_S3_SECRET_ACCESS_KEY: 'k9XvQ2mLp8Rt3Zw7Yb5Nc1Hd6Jf4Gs' }, /32-256 characters/));
    assert.ok(has({ ...R2, STORAGE_S3_SECRET_ACCESS_KEY: `${SECRET} x` }, /printable ASCII without whitespace/));
    assert.ok(has({ ...R2, STORAGE_S3_SECRET_ACCESS_KEY: `change-me-${SECRET}` }, /placeholder/));
    assert.ok(has({ ...R2, STORAGE_S3_SECRET_ACCESS_KEY: `${'a1'.repeat(16)}`, STORAGE_S3_ACCESS_KEY_ID: `${'a1'.repeat(16)}` }, /must differ/));
  });

  it('no problem message ever contains the secret, the access key id, the endpoint or the bucket', () => {
    const leaky = { ...R2, STORAGE_S3_ENDPOINT: 'https://user:pw-LEAK-1@acct-LEAK-2.test/bucket-LEAK-3', STORAGE_S3_SECRET_ACCESS_KEY: 'placeholder LEAK-4 with spaces and more chars', STORAGE_S3_ACCESS_KEY_ID: 'LEAK-5!', STORAGE_S3_BUCKET: 'LEAK_6' };
    try {
      loadStorageConfig(leaky);
      assert.fail('expected an error');
    } catch (e) {
      assert.ok(e instanceof StorageConfigError);
      assert.ok(e.problems.length >= 4);
      assert.ok(!/LEAK|pw-|acct-/.test(e.message), e.message);
    }
    const r = JSON.stringify(redactStorageConfig(loadStorageConfig(R2)));
    for (const s of [SECRET, AKID, 'najaf-media', '0123456789abcdef', 'cloudflarestorage']) assert.ok(!r.includes(s), s);
    assert.match(r, /"region":"auto"/);
  });
});

describe('storage configuration: memory, prefix and limits', () => {
  it('memory is for tests and development only, and takes no S3 setting', () => {
    assert.equal(loadStorageConfig({ STORAGE_PROVIDER: 'memory' }).s3, null);
    assert.ok(has({ STORAGE_PROVIDER: 'memory', NODE_ENV: 'production' }, /not allowed in production/));
    assert.ok(has({ STORAGE_PROVIDER: 'memory', STORAGE_S3_BUCKET: 'najaf-media' }, /STORAGE_S3_BUCKET must not be set/));
    assert.equal(createStorageFromEnv({ STORAGE_PROVIDER: 'memory' }).kind, 'memory');
    assert.equal(createStorageFromEnv(R2).kind, 'r2');
  });

  it('the key prefix follows the key rules; timeout and size limits are bounded whole numbers', () => {
    assert.equal(loadStorageConfig({ ...R2, STORAGE_KEY_PREFIX: 'staging/v1' }).keyPrefix, 'staging/v1');
    for (const p of ['../x', '/x', 'x/', 'a b', '.x']) assert.ok(has({ ...R2, STORAGE_KEY_PREFIX: p }, /STORAGE_KEY_PREFIX/), p);
    assert.equal(loadStorageConfig({ ...R2, STORAGE_TIMEOUT_MS: '2500', STORAGE_MAX_OBJECT_BYTES: '1024' }).timeoutMs, 2500);
    for (const t of ['999', '60001', '1e4', '-1', '10s', ' 1000']) assert.ok(has({ ...R2, STORAGE_TIMEOUT_MS: t }, /STORAGE_TIMEOUT_MS/), t);
    for (const b of ['0', '104857601', '1.5', 'big']) assert.ok(has({ ...R2, STORAGE_MAX_OBJECT_BYTES: b }, /STORAGE_MAX_OBJECT_BYTES/), b);
    assert.equal(loadStorageConfig({ ...R2, STORAGE_MAX_OBJECT_BYTES: '104857600' }).maxObjectBytes, 104857600);
  });

  it('createStorage refuses an r2 configuration without S3 settings', () => {
    assert.throws(() => createStorage({ provider: 'r2', s3: null, keyPrefix: '', timeoutMs: 1000, maxObjectBytes: 1 }));
  });
});

describe('.env.storage.example documents the storage configuration exactly', () => {
  const example = readFileSync(join(import.meta.dirname, '..', '..', '.env.storage.example'), 'utf8');
  const documented = new Set([...example.matchAll(/^#?\s*([A-Z][A-Z0-9_]*)=/gm)].map((m) => m[1] as string));

  it('every variable the code reads is documented, and nothing else is listed', () => {
    for (const v of STORAGE_ENV_VARS) assert.ok(documented.has(v), `${v} is not documented`);
    for (const v of documented) assert.ok((STORAGE_ENV_VARS as readonly string[]).includes(v), `${v} is listed but not read`);
  });

  it('ships no credential, bucket or endpoint, and the example as shipped is NOT a valid configuration', () => {
    for (const m of example.matchAll(/^#?\s*(STORAGE_S3_[A-Z_]+|STORAGE_PROVIDER)=(.*)$/gm)) assert.equal((m[2] as string).trim(), '', `${m[1]} must be empty`);
    assert.ok(!/r2\.cloudflarestorage\.com|amazonaws\.com|https?:\/\//.test(example));
    const env: Record<string, string> = {};
    for (const m of example.matchAll(/^([A-Z][A-Z0-9_]*)=(.*)$/gm)) env[m[1] as string] = (m[2] as string).trim();
    assert.ok(problemsOf(env).length > 0);
  });
});

# Backend — أساس المرحلة 11.4.1

**الحالة بصراحة:** هذا الأساس **غير متصل بالواجهة** ولا يضيف أي ميزة للمستخدم. يحوي فقط: إعدادات البيئة، طبقة اتصال آمنة بـPostgreSQL 16، فحص الدور والمخطط عند الإقلاع، ونقطتَي صحة (`/healthz` و`/readyz`). الواجهة (التطبيق الحالي) ما زالت تعمل على `localStorage` كما كانت، ولم يُعدَّل فيها ملف.

## البنية
```
backend/
├── src/
│   ├── config.ts          إعدادات البيئة: تحقق كامل، لا كلمة مرور في الأخطاء أو السجلات
│   ├── errors.ts          تصنيف أخطاء المشغّل (SQLSTATE/شبكة) إلى DbError آمن (بلا SQL ولا قيم)
│   ├── http-errors.ts     تحويل الأخطاء إلى ردود HTTP عامة (409/422/403/503/500)
│   ├── role.ts            فحص أن الاتصال بدور أدنى امتيازًا (ليس superuser، عضو في najaf_app)
│   ├── schema-contract.ts العقد مع المخطط المُختبَر: 16 جدولًا + viewان (يُقارَن آليًا بالترحيلات)
│   ├── db.ts              Pool + query + tx (BEGIN/COMMIT/ROLLBACK مضمونة) + ping/verifyRole/checkSchema
│   ├── health.ts          liveness بلا قاعدة، readiness (اتصال + عقد المخطط) بلا تفاصيل للعميل
│   ├── server.ts          Fastify رفيع: /healthz و/readyz و404/خطأ عامّان، request-id، no-store
│   ├── index.ts           نقطة الدخول: config → db → سياسة الدور → خادم → إيقاف نظيف
│   └── types.ts           واجهة Logger (متوافقة مع pino)
├── scripts/db-check.ts    أداة تشغيل: تفحص الاتصال والدور والمخطط وتطبع JSON بلا أسرار
├── ops/create_app_login.sql  ينشئ دور الدخول الأدنى امتيازًا (كلمة المرور تُمرَّر -v ولا تُكتب في الملف)
├── test/unit/             اختبارات بلا قاعدة بيانات (تعمل في أي بيئة)
├── test/integration/      اختبارات على PostgreSQL حقيقي (تُتخطّى بوضوح بلا DATABASE_URL)
└── .env.example           كل متغيرات البيئة موثَّقة (اختبار آلي يمنع اختلافها عن الكود)
```
**القاعدة الحاكمة:** كل المنطق في وحدات **بلا اعتماديات** (تُختبر محليًا بالكامل)؛ و`pg` وFastify لا يظهران إلا في `db.ts` (استيراد كسول عبر factory) و`server.ts`.

## نموذج الأمان (ما اعتُمد)
- **لا اتصال بمشرف.** يتصل الـBackend بدور دخول (`najaf_app_login`) **عضو** في `najaf_app` (من الترحيل 0012) فيرث الامتيازات المُختبَرة فقط: بلا DDL ولا TRUNCATE، بلا DELETE على `users` و`showrooms` و`audit_logs` و`exchange_rates`، بلا تعديل `users.role`، وبعد 0013 بلا تعديل أعمدة الملكية والأوقات و`version`.
- **سياسة تُفرض عند الإقلاع** (`DB_REQUIRE_APP_ROLE=true`، ولا يُسمح بتعطيلها في الإنتاج): ترفض العملية الدور إن كان superuser أو يستطيع إنشاء أدوار/قواعد أو له replication/bypassrls أو ليس عضوًا في `najaf_app`، وترفض كذلك اسم المستخدم `postgres` في الإعداد. رمز الخروج 78.
- **TLS:** الافتراضي `verify-full` في الإنتاج، و`disable` مرفوض فيه؛ أنماط libpq التي تُضعف الأمان بصمت (`prefer`/`allow`/`verify-ca`) مرفوضة.
- **استعلامات مُعلَّمة فقط** (القيم لا تُدمج في SQL أبدًا)، و`checkSchema` يمرّر أسماء الكائنات معلَّمة كذلك.
- **مهلات من أول جملة:** `statement_timeout` و`lock_timeout` و`idle_in_transaction_session_timeout` كمعاملات بدء الاتصال (يتحقق منها اختبار التكامل بقراءة `current_setting`).
- **أخطاء بلا تسريب:** `DbError` يحمل النوع والـSQLSTATE واسم القيد فقط؛ رسالة المشغّل الأصلية للسجل الداخلي وحده؛ ردود HTTP عامة (لا SQL ولا أسماء قيود ولا تتبّع مكدّس).
- **المعاملات:** الاتصال يُحرَّر مرة واحدة دائمًا؛ فشل `ROLLBACK` يُتلف الاتصال بدل إعادة استعماله؛ استعلام المعاملة بعد انتهائها مرفوض.
- **readiness** لا يكشف شيئًا للعميل سوى حالات خشنة (`ok/fail/skipped`)؛ التفاصيل في السجل.

## البيئة (`.env.example`)
`DATABASE_URL` (أو `PGHOST`/`PGPORT`/`PGDATABASE`/`PGUSER`/`PGPASSWORD`)، `DB_SSL` و`DB_SSL_CA`، `DB_POOL_MAX` (10)، `DB_STATEMENT_TIMEOUT_MS` (15000)، `DB_LOCK_TIMEOUT_MS` (5000)، `DB_IDLE_IN_TX_TIMEOUT_MS` (15000)، `DB_CONNECT_TIMEOUT_MS` (5000)، `DB_IDLE_TIMEOUT_MS` (30000)، `DB_APPLICATION_NAME`، `DB_REQUIRE_APP_ROLE`، و`NODE_ENV` و`HOST` و`PORT` و`LOG_LEVEL`. القيم الخاطئة تُجمَع في خطأ واحد واضح، ولا يظهر فيه كلمة المرور أبدًا. لا ملف `.env` في المستودع (`.gitignore`).

## التشغيل
```bash
# 1) قاعدة PostgreSQL 16 بالترحيلات المُختبَرة
for f in ../database/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -1 -d najaf -f "$f"; done
# 2) دور الاتصال (مرة واحدة)
psql -v ON_ERROR_STOP=1 -d najaf -v login=najaf_app_login -v pw="$NAJAF_APP_PASSWORD" -f ops/create_app_login.sql
# 3) الاعتماديات والإعداد
npm install && cp .env.example .env     # عدّل DATABASE_URL
npm run db:check                         # يفحص الاتصال والدور والمخطط
npm run dev                              # خادم Node ≥ 22.18 يشغّل TypeScript مباشرة (بلا خطوة بناء)
```
`GET /healthz` ← `{"status":"ok"}`؛ `GET /readyz` ← 200 `{"status":"ready",...}` أو 503 `not_ready`.

## الاختبارات
| الأمر | ماذا يشغّل | يحتاج |
| --- | --- | --- |
| `npm test` | **117 اختبار وحدة** تعمل بلا أي اعتمادية: الإعدادات (27)، تصنيف الأخطاء وردود HTTP (44)، طبقة الاتصال بـpool مزيّف: خيارات `pg`، معاملات، تنظيف الاتصال، أخطاء (22)، سياسة الدور (8)، الصحة (7)، العقد مع الترحيلات (5)، توافق `.env.example` (4). ثم **7 اختبارات خادم HTTP** (Fastify `inject`) | Node ≥ 22.18. اختبارات الخادم تحتاج `npm install` وإلا تُتخطّى بوضوح كمجموعة |
| `npm run test:integration` | **58 اختبار تكامل** على PostgreSQL حقيقي: اتصال ودور ومهلات فعلية وكلمة مرور خاطئة وخادم غير متاح وحدّ الـpool وcommit/rollback وعدم تسريب الاتصالات (17)، **امتيازات الدور** (23 عملية ممنوعة و12 مسموحة + إضافة التدقيق + منع إنشاء مدير + 3 معارض/115 سيارة) (38)، وردود الصحة عبر HTTP (3) | `DATABASE_URL` (دور التطبيق) و`ADMIN_DATABASE_URL` (superuser للتجهيز فقط) |
| `npm run typecheck` | `tsc --noEmit` صارم (`erasableSyntaxOnly`) | `npm install` |

CI: `.github/workflows/backend.yml` (تشغيل يدوي) يطبّق الترحيلات المُختبَرة ويشغّل الثلاثة معًا + انحدار الواجهة (33 ملفًا) على PostgreSQL 16.

## التراجع (المرحلة قابلة للإزالة بالكامل)
هذه المرحلة **إضافية بحتة**: احذف `backend/` و`.github/workflows/backend.yml` وفقرة 11.4.1 من `README.md` الجذر، فيعود المشروع كما كان في 11p3 بلا أي أثر. لا ملف في الواجهة أو الخدمات أو المستودعات أو `database/` تغيّر.

## قرارات معمارية معلَّقة (لم تُنفَّذ عمدًا؛ تحتاج موافقتك قبل 11.4.2)
1. **TypeScript بلا بناء:** يُنفَّذ مباشرة بـNode ≥ 22.18 (type stripping) وتُفحَص أنواعه بـ`tsc` في CI. بديله: خطوة بناء (esbuild/tsc) — أُبقي المشروع بلا بناء اتساقًا مع قاعدته.
2. **Drizzle ORM** (المذكور في وثيقة 11.1) **مؤجَّل**: المخطط يعتمد مشغّلات وviews وصلاحيات أعمدة ومهاجرات SQL مكتوبة يدويًا واجتازت التحقق؛ فالمقترح SQL مُعلَّم مباشرة بـ`pg`، مع إعادة النظر عند نقل أول مستودع.
3. **Zod** مؤجَّل لحين وجود أول مسار يستقبل مدخلات.
4. **لا مشغّل ترحيلات في الباكند:** الترحيلات SQL تُطبَّق بـ`psql`؛ جدول تتبّع داخل المخطط سيغيّر ما اجتاز التحقق. خيارات 11.4.2: أداة خارجية (dbmate/graphile-migrate) أو مشغّل بمخطط `ops` منفصل.
5. **ملف قفل الحزم غير موجود:** بيئتي لا تثبّت حزم npm؛ يُنشأ `package-lock.json` من أول تشغيل ناجح في CI ويُلتزم به.

## خريطة الخدمات الحالية → وحدات الباكند القادمة (تصميم، غير منفَّذ)
| الواجهة الآن | وحدة الباكند | الجداول |
| --- | --- | --- |
| AuthService/SessionService/UserService | auth | users, sessions, verification_codes, message_deliveries |
| SearchService/VisibilityService/CarFilterService | catalog (قراءة عامة) | views: public_cars, public_showrooms |
| MemberCarsService/ShowroomCarsService/ShowroomService/FavoritesService | owners | cars, showrooms, favorites |
| CarImagesService/ImageService/ImageStore (IndexedDB) | uploads | assets, car_images + تخزين كائنات |
| AdminService | moderation | users, showrooms, cars, audit_logs |
| RewardService | rewards | reward_grants |
| FormatService (TEXT_LIMITS) وسعر الصرف | settings | app_settings, exchange_rates |
| AuthorizationService | سياسة `can(actor, action, resource)` واحدة | — |
| MigrationService (مخطط localStorage) | لا مقابل (تحلّ محلّه ترحيلات SQL) | — |

ربط الواجهة بالباكند (علم `DATA_SOURCE=local|api` ومستودعات بعيدة بالواجهة نفسها) في مرحلة لاحقة؛ الواجهة هنا لم تُلمَس.

## Migration Runner (دمج أداة الترحيلات)

أُدمجت **node-pg-migrate 9.0.0** (نسخة مثبَّتة بلا `^`) بعد أن نجح تقييمها المنفصل على PostgreSQL 16 (29 نجاحًا، 0 فشل، 3 معلومات). **لم يُعدَّل أي ملف في `database/migrations` (0001–0013)، ولم يتغير مخطط PostgreSQL.**

- **المصدر الوحيد للـSQL:** `database/migrations` (مجمَّد وبصماته في `database/CHECKSUMS.sha256`). الأداة لا تكتب فيه.
- **التغليف:** `db/migrations/NNNN_name.js` (13 ملف CommonJS) يقرأ ملف SQL الأصلي حرفيًا. و**`db/down/NNNN_name.down.sql`** (13) هي ملفات التراجع. التفاصيل في `db/README.md`.
- **التتبع:** `ops.pgmigrations` (لا شيء في `public`).
- **حساب منفصل:** `MIGRATION_DATABASE_URL` يشير إلى `najaf_migrator` (مالك قاعدة البيانات، `CREATEROLE`، ليس superuser، ولا يرث صلاحيات `najaf_app` ولا يستطيع `SET ROLE` إليه). يُنشأ بـ`ops/create_migration_role.sql`. الإعداد يرفض `najaf_app` و`najaf_app_login` و`najaf_report`، ويرفض الحساب نفسه المستعمل في `DATABASE_URL`، وفحص الدور قبل أي تشغيل يرفض أي حساب **يرث صلاحيات `najaf_app` أو يستطيع `SET ROLE` إليه** (هوية تطبيق). أما العضوية الإدارية `ADMIN OPTION` التي يمنحها PostgreSQL 16 تلقائيًا لمنشئ الدور فمقبولة لأنها لا تمنح صلاحياته ولا التحويل إليه.
- **المتغيرات:** `.env.migrations.example` (اختبار آلي يمنع اختلافها عن الكود).

```bash
npm run db:migrate                       # تطبيق كل الترحيلات المعلّقة
npm run db:migrate:status                # applied / pending / unknown
npm run db:rollback -- --steps 1         # تراجع آخر ترحيلة (لا عدد افتراضيًا)
npm run db:rollback -- --all             # تراجع كل شيء (تُحذف الجداول؛ الأدوار تبقى)
```
قواعد أمان: `down` بلا `--steps`/`--all` مرفوض؛ وفي الإنتاج مرفوض ما لم يُضبط `MIGRATION_ALLOW_ROLLBACK=true`؛ ولا تظهر كلمة المرور في أي مخرج.

**الاختبارات:** 60 اختبار وحدة (إعدادات الـRunner، الـRunner بـ`runner` مزيّف، فحص الدور، الحالة، وأصول الترحيل) + 9 اختبارات تكامل على PostgreSQL حقيقي (`test/integration/migrate.integration.test.ts`، تحتاج قاعدة **فارغة** واسمها فيه test أو mig أو ci لأنها تتراجع عن كل شيء) + `.github/workflows/migrations.yml` (تشغيل يدوي): يطبّق ويتراجع ويقارن `pg_dump` بمرجع `psql -1`.

**التراجع عن هذه الخطوة بالكامل** (إضافية بحتة، لا شيء قديم حُذف أو استُبدل): احذف `backend/src/migrate/` و`backend/scripts/migrate.ts` و`backend/db/` و`backend/ops/create_migration_role.sql` و`backend/.env.migrations.example` و`backend/test/**/migrate*` و`.github/workflows/migrations.yml` وهذا القسم، وأزل من `backend/package.json` ثلاثة أوامر `db:migrate*`/`db:rollback` وسطر `"node-pg-migrate": "9.0.0"`.

## المصادقة والحسابات (Phase 11.4): الخطوات 1 إلى 4

تسجيل مستخدم، والتحقق من بيانات الدخول، **رمز وصول 15 دقيقة**، **رمز تحديث دوّار مع كشف إعادة الاستعمال**، وحدّ معدّل، و**تحقق الهاتف واسترداد كلمة المرور برمز لمرة واحدة**. **لا ربط بالواجهة بعد**، ولا تسليم فعلي للرموز (انظر أدناه)، ولا تفويض (11.5). **لم يتغير مخطط PostgreSQL ولا أي ترحيلة** (يكفي `sessions` و`verification_codes`: الغرض والمستخدم والهاتف والتجزئة والمحاولات والانتهاء والاستهلاك والفهرس الفريد «رمز نشط واحد»).

| المسار | الطلب | النجاح | الفشل |
| --- | --- | --- | --- |
| `POST /v1/auth/register` | `{name, phone, password}` | 201 `{user, session}` | 400 تحقق، 409 تعذّر التسجيل، 429 |
| `POST /v1/auth/login` | `{phone, password}` | 200 `{user, session}` | 400، 401 `invalid_credentials`، 429 |
| `POST /v1/auth/refresh` | `{refreshToken}` | 200 `{user, session}` (جديدان كلاهما) | 400، 401 `unauthorized`، 429 |
| `GET /v1/auth/me` | `Authorization: Bearer <accessToken>` | 200 `{user}` | 401 `unauthorized` |
| `POST /v1/auth/logout` | `{refreshToken}` | 204 | 400، 429 |
| `POST /v1/auth/phone/verify/request` | `Bearer` (بلا جسم) | 202 `{status:'sent'}` أو 200 `{status:'already_verified'}` | 401، 429 |
| `POST /v1/auth/phone/verify/confirm` | `Bearer` + `{code}` | 200 `{user}` | 400 `invalid_code`، 401، 429 |
| `POST /v1/auth/password/forgot` | `{phone}` | 202 `{status:'accepted'}` **دائمًا** | 400 (مدخل معطوب)، 429 |
| `POST /v1/auth/password/reset` | `{phone, code, newPassword}` | 200 `{status:'password_reset'}` | 400 `invalid_code` أو تحقق، 429 |
| `POST /v1/auth/password/change` | `Bearer` + `{currentPassword, newPassword}` | 200 `{status:'password_changed'}` | 400 `invalid_current_password` أو تحقق، 401، 429 |
| `POST /v1/auth/logout/all` | `Bearer` (بلا جسم) | 204 | 401، 429 |

`session = {accessToken, accessExpiresAt, refreshToken, refreshExpiresAt}`، ويُعرض كل رمز **مرة واحدة**. المستخدم العام `{id, name, phone, role, status, createdAt}` يُبنى حقلًا حقلًا (لا كلمة مرور ولا تجزئة)، و`phone` بصيغة E.164.

**الرمزان**
- **رمز الوصول:** HS256 (على `node:crypto`، بلا تبعية)، 15 دقيقة، يحمل `sub` و`sid` فقط. **الدور والحالة لا تُقرأ منه أبدًا**: تُعاد قراءة الجلسة والمستخدم من القاعدة عند كل طلب، فيموت الرمز **فورًا** عند الخروج أو الإيقاف أو كشف إعادة الاستعمال أو تغيير كلمة المرور (مشغّلات القاعدة)، لا بعد 15 دقيقة. التحقق صارم: ترويسة ثابتة، توقيع بزمن ثابت، مطالبات محددة بالضبط، عمر لا يتجاوز السياسة.
- **رمز التحديث:** عشوائي 256 بت (`nsj_…`)، **SHA-256 فقط** في `sessions.token_hash`، **30 يومًا مطلقة** من الدخول (التدوير لا يمدّها). لا يُقبل رمز تحديث كرمز وصول، ولا العكس.
- **التدوير:** كل `/refresh` يُصدر زوجًا جديدًا في المعاملة نفسها (قفل الصف `FOR UPDATE`): يُلغى الصف القديم بسبب `rotated` مع `replaced_by`، ويُدرج جديد بنفس `family_id` ونفس الانتهاء.
- **كشف إعادة الاستعمال:** عرض رمز دُوِّر سابقًا يُلغي **كل** جلسة الدخول (`reuse_detected`) ويُثبَّت الإلغاء، ولا يُصدر شيئًا. وهو **صارم عمدًا**: طلبان متزامنان بالرمز نفسه يُنهيان الجلسة (فعلى العميل ألا يجدّد بالتوازي). الجلسات الأخرى للمستخدم لا تتأثر.
- **الخروج:** بـ`refreshToken` (يعمل ولو انتهى رمز الوصول)، ويُنهي جلسة الدخول كلها. وهو متساوي الأثر بأي رمز من السلسلة، ولا يُعدّ إعادة استعمال.
- **كل إخفاق تجديد** (مجهول، منتهٍ، مُلغى، مُعاد استعماله، حساب موقوف أو محذوف) هو **الخطأ نفسه** `unauthorized`.

**الإعداد** (وحدة منفصلة `src/auth/config.ts`، ومثال `.env.auth.example`)
- `AUTH_ACCESS_TOKEN_SECRET` **مطلوب** (32 حرفًا فأكثر، عشوائي: `openssl rand -base64 48`)، ويُرفض الفارغ والقصير وقليل التنوع والنماذج (`change-me`…). لا يُسجَّل ولا يُكرَّر في أي خطأ. **بدونه لا يبدأ الخادم** (`npm start` يخرج برمز 78).
- `AUTH_TRUSTED_PROXIES` اختياري: عناوين/CIDR للوكلاء الذين يُوثَق بـ`X-Forwarded-For` منهم (Cloudflare/موازن الحمل). الافتراضي **لا أحد**، و«الثقة بالجميع» (`/0` و`*` و`true`) **مرفوضة**. بدونه خلف وكيل تظهر كل الطلبات من عنوان الوكيل.
- تدوير السر يُبطل رموز الوصول فقط (رموز التحديث تعمل وتُصدر رموز وصول جديدة).

**حدّ المعدّل** (`src/auth/rate-limit.ts`): لكل عنوان عميل ولكل مسار، نوافذ ثابتة **في ذاكرة العملية** (بلا جدول ولا ترحيلة): `register` 5/ساعة، `login` 10/5 دقائق، `refresh` 60/10 دقائق، `logout` 30/5 دقائق. يُجاب 429 مع `Retry-After` **قبل قراءة الجسم**. الذاكرة محدودة (50 ألف مفتاح). **القيود:** الحدّ لكل نسخة تشغيل (عند عدة نسخ يتضاعف السقف)، ويضاف إلى قفل الحساب (5 إخفاقات/15 دقيقة) لا يحلّ محله.

**سائر الضمانات (الخطوة 1):**
- argon2id (`m=19456,t=2,p=1`)، ولا كلمة مرور تُسجَّل أو تُرجَع.
- فشل الدخول بكل أسبابه خطأ واحد، وتحقق argon2 واحد في كل مسار (لا فرق توقيت).
- الدور والحالة ليسا مدخلين (حقل `role` يُرفض).
- `register` و`login` و`refresh` و`logout` تقبل `application/json` فقط (415 قبل قراءة الجسم)، وحدّ الجسم 4 KiB.
- استعلامات SQL مُعلَّمة فقط، والوقت من ساعة القاعدة (انتهاء الجلسة) وساعة التطبيق (انتهاء رمز الوصول).

**الرموز لمرة واحدة (الخطوة 3)**
- **التوليد والتخزين:** رمز من 6 أرقام بـCSPRNG (`crypto.randomInt`)، ولا يُخزَّن إلا **HMAC-SHA256** بمفتاح مشتق من سر الخادم (التجزئة العادية عديمة الفائدة: 10^6 احتمال فقط)، **مرتبط بالغرض والمستخدم والهاتف** (لا يصلح رمز لغرض أو مستخدم أو رقم آخر). لا يُسجَّل ولا يُرجَع ولا يظهر في خطأ.
- **القيود:** صلاحية 10 دقائق، 5 محاولات للرمز (بعدها يُرفض حتى الصحيح)، مهلة 60 ثانية بين رمزين، 3 في الساعة و10 في اليوم لكل (مستخدم، غرض). رمز نشط واحد لكل (مستخدم، غرض): الجديد يُبطل القديم. تساوي القيم `app_settings` المبذورة `otp.policy` (ملاحظتها: «مقترح، يحتاج موافقة»)، والشيفرة **لا تقرؤها بعد**.
- **الاستعمال مرة واحدة:** يُستهلك الرمز في المعاملة نفسها التي تنفّذ أثره، تحت قفل الصف. محاولة فاشلة **تُثبَّت** (تُعاد النتيجة من المعاملة لا تُرمى منها). الطلبات المتزامنة: قفل استشاري لكل (مستخدم، غرض) يمنع تجاوز حدود الإرسال بالتزامن.
- **خطأ واحد** `invalid_code` لكل فشل: خاطئ، منتهٍ، مستعمل، مستنفد، غرض آخر، مستخدم آخر، حساب مجهول.
- **تحقق الهاتف:** التسجيل **لا** يوثّق الهاتف. الطلب يخص هاتف صاحب الرمز فقط (المعرّف من رمز الوصول لا من الطلب). عند النجاح يُضبط `phone_verified_at` ويُستهلك الرمز معًا. المستخدم الموثَّق: الطلب لا يرسل شيئًا، والتأكيد نجاح بلا أثر ولا يستبدل وقت التوثيق. `phoneVerified` ظاهر في `user` (register/login/refresh/me).
- **الاسترداد:** `forgot` يجيب **بالجواب نفسه** لحساب موجود أو غير موجود أو موقوف أو مخنوق. `reset` يتحقق من سياسة كلمة المرور **قبل** النظر في الرمز (كلمة ضعيفة لا تحرق محاولة)، ويجزّئ كلمة المرور **بعد** التحقق من الرمز (فلا يُستنزف المعالج بتخمينات)، ثم في معاملة واحدة: كلمة مرور جديدة بـargon2id، وفك قفل الدخول، و**إبطال كل جلسات المستخدم فورًا** (رموز الوصول والتحديث). الاستعمال الثاني للرمز مرفوض (لا إعادة تشغيل).
- **التسليم:** عبر واجهة `MessagingProvider` (`src/messaging/provider.ts`) **بعد الالتزام وبلا انتظار** (فلا يتأثر زمن الاستجابة بالمزوّد)، وفشله يُسجَّل بلا أي سر ولا يغيّر الجواب. **لا مزوّد SMS/WhatsApp مدمج بعد**: `npm start` يركّب مزوّدًا يرفض كل إرسال ويسجّل تحذيرًا عند الإقلاع، فالتدفقات تعمل من طرف إلى طرف لكن **لا شيء يصل إلى الهاتف**. لا مفتاح بيئة جديد (مفتاح التجزئة مشتق من `AUTH_ACCESS_TOKEN_SECRET`، وتدويره يُبطل الرموز المعلّقة فقط، 10 دقائق).
- **مخاطر معروفة:** تسجيل رقم غيرك قبله (بلا OTP عند التسجيل) ما زال ممكنًا، لكن صاحب الرقم يستردّ الحساب بـ`forgot`؛ وزمن استجابة `forgot` قد يختلف ميلي ثوانٍ بين الموجود والمجهول (إدراج واحد، والإرسال غير منتظَر، والحد لكل عنوان يقيّد الاستكشاف). تخمين رمز: أقصى 15 محاولة/ساعة من 10^6.

**أمان الحساب والجلسات (الخطوة 4)** — يحتاج المساران `Bearer <accessToken>`، **والمعرّف دائمًا من الرمز المُتحقَّق منه** (المدخلات تُرفض إن حملت `userId`، ولا يُقرأ معرّف من الجسم أو المعاملات أو الاستعلام).
- **تغيير كلمة المرور:** يتطلب الحالية؛ وكلمة المرور الجديدة بالسياسة نفسها (تُفحص **قبل** أي شيء، فلا تكلّف محاولة)؛ ولا يجوز أن تساوي الحالية (`same_as_current`، ولا تُذكر إلا لمن أثبت الحالية). المحاولات الخاطئة **تُحسب كالدخول الفاشل** (القفل نفسه: 5 ثم 15 دقيقة، وأثناء القفل لا تُفحص الحالية أصلًا)، فلا يخمّن رمز وصول مسروق كلمة المرور. التبديل **بشرط المقارنة** على التجزئة القديمة، فمن تغييرين متزامنين يُطبَّق واحد.
- **الجلسات عند تغيير كلمة المرور (قرار موثَّق):** تنتهي **كل** الجلسات **بما فيها الحالية**، فيدخل المستخدم من جديد بكلمته الجديدة. السبب: هذا نموذج المشروع القائم أصلًا (مشغّل `users_revoke_sessions` يلغي كل الجلسات عند تغيّر `password_hash`، والاسترداد كذلك)، ولا نصدر رموزًا داخل عملية تغيير كلمة المرور، ومن يحمل أي جلسة (ولو مسروقة) يفقدها. الثمن تسجيل دخول واحد على هذا الجهاز.
- **الخروج من كل الأجهزة:** يُنهي كل جلسة دخول للمستخدم (وصول وتحديث)، ولا ينشئ جلسة ولا يمدّد انتهاءً. **آمن مع تجديد جارٍ:** `revokeAllLive` يقفل أولًا كل الصفوف الحيّة بـ`SELECT … FOR UPDATE` (ينتظر أي تجديد جارٍ ليلتزم)، ثم `UPDATE` بلقطة جديدة ترى الصف الذي أدرجه ذلك التجديد. عبارة `UPDATE` واحدة كانت تفوّته فتبقى جلسة حيّة. وتجديد يبدأ بعدها يجد صفّه ملغى فيُرفض (ولا يُعدّ إعادة استعمال).
- **التدقيق (`audit_logs`):** حدثان فقط، بعرف الجدول نفسه `<نطاق>.<حدث>`: `auth.password_changed` و`auth.logout_all`، لكل منهما الفاعل ودوره والكيان `user` ومعرّفه و`request_id` وعدد الجلسات المُنهاة (`after_data = {"sessions_revoked": n}`). **أرقام فقط**: حارس في المستودع يرفض أي مفتاح يشبه سرًّا (`pass|hash|token|secret|code|otp|phone|key|cred`) أو قيمة غير رقمية. الحدث والفعل **معاملة واحدة** (لا فعل بلا حدث ولا حدث بلا فعل). الجدول إلحاق فقط بمشغّلات (حتى للمستخدم الأعلى) ودور التطبيق `SELECT, INSERT` فقط، والشيفرة كلها لا تحوي `UPDATE`/`DELETE`/`TRUNCATE` عليه (حارس ساكن في الاختبارات). **لا يُسجَّل** المحاولات الخاطئة ولا الرفض (مسجّلة في السجل التشغيلي بلا أسرار).
- **الحسابات الموقوفة/المحذوفة:** 401 على المسارين كأي رمز ميّت.

**تقوية ما قبل المرحلة 11.5 (الخطوة 5.0)** — ثلاثة إصلاحات فقط، بلا ترحيلة ولا تغيير في سياسات الرموز أو OTP أو كلمات المرور:
- **سباق الدخول مقابل تغيير كلمة المرور:** كان الدخول يتحقق من كلمة المرور خارج المعاملة ثم يُنشئ الجلسة دون إعادة التحقق، فدخول بدأ قبل التغيير قد ينتج جلسة حيّة بعده. الآن **أول** عبارة في معاملة الدخول تحديث مشروط (`recordSuccessfulLoginIf`): `WHERE id=$1 AND password_hash=$2 AND status='active' AND deleted_at IS NULL`، ولا تُدرج الجلسة إلا إن نجح. السلامة من **قفل صف المستخدم في PostgreSQL** لا من التوقيت: التغيير السابق يجعل المقارنة تفشل، والدخول السابق يمسك القفل فينتظر التغيير ثم يمسح المشغّل `users_revoke_sessions` الجلسة. الفشل `invalid_credentials` العام نفسه (لا يكشف تغيّر كلمة المرور) ولا يُحسب محاولة خاطئة. ويشمل الإيقاف والحذف بين التحقق وإنشاء الجلسة.
- **تدقيق الاسترداد:** نجاح الاسترداد يكتب حدثًا واحدًا `auth.password_reset` (الفاعل ودوره والكيان ومعرّف الطلب وعدد الجلسات المُنهاة، أرقام فقط) في **معاملة الاسترداد نفسها**: يتراجع معها. لا حدث لطلب الرمز ولا للتوثيق ولا للرفض.
- **توحيد إلغاء الجلسات:** آلية واحدة للإلغاء الآمن مع تجديد جارٍ (قفل صفوف الجلسات الحيّة بـ`SELECT … FOR UPDATE` فينتظر أي تجديد جارٍ، ثم `UPDATE` بلقطة جديدة ترى ما التزم)، في دالة مساعدة واحدة `revokeLive` لها نطاقان: `revokeAllLive` (كل جلسات المستخدم: تغيير كلمة المرور والخروج الشامل والاسترداد) و`revokeFamilyLive` (جلسة دخول واحدة: **الخروج**). كان الخروج `UPDATE` واحدًا تلقائي الالتزام، فتجديد جارٍ لجلسته نفسها كان يترك جلسة حيّة بعده؛ صار يعمل داخل معاملة (`store.transaction`) ويمس عائلة الجلسة وحدها بالسبب `logout`. أما `revokeAllForUser` و`revokeFamilyByTokenHash` (عبارة `UPDATE` واحدة) فبقيتا **كما هما حرفيًا** لأن اختباراتهما قائمة، لكن **لا شيء في الإنتاج يستدعيهما** (حارس ساكن يفرض ذلك). كشف إعادة الاستعمال في `rotate` لم يتغير (يعمل أصلًا تحت قفل صف داخل معاملة). وفي الاسترداد: تُجزَّأ كلمة المرور بعد التحقق من الرمز وقبل أي قفل على الجلسات، ثم `revokeAllLive`، ثم تغيير كلمة المرور، ثم حدث التدقيق.

**ما لم يُنفَّذ بعد:** مزوّد التسليم الفعلي (SMS/WhatsApp) وجدول `message_deliveries`، وتنظيف رموز `verification_codes` القديمة (وفهرس `(user_id, purpose, created_at)` إن كبر الجدول)، والمدير الأول، وتسجيل التجار والبريد، وأحداث تدقيق أخرى (الدخول الفاشل، والتوثيق)، وعرض الجلسات وإلغاء واحدة بعينها، وCORS وكوكي رمز التحديث (يُحسمان مع 11.7)، و`ip_hash` (يحتاج سرًّا)، وذاكرة مؤقتة ≤ 30 ثانية لقراءة المستخدم (حاليًا قراءة عند كل طلب: أدق وأبطأ).

**قرارات تنتظر موافقتك (غير واردة في الخطة):** أرقام القفل وحدّ المعدّل، والحد الأدنى لكلمة المرور 6 (يُنصح بـ8)، وكشف إعادة الاستعمال الصارم بلا مهلة سماح، وأرقام الرموز (6 أرقام، 10 دقائق، 5 محاولات، 60 ثانية، 3/ساعة، 10/يوم: «مقترح» في `otp.policy` نفسها)، وحدود المعدّل الأربعة للمسارات الجديدة، وأن إعادة التعيين لا توثّق الهاتف، وأن تغيير كلمة المرور يُنهي الجلسة الحالية أيضًا، وحدّي المسارين الجديدين (تغيير كلمة المرور 5/10 دقائق، والخروج الشامل 10/10 دقائق).
**التبعيات:** لا جديدة في هذه الخطوة (`argon2` من الخطوة 1 فقط).
**الاختبارات:** وحدات `test/unit/auth-*.test.ts` (رمز الوصول، الخدمة، التجديد، المستودعات، حدّ المعدّل، الإعداد، التحقق، HTTP، **الرموز لمرة واحدة**: الأساسيات والخدمة والمستودع والتحقق)، وتكامل `test/integration/auth*.integration.test.ts` على PostgreSQL حقيقي مع argon2id حقيقي (`auth-otp.integration.test.ts` للرموز).

## Authorization & policy core (Phase 11.5, Step 5.1)

`src/authz/` is the reusable, I/O-free policy layer that every future business route must go through. It contains no routes.

- **Who** (`actor.ts`): `loadActor(auth, token)` verifies the access token, lets `authenticate` re-read the account from the database, and returns an `Actor {id, role: member|dealer|admin}` only for an ACTIVE, NOT-DELETED account with a known role. Suspended, pending, deleted, unknown-role or malformed-id accounts yield `null` (treated as a guest). Role and status are never in the token and never in the request.
- **What** (`resources.ts`): resources are built from rows the server loaded; factories reject malformed ids so a client string can never become an owner.
- **May they** (`policy.ts`): pure `can(actor, action, resource)`, deny by default. Ownership is by id; a dealer owns a showroom and its cars; a member is never a showroom owner; admin has broad access but cannot rewrite member ads, read favorites, or edit/delete showroom cars (an admin may only read them and change their status, `moderate`; Step 5.7 hardening).
- **Public vs private** (`public.ts`): `isPublic` mirrors the `public_showrooms`/`public_cars` views and grants nothing private.
- **Outcome** (`access.ts`): `authorize` / `authorizeRead` throw `AuthzError`; a private resource the caller cannot read is `404 not_found`, identical to a missing one; `403 forbidden` only when the caller can already read it.

Routes must pass the Actor from `loadActor` and the server-loaded resource; never `ownerId`, `showroomId` or `role` from the request. Out of scope here: business rules such as status transitions, quotas and subscriptions.

## Dealer lifecycle (Phase 11.5, Step 5.2)

- **Application:** `POST /v1/dealers/register` creates a `dealer` account with status `pending` and signs it in. No showroom exists yet.
- **Pending dealers may authenticate** (sign-in, refresh, session lookup, change password, sign out everywhere). One rule, `src/auth/account-state.ts`, mirrored in the SQL of `auth/repository.ts`. They get **no Actor** from `src/authz`, so they have no dealer or admin powers.
- **Phone verification and password recovery still refuse a pending dealer** (fail-closed). `auth/otp-service.ts` was deliberately left unchanged because the OTP files are frozen by the change-control rules. Lifting this needs an explicit approval.
- **Decisions** (admin only, `src/dealers/`): `approve` pending→active (creates or approves the showroom, once), `reject` pending→suspended, `suspend` active→suspended (ends all sessions), `reactivate` suspended→active. Each runs in one transaction with a compare-and-swap, a row lock, and an audit row (`dealer.approve|reject|suspend|reactivate`, numbers only).
- **The schema has no `rejected` account state.** A rejected application is `suspended`, as in the prototype; the audit action records which it was.
- **Routes:** `GET /v1/dealer/showroom` (active dealer, own showroom only), `GET /v1/admin/dealers`, and `POST /v1/admin/dealers/:id/{approve|reject|suspend|reactivate}`. The only input to an admin action is the `:id` target. Unknown fields and any body are refused with 400.
- **Errors:** 404 for anything the caller may not see (including an unknown id), 403 only for one's own account, 409 for an invalid transition.

## Public catalog (Phase 11.5, Step 5.3)

Read-only, **no authentication**: an `Authorization` header, valid or not, is ignored. Code is in `src/catalog/`.

- **Routes:** `GET /v1/public/showrooms`, `GET /v1/public/showrooms/:id`, `GET /v1/public/cars`, `GET /v1/public/cars/:id`. No write method exists.
- **Visibility comes only from the database views.** Every query reads `public_showrooms` or `public_cars` and nothing else (no base table, no `owner_id`, no reviewer or reason columns). A pending, suspended, deleted or otherwise non-public record, a record of a suspended or deleted owner, and a car of a hidden showroom are simply absent. A detail request for any of them is the same `404 not_found` as an unknown id, and a malformed id is that same 404 without touching the database.
- **Filters (whitelist, strict):** `q` (up to 100 characters, 5 terms, all must match; NFKC and case folded; LIKE metacharacters escaped), `source`, `showroomId`, `brand`, `model`, `color`, `transmission`, `fuelType`, `status` (`available|sold|active`), `yearMin/yearMax` (1980..2100), `currency` (`IQD|USD`), `priceMin/priceMax`. A price range requires `currency`: prices are never compared across currencies. Unknown keys, repeated keys, bad enum values, reversed ranges and ids above bigint are `400 validation_failed` with field names and codes only (never the submitted values).
- **Pagination:** keyset on `id DESC` (`before` = the last id received), default 20, maximum 50, no OFFSET. `nextBefore` is returned only after a full page.
- **Rate limit (PROPOSED, per address and per instance):** lists 240 / 10 min, details 480 / 10 min.
- **By design public:** member-car phone, WhatsApp, location and display name are exposed as the view defines them.
- **Migration:** none.

## Member cars (Phase 11.5, Step 5.4)

A member's OWN car ads, in `src/member-cars/`. Every route needs a bearer token. The owner is always the verified token's account, never a request field.

- **Routes:** `POST /v1/me/cars` (201 `{car}`), `GET /v1/me/cars?limit=&before=&status=`, `GET /v1/me/cars/:id`, `PATCH /v1/me/cars/:id` (body `{version, ...changed fields}`), and `DELETE /v1/me/cars/:id?version=N` (204, soft delete).
- **Publishing is disabled (decision D1):** every new ad is stored `pending` (not in `public_cars`), whatever the role, and no input can set `active`. The only status an owner sets is `active` → `sold` (`PATCH {version, status: "sold"}`); from any other state that is `409 invalid_state`. Publishing arrives with rewarded-ad verification.
- **Ownership (IDOR/BOLA):** enforced in three layers. The SQL is scoped by `owner_id = actor`, `source_type = 'member'` and `deleted_at IS NULL`; the service re-checks `row.ownerId === actor.id`; and `authorize()` from `src/authz` must allow the action. Another user's ad (an administrator's included: there is no admin car management here), a showroom car, a deleted ad, an unknown id and a malformed id are all the same `404`. An authenticated account that may not act (pending dealer) gets `403` on create/list and `404` on an item.
- **Input (strict whitelist):** `brand`, `model`, `year`, `price`, `currency` and `phone` are required on create. The optional fields are `mileage`, `transmission`, `fuelType`, `color`, `description`, `whatsapp` (defaults to the phone), `location`, and `latitude`/`longitude` as a pair. Types, lengths and ranges follow the `cars` CHECKs. Any owner, showroom, source, status, reviewer, reason, id, version-on-create or deletion field is `400 unknown_field`. Errors carry field names and codes only.
- **Optimistic concurrency:** in one transaction the acting account is re-checked and share-locked, the ad is locked `FOR UPDATE`, `version` is compared (`409 version_conflict`), the write is a compare-and-swap on `version` (the `touch_versioned` trigger increments it), and the audit row is written. All or nothing.
- **Soft delete:** `deleted_at = now()`, and the existing trigger removes the ad's favorites. There is no hard delete.
- **Audit:** `member_car.create|update|mark_sold|delete`, entity `car`, numbers only (version, number of fields changed), through the single writer in `auth/repository.ts`.
- **Rate limits (PROPOSED, per address and per instance):** create 20 / hour, update and delete 120 / 10 min, reads 240 / 10 min.
- **Migration:** none (the app role's column privileges from 0013 already cover exactly these writes).

## Car images (Phase 11.5, Step 5.5)

Images of a member's OWN car, in `src/car-images/`. Every route needs a bearer token; the owner is always the verified token's account.

- **Routes:** `GET /v1/me/cars/:id/images` (200 `{images, maxImages}`), `POST /v1/me/cars/:id/images` (body `{assetId}`, 201 `{image}`) and `DELETE /v1/me/cars/:id/images/:imageId` (204, no body).
- **What "add" means:** it attaches an existing, `ready`, `car_image` asset owned by the caller to the car. Uploading, image processing and object storage (R2) are a later step; nothing here touches file bytes, and no response carries `storage_key`, `thumb_key` or the checksum (the DTO is `{id, assetId, sortOrder, isMain, width, height, createdAt}`). A pending, rejected, showroom-cover or already-attached asset is `409 invalid_state`.
- **Ownership (IDOR/BOLA):** car → car_images → assets. The car is found only as the actor's own member car (`owner_id = actor`, not deleted), re-checked in the service and authorized with the existing policy; an image is found only through that car (an image id of another car is 404 even if the caller owns both); an asset is found only if the caller owns it. Another user's car or asset (an administrator included), a deleted or showroom car, unknown and malformed ids are all the same `404`.
- **Limit:** read from `app_settings` `images.max_per_car` (member: 4), the value the database trigger enforces. Reaching it is `409 image_limit`; the check runs under the car's `FOR UPDATE` lock, so concurrent adds cannot exceed it.
- **Layout:** decided by the server. A new image goes last and is main if it is the first; deleting the main image promotes the first remaining one; positions stay contiguous (the deferred `car_images_require_main` trigger is satisfied at COMMIT). No set-main or reorder route in this step.
- **Delete:** removes the LINK only. The asset stays (ready, unattached, the caller's) for the cleanup job that also removes the stored files, so no file is orphaned. The car row and its `version` are never written.
- **Audit:** `member_car.image_add|image_delete`, entity `car`, numbers only, through the single writer in `auth/repository.ts`, in the same transaction.
- **Rate limits (PROPOSED, per address and per instance):** add and delete 60 / 10 min, list 240 / 10 min.
- **Migration:** none.

## Favorites (Phase 11.5, Step 5.6)

A member's OWN favorites, in `src/favorites/`. Every route needs a bearer token; the user is always the verified token's account, never a request field (a `userId` in the body or query is `400 unknown_field`).

- **Routes:** `POST /v1/me/favorites` (body `{carId}`; `201 {favorite}` when new, `200 {favorite}` when the car was already a favorite), `GET /v1/me/favorites?limit=&before=` (`200 {items: [{car, favoritedAt}], nextBefore}`) and `DELETE /v1/me/favorites/:carId` (`204`, no body).
- **Public cars only:** visibility is the existing view `public_cars`, not re-implemented. A favorite is created with `INSERT ... SELECT FROM public_cars`, and the list joins `public_cars`, so a deleted, pending, suspended or otherwise hidden car is never returned. An unknown, deleted, hidden or malformed car id on add is the same `404`. The `car` in the list is the public catalog DTO (Step 5.3): no owner id, reviewer data or search text.
- **Duplicates:** `UNIQUE (user_id, car_id)` with `ON CONFLICT DO NOTHING` decides, also under concurrency (never a second row, never a 500). The car row is locked `FOR SHARE` while adding, so the existing soft-delete trigger (which removes a car's favorites) cannot miss a favorite inserted at the same moment.
- **Delete is idempotent:** `204` whether or not the favorite existed, and it works for a car that is no longer public (the user can always clean up the list). It is scoped by `user_id = actor`, so it can never remove another user's row; another user's favorite and a missing one look the same. A malformed car id is `404`.
- **Hidden is not deleted:** suspending or hiding a car keeps the favorite row (only soft delete removes it, by trigger); the car is simply not listed until it is public again.
- **Pagination:** keyset on `favorites.id`, newest favorite first; `limit` 1-50 (default 20), `before` is the opaque `nextBefore` of the previous page. A cursor grants no access: the query is always scoped to the caller.
- **Authorization:** the existing `favorite` policy (strictly the owner, not even an administrator). An authenticated account that may not act (pending dealer) gets `403` on add/list and `404` on delete.
- **Audit:** `favorite.add` / `favorite.remove`, entity `car`, `{carId}` only, through the single writer in `auth/repository.ts`, in the same transaction and only when something changed.
- **Rate limits (PROPOSED, per address and per instance):** add and delete 120 / 10 min, list 240 / 10 min.
- **Migration:** none (SELECT/INSERT/DELETE on `favorites` and SELECT on `cars` and `public_cars` already exist; there is deliberately no UPDATE).

## Showroom cars: dealer and admin flows (Phase 11.5, Step 5.7)

A dealer's own showroom cars and the administrator's status change, in `src/showroom-cars/`. Every route needs a bearer token.

- **Dealer routes:** `POST /v1/dealer/cars` (201 `{car}`), `GET /v1/dealer/cars?limit=&before=&status=`, `GET /v1/dealer/cars/:id`, `PATCH /v1/dealer/cars/:id` (body `{version, ...changed fields, status?}`), `DELETE /v1/dealer/cars/:id?version=N` (204, soft delete).
- **Admin route:** `PATCH /v1/admin/showroom-cars/:id/status` with body `{version, status}` only. There is no administrator create, edit or delete route.
- **Who:** the dealer area is for an acting dealer (account `active`) only. A member, an administrator, a pending dealer and a dealer without a showroom get `404` on every dealer route, as on `GET /v1/dealer/showroom`. Non-administrators get `404` on the admin route before anything is read.
- **Ownership (IDOR/BOLA):** the showroom is always the one with `owner_id = actor` (never an input). Every statement is scoped by that showroom, `source_type = 'showroom'` and `deleted_at IS NULL`. The service re-checks the row's showroom, and `authorize()` must allow the action on a `showroomCarResource` built from the server-loaded showroom. Another showroom's car, a member ad, a deleted car, an unknown id and a malformed id are all the same `404`.
- **Status rule (unchanged):** a new car is `available` immediately, with no rewarded ad and no per-car approval. It is public only while its showroom is public (the `public_cars` view). The dealer switches a car between `available` and `sold`, the only two states of a showroom car. The administrator may set those same two states on any showroom car that is not deleted; setting the status a car already has writes nothing.
- **Input (strict whitelist):** `brand`, `model`, `year`, `price` and `currency` are required on create. `mileage` (null = unknown), `transmission`, `fuelType`, `color` and `description` are optional. Types, lengths and ranges follow the `cars` CHECKs. Any showroom, owner, source, status-on-create, version-on-create, member-only (phone, WhatsApp, location, coordinates, reasons) or deletion field is `400 unknown_field`.
- **Optimistic concurrency:** every write names `version`. In one transaction the acting account is re-checked and share-locked, the car is locked `FOR UPDATE`, the version is compared (`409 version_conflict`), the write is a compare-and-swap on `version`, and the audit row is written.
- **Soft delete:** `deleted_at = now()`; the existing trigger removes the car's favorites.
- **Audit:** `showroom_car.create|update|mark_sold|mark_available|delete` for the dealer and `showroom_car.admin_mark_sold|admin_mark_available` for the administrator, entity `car`, numbers only.
- **Rate limits (PROPOSED, per address and per instance):** create 60 / hour, update and delete 120 / 10 min, reads 240 / 10 min, admin status 120 / 10 min.
- **Migration:** none.

## Object storage foundation (Phase 11.6.1)

A replaceable storage layer in `src/storage/`, for the image pipeline of the next steps. **Nothing in the running server uses it yet**: there is no upload route, no image processing and no startup wiring in this step.

- **Interface** (`provider.ts`): `put(key, bytes, {contentType})`, `get(key)` → `{body, contentType, size} | null`, `delete(key)` (idempotent) and `exists(key)`. Errors are `StorageError` with a code (`invalid_key`, `invalid_content_type`, `too_large`, `unavailable`, `integrity`), a fixed message and, for backend failures, the HTTP status only. No error contains a key, bucket, endpoint, credential or backend response body.
- **Providers:** `createS3Storage` is Cloudflare R2 or any S3-compatible service, over the S3 REST API with Node's `fetch` and an AWS Signature V4 signer written on `node:crypto` (no SDK, no new dependency). `createMemoryStorage` is an in-memory provider with the same contract, for tests and local development. One contract test suite runs against both.
- **R2 requests:** path-style `<endpoint>/<bucket>/<prefix>/<key>`, signed payload (`x-amz-content-sha256`, never `UNSIGNED-PAYLOAD`), redirects refused, a per-request timeout, and size limits on upload and download (an announced or streamed size above the limit is refused, and a length mismatch is an `integrity` error). A 404 on `get`/`exists` means missing; any other failure is `unavailable`, never "missing".
- **Keys** (`keys.ts`) are generated by the server, never taken from a client, and never returned to one. They are still checked before every call: 1-8 segments of `[A-Za-z0-9._-]` that start with a letter or digit, at most 512 characters. Traversal (`..`), absolute paths, empty segments, backslashes, percent-encoding, whitespace, control and non-ASCII characters are refused.
- **Configuration** (`config.ts`, documented in `.env.storage.example`): `STORAGE_PROVIDER` (`r2` | `memory`; memory is refused in production). For r2, `STORAGE_S3_ENDPOINT` (an https origin, with plain http only for a loopback test server outside production), `STORAGE_S3_REGION` (`auto` for R2), `STORAGE_S3_BUCKET`, `STORAGE_S3_ACCESS_KEY_ID` and `STORAGE_S3_SECRET_ACCESS_KEY` are all required, with no built-in value. Optional: `STORAGE_KEY_PREFIX`, `STORAGE_TIMEOUT_MS` (default 10000) and `STORAGE_MAX_OBJECT_BYTES` (default 10 MiB). Problems are listed without values, and `redactStorageConfig` hides the endpoint, bucket and both credentials.
- **Verification:** the signer reproduces AWS's published S3 GET and PUT example signatures and matches botocore on 40 generated requests (`test/fixtures/sigv4-botocore-vectors.json`). `test/integration/storage.integration.test.ts` runs against a real bucket only with `STORAGE_IT=1`.
- **Migration:** none.

// Phase 11.6.4: the asset cleanup job. Rules over the in-memory cleanup repository and the real in-memory storage provider
// (listing included): dry-run by default, bounded batches, stale rows, orphaned objects, never a referenced or recent object,
// failures that stop the run safely; a randomized safety property; the CLI argument parser; SQL and source guards.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { CLEANUP_DEFAULTS, CleanupOptionsError, classifyObjectKey, referenceCandidates, resolveCleanupOptions, runAssetCleanup } from '../../src/assets/cleanup.ts';
import type { CleanupReport } from '../../src/assets/cleanup.ts';
import { FIND_REFERENCED_KEYS_SQL, buildDeleteStale, buildListStale } from '../../src/assets/cleanup-repository.ts';
import { StorageError, createMemoryStorage } from '../../src/storage/index.ts';
import type { ListableStorage } from '../../src/storage/index.ts';
import { parseCleanupArgs } from '../../scripts/assets-cleanup.ts';
import { makeFakeCleanup } from '../helpers/fake-cleanup.ts';
import type { CleanRow } from '../helpers/fake-cleanup.ts';

const ROOT = join(import.meta.dirname, '..', '..');
const code = (rel: string) =>
  readFileSync(join(ROOT, rel), 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split('\n')
    .map((l) => l.replace(/^\s*\/\/.*$/, ''))
    .join('\n');
const T0 = Date.UTC(2026, 9, 10);
const H = 3600 * 1000;
const u = (i: number) => `d0000000-0000-4000-8000-${String(i).padStart(12, '0')}`;
const inc = (i: number, kind = 'car_image') => `incoming/${kind}/${u(i)}`;
const proc = (i: number, kind = 'car_image') => `processed/${kind}/${u(i)}.webp`;
const thumb = (i: number, kind = 'car_image') => `thumbs/${kind}/${u(i)}.webp`;

function world() {
  let t = new Date(T0);
  const clock = { now: () => t };
  const storageTime = { at: new Date(T0) };
  const storage = createMemoryStorage({ now: () => storageTime.at });
  const fc = makeFakeCleanup(clock);
  const deleted: string[] = [];
  const spy: ListableStorage & { faults: { delete: StorageError | null; list: StorageError | null; deleteAfter: number } } = {
    kind: 'memory',
    faults: { delete: null, list: null, deleteAfter: 0 },
    put: (k, b, o) => storage.put(k, b, o),
    get: (k) => storage.get(k),
    exists: (k) => storage.exists(k),
    async delete(k) {
      if (spy.faults.delete && deleted.length >= spy.faults.deleteAfter) throw spy.faults.delete;
      deleted.push(k);
      return storage.delete(k);
    },
    async list(p, o) {
      if (spy.faults.list) throw spy.faults.list;
      return storage.list(p, o);
    },
  };
  /** Stores an object last modified `ageHours` ago. */
  async function obj(key: string, ageHours = 48) {
    storageTime.at = new Date(T0 - ageHours * H);
    await storage.put(key, new Uint8Array([1]), { contentType: 'image/webp' });
  }
  const row = (fields: Partial<CleanRow>, ageHours = 48) => fc.add({ createdAt: new Date(T0 - ageHours * H), ...fields });
  const logs: Array<Record<string, unknown>> = [];
  const run = (opts: Parameters<typeof runAssetCleanup>[1] = {}) => runAssetCleanup({ repo: fc.repo, storage: spy, now: clock.now, logger: { info: (o) => void logs.push(o), warn: (o) => void logs.push(o) } }, opts);
  return { fc, storage, spy, deleted, obj, row, run, logs, setNow: (d: Date) => (t = d) };
}

/** The scenario used by several tests. */
async function scenario() {
  const w = world();
  const R = {
    stalePending: w.row({ status: 'pending', storageKey: inc(1) }),
    staleRejected: w.row({ status: 'rejected', storageKey: inc(2, 'showroom_cover') }),
    recentPending: w.row({ status: 'pending', storageKey: inc(3) }, 1),
    ready: w.row({ status: 'ready', storageKey: proc(4), thumbKey: thumb(4) }, 500),
    referencedPending: w.row({ status: 'pending', storageKey: inc(5), referenced: true }),
    noKey: w.row({ status: 'pending', storageKey: null }),
    legacyKey: w.row({ status: 'rejected', storageKey: 'cars/7/x/full.webp' }),
    inFlight: w.row({ status: 'pending', storageKey: inc(12) }, 2),
  };
  await w.obj(inc(1));
  await w.obj(inc(2, 'showroom_cover'));
  await w.obj(proc(2, 'showroom_cover'));
  await w.obj(thumb(2, 'showroom_cover'));
  await w.obj(inc(3), 1);
  await w.obj(proc(4), 400);
  await w.obj(thumb(4), 400);
  await w.obj(inc(4), 400); // the original left behind after processing (its delete failed): an orphan
  await w.obj(inc(5));
  await w.obj('cars/7/x/full.webp');
  await w.obj(inc(9)); // no row at all
  await w.obj(proc(10));
  await w.obj(thumb(10));
  await w.obj(inc(11), 2); // an orphan, but too recent
  await w.obj('incoming/car_image/readme.txt'); // not a key this backend generates
  await w.obj(proc(12), 30); // outputs of the pending (not yet stale) row 12: referenced through its original
  await w.obj(thumb(12), 30);
  return { w, R };
}

describe('asset cleanup: options', () => {
  it('dry-run by default; defaults 100 x 10 batches, 24 hours; every bound is validated', () => {
    assert.deepEqual(resolveCleanupOptions(), { dryRun: true, batchSize: 100, maxBatches: 10, olderThanHours: 24, shard: '', rows: true, orphans: true });
    assert.deepEqual(CLEANUP_DEFAULTS, { batchSize: 100, maxBatches: 10, olderThanHours: 24 });
    assert.equal(resolveCleanupOptions({ dryRun: undefined }).dryRun, true);
    assert.equal(resolveCleanupOptions({ dryRun: 0 as never }).dryRun, true, 'only an explicit false executes');
    assert.equal(resolveCleanupOptions({ dryRun: false }).dryRun, false);
    for (const [k, v] of [['batchSize', 0], ['batchSize', 1001], ['batchSize', 2.5], ['maxBatches', 0], ['maxBatches', 101], ['olderThanHours', 23], ['olderThanHours', 721], ['shard', 'g'], ['shard', 'abc'], ['shard', 'A'], ['shard', '../'], ['shard', 5]] as const) {
      assert.throws(() => resolveCleanupOptions({ [k]: v }), (e: unknown) => e instanceof CleanupOptionsError && e.problems.includes(k), `${k}=${String(v)}`);
    }
    assert.ok(resolveCleanupOptions({ batchSize: 1000, maxBatches: 100, olderThanHours: 720, shard: 'f0' }));
  });

  it('the CLI parser: --execute is the only way to delete; numbers and the shard are validated; unknown arguments are refused', () => {
    assert.equal(parseCleanupArgs([]).dryRun, true);
    assert.equal(parseCleanupArgs(['--execute']).dryRun, false);
    assert.equal(parseCleanupArgs(['--execute', '--dry-run']).dryRun, true);
    assert.deepEqual(parseCleanupArgs(['--batch-size=50', '--max-batches=3', '--older-than-hours=48', '--shard=0a', '--skip-orphans']), { dryRun: true, batchSize: 50, maxBatches: 3, olderThanHours: 48, shard: '0a', rows: true, orphans: false });
    assert.equal(parseCleanupArgs(['--skip-rows']).rows, false);
    for (const bad of [['--execute=yes'], ['--batch-size'], ['--batch-size=0'], ['--batch-size=-1'], ['--batch-size=1e3'], ['--batch-size=5000'], ['--older-than-hours=1'], ['--shard'], ['--shard=xyz'], ['--force'], ['-x'], ['delete']]) {
      assert.throws(() => parseCleanupArgs(bad), CleanupOptionsError, bad.join(' '));
    }
    assert.throws(() => parseCleanupArgs(['--key=processed/x']), (e: unknown) => e instanceof CleanupOptionsError && !JSON.stringify(e.problems).includes('processed'), 'values are never echoed');
  });
});

describe('asset cleanup: object keys', () => {
  it('recognizes exactly the keys this backend generates', () => {
    assert.deepEqual(classifyObjectKey(inc(1)), { area: 'incoming', kind: 'car_image', original: inc(1), main: proc(1), thumb: thumb(1) });
    assert.equal(classifyObjectKey(proc(1, 'showroom_cover'))!.area, 'processed');
    assert.equal(classifyObjectKey(thumb(1))!.original, inc(1));
    for (const k of [`${inc(1)}.webp`, proc(1).replace('.webp', ''), thumb(1).replace('.webp', '.png'), inc(1).toUpperCase(), `incoming/car_image/${u(1)}/x`, `incoming/avatar/${u(1)}`, `other/car_image/${u(1)}`, 'cars/1/x/full.webp', `incoming/car_image/${u(1).slice(1)}`, `x/${inc(1)}`]) {
      assert.equal(classifyObjectKey(k), null, k);
    }
  });

  it('an original is referenced only as a storage key; processed outputs also through their original (pending) or main image (ready)', () => {
    assert.deepEqual(referenceCandidates(inc(1), classifyObjectKey(inc(1))!), [inc(1)]);
    assert.deepEqual(referenceCandidates(thumb(1), classifyObjectKey(thumb(1))!), [thumb(1), inc(1), proc(1)]);
    assert.deepEqual(referenceCandidates(proc(1), classifyObjectKey(proc(1))!), [proc(1), inc(1), proc(1)]);
  });
});

describe('asset cleanup: dry run', () => {
  it('counts what would be deleted and deletes NOTHING (rows and objects untouched)', async () => {
    const { w } = await scenario();
    const rowsBefore = w.fc.rows().length;
    const keysBefore = w.storage.keys();
    const r = await w.run();
    assert.equal(r.dryRun, true);
    // In a dry run the stale rows still exist, so their objects still count as referenced.
    assert.equal(r.error, null);
    assert.deepEqual(r.rows, { batches: 1, scanned: 4, eligible: 3, deleted: 0, changed: 0, objectsDeleted: 0, objectDeleteFailures: 0, unrecognizedKeys: 1, complete: true });
    assert.deepEqual({ ...r.orphans, pages: undefined }, { pages: undefined, scanned: 16, unsafe: 0, tooRecent: 2, unrecognized: 1, referenced: 9, orphaned: 4, deleted: 0, deleteFailures: 0, complete: true });
    assert.equal(w.fc.rows().length, rowsBefore);
    assert.deepEqual(w.storage.keys(), keysBefore);
    assert.deepEqual(w.deleted, []);
    assert.ok(!w.fc.calls.some((c) => c.op === 'deleteStale'));
  });
});

describe('asset cleanup: execute', () => {
  it('deletes stale unreferenced rows with their objects, then orphans; keeps everything referenced, recent, unknown or legacy', async () => {
    const { w, R } = await scenario();
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, null);
    assert.deepEqual(r.rows, { batches: 1, scanned: 4, eligible: 3, deleted: 3, changed: 0, objectsDeleted: 6, objectDeleteFailures: 0, unrecognizedKeys: 1, complete: true });
    assert.deepEqual(w.fc.rows().map((x) => x.id).sort(), [R.recentPending.id, R.ready.id, R.referencedPending.id, R.legacyKey.id, R.inFlight.id].sort());
    assert.deepEqual(w.storage.keys(), [
      'cars/7/x/full.webp', inc(11), inc(3), inc(5), 'incoming/car_image/readme.txt', proc(12), proc(4), thumb(12), thumb(4),
    ].sort());
    // Phase 2 found the original left behind by processing (row 4 is ready) and the objects without any row.
    assert.equal(r.orphans!.deleted, 4);
    assert.equal(r.orphans!.orphaned, 4);
    for (const k of [inc(4), inc(9), proc(10), thumb(10)]) assert.ok(w.deleted.includes(k), k);
    // A second run has nothing left to do.
    const again = await w.run({ dryRun: false });
    assert.equal(again.rows!.deleted, 0);
    assert.equal(again.orphans!.deleted, 0);
  });

  it('once a pending row with processing outputs becomes stale, phase 1 removes it with ALL its objects; ready assets are never touched', async () => {
    const { w } = await scenario();
    // Make every row old enough: row 12 (pending, outputs present) becomes stale and is cleaned as a whole by phase 1.
    w.setNow(new Date(T0 + 100 * H));
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, null);
    for (const k of [inc(12), proc(12), thumb(12)]) assert.ok(!w.storage.keys().includes(k), k);
    assert.ok(w.storage.keys().includes(proc(4)) && w.storage.keys().includes(thumb(4)), 'a ready asset is never touched, however old');
  });

  it('a row that changed between the listing and the delete (processed, attached) is left alone with its objects', async () => {
    for (const change of [(x: CleanRow) => Object.assign(x, { status: 'ready', storageKey: proc(1), thumbKey: thumb(1) }), (x: CleanRow) => Object.assign(x, { referenced: true })]) {
      const w = world();
      const row = w.row({ status: 'pending', storageKey: inc(1) });
      await w.obj(inc(1));
      w.fc.faults.beforeDelete = change;
      const r = await w.run({ dryRun: false, orphans: false });
      assert.equal(r.rows!.changed, 1);
      assert.equal(r.rows!.deleted, 0);
      assert.ok(w.fc.rows().includes(row));
      assert.deepEqual(w.deleted, []);
    }
  });

  it('respects the bounds: at most maxBatches listings of batchSize rows; a later run continues', async () => {
    const w = world();
    for (let i = 1; i <= 7; i++) w.row({ status: 'pending', storageKey: inc(i) });
    const r = await w.run({ dryRun: false, batchSize: 2, maxBatches: 2, orphans: false });
    assert.equal(r.rows!.batches, 2);
    assert.equal(r.rows!.deleted, 4);
    assert.equal(r.rows!.complete, false);
    const lists = w.fc.calls.filter((c) => c.op === 'listStale').map((c) => c.arg as { limit: number; olderThanSeconds: number });
    assert.equal(lists.length, 2);
    for (const l of lists) assert.deepEqual([l.limit, l.olderThanSeconds], [2, 24 * 3600]);
    const r2 = await w.run({ dryRun: false, batchSize: 2, maxBatches: 2, orphans: false });
    assert.equal(r2.rows!.deleted, 3);
    assert.equal(r2.rows!.complete, true);
    assert.equal(w.fc.rows().length, 0);
  });

  it('dry-run paging advances (keyset), so a bounded dry run never loops on the same rows', async () => {
    const w = world();
    for (let i = 1; i <= 5; i++) w.row({ status: 'rejected', storageKey: inc(i) });
    const r = await w.run({ batchSize: 2, maxBatches: 10, orphans: false });
    assert.deepEqual([r.rows!.batches, r.rows!.eligible, r.rows!.complete], [3, 5, true]);
    const afters = w.fc.calls.filter((c) => c.op === 'listStale').map((c) => (c.arg as { afterId: string | null }).afterId);
    assert.deepEqual(afters, [null, w.fc.rows()[1]!.id, w.fc.rows()[3]!.id]);
  });

  it('the age threshold is respected for rows and for objects (--older-than-hours)', async () => {
    const w = world();
    w.row({ status: 'pending', storageKey: inc(1) }, 30);
    await w.obj(inc(2), 30);
    const r = await w.run({ dryRun: false, olderThanHours: 48 });
    assert.equal(r.rows!.eligible, 0);
    assert.equal(r.orphans!.tooRecent, 1);
    assert.deepEqual(w.deleted, []);
    const r2 = await w.run({ dryRun: false, olderThanHours: 24 });
    assert.equal(r2.rows!.deleted, 1);
    assert.equal(r2.orphans!.deleted, 1);
  });

  it('orphan listing is bounded (pages of batchSize, maxBatches pages in total) and a shard narrows it', async () => {
    const w = world();
    for (let i = 1; i <= 9; i++) await w.obj(inc(i));
    const r = await w.run({ dryRun: false, rows: false, batchSize: 2, maxBatches: 3 });
    assert.equal(r.orphans!.pages, 3);
    assert.equal(r.orphans!.deleted, 6);
    assert.equal(r.orphans!.complete, false);
    const w2 = world();
    await w2.obj(`incoming/car_image/a${u(1).slice(1)}`);
    await w2.obj(`incoming/car_image/b${u(1).slice(1)}`);
    const r2 = await w2.run({ dryRun: false, rows: false, shard: 'a' });
    assert.equal(r2.orphans!.deleted, 1);
    assert.equal(r2.orphans!.complete, true);
    assert.deepEqual(w2.storage.keys(), [`incoming/car_image/b${u(1).slice(1)}`]);
  });

  it('only the incoming/, processed/ and thumbs/ areas of the two kinds are ever listed', async () => {
    const w = world();
    const prefixes: string[] = [];
    const list = w.spy.list.bind(w.spy);
    w.spy.list = async (p, o) => (prefixes.push(p), list(p, o));
    await w.run({ rows: false });
    assert.deepEqual(prefixes, ['incoming/car_image/', 'incoming/showroom_cover/', 'processed/car_image/', 'processed/showroom_cover/', 'thumbs/car_image/', 'thumbs/showroom_cover/']);
  });
});

describe('asset cleanup: failures stop the run safely', () => {
  it('a database failure while listing rows: nothing deleted, error database_unavailable, orphan phase not run', async () => {
    const { w } = await scenario();
    w.fc.faults.failListAt = 1;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'database_unavailable');
    assert.equal(r.orphans, null);
    assert.deepEqual(w.deleted, []);
  });

  it('a database failure while deleting a row: that object is not touched', async () => {
    const { w } = await scenario();
    w.fc.faults.failDelete = true;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'database_unavailable');
    assert.deepEqual(w.deleted, []);
  });

  it('a storage failure after a row was deleted: the run stops, and the next run sweeps the objects left behind', async () => {
    const w = world();
    w.row({ status: 'rejected', storageKey: inc(1) });
    await w.obj(inc(1));
    await w.obj(proc(1));
    w.spy.faults.delete = new StorageError('unavailable', 500);
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'storage_unavailable');
    assert.deepEqual([r.rows!.deleted, r.rows!.objectsDeleted, r.rows!.objectDeleteFailures], [1, 0, 1]);
    assert.equal(w.fc.rows().length, 0);
    assert.equal(r.orphans, null);
    w.spy.faults.delete = null;
    const r2 = await w.run({ dryRun: false });
    assert.equal(r2.error, null);
    assert.equal(r2.orphans!.deleted, 2);
    assert.deepEqual(w.storage.keys(), []);
  });

  it('an orphan delete failure stops the sweep at once (counted, nothing further attempted)', async () => {
    const w = world();
    await w.obj(inc(1));
    await w.obj(inc(2));
    w.spy.faults.delete = new StorageError('unavailable', 500);
    const r = await w.run({ dryRun: false, rows: false });
    assert.equal(r.error, 'storage_unavailable');
    assert.deepEqual([r.orphans!.orphaned, r.orphans!.deleted, r.orphans!.deleteFailures], [1, 0, 1]);
    assert.deepEqual(w.storage.keys(), [inc(1), inc(2)]);
  });

  it('a listing failure is storage_unavailable; a reference lookup failure is database_unavailable and deletes nothing on that page', async () => {
    const w = world();
    await w.obj(inc(1));
    w.spy.faults.list = new StorageError('unavailable');
    assert.equal((await w.run({ dryRun: false })).error, 'storage_unavailable');
    w.spy.faults.list = null;
    w.fc.faults.failRefs = true;
    const r = await w.run({ dryRun: false });
    assert.equal(r.error, 'database_unavailable');
    assert.deepEqual(w.deleted, []);
    assert.deepEqual(w.storage.keys(), [inc(1)]);
  });

  it('an unexpected error is reported as such (never thrown to the caller); invalid options do throw', async () => {
    const w = world();
    w.row({ status: 'pending', storageKey: inc(1) });
    w.fc.faults.failListAt = 1;
    w.fc.faults.nonDbError = true;
    assert.equal((await w.run({ dryRun: false })).error, 'unexpected');
    await assert.rejects(w.run({ batchSize: 0 }), CleanupOptionsError);
  });

  it('the report and the log line carry counts only: no key, prefix, row id or provider detail', async () => {
    const { w } = await scenario();
    w.spy.faults.delete = new StorageError('unavailable', 503);
    const r = await w.run({ dryRun: false });
    const text = JSON.stringify(r) + JSON.stringify(w.logs);
    for (const s of ['incoming', 'processed', 'thumbs', 'cars/', 'd0000000', 'a0000000', '503', 'webp']) assert.ok(!text.includes(s), s);
    assert.equal(w.logs.length, 1);
    assert.equal(w.logs[0]!['event'], 'assets.cleanup');
  });
});

describe('asset cleanup: safety property (randomized)', () => {
  it('over 300 random worlds: a referenced or recent object, a ready/referenced/recent row, or an unknown key is NEVER deleted', async () => {
    let seed = 1164;
    const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
    const pick = <T,>(xs: readonly T[]): T => xs[Math.floor(rnd() * xs.length)]!;
    const totals = { rows: 0, objects: 0, orphans: 0, kept: 0 };
    for (let round = 0; round < 300; round++) {
      const w = world();
      const kinds = ['car_image', 'showroom_cover'] as const;
      let id = 0;
      for (let i = 0; i < 12; i++) {
        const k = pick(kinds);
        const n = ++id;
        const status = pick(['pending', 'ready', 'rejected', 'none'] as const);
        const age = pick([1, 10, 23, 25, 48, 400]);
        if (status === 'ready') w.row({ status, storageKey: proc(n, k), thumbKey: thumb(n, k), referenced: rnd() < 0.5 }, age);
        else if (status !== 'none') w.row({ status, storageKey: rnd() < 0.1 ? `legacy/${n}` : inc(n, k), referenced: rnd() < 0.2 }, age);
        for (const key of [inc(n, k), proc(n, k), thumb(n, k)]) if (rnd() < 0.6) await w.obj(key, pick([1, 10, 23, 25, 48, 400]));
        if (rnd() < 0.1) await w.obj(`incoming/${k}/junk-${n}`, 400);
      }
      const rowsBefore = w.fc.rows().map((r) => ({ ...r }));
      const listAll = async () => [...(await w.storage.list('i', { maxKeys: 1000 })).objects, ...(await w.storage.list('p', { maxKeys: 1000 })).objects, ...(await w.storage.list('t', { maxKeys: 1000 })).objects];
      const before = new Map((await listAll()).map((o) => [o.key, o.lastModified.getTime()]));
      const report: CleanupReport = await w.run({ dryRun: false, batchSize: pick([1, 3, 100]), maxBatches: pick([1, 2, 100]) });
      assert.equal(report.error, null);
      totals.rows += report.rows!.deleted;
      totals.objects += report.rows!.objectsDeleted;
      totals.orphans += report.orphans!.deleted;
      totals.kept += report.orphans!.referenced + report.orphans!.tooRecent + report.orphans!.unrecognized;
      const cutoff = T0 - 24 * H;
      // Rows: only stale (pending/rejected, old, unreferenced, recognized key or none) rows may disappear.
      const after = new Set(w.fc.rows().map((r) => r.id));
      for (const r of rowsBefore) {
        if (after.has(r.id)) continue;
        assert.ok(r.status !== 'ready' && !r.referenced && r.createdAt.getTime() < cutoff && (r.storageKey === null || classifyObjectKey(r.storageKey) !== null), `round ${round}: row ${JSON.stringify(r)} deleted`);
      }
      // Objects: a deleted object was never referenced by a remaining row, and was either an output of a deleted row or an old orphan.
      const deletedRows = rowsBefore.filter((r) => !after.has(r.id));
      for (const key of w.deleted) {
        const info = classifyObjectKey(key);
        assert.ok(info, `round ${round}: unknown key ${key} deleted`);
        const remaining = w.fc.rows();
        const referencedNow = remaining.some((r) => referenceCandidates(key, info).some((c) => c === r.storageKey || c === r.thumbKey));
        assert.ok(!referencedNow, `round ${round}: referenced ${key} deleted`);
        const ownRowDeleted = deletedRows.some((r) => r.storageKey === info.original);
        const at = before.get(key);
        assert.ok(ownRowDeleted || (at !== undefined && at <= cutoff), `round ${round}: recent orphan ${key} deleted`);
      }
    }
    // The property is not vacuous: plenty was deleted, and plenty was kept.
    for (const [k, v] of Object.entries(totals)) assert.ok(v > 100, `${k}: ${v}`);
  });
});

describe('asset cleanup: SQL and source guards', () => {
  it('stale = pending/rejected, older than the threshold by the DATABASE clock, unreferenced; keyset on id; bounded', () => {
    const l = buildListStale({ olderThanSeconds: 86400, afterId: null, limit: 100 });
    assert.match(l.text, /a\.status IN \('pending', 'rejected'\)/);
    assert.match(l.text, /a\.created_at < now\(\) - make_interval\(secs => \$1::double precision\)/);
    assert.match(l.text, /\(\$2::uuid IS NULL OR a\.id > \$2::uuid\)/);
    assert.match(l.text, /NOT EXISTS \(SELECT 1 FROM car_images ci WHERE ci\.asset_id = a\.id\)\s+AND NOT EXISTS \(SELECT 1 FROM showrooms s WHERE s\.cover_asset_id = a\.id\)/);
    assert.match(l.text, /ORDER BY a\.id\s+LIMIT \$3::int$/);
    assert.deepEqual(l.values, [86400, null, 100]);
    const d = buildDeleteStale({ id: 'x', storageKey: 'k', olderThanSeconds: 86400 });
    assert.match(d.text, /^DELETE FROM assets a\s+WHERE a\.id = \$1::uuid\s+AND a\.status IN \('pending', 'rejected'\)\s+AND a\.storage_key IS NOT DISTINCT FROM \$2::text\s+AND a\.created_at < now\(\) - make_interval\(secs => \$3::double precision\)\s+AND NOT EXISTS/);
    assert.deepEqual(d.values, ['x', 'k', 86400]);
    assert.match(FIND_REFERENCED_KEYS_SQL, /a\.storage_key = ANY\(\$1::text\[\]\)[\s\S]*UNION[\s\S]*a\.thumb_key = ANY\(\$1::text\[\]\)/);
    assert.ok(!/status/.test(FIND_REFERENCED_KEYS_SQL), 'a reference by a row of ANY status counts');
  });

  it('the job deletes the row before its objects, never prints a key, and is not reachable from any route', () => {
    const src = code('src/assets/cleanup.ts');
    assert.ok(src.indexOf('repo.deleteStale(') < src.indexOf('storage.delete(k)'));
    assert.match(src, /if \(!deleted\) \{\s*r\.changed\+\+;\s*continue;\s*\}/);
    const logs = [...src.matchAll(/log\?\.\(\{([^}]*)\}/g)].map((m) => m[1]!);
    assert.deepEqual(logs, [" event: 'assets.cleanup', dryRun: report.dryRun, error: report.error, rows: report.rows, orphans: report.orphans "]);
    for (const f of ['src/server.ts', 'src/index.ts', 'src/assets/routes.ts', 'src/assets/delivery-routes.ts', 'src/assets/cover-routes.ts']) assert.ok(!/cleanup/.test(code(f)), f);
    const cli = code('scripts/assets-cleanup.ts');
    assert.match(cli, /if \(storageConfig\.provider !== 'r2'\)/);
    assert.ok(!/console\.\w+\([^)]*storageConfig\b(?!\.provider)/.test(cli), 'the CLI never prints the storage configuration');
  });
});

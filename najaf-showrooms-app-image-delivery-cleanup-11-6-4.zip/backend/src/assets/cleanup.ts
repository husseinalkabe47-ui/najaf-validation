// Asset cleanup (Phase 11.6.4): removes ABANDONED uploads and ORPHANED objects, in bounded batches, DRY-RUN unless told otherwise.
// Run by an operator or a scheduler through scripts/assets-cleanup.ts; never by an HTTP route.
//
// Phase 1, stale rows. A 'pending' or 'rejected' asset older than the threshold (default 24 hours, never less) that nothing
// references (no car image, no showroom cover) is abandoned: the upload was never processed, or was refused. A row whose key has
// no shape this backend generates is left alone (it is the only record of that object). For each other one:
//   1. the ROW is deleted first, by a compare-and-swap that re-checks everything (cleanup-repository.ts). A row that was processed,
//      attached or changed meanwhile is left alone ("changed");
//   2. then its objects (the original and any processing outputs, all derived from the row's key: derivedKeys()) are deleted.
//      Deleting a missing object succeeds. If storage fails, the objects are now orphans: phase 2 (this run or a later one) finds
//      them, so nothing is ever lost track of. Row first, because the opposite order could delete the objects of a row that became
//      ready in between.
// Phase 2, orphaned objects. The three areas the backend writes (incoming/, processed/, thumbs/; per kind, optionally one uuid
// shard) are listed page by page. An object is deleted only if ALL of these hold:
//   - its key has exactly a shape this backend generates (incoming/<kind>/<uuid>, processed|thumbs/<kind>/<uuid>.webp); any other
//     key is never deleted ("unrecognized"), and nothing outside these areas is even listed (legacy keys, other data);
//   - it is older than the same grace period (an upload in progress, or an image being processed, is never touched);
//   - NO asset row references it: no row has it as storage_key or thumb_key, and, for a processed image or thumbnail, no row
//     has its original (a pending/rejected row whose processing may be writing it) or its main image (a ready row) as storage_key.
//   Keys are random and never reused, so an object that is unreferenced now can never become referenced later.
// Limits: at most `maxBatches` row batches of `batchSize` rows, and at most `maxBatches` listing pages of `batchSize` keys in
// total. A run that hits a limit says so ("complete": false); the next run continues (deleted rows and objects are gone; a uuid
// shard narrows the listing of a large bucket).
// Failures: a database or storage failure STOPS the run (no guessing): the report says which, with the counts so far. Every step
// already done is consistent on its own. Nothing printed or logged contains a storage key, a bucket, an endpoint or a credential:
// the report has counts only.
import { DbError } from '../errors.ts';
import { StorageError } from '../storage/index.ts';
import type { ListableStorage } from '../storage/index.ts';
import type { CleanupRepository } from './cleanup-repository.ts';
import { derivedKeys } from './processing-service.ts';

export const CLEANUP_DEFAULTS = Object.freeze({ batchSize: 100, maxBatches: 10, olderThanHours: 24 });
export const CLEANUP_LIMITS = Object.freeze({ batchSizeMax: 1000, maxBatchesMax: 100, olderThanHoursMin: 24, olderThanHoursMax: 720 });
const AREAS = ['incoming', 'processed', 'thumbs'] as const;
const KINDS = ['car_image', 'showroom_cover'] as const;
const OBJECT_KEY = /^(incoming|processed|thumbs)\/(car_image|showroom_cover)\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(\.webp)?$/;
const SHARD = /^[0-9a-f]{0,2}$/;

export interface CleanupOptions {
  /** true (the default) = count only, delete nothing. */
  dryRun: boolean;
  batchSize: number;
  maxBatches: number;
  /** Stale rows and orphan objects must be at least this old (hours). */
  olderThanHours: number;
  /** '' or 1-2 lower-case hex digits: list only object keys whose uuid starts with it. */
  shard: string;
  rows: boolean;
  orphans: boolean;
}

export interface RowPhaseReport {
  batches: number;
  /** Stale rows listed. */
  scanned: number;
  /** Of those, the rows this run deletes (or, in a dry run, would delete). */
  eligible: number;
  deleted: number;
  /** Rows that changed between the listing and the delete (left alone). */
  changed: number;
  objectsDeleted: number;
  objectDeleteFailures: number;
  /** Stale rows whose storage key has no shape this backend generates: kept (the row is the only record of that object). */
  unrecognizedKeys: number;
  complete: boolean;
}
export interface OrphanPhaseReport {
  pages: number;
  scanned: number;
  /** Listed entries that are not safe keys (never touched). */
  unsafe: number;
  tooRecent: number;
  unrecognized: number;
  referenced: number;
  orphaned: number;
  deleted: number;
  deleteFailures: number;
  complete: boolean;
}
export type CleanupErrorCode = 'database_unavailable' | 'storage_unavailable' | 'unexpected';
export interface CleanupReport {
  dryRun: boolean;
  options: { batchSize: number; maxBatches: number; olderThanHours: number; shard: string };
  rows: RowPhaseReport | null;
  orphans: OrphanPhaseReport | null;
  error: CleanupErrorCode | null;
}

export interface CleanupLogger {
  info(obj: Record<string, unknown>, msg?: string): void;
  warn(obj: Record<string, unknown>, msg?: string): void;
}

export class CleanupOptionsError extends Error {
  readonly problems: string[];
  constructor(problems: string[]) {
    super(`invalid cleanup options: ${problems.join(', ')}`);
    this.name = 'CleanupOptionsError';
    this.problems = problems;
  }
}

const intIn = (v: unknown, min: number, max: number): v is number => typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max;

/** Fills the defaults and validates every bound. Dry-run unless dryRun is explicitly false. */
export function resolveCleanupOptions(input: Partial<CleanupOptions> = {}): CleanupOptions {
  const o: CleanupOptions = {
    dryRun: input.dryRun !== false,
    batchSize: input.batchSize ?? CLEANUP_DEFAULTS.batchSize,
    maxBatches: input.maxBatches ?? CLEANUP_DEFAULTS.maxBatches,
    olderThanHours: input.olderThanHours ?? CLEANUP_DEFAULTS.olderThanHours,
    shard: input.shard ?? '',
    rows: input.rows !== false,
    orphans: input.orphans !== false,
  };
  const problems: string[] = [];
  if (!intIn(o.batchSize, 1, CLEANUP_LIMITS.batchSizeMax)) problems.push('batchSize');
  if (!intIn(o.maxBatches, 1, CLEANUP_LIMITS.maxBatchesMax)) problems.push('maxBatches');
  if (!intIn(o.olderThanHours, CLEANUP_LIMITS.olderThanHoursMin, CLEANUP_LIMITS.olderThanHoursMax)) problems.push('olderThanHours');
  if (typeof o.shard !== 'string' || !SHARD.test(o.shard)) problems.push('shard');
  if (problems.length > 0) throw new CleanupOptionsError(problems);
  return o;
}

export interface ObjectKeyInfo {
  area: (typeof AREAS)[number];
  kind: (typeof KINDS)[number];
  original: string;
  main: string;
  thumb: string;
}
/** The shape of a key this backend generates; null for anything else (such a key is never deleted by the orphan sweep). */
export function classifyObjectKey(key: string): ObjectKeyInfo | null {
  const m = OBJECT_KEY.exec(key);
  if (!m) return null;
  const area = m[1] as ObjectKeyInfo['area'];
  if ((area === 'incoming') !== (m[4] === undefined)) return null;
  const keys = derivedKeys(`incoming/${m[2]}/${m[3]}`);
  if (!keys) return null;
  return { area, kind: m[2] as ObjectKeyInfo['kind'], ...keys };
}

/** The keys whose presence in a row makes `key` referenced (see the header). */
export function referenceCandidates(key: string, info: ObjectKeyInfo): string[] {
  return info.area === 'incoming' ? [key] : [key, info.original, info.main];
}

class Stop extends Error {
  readonly code: CleanupErrorCode;
  constructor(code: CleanupErrorCode) {
    super(code);
    this.code = code;
  }
}

export async function runAssetCleanup(deps: { repo: CleanupRepository; storage: ListableStorage; now?: () => Date; logger?: CleanupLogger }, input: Partial<CleanupOptions> = {}): Promise<CleanupReport> {
  const opts = resolveCleanupOptions(input);
  const { repo, storage, logger } = deps;
  const now = deps.now ?? (() => new Date());
  const olderThanSeconds = opts.olderThanHours * 3600;
  const report: CleanupReport = {
    dryRun: opts.dryRun,
    options: { batchSize: opts.batchSize, maxBatches: opts.maxBatches, olderThanHours: opts.olderThanHours, shard: opts.shard },
    rows: null,
    orphans: null,
    error: null,
  };

  // Every database call and every storage call goes through one of these: a failure becomes a Stop with a code (never a message).
  const db = async <T>(fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (e) {
      throw new Stop(e instanceof DbError ? 'database_unavailable' : 'unexpected');
    }
  };
  const store = async <T>(fn: () => Promise<T>): Promise<T> => {
    try {
      return await fn();
    } catch (e) {
      throw new Stop(e instanceof StorageError ? 'storage_unavailable' : 'unexpected');
    }
  };

  try {
    if (opts.rows) {
      const r: RowPhaseReport = { batches: 0, scanned: 0, eligible: 0, deleted: 0, changed: 0, objectsDeleted: 0, objectDeleteFailures: 0, unrecognizedKeys: 0, complete: false };
      report.rows = r;
      let afterId: string | null = null;
      for (;;) {
        if (r.batches >= opts.maxBatches) break;
        const rows = await db(() => repo.listStale({ olderThanSeconds, afterId, limit: opts.batchSize }));
        r.batches++;
        r.scanned += rows.length;
        for (const row of rows) {
          // A key this backend did not generate: the row is the only record of that object, so it is kept (and counted).
          const keys = row.storageKey === null ? null : derivedKeys(row.storageKey);
          if (row.storageKey !== null && !keys) {
            r.unrecognizedKeys++;
            continue;
          }
          r.eligible++;
          if (opts.dryRun) continue;
          const deleted = await db(() => repo.deleteStale({ id: row.id, storageKey: row.storageKey, olderThanSeconds }));
          if (!deleted) {
            r.changed++;
            continue;
          }
          r.deleted++;
          if (!keys) continue;
          for (const k of [keys.original, keys.main, keys.thumb]) {
            try {
              await store(() => storage.delete(k));
              r.objectsDeleted++;
            } catch (e) {
              r.objectDeleteFailures++;
              throw e; // the row is gone: its remaining objects are orphans now, found by phase 2 of a later run
            }
          }
        }
        if (rows.length < opts.batchSize) {
          r.complete = true;
          break;
        }
        afterId = rows[rows.length - 1]!.id;
      }
    }

    if (opts.orphans) {
      const o: OrphanPhaseReport = { pages: 0, scanned: 0, unsafe: 0, tooRecent: 0, unrecognized: 0, referenced: 0, orphaned: 0, deleted: 0, deleteFailures: 0, complete: false };
      report.orphans = o;
      const cutoff = now().getTime() - olderThanSeconds * 1000;
      let budgetLeft = true;
      outer: for (const area of AREAS) {
        for (const kind of KINDS) {
          const prefix = `${area}/${kind}/${opts.shard}`;
          let token: string | null = null;
          do {
            if (o.pages >= opts.maxBatches) {
              budgetLeft = false;
              break outer;
            }
            const page = await store(() => storage.list(prefix, { maxKeys: opts.batchSize, token }));
            o.pages++;
            o.scanned += page.objects.length + page.skipped;
            o.unsafe += page.skipped;
            const candidates: Array<{ key: string; info: ObjectKeyInfo }> = [];
            for (const obj of page.objects) {
              const info = classifyObjectKey(obj.key);
              if (!info) o.unrecognized++;
              else if (!(obj.lastModified.getTime() <= cutoff)) o.tooRecent++;
              else candidates.push({ key: obj.key, info });
            }
            const lookup = [...new Set(candidates.flatMap((c) => referenceCandidates(c.key, c.info)))];
            const refs = await db(() => repo.findReferencedKeys(lookup));
            for (const c of candidates) {
              if (referenceCandidates(c.key, c.info).some((k) => refs.has(k))) {
                o.referenced++;
                continue;
              }
              o.orphaned++;
              if (opts.dryRun) continue;
              try {
                await store(() => storage.delete(c.key));
                o.deleted++;
              } catch (e) {
                o.deleteFailures++;
                throw e;
              }
            }
            token = page.nextToken;
          } while (token !== null);
        }
      }
      o.complete = budgetLeft;
    }
  } catch (e) {
    report.error = e instanceof Stop ? e.code : 'unexpected';
  }

  const log = report.error ? logger?.warn.bind(logger) : logger?.info.bind(logger);
  log?.({ event: 'assets.cleanup', dryRun: report.dryRun, error: report.error, rows: report.rows, orphans: report.orphans });
  return report;
}

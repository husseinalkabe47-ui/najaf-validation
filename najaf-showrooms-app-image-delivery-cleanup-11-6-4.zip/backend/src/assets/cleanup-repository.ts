// PostgreSQL access for the asset CLEANUP job (Phase 11.6.4), on the existing `assets` table and its cleanup index
// (assets_cleanup_idx: pending/rejected rows by created_at, migration 0003). No migration.
//  - A STALE row is 'pending' or 'rejected', older than the threshold (measured with the DATABASE clock, now()), and referenced by
//    nothing (no car_images row, no showroom cover). 'ready' rows are never stale here.
//  - Deleting is a compare-and-swap that re-checks ALL of that, plus the storage key the job read: a row that was processed,
//    attached or changed meanwhile is not deleted (and its objects are left alone).
//  - Paging is keyset on the primary key (exact, no timestamp precision issue), bounded by the caller.
//  - Reference lookup for the orphan sweep: which of the given keys are a storage_key or a thumb_key of ANY row (any status).
//    storage_key is indexed (assets_storage_key_uq); thumb_key is not, so that half is one scan per listed page (bounded).
import type { Tx } from '../db.ts';

export interface StaleAssetRow {
  id: string;
  status: string;
  /** Internal. Used to delete the asset's objects; never returned, printed or logged. */
  storageKey: string | null;
}

export interface CleanupRepository {
  listStale(input: { olderThanSeconds: number; afterId: string | null; limit: number }): Promise<StaleAssetRow[]>;
  deleteStale(input: { id: string; storageKey: string | null; olderThanSeconds: number }): Promise<boolean>;
  findReferencedKeys(keys: string[]): Promise<Set<string>>;
}

const UNREFERENCED = `NOT EXISTS (SELECT 1 FROM car_images ci WHERE ci.asset_id = a.id)
              AND NOT EXISTS (SELECT 1 FROM showrooms s WHERE s.cover_asset_id = a.id)`;

export function buildListStale(i: { olderThanSeconds: number; afterId: string | null; limit: number }): { text: string; values: unknown[] } {
  return {
    text: `SELECT a.id, a.status, a.storage_key FROM assets a
            WHERE a.status IN ('pending', 'rejected')
              AND a.created_at < now() - make_interval(secs => $1::double precision)
              AND ($2::uuid IS NULL OR a.id > $2::uuid)
              AND ${UNREFERENCED}
            ORDER BY a.id
            LIMIT $3::int`,
    values: [i.olderThanSeconds, i.afterId, i.limit],
  };
}

export function buildDeleteStale(i: { id: string; storageKey: string | null; olderThanSeconds: number }): { text: string; values: unknown[] } {
  return {
    text: `DELETE FROM assets a
            WHERE a.id = $1::uuid
              AND a.status IN ('pending', 'rejected')
              AND a.storage_key IS NOT DISTINCT FROM $2::text
              AND a.created_at < now() - make_interval(secs => $3::double precision)
              AND ${UNREFERENCED}
        RETURNING a.id`,
    values: [i.id, i.storageKey, i.olderThanSeconds],
  };
}

export const FIND_REFERENCED_KEYS_SQL = `SELECT a.storage_key AS k FROM assets a WHERE a.storage_key = ANY($1::text[])
 UNION
SELECT a.thumb_key AS k FROM assets a WHERE a.thumb_key = ANY($1::text[])`;

export function createPgCleanupRepository(q: Tx): CleanupRepository {
  return {
    async listStale(input) {
      const s = buildListStale(input);
      return (await q.query<{ id: string; status: string; storage_key: string | null }>(s.text, s.values)).rows.map((r) => ({ id: String(r.id), status: r.status, storageKey: r.storage_key }));
    },
    async deleteStale(input) {
      const s = buildDeleteStale(input);
      return (await q.query(s.text, s.values)).rows.length === 1;
    },
    async findReferencedKeys(keys) {
      if (keys.length === 0) return new Set();
      const rows = (await q.query<{ k: string | null }>(FIND_REFERENCED_KEYS_SQL, [keys])).rows;
      return new Set(rows.map((r) => r.k).filter((k): k is string => typeof k === 'string'));
    },
  };
}

/* Task 11.7-A — القوائم والتفاصيل العامة (سيارات، معارض، بحث، فلاتر) من الخادم داخل التطبيق الفعلي (vm بسكربتات index.html).
   «الخادم» الوهمي يحاكي العقد الموجود فقط (backend/src/catalog/params.ts + routes.ts): GET /v1/public/{cars,showrooms}[/:id]
   مع q/limit/before/source/showroomId/brand/model/yearMin/yearMax/currency/priceMin/priceMax، وتحققه الصارم (حقل مجهول/نطاق/عملة مفقودة = 400).
   لا خادم ولا قاعدة بيانات حقيقية: لا شيء هنا يثبت التكامل مع الخلفية الفعلية. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv } = require('./harness.js');
const { world, tick } = require('./session_world.js');

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const err = (status, code, fields) => json(status, { error: { code, message: 'm', requestId: 'r', fields } });
const iso = '2026-01-01T00:00:00.000Z';
const CAR_KEYS = ['q', 'limit', 'before', 'source', 'showroomId', 'brand', 'model', 'color', 'transmission', 'fuelType', 'status', 'yearMin', 'yearMax', 'currency', 'priceMin', 'priceMax'];

function catalogWorld() {
  const w = world();
  const d = { showrooms: [], cars: [], seq: 0, fail: null, gate: null, delay: null };
  d.showroom = (o) => { const s = Object.assign({ id: String(++d.seq), name: 'معرض الفرات', description: 'وصف', phone: '+9647801111111', whatsapp: null, address: 'النجف - الكوفة', latitude: 32.0, longitude: 44.3, workingHours: '9-5', services: ['صيانة'], createdAt: iso, updatedAt: iso }, o); d.showrooms.push(s); return s; };
  d.car = (o) => { const c = Object.assign({ id: String(++d.seq), sourceType: 'showroom', showroomId: null, brand: 'Toyota', model: 'Camry', year: 2020, price: 25000000, currency: 'IQD', mileage: 1000, transmission: 'أوتوماتيك', fuelType: 'بنزين', color: 'أبيض', description: '', status: 'available', phone: null, whatsapp: null, location: '', latitude: null, longitude: null, ownerName: null, createdAt: iso, updatedAt: iso }, o); d.cars.push(c); return c; };
  const base = w.fetchImpl;
  w.fetchImpl = async function (url, init) {
    const u = new URL(url, 'https://app.test');
    if (!u.pathname.startsWith('/v1/public/')) return base(url, init);
    const h = {}; Object.keys(init.headers || {}).forEach(k => { h[k.toLowerCase()] = init.headers[k]; });
    const call = { path: u.pathname, query: Object.fromEntries(u.searchParams), headers: h, method: init.method };
    w.srv.calls.push(call);
    if (d.gate) await d.gate(call);
    if (w.srv.down) throw new TypeError('Failed to fetch');
    if (d.fail) { const f = d.fail(call); if (f) return f; }
    const q = call.query, bad = [];
    const id = /^\/v1\/public\/(cars|showrooms)\/([^/]+)$/.exec(u.pathname);
    if (id) {
      const row = (id[1] === 'cars' ? d.cars : d.showrooms).find(x => x.id === id[2]);
      return row ? json(200, { [id[1] === 'cars' ? 'car' : 'showroom']: row }) : err(404, 'not_found');
    }
    const isCars = u.pathname === '/v1/public/cars';
    const allowed = isCars ? CAR_KEYS : ['q', 'limit', 'before'];
    Object.keys(q).forEach(k => { if (!allowed.includes(k)) bad.push({ field: k, code: 'unknown_field' }); });
    if (q.limit !== undefined && (!/^[1-9][0-9]{0,2}$/.test(q.limit) || Number(q.limit) > 50)) bad.push({ field: 'limit', code: 'invalid_format' });
    if (isCars) {
      if ((q.priceMin || q.priceMax) && !q.currency) bad.push({ field: 'currency', code: 'required' });
      if (q.priceMin && q.priceMax && Number(q.priceMin) > Number(q.priceMax)) bad.push({ field: 'priceMax', code: 'invalid_format' });
      if (q.q && q.q.split(' ').length > 5) bad.push({ field: 'q', code: 'too_long' });
    }
    if (bad.length) return err(400, 'validation_failed', bad);
    const limit = Number(q.limit || 20), terms = (q.q || '').toLowerCase().split(' ').filter(Boolean);
    let rows = (isCars ? d.cars : d.showrooms).slice().sort((a, b) => Number(b.id) - Number(a.id));
    if (q.before) rows = rows.filter(r => Number(r.id) < Number(q.before));
    const text = r => (isCars ? [r.brand, r.model, r.color, r.year].join(' ') : [r.name, r.address].join(' ')).toLowerCase();
    rows = rows.filter(r => terms.every(t => text(r).includes(t)));
    if (isCars) {
      if (q.source) rows = rows.filter(r => r.sourceType === q.source);
      if (q.showroomId) rows = rows.filter(r => r.showroomId === q.showroomId);
      if (q.brand) rows = rows.filter(r => r.brand.toLowerCase() === q.brand.toLowerCase());
      if (q.model) rows = rows.filter(r => r.model.toLowerCase() === q.model.toLowerCase());
      if (q.yearMin) rows = rows.filter(r => r.year >= Number(q.yearMin));
      if (q.yearMax) rows = rows.filter(r => r.year <= Number(q.yearMax));
      if (q.currency) rows = rows.filter(r => r.currency === q.currency);
      if (q.priceMin) rows = rows.filter(r => r.price >= Number(q.priceMin));
      if (q.priceMax) rows = rows.filter(r => r.price <= Number(q.priceMax));
    }
    const page = rows.slice(0, limit);
    return json(200, { items: page, nextBefore: page.length === limit ? page[page.length - 1].id : null });
  };
  return { w, d };
}

function page(w, opts) {
  const env = makeEnv({});
  env.ctx.__fetch = w.fetchImpl; env.ctx.__now = () => w.clock.t; env.ctx.__locks = w.locks;
  env.ctx.AbortController = AbortController; env.ctx.__st = () => 1; env.ctx.__ct = () => {};
  env.run("BackendAuth.init({ baseUrl: '/', sessionTransport: 'cookie', fetch: __fetch, now: __now, locks: __locks, setTimeout: __st, clearTimeout: __ct, AbortController })");
  env.run('BackendAuth.onLost(handleAuthLost)');
  // مؤقّت التأخير (debounce) يدويًا: نلتقط الدالة المؤجَّلة ونشغّلها بـ flush()
  let pending = null;
  env.ctx.setTimeout = fn => { pending = fn; return 1; }; env.ctx.clearTimeout = () => { pending = null; };
  const set = (id, v) => env.run(`document.getElementById('${id}').value = ${JSON.stringify(v)}`);
  const p = {
    env, run: c => env.run(c), set, screen: () => env.screen(), route: () => env.run('currentRoute'),
    list: () => env.els.carsList && env.els.carsList.innerHTML,
    calls: re => w.srv.calls.filter(c => re.test(c.path)),
    flush: async () => { const f = pending; pending = null; if (f) f(); await settle(); },
    hasPending: () => !!pending,
  };
  return p;
}
const settle = async () => { for (let i = 0; i < 30; i++) await tick(); };
const CARS = /^\/v1\/public\/cars$/, SHOWROOMS = /^\/v1\/public\/showrooms$/;
const seed = d => {
  const s1 = d.showroom({ name: 'معرض الفرات', address: 'النجف - الكوفة' });
  const s2 = d.showroom({ name: 'معرض الغدير', address: 'النجف - المدينة', latitude: null, longitude: null, phone: null });
  d.car({ showroomId: s1.id, brand: 'Toyota', model: 'Camry', year: 2020, price: 25000000 });
  d.car({ showroomId: s1.id, brand: 'Kia', model: 'Sportage', year: 2022, price: 30000 , currency: 'USD', color: 'أسود' });
  d.car({ showroomId: s2.id, brand: 'Hyundai', model: 'Elantra', year: 2019, price: 18000000 });
  d.car({ sourceType: 'member', showroomId: null, brand: 'Nissan', model: 'Sunny', year: 2015, price: 9000000, status: 'active', location: 'النجف - حي الأمير', phone: '+9647709999999', ownerName: 'علي' });
  return { s1, s2 };
};

/* ====================== الوضع المحلي (دون تغيير) ====================== */

test('الوضع المحلي دون تغيير: السيارات/المعارض/البحث/الرئيسية من البيانات المحلية بلا أي طلب، وفلتر الكيلومترات والمفضلة باقيان', async () => {
  const env = makeEnv(); assert.equal(env.run('BackendCatalog.isEnabled()'), false);
  env.run("go('cars')"); let h = env.screen();
  assert.match(h, /car-card/); assert.match(h, /fav-btn/); assert.match(h, /MinMileage/);
  env.run("go('showrooms')"); assert.match(env.screen(), /showroom-card/);
  env.run("go('search', 'toyota')"); assert.match(env.screen(), /car-card/);
  env.run("go('home')"); assert.match(env.screen(), /homeRecent/);
  env.run("go('map')"); assert.match(env.screen(), /الموقع على الخريطة|لا توجد معارض/);
  env.run("go('recentCars')"); assert.match(env.screen(), /car-card/);
  assert.deepEqual(env.errors, []);
});

/* ====================== السيارات: قائمة وفلاتر وصفحات ====================== */

test('وضع الخادم: قائمة السيارات من GET /v1/public/cars?source=showroom (بلا رمز دخول، حتى لزائر)، لا بيانات محلية، لا مفضلة ولا كيلومترات', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  p.run("go('cars')");
  assert.match(p.screen(), /جارٍ تحميل السيارات/);
  await settle();
  const c = p.calls(CARS);
  assert.ok(c.length >= 1);
  const first = c.find(x => x.query.source === 'showroom' && x.query.limit === '50');
  assert.ok(first, 'قائمة السيارات المعروضة'); assert.ok(c.every(x => x.headers.authorization === undefined), 'مسارات عامة: لا ترويسة دخول');
  const html = p.list();
  assert.match(html, /Toyota Camry/); assert.match(html, /Kia Sportage/); assert.match(html, /Hyundai Elantra/);
  assert.ok(!/Nissan Sunny/.test(html), 'سيارة العضو ليست في قائمة المعارض');
  assert.match(html, /go\('carDetails','\d+'\)/); assert.ok(!/fav-btn|handleFavoriteToggle/.test(html));
  assert.ok(!/MinMileage|MaxMileage/.test(p.screen()), 'الكيلومترات غير مدعومة في العقد');
  assert.ok(!/تويوتا|Corolla|Elantra 2021/.test(html), 'لا بيانات تجريبية محلية');
  assert.deepEqual(p.env.errors, []);
});

test('الفلاتر: الماركة/الموديل/السنة/السعر+العملة تُرسل كمعاملات الخادم، وخيارات الفلاتر من السيارات المحمَّلة (لا ماركات محلية)', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  p.run("go('cars')"); await settle();
  const bar = p.env.els.carsFilterBar.innerHTML;
  assert.match(bar, /value="kia"/i); assert.match(bar, /value="toyota"/i); assert.ok(!/value="honda"/i.test(bar), "خيارات الماركة من نتائج الخادم");
  p.set('carsFilterBrand', 'Kia'); p.run('onCarsFilter()'); await settle();
  let c = p.calls(CARS).filter(x => x.query.brand === 'Kia');
  assert.equal(c.length, 1); assert.equal(c[0].query.source, 'showroom');
  assert.match(p.list(), /Kia Sportage/); assert.ok(!/Toyota Camry/.test(p.list()));
  p.set('carsFilterModel', 'Sportage'); p.set('carsFilterYear', '2022'); p.run('onCarsFilter()'); await settle();
  c = p.calls(CARS).filter(x => x.query.model === 'Sportage');
  assert.equal(c.length, 1); assert.equal(c[0].query.yearMin, '2022'); assert.equal(c[0].query.yearMax, '2022');
  p.run('clearCarsFilters()'); await settle();
  ['carsFilterBrand', 'carsFilterModel', 'carsFilterYear'].forEach(id => p.set(id, ''));   // الحقول الوهمية لا تُعاد رسمها كما في المتصفح
  p.set('carsFilterMinPrice', '10,000,000'); p.set('carsFilterMaxPrice', '٢٠٬٠٠٠٬٠٠٠'); p.run('onCarsRange()'); await settle();
  c = p.calls(CARS).filter(x => x.query.priceMin);
  assert.equal(c.length, 1); assert.equal(c[0].query.priceMin, '10000000'); assert.equal(c[0].query.priceMax, '20000000'); assert.equal(c[0].query.currency, 'IQD', 'العملة إلزامية مع السعر (الدينار افتراضيًا)');
  assert.match(p.list(), /Hyundai Elantra/); assert.ok(!/Toyota Camry/.test(p.list()));
  p.set('carsPriceCurrency', 'USD'); p.set('carsFilterMinPrice', '1000'); p.set('carsFilterMaxPrice', '50000'); p.run('onCarsFilter()'); await settle();
  c = p.calls(CARS).filter(x => x.query.currency === 'USD');
  assert.equal(c.length >= 1, true); assert.match(p.list(), /Kia Sportage/);
  assert.ok(p.calls(CARS).every(x => !('minMileage' in x.query) && !('mileage' in x.query)));
});

test('الفلاتر: نطاق سعر معكوس لا يُرسل (لا 400)، ويظهر تنبيه الفلتر القائم؛ والخطأ 400 من الخادم يعطي رسالة لا بيانات محلية', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  p.run("go('cars')"); await settle();
  p.set('carsFilterMinPrice', '50'); p.set('carsFilterMaxPrice', '10'); p.run('onCarsRange()'); await settle();
  assert.ok(p.calls(CARS).every(x => !x.query.priceMin && !x.query.priceMax), 'لا يُرسل نطاق معكوس');
  d.fail = c => (c.query.brand === 'Boom' ? err(400, 'validation_failed', [{ field: 'brand', code: 'too_long' }]) : null);
  p.run('clearCarsFilters()'); await settle();
  p.set('carsFilterBrand', 'Boom'); p.run('onCarsFilter()'); await settle();
  assert.match(p.list(), /تحقق من قيم البحث والفلاتر/); assert.ok(!/ad-row|car-card/.test(p.list()));
});

test('البحث النصي: q مقصوص لحدود الخادم، debounce (طلب واحد بعد الكتابة المتتالية)، ونتيجة قديمة لا تطغى على الأحدث', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  p.run("go('cars')"); await settle();
  const before = p.calls(CARS).length;
  p.set('x', ''); ['K', 'Ki', 'Kia'].forEach(v => p.run(`onCarsSearch(${JSON.stringify(v)})`));
  assert.equal(p.calls(CARS).length, before, 'لا طلب أثناء الكتابة');
  await p.flush();
  const c = p.calls(CARS).filter(x => x.query.q);
  assert.equal(c.length, 1); assert.equal(c[0].query.q.toLowerCase(), 'kia');
  assert.match(p.list(), /Kia Sportage/); assert.ok(!/Toyota Camry/.test(p.list()));
  // كلمات كثيرة/طويلة: تُقصّ بدل أن يُرفض الطلب كله
  p.run(`onCarsSearch(${JSON.stringify('a b c d e f g h ' + 'x'.repeat(200))})`); await p.flush();
  const last = p.calls(CARS).filter(x => x.query.q).pop();
  assert.ok(last.query.q.split(' ').length <= 5 && Array.from(last.query.q).length <= 100);
  // نتيجة قديمة (تصل بعد الأحدث) لا تُطبَّق
  let release; let n = 0;
  d.gate = c => (c.query.q === 'toyota' && !n++ ? new Promise(r => { release = r; }) : null);
  p.run("onCarsSearch('toyota')"); await p.flush();
  p.run("onCarsSearch('kia')"); await p.flush();
  release(); await settle();
  assert.match(p.list(), /Kia Sportage/); assert.ok(!/Toyota Camry/.test(p.list()), 'نتيجة toyota القديمة لم تطغَ');
  p.run("onCarsSearch('zzz')"); await p.flush();
  assert.match(p.list(), /لم نعثر على سيارات مطابقة/);
});

test('الصفحات: «عرض المزيد» بـ before=nextBefore يُلحق الصفحة التالية؛ وفشله يُبقي القائمة مع رسالة', async () => {
  const { w, d } = catalogWorld(); for (let i = 0; i < 205; i++) d.car({ brand: 'Brand' + i, model: 'M' + i, year: 2020 });
  const p = page(w);
  p.run("go('cars')"); await settle();
  assert.equal((p.list().match(/class="card car-card"/g) || []).length, 200);
  assert.match(p.list(), /والمزيد/); assert.match(p.list(), /عرض المزيد/);
  const nb = p.calls(CARS).find(x => x.query.source === 'showroom' && x.query.limit === '50' && !x.query.before);
  assert.ok(nb);
  d.fail = c => (c.query.before ? err(503, 'unavailable') : null);
  p.run('_carsMore()'); await settle();
  assert.equal((p.list().match(/class="card car-card"/g) || []).length, 200, 'القائمة باقية');
  assert.match(p.list(), /خطأ في الخادم/);
  d.fail = null; p.run('_carsMore()'); await settle();
  assert.equal((p.list().match(/class="card car-card"/g) || []).length, 205);
  assert.ok(!/عرض المزيد/.test(p.list()));
});

test('الحالات: فراغ، خطأ شبكة/خادم برسالة وإعادة المحاولة تنجح، وبلا رجوع صامت للبيانات المحلية', async () => {
  const { w, d } = catalogWorld(); const p = page(w);
  p.run("go('cars')"); await settle();
  assert.match(p.list(), /لا توجد سيارات حاليًا/);
  seed(d); w.srv.down = true; p.run('_carsReload()'); await settle();
  assert.match(p.list(), /تعذّر الاتصال بالخادم/); assert.match(p.list(), /إعادة المحاولة/); assert.ok(!/car-card/.test(p.list()));
  w.srv.down = false; d.fail = c => err(500, 'internal');
  p.run('_carsReload()'); await settle(); assert.match(p.list(), /خطأ في الخادم/);
  d.fail = c => err(429, 'rate_limited'); p.run('_carsReload()'); await settle(); assert.match(p.list(), /محاولات كثيرة/);
  d.fail = c => json(200, { items: [{ id: 'x' }], nextBefore: null }); p.run('_carsReload()'); await settle(); assert.match(p.list(), /ردّ الخادم غير صالح/);
  d.fail = null; p.run('_carsReload()'); await settle(); assert.match(p.list(), /Toyota Camry/);
});

test('سيارات الأعضاء: GET /v1/public/cars?source=member، وبطاقتها بالموقع وشارة «عضو»', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  p.run("go('memberCars')"); await settle();
  const c = p.calls(CARS).find(x => x.query.source === 'member' && x.query.limit === '50');
  assert.ok(c);
  const h = p.env.els.memberCarsList.innerHTML;
  assert.match(h, /Nissan Sunny/); assert.match(h, /حي الأمير/); assert.ok(!/Toyota/.test(h));
});

/* ====================== التفاصيل ====================== */

test('تفاصيل سيارة معرض: GET /v1/public/cars/:id ثم المعرض GET /v1/public/showrooms/:id (الاسم والتواصل)؛ بلا مفضلة', async () => {
  const { w, d } = catalogWorld(); const { s1 } = seed(d); const car = d.cars[0]; const p = page(w);
  p.run("go('cars')"); await settle();
  p.run(`go('carDetails','${car.id}')`);
  assert.match(p.screen(), /جارٍ تحميل السيارة/);
  await settle();
  assert.equal(p.calls(new RegExp(`/cars/${car.id}$`)).length, 1); assert.equal(p.calls(new RegExp(`/showrooms/${s1.id}$`)).length, 1);
  const h = p.screen();
  assert.match(h, /Toyota Camry/); assert.match(h, /معرض الفرات/); assert.match(h, /tel:|wa\.me|maps/); assert.match(h, new RegExp(`go\\('showroomDetails','${s1.id}'\\)`));
  assert.ok(!/fav-inline|handleFavoriteToggle/.test(h));
  assert.equal(p.calls(/\/cars\/\d+$/).every(x => x.headers.authorization === undefined), true);
  p.run('render()'); await settle();
  assert.equal(p.calls(new RegExp(`/cars/${car.id}$`)).length, 1, 'إعادة الرسم لا تكرر الطلب (ذاكرة 30 ث)');
});

test('تفاصيل: سيارة عضو بجهة اتصالها من الخادم؛ 404 «غير موجودة»؛ معرّف غير صالح بلا طلب؛ خطأ شبكة مع إعادة المحاولة', async () => {
  const { w, d } = catalogWorld(); seed(d); const member = d.cars[3]; const p = page(w);
  p.run(`go('carDetails','${member.id}')`); await settle();
  assert.match(p.screen(), /Nissan Sunny/); assert.match(p.screen(), /tel:\+9647709999999|wa\.me|9647709999999/); assert.equal(p.calls(/showrooms\/\d+$/).length, 0);
  p.run("go('carDetails','9999')"); await settle();
  assert.match(p.screen(), /السيارة غير موجودة أو غير متاحة/);
  const n = w.srv.calls.length; p.run("go('carDetails','abc')"); await settle();
  assert.match(p.screen(), /السيارة غير موجودة/); assert.equal(w.srv.calls.length, n, 'معرّف غير صالح: لا طلب');
  w.srv.down = true; p.run(`go('carDetails','${d.cars[1].id}')`); await settle();
  assert.match(p.screen(), /تعذّر الاتصال بالخادم/); assert.match(p.screen(), /إعادة المحاولة/);
  w.srv.down = false; p.run("BackendCatalog.reloadDetail('car', currentParam, _detailsDone('carDetails'));render()"); await settle();
  assert.match(p.screen(), /Kia Sportage/);
});

/* ====================== المعارض ====================== */

test('المعارض: GET /v1/public/showrooms، بحث q (debounce)، بطاقة بلا عدّاد سيارات، وحالات الفراغ/الخطأ', async () => {
  const { w, d } = catalogWorld(); const p = page(w);
  p.run("go('showrooms')"); await settle();
  assert.match(p.env.els.showroomsList.innerHTML, /لا توجد معارض/);
  seed(d); p.run('_showroomsReload()'); await settle();
  const h = p.env.els.showroomsList.innerHTML;
  assert.match(h, /معرض الفرات/); assert.match(h, /معرض الغدير/); assert.match(h, /go\('showroomDetails','\d+'\)/); assert.ok(!/\d+ سيارة/.test(h));
  p.run("onShowroomsSearch('الغدير')"); assert.ok(p.hasPending()); await p.flush();
  assert.ok(p.calls(SHOWROOMS).some(x => x.query.q === 'الغدير'));
  assert.match(p.env.els.showroomsList.innerHTML, /معرض الغدير/); assert.ok(!/معرض الفرات/.test(p.env.els.showroomsList.innerHTML));
  p.run("onShowroomsSearch('لا شيء')"); await p.flush();
  assert.match(p.env.els.showroomsList.innerHTML, /لم نعثر على معارض/);
  w.srv.down = true; p.run('_showroomsReload()'); await settle();
  assert.match(p.env.els.showroomsList.innerHTML, /تعذّر الاتصال/); assert.ok(!/showroom-card/.test(p.env.els.showroomsList.innerHTML));
});

test('تفاصيل المعرض: GET /v1/public/showrooms/:id + سياراته GET /v1/public/cars?showroomId=:id؛ 404 «غير موجود»؛ معرض بلا سيارات', async () => {
  const { w, d } = catalogWorld(); const { s1, s2 } = seed(d); const empty = d.showroom({ name: 'معرض فارغ' }); const p = page(w);
  p.run(`go('showroomDetails','${s1.id}')`); await settle();
  assert.equal(p.calls(new RegExp(`/showrooms/${s1.id}$`)).length, 1);
  const c = p.calls(CARS).find(x => x.query.showroomId === s1.id);
  assert.ok(c); assert.ok(!c.query.source);
  let h = p.screen();
  assert.match(h, /معرض الفرات/); assert.match(h, /النجف - الكوفة/); assert.match(h, /صيانة/); assert.match(h, /Toyota Camry/); assert.match(h, /Kia Sportage/); assert.ok(!/Hyundai Elantra/.test(h), 'سيارات هذا المعرض فقط');
  p.run(`go('showroomDetails','${empty.id}')`); await settle(); assert.match(p.screen(), /لا توجد سيارات في هذا المعرض/);
  p.run("go('showroomDetails','999')"); await settle(); assert.match(p.screen(), /المعرض غير موجود أو غير متاح/);
  void s2;
});

/* ====================== البحث الموحّد ====================== */

test('البحث الموحّد: معارض (q) + سيارات (q + الفلاتر) من الخادم، خيارات الفلاتر من نتائج البحث، وأخطاء مفصّلة', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  p.run("go('search', 'ki')"); await settle();
  assert.ok(p.calls(SHOWROOMS).some(x => x.query.q === 'ki')); assert.ok(p.calls(CARS).some(x => x.query.q === 'ki' && !x.query.source));
  let h = p.env.els.searchResults.innerHTML;
  assert.match(h, /Kia Sportage/); assert.ok(!/Toyota/.test(h));
  assert.match(p.env.els.searchFilterBar.innerHTML, /value="Kia"/);
  p.run("go('search', 'a')"); await settle();
  p.set('searchFilterBrand', 'Toyota'); p.run('onSearchFilter()'); await settle();
  assert.ok(p.calls(CARS).some(x => x.query.q === 'a' && x.query.brand === 'Toyota'));
  assert.match(p.env.els.searchResults.innerHTML, /Toyota Camry/);
  d.fail = c => (c.path === '/v1/public/showrooms' ? err(500, 'internal') : null);
  p.run('clearSearchFilters()'); p.run("go('search', 'toy')"); await settle();
  assert.match(p.env.els.searchResults.innerHTML, /خطأ في الخادم/);
  d.fail = null; p.run('_searchReload()'); await settle();
  p.run("go('search', 'qqqq')"); await settle();
  assert.match(p.env.els.searchResults.innerHTML, /لم نعثر على سيارات مطابقة/);
});

/* ====================== الرئيسية والأحدث والخريطة ====================== */

test('الرئيسية: أقسامها من الخادم (أحدث 10) بحالات مستقلة؛ فشل قسم لا يُسقط البقية ولا يعرض بيانات محلية', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  d.fail = c => (c.path === '/v1/public/showrooms' ? err(500, 'internal') : null);
  p.run("go('home')"); await settle();
  assert.ok(p.calls(CARS).some(x => x.query.limit === '10' && !x.query.source), 'الأحدث'); assert.ok(p.calls(CARS).some(x => x.query.source === 'showroom' && x.query.limit === '10'));
  assert.ok(p.calls(CARS).some(x => x.query.source === 'member' && x.query.limit === '10'));
  const h = p.screen();
  assert.match(h, /Toyota Camry/); assert.match(h, /Nissan Sunny/); assert.match(h, /خطأ في الخادم/); assert.ok(!/معرض الفرات/.test(h));
  d.fail = null; p.run('_homeRetry()'); await settle();
  assert.match(p.screen(), /معرض الفرات/);
});

test('السيارات المضافة حديثًا والخريطة من الخادم (الأحدث أولًا؛ معرّفات نصية في الروابط)', async () => {
  const { w, d } = catalogWorld(); const { s1 } = seed(d); const p = page(w);
  p.run("go('recentCars')"); await settle();
  const h = p.env.els.recentCarsList.innerHTML;
  assert.ok(h.indexOf('Nissan Sunny') < h.indexOf('Toyota Camry'), 'الأحدث (الأعلى معرّفًا) أولًا');
  p.run("go('map')"); await settle();
  assert.match(p.screen(), new RegExp(`go\\('showroomDetails','${s1.id}'\\)`)); assert.match(p.screen(), /معرض الغدير/); assert.match(p.screen(), /الموقع غير متوفر/);
});

/* ====================== انحدار وعزل ====================== */

test('التنقل: الرجوع إلى تفاصيل الخادم لا يُتخطّى (الشاشة تبقى صالحة في سجل التنقل)', async () => {
  const { w, d } = catalogWorld(); seed(d); const car = d.cars[0]; const p = page(w);
  p.run("go('cars')"); await settle(); p.run(`go('carDetails','${car.id}')`); await settle();
  p.run("go('showrooms')"); await settle(); p.run('goBack("home")'); await settle();
  assert.equal(p.route(), 'carDetails'); assert.equal(p.run('currentParam'), car.id);
  assert.match(p.screen(), /Toyota Camry/);
});

test('الدخول لا يغيّر شيئًا: مستخدم مسجَّل يتصفح بلا ترويسة دخول، والذاكرة المؤقتة تُبطَل بعد كتابة التاجر', async () => {
  const { w, d } = catalogWorld(); seed(d); const p = page(w);
  await p.run("BackendAuth.login('07700000003', 'Pa55w0rd-1')");
  p.run("go('cars')"); await settle();
  assert.ok(p.calls(CARS).length > 0 && p.calls(CARS).every(x => x.headers.authorization === undefined));
  const n = p.calls(CARS).length; p.run('render()'); await settle();
  assert.equal(p.calls(CARS).length, n, 'ذاكرة مؤقتة');
  p.run('BackendCatalog.invalidate()'); p.run('render()'); await settle();
  assert.ok(p.calls(CARS).length > n, 'بعد الإبطال يُعاد الجلب');
});

test('عزل: BackendCatalog قراءة فقط (GET) بلا تخزين/console/fetch مباشر، ولا سكربت جديد (87)', () => {
  const root = path.join(__dirname, '..');
  const all = fs.readFileSync(path.join(root, 'api/authBridge.js'), 'utf8');
  const a = all.indexOf('const BackendCatalog'), b = all.length;
  const src = all.slice(a, b).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(src.length > 2000);
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|\bconsole\.|\bfetch\s*\(|Repository|AppStorage/.test(src));
  assert.ok(!/api\.(post|patch|put|delete)\(/.test(src));
  assert.deepEqual([...src.matchAll(/api\.get\(([^,)]+)/g)].map(m => m[1].trim()).sort(), ['path', 'path']);
  assert.ok(/auth: 'none'/.test(src));
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.equal((html.match(/<script src=/g) || []).length, 87);
});

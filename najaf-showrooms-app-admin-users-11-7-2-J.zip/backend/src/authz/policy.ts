// Authorization core (Phase 11.5, Step 5.1): PRIVATE authorization as pure, deny-by-default functions.
//
// can(actor, action, resource) answers only "may this authenticated actor do this to this resource?". No I/O, no request data.
// A null actor (guest, or an account that may not act) is never allowed. An unknown action or kind is never allowed.

import type { Actor } from './actor.ts';
import type { Resource } from './resources.ts';

export type Action = 'read' | 'update' | 'delete' | 'moderate';

const ACTIONS: ReadonlySet<string> = new Set<Action>(['read', 'update', 'delete', 'moderate']);

const isAdmin = (a: Actor) => a.role === 'admin';
/** A dealer owns a showroom (and so its cars) by id. A member can never act as a showroom owner. */
const isDealerOwner = (a: Actor, ownerId: string) => a.role === 'dealer' && a.id === ownerId;
const isSelf = (a: Actor, userId: string) => a.id === userId;

export function can(actor: Actor | null, action: Action, resource: Resource): boolean {
  if (!actor || typeof actor !== 'object') return false;
  if (!ACTIONS.has(action)) return false;
  if (typeof resource !== 'object' || resource === null) return false;

  switch (resource.kind) {
    case 'user':
      // Own profile: read and update. Administrators read any account and moderate (suspend/restore) it; they do not edit profiles.
      if (action === 'read') return isSelf(actor, resource.id) || isAdmin(actor);
      if (action === 'update') return isSelf(actor, resource.id);
      if (action === 'moderate') return isAdmin(actor);
      return false;

    case 'showroom':
      // The owner manages the showroom even while it is not public (pending/suspended); only an administrator deletes or moderates.
      if (action === 'read' || action === 'update') return isAdmin(actor) || isDealerOwner(actor, resource.ownerId);
      return isAdmin(actor);

    case 'showroom_car':
      // The showroom's dealer reads, updates and deletes its cars (whatever the showroom's state). An administrator reads any showroom
      // car and may only change its STATUS ('moderate'); generic update and delete are the dealer's alone (Step 5.7 hardening).
      if (action === 'moderate') return isAdmin(actor);
      if (action === 'read') return isAdmin(actor) || isDealerOwner(actor, resource.showroomOwnerId);
      return isDealerOwner(actor, resource.showroomOwnerId);

    case 'member_car':
      // The owner (by id, never by role) manages their own ad; an administrator may read, delete and moderate any ad but not rewrite it.
      if (action === 'read' || action === 'delete') return isSelf(actor, resource.ownerId) || isAdmin(actor);
      if (action === 'update') return isSelf(actor, resource.ownerId);
      return isAdmin(actor);

    case 'dealer_directory':
      // Listing dealer accounts (with their phone numbers) is an administrator's job only.
      return action === 'read' && isAdmin(actor);

    case 'user_directory':
    case 'platform_stats':
      // Phase 11.7.2-J: the account directory (names, phones, emails) and the dashboard counts are read by administrators only.
      // Read is the ONLY action: there is no account state change behind these resources.
      return action === 'read' && isAdmin(actor);

    case 'favorite':
      // Strictly the owner: not even an administrator (least privilege).
      return action !== 'moderate' && isSelf(actor, resource.userId);

    default:
      return false;
  }
}

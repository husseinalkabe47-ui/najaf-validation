// Process entry point: configuration -> database -> role/schema policy -> HTTP server -> graceful shutdown.
// Security failures (bad configuration, privileged database role, missing schema) stop the process with exit code 78.
import { ConfigError, describeDbTarget, loadConfig, redactConfig } from './config.ts';
import { AuthConfigError, loadAuthConfig, redactAuthConfig } from './auth/config.ts';
import { createAccountService } from './auth/account-service.ts';
import { createOtpService } from './auth/otp-service.ts';
import { createArgon2idHasher } from './auth/password.ts';
import { createMemoryRateLimiter } from './auth/rate-limit.ts';
import { SessionCookieConfigError, loadSessionCookieConfig, redactSessionCookieConfig } from './auth/session-cookie.ts';
import { createPgAuthStore } from './auth/repository.ts';
import { createAuthService } from './auth/service.ts';
import { createDb } from './db.ts';
import { createPgDealerStore } from './dealers/repository.ts';
import { createDealerService } from './dealers/service.ts';
import { createPgCatalogRepository } from './catalog/repository.ts';
import { createCatalogService } from './catalog/service.ts';
import { createPgMemberCarStore } from './member-cars/repository.ts';
import { createModerationService, createPgModerationStore } from './member-cars/moderation.ts';
import { createMemberCarService } from './member-cars/service.ts';
import { createPgCarImageStore } from './car-images/repository.ts';
import { createCarImageService } from './car-images/service.ts';
import { createPgShowroomImageStore } from './showroom-car-images/repository.ts';
import { createShowroomCarImageService } from './showroom-car-images/service.ts';
import { createPgAdminUsersRepository } from './admin-users/repository.ts';
import { createAdminUsersService } from './admin-users/service.ts';
import { createPgFavoriteStore } from './favorites/repository.ts';
import { createFavoriteService } from './favorites/service.ts';
import { createPgShowroomCarStore } from './showroom-cars/repository.ts';
import { createShowroomCarService } from './showroom-cars/service.ts';
import { StorageConfigError, createStorage, loadStorageConfig, redactStorageConfig } from './storage/index.ts';
import { createPgAssetStore } from './assets/repository.ts';
import { createAssetService } from './assets/service.ts';
import { createPgProcessingRepository } from './assets/processing-repository.ts';
import { createAssetProcessor } from './assets/processing-service.ts';
import type { ImageCodec } from './assets/codec.ts';
import { createPgDeliveryRepository } from './assets/delivery-repository.ts';
import { createAssetDelivery } from './assets/delivery.ts';
import { createPgCoverStore } from './assets/cover-repository.ts';
import { createShowroomCoverService } from './assets/cover.ts';
import { createUnconfiguredMessagingProvider } from './messaging/provider.ts';
import { describeError } from './errors.ts';
import { RoleError, assertAppRole } from './role.ts';
import { buildServer } from './server.ts';
import { createConsoleLogger } from './types.ts';

const EX_CONFIG = 78;
const boot = createConsoleLogger();

async function main(): Promise<void> {
  let config;
  try {
    config = loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      boot.error({ problems: e.problems }, 'invalid configuration');
      process.exit(EX_CONFIG);
    }
    throw e;
  }
  boot.info({ config: redactConfig(config) }, 'configuration loaded');

  let authConfig;
  try {
    authConfig = loadAuthConfig();
  } catch (e) {
    if (e instanceof AuthConfigError) {
      boot.error({ problems: e.problems }, 'invalid authentication configuration');
      process.exit(EX_CONFIG);
    }
    throw e;
  }
  boot.info({ auth: redactAuthConfig(authConfig) }, 'authentication configuration loaded');

  // Cookie transport for the refresh token (Phase 11.7.2.2): optional; disabled unless AUTH_COOKIE_ORIGINS is set.
  let sessionCookie;
  try {
    sessionCookie = loadSessionCookieConfig();
  } catch (e) {
    if (e instanceof SessionCookieConfigError) {
      boot.error({ problems: e.problems }, 'invalid session cookie configuration');
      process.exit(EX_CONFIG);
    }
    throw e;
  }
  boot.info({ sessionCookie: redactSessionCookieConfig(sessionCookie) }, 'session cookie configuration loaded');

  // Object storage (Phase 11.6.2) is optional: without STORAGE_PROVIDER the upload routes are simply not registered. When it IS set,
  // the whole storage configuration must be valid or the process stops (problems are listed without values).
  let storageConfig = null;
  if ((process.env['STORAGE_PROVIDER'] ?? '') !== '') {
    try {
      storageConfig = loadStorageConfig();
    } catch (e) {
      if (e instanceof StorageConfigError) {
        boot.error({ problems: e.problems }, 'invalid storage configuration');
        process.exit(EX_CONFIG);
      }
      throw e;
    }
    boot.info({ storage: redactStorageConfig(storageConfig) }, 'storage configuration loaded');
  } else {
    boot.warn({ event: 'storage.not_configured' }, 'no object storage is configured: image upload routes are disabled');
  }

  const db = await createDb(config.db, { logger: boot });
  try {
    await db.ping();
    if (config.db.requireAppRole) assertAppRole(await db.verifyRole());
    const { missing } = await db.checkSchema();
    if (missing.length > 0) {
      boot.error({ missing }, 'database schema does not satisfy the backend contract (apply database/migrations 0001-0013)');
      await db.close();
      process.exit(EX_CONFIG);
    }
  } catch (e) {
    if (e instanceof RoleError) {
      boot.error({ violations: e.violations, target: describeDbTarget(config.db) }, 'refusing to run with a privileged database role');
      await db.close();
      process.exit(EX_CONFIG);
    }
    boot.error({ err: describeError(e), target: describeDbTarget(config.db) }, 'database startup check failed');
    await db.close();
    process.exit(1);
  }

  // Authentication needs argon2: prove the native module works BEFORE accepting traffic.
  const hasher = createArgon2idHasher();
  try {
    await hasher.ready();
  } catch (e) {
    boot.error({ err: describeError(e) }, 'password hasher (argon2) is not usable');
    await db.close();
    process.exit(1);
  }
  const auth = createAuthService({ store: createPgAuthStore(db), hasher, accessTokenSecret: authConfig.accessTokenSecret, logger: boot });

  // No SMS/WhatsApp provider is integrated yet: the OTP flows run end to end, but nothing can be delivered. Say so loudly.
  boot.warn({ event: 'messaging.provider_not_configured' }, 'no messaging provider is configured: one-time codes cannot be delivered');
  const otp = createOtpService({ store: createPgAuthStore(db), hasher, provider: createUnconfiguredMessagingProvider(), otpSecret: authConfig.accessTokenSecret, logger: boot });

  const account = createAccountService({ store: createPgAuthStore(db), hasher, logger: boot });

  const dealers = { registration: auth, lifecycle: createDealerService({ store: createPgDealerStore(db), logger: boot }) };

  const catalog = createCatalogService({ repo: createPgCatalogRepository(db) });

  const memberCars = createMemberCarService({ store: createPgMemberCarStore(db) });
  const memberCarModeration = createModerationService({ store: createPgModerationStore(db) });

  const carImages = createCarImageService({ store: createPgCarImageStore(db) });
  const showroomCarImages = createShowroomCarImageService({ store: createPgShowroomImageStore(db) });
  const adminUsers = createAdminUsersService({ repo: createPgAdminUsersRepository(db) });
  const favorites = createFavoriteService({ store: createPgFavoriteStore(db) });
  const showroomCars = createShowroomCarService({ store: createPgShowroomCarStore(db) });
  // Image processing (Phase 11.6.3) runs with uploads: decode with limits, WebP + thumbnail, metadata stripped, then 'ready'.
  // The native codec (sharp) is loaded only when storage is configured, and must load BEFORE traffic is accepted.
  let imageCodec: ImageCodec | null = null;
  if (storageConfig) {
    try {
      const { createSharpCodec } = await import('./assets/sharp-codec.ts');
      imageCodec = createSharpCodec();
    } catch (e) {
      boot.error({ err: describeError(e) }, 'image codec (sharp) is not usable: run "npm install"');
      await db.close();
      process.exit(1);
    }
  }
  const storage = storageConfig ? createStorage(storageConfig) : null;
  const assets = storageConfig && storage && imageCodec
    ? createAssetService({
        store: createPgAssetStore(db), storage, maxObjectBytes: storageConfig.maxObjectBytes, logger: boot,
        processor: createAssetProcessor({ repo: createPgProcessingRepository(db), storage, codec: imageCodec, logger: boot }),
      })
    : undefined;
  // Delivery of processed images and the dealer's showroom cover (Phase 11.6.4): with storage only (there are no images without it).
  const assetDelivery = assets && storage ? createAssetDelivery({ repo: createPgDeliveryRepository(db), storage, logger: boot }) : undefined;
  const showroomCover = assets ? createShowroomCoverService({ store: createPgCoverStore(db) }) : undefined;

  const app = await buildServer({ config, db, auth, otp, account, dealers, catalog, memberCars, memberCarModeration, carImages, showroomCarImages, adminUsers, favorites, showroomCars, ...(assets ? { assets } : {}), ...(assetDelivery ? { assetDelivery } : {}), ...(showroomCover ? { showroomCover } : {}), rateLimiter: createMemoryRateLimiter(), ...(sessionCookie ? { sessionCookie } : {}), trustProxy: authConfig.trustedProxies });
  await app.listen({ host: config.server.host, port: config.server.port });

  let stopping = false;
  const stop = async (signal: string): Promise<void> => {
    if (stopping) return;
    stopping = true;
    app.log.info({ signal }, 'shutting down');
    const force = setTimeout(() => process.exit(1), 10_000);
    force.unref();
    try {
      await app.close();
      await db.close();
      process.exit(0);
    } catch (e) {
      app.log.error({ err: describeError(e) }, 'shutdown failed');
      process.exit(1);
    }
  };
  process.on('SIGTERM', () => void stop('SIGTERM'));
  process.on('SIGINT', () => void stop('SIGINT'));
}

main().catch((e) => {
  boot.error({ err: describeError(e) }, 'fatal startup error');
  process.exit(1);
});

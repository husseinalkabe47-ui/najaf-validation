/* AdminDashboardScreen — الشاشة الرئيسية للوحة الإدارة. بطاقات إحصائية قابلة
   للضغط + قائمة تنقل لبقية شاشات الإدارة. القراءة فقط عبر adminService.
   إصلاح (الإحصائيات): معامل التنقل كان يُكتب JSON.stringify(param) أي "pending" بعلامتي اقتباس مزدوجتين داخل سمة
   onclick المحاطة بمزدوجتين، فتنقطع السمة (go('adminMemberCars',) وتنتهي بـ SyntaxError: Unexpected end of input
   بدل الانتقال (بطاقات قيد المراجعة/نشطة/مباعة/مرفوضة). الآن يمرّ المعامل عبر esc() كباقي الشاشات.
   «قيد المراجعة» (pending) لا ينتجها النشر الجديد أبدًا (النشر بعد المكافأة = active مباشرة)؛ تمثل اليوم سجلات قديمة
   أو سجلات أعادتها الإدارة للمراجعة (restoreMemberCar)، فالبطاقة تذكر ذلك صراحةً. */
/* (11.7-E) وضع الخادم: أقسام الإدارة المدعومة (أصحاب المعارض، مراجعة الإعلانات). (11.7.2-J) الإحصاءات من GET /v1/admin/stats
   (BackendUserDirectory) بالبطاقات والتسميات نفسها للوضع المحلي؛ تحميل/خطأ + إعادة المحاولة بلا أرقام محلية. وما لا مسار له يُذكر صراحةً. */
function _AdminStatsRemote() {
  const st = BackendUserDirectory.stats(_rerenderIf(currentRoute));
  if (st.status === 'loading') return '<div class="placeholder" role="status" aria-busy="true"><span class="ic" aria-hidden="true">⏳</span><b>جارٍ تحميل الإحصاءات…</b></div>';
  if (st.status !== 'ready') return `<div role="alert" class="form-error">${esc(st.error || BackendUserDirectory.messages.stats)} <button type="button" class="link-btn" onclick="BackendUserDirectory.retryStats(_rerenderIf(currentRoute));render()">إعادة المحاولة</button></div>`;
  const s = st.data;
  const card = (num, label, route, param, hint) =>
    `<div class="stat-card" role="button" tabindex="0" onclick="go('${route}'${param !== undefined ? `,${esc(JSON.stringify(param))}` : ''})"><div class="num">${esc(num)}</div><div class="lbl">${label}</div>${hint ? `<div class="lbl">${hint}</div>` : ''}</div>`;
  return `
    <div class="stats-grid">
      ${card(s.totalUsers, 'إجمالي المستخدمين', 'adminUsers')}
      ${card(s.totalShowrooms, 'إجمالي المعارض', 'adminShowrooms')}
      ${card(s.totalShowroomCars, 'سيارات المعارض', 'adminShowroomCars')}
      ${card(s.totalMemberCars, 'سيارات الأعضاء', 'adminMemberCars', 'all')}
      ${card(s.pendingMemberCars, 'قيد المراجعة', 'adminMemberCars', 'pending')}
      ${card(s.activeMemberCars, 'إعلانات نشطة', 'adminMemberCars', 'active')}
      ${card(s.soldMemberCars, 'إعلانات مباعة', 'adminMemberCars', 'sold')}
      ${card(s.rejectedMemberCars, 'إعلانات مرفوضة', 'adminMemberCars', 'rejected')}
    </div>`;
}
function _AdminDashboardRemote() {
  const badge = BackendAdmin.pendingBadge(_rerenderIf(currentRoute));
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1><p class="sub">مرحبًا ${esc((SessionService.getCurrentUser() || {}).name || '')}</p></div>
  <div class="section">
    <h2>📊 الإحصائيات</h2>
    ${_AdminStatsRemote()}
    <div class="admin-menu">
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminDealerRequests')">🏪 أصحاب المعارض (طلبات وحالة الحساب)${badge === null ? '' : ` <span class="badge-count">${esc(badge)}</span>`}</div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminMemberCars','pending')">🚗 مراجعة إعلانات الأعضاء (موافقة/رفض/إيقاف/استعادة)</div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminUsers')">👥 المستخدمون</div>
    </div>
    <div class="placeholder" style="margin-top:14px"><span class="ic" aria-hidden="true">ℹ️</span>غير متاح بعد مع الخادم (لا مسار إداري له في الخلفية): قائمة المعارض، وسيارات المعارض.</div>
  </div>`;
}
function AdminDashboardScreen() {
  if (BackendAdmin.isEnabled()) return _AdminDashboardRemote();
  const s = getDashboardStats();
  const card = (num, label, route, param, hint) =>
    `<div class="stat-card" role="button" tabindex="0" onclick="go('${route}'${param !== undefined ? `,${esc(JSON.stringify(param))}` : ''})"><div class="num">${num}</div><div class="lbl">${label}</div>${hint ? `<div class="lbl">${hint}</div>` : ''}</div>`;
  return `
  <div class="topbar"><h1>🛡️ لوحة الإدارة</h1><p class="sub">مرحبًا ${(SessionService.getCurrentUser() || {}).name || ''}</p></div>
  <div class="section">
    <h2>📊 الإحصائيات</h2>
    <div class="stats-grid">
      ${card(s.totalUsers, 'إجمالي المستخدمين', 'adminUsers')}
      ${card(s.totalShowrooms, 'إجمالي المعارض', 'adminShowrooms')}
      ${card(s.totalShowroomCars, 'سيارات المعارض', 'adminShowroomCars')}
      ${card(s.totalMemberCars, 'سيارات الأعضاء', 'adminMemberCars', 'all')}
      ${card(s.pendingMemberCars, 'قيد المراجعة', 'adminMemberCars', 'pending', 'سجلات قديمة أو أعادتها الإدارة')}
      ${card(s.activeMemberCars, 'إعلانات نشطة', 'adminMemberCars', 'active')}
      ${card(s.soldMemberCars, 'إعلانات مباعة', 'adminMemberCars', 'sold')}
      ${card(s.rejectedMemberCars, 'إعلانات مرفوضة', 'adminMemberCars', 'rejected')}
    </div>
    <div class="admin-menu">
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminMemberCars','pending')">🚗 سجلات الأعضاء بانتظار قرار الإدارة <span class="badge-count">${s.pendingMemberCars}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminShowrooms')">🏢 المعارض <span class="badge-count">${s.totalShowrooms}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminShowroomCars')">🚘 سيارات المعارض <span class="badge-count">${s.totalShowroomCars}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminUsers')">👥 المستخدمون <span class="badge-count">${s.totalUsers}</span></div>
      <div class="admin-menu-item" role="button" tabindex="0" onclick="go('adminDealerRequests')">🏪 طلبات أصحاب المعارض <span class="badge-count">${s.pendingDealers}</span></div>
    </div>
  </div>`;
}
